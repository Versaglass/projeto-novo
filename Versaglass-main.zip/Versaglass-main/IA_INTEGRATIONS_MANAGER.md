# IA Intelligence — Centro de Integrações Inteligentes

Implementado módulo para a IA Intelligence configurar, diagnosticar, corrigir e monitorar integrações da VersaGlass.

## Incluído

- Página `/app/integracoes`, visível apenas para ADM.
- Provedores prontos: Mercado Livre, Shopee, TikTok Shop, Shopify, WooCommerce, Asaas, Efí, Mercado Pago, Pagar.me, PlugNotas, TecnoSpeed, Nuvem Fiscal, WhatsApp Business API, Google Agenda, Google Drive e SMTP.
- Diagnóstico de tokens, webhooks, status, últimas sincronizações e erros.
- Ações com confirmação obrigatória por senha ADM.
- Sincronização preparada para produtos, estoque, pedidos, clientes, preços e imagens.
- Jobs de correção para testar conexão, validar token, recriar webhook e registrar log.
- Integração com IA Intelligence via comandos em linguagem natural.
- Migration Supabase com RLS.

## Arquivos principais

- `src/lib/integration-architect.ts`
- `src/routes/_authenticated/app.integracoes.tsx`
- `src/lib/ia-intelligence.ts`
- `src/components/AppShell.tsx`
- `supabase/migrations/20260704133000_ia_integrations_manager.sql`

## Segurança

Usuário comum não vê o módulo. Toda ação crítica cria prévia e exige senha ADM antes da execução.
