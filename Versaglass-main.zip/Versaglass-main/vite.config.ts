// @lovable.dev/vite-tanstack-config already includes the base TanStack/React/Tailwind config.
// Add only safe production optimizations here.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

export default defineConfig({
  tanstackStart: {
    server: { entry: "server" },
  },
  // ALVO DE PRODUÇÃO: VERCEL (Revisão 63).
  //
  // O wrapper da Lovable injeta `defaultPreset: "cloudflare-module"`. Repare que
  // é `defaultPreset`, não `preset`: é FALLBACK, usado só quando nada mais
  // determinou o alvo. A ordem de resolução do Nitro é
  //
  //     preset explícito → NITRO_PRESET → SERVER_PRESET
  //                      → auto-detecção do provedor → defaultPreset
  //
  // e a Vercel define `VERCEL=1` em toda build, então lá a auto-detecção já
  // acertaria sozinha (medido na Revisão 62). Fixamos assim mesmo, e o motivo
  // NÃO é produção — é o build LOCAL.
  //
  // Sem esta linha, quem constrói nesta máquina cai no fallback e gera um
  // WORKER da Cloudflare, enquanto produção gera uma função Node da Vercel:
  // dois artefatos diferentes saindo do mesmo commit. A Revisão 45 pagou por
  // isso — "produção não sobe local porque o preset é Cloudflare;
  // `.output/server/index.mjs` é Worker, não servidor Node" — e metade dos
  // tropeços daquele dia veio de medir um artefato que não era o publicado.
  //
  // Com `preset` fixo, `npm run build` produz `.vercel/output` (Build Output
  // API v3) em qualquer máquina, com ou sem `VERCEL` no ambiente.
  nitro: { preset: "vercel" },
  vite: {
    // Falha alto se a porta já estiver ocupada, em vez de escorregar para a
    // próxima livre. Sem isto, um servidor ÓRFÃO de uma sessão anterior continua
    // servindo a aplicação na porta que o navegador tem aberta — com o ambiente
    // que ELE leu ao iniciar — enquanto o processo novo sobe em outra porta e
    // parece saudável. Foi exatamente o que fez a aplicação local falar com o
    // Supabase de PRODUÇÃO (Defeito 2, Revisões 21 e 23).
    server: {
      strictPort: true,
      // HOST TRAVADO EM 127.0.0.1 (Revisão 47).
      //
      // O preset (`@lovable.dev/vite-tanstack-config`) traz `host: "::"`, que
      // faz bind em TODAS as interfaces. Numa máquina Windows com WSL2/Docker
      // isso faz o terminal imprimir várias linhas "Network:", entre elas o IP
      // da vEthernet (`172.30.240.1`) — e abrir a aplicação por esse IP é
      // dramaticamente mais lento. Medido na Revisão 47, mesma máquina, mesmo
      // servidor, só mudando a origem:
      //
      //     172.30.240.1:8080   TTFB 2.560 ms · FCP 18.656 ms
      //     localhost:8080      TTFB    25 ms · FCP  1.428 ms
      //     127.0.0.1:8080      TTFB    22 ms · FCP  1.420 ms
      //
      // 13× de diferença no primeiro pixel. Não é a CSP (zero violações
      // relacionadas ao Supabase em qualquer das origens) nem lentidão da
      // aplicação: é o caminho de rede pela interface virtual, pago em CADA
      // uma das ~245 requisições que o Vite faz em dev.
      //
      // Travar em 127.0.0.1 remove a possibilidade de cair nesse IP por
      // engano: o terminal passa a mostrar só o endereço local.
      //
      // PARA EXPOR NA REDE de propósito (testar num celular, por exemplo),
      // rode `npx vite dev --host` nesta sessão em vez de mudar este arquivo.
      host: "127.0.0.1",
    },
    build: {
      cssCodeSplit: true,
      assetsInlineLimit: 4096,
      rollupOptions: {
        output: {
          manualChunks(id) {
            if (!id.includes("node_modules")) return;
            if (id.includes("@supabase")) return "vendor-supabase";
            if (id.includes("@tanstack")) return "vendor-tanstack";
            if (id.includes("jspdf")) return "vendor-pdf";
            if (id.includes("recharts")) return "vendor-charts";
            if (id.includes("@radix-ui") || id.includes("lucide-react")) return "vendor-ui";
            return "vendor";
          },
        },
      },
    },
  },
});
