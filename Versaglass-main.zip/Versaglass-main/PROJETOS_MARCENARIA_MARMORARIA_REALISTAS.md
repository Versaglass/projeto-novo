# Upgrade — Projetos realistas e editáveis para Marcenaria e Marmoraria

Alterações aplicadas no editor paramétrico de projetos:

## Marcenaria
- Projetos agora abrem com composição realista em peças editáveis: caixa externa, laterais, prateleiras, divisórias, portas, gavetas e puxadores.
- Textura visual de MDF/madeira no SVG.
- Visão 2D, 3D, explodida e plano de corte.
- Ao alterar largura, altura, posição, material, cor, portas, gavetas ou prateleiras, o desenho muda em tempo real.
- Lista de materiais mostra peça, material e quantidade.

## Marmoraria
- Projetos agora abrem com bancada principal, frontão, saia frontal, recorte de cuba, recorte de cooktop e furo de torneira.
- Textura visual de pedra/granito no SVG.
- Alterações de recortes, furo, largura, profundidade, material e acabamento aparecem na hora no desenho.
- Plano de corte lista peças de pedra com medidas.

## Melhorias gerais
- Painel de medidas gerais do projeto.
- Profundidade 3D configurável.
- Campo de acabamento geral.
- Campo de cor HEX por peça.
- Visualização da alteração durante a edição, para o usuário saber exatamente o que está mudando.

Arquivo principal alterado:
- `src/components/ParametricProjectEditor.tsx`

Build testado com sucesso usando `npm run build`.
