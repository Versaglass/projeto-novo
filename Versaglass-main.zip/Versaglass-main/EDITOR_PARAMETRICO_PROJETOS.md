# Upgrade — Editor Paramétrico de Projetos

Alteração aplicada na aba **Projetos**.

## O que foi adicionado

- Botão **Editar projeto** em cada projeto liberado.
- Editor paramétrico para vidraçaria, serralheria de aço, marcenaria e marmoraria.
- Edição de medidas principais:
  - largura
  - altura
  - profundidade
  - material principal
  - acabamento
- Blocos rápidos por área:
  - Vidraçaria: folha de vidro, recorte de fechadura, furo de puxador, dobradiça, puxador e trilho.
  - Serralheria de aço: quadro metalon, travessa, diagonal, chapa de fechamento e dobradiça.
  - Marcenaria: lateral MDF, prateleira, porta, gaveta, dobradiça e corrediça.
  - Marmoraria: tampo, saia, rodabanca, recorte de cuba e recorte de cooktop.
- Edição individual de peças:
  - nome
  - posição X/Y
  - largura
  - altura
  - profundidade
  - quantidade
  - material
- Duplicar e excluir peças.
- Visualização técnica em **2D e 3D**.
- Cálculo estimado de:
  - área m²
  - metro linear
  - quantidade de ferragens
  - valor estimado
- Salvar edição local no navegador.
- Salvar como novo projeto no banco `project_templates`.
- Exportar JSON técnico do projeto editado.

## Arquivos alterados

- `src/routes/_authenticated/app.projetos.tsx`
- `src/components/ParametricProjectEditor.tsx`
- `src/styles.css`

## Observação

Projetos Premium continuam bloqueados e direcionando para assinatura/pagamento. O editor aparece apenas em projetos liberados.
