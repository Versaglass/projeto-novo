# Aba "Diálogo com a IA" — IA Intelligence

Adicionar uma aba de conversa tipo ChatGPT dentro da IA Intelligence, restrita a ADM/super_admin, com chat de texto, comando por voz, resposta em áudio, sugestões, prévia obrigatória e execução confirmada por senha.

## O que já existe (reaproveitar)

- `src/components/ia/IAIntelligencePanel.tsx` — painel atual com voz/mic e execução por senha.
- `src/lib/ia-intelligence.ts` — tipos e executor de ações (produto, estoque, template, integrações, etc.) com snapshot e log.
- `src/lib/ia-intelligence-chat.functions.ts` — server fn `iaAdvise` (OpenAI/Lovable AI Gateway + fallback local) que devolve `{reply, suggestions, refinedCommand, risk}`.
- Rota `/_authenticated/app/ia-intelligence` já gated para ADM.
- Web Speech API (voz) já usada no painel atual.

Não vamos duplicar essa lógica — vamos orquestrar em um novo módulo com abas.

## Estrutura de arquivos

Novos, em `src/modules/ai-intelligence/`:

- `AIDialogPage.tsx` — página com abas: Conversa · Sugestões · Plano · Execuções. Guard ADM.
- `AIDialogChat.tsx` — transcrição (user/assistant), input, envio, streaming visual, markdown.
- `AIVoiceButton.tsx` — botão push-to-talk (SpeechRecognition) + TTS (SpeechSynthesis) da resposta.
- `AIDialogActions.tsx` — cards de sugestões e botões "Gerar plano" / "Executar" / "Cancelar".
- `AIExecutionPreview.tsx` — modal com prévia (diff/JSON), risco, snapshot, campo de senha ADM, botões Executar/Cancelar.
- `aiDialogService.ts` — CRUD de sessões/mensagens/sugestões/prévias/execuções no Supabase.
- `aiCommandPlanner.ts` — chama `iaAdvise` e converte `refinedCommand` em `IAIntent` (reusa parser de `ia-intelligence.ts`).
- `aiActionExecutor.ts` — wrapper que valida senha, cria snapshot, chama executor existente, grava `ai_dialog_executions` + `audit_logs`, faz rollback quando possível.
- `aiVoiceService.ts` — helpers `startListening()`, `stopListening()`, `speak(text)`, detecção de suporte.

Rota: adicionar aba dentro de `app.ia-intelligence.tsx` (ou nova sub-rota `app.ia-intelligence.dialogo.tsx`) que renderiza `AIDialogPage`.

## Modos

Selector no topo do chat:
1. Apenas conversar — não gera prévia, só responde.
2. Sugerir melhorias — retorna lista em `AIDialogActions`.
3. Criar plano — gera prévia estruturada, sem executar.
4. Executar com confirmação — plano + modal de senha.

## Banco de dados (migration)

Cinco tabelas em `public`, com RLS restrita a ADM (`has_role(auth.uid(),'admin')`), grants para `authenticated`/`service_role`, `updated_at` trigger.

- `ai_dialog_sessions` (user_id, title, mode, status)
- `ai_dialog_messages` (session_id, role: user|assistant|system, content, audio_url, tokens)
- `ai_dialog_suggestions` (session_id, message_id, title, description, risk, applied)
- `ai_dialog_action_previews` (session_id, message_id, intent jsonb, preview jsonb, risk, snapshot jsonb, status: pending|approved|rejected|executed)
- `ai_dialog_executions` (preview_id, executed_by, result jsonb, success bool, rollback_available bool, error)

Também grava em `audit_logs` existente.

## Fluxo

1. ADM abre aba → cria/retoma sessão.
2. Digita ou fala → mensagem salva → `iaAdvise` retorna reply + sugestões + refinedCommand + risco.
3. Resposta é falada por TTS quando modo voz está ativo.
4. Se modo ≥ 3: `aiCommandPlanner` gera prévia estruturada e salva em `ai_dialog_action_previews`.
5. `AIExecutionPreview` mostra o que vai mudar + risco + snapshot.
6. ADM clica Executar → digita senha → `aiActionExecutor` valida, executa via `ia-intelligence.ts`, grava execução e audit_log.
7. Rollback disponível quando snapshot existe.

## Segurança

- Guard em `AIDialogPage` (`useAuth().isAdmin`) + RLS no banco.
- Senha ADM obrigatória para toda execução (reutiliza fluxo atual).
- Sem execução automática — sempre prévia + confirmação.
- Logs completos.

## Detalhes técnicos

- Chat usa `iaAdvise` já existente (`useServerFn`), mensagens em array local + persistidas.
- Renderiza markdown com `react-markdown` (já em uso? senão instalar).
- Voz: `window.SpeechRecognition || window.webkitSpeechRecognition` + `speechSynthesis.speak(new SpeechSynthesisUtterance(text))`, `lang="pt-BR"`.
- Nada de mudar código-fonte em runtime — "alterar código" resulta em sugestão registrada, não em edição real do repositório.

## Entrega

- 1 migration (5 tabelas + RLS + grants).
- 9 arquivos novos em `src/modules/ai-intelligence/`.
- Edição de `app.ia-intelligence.tsx` para incluir a nova aba.
- Build passando.
