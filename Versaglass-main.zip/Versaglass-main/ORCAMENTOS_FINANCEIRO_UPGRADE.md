# Upgrade Orçamentos + Financeiro

## Orçamentos
- Botão para editar o nome do cliente diretamente na tela do orçamento.
- Botões visuais em formato de cards para relatórios:
  - Cliente
  - Materiais.pdf
  - Vidros
  - Instalador
  - Recibo
  - Contrato
  - Localização
  - Enviar PDF no WhatsApp
- Geração de PDFs separados para cliente, materiais, vidros, instalador, recibo, contrato e localização.
- Botão de WhatsApp gera o PDF e abre a conversa do cliente com uma mensagem pronta.
- Campo de notas do orçamento.
- Upload de imagem para nota visual, como foto da obra, croqui, comprovante ou detalhe técnico.
- Localização abre o endereço do cliente no Google Maps.

## Financeiro
- Aba Financeiro mantida.
- Nova aba Notas fiscais.
- Nova aba Boletos.
- Cada aba possui CRUD, busca, filtro e armazenamento local compatível com o padrão EnterpriseCrudPage.

## Supabase
Incluída migration para persistência futura:
- quote_notes
- quote_documents
- fiscal_invoices
- payment_slips

As telas continuam funcionando mesmo antes da integração total com banco, mantendo o projeto estável.
