// TikTok Pixel helper. Loader is injected in src/routes/__root.tsx.
type TtqMethod = "page" | "track" | "identify";

type TtqFn = (...args: unknown[]) => void;
type TtqApi = Partial<Record<TtqMethod, TtqFn>>;

function ttq(): TtqApi | null {
  if (typeof window === "undefined") return null;
  const w = window as Window & { ttq?: TtqApi };
  return w.ttq ?? null;
}

export function ttCall(method: TtqMethod, ...args: unknown[]) {
  const q = ttq();
  if (!q || typeof q[method] !== "function") return;
  try {
    q[method]!(...args);
  } catch {
    // Intencionalmente vazio. `ttq` é o pixel do TikTok, script de TERCEIRO: se
    // ele quebrar, for bloqueado por extensão ou mudar de API, isso não pode
    // derrubar a aplicação nem aparecer para o usuário — telemetria é acessória
    // ao produto. Não há ação de recuperação possível do nosso lado.
  }
}

async function sha256(value: string): Promise<string> {
  const data = new TextEncoder().encode(value.trim().toLowerCase());
  const buf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export async function ttIdentify(params: {
  email?: string | null;
  phone?: string | null;
  userId?: string | null;
}) {
  if (typeof window === "undefined") return;
  const payload: Record<string, string> = {};
  if (params.email) payload.email = await sha256(params.email);
  if (params.phone) payload.phone_number = await sha256(params.phone);
  if (params.userId) payload.external_id = await sha256(params.userId);
  ttCall("identify", payload);
}

export function ttTrack(event: string, payload?: Record<string, unknown>) {
  ttCall("track", event, payload ?? {});
}
