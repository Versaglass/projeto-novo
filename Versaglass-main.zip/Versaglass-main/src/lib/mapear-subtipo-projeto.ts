import { ehQuoteItemTipoProjeto } from "@/lib/quote-item-tipo-helpers";
import type { QuoteItemTipoProjeto } from "@/lib/tipo-projeto-orcamento";

/**
 * `project_templates.subtipo` → `quote_items.tipo_projeto` (select do item).
 *
 * Áreas operacionais (Vidraçaria + Esquadrias): IDs idênticos ao enum → 1:1.
 *
 * Legado (pré-lista comercial nos modelos):
 *   porta_vidro → porta, janela_vidro → janela
 *   fechamento_vidro / outro_vidracaria → null (sem par inequívoco)
 *
 * Sem par → `null` (select "— Sem tipo —"):
 *   + subtipos legado de Esquadrias (`janela_aluminio_esquadrias`, …)
 *   + subtipos de Serralheria / Marcenaria / Marmoraria
 */
const MAPA_SUBTIPO_LEGADO: Record<string, QuoteItemTipoProjeto> = {
  porta_vidro: "porta",
  janela_vidro: "janela",
};

export function mapearSubtipoParaTipoProjetoOrcamento(
  subtipo: string | null | undefined,
): QuoteItemTipoProjeto | null {
  if (!subtipo) return null;
  if (ehQuoteItemTipoProjeto(subtipo)) return subtipo;
  const legado = MAPA_SUBTIPO_LEGADO[subtipo];
  if (legado) return legado;
  return null;
}
