import { logServerEvent, type LogResult } from "@/lib/logging.functions";
import { mensagemDoErro } from "@/lib/erro-mensagem";

export type LogLevel = "info" | "warn" | "error";
export type { LogResult };

/**
 * Executa uma chamada de log tratando a falha de forma explícita.
 *
 * IMPORTANTE: só escreve no console. Nunca chame outro helper de log daqui —
 * um erro ao registrar log não pode disparar outro log e virar laço.
 * A mensagem do erro NÃO vai para o console: pode carregar trecho de payload.
 */
export async function runLogCall(
  fn: () => Promise<LogResult>,
  contexto: string,
): Promise<LogResult> {
  try {
    return await fn();
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    const code = /forbidden/i.test(message)
      ? "forbidden"
      : /unauthorized|no authorization|invalid token/i.test(message)
        ? "unauthenticated"
        : /parse|invalid|expected/i.test(message)
          ? "invalid_payload"
          : "log_ingest_failed";
    console.warn(`[log:${contexto}] não registrado (${code})`);
    return { success: false, code, message };
  }
}

/**
 * Registro de aplicação em public.server_logs.
 *
 * A gravação acontece no servidor (ver `logging.functions.ts`): o navegador
 * não tem — e não deve ter — permissão de INSERT nesta tabela. `user_id` e
 * `user_email` são derivados do token validado, não enviados daqui.
 *
 * Exige sessão. Sem sessão devolve `{ success: false, code: "unauthenticated" }`
 * em vez de falhar em silêncio, como acontecia antes.
 */
export async function serverLog(
  action: string,
  data: {
    level?: LogLevel;
    status?: number;
    duration_ms?: number;
    message?: string;
    metadata?: Record<string, unknown>;
  } = {},
): Promise<LogResult> {
  return runLogCall(
    () =>
      logServerEvent({
        data: {
          action,
          level: data.level ?? "info",
          status: data.status,
          durationMs: data.duration_ms,
          message: data.message,
          metadata: data.metadata,
        },
      }),
    `server_logs:${action}`,
  );
}

/** Envolve uma promise medindo duração e registrando sucesso/erro. */
export async function withServerLog<T>(
  action: string,
  fn: () => Promise<T>,
  meta: Record<string, unknown> = {},
): Promise<T> {
  const t0 = Date.now();
  try {
    const r = await fn();
    // Falha de log não derruba a operação principal: `serverLog` já devolve
    // resultado tipado em vez de lançar.
    void serverLog(action, {
      level: "info",
      status: 200,
      duration_ms: Date.now() - t0,
      metadata: meta,
    });
    return r;
  } catch (e: unknown) {
    void serverLog(action, {
      level: "error",
      status: 500,
      duration_ms: Date.now() - t0,
      message: mensagemDoErro(e) ?? String(e),
      metadata: meta,
    });
    throw e;
  }
}
