import { supabase } from "@/integrations/supabase/client";
import { brl, num } from "@/lib/format";
import { composeAddress, formatDoc, formatPhone, docLabel } from "@/lib/quote-company-pdf";
import { pagamentoLabel, type SaleDocument, type SaleUnit } from "@/hooks/use-sales";

/**
 * Comprovante térmico de venda (NÃO FISCAL).
 *
 * Fonte: `SaleDocument` lido do banco (`sales` + `sale_items` + customer).
 * Empresa: `company_profiles` da venda (`sale.company_id`), sem logo —
 * prioriza impressão confiável em 80 mm.
 */

export type SaleReceiptCompany = {
  company_name: string | null;
  cnpjFormatted: string | null;
  phoneFormatted: string | null;
  email: string | null;
  addressLine: string | null;
  cityState: string | null;
};

const UNIDADE_LABEL: Record<SaleUnit, string> = {
  m: "m",
  m2: "m²",
  un: "un",
  kg: "kg",
  pc: "pç",
  cx: "cx",
};

/** Cabeçalho da empresa da venda — só texto; campos vazios viram null. */
export async function loadSaleReceiptCompany(
  companyId: string | null | undefined,
): Promise<SaleReceiptCompany | null> {
  if (!companyId) return null;

  const { data, error } = await supabase
    .from("company_profiles")
    .select("company_name, cnpj, phone, email, address, city, state")
    .eq("id", companyId)
    .maybeSingle();

  if (error) {
    console.error("Não foi possível carregar a empresa do comprovante.", error);
    return null;
  }
  if (!data) return null;

  const city = (data.city ?? "").trim();
  const state = (data.state ?? "").trim();
  const cityState = city && state ? `${city} - ${state}` : city || state || null;

  return {
    company_name: (data.company_name ?? "").trim() || null,
    cnpjFormatted: formatDoc(data.cnpj),
    phoneFormatted: formatPhone(data.phone),
    email: (data.email ?? "").trim() || null,
    addressLine: composeAddress(data.address, null, null),
    cityState,
  };
}

/** Data/hora pt-BR: DD/MM/YYYY HH:mm */
export function formatSaleReceiptDateTime(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  const data = d.toLocaleDateString("pt-BR");
  const hora = d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  return `${data} ${hora}`;
}

export function saleReceiptCustomerName(doc: SaleDocument): string {
  const cadastrado = (doc.customer?.nome ?? "").trim();
  if (cadastrado) return cadastrado;
  const avulso = (doc.sale.cliente_nome ?? "").trim();
  if (avulso) return avulso;
  return "Consumidor final";
}

export function saleReceiptCustomerDoc(doc: SaleDocument): {
  label: string;
  value: string;
} | null {
  const raw = doc.customer?.documento ?? null;
  const value = formatDoc(raw);
  if (!value) return null;
  return { label: docLabel(raw), value };
}

export function saleReceiptPaymentLabel(doc: SaleDocument): string {
  return pagamentoLabel(doc.sale.forma_pagamento);
}

export function saleReceiptItemQtyLine(item: SaleDocument["items"][number]): string {
  const un = UNIDADE_LABEL[item.unidade] ?? item.unidade;
  if (item.unidade === "m2") {
    const area = Number(item.m2) || 0;
    return `${num(area, 4)} ${un} x ${brl(Number(item.preco_unit) || 0)}`;
  }
  const qtd = Number(item.quantidade) || 0;
  return `${num(qtd, 2)} ${un} x ${brl(Number(item.preco_unit) || 0)}`;
}
