/**
 * As 27 unidades federativas do Brasil — 26 estados + o Distrito Federal.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * POR QUE UMA LISTA, E NÃO UMA MÁSCARA
 * ────────────────────────────────────────────────────────────────────────────
 * A UF é o caso em que máscara é a ferramenta errada. Uma máscara de "duas
 * letras maiúsculas" — que é o que o campo fazia até a Revisão 94, com
 * `toUpperCase().slice(0, 2)` — aceita `XX`, `ZZ` e `QQ` com o mesmo sorriso
 * com que aceita `SP`. O conjunto de valores válidos é FECHADO e tem 27
 * elementos: um `<select>` resolve máscara e validação de uma vez só, e o
 * usuário não tem como errar de digitação.
 *
 * ⚠️ Isto NÃO impõe a lista ao banco. A coluna `company_profiles.state` segue
 * `text` livre, sem CHECK, e a RPC do onboarding e um `update` direto pelo
 * PostgREST continuam aceitando qualquer coisa — a mesma pendência aberta na
 * Revisão 92 §7 para CNPJ e telefone, que só fecha com migration.
 *
 * Ordem alfabética por sigla, que é como o campo é lido e digitado.
 */
export const UFS_BRASIL = [
  "AC",
  "AL",
  "AM",
  "AP",
  "BA",
  "CE",
  "DF",
  "ES",
  "GO",
  "MA",
  "MG",
  "MS",
  "MT",
  "PA",
  "PB",
  "PE",
  "PI",
  "PR",
  "RJ",
  "RN",
  "RO",
  "RR",
  "RS",
  "SC",
  "SE",
  "SP",
  "TO",
] as const;

export type Uf = (typeof UFS_BRASIL)[number];

/** `true` só para uma das 27 siglas, em maiúsculas e sem espaços nas pontas. */
export function ehUfValida(bruto: unknown): boolean {
  const v = String(bruto ?? "")
    .trim()
    .toUpperCase();
  return (UFS_BRASIL as readonly string[]).includes(v);
}
