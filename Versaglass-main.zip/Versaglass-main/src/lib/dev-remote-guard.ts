// =====================================================================
// Sentinela de ambiente — impede que a aplicação em DESENVOLVIMENTO escreva
// no Supabase de PRODUÇÃO por acidente.
//
// POR QUE ELA EXISTE (Defeito 2, Revisões 21 e 23)
//   Um servidor de desenvolvimento ÓRFÃO de uma sessão anterior continuou vivo
//   na porta que o navegador tinha aberta, servindo a aplicação com o ambiente
//   que ELE leu ao iniciar — apontado para o projeto remoto. Três tentativas de
//   cadastro foram parar em produção; só não gravaram porque um limite de envio
//   de e-mail respondeu 429 antes. O `strictPort` do `vite.config.ts` fecha
//   aquele caminho específico; esta sentinela fecha a CLASSE do problema:
//   qualquer que seja a causa (porta, `.env.local` esquecido, processo velho),
//   o que importa é a condição "estou em dev falando com produção".
//
// TRÊS CAMADAS, NESTA ORDEM
//   1. `console.error` alto na primeira vez que o cliente é usado;
//   2. faixa fixa vermelha no topo da página, impossível de ignorar;
//   3. BLOQUEIO das escritas — o erro é lançado ANTES de a requisição sair.
//      Leitura (`select`) continua funcionando, para a navegação não travar e a
//      pessoa conseguir ler a faixa e entender o que houve.
//
// ESCAPE DELIBERADO
//   `VITE_PERMITIR_SUPABASE_REMOTO=1` desliga as três camadas. É o caso
//   legítimo de apontar para o remoto de propósito, como nas Revisões 17-19.
//
// PRODUÇÃO
//   Tudo depende de `import.meta.env.DEV`, que o Vite substitui por `false` no
//   build — as funções viram no-op e o corpo é eliminado. Confirmado por
//   varredura do bundle (ver Revisão 24).
// =====================================================================

type AmbienteVite = {
  DEV?: boolean;
  VITE_SUPABASE_URL?: string;
  VITE_PERMITIR_SUPABASE_REMOTO?: string;
};

const env = import.meta.env as unknown as AmbienteVite;

/**
 * `local` · `remoto` · `indefinido`.
 *
 * "Indefinido" (URL ausente ou impossível de interpretar) **não** dispara a
 * sentinela: nesse estado o cliente Supabase nem chega a ser criado, e um alarme
 * aqui só confundiria o diagnóstico real.
 */
function classificarUrl(url: string | undefined): "local" | "remoto" | "indefinido" {
  if (!url) return "indefinido";
  let host: string;
  try {
    host = new URL(url).hostname.toLowerCase();
  } catch {
    return "indefinido";
  }
  if (!host) return "indefinido";
  const ehLocal =
    host === "localhost" ||
    host === "127.0.0.1" ||
    host === "::1" ||
    host === "[::1]" ||
    host === "0.0.0.0" ||
    host.endsWith(".localhost");
  return ehLocal ? "local" : "remoto";
}

const URL_CONFIGURADA = env.VITE_SUPABASE_URL;
const ESCAPE_ATIVO = env.VITE_PERMITIR_SUPABASE_REMOTO === "1";

/**
 * TRUE só quando: estamos em dev **e** a URL é remota **e** o escape não foi
 * declarado. Começa por `import.meta.env.DEV` de propósito — é o que permite ao
 * Vite dobrar a constante para `false` no build e eliminar o resto.
 */
export const SUPABASE_REMOTO_EM_DEV =
  !!env.DEV && classificarUrl(URL_CONFIGURADA) === "remoto" && !ESCAPE_ATIVO;

const HOST_EM_USO = (() => {
  try {
    return URL_CONFIGURADA ? new URL(URL_CONFIGURADA).host : "(desconhecido)";
  } catch {
    return "(desconhecido)";
  }
})();

const MENSAGEM_DE_BLOQUEIO =
  `Escrita bloqueada: a aplicação está em DESENVOLVIMENTO e apontada para um Supabase REMOTO (${HOST_EM_USO}). ` +
  `Aponte VITE_SUPABASE_URL para o ambiente local, ou defina VITE_PERMITIR_SUPABASE_REMOTO=1 se a intenção for mesmo escrever no remoto.`;

const ID_DA_FAIXA = "sentinela-supabase-remoto";

function montarFaixa(): void {
  if (!SUPABASE_REMOTO_EM_DEV) return;
  if (typeof document === "undefined") return; // SSR: não há DOM
  if (document.getElementById(ID_DA_FAIXA)) return;

  const aplicar = () => {
    if (!document.body || document.getElementById(ID_DA_FAIXA)) return;
    const faixa = document.createElement("div");
    faixa.id = ID_DA_FAIXA;
    faixa.setAttribute("role", "alert");
    faixa.textContent =
      `⚠️ DESENVOLVIMENTO conectado a um Supabase REMOTO (${HOST_EM_USO}) — escritas bloqueadas. ` +
      `Defina VITE_PERMITIR_SUPABASE_REMOTO=1 para permitir de propósito.`;
    // Estilo inline: a faixa não pode depender de CSS da aplicação, porque
    // precisa aparecer mesmo se o tema ou o shell falharem ao carregar.
    faixa.style.cssText = [
      "position:fixed",
      "top:0",
      "left:0",
      "right:0",
      "z-index:2147483647",
      "background:#b91c1c",
      "color:#fff",
      "font:600 13px/1.4 system-ui,sans-serif",
      "padding:10px 16px",
      "text-align:center",
      "box-shadow:0 2px 8px rgba(0,0,0,.4)",
    ].join(";");
    document.body.prepend(faixa);
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", aplicar, { once: true });
  } else {
    aplicar();
  }
}

let jaAvisou = false;

function avisarUmaVez(): void {
  if (!SUPABASE_REMOTO_EM_DEV || jaAvisou) return;
  jaAvisou = true;
  console.error(
    "\n" +
      "==================================================================\n" +
      " ⚠️  DESENVOLVIMENTO CONECTADO A UM SUPABASE REMOTO\n" +
      `     host: ${HOST_EM_USO}\n` +
      "     BLOQUEADOS: dados (insert/update/delete/upsert), rpc,\n" +
      "                 autenticação (cadastro, login, troca de senha) e\n" +
      "                 arquivos (upload/update/remove).\n" +
      "     LIVRES:     leitura (select), sessão (getSession) e signOut.\n" +
      "     Para permitir de propósito: VITE_PERMITIR_SUPABASE_REMOTO=1\n" +
      "==================================================================\n",
  );
  montarFaixa();
}

// ---------------------------------------------------------------------
// O QUE É ESCRITA, POR SUPERFÍCIE
//
// A regra em todas: bloqueia o que CRIA OU ALTERA estado no servidor remoto;
// libera o que só lê. Leitura precisa continuar funcionando para a navegação
// não travar e a pessoa conseguir ler a faixa que explica o que houve.
// ---------------------------------------------------------------------

/** PostgREST — `select` fica FORA da lista de propósito. */
const METODOS_DE_ESCRITA = new Set(["insert", "update", "delete", "upsert"]);

/**
 * GoTrue. Inclui `signInWithPassword` **de propósito** (Revisão 25): autenticar
 * numa conta REAL de produção a partir de um build de desenvolvimento é o mesmo
 * risco do `signUp` que originou o incidente — grava `last_sign_in_at`, gera
 * evento de auditoria e, principalmente, é a PORTA: uma vez logado, toda tela
 * seguinte fica a um clique de uma escrita.
 *
 * `signOut` fica liberado (é a saída), assim como tudo que só lê sessão:
 * `getSession`, `getUser`, `getClaims`, `onAuthStateChange`.
 */
const METODOS_AUTH_BLOQUEADOS = new Set([
  "signUp",
  "signInWithPassword",
  "signInWithOtp",
  "signInWithOAuth",
  "signInWithIdToken",
  "signInAnonymously",
  "resetPasswordForEmail",
  "updateUser",
  "verifyOtp",
  "resend",
  "reauthenticate",
  "linkIdentity",
  "unlinkIdentity",
  "exchangeCodeForSession",
  "setSession",
  "refreshSession",
]);

/** Storage, nível objeto (`storage.from(bucket).*`). */
const METODOS_STORAGE_BLOQUEADOS = new Set([
  "upload",
  "uploadToSignedUrl",
  "update",
  "remove",
  "move",
  "copy",
  "createSignedUploadUrl",
]);

/** Storage, nível bucket (`storage.*`). */
const METODOS_BUCKET_BLOQUEADOS = new Set([
  "createBucket",
  "deleteBucket",
  "updateBucket",
  "emptyBucket",
]);

/**
 * `auth.admin.*` — só alcançável com service_role, portanto só no cliente do
 * servidor. `getUserById` e `listUsers` ficam livres (leitura).
 */
const METODOS_AUTH_ADMIN_BLOQUEADOS = new Set([
  "createUser",
  "updateUserById",
  "deleteUser",
  "inviteUserByEmail",
  "generateLink",
  "signOut",
]);

function bloquear(): never {
  throw new Error(MENSAGEM_DE_BLOQUEIO);
}

// Os Proxies são MEMOIZADOS por objeto-alvo: `supabase.auth` é lido dezenas de
// vezes e precisa devolver sempre a mesma referência, senão dependências de
// efeito e identidade de assinatura (`onAuthStateChange`) quebrariam.
const cacheDeProxies = new WeakMap<object, unknown>();

function proxyBloqueando<T extends object>(
  alvo: T,
  bloqueados: Set<string>,
  aoLer?: (prop: string, valor: unknown) => unknown,
): T {
  const emCache = cacheDeProxies.get(alvo);
  if (emCache) return emCache as T;

  const proxy = new Proxy(alvo, {
    get(destino, prop, receptor) {
      if (typeof prop === "string" && bloqueados.has(prop)) return bloquear;
      const valor = Reflect.get(destino, prop, receptor);
      if (aoLer && typeof prop === "string") {
        const substituto = aoLer(prop, valor);
        if (substituto !== undefined) return substituto;
      }
      return typeof valor === "function" ? valor.bind(destino) : valor;
    },
  });

  cacheDeProxies.set(alvo, proxy);
  return proxy as T;
}

function protegerConstrutorDeConsulta<T extends object>(construtor: T): T {
  return proxyBloqueando(construtor, METODOS_DE_ESCRITA);
}

function protegerStorage<T extends object>(storage: T): T {
  return proxyBloqueando(storage, METODOS_BUCKET_BLOQUEADOS, (prop, valor) => {
    if (prop !== "from" || typeof valor !== "function") return undefined;
    return (...args: unknown[]) =>
      proxyBloqueando(
        (valor as (...a: unknown[]) => object).apply(storage, args),
        METODOS_STORAGE_BLOQUEADOS,
      );
  });
}

/**
 * Envolve o cliente Supabase. Fora da condição de risco devolve o próprio
 * cliente, sem Proxy e sem custo.
 *
 * A interceptação é feita AQUI, num lugar só — não em cada chamada — para que
 * nenhum ponto do código precise lembrar de checar nada.
 *
 * Cobre as QUATRO superfícies do cliente (desde a Revisão 25): dados
 * (`from`), procedimentos (`rpc`), autenticação (`auth`) e arquivos
 * (`storage`). A tela de login continua ABRINDO — só as chamadas que gravariam
 * no GoTrue remoto é que falham, e é ali que a faixa é lida.
 */
export function protegerEscritasEmDev<T extends object>(cliente: T): T {
  if (!SUPABASE_REMOTO_EM_DEV) return cliente;

  avisarUmaVez();

  return new Proxy(cliente, {
    get(alvo, prop, receptor) {
      const valor = Reflect.get(alvo, prop, receptor);

      if (prop === "from" && typeof valor === "function") {
        return (...args: unknown[]) =>
          protegerConstrutorDeConsulta((valor as (...a: unknown[]) => object).apply(alvo, args));
      }
      if (prop === "rpc" && typeof valor === "function") {
        return bloquear;
      }
      // `auth` e `storage` são OBJETOS, não funções — daí o Proxy memoizado em
      // vez de um wrapper por chamada.
      if (prop === "auth" && valor && typeof valor === "object") {
        return proxyBloqueando(valor as object, METODOS_AUTH_BLOQUEADOS);
      }
      if (prop === "storage" && valor && typeof valor === "object") {
        return protegerStorage(valor as object);
      }
      return typeof valor === "function" ? valor.bind(alvo) : valor;
    },
  });
}

// =====================================================================
// SENTINELA DO CLIENTE DE SERVIDOR (`client.server.ts`, service_role)
//
// POR QUE PRECISA DE TRATAMENTO PRÓPRIO
//   Aquele cliente lê `process.env.SUPABASE_URL` — variável DIFERENTE da
//   `VITE_SUPABASE_URL` que a sentinela do navegador observa. Numa sessão como a
//   da Revisão 21 os dois podiam divergir, e o caminho de log server-side
//   escreveria em produção sem passar por proteção nenhuma.
//
// POR QUE BLOQUEAR, E NÃO SÓ AVISAR (decisão da Revisão 26)
//   1. `service_role` IGNORA RLS. É a única superfície do sistema sem rede de
//      segurança no banco: um insert errado entra e pronto. Justamente onde o
//      custo de errar é maior, avisar é pouco.
//   2. Os consumidores são dois, e ambos toleram o bloqueio:
//      · `log-ingest.server.ts` — já LANÇA em falha de insert
//        (`if (error) throw ...`), e `runLogCall` (`server-log.ts:17-30`) captura
//        tudo e devolve `{success:false}` sem relançar. Lançar aqui segue o
//        MESMO caminho de uma falha de insert comum, que o P-07 tolera por
//        projeto — "falha de log não derruba a aplicação" continua valendo.
//      · `admin-bootstrap.functions.ts` — promoção de administrador. É uma
//        escrita privilegiada em produção a partir de um build de dev:
//        exatamente o que NÃO pode acontecer sem intenção declarada.
//   3. Um aviso no terminal seria mais uma linha num log que rola — o mesmo tipo
//      de sinal que passou despercebido na Revisão 21 ("Port 8080 is in use").
//
//   O aviso alto no console do servidor foi mantido ASSIM MESMO: bloquear sem
//   explicar deixaria o desenvolvedor com um erro sem causa aparente.
// =====================================================================

/** Escape lido nas duas formas: inlined pelo Vite e via `process.env`. */
function escapeDoServidorAtivo(): boolean {
  if (env.VITE_PERMITIR_SUPABASE_REMOTO === "1") return true;
  if (typeof process !== "undefined" && process.env?.VITE_PERMITIR_SUPABASE_REMOTO === "1")
    return true;
  return false;
}

let jaAvisouNoServidor = false;

/**
 * Envolve o cliente `service_role`. Fora da condição de risco devolve o próprio
 * cliente, sem Proxy.
 *
 * @param urlDoServidor o valor de `process.env.SUPABASE_URL` lido por quem chama
 *                      — a classificação é feita sobre ELE, não sobre a variável
 *                      do navegador.
 */
export function protegerAdminEmDev<T extends object>(
  cliente: T,
  urlDoServidor: string | undefined,
): T {
  if (!env.DEV) return cliente; // eliminado no build de produção
  if (escapeDoServidorAtivo()) return cliente;
  if (classificarUrl(urlDoServidor) !== "remoto") return cliente;

  let host = "(desconhecido)";
  try {
    host = urlDoServidor ? new URL(urlDoServidor).host : host;
  } catch {
    /* mantém o rótulo genérico */
  }

  const mensagem =
    `Escrita bloqueada (service_role): o SERVIDOR de desenvolvimento está apontado para um Supabase REMOTO (${host}). ` +
    `Como service_role ignora RLS, a escrita foi impedida antes de sair. Aponte SUPABASE_URL para o ambiente local, ` +
    `ou defina VITE_PERMITIR_SUPABASE_REMOTO=1 se a intenção for mesmo escrever no remoto.`;

  if (!jaAvisouNoServidor) {
    jaAvisouNoServidor = true;
    console.error(
      "\n" +
        "==================================================================\n" +
        " ⚠️  SERVIDOR DE DESENVOLVIMENTO USANDO service_role EM UM\n" +
        "     SUPABASE REMOTO — escritas BLOQUEADAS\n" +
        `     host: ${host}\n` +
        "     service_role IGNORA RLS: não há rede de segurança no banco.\n" +
        "     Afeta o caminho de log (P-07) e o bootstrap de administrador.\n" +
        "     Falha de log NÃO derruba o fluxo — runLogCall a absorve.\n" +
        "     Para permitir de propósito: VITE_PERMITIR_SUPABASE_REMOTO=1\n" +
        "==================================================================\n",
    );
  }

  const bloquearNoServidor = (): never => {
    throw new Error(mensagem);
  };

  const proxyServidor = <U extends object>(
    alvo: U,
    bloqueados: Set<string>,
    aoLer?: (p: string, v: unknown) => unknown,
  ): U =>
    new Proxy(alvo, {
      get(destino, prop, receptor) {
        if (typeof prop === "string" && bloqueados.has(prop)) return bloquearNoServidor;
        const valor = Reflect.get(destino, prop, receptor);
        if (aoLer && typeof prop === "string") {
          const substituto = aoLer(prop, valor);
          if (substituto !== undefined) return substituto;
        }
        return typeof valor === "function" ? valor.bind(destino) : valor;
      },
    });

  return new Proxy(cliente, {
    get(alvo, prop, receptor) {
      const valor = Reflect.get(alvo, prop, receptor);

      if (prop === "from" && typeof valor === "function") {
        return (...args: unknown[]) =>
          proxyServidor(
            (valor as (...a: unknown[]) => object).apply(alvo, args),
            METODOS_DE_ESCRITA,
          );
      }
      if (prop === "rpc" && typeof valor === "function") return bloquearNoServidor;
      if (prop === "auth" && valor && typeof valor === "object") {
        // `auth` do service_role expõe também o namespace `admin`.
        return proxyServidor(valor as object, METODOS_AUTH_BLOQUEADOS, (p, v) => {
          if (p !== "admin" || !v || typeof v !== "object") return undefined;
          return proxyServidor(v as object, METODOS_AUTH_ADMIN_BLOQUEADOS);
        });
      }
      if (prop === "storage" && valor && typeof valor === "object") {
        return proxyServidor(valor as object, METODOS_BUCKET_BLOQUEADOS, (p, v) => {
          if (p !== "from" || typeof v !== "function") return undefined;
          return (...args: unknown[]) =>
            proxyServidor(
              (v as (...a: unknown[]) => object).apply(valor, args),
              METODOS_STORAGE_BLOQUEADOS,
            );
        });
      }
      return typeof valor === "function" ? valor.bind(alvo) : valor;
    },
  });
}
