import { supabase } from "@/integrations/supabase/client";
import { cnpjEhValido, formatarCnpj } from "@/lib/cnpj";

// Dados empresariais do PDF do orçamento.
//
// REGRA CENTRAL: a empresa vem SEMPRE de `quote.company_id`, nunca da empresa
// ativa no momento. Abrir um orçamento antigo de outra empresa não pode carimbar
// nele o cabeçalho da empresa selecionada agora.
//
// Campos reais de `public.company_profiles` (auditados antes de qualquer
// migration): company_name (not null), cnpj, phone, email, address, city, state
// e logo_url (adicionada em 20260727020000). NÃO existem razão social/nome
// fantasia separados, nem número/complemento/bairro/CEP — nada disso é inventado
// aqui. A leitura funciona para qualquer membro ativo desde a mesma migration.

export type QuoteCompany = {
  id: string;
  company_name: string;
  cnpj: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  logo_url: string | null;
};

export type CompanyHeaderData = {
  company: QuoteCompany | null;
  /** Logo já convertido para data URL; null quando não há ou falhou o download. */
  logo: { dataUrl: string; width: number; height: number } | null;
  /** Cadastro empresarial incompleto (sem CNPJ) — registrado, não exibido ao cliente. */
  semCnpj: boolean;
};

const BUCKET = "project-images";

/**
 * Formata CNPJ (numérico ou alfanumérico) ou CPF (11 dígitos).
 *
 * ────────────────────────────────────────────────────────────────────────────
 * O QUE MUDOU NA REVISÃO 92, E POR QUÊ
 * ────────────────────────────────────────────────────────────────────────────
 * A versão anterior terminava com `return limpo === "" ? null : limpo` — ou
 * seja, **documento irreconhecível voltava CRU e ia impresso**. A Revisão 91
 * mediu a consequência: com `abc` gravado no CNPJ, o PDF do orçamento E o da
 * venda imprimiam **`Documento: abc`** no cabeçalho, e ninguém era avisado.
 * A degradação era elegante (nunca saía "undefined") e era exatamente isso que
 * escondia o erro até a folha chegar ao cliente.
 *
 * Agora: **o que não é documento reconhecível devolve `null` e vai para o
 * console**. Todos os chamadores já tratam `null` omitindo a linha
 * (`if (cnpj) {…}`, `joinParts`), então o efeito é **a linha sumir do PDF em
 * vez de sair errada** — e o `console.warn` diz o que corrigir.
 *
 * ⚠️ **Alcance declarado:** isto atinge também o documento do CLIENTE
 * (`customer.documento`), que continua sem validação no cadastro. Um cliente
 * com documento fora de CPF/CNPJ — uma Inscrição Estadual digitada ali, por
 * exemplo — **deixa de aparecer no PDF**. É a troca deliberada: melhor a
 * ausência de um dado do que um dado errado com cara de documento oficial.
 *
 * 📌 **CPF continua sendo só "11 dígitos", sem conferir dígito verificador.**
 * Apertar isso é outra decisão, de outro campo, e não foi pedida.
 */
export function formatDoc(raw: string | null | undefined): string | null {
  const bruto = (raw ?? "").trim();
  if (bruto === "") return null;

  // CNPJ — os dois formatos. `cnpjEhValido` confere estrutura E dígito
  // verificador pelo algoritmo oficial da Receita (ver `src/lib/cnpj.ts`).
  if (cnpjEhValido(bruto)) return formatarCnpj(bruto);

  const d = bruto.replace(/\D/g, "");
  if (d.length === 11) return d.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, "$1.$2.$3-$4");

  console.warn(
    `Documento não reconhecido como CNPJ ou CPF e por isso OMITIDO do PDF: "${bruto}". Corrija o cadastro.`,
  );
  return null;
}

/**
 * Rótulo correto do documento.
 *
 * Passou a exigir CNPJ **válido** para dizer "CNPJ" (antes bastava ter 14
 * dígitos, então um número inventado ganhava o rótulo oficial). O fallback
 * "Documento" continua existindo, mas na prática deixou de ser alcançado pelo
 * PDF: `formatDoc` devolve `null` nesse caso e a linha inteira não é impressa.
 */
export function docLabel(raw: string | null | undefined): string {
  if (cnpjEhValido(raw)) return "CNPJ";
  if ((raw ?? "").replace(/\D/g, "").length === 11) return "CPF";
  return "Documento";
}

/** Formata telefone brasileiro (10 ou 11 dígitos). Fora disso, valor original. */
export function formatPhone(raw: string | null | undefined): string | null {
  const d = (raw ?? "").replace(/\D/g, "");
  if (d.length === 11) return d.replace(/^(\d{2})(\d{5})(\d{4})$/, "($1) $2-$3");
  if (d.length === 10) return d.replace(/^(\d{2})(\d{4})(\d{4})$/, "($1) $2-$3");
  const limpo = (raw ?? "").trim();
  return limpo === "" ? null : limpo;
}

/**
 * Monta o endereço SÓ com as partes que existem. Sem vírgula solta, sem "null",
 * sem "undefined" — se nada existir, devolve null e o bloco simplesmente não é
 * impresso.
 */
export function composeAddress(
  address: string | null | undefined,
  city: string | null | undefined,
  state: string | null | undefined,
): string | null {
  const logradouro = (address ?? "").trim();
  const municipio = (city ?? "").trim();
  const uf = (state ?? "").trim();
  const local = municipio && uf ? `${municipio}/${uf}` : municipio || uf;
  const partes = [logradouro, local].filter(Boolean);
  return partes.length ? partes.join(" - ") : null;
}

/** Junta pedaços não vazios com um separador, ignorando null/vazio. */
export function joinParts(partes: Array<string | null | undefined>, sep = " · "): string | null {
  const limpas = partes.map((p) => (p ?? "").trim()).filter(Boolean);
  return limpas.length ? limpas.join(sep) : null;
}

async function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Falha ao ler a imagem"));
    reader.readAsDataURL(blob);
  });
}

async function measure(dataUrl: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve({ width: img.naturalWidth || 1, height: img.naturalHeight || 1 });
    img.onerror = () => reject(new Error("Imagem inválida"));
    img.src = dataUrl;
  });
}

/**
 * Carrega a empresa do orçamento e, se houver, o logotipo.
 *
 * O logo vive em bucket PRIVADO: é baixado por URL assinada temporária e
 * convertido para data URL só para entrar no PDF — a URL assinada nunca é
 * persistida. Qualquer falha (sem permissão, arquivo removido, imagem inválida)
 * degrada para `logo: null` e o documento continua sendo gerado.
 */
export async function loadQuoteCompany(
  companyId: string | null | undefined,
): Promise<CompanyHeaderData> {
  if (!companyId) return { company: null, logo: null, semCnpj: true };

  const { data, error } = await supabase
    .from("company_profiles")
    .select("id, company_name, cnpj, phone, email, address, city, state, logo_url")
    .eq("id", companyId)
    .maybeSingle();

  if (error || !data) {
    if (error) console.error("Não foi possível carregar os dados da empresa do orçamento", error);
    return { company: null, logo: null, semCnpj: true };
  }

  const company = data as unknown as QuoteCompany;
  const semCnpj = !(company.cnpj ?? "").trim();
  if (semCnpj) {
    console.warn("Cadastro empresarial incompleto: empresa sem CNPJ. O PDF sai apenas com o nome.");
  }

  let logo: CompanyHeaderData["logo"] = null;
  const path = (company.logo_url ?? "").trim();
  if (path && !path.startsWith("http")) {
    try {
      const { data: assinada, error: erroUrl } = await supabase.storage
        .from(BUCKET)
        .createSignedUrl(path, 60);
      if (erroUrl || !assinada?.signedUrl) throw erroUrl ?? new Error("sem URL assinada");
      const resp = await fetch(assinada.signedUrl);
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const dataUrl = await blobToDataUrl(await resp.blob());
      const { width, height } = await measure(dataUrl);
      logo = { dataUrl, width, height };
    } catch (err) {
      // Logo é opcional: o PDF continua sem ele.
      console.error("Falha ao carregar o logotipo da empresa; o PDF será gerado sem logo.", err);
      logo = null;
    }
  }

  return { company, logo, semCnpj };
}
