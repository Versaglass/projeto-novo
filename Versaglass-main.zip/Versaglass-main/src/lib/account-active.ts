import { redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { getAuthzSnapshot, invalidateAuthzSnapshot } from "@/lib/authz-snapshot";
import { invalidateAuthSessionSnapshot } from "@/lib/auth-session-snapshot";

/**
 * Bloqueio lógico de conta (`profiles.ativo = false`).
 *
 * Sessão Supabase Auth válida NÃO basta: o VersaGlass consulta `profiles.ativo`
 * e encerra a sessão local quando a conta está desativada. Enforcement é da
 * aplicação (signOut + redirect); RLS do banco não filtra por este campo.
 */

export const ACCOUNT_INACTIVE_TOAST =
  "Sua conta está desativada. Entre em contato com o administrador.";

export const ACCOUNT_INACTIVE_TOAST_KEY = "vmm_account_inactive_toast";

export type AccountActiveStatus = "active" | "inactive" | "unknown";

export function queueAccountInactiveToast() {
  if (typeof sessionStorage === "undefined") return;
  sessionStorage.setItem(ACCOUNT_INACTIVE_TOAST_KEY, ACCOUNT_INACTIVE_TOAST);
}

export function consumeAccountInactiveToast(): string | null {
  if (typeof sessionStorage === "undefined") return null;
  const msg = sessionStorage.getItem(ACCOUNT_INACTIVE_TOAST_KEY);
  if (msg) sessionStorage.removeItem(ACCOUNT_INACTIVE_TOAST_KEY);
  return msg;
}

/** Evita dois toasts quando submit + onAuthStateChange detectam inativo juntos. */
let lastInactiveToastAt = 0;

export function shouldShowAccountInactiveToast(): boolean {
  const now = Date.now();
  if (now - lastInactiveToastAt < 4000) return false;
  lastInactiveToastAt = now;
  return true;
}

/**
 * Consulta `profiles.ativo` via snapshot compartilhado (paralelo + TTL).
 * - `inactive` só quando o banco devolve explicitamente `false`
 * - erro de rede / consulta → `unknown` (não fingir desativação)
 * - profile ausente → `active` (não bloquear por race de provisionamento;
 *   coluna é NOT NULL DEFAULT true quando a linha existe)
 */
export async function fetchAccountActiveStatus(userId: string): Promise<AccountActiveStatus> {
  const snap = await getAuthzSnapshot(userId);
  return snap.ativo;
}

/**
 * Encerra a sessão local e prepara toast. Idempotente se já não houver sessão.
 */
export async function signOutInactiveAccount() {
  invalidateAuthzSnapshot();
  invalidateAuthSessionSnapshot();
  queueAccountInactiveToast();
  await supabase.auth.signOut({ scope: "local" });
}

/**
 * `beforeLoad` de `/_authenticated` — revalida via snapshot (TTL 30s).
 * Desativação remota é detectada na próxima navegação após expirar o cache.
 */
export async function enforceAccountActive(userId: string) {
  const status = await fetchAccountActiveStatus(userId);
  if (status !== "inactive") return;
  await signOutInactiveAccount();
  throw redirect({ to: "/auth", replace: true });
}
