import { textoParaNumero, validaCamposNumericos } from "@/lib/numero-campo";
import type { QuoteItemInput } from "@/hooks/use-quotes";
import type { InventoryUnidade } from "@/hooks/use-inventory";

/** Linha do carrinho da Lista de Projeto — preço por m² com medidas em mm na tela. */
export type LinhaOrcamentoObra = {
  id: string;
  nome: string;
  categoria: string;
  unidade: InventoryUnidade;
  /** Milímetros na tela — convertidos para metros na RPC. */
  largura: string;
  altura: string;
  qtd: string;
  valorUnit: string;
  /** Snapshot paramétrico do modelo (quando veio da Biblioteca). */
  project_data?: unknown | null;
};

/** @deprecated Use `LinhaOrcamentoObra` — alias mantido na transição Rev. 188→189. */
export type LinhaOrcamentoEstoque = LinhaOrcamentoObra;

const CAMPOS_NUMERICOS = [
  { chave: "largura" as const, rotulo: "Largura" },
  { chave: "altura" as const, rotulo: "Altura" },
  { chave: "qtd" as const, rotulo: "Qtd" },
  { chave: "valorUnit" as const, rotulo: "Valor" },
];

function entradaInvalida(v: string) {
  return v.trim() !== "" && Number.isNaN(textoParaNumero(v));
}

/** Prévia da linha — espelha `save_quote_with_items` (m² × preço ou qtd × preço). */
export function calcLinhaOrcamentoObra(linha: LinhaOrcamentoObra) {
  const invalidos = CAMPOS_NUMERICOS.filter((c) => entradaInvalida(linha[c.chave])).map(
    (c) => c.rotulo,
  );

  const qtd = textoParaNumero(linha.qtd) || 0;
  const valorUnit = textoParaNumero(linha.valorUnit) || 0;
  const larguraMm = textoParaNumero(linha.largura) || 0;
  const alturaMm = textoParaNumero(linha.altura) || 0;

  const larguraM = larguraMm / 1000;
  const alturaM = alturaMm / 1000;
  const area = linha.unidade === "m2" ? larguraM * alturaM * qtd : 0;

  const base = linha.unidade === "m2" ? larguraM * alturaM * qtd : qtd;
  const subtotal = invalidos.length ? 0 : Math.max(0, base * valorUnit);

  const faltaMedida = linha.unidade === "m2" && (larguraMm <= 0 || alturaMm <= 0);

  return { qtd, valorUnit, larguraM, alturaM, area, subtotal, invalidos, faltaMedida };
}

/** @deprecated Use `calcLinhaOrcamentoObra`. */
export const calcLinhaOrcamentoEstoque = calcLinhaOrcamentoObra;

export function linhaOrcamentoObraVazia(
  partial: Partial<LinhaOrcamentoObra> = {},
): LinhaOrcamentoObra {
  return {
    id: crypto.randomUUID?.() ?? Math.random().toString(36).slice(2),
    nome: partial.nome ?? "",
    categoria: partial.categoria ?? "Geral",
    unidade: partial.unidade ?? "m2",
    largura: partial.largura ?? "",
    altura: partial.altura ?? "",
    qtd: partial.qtd ?? "1",
    valorUnit: partial.valorUnit ?? "",
    project_data: partial.project_data ?? null,
  };
}

/** @deprecated Use `linhaOrcamentoObraVazia`. */
export const linhaOrcamentoEstoqueVazia = linhaOrcamentoObraVazia;

export function montarItensOrcamento(
  linhas: LinhaOrcamentoObra[],
): { ok: true; itens: QuoteItemInput[] } | { ok: false; erro: string } {
  if (linhas.length === 0) {
    return { ok: false, erro: "Adicione ao menos um item ao orçamento." };
  }

  const itens: QuoteItemInput[] = [];

  for (let i = 0; i < linhas.length; i++) {
    const linha = linhas[i];
    const posicao = `Item ${i + 1}`;
    const nome = linha.nome.trim();
    if (!nome) return { ok: false, erro: `${posicao}: informe a descrição do produto.` };

    const numeros = validaCamposNumericos([
      { chave: "largura", texto: linha.largura, regra: { label: "a largura", min: 0 } },
      { chave: "altura", texto: linha.altura, regra: { label: "a altura", min: 0 } },
      {
        chave: "qtd",
        texto: linha.qtd,
        regra: { label: "a quantidade", min: 0, obrigatorio: true },
      },
      { chave: "valorUnit", texto: linha.valorUnit, regra: { label: "o valor", min: 0 } },
    ]);
    if (!numeros.ok) return { ok: false, erro: `${posicao} (${nome}): ${numeros.erro}` };

    const { largura, altura, qtd, valorUnit } = numeros.valores;

    if (qtd <= 0) {
      return { ok: false, erro: `${posicao} (${nome}): a quantidade deve ser maior que zero.` };
    }

    if (linha.unidade === "m2" && (largura <= 0 || altura <= 0)) {
      return {
        ok: false,
        erro: `${posicao} (${nome}): item em m² precisa de largura e altura maiores que zero.`,
      };
    }

    itens.push({
      descricao: nome,
      largura: largura / 1000,
      altura: altura / 1000,
      quantidade: Math.round(qtd),
      preco_unit: valorUnit,
      ...(linha.project_data != null ? { project_data: linha.project_data } : {}),
      originado_de_projeto: linha.project_data != null,
    });
  }

  return { ok: true, itens };
}
