// =====================================================================
// FRONTEIRA DE SEGURANÇA — MÓDULO SERVER-ONLY
//
// Este arquivo importa `supabaseAdmin`, que carrega SUPABASE_SERVICE_ROLE_KEY
// de `process.env`. Ele NUNCA pode ser importado por código que chega ao
// navegador: é carregado apenas por `await import("@/lib/log-ingest.server")`
// dentro de handlers de `createServerFn`, que o bundler remove do bundle
// público. Não exporte nada daqui para arquivos importáveis pelo cliente.
//
// Motivo de existir: as quatro tabelas de log (auth_events, server_logs,
// security_events, audit_logs) não têm policy de INSERT para anon nem para
// authenticated — por decisão de projeto, só `service_role` grava. A RLS não
// foi enfraquecida; a escrita passou a acontecer aqui. Ver P-07.
// =====================================================================
import { getRequest } from "@tanstack/react-start/server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

// ---------------------------------------------------------------------
// Limites de sanitização
// ---------------------------------------------------------------------
const MAX_STRING = 500;
const MAX_MESSAGE = 2_000;
const MAX_SHORT = 160;
const MAX_METADATA_KEYS = 30;
const MAX_METADATA_DEPTH = 2;
const MAX_ARRAY_ITEMS = 20;
const MAX_METADATA_BYTES = 8_000;

/** Chaves cujo VALOR nunca é persistido, em qualquer profundidade. */
const SENSITIVE_KEY =
  /(pass(word)?|senha|secret|token|authorization|bearer|cookie|credential|api[-_]?key|access[-_]?key|refresh|jwt|session|private)/i;

const REMOVED = "[removido: campo sensível]";

export function clamp(value: string | null | undefined, max = MAX_STRING): string | null {
  if (value == null) return null;
  const s = String(value).trim();
  if (!s) return null;
  return s.length > max ? `${s.slice(0, max)}…[truncado]` : s;
}

/**
 * Remove segredos, limita profundidade, largura e tamanho de metadata.
 * Sempre devolve um objeto simples — nunca `undefined`, porque as colunas
 * `metadata` de server_logs, audit_logs e security_events são NOT NULL.
 */
export function sanitizeMetadata(input: unknown): Record<string, unknown> {
  const walk = (value: unknown, depth: number): unknown => {
    if (value === null || value === undefined) return null;
    if (typeof value === "number") return Number.isFinite(value) ? value : null;
    if (typeof value === "boolean") return value;
    if (typeof value === "string") return clamp(value);
    if (depth >= MAX_METADATA_DEPTH) return "[truncado: profundidade]";
    if (Array.isArray(value)) {
      const items = value.slice(0, MAX_ARRAY_ITEMS).map((v) => walk(v, depth + 1));
      if (value.length > MAX_ARRAY_ITEMS)
        items.push(`[+${value.length - MAX_ARRAY_ITEMS} itens omitidos]`);
      return items;
    }
    if (typeof value === "object") {
      const out: Record<string, unknown> = {};
      let n = 0;
      for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
        if (n >= MAX_METADATA_KEYS) {
          out["[truncado]"] = "limite de chaves atingido";
          break;
        }
        out[k.slice(0, 64)] = SENSITIVE_KEY.test(k) ? REMOVED : walk(v, depth + 1);
        n++;
      }
      return out;
    }
    // function, symbol, bigint — descartados
    return null;
  };

  const walked = walk(input, 0);
  const obj =
    walked && typeof walked === "object" && !Array.isArray(walked)
      ? (walked as Record<string, unknown>)
      : { valor: walked };

  // Rede final de proteção por tamanho total.
  if (JSON.stringify(obj).length > MAX_METADATA_BYTES) {
    return { truncado: true, motivo: "metadata excedeu o limite de tamanho" };
  }
  return obj;
}

/**
 * IP e user-agent são SEMPRE derivados do request. O cliente não os envia e,
 * se enviar, o valor é ignorado — seria trivial forjar.
 */
export function requestContext(): { ip: string | null; userAgent: string | null } {
  try {
    const headers = getRequest()?.headers;
    if (!headers) return { ip: null, userAgent: null };
    const forwarded = headers.get("x-forwarded-for");
    const ip = forwarded ? forwarded.split(",")[0] : headers.get("x-real-ip");
    return { ip: clamp(ip, 64), userAgent: clamp(headers.get("user-agent"), MAX_SHORT) };
  } catch {
    return { ip: null, userAgent: null };
  }
}

// ---------------------------------------------------------------------
// Escritas. A tabela de destino é escolhida AQUI, nunca pelo cliente.
// Cada função devolve void e lança em falha — quem chama decide o que fazer.
// ---------------------------------------------------------------------

export async function writeAuthEvent(row: {
  kind: "signup" | "login_success" | "login_error" | "payment" | "subscription_created";
  email?: string | null;
  userId?: string | null;
  metadata?: unknown;
}): Promise<void> {
  const { ip, userAgent } = requestContext();
  const { error } = await supabaseAdmin.from("auth_events").insert({
    kind: row.kind,
    email: clamp(row.email, 255),
    user_id: row.userId ?? null,
    ip,
    user_agent: userAgent,
    metadata: sanitizeMetadata(row.metadata) as never,
  });
  if (error) throw new Error(`auth_events: ${error.message}`);
}

export async function writeServerLog(row: {
  action: string;
  level: "info" | "warn" | "error";
  status?: number | null;
  durationMs?: number | null;
  message?: string | null;
  userId?: string | null;
  userEmail?: string | null;
  metadata?: unknown;
}): Promise<void> {
  const { error } = await supabaseAdmin.from("server_logs").insert({
    action: clamp(row.action, MAX_SHORT) ?? "desconhecida",
    level: row.level,
    status: Number.isInteger(row.status) ? row.status : null,
    duration_ms: Number.isInteger(row.durationMs) ? row.durationMs : null,
    message: clamp(row.message, MAX_MESSAGE),
    user_id: row.userId ?? null,
    user_email: clamp(row.userEmail, 255),
    metadata: sanitizeMetadata(row.metadata) as never,
  });
  if (error) throw new Error(`server_logs: ${error.message}`);
}

export async function writeSecurityEvent(row: {
  flow: string;
  action: string;
  success: boolean;
  email?: string | null;
  phone?: string | null;
  userId?: string | null;
  metadata?: unknown;
}): Promise<void> {
  const { ip, userAgent } = requestContext();
  const { error } = await supabaseAdmin.from("security_events").insert({
    flow: clamp(row.flow, 64) ?? "desconhecido",
    action: clamp(row.action, MAX_SHORT) ?? "desconhecida",
    success: row.success,
    email: clamp(row.email, 255),
    phone: clamp(row.phone, 32),
    user_id: row.userId ?? null,
    // company_id NÃO é aceito do cliente: seria prova de autorização forjável.
    company_id: null,
    ip_address: ip,
    user_agent: userAgent,
    metadata: sanitizeMetadata(row.metadata) as never,
  });
  if (error) throw new Error(`security_events: ${error.message}`);
}

export async function writeAuditLog(row: {
  actorId: string;
  actorEmail?: string | null;
  action: string;
  entity?: string | null;
  entityId?: string | null;
  metadata?: unknown;
}): Promise<void> {
  const { ip } = requestContext();
  const { error } = await supabaseAdmin.from("audit_logs").insert({
    actor_id: row.actorId,
    actor_email: clamp(row.actorEmail, 255),
    action: clamp(row.action, MAX_SHORT) ?? "desconhecida",
    entity: clamp(row.entity, 64),
    entity_id: clamp(row.entityId, 64),
    ip,
    metadata: sanitizeMetadata(row.metadata) as never,
  });
  if (error) throw new Error(`audit_logs: ${error.message}`);
}
