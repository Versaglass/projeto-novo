import {
  getPlanFromStorage,
  hasModuleAccess,
  type ModuleKey,
  type Segment,
} from "@/lib/module-access";
import { canAccessModel, type PlanSlug } from "@/data/projectLibrary";

export type UserPlan = Segment | PlanSlug | "free" | "premium" | "pro";

export function getUserPlan(): UserPlan {
  if (typeof window === "undefined") return "vidracaria";
  const subscription = window.localStorage.getItem("vmm_subscription_plan") as PlanSlug | null;
  if (subscription === "pro" || subscription === "premium" || subscription === "free")
    return subscription;
  return getPlanFromStorage();
}

export function canAccessModule(moduleKey: ModuleKey, options?: { plan?: Segment | string }) {
  // Sem bypass de plataforma: plano da empresa vale para todos no lado operacional.
  return hasModuleAccess(options?.plan || getPlanFromStorage(), moduleKey);
}

export function canAccessProjectCategory(
  categorySlug: string,
  modelIndex = 0,
  freePreview = false,
  plan?: PlanSlug,
) {
  const resolvedPlan =
    plan ||
    ((typeof window !== "undefined"
      ? window.localStorage.getItem("vmm_subscription_plan")
      : null) as PlanSlug | null) ||
    "pro";
  return canAccessModel(resolvedPlan, categorySlug, modelIndex, { freePreview });
}

export function getModuleLockReason(moduleLabel: string, planName?: string) {
  return `${moduleLabel} disponível no ${planName || "plano correspondente"}. Faça upgrade para liberar.`;
}
