export type Segment = "vidracaria" | "marcenaria" | "marmoraria" | "serralheria";
export type ElementKind =
  | "glass"
  | "profile"
  | "hardware"
  | "wood"
  | "stone"
  | "steel"
  | "cutout"
  | "dimension";

export type EngineeringElement = {
  id: string;
  kind: ElementKind;
  label: string;
  x: number;
  y: number;
  width: number;
  height: number;
  depth?: number;
  thickness: number;
  material: string;
  unitCost: number;
  quantity: number;
  locked?: boolean;
  color?: string;
};

export type EngineeringProject = {
  id: string;
  segment: Segment;
  title: string;
  width: number;
  height: number;
  depth: number;
  marginPercent: number;
  laborCost: number;
  elements: EngineeringElement[];
};

const glass: EngineeringProject = {
  id: "vidro-porta-4-folhas",
  segment: "vidracaria",
  title: "Porta de vidro 4 folhas",
  width: 4400,
  height: 2200,
  depth: 10,
  marginPercent: 35,
  laborCost: 650,
  elements: [
    {
      id: "v1",
      kind: "glass",
      label: "Vidro 1",
      x: 0,
      y: 0,
      width: 1100,
      height: 2200,
      thickness: 10,
      material: "Vidro temperado incolor 10mm",
      unitCost: 210,
      quantity: 1,
      color: "#cdebe8",
    },
    {
      id: "v2",
      kind: "glass",
      label: "Vidro 2",
      x: 1100,
      y: 0,
      width: 1100,
      height: 2200,
      thickness: 10,
      material: "Vidro temperado incolor 10mm",
      unitCost: 210,
      quantity: 1,
      color: "#cdebe8",
    },
    {
      id: "v3",
      kind: "glass",
      label: "Vidro 3",
      x: 2200,
      y: 0,
      width: 1100,
      height: 2200,
      thickness: 10,
      material: "Vidro temperado incolor 10mm",
      unitCost: 210,
      quantity: 1,
      color: "#cdebe8",
    },
    {
      id: "v4",
      kind: "glass",
      label: "Vidro 4",
      x: 3300,
      y: 0,
      width: 1100,
      height: 2200,
      thickness: 10,
      material: "Vidro temperado incolor 10mm",
      unitCost: 210,
      quantity: 1,
      color: "#cdebe8",
    },
    {
      id: "p1",
      kind: "profile",
      label: "Perfil U superior",
      x: 0,
      y: -55,
      width: 4400,
      height: 35,
      thickness: 1.5,
      material: "Alumínio perfil U",
      unitCost: 38,
      quantity: 4.4,
      color: "#151923",
    },
    {
      id: "p2",
      kind: "profile",
      label: "Perfil U inferior",
      x: 0,
      y: 2220,
      width: 4400,
      height: 35,
      thickness: 1.5,
      material: "Alumínio perfil U",
      unitCost: 38,
      quantity: 4.4,
      color: "#151923",
    },
    {
      id: "h1",
      kind: "hardware",
      label: "Puxador 1038A",
      x: 2100,
      y: 980,
      width: 35,
      height: 290,
      thickness: 2,
      material: "Puxador inox",
      unitCost: 85,
      quantity: 2,
      color: "#1b1f28",
    },
    {
      id: "h2",
      kind: "hardware",
      label: "Dobradiça 1570P",
      x: 2150,
      y: 760,
      width: 45,
      height: 90,
      thickness: 2,
      material: "Dobradiça vidro",
      unitCost: 120,
      quantity: 2,
      color: "#1b1f28",
    },
  ],
};

const wood: EngineeringProject = {
  id: "cozinha-planejada",
  segment: "marcenaria",
  title: "Cozinha planejada MDF",
  width: 3000,
  height: 2200,
  depth: 550,
  marginPercent: 40,
  laborCost: 900,
  elements: [
    {
      id: "mdf1",
      kind: "wood",
      label: "Módulo aéreo esquerdo",
      x: 0,
      y: 0,
      width: 900,
      height: 700,
      depth: 350,
      thickness: 18,
      material: "MDF amadeirado 18mm",
      unitCost: 145,
      quantity: 1,
      color: "#9b673c",
    },
    {
      id: "mdf2",
      kind: "wood",
      label: "Módulo aéreo central",
      x: 900,
      y: 0,
      width: 900,
      height: 700,
      depth: 350,
      thickness: 18,
      material: "MDF amadeirado 18mm",
      unitCost: 145,
      quantity: 1,
      color: "#8a5a34",
    },
    {
      id: "mdf3",
      kind: "wood",
      label: "Módulo aéreo direito",
      x: 1800,
      y: 0,
      width: 900,
      height: 700,
      depth: 350,
      thickness: 18,
      material: "MDF amadeirado 18mm",
      unitCost: 145,
      quantity: 1,
      color: "#9b673c",
    },
    {
      id: "mdf4",
      kind: "wood",
      label: "Balcão inferior",
      x: 0,
      y: 1200,
      width: 3000,
      height: 820,
      depth: 550,
      thickness: 18,
      material: "MDF amadeirado 18mm",
      unitCost: 145,
      quantity: 1,
      color: "#724423",
    },
    {
      id: "g1",
      kind: "hardware",
      label: "Gavetas",
      x: 1120,
      y: 1320,
      width: 760,
      height: 520,
      thickness: 2,
      material: "Corrediças e puxadores",
      unitCost: 240,
      quantity: 3,
      color: "#2b1a12",
    },
  ],
};

const stone: EngineeringProject = {
  id: "bancada-cozinha",
  segment: "marmoraria",
  title: "Bancada de cozinha com cuba e cooktop",
  width: 3200,
  height: 620,
  depth: 620,
  marginPercent: 45,
  laborCost: 750,
  elements: [
    {
      id: "pedra1",
      kind: "stone",
      label: "Bancada principal",
      x: 0,
      y: 0,
      width: 3200,
      height: 620,
      depth: 30,
      thickness: 30,
      material: "Quartzo branco 30mm",
      unitCost: 680,
      quantity: 1,
      color: "#e5e2dc",
    },
    {
      id: "cuba",
      kind: "cutout",
      label: "Recorte cuba",
      x: 520,
      y: 140,
      width: 620,
      height: 360,
      thickness: 30,
      material: "Recorte de cuba",
      unitCost: 110,
      quantity: 1,
      color: "#2c3742",
    },
    {
      id: "cooktop",
      kind: "cutout",
      label: "Recorte cooktop",
      x: 2050,
      y: 155,
      width: 700,
      height: 360,
      thickness: 30,
      material: "Recorte cooktop",
      unitCost: 130,
      quantity: 1,
      color: "#171717",
    },
    {
      id: "frontao",
      kind: "stone",
      label: "Frontão",
      x: 0,
      y: -180,
      width: 3200,
      height: 150,
      thickness: 20,
      material: "Frontão quartzo",
      unitCost: 120,
      quantity: 1,
      color: "#d8d4cb",
    },
  ],
};

const steel: EngineeringProject = {
  id: "galpao-metalico",
  segment: "serralheria",
  title: "Galpão metálico simples",
  width: 6000,
  height: 3200,
  depth: 4500,
  marginPercent: 32,
  laborCost: 1800,
  elements: [
    {
      id: "col1",
      kind: "steel",
      label: "Pilar esquerdo",
      x: 0,
      y: 0,
      width: 120,
      height: 3200,
      depth: 120,
      thickness: 2,
      material: "Metalon 100x100",
      unitCost: 95,
      quantity: 3.2,
      color: "#40464f",
    },
    {
      id: "col2",
      kind: "steel",
      label: "Pilar direito",
      x: 5880,
      y: 0,
      width: 120,
      height: 3200,
      depth: 120,
      thickness: 2,
      material: "Metalon 100x100",
      unitCost: 95,
      quantity: 3.2,
      color: "#40464f",
    },
    {
      id: "viga",
      kind: "steel",
      label: "Viga superior",
      x: 0,
      y: 0,
      width: 6000,
      height: 120,
      depth: 120,
      thickness: 2,
      material: "Metalon 100x100",
      unitCost: 95,
      quantity: 6,
      color: "#565e69",
    },
    {
      id: "tesoura1",
      kind: "steel",
      label: "Tesoura metálica",
      x: 800,
      y: 300,
      width: 4400,
      height: 680,
      thickness: 2,
      material: "Treliça metálica",
      unitCost: 78,
      quantity: 8.8,
      color: "#6a7280",
    },
    {
      id: "telha",
      kind: "steel",
      label: "Cobertura metálica",
      x: 350,
      y: 860,
      width: 5300,
      height: 420,
      thickness: 0.5,
      material: "Telha metálica",
      unitCost: 58,
      quantity: 23.8,
      color: "#7d8795",
    },
  ],
};

export const START_PROJECTS: Record<Segment, EngineeringProject> = {
  vidracaria: glass,
  marcenaria: wood,
  marmoraria: stone,
  serralheria: steel,
};

export function cloneProject(project: EngineeringProject): EngineeringProject {
  return JSON.parse(JSON.stringify(project));
}

export function areaM2(element: EngineeringElement) {
  return Math.max(0, (element.width * element.height) / 1_000_000) * element.quantity;
}

export function linearM(element: EngineeringElement) {
  return Math.max(0, element.width / 1000) * element.quantity;
}

export function elementCost(element: EngineeringElement) {
  if (["profile", "steel"].includes(element.kind)) return linearM(element) * element.unitCost;
  if (element.kind === "hardware" || element.kind === "cutout")
    return element.quantity * element.unitCost;
  return areaM2(element) * element.unitCost;
}

export function calculateProject(project: EngineeringProject) {
  const materialCost = project.elements.reduce((sum, el) => sum + elementCost(el), 0);
  const subtotal = materialCost + project.laborCost;
  const margin = subtotal * (project.marginPercent / 100);
  const total = subtotal + margin;
  const totalArea = project.elements
    .filter((e) => ["glass", "wood", "stone"].includes(e.kind))
    .reduce((s, e) => s + areaM2(e), 0);
  const totalLinear = project.elements
    .filter((e) => ["profile", "steel"].includes(e.kind))
    .reduce((s, e) => s + linearM(e), 0);
  return { materialCost, subtotal, margin, total, totalArea, totalLinear };
}

export function generateCutPieces(project: EngineeringProject) {
  return project.elements
    .filter((el) => ["glass", "wood", "stone", "steel", "profile"].includes(el.kind))
    .map((el) => ({
      id: el.id,
      label: el.label,
      material: el.material,
      width: el.width,
      height: el.height,
      quantity: el.quantity,
      sobraLargura: Math.max(0, Math.round((project.width - el.width) / 2)),
      sobraAltura: Math.max(0, Math.round((project.height - el.height) / 2)),
      cost: elementCost(el),
    }));
}
