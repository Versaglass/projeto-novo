/**
 * Máscaras de digitação — CNPJ e telefone brasileiro.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * POR QUE ISTO EXISTE, E O QUE MUDA EM RELAÇÃO À REVISÃO 92
 * ────────────────────────────────────────────────────────────────────────────
 * A Revisão 92 decidiu NÃO mascarar enquanto se digita, seguindo a regra que a
 * Revisão 32 fixou para campo numérico (estado em texto, conversão só no
 * envio). O motivo declarado lá era que validar durante a digitação acusaria
 * erro em "12.AB", que ainda vai virar um CNPJ inteiro.
 *
 * A Revisão 95 revê a decisão a pedido do usuário — e ela não conflita com a
 * Revisão 32, porque MÁSCARA NÃO É VALIDAÇÃO:
 *
 *   · a máscara é APRESENTAÇÃO — enfeita o que já foi digitado e nunca recusa
 *     um valor pela metade ("12.AB" continua sendo um estado legítimo);
 *   · a VALIDAÇÃO continua onde estava: ao sair do campo (`onBlur`) e no envio,
 *     por `validarCnpj` / `validarTelefoneBrCom`, sem uma linha alterada.
 *
 * O que é gravado no banco TAMBÉM não muda: o CNPJ desce em forma canônica
 * (14 caracteres, sem máscara, maiúsculas — `validarCnpj().cnpj`) e o telefone
 * desce como foi digitado, exatamente como antes.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * A REGRA DE OURO DAS DUAS MÁSCARAS
 * ────────────────────────────────────────────────────────────────────────────
 * **Pontuação só aparece quando há conteúdo depois dela.** Digitar "12" mostra
 * `12`, não `12.` — e apagar o "3" de `12.3` devolve `12`, não `12.` com um
 * ponto órfão que o backspace seguinte não consegue remover. É o detalhe que
 * separa uma máscara utilizável de uma que trava.
 *
 * O cursor é assunto de `CampoMascarado` (`src/components/CampoMascarado.tsx`);
 * aqui as funções são puras — texto entra, texto sai — para poderem ser
 * testadas sem navegador.
 */

/** Um caractere é CONTEÚDO quando sobrevive à máscara; o resto é pontuação. */
export const REGEX_CONTEUDO = /[0-9A-Za-z]/;

/** Quantos caracteres de conteúdo (letra ou dígito) o texto tem. */
export function contarConteudo(texto: string): number {
  let total = 0;
  for (const c of texto) if (REGEX_CONTEUDO.test(c)) total++;
  return total;
}

/**
 * Máscara do CNPJ: `XX.XXX.XXX/XXXX-XX`.
 *
 * ⚠️ **Os 12 primeiros caracteres aceitam LETRA ou dígito** — é o formato
 * alfanumérico que a Revisão 92 implementou a partir da referência oficial da
 * Receita (`src/lib/cnpj.ts`). **Só os 2 últimos, os dígitos verificadores,
 * exigem número.** Uma letra digitada na posição do DV é simplesmente ignorada,
 * em vez de entrar e fazer a validação recusar depois.
 *
 * Minúsculas sobem para maiúsculas, como já fazia `normalizarCnpj`.
 */
export function mascararCnpj(bruto: unknown): string {
  const cru = String(bruto ?? "").toUpperCase();

  let base = ""; // até 12 alfanuméricos
  let dv = ""; // até 2 dígitos
  for (const c of cru) {
    if (base.length < 12) {
      if (/[A-Z0-9]/.test(c)) base += c;
    } else if (dv.length < 2 && /[0-9]/.test(c)) {
      dv += c;
    }
  }

  const t = base + dv;
  const n = t.length;
  if (n === 0) return "";

  let saida = t.slice(0, 2);
  if (n > 2) saida += `.${t.slice(2, 5)}`;
  if (n > 5) saida += `.${t.slice(5, 8)}`;
  if (n > 8) saida += `/${t.slice(8, 12)}`;
  if (n > 12) saida += `-${t.slice(12, 14)}`;
  return saida;
}

/**
 * Máscara do CPF: `XXX.XXX.XXX-XX`.
 *
 * Só dígitos (até 11). Pontuação só aparece quando há conteúdo depois dela —
 * a mesma regra de ouro das máscaras de CNPJ e telefone.
 */
export function mascararCpf(bruto: unknown): string {
  const d = String(bruto ?? "")
    .replace(/\D/g, "")
    .slice(0, 11);
  const n = d.length;
  if (n === 0) return "";

  let saida = d.slice(0, 3);
  if (n > 3) saida += `.${d.slice(3, 6)}`;
  if (n > 6) saida += `.${d.slice(6, 9)}`;
  if (n > 9) saida += `-${d.slice(9, 11)}`;
  return saida;
}

/**
 * Máscara dual CPF/CNPJ — troca pelo conteúdo digitado (Revisão 126).
 *
 * · só dígitos e ≤ 11 → CPF `XXX.XXX.XXX-XX`;
 * · letra digitada **ou** > 11 caracteres de conteúdo → CNPJ
 *   `XX.XXX.XXX/XXXX-XX` (reusa `mascararCnpj`, inclusive alfanumérico).
 *
 * É o mesmo espírito do telefone 10↔11 e do DDI da Revisão 95: a máscara
 * decide pela QUANTIDADE (e pela presença de letra), nunca valida. Quem
 * recusa é `validarDocumentoCliente`, no `onBlur` e no envio.
 */
export function mascararCpfCnpj(bruto: unknown): string {
  const cru = String(bruto ?? "");
  if (/[A-Za-z]/.test(cru)) return mascararCnpj(cru);

  const digitos = cru.replace(/\D/g, "");
  if (digitos.length > 11) return mascararCnpj(cru);
  return mascararCpf(digitos);
}

/**
 * Máscara do telefone: `(XX) XXXXX-XXXX` ou `(XX) XXXX-XXXX`.
 *
 * O formato se adapta sozinho: enquanto houver 10 dígitos ou menos, o corte é
 * 4+4 (fixo); no 11º dígito vira 5+4 (celular). A troca acontece com o cursor
 * no fim da linha, que é onde ela não incomoda.
 *
 * 📌 **O prefixo `+55` é aceito de propósito, e não é enfeite.** O campo do
 * telefone da empresa já podia guardar um número com DDI (`validarTelefoneBrCom`
 * aceita 12 e 13 dígitos começando em 55, Revisões 56-59). Uma máscara travada
 * em 11 dígitos apagaria o DDI de um cadastro existente no primeiro toque de
 * tecla — dado gravado sumindo por causa de uma camada visual.
 *
 * ⚠️ **O corte é em 11 dígitos, não no prefixo `55`.** `5533334444` são 10
 * dígitos: DDD 55 (Santa Maria/RS) + fixo, e sai `(55) 3333-4444`. É a mesma
 * desambiguação por QUANTIDADE de dígitos que a Revisão 56 documentou — pelo
 * prefixo seria impossível distinguir.
 */
export function mascararTelefoneBr(bruto: unknown): string {
  const d = String(bruto ?? "")
    .replace(/\D/g, "")
    .slice(0, 13);
  if (d.length > 11 && d.startsWith("55")) return `+55 ${mascararNacional(d.slice(2))}`;
  // `slice(0, 11)` importa no caso "inserir dígito no meio de um número já
  // cheio": sem ele o excedente vazaria para o último grupo e a máscara
  // mostraria 12 dígitos. O que não cabe é descartado, como no CNPJ.
  return mascararNacional(d.slice(0, 11));
}

/** DDD + número, sem DDI. Recebe no máximo 11 dígitos. */
function mascararNacional(d: string): string {
  const n = d.length;
  if (n === 0) return "";
  if (n <= 2) return `(${d}`;

  const ddd = d.slice(0, 2);
  const resto = d.slice(2);
  if (n <= 6) return `(${ddd}) ${resto}`;
  if (n <= 10) return `(${ddd}) ${resto.slice(0, 4)}-${resto.slice(4)}`;
  return `(${ddd}) ${resto.slice(0, 5)}-${resto.slice(5)}`;
}

/**
 * ────────────────────────────────────────────────────────────────────────────
 * O QUE ACONTECE A CADA TECLA — e por que isto mora aqui, e não no componente
 * ────────────────────────────────────────────────────────────────────────────
 * Máscara mal implementada não erra a máscara: erra o CURSOR. Toda a conta que
 * decide onde o cursor para está nesta função, PURA — entram o texto que o
 * navegador deixou no campo, a posição do cursor e o tipo da edição; saem o
 * texto mascarado e a posição nova. Nenhum DOM, nenhum React.
 *
 * Isso existe para poder ser testado sem navegador: as armadilhas de cursor são
 * combinatórias (digitar no meio, apagar em cima de pontuação, colar, recusar
 * caractere) e conferir isso só no olho, clicando, é como se descobre um mês
 * depois que o campo inverte número.
 *
 * As três armadilhas tratadas:
 *
 * 1. **Contar posição em caracteres da tela dá errado**, porque a máscara
 *    insere e remove pontuação. O que se conta é **quantos caracteres de
 *    CONTEÚDO (letra ou dígito) existem à esquerda do cursor** — esse número
 *    sobrevive à máscara. O cursor volta logo depois do mesmo n-ésimo
 *    caractere de conteúdo no texto já mascarado.
 *
 * 2. **Backspace em cima da pontuação vira tecla morta.** Apagar o "." de
 *    `12.345` devolve `12345`, que a máscara reescreve como `12.345` —
 *    idêntico ao que estava. Nada muda na tela, o usuário aperta de novo, e de
 *    novo, e o campo parece travado. Quando o apagar não altera nada, o
 *    caractere de conteúdo vizinho é removido no lugar da pontuação — que é o
 *    que a tecla significa para quem está olhando. Idem para o Delete, na
 *    direção oposta.
 *
 * 3. **Caractere RECUSADO pela máscara também mexe o cursor.** Digitar uma
 *    letra na posição do dígito verificador, ou um 15º caractere, não pode
 *    fazer o cursor saltar para o fim: o `Math.min` de `posicaoDoCursor` faz
 *    ele ficar exatamente onde estava.
 */
export type TeclaAplicada = { valor: string; cursor: number };

export function aplicarTecla(params: {
  /** O texto que o navegador deixou no campo depois da tecla. */
  bruto: string;
  /** `selectionStart` depois da edição do navegador. */
  cursor: number;
  /** O valor mascarado que estava lá ANTES da tecla. */
  anterior: string;
  /** `InputEvent.inputType` — só `delete*` muda o rumo. */
  tipo: string | null | undefined;
  mascara: (valor: string) => string;
}): TeclaAplicada {
  const { anterior, tipo, mascara } = params;
  let bruto = params.bruto;
  let conteudoAntes = contarConteudo(bruto.slice(0, params.cursor));
  let mascarado = mascara(bruto);

  // Armadilha 2: a tecla comeu só pontuação e a máscara devolveu o mesmo texto.
  if (mascarado === anterior) {
    if (tipo === "deleteContentBackward" && conteudoAntes > 0) {
      bruto = removerConteudo(bruto, conteudoAntes);
      conteudoAntes -= 1;
      mascarado = mascara(bruto);
    } else if (tipo === "deleteContentForward") {
      // Delete apaga para a DIREITA: some o conteúdo seguinte e o cursor fica
      // onde está. Sem conteúdo seguinte, nada acontece — que é o correto.
      bruto = removerConteudo(bruto, conteudoAntes + 1);
      mascarado = mascara(bruto);
    }
  }

  return { valor: mascarado, cursor: posicaoDoCursor(mascarado, conteudoAntes) };
}

/** Remove o n-ésimo (1-based) caractere de conteúdo. Fora do alcance, devolve igual. */
function removerConteudo(texto: string, n: number): string {
  if (n <= 0) return texto;
  let vistos = 0;
  for (let i = 0; i < texto.length; i++) {
    if (REGEX_CONTEUDO.test(texto[i]) && ++vistos === n) {
      return texto.slice(0, i) + texto.slice(i + 1);
    }
  }
  return texto;
}

/**
 * Índice do cursor logo depois do n-ésimo caractere de conteúdo.
 *
 * Dois detalhes decidem se a digitação parece natural:
 *
 * · **`Math.min` com o total** — quando a máscara RECUSA o caractere digitado,
 *   o alvo cai em um e o cursor fica exatamente onde estava, em vez de saltar
 *   para o fim (armadilha 3).
 * · **Pular a pontuação seguinte** — parar antes do `.` de `12.` faria a
 *   próxima tecla parecer que entrou no lugar errado.
 */
function posicaoDoCursor(mascarado: string, conteudoAntes: number): number {
  const alvo = Math.min(conteudoAntes, contarConteudo(mascarado));
  let pos = 0;
  if (alvo > 0) {
    let vistos = 0;
    for (let i = 0; i < mascarado.length; i++) {
      if (REGEX_CONTEUDO.test(mascarado[i]) && ++vistos === alvo) {
        pos = i + 1;
        break;
      }
    }
  }
  while (pos < mascarado.length && !REGEX_CONTEUDO.test(mascarado[pos])) pos++;
  return pos;
}

/**
 * Máscara para valor VINDO DO BANCO — aplica só quando não perde nada.
 *
 * 🔴 Existe por um risco concreto: mascarar o que já está gravado pode APAGAR
 * caractere. Um telefone com 15 dígitos, ou um CNPJ com caractere estranho,
 * passaria pela máscara encurtado, e o próximo "Salvar" gravaria a versão
 * mutilada por cima do original — perda de dado causada por enfeite de tela.
 *
 * A regra aqui é literal: **se o texto mascarado não tiver exatamente os mesmos
 * caracteres de conteúdo do original, o original é exibido cru.** O usuário
 * continua vendo o que está no banco, a máscara assume assim que ele digitar, e
 * a validação (que é quem recusa) segue igual.
 */
export function mascararSalvo(
  bruto: string | null | undefined,
  mascara: (valor: string) => string,
): string {
  const original = String(bruto ?? "").trim();
  if (!original) return "";
  const mascarado = mascara(original);
  const conteudo = (t: string) => t.toUpperCase().replace(/[^0-9A-Z]/g, "");
  return conteudo(mascarado) === conteudo(original) ? mascarado : original;
}
