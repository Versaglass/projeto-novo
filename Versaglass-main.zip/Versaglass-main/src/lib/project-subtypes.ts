// =====================================================================
// SUBTIPO do modelo técnico — o "Tipo de projeto" DENTRO da área.
//
// Espelha a constraint `project_templates_area_subtipo` (migrations
// 20260728100000 + 20260903150100 + 20260903150200 + 20260903160000 +
// 20260904120000 + 20260904130000): Vidraçaria e Esquadrias usam 13 tipos
// comerciais cada; Serralheria / Marcenaria / Marmoraria seguem sete
// subtipos (com `outro_*`).
//
// Esquadrias: IDs sufixados `_esquadrias` — nunca compartilha identificadores
// com Vidraçaria (nem com `portao` de Serralheria).
//
// TRÊS EIXOS INDEPENDENTES, e confundi-los é o defeito que este arquivo existe
// para evitar:
//
//   área      → vidraçaria | esquadrias | serralheria | marcenaria | marmoraria
//               (`public.project_area`; decide card, filtro e paleta do editor)
//   subtipo   → box | janela_esquadrias | portao | armario | ...
//               (ESTE arquivo; o PRODUTO dentro da área)
//   categoria → vidro_comum | temperado | espelho | esquadria
//               (`public.project_category`; o MATERIAL do produto de vidraçaria)
//
// Antes deste módulo, "que produto é este?" morava em `project_templates.tipo`,
// uma coluna TEXT digitada à mão ("Box", "box correr", "BOX 2 FLS"). Texto livre
// não filtra, não agrupa e não pode ser validado — a mesma razão pela qual a
// área ganhou coluna própria em 20260727090000. `tipo` continua existindo e
// intocado; ele deixou de ser a classificação.
//
// ESTE É O ÚNICO LUGAR onde as listas e os rótulos de SUBTIPO de modelo são
// escritos (exceto Vidraçaria, cujos value/label vêm de
// `TIPOS_PROJETO_ORCAMENTO` — subset Vidraçaria de `quote_item_tipo_projeto`).
// Formulário, filtro, card e importação para orçamento partem daqui. Duplicar
// o array em uma tela é como as quatro listas saem de sincronia — e a que
// diverge é sempre a que ninguém está olhando.
// =====================================================================

import { AREAS_PROJETO, type AreaProjeto } from "@/lib/project-area";
import {
  TIPOS_PROJETO_ORCAMENTO,
  type TipoProjetoVidracaria,
  type QuoteItemTipoProjeto,
} from "@/lib/tipo-projeto-orcamento";

/**
 * Os 13 tipos comerciais de Vidraçaria — mesma ordem/valores/rótulos de
 * `TIPOS_PROJETO_ORCAMENTO` (subset de `public.quote_item_tipo_projeto`).
 *
 * Fonte única dos value+label: `tipo-projeto-orcamento.ts`. Aqui só materializa
 * o array de IDs para o `<select>` e a constraint espelhada.
 */
export const SUBTIPOS_VIDRACARIA = TIPOS_PROJETO_ORCAMENTO.map(
  (t) => t.value,
) as readonly TipoProjetoVidracaria[];

/**
 * As opções de cada área, na ordem em que aparecem no `<select>`.
 *
 * Vidraçaria e Esquadrias: 13 tipos comerciais cada (sem "Outro").
 * Demais áreas: produtos mais cadastrados primeiro; `outro_*` fecha a lista.
 *
 * `outro_<area>` (e não um único `outro`) é deliberado nas áreas que o têm: com
 * o identificador carregando a área, um "Outro" de marcenaria nunca pode ser
 * confundido com um "Outro" de marmoraria.
 */
export const SUBTIPOS_POR_AREA = {
  vidracaria: [
    "janela",
    "porta",
    "fixo",
    "box",
    "fechamento_pia",
    "espelho",
    "bascula_maxiar_pivotante",
    "guarda_corpo",
    "reposicao",
    "sacadas",
    "articulados",
    "muro",
    "vitrine",
  ],
  // Taxonomia comercial de Esquadrias. IDs com sufixo `_esquadrias`.
  esquadrias: [
    "janela_esquadrias",
    "porta_esquadrias",
    "maxim_ar_esquadrias",
    "fixos_esquadrias",
    "portao_esquadrias",
    "fachada_esquadrias",
    "porta_pivotante_esquadrias",
    "diversos_esquadrias",
    "basculantes_esquadrias",
    "janela_pivotante_esquadrias",
    "camarao_esquadrias",
    "janela_abrir_esquadrias",
    "gradil_esquadrias",
  ],
  serralheria: [
    "portao",
    "grade",
    "corrimao",
    "estrutura_metalica",
    "cobertura",
    "esquadria_metalica",
    "outro_serralheria",
  ],
  marcenaria: [
    "armario",
    "porta_madeira",
    "painel",
    "bancada_madeira",
    "movel_planejado",
    "prateleira",
    "outro_marcenaria",
  ],
  marmoraria: [
    "bancada_pedra",
    "pia",
    "soleira",
    "revestimento",
    "escada",
    "peitoril",
    "outro_marmoraria",
  ],
} as const satisfies Record<AreaProjeto, readonly string[]>;

/** Qualquer identificador de subtipo válido (união de todas as áreas). */
export type SubtipoProjeto = (typeof SUBTIPOS_POR_AREA)[AreaProjeto][number];

/** Os subtipos de UMA área — `SubtipoDaArea<"marmoraria">` não aceita `"box"`. */
export type SubtipoDaArea<A extends AreaProjeto> = (typeof SUBTIPOS_POR_AREA)[A][number];

/** Garante em compile-time que Vidraçaria ≡ subset comercial dos orçamentos. */
type _VidracariaAlinhadaAoOrcamento =
  SubtipoDaArea<"vidracaria"> extends TipoProjetoVidracaria
    ? TipoProjetoVidracaria extends SubtipoDaArea<"vidracaria">
      ? true
      : never
    : never;
const _vidracariaAlinhadaAoOrcamento: _VidracariaAlinhadaAoOrcamento = true;
void _vidracariaAlinhadaAoOrcamento;
void SUBTIPOS_VIDRACARIA;

/** Garante que os 13 IDs de Esquadrias cabem no enum expandido de orçamento. */
type _EsquadriasNoEnumOrcamento =
  SubtipoDaArea<"esquadrias"> extends QuoteItemTipoProjeto ? true : never;
const _esquadriasNoEnumOrcamento: _EsquadriasNoEnumOrcamento = true;
void _esquadriasNoEnumOrcamento;

/**
 * Rótulos de tela, em português.
 *
 * Os `outro_*` compartilham o rótulo "Outro": o identificador precisa dizer de
 * que área ele é (ver acima), o usuário não — dentro do formulário de
 * marcenaria, "Outro (marcenaria)" seria ruído, porque não há outra opção ali.
 *
 * Esquadrias usa rótulos e IDs próprios (sufixo `_esquadrias`); não compartilha
 * identificadores com Vidraçaria.
 *
 * Vidraçaria: rótulos idênticos a `TIPOS_PROJETO_ORCAMENTO`.
 */
export const ROTULO_SUBTIPO: Record<SubtipoProjeto, string> = {
  // Vidraçaria — labels canônicos do enum comercial
  janela: "Janela",
  porta: "Porta",
  fixo: "Fixo",
  box: "Box",
  fechamento_pia: "Fechamento de Pia",
  espelho: "Espelho",
  bascula_maxiar_pivotante: "Bascula/Maxi-ar/Pivotante",
  guarda_corpo: "Guarda-Corpo",
  reposicao: "Reposição",
  sacadas: "Sacadas",
  articulados: "Articulados",
  muro: "Muro",
  vitrine: "Vitrine",
  // Esquadrias — 13 tipos comerciais (labels exatos do cliente)
  janela_esquadrias: "Janela",
  porta_esquadrias: "Porta",
  maxim_ar_esquadrias: "Maxim-ar",
  fixos_esquadrias: "Fixos",
  portao_esquadrias: "Portão",
  fachada_esquadrias: "Fachada",
  porta_pivotante_esquadrias: "Porta Pivotante",
  diversos_esquadrias: "Diversos",
  basculantes_esquadrias: "Basculantes",
  janela_pivotante_esquadrias: "Janela Pivotante",
  camarao_esquadrias: "Camarão",
  janela_abrir_esquadrias: "Janela Abrir",
  gradil_esquadrias: "Gradil",
  // Serralheria de aço
  portao: "Portão",
  grade: "Grade",
  corrimao: "Corrimão",
  estrutura_metalica: "Estrutura metálica",
  cobertura: "Cobertura",
  esquadria_metalica: "Esquadria metálica",
  outro_serralheria: "Outro",
  // Marcenaria
  armario: "Armário",
  porta_madeira: "Porta de madeira",
  painel: "Painel",
  bancada_madeira: "Bancada de madeira",
  movel_planejado: "Móvel planejado",
  prateleira: "Prateleira",
  outro_marcenaria: "Outro",
  // Marmoraria
  bancada_pedra: "Bancada de pedra",
  pia: "Pia",
  soleira: "Soleira",
  revestimento: "Revestimento",
  escada: "Escada",
  peitoril: "Peitoril",
  outro_marmoraria: "Outro",
};

/**
 * Rótulos só para exibição de registros legados.
 * NÃO entram em `subtiposDaArea` / selects de novos cadastros.
 */
const ROTULO_SUBTIPO_LEGADO: Readonly<Record<string, string>> = {
  // Vidraçaria (pré-lista comercial)
  porta_vidro: "Porta de vidro",
  janela_vidro: "Janela de vidro",
  fechamento_vidro: "Fechamento de vidro",
  outro_vidracaria: "Outro",
  // Esquadrias — taxonomia alumínio (20260903160000) e espelho visual anterior
  janela_aluminio_esquadrias: "Janela de alumínio",
  porta_aluminio_esquadrias: "Porta de alumínio",
  porta_correr_esquadrias: "Porta de correr",
  veneziana_esquadrias: "Veneziana",
  guarda_corpo_esquadrias: "Guarda-corpo",
  outro_esquadrias: "Outro",
  box_esquadrias: "Box",
  porta_vidro_esquadrias: "Porta de vidro",
  janela_vidro_esquadrias: "Janela de vidro",
  espelho_esquadrias: "Espelho",
  fechamento_vidro_esquadrias: "Fechamento de vidro",
};

/** Todos os identificadores em lista única — para validação, nunca para `<select>`. */
export const SUBTIPOS_PROJETO: readonly SubtipoProjeto[] = AREAS_PROJETO.flatMap(
  (a) => SUBTIPOS_POR_AREA[a] as readonly SubtipoProjeto[],
);

/**
 * As opções da área — a ÚNICA fonte para montar o `<select>` do formulário e do
 * filtro. Nenhuma tela deve escrever a lista de novo.
 */
export function subtiposDaArea(area: AreaProjeto): readonly SubtipoProjeto[] {
  return SUBTIPOS_POR_AREA[area];
}

/** Confere se o valor é um identificador conhecido, sem olhar a área. */
export function ehSubtipoProjeto(valor: unknown): valor is SubtipoProjeto {
  return typeof valor === "string" && (SUBTIPOS_PROJETO as readonly string[]).includes(valor);
}

/**
 * VALIDAÇÃO DO PAR — a mesma pergunta que a constraint
 * `project_templates_area_subtipo` faz no banco (para valores atuais).
 *
 * É esta função, e não `ehSubtipoProjeto`, que o formulário usa: `portao` é um
 * subtipo perfeitamente válido e ainda assim não pode ser salvo em um modelo de
 * marcenaria. Quem valida só a lista global deixa passar exatamente o erro que
 * a constraint existe para barrar — e o usuário descobre no `save`, com uma
 * mensagem de banco.
 */
export function ehSubtipoDaArea(area: AreaProjeto, valor: unknown): valor is SubtipoProjeto {
  return (
    typeof valor === "string" && (SUBTIPOS_POR_AREA[area] as readonly string[]).includes(valor)
  );
}

/**
 * Contagem por área só de modelos **navegáveis** na taxonomia atual
 * (`ehSubtipoDaArea`). Subtipos legados (`janela_vidro`, `porta_vidro`, …)
 * existem no banco e ainda entram em listagens brutas por `area`, mas não
 * aparecem nos cards de tipo — por isso a contagem do card de área precisa
 * usar esta função (ou o mesmo predicado), não um `count` por `area` puro.
 */
export type ContagemNavegavelPorArea = Record<AreaProjeto, number> & { todos: number };

export function contagemNavegavelPorArea(
  linhas: readonly { area: string | null; subtipo: string | null }[],
): ContagemNavegavelPorArea {
  const contagem: ContagemNavegavelPorArea = {
    todos: 0,
    vidracaria: 0,
    esquadrias: 0,
    serralheria: 0,
    marcenaria: 0,
    marmoraria: 0,
  };
  for (const l of linhas) {
    if (!l.area || !(AREAS_PROJETO as readonly string[]).includes(l.area)) continue;
    const area = l.area as AreaProjeto;
    if (!ehSubtipoDaArea(area, l.subtipo)) continue;
    contagem[area] += 1;
    contagem.todos += 1;
  }
  return contagem;
}

/**
 * Valor vindo de fora (URL, estado antigo, resposta do banco) → subtipo válido
 * PARA AQUELA ÁREA, ou `null`.
 *
 * Devolve `null` em vez de um padrão pelo mesmo motivo de `normalizaArea`: um
 * subtipo errado é pior do que subtipo nenhum, porque parece certo. Quem chama
 * decide — o formulário volta a exigir a escolha, o filtro simplesmente não
 * filtra.
 */
export function normalizaSubtipo(area: AreaProjeto, valor: unknown): SubtipoProjeto | null {
  return ehSubtipoDaArea(area, valor) ? valor : null;
}

/**
 * O "Outro" da área — `outro_serralheria`, `outro_marcenaria`, etc.
 *
 * Vidraçaria e Esquadrias não têm mais "Outro" (listas comerciais fechadas).
 * Existe para que nenhuma tela precise concatenar `"outro_" + area` na mão.
 */
export function subtipoOutroDaArea(area: AreaProjeto): SubtipoProjeto {
  const candidato = `outro_${area}`;
  if (!ehSubtipoDaArea(area, candidato)) {
    throw new Error(`A área "${area}" não possui subtipo "Outro".`);
  }
  return candidato;
}

/**
 * Rótulo amigável para exibição.
 *
 * Aceita `unknown` porque o card recebe o valor cru do banco e um modelo de uma
 * base sem a migration aplicada traz `null`. Nesses casos devolve `null` — a
 * tela decide se omite a linha ou escreve "não definido", em vez de receber um
 * rótulo inventado.
 *
 * Subtipos legados (removidos dos selects) ainda recebem rótulo para
 * cards/listagens não ficarem mudos.
 */
export function rotuloSubtipo(valor: unknown): string | null {
  if (ehSubtipoProjeto(valor)) return ROTULO_SUBTIPO[valor];
  if (typeof valor === "string" && valor in ROTULO_SUBTIPO_LEGADO) {
    return ROTULO_SUBTIPO_LEGADO[valor] ?? null;
  }
  return null;
}
