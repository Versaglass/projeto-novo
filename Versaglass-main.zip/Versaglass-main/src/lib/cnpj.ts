/**
 * CNPJ — validação de formato E de dígito verificador, nos DOIS algoritmos.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * FONTE DO ALGORITMO — não foi deduzido nem copiado de blog
 * ────────────────────────────────────────────────────────────────────────────
 * Portado da **implementação de referência OFICIAL da Receita Federal**, em
 * TypeScript, distribuída no pacote `codigos-cnpj.zip` da página de documentos
 * técnicos do CNPJ:
 *
 *   https://www.gov.br/receitafederal/pt-br/centrais-de-conteudo/publicacoes/
 *     documentos-tecnicos/cnpj
 *   → "Arquivos de Referência para Cálculo do DV" (codigos-cnpj.zip),
 *     arquivo `src/typescript/cnpj.ts` (classe `CNPJ`)
 *   → acompanha o "Manual de Cálculo do DV do CNPJ" (manual-dv-cnpj.pdf)
 *
 * Os vetores de teste desta implementação são os do próprio pacote oficial
 * (`src/typescript/test.ts`), incluindo `12.ABC.345/01DE-35`, `ABCDEFGHIJKL80`
 * e `00000000000191`.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * A REGRA, EM UMA FRASE
 * ────────────────────────────────────────────────────────────────────────────
 * O CNPJ tem **14 caracteres**: os **12 primeiros** podem ser letras `A-Z` ou
 * dígitos; os **2 últimos** são o DV e são **sempre numéricos**.
 *
 * O DV continua sendo módulo 11 com os mesmos pesos de sempre. A única mudança
 * do formato alfanumérico é **como cada caractere vira número**:
 *
 *     valor = código ASCII do caractere − 48
 *
 * Para dígitos isso devolve o próprio dígito (`'7'` = 55 − 48 = 7), e é por
 * isso que **o algoritmo novo calcula o mesmo DV que o antigo para um CNPJ
 * totalmente numérico** — não são duas contas, é uma só que generaliza a
 * anterior. Para letras, `'A'` = 65 − 48 = **17**, …, `'Z'` = 90 − 48 = **42**.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * DIFERENÇAS DELIBERADAS EM RELAÇÃO À REFERÊNCIA OFICIAL
 * ────────────────────────────────────────────────────────────────────────────
 * O núcleo (`calcularDvCnpj`) é fiel linha a linha. O que muda é só a camada de
 * ENTRADA, e cada desvio está aqui para ser conferido:
 *
 * 1. **Minúsculas são aceitas e convertidas para maiúsculas.** A referência
 *    oficial RECUSA `12.ABc.345/01DE-35` (o regex `/^([A-Z\d]){12}$/` não tem
 *    flag `i`). Num formulário isso puniria quem digita sem Caps Lock, e o
 *    valor gravado é o canônico em maiúsculas de qualquer jeito. **A validade
 *    não muda — só a tolerância na digitação.**
 * 2. **Espaços em branco são removidos** junto com a máscara. A referência só
 *    remove `.`, `/` e `-`.
 * 3. **Mensagens em português, dizendo o que corrigir**, em vez de um booleano
 *    (o padrão que `validarTelefoneBr` e `validaNumeroCampo` já seguem).
 *
 * ⚠️ **O que esta implementação NÃO faz, porque a oficial também não:** ela
 * **não recusa sequências repetidas** como `11.111.111/1111-11`. O único valor
 * repetido barrado é o **CNPJ zerado** (`00000000000000`), que a referência
 * trata como caso especial. Se `11111111111111` fecha o DV, ele passa — e
 * inventar uma regra a mais faria esta validação divergir da Receita.
 */

/** Os 12 primeiros caracteres: letra maiúscula ou dígito. */
const REGEX_BASE = /^[A-Z\d]{12}$/;
/** CNPJ completo: 12 alfanuméricos + 2 dígitos. */
const REGEX_COMPLETO = /^[A-Z\d]{12}\d{2}$/;
/** Pontuação da máscara e espaços — descartados antes de validar. */
const REGEX_MASCARA = /[./\-\s]/g;
/** Qualquer coisa fora de letra, dígito, máscara ou espaço reprova de saída. */
const REGEX_CARACTERE_PROIBIDO = /[^A-Z\d./\-\s]/i;

/** `"0"` — a base da conversão ASCII descrita no manual oficial. */
const VALOR_BASE = "0".charCodeAt(0);

/**
 * Pesos do módulo 11, na ordem da referência oficial.
 *
 * O 1º DV usa `PESOS[1..12]` (12 pesos) e o 2º usa `PESOS[0..12]` (13 pesos,
 * o último multiplicando o DV1 recém-calculado). É por isso que a lista tem
 * 13 posições e não 12.
 */
const PESOS = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];

const CNPJ_ZERADO = "00000000000000";

/** Tira máscara e espaços e sobe para maiúsculas. Não valida nada. */
export function normalizarCnpj(bruto: unknown): string {
  return String(bruto ?? "")
    .trim()
    .toUpperCase()
    .replace(REGEX_MASCARA, "");
}

/**
 * Calcula os dois dígitos verificadores dos 12 primeiros caracteres.
 *
 * Porte fiel de `CNPJ.calculaDV` da referência oficial. Devolve `null` — em vez
 * de lançar, como a original — porque aqui quem decide a mensagem é a camada de
 * validação, e exceção para entrada de formulário é caro sem ganho.
 */
export function calcularDvCnpj(base: string): string | null {
  const b = normalizarCnpj(base);
  if (!REGEX_BASE.test(b) || b === CNPJ_ZERADO.substring(0, 12)) return null;

  let somaDv1 = 0;
  let somaDv2 = 0;
  for (let i = 0; i < 12; i++) {
    const valor = b.charCodeAt(i) - VALOR_BASE;
    somaDv1 += valor * PESOS[i + 1];
    somaDv2 += valor * PESOS[i];
  }
  const dv1 = somaDv1 % 11 < 2 ? 0 : 11 - (somaDv1 % 11);
  somaDv2 += dv1 * PESOS[12];
  const dv2 = somaDv2 % 11 < 2 ? 0 : 11 - (somaDv2 % 11);
  return `${dv1}${dv2}`;
}

/** `true` só para CNPJ completo e com DV correto. Sem tolerância. */
export function cnpjEhValido(bruto: unknown): boolean {
  const c = normalizarCnpj(bruto);
  if (!REGEX_COMPLETO.test(c) || c === CNPJ_ZERADO) return false;
  return calcularDvCnpj(c.substring(0, 12)) === c.substring(12);
}

/** `true` quando é totalmente numérico — o formato antigo. */
export function cnpjEhNumerico(bruto: unknown): boolean {
  return /^\d{14}$/.test(normalizarCnpj(bruto));
}

/**
 * Aplica a máscara `XX.XXX.XXX/XXXX-XX`.
 *
 * Serve para os dois formatos: a máscara é posicional e não olha se o
 * caractere é letra ou dígito. Entrada que não tem 14 caracteres volta como
 * está — formatar lixo com cara de documento é justamente o que a Revisão 91
 * flagrou.
 */
export function formatarCnpj(bruto: unknown): string {
  const c = normalizarCnpj(bruto);
  if (c.length !== 14) return String(bruto ?? "").trim();
  return `${c.slice(0, 2)}.${c.slice(2, 5)}.${c.slice(5, 8)}/${c.slice(8, 12)}-${c.slice(12)}`;
}

export type CnpjValidado =
  | { ok: true; /** 14 caracteres, sem máscara, maiúsculas. */ cnpj: string; formatado: string }
  | { ok: false; erro: string };

/**
 * Valida um CNPJ digitado e devolve o valor canônico ou a razão da recusa.
 *
 * `obrigatorio: false` (o padrão) trata campo vazio como ausência legítima —
 * é assim que o cadastro da empresa trata o CNPJ hoje, e apertar isso seria
 * outra decisão, não esta.
 */
export function validarCnpj(bruto: unknown, opcoes?: { obrigatorio?: boolean }): CnpjValidado {
  const original = String(bruto ?? "").trim();
  const obrigatorio = opcoes?.obrigatorio ?? false;

  if (!original) {
    return obrigatorio
      ? { ok: false, erro: "Informe o CNPJ da empresa." }
      : { ok: true, cnpj: "", formatado: "" };
  }

  if (REGEX_CARACTERE_PROIBIDO.test(original)) {
    return {
      ok: false,
      erro: `O CNPJ tem caractere que não existe neste documento ("${original}"). Use apenas letras de A a Z, números e a pontuação . / -`,
    };
  }

  const c = normalizarCnpj(original);

  if (c.length !== 14) {
    return {
      ok: false,
      erro: `O CNPJ precisa ter 14 caracteres — 12 mais os 2 dígitos verificadores. Você digitou ${c.length}.`,
    };
  }

  if (!/^\d{2}$/.test(c.slice(12))) {
    return {
      ok: false,
      erro: "Os dois últimos caracteres do CNPJ são os dígitos verificadores e precisam ser números, mesmo no formato novo com letras.",
    };
  }

  if (!REGEX_BASE.test(c.slice(0, 12))) {
    return {
      ok: false,
      erro: "Os 12 primeiros caracteres do CNPJ aceitam apenas letras de A a Z e números.",
    };
  }

  if (c === CNPJ_ZERADO) {
    return { ok: false, erro: "CNPJ zerado não é um documento válido." };
  }

  const dvEsperado = calcularDvCnpj(c.slice(0, 12));
  if (dvEsperado === null) {
    // Só acontece com a base zerada, já barrada acima — rede de segurança.
    return { ok: false, erro: "CNPJ inválido." };
  }
  if (dvEsperado !== c.slice(12)) {
    return {
      ok: false,
      erro: `CNPJ inválido: os dígitos verificadores não conferem. Para os 12 primeiros caracteres digitados, o final correto seria "${dvEsperado}" — confira o número.`,
    };
  }

  return { ok: true, cnpj: c, formatado: formatarCnpj(c) };
}
