import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const PROVISIONAL_PASSWORD = "12345678";

const inputSchema = z.object({
  email: z.string().trim().toLowerCase().email().max(255).optional(),
});

/**
 * Redefine a senha do próprio usuário admin autenticado para a senha provisória (12345678).
 * Uso: recuperação emergencial dentro da IA Intelligence.
 */
export const resetAdminToProvisional = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => inputSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: isAdmin, error: roleErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (roleErr) throw new Error(roleErr.message);
    if (!isAdmin) throw new Error("Este usuário não tem permissão de admin.");

    const { data: userResult, error: userErr } = await supabaseAdmin.auth.admin.getUserById(
      context.userId,
    );
    if (userErr) throw new Error(userErr.message);
    const user = userResult.user;
    const currentEmail = (user.email ?? "").toLowerCase();
    if (data.email && data.email !== currentEmail) {
      throw new Error("Por segurança, só é possível ativar a senha provisória do ADM logado.");
    }

    const { error: updErr } = await supabaseAdmin.auth.admin.updateUserById(context.userId, {
      password: PROVISIONAL_PASSWORD,
      email_confirm: true,
    });
    if (updErr) throw new Error(updErr.message);

    return { ok: true as const, email: currentEmail };
  });
