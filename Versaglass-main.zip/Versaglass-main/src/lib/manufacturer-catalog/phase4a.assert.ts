/**
 * Asserções Fase 4A — Catálogo de Fabricantes (somente leitura).
 * npx tsx src/lib/manufacturer-catalog/phase4a.assert.ts
 */

import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  formatManufacturerAttributes,
  formatManufacturerObservations,
  PHASE4A_READ_ONLY,
  sanitizeCatalogSearchTerm,
} from "./attributes";
import {
  catalogListRange,
  catalogSortColumn,
  MANUFACTURER_CATALOG_PAGE_SIZE,
  searchCatalogoFabricantes,
} from "./search";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "../../..");

function run() {
  assert.equal(PHASE4A_READ_ONLY, true);

  // Busca / sanitize
  assert.equal(sanitizeCatalogSearchTerm("AL 1629 JB"), "AL 1629 JB");
  assert.ok(!sanitizeCatalogSearchTerm("a%b(c),*").includes("%"));
  assert.ok(!sanitizeCatalogSearchTerm("a%b(c),*").includes("("));
  assert.ok(!sanitizeCatalogSearchTerm("foo_bar").includes("_"));

  // Search params URL
  const s = searchCatalogoFabricantes({
    q: "puxador",
    fabricante: "11111111-1111-1111-1111-111111111111",
    categoria: "ferragem",
    linha: "Tradicional",
    page: 2,
    ordem: "nome_desc",
  });
  assert.equal(s.q, "puxador");
  assert.equal(s.fabricante, "11111111-1111-1111-1111-111111111111");
  assert.equal(s.categoria, "ferragem");
  assert.equal(s.linha, "Tradicional");
  assert.equal(s.page, 2);
  assert.equal(s.ordem, "nome_desc");
  assert.equal(searchCatalogoFabricantes({ page: 1, ordem: "nome_asc" }).page, undefined);

  // Paginação
  assert.equal(MANUFACTURER_CATALOG_PAGE_SIZE, 24);
  assert.deepEqual(catalogListRange(1), { from: 0, to: 23, pageSize: 24 });
  assert.deepEqual(catalogListRange(2), { from: 24, to: 47, pageSize: 24 });

  // Ordenação
  assert.deepEqual(catalogSortColumn("nome_asc"), { column: "name", ascending: true });
  assert.deepEqual(catalogSortColumn("nome_desc"), { column: "name", ascending: false });
  assert.deepEqual(catalogSortColumn("recentes"), { column: "created_at", ascending: false });

  // Attributes
  const strAttrs = formatManufacturerAttributes([{ name: "Diâmetro", value: "25", unit: "mm" }]);
  assert.equal(strAttrs[0]?.label, "Diâmetro");
  assert.equal(strAttrs[0]?.value, "25 mm");

  const numAttrs = formatManufacturerAttributes([{ label: "Espessura", value: 3, unit: "mm" }]);
  assert.equal(numAttrs[0]?.value, "3 mm");

  const arrAttrs = formatManufacturerAttributes([
    { name: "Cores disponíveis", value: ["CRO", "NAT", "BCO"] },
  ]);
  assert.ok(arrAttrs[0]?.value.includes("CRO"));
  assert.ok(arrAttrs[0]?.value.includes("NAT"));

  assert.deepEqual(formatManufacturerAttributes(null), []);
  assert.deepEqual(formatManufacturerAttributes(undefined), []);
  assert.doesNotThrow(() => formatManufacturerAttributes({ weird: { nested: true } }));

  // Observations
  assert.deepEqual(formatManufacturerObservations([]), []);
  assert.deepEqual(formatManufacturerObservations(null), []);
  assert.deepEqual(formatManufacturerObservations(["Obs A", "Obs B"]), ["Obs A", "Obs B"]);
  assert.doesNotThrow(() => formatManufacturerObservations({ bad: true }));

  // Sem mutações / sem importação na feature 4A
  const hookSrc = readFileSync(join(root, "src/hooks/use-manufacturer-catalog.ts"), "utf8");
  assert.ok(!/\.insert\(|\.update\(|\.delete\(|\.upsert\(/.test(hookSrc));
  assert.ok(!hookSrc.includes('.from("inventory_items")'));
  assert.ok(!hookSrc.includes(".from('inventory_items')"));
  assert.ok(hookSrc.includes('.eq("active", true)'));
  assert.ok(hookSrc.includes("product_manufacturers") && hookSrc.includes("!inner"));
  assert.ok(hookSrc.includes("product_manufacturers.active"));

  const routesDir = join(root, "src/routes/_authenticated");
  const catalogRoutes = readdirSync(routesDir).filter((f) => f.includes("catalogo-fabricantes"));
  assert.ok(catalogRoutes.length >= 1);
  for (const f of catalogRoutes) {
    const src = readFileSync(join(routesDir, f), "utf8");
    assert.ok(!/\.insert\(|\.update\(|\.delete\(/.test(src));
    assert.ok(!src.includes('.from("inventory_items")'));
    assert.ok(!src.includes("importar-catalogo"));
    // Fase 4B adiciona "Adicionar ao estoque" no detalhe; 4A garante sem mutação do global.
    assert.ok(
      !/\.from\(["']manufacturer_products["']\)[\s\S]{0,80}\.(insert|update|delete)/.test(src),
    );
    // Rotas legadas: acesso só platform admin (produtos globais vão ao Estoque).
    assert.ok(src.includes("requireAdmin"));
  }

  // StorageImage inclui manufacturer-catalog
  const imgSrc = readFileSync(join(root, "src/components/StorageImage.tsx"), "utf8");
  assert.ok(imgSrc.includes("manufacturer-catalog"));

  // Nav: Catálogo de Fabricantes removido do menu do usuário; Estoque permanece.
  const shell = readFileSync(join(root, "src/components/AppShell.tsx"), "utf8");
  assert.ok(!shell.includes('label: "Catálogo de Fabricantes"'));
  assert.ok(!/to:\s*"\/app\/catalogo-fabricantes"/.test(shell));
  assert.ok(shell.includes("/app/estoque"));
  // Importação continua adminOnly
  assert.ok(shell.includes("Importar catálogo com IA"));
  assert.ok(shell.includes("/app/admin/importar-catalogo"));
  assert.match(shell, /to:\s*"\/app\/admin\/importar-catalogo"[\s\S]*?adminOnly:\s*true/);

  // Placeholder / empty concepts
  assert.ok(true); // primary null → UI placeholder (rota)

  console.log("manufacturer-catalog phase4a.assert: OK");
}

run();
