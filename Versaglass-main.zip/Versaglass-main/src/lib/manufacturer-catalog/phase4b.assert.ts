/**
 * Asserções Fase 4B — adoção manufacturer_products → inventory_items.
 * npx tsx src/lib/manufacturer-catalog/phase4b.assert.ts
 *
 * Live tests (RLS/race/empresa) NÃO são executados aqui.
 */

import assert from "node:assert/strict";
import { readFileSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  adoptManufacturerProductErrorMessage,
  canAdoptManufacturerProduct,
  draftFromManufacturerProduct,
} from "./adopt";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "../../..");

function run() {
  const migPath = join(
    root,
    "supabase/migrations/20260910190000_inventory_adopt_manufacturer_product.sql",
  );
  assert.ok(existsSync(migPath), "migration 4B existe");
  const mig = readFileSync(migPath, "utf8");

  // 1. coluna nullable
  assert.ok(mig.includes("manufacturer_product_id uuid"));
  assert.ok(/add column if not exists manufacturer_product_id/i.test(mig));

  // 3–4. FK + ON DELETE SET NULL
  assert.ok(/references public\.manufacturer_products\(id\)\s+on delete set null/i.test(mig));

  // 5. unique parcial
  assert.ok(mig.includes("inventory_items_company_manufacturer_product_uq"));
  assert.ok(/unique index[\s\S]*company_id,\s*manufacturer_product_id/i.test(mig));
  assert.ok(/where manufacturer_product_id is not null/i.test(mig));

  // 9–11. RPC revalida ativo
  assert.ok(mig.includes("adopt_manufacturer_product_to_inventory"));
  assert.ok(mig.includes("mp.active = true"));
  assert.ok(mig.includes("PRODUTO_INDISPONIVEL"));
  assert.ok(mig.includes("JA_ADOTADO"));
  assert.ok(mig.includes("is_company_member"));
  assert.ok(/imagem_url,\s*\n\s*null/i.test(mig) || mig.includes("null, -- sem cópia"));
  assert.ok(
    mig.includes("null, -- fabricante ≠ fornecedor") || /fornecedor[\s\S]{0,40}null/.test(mig),
  );
  assert.ok(!/create trigger[\s\S]*manufacturer_product/i.test(mig)); // sem sync trigger
  assert.ok(mig.toLowerCase().includes("sem sincronização") || mig.includes("Sem sync"));

  // Draft / herança
  const draft = draftFromManufacturerProduct({
    name: "Puxador com 25mm de diâmetro",
    description: "Desc técnica",
    source_code: "AL 1629 JB",
    inventory_category: "ferragem",
    unit: "un",
  });
  assert.equal(draft.nome, "Puxador com 25mm de diâmetro");
  assert.equal(draft.descricao, "Desc técnica");
  assert.equal(draft.sku, "AL 1629 JB");
  assert.equal(draft.categoria, "ferragem");
  assert.equal(draft.unidade, "un");
  assert.ok(!("imagem_url" in draft)); // 29–30 sem cópia
  assert.ok(!("quantidade" in draft));
  assert.ok(!("custo_unit" in draft));
  assert.ok(!("preco_venda" in draft));
  assert.ok(!("supplier_id" in draft));
  assert.ok(!("ncm" in draft));

  const draftFallback = draftFromManufacturerProduct({
    name: "X",
    description: null,
    source_code: "C1",
    inventory_category: null,
    unit: null,
  });
  assert.equal(draftFallback.categoria, undefined);
  assert.equal(draftFallback.unidade, undefined);

  assert.equal(
    canAdoptManufacturerProduct({
      hasActiveCompany: false,
      companyRole: "owner",
      permissions: { manage_estoque: true },
    }),
    false,
  );

  // Erros amigáveis
  assert.equal(
    adoptManufacturerProductErrorMessage({ code: "23505", message: "JA_ADOTADO" }),
    "Este produto já foi adicionado ao estoque da empresa.",
  );
  assert.equal(
    adoptManufacturerProductErrorMessage({ code: "P0002", message: "PRODUTO_INDISPONIVEL" }),
    "Este produto não está mais disponível no catálogo.",
  );

  // Hook adoção: RPC, sem service role, sem escrita em manufacturer_products
  const adoptHook = readFileSync(join(root, "src/hooks/use-adopt-manufacturer-product.ts"), "utf8");
  assert.ok(adoptHook.includes('rpc("adopt_manufacturer_product_to_inventory"'));
  assert.ok(!adoptHook.includes("service_role"));
  assert.ok(!adoptHook.includes('.from("manufacturer_products")'));
  assert.ok(adoptHook.includes("useAdoptedManufacturerProductIds"));
  assert.ok(adoptHook.includes('.in("manufacturer_product_id"'));

  // use-inventory: join + manufacturer_product_id + comentário snapshot
  const inv = readFileSync(join(root, "src/hooks/use-inventory.ts"), "utf8");
  assert.ok(inv.includes("manufacturer_product_id"));
  assert.ok(inv.includes("manufacturer_products ("));
  assert.ok(
    inv.includes("Não sincroniza automaticamente") ||
      inv.includes("sem sincronização") ||
      inv.includes("snapshot"),
  );
  assert.ok(inv.includes("mapInventoryRow"));

  // UI detalhe: CTA de adoção removido — overlay automático no Estoque
  const detail = readFileSync(
    join(root, "src/routes/_authenticated/app.catalogo-fabricantes.$productId.tsx"),
    "utf8",
  );
  assert.ok(!detail.includes("Adicionar ao estoque"));
  assert.ok(!detail.includes("useAdoptManufacturerProduct"));
  assert.ok(!detail.includes("canAdoptManufacturerProduct"));
  assert.ok(!detail.includes("InventoryItemDialog"));
  assert.ok(detail.includes('to="/app/estoque"'));
  assert.ok(detail.includes("aparecem automaticamente") || detail.includes("Não é necessário"));
  assert.ok(!detail.includes('.from("manufacturer_products").update'));
  assert.ok(!detail.includes('.from("manufacturer_products").insert'));

  // Listagem: sem badge de adoção / sem N+1
  const list = readFileSync(
    join(root, "src/routes/_authenticated/app.catalogo-fabricantes.tsx"),
    "utf8",
  );
  assert.ok(!list.includes("useAdoptedManufacturerProductIds"));
  assert.ok(!list.includes("No estoque"));
  assert.ok(!/items\.map\([\s\S]{0,200}from\(["']inventory_items["']\)/.test(list));
  assert.ok(list.includes("requireAdmin"));

  // Thumb fallback
  const thumb = readFileSync(join(root, "src/components/inventory/InventoryItemThumb.tsx"), "utf8");
  assert.ok(thumb.includes('bucket="manufacturer-catalog"'));
  assert.ok(thumb.includes("imagem_url"));
  assert.ok(thumb.includes("primary_image_path"));

  // Estoque usa thumb
  const estoque = readFileSync(join(root, "src/routes/_authenticated/app.estoque.tsx"), "utf8");
  assert.ok(estoque.includes("InventoryItemThumb"));

  // Dialog reutilizado
  const dialog = readFileSync(
    join(root, "src/components/inventory/InventoryItemDialog.tsx"),
    "utf8",
  );
  assert.ok(dialog.includes("dialogTitle"));
  assert.ok(dialog.includes("contextBanner"));
  assert.ok(dialog.includes("needsCategoryChoice"));

  // Types
  const types = readFileSync(join(root, "src/integrations/supabase/types.ts"), "utf8");
  assert.ok(types.includes("manufacturer_product_id"));
  assert.ok(types.includes("adopt_manufacturer_product_to_inventory"));
  assert.ok(types.includes("can_manage_company_estoque"));

  // Comentário architectural na migration
  assert.ok(mig.includes("proveniência") || mig.includes("Origem no catálogo"));

  // Hardening migration presente
  assert.ok(
    existsSync(
      join(root, "supabase/migrations/20260910193000_adopt_estoque_permission_hardening.sql"),
    ),
  );

  console.log("manufacturer-catalog phase4b.assert: OK");
}

run();
