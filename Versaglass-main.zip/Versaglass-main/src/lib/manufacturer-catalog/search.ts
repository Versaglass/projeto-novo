/**
 * Params de busca/listagem do Catálogo de Fabricantes (Fase 4A).
 */

import {
  MANUFACTURER_CATALOG_PAGE_SIZE,
  parseCatalogPage,
  parseCatalogSort,
  sanitizeCatalogSearchTerm,
  type CatalogSort,
} from "./attributes";

export type ManufacturerCatalogSearch = {
  q?: string;
  fabricante?: string;
  categoria?: string;
  linha?: string;
  page?: number;
  ordem?: CatalogSort;
};

export function searchCatalogoFabricantes(valores: {
  q?: string;
  fabricante?: string;
  categoria?: string;
  linha?: string;
  page?: unknown;
  ordem?: unknown;
}): ManufacturerCatalogSearch {
  const saida: ManufacturerCatalogSearch = {};
  const q = typeof valores.q === "string" ? sanitizeCatalogSearchTerm(valores.q) : "";
  if (q) saida.q = q;

  if (
    typeof valores.fabricante === "string" &&
    /^[0-9a-f-]{36}$/i.test(valores.fabricante.trim())
  ) {
    saida.fabricante = valores.fabricante.trim().toLowerCase();
  }

  if (typeof valores.categoria === "string" && valores.categoria.trim()) {
    saida.categoria = valores.categoria.trim();
  }

  if (typeof valores.linha === "string" && valores.linha.trim()) {
    saida.linha = valores.linha.trim().slice(0, 120);
  }

  const page = parseCatalogPage(valores.page);
  if (page > 1) saida.page = page;

  const ordem = parseCatalogSort(valores.ordem);
  if (ordem !== "nome_asc") saida.ordem = ordem;

  return saida;
}

export function catalogListRange(page: number, pageSize = MANUFACTURER_CATALOG_PAGE_SIZE) {
  const p = Math.max(1, page);
  const from = (p - 1) * pageSize;
  const to = from + pageSize - 1;
  return { from, to, pageSize };
}

export function catalogSortColumn(ordem: CatalogSort): {
  column: "name" | "created_at";
  ascending: boolean;
} {
  if (ordem === "nome_desc") return { column: "name", ascending: false };
  if (ordem === "recentes") return { column: "created_at", ascending: false };
  return { column: "name", ascending: true };
}

export { MANUFACTURER_CATALOG_PAGE_SIZE };
