/**
 * Helpers puros da adoção catálogo → estoque (Fase 4B).
 * Sem React / Supabase — testáveis offline.
 */

import { canManageCompanyEstoque } from "../inventory-auth";

export { canManageCompanyEstoque } from "../inventory-auth";

const CATEGORIA_VALUES = [
  "aluminio",
  "vidro",
  "ferragem",
  "acessorio",
  "perfil",
  "led",
  "cola",
  "outros",
  "aco_metalon",
  "chapa_aco",
  "solda",
  "mdf",
  "ferragem_moveis",
  "fita_borda",
  "marmore",
  "quartzo",
  "porcelanato",
] as const;

const UNIT_VALUES = ["un", "m", "m2", "kg", "pc", "cx"] as const;

export type ManufacturerProductAdoptDraft = {
  nome: string;
  descricao: string;
  sku: string;
  /** Só preenchido se o catálogo tiver enum válido — sem fallback arbitrário. */
  categoria?: (typeof CATEGORIA_VALUES)[number];
  /** Só preenchido se o catálogo tiver enum válido — unidade é NOT NULL no estoque. */
  unidade?: (typeof UNIT_VALUES)[number];
};

/** Prefill comercial a partir do produto global (editável antes de salvar). */
export function draftFromManufacturerProduct(product: {
  name: string;
  description: string | null;
  source_code: string;
  inventory_category: string | null;
  unit: string | null;
}): ManufacturerProductAdoptDraft {
  const draft: ManufacturerProductAdoptDraft = {
    nome: product.name.slice(0, 120),
    descricao: (product.description ?? "").slice(0, 255),
    sku: product.source_code.slice(0, 64),
  };

  if (
    product.inventory_category &&
    CATEGORIA_VALUES.includes(product.inventory_category as (typeof CATEGORIA_VALUES)[number])
  ) {
    draft.categoria = product.inventory_category as (typeof CATEGORIA_VALUES)[number];
  }

  if (product.unit && UNIT_VALUES.includes(product.unit as (typeof UNIT_VALUES)[number])) {
    draft.unidade = product.unit as (typeof UNIT_VALUES)[number];
  }

  return draft;
}

/**
 * Ação "Adicionar ao estoque" a partir do catálogo: mesma regra de gestão de estoque.
 */
export function canAdoptManufacturerProduct(args: {
  hasActiveCompany: boolean;
  companyRole: string | null | undefined;
  permissions: { manage_estoque?: boolean } | null | undefined;
}): boolean {
  return canManageCompanyEstoque(args);
}

export function adoptManufacturerProductErrorMessage(error: unknown): string {
  const e = error as { code?: string; message?: string; details?: string } | null;
  const msg = `${e?.message ?? ""} ${e?.details ?? ""}`;
  if (msg.includes("PRODUTO_INDISPONIVEL") || e?.code === "P0002") {
    return "Este produto não está mais disponível no catálogo.";
  }
  if (msg.includes("JA_ADOTADO") || e?.code === "23505") {
    return "Este produto já foi adicionado ao estoque da empresa.";
  }
  if (
    e?.code === "42501" ||
    e?.code === "PGRST301" ||
    msg.includes("Sem permissao") ||
    msg.includes("Sem permissão")
  ) {
    return "Você não tem permissão para esta operação.";
  }
  if (e?.code === "23514" || msg.includes("Valores comerciais")) {
    return "Valor inválido: quantidade e preços não podem ser negativos.";
  }
  if (msg.includes("Categoria obrigatoria") || msg.includes("Categoria obrigatória")) {
    return "Selecione uma categoria.";
  }
  if (msg.includes("Unidade obrigatoria") || msg.includes("Unidade obrigatória")) {
    return "Selecione uma unidade.";
  }
  if (e?.message === "Já existe um item com esses dados.") {
    return "Este produto já foi adicionado ao estoque da empresa.";
  }
  if (e?.message) return e.message;
  return "Não foi possível concluir a operação. Tente novamente.";
}
