/**
 * Hardening Fase 4B — autorização, categoria obrigatória, multiempresa, race.
 * npx tsx src/lib/manufacturer-catalog/phase4b.hardening.assert.ts
 *
 * Live RLS/RPC tests NÃO são executados aqui.
 */

import assert from "node:assert/strict";
import { existsSync, readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  adoptManufacturerProductErrorMessage,
  canAdoptManufacturerProduct,
  draftFromManufacturerProduct,
} from "./adopt";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "../../..");

function run() {
  const migOrig = readFileSync(
    join(root, "supabase/migrations/20260910190000_inventory_adopt_manufacturer_product.sql"),
    "utf8",
  );
  const hardPath = join(
    root,
    "supabase/migrations/20260910193000_adopt_estoque_permission_hardening.sql",
  );
  assert.ok(existsSync(hardPath), "migration incremental de hardening existe");
  const mig = readFileSync(hardPath, "utf8");

  // Originais preservados (não editar 190000)
  assert.ok(/security invoker/i.test(migOrig));
  assert.ok(/on delete set null/i.test(migOrig));
  assert.ok(!/create\s+trigger/i.test(migOrig));

  // 1–4. can_manage_company_estoque + RPC endurecida
  assert.ok(mig.includes("can_manage_company_estoque"));
  assert.ok(mig.includes("can_manage_company_estoque(p_company_id, v_uid)"));
  assert.ok(mig.includes("is_company_member"));
  assert.ok(mig.includes("is_company_admin"));
  assert.ok(mig.includes("manage_estoque"));
  assert.ok(!mig.includes("has_permission(")); // evita bypass de platform admin
  assert.ok(!mig.includes("is_platform_admin"));
  assert.ok(/security invoker/i.test(mig)); // RPC permanece INVOKER
  assert.ok(mig.includes("v_uid, -- owner_id server-side") || mig.includes("v_uid,"));
  assert.ok(!/owner_id\s*:=\s*p_/i.test(mig));
  assert.ok(mig.includes("PRODUTO_INDISPONIVEL"));
  assert.ok(mig.includes("JA_ADOTADO"));
  assert.ok(mig.includes("p_quantidade < 0"));
  assert.ok(mig.includes("p_estoque_minimo < 0"));
  assert.ok(mig.includes("p_custo_unit < 0"));
  assert.ok(mig.includes("p_preco_venda < 0"));
  assert.ok(!/greatest\(coalesce\(p_quantidade/i.test(mig)); // sem clamp de negativo
  assert.ok(mig.includes("Categoria obrigatoria") || mig.includes("p_categoria is null"));
  assert.ok(mig.includes("Unidade obrigatoria") || mig.includes("p_unidade is null"));
  assert.ok(!/\.update\(|\.insert\s+into\s+public\.manufacturer_/i.test(mig));
  assert.ok(!mig.toLowerCase().includes("into public.manufacturer_products"));
  assert.ok(!mig.toLowerCase().includes("into public.product_manufacturers"));
  assert.ok(
    mig.includes("null, -- sem cópia de imagem global") || /imagem_url[\s\S]{0,200}null/.test(mig),
  );
  assert.ok(
    mig.includes("fabricante ≠ fornecedor") ||
      mig.includes("fabricante != fornecedor") ||
      /fornecedor[\s\S]{0,80}null/.test(mig),
  );

  // UI auth: sem bypass de platform admin
  assert.equal(
    canAdoptManufacturerProduct({
      hasActiveCompany: false,
      companyRole: null,
      permissions: { manage_estoque: true },
    }),
    false,
    "platform admin / qualquer um sem empresa ativa não adota",
  );
  assert.equal(
    canAdoptManufacturerProduct({
      hasActiveCompany: true,
      companyRole: "seller",
      permissions: { manage_estoque: false },
    }),
    false,
    "membro sem manage_estoque não adota",
  );
  assert.equal(
    canAdoptManufacturerProduct({
      hasActiveCompany: true,
      companyRole: "seller",
      permissions: { manage_estoque: true },
    }),
    true,
    "membro com manage_estoque pode adotar",
  );
  assert.equal(
    canAdoptManufacturerProduct({
      hasActiveCompany: true,
      companyRole: "owner",
      permissions: { manage_estoque: false },
    }),
    true,
    "owner/admin/manager pode adotar",
  );
  assert.equal(
    canAdoptManufacturerProduct({
      hasActiveCompany: true,
      companyRole: "manager",
      permissions: {},
    }),
    true,
  );

  // Categoria/unidade: sem fallback arbitrário
  const withCat = draftFromManufacturerProduct({
    name: "Puxador",
    description: null,
    source_code: "AL1",
    inventory_category: "ferragem",
    unit: "un",
  });
  assert.equal(withCat.categoria, "ferragem");
  assert.equal(withCat.unidade, "un");

  const noCat = draftFromManufacturerProduct({
    name: "X",
    description: null,
    source_code: "C1",
    inventory_category: null,
    unit: null,
  });
  assert.equal(noCat.categoria, undefined);
  assert.equal(noCat.unidade, undefined);
  assert.ok(!("ncm" in noCat));
  assert.ok(!("supplier_id" in noCat));
  assert.ok(!("cest" in noCat));
  assert.ok(!("gtin" in noCat));

  const badCat = draftFromManufacturerProduct({
    name: "Y",
    description: null,
    source_code: "C2",
    inventory_category: "suggested_not_enum",
    unit: "xyz",
  });
  assert.equal(badCat.categoria, undefined);
  assert.equal(badCat.unidade, undefined);

  // Erros sanitizados
  assert.equal(
    adoptManufacturerProductErrorMessage({ code: "23505", message: "JA_ADOTADO" }),
    "Este produto já foi adicionado ao estoque da empresa.",
  );
  assert.ok(
    !adoptManufacturerProductErrorMessage({ code: "23505", message: "JA_ADOTADO" }).includes(
      "23505",
    ),
  );
  assert.equal(
    adoptManufacturerProductErrorMessage({
      code: "42501",
      message: "Sem permissao de estoque nesta empresa.",
    }),
    "Você não tem permissão para esta operação.",
  );

  // Detail UI: CTA adoção removido; link ao Estoque permanece
  const detail = readFileSync(
    join(root, "src/routes/_authenticated/app.catalogo-fabricantes.$productId.tsx"),
    "utf8",
  );
  assert.ok(!detail.includes("canAdoptManufacturerProduct"));
  assert.ok(!detail.includes("useHasFinePermission"));
  assert.ok(!detail.includes("Adicionar ao estoque"));
  assert.ok(!detail.includes("Já está no estoque"));
  assert.ok(!detail.includes("useAdoptManufacturerProduct"));
  assert.ok(detail.includes("/app/estoque"));
  assert.ok(detail.includes("aparecem automaticamente") || detail.includes("Não é necessário"));

  // Multiempresa: query de adoção escopada a companyId ativo
  const adoptHook = readFileSync(join(root, "src/hooks/use-adopt-manufacturer-product.ts"), "utf8");
  assert.ok(adoptHook.includes('.eq("company_id", companyId)'));
  assert.ok(adoptHook.includes("activeCompany?.companyId"));
  assert.ok(adoptHook.includes('rpc("adopt_manufacturer_product_to_inventory"'));
  assert.ok(!adoptHook.includes("service_role"));
  assert.ok(!adoptHook.includes("p_owner_id"));
  assert.ok(!adoptHook.includes("owner_id:"));

  // Dialog exige seleção quando draft sem categoria
  const dialog = readFileSync(
    join(root, "src/components/inventory/InventoryItemDialog.tsx"),
    "utf8",
  );
  assert.ok(dialog.includes("needsCategoryChoice"));
  assert.ok(dialog.includes("needsUnitChoice"));
  assert.ok(dialog.includes("Selecione uma categoria."));
  assert.ok(dialog.includes("Selecione a categoria"));

  // Thumb hierarquia
  const thumb = readFileSync(join(root, "src/components/inventory/InventoryItemThumb.tsx"), "utf8");
  assert.ok(thumb.includes("imagem_url"));
  assert.ok(thumb.includes("primary_image_path"));
  assert.ok(thumb.includes('bucket="manufacturer-catalog"'));

  // Listagem: sem badge/query de adoção (overlay no Estoque)
  const list = readFileSync(
    join(root, "src/routes/_authenticated/app.catalogo-fabricantes.tsx"),
    "utf8",
  );
  assert.ok(!list.includes("useAdoptedManufacturerProductIds"));
  assert.ok(!list.includes("pageProductIds"));
  assert.ok(!list.includes("No estoque"));
  assert.ok(list.includes("beforeLoad: requireAdmin"));

  // Types
  const types = readFileSync(join(root, "src/integrations/supabase/types.ts"), "utf8");
  assert.ok(types.includes("can_manage_company_estoque"));

  // Nenhuma migration posterior altera manufacturer_products via adopt
  const migDir = join(root, "supabase/migrations");
  for (const f of readdirSync(migDir).filter((n) => n.includes("adopt"))) {
    const src = readFileSync(join(migDir, f), "utf8");
    assert.ok(!/update\s+public\.manufacturer_products/i.test(src));
    assert.ok(!/delete\s+from\s+public\.manufacturer_products/i.test(src));
  }

  console.log("manufacturer-catalog phase4b.hardening.assert: OK");
}

run();
