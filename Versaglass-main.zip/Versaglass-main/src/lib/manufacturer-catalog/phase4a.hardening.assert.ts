/**
 * Hardening Fase 4A — consulta robusta do Catálogo de Fabricantes.
 * npx tsx src/lib/manufacturer-catalog/phase4a.hardening.assert.ts
 */

import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  buildProductSearchOrFilter,
  clampCatalogPage,
  sanitizeCatalogSearchTerm,
} from "./attributes";
import { searchCatalogoFabricantes } from "./search";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "../../..");

function run() {
  // 3–6. Caracteres especiais / curingas
  for (const raw of ["100%", "teste,abc", "teste(abc)", "_", "%", "a*b", "foo.bar"]) {
    const s = sanitizeCatalogSearchTerm(raw);
    assert.ok(!s.includes("%"), `sanitize % em ${raw}`);
    assert.ok(!s.includes(","), `sanitize , em ${raw}`);
    assert.ok(!s.includes("("), `sanitize ( em ${raw}`);
    assert.ok(!s.includes(")"), `sanitize ) em ${raw}`);
    assert.ok(!s.includes("_"), `sanitize _ em ${raw}`);
    assert.ok(!s.includes("*"), `sanitize * em ${raw}`);
  }
  assert.equal(sanitizeCatalogSearchTerm("AL 1629 JB"), "AL 1629 JB");
  assert.equal(sanitizeCatalogSearchTerm("puxador"), "puxador");
  assert.equal(sanitizeCatalogSearchTerm("%"), "");
  assert.equal(sanitizeCatalogSearchTerm("___"), "");

  // 7. fabricante sem correspondência → sem .in.()
  const onlyFields = buildProductSearchOrFilter("puxador", []);
  assert.ok(onlyFields);
  assert.ok(!onlyFields!.includes(".in.("));
  assert.ok(onlyFields!.includes("name.ilike.%puxador%"));

  const withMfg = buildProductSearchOrFilter("AL", [
    "11111111-1111-1111-1111-111111111111",
    "not-a-uuid",
  ]);
  assert.ok(withMfg!.includes("manufacturer_id.in.(11111111-1111-1111-1111-111111111111)"));
  assert.ok(!withMfg!.includes("not-a-uuid"));

  assert.equal(buildProductSearchOrFilter("%", ["11111111-1111-1111-1111-111111111111"]), null);
  assert.equal(buildProductSearchOrFilter("   ", []), null);

  // 8. alteração de filtro → page omitida (=1) quando page=1
  const reset = searchCatalogoFabricantes({
    q: "novo",
    fabricante: "11111111-1111-1111-1111-111111111111",
    page: 1,
  });
  assert.equal(reset.page, undefined);
  assert.equal(reset.q, "novo");

  // patchSearch na UI passa page:1 por padrão ao mudar filtros (verificado no fonte)
  const listSrc = readFileSync(
    join(root, "src/routes/_authenticated/app.catalogo-fabricantes.tsx"),
    "utf8",
  );
  assert.ok(listSrc.includes("page: patch.page !== undefined ? patch.page : 1"));
  assert.ok(listSrc.includes("clampCatalogPage"));

  // 9. page fora do intervalo
  assert.equal(clampCatalogPage(999, 50, 24), 3);
  assert.equal(clampCatalogPage(2, 50, 24), 2);
  assert.equal(clampCatalogPage(0, 50, 24), 1);
  assert.equal(clampCatalogPage(5, 0, 24), 1);

  // 1–2. Linhas via RPC DISTINCT; fabricantes paginados (sem limit único truncador)
  const hookSrc = readFileSync(join(root, "src/hooks/use-manufacturer-catalog.ts"), "utf8");
  assert.ok(hookSrc.includes('rpc("list_manufacturer_product_lines"'));
  assert.ok(!hookSrc.includes(".limit(1000)"));
  assert.ok(hookSrc.includes("fetchAllActiveManufacturers") || hookSrc.includes("range(from"));
  assert.ok(hookSrc.includes("buildProductSearchOrFilter"));
  assert.ok(!/\.insert\(|\.update\(|\.delete\(|\.upsert\(/.test(hookSrc));
  assert.ok(!hookSrc.includes('.from("inventory_items")'));

  // 10–11. Detalhe exige active produto + fabricante
  assert.ok(hookSrc.includes("useManufacturerCatalogProduct"));
  const detailBlock = hookSrc.slice(hookSrc.indexOf("useManufacturerCatalogProduct"));
  assert.ok(detailBlock.includes('.eq("active", true)'));
  assert.ok(detailBlock.includes("product_manufacturers.active"));
  assert.ok(detailBlock.includes("!mfg.active"));

  // Migration RPC
  const mig = readFileSync(
    join(root, "supabase/migrations/20260910180000_manufacturer_catalog_distinct_lines.sql"),
    "utf8",
  );
  assert.ok(mig.includes("list_manufacturer_product_lines"));
  assert.ok(mig.includes("security invoker"));
  assert.ok(mig.includes("distinct"));
  assert.ok(mig.includes("mp.active = true"));
  assert.ok(mig.includes("pm.active = true"));

  console.log("manufacturer-catalog phase4a.hardening.assert: OK");
}

run();
