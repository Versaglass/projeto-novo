/**
 * Asserções Fase 5 — RLS inventory_items alinhada a manage_estoque.
 * npx tsx src/lib/manufacturer-catalog/phase5.assert.ts
 */

import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { canManageCompanyEstoque } from "../inventory-auth";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "../../..");

function run() {
  const migPath = join(
    root,
    "supabase/migrations/20260910200000_inventory_items_rls_manage_estoque.sql",
  );
  assert.ok(existsSync(migPath), "migration Fase 5 existe");
  const mig = readFileSync(migPath, "utf8");

  assert.ok(mig.includes("can_manage_company_estoque"));
  assert.ok(mig.includes("inventory_insert_company"));
  assert.ok(mig.includes("inventory_update_company"));
  assert.ok(mig.includes("inventory_delete_company"));
  assert.ok(!mig.includes("has_permission"));
  assert.ok(!mig.includes("is_platform_admin"));
  // INSERT: owner_id + can_manage
  assert.ok(/owner_id\s*=\s*auth\.uid\(\)/.test(mig));
  assert.ok(/with check[\s\S]*can_manage_company_estoque/i.test(mig));
  // UPDATE/DELETE usam can_manage (não só creator)
  assert.ok(mig.includes("using (public.can_manage_company_estoque"));
  // SELECT não é recriado neste arquivo (permanece membership)
  assert.ok(!mig.includes("inventory_select_company"));

  // UI auth helper
  assert.equal(
    canManageCompanyEstoque({
      hasActiveCompany: false,
      companyRole: "owner",
      permissions: { manage_estoque: true },
    }),
    false,
  );
  assert.equal(
    canManageCompanyEstoque({
      hasActiveCompany: true,
      companyRole: "seller",
      permissions: { manage_estoque: false },
    }),
    false,
  );
  assert.equal(
    canManageCompanyEstoque({
      hasActiveCompany: true,
      companyRole: "seller",
      permissions: { manage_estoque: true },
    }),
    true,
  );
  assert.equal(
    canManageCompanyEstoque({
      hasActiveCompany: true,
      companyRole: "manager",
      permissions: {},
    }),
    true,
  );

  // Docs
  assert.ok(existsSync(join(root, "docs/IMPORTACAO_CATALOGOS_IA.md")));

  // Dialog não reexporta helpers (react-refresh)
  const dialog = readFileSync(
    join(root, "src/components/inventory/InventoryItemDialog.tsx"),
    "utf8",
  );
  assert.ok(!dialog.includes("export function inventoryFormToInput"));
  assert.ok(!dialog.includes("export type InventoryItemForm"));
  assert.ok(existsSync(join(root, "src/components/inventory/inventory-item-form.ts")));

  // Entry points de escrita usam canManageCompanyEstoque
  const estoque = readFileSync(join(root, "src/routes/_authenticated/app.estoque.tsx"), "utf8");
  assert.ok(estoque.includes("canManageCompanyEstoque"));
  const alum = readFileSync(join(root, "src/components/AluminumCatalog.tsx"), "utf8");
  assert.ok(alum.includes("canManageCompanyEstoque"));
  const projetos = readFileSync(join(root, "src/routes/_authenticated/app.projetos.tsx"), "utf8");
  assert.ok(projetos.includes("canManageCompanyEstoque"));

  console.log("manufacturer-catalog phase5.assert: OK");
}

run();
