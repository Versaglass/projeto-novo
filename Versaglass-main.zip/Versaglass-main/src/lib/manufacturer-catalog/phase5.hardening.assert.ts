/**
 * Hardening Fase 5 — RLS estoque + ausência de bypass platform admin.
 * npx tsx src/lib/manufacturer-catalog/phase5.hardening.assert.ts
 */

import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "../../..");

function run() {
  const mig = readFileSync(
    join(root, "supabase/migrations/20260910200000_inventory_items_rls_manage_estoque.sql"),
    "utf8",
  );

  // Não edita migrations anteriores
  assert.ok(!mig.includes("20260910190000"));
  assert.ok(mig.includes('drop policy if exists "inventory_insert_company"'));
  assert.ok(mig.includes('drop policy if exists "inventory_update_company"'));
  assert.ok(mig.includes('drop policy if exists "inventory_delete_company"'));

  // Sem ampliar SELECT
  assert.ok(!mig.toLowerCase().includes('create policy "inventory_select'));

  // Sales DEFINER não tocados nesta migration
  assert.ok(!mig.toLowerCase().includes("create_sale"));
  assert.ok(!mig.toLowerCase().includes("cancel_sale"));

  const auth = readFileSync(join(root, "src/lib/inventory-auth.ts"), "utf8");
  assert.ok(!auth.includes("isPlatformAdmin"));
  assert.ok(!auth.includes("isAdmin"));
  assert.ok(auth.includes("manage_estoque"));

  // Migrations da feature não foram editadas retroativamente (conteúdo mínimo esperado)
  for (const f of [
    "20260910120000",
    "20260910140000",
    "20260910150000",
    "20260910160000",
    "20260910170000",
    "20260910180000",
    "20260910190000",
    "20260910193000",
  ]) {
    const matches = readdirSync(join(root, "supabase/migrations")).filter((n) => n.startsWith(f));
    assert.equal(matches.length, 1, `migration ${f} única`);
  }

  console.log("manufacturer-catalog phase5.hardening.assert: OK");
}

run();
