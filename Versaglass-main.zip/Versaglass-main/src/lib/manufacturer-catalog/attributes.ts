/**
 * Formatação legível de attributes / observations do catálogo de fabricantes.
 * Estruturas flexíveis (JSONB) — nunca quebrar a página.
 */

export type AttributeDisplayRow = {
  label: string;
  value: string;
};

function isPlainObject(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

function formatPrimitive(v: unknown): string {
  if (v === null || v === undefined) return "";
  if (typeof v === "boolean") return v ? "Sim" : "Não";
  if (typeof v === "number" && Number.isFinite(v)) return String(v);
  if (typeof v === "string") return v.trim();
  return "";
}

function formatValueWithOptionalUnit(value: unknown, unit: unknown): string {
  const base = formatPrimitive(value);
  const u = formatPrimitive(unit);
  if (!base) return u;
  if (!u) return base;
  return `${base} ${u}`;
}

function formatArrayValue(arr: unknown[]): string {
  const parts = arr
    .map((item) => {
      if (isPlainObject(item)) {
        const name = formatPrimitive(item.name ?? item.label ?? item.key);
        const val = formatValueWithOptionalUnit(
          item.value ?? item.val ?? item.text,
          item.unit ?? item.unidade,
        );
        if (name && val) return `${name}: ${val}`;
        return name || val || formatPrimitive(item);
      }
      return formatPrimitive(item);
    })
    .filter(Boolean);
  return parts.join(", ");
}

/**
 * Converte JSONB `attributes` em linhas label/value para UI.
 * Aceita array de objetos, objeto plano, ou formatos inesperados (fallback seguro).
 */
export function formatManufacturerAttributes(raw: unknown): AttributeDisplayRow[] {
  try {
    if (raw == null) return [];

    if (Array.isArray(raw)) {
      const rows: AttributeDisplayRow[] = [];
      for (const item of raw) {
        if (typeof item === "string" || typeof item === "number" || typeof item === "boolean") {
          const v = formatPrimitive(item);
          if (v) rows.push({ label: "Atributo", value: v });
          continue;
        }
        if (!isPlainObject(item)) continue;
        const label =
          formatPrimitive(item.name) ||
          formatPrimitive(item.label) ||
          formatPrimitive(item.key) ||
          formatPrimitive(item.titulo) ||
          "Atributo";
        let value = "";
        if (Array.isArray(item.value)) {
          value = formatArrayValue(item.value);
        } else if (
          item.value !== undefined ||
          item.unit !== undefined ||
          item.unidade !== undefined
        ) {
          value = formatValueWithOptionalUnit(item.value, item.unit ?? item.unidade);
        } else if (Array.isArray(item.values)) {
          value = formatArrayValue(item.values);
        } else {
          // objeto sem value tipado — tenta campos comuns
          value =
            formatPrimitive(item.text) ||
            formatPrimitive(item.descricao) ||
            formatArrayValue(
              Object.entries(item)
                .filter(([k]) => !["name", "label", "key", "titulo"].includes(k))
                .map(([, v]) => v),
            );
        }
        if (label && value) rows.push({ label, value });
      }
      return rows;
    }

    if (isPlainObject(raw)) {
      return Object.entries(raw)
        .map(([key, val]) => {
          let value = "";
          if (Array.isArray(val)) value = formatArrayValue(val);
          else if (isPlainObject(val)) {
            value = formatValueWithOptionalUnit(val.value ?? val.val, val.unit ?? val.unidade);
            if (!value) value = formatPrimitive(val);
          } else value = formatPrimitive(val);
          return { label: key, value };
        })
        .filter((r) => r.label && r.value);
    }

    const single = formatPrimitive(raw);
    return single ? [{ label: "Atributo", value: single }] : [];
  } catch {
    return [];
  }
}

/** Observations JSONB → lista de strings legíveis. */
export function formatManufacturerObservations(raw: unknown): string[] {
  try {
    if (raw == null) return [];
    if (typeof raw === "string") {
      const t = raw.trim();
      return t ? [t] : [];
    }
    if (Array.isArray(raw)) {
      return raw
        .map((item) => {
          if (typeof item === "string") return item.trim();
          if (typeof item === "number" || typeof item === "boolean") return formatPrimitive(item);
          if (isPlainObject(item)) {
            return (
              formatPrimitive(item.text) ||
              formatPrimitive(item.observation) ||
              formatPrimitive(item.observacao) ||
              formatPrimitive(item.message) ||
              formatPrimitive(item.value) ||
              ""
            );
          }
          return "";
        })
        .filter(Boolean);
    }
    if (isPlainObject(raw)) {
      const v =
        formatPrimitive(raw.text) ||
        formatPrimitive(raw.observation) ||
        formatPrimitive(raw.message);
      return v ? [v] : [];
    }
    return [];
  } catch {
    return [];
  }
}

export function sanitizeCatalogSearchTerm(raw: string): string {
  // Remove metacharacters PostgREST (or/filters) e curingas ILIKE.
  return raw
    .replace(/[,.()%*_\\]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 120);
}

/** Monta filtro `.or(...)` seguro. Retorna null se o termo ficar vazio. Nunca gera `.in.()`. */
export function buildProductSearchOrFilter(
  rawTerm: string,
  manufacturerIds: string[],
): string | null {
  const term = sanitizeCatalogSearchTerm(rawTerm);
  if (!term) return null;

  const parts = [
    `name.ilike.%${term}%`,
    `source_code.ilike.%${term}%`,
    `base_code.ilike.%${term}%`,
  ];

  const ids = manufacturerIds.filter((id) =>
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id),
  );
  if (ids.length > 0) {
    parts.push(`manufacturer_id.in.(${ids.join(",")})`);
  }

  return parts.join(",");
}

/** Normaliza page quando total conhecido — evita página vazia artificial. */
export function clampCatalogPage(page: number, total: number, pageSize = 24): number {
  const p = parseCatalogPage(page);
  if (total <= 0) return 1;
  const pageCount = Math.max(1, Math.ceil(total / pageSize));
  return Math.min(p, pageCount);
}

export type CatalogSort = "nome_asc" | "nome_desc" | "recentes";

export function parseCatalogSort(raw: unknown): CatalogSort {
  if (raw === "nome_desc" || raw === "recentes") return raw;
  return "nome_asc";
}

export function parseCatalogPage(raw: unknown): number {
  const n = typeof raw === "number" ? raw : typeof raw === "string" ? Number(raw) : 1;
  if (!Number.isFinite(n) || n < 1) return 1;
  return Math.min(Math.floor(n), 10_000);
}

export const MANUFACTURER_CATALOG_PAGE_SIZE = 24;

/** Fase 4A é somente leitura — asserts verificam ausência de mutações. */
export const PHASE4A_READ_ONLY = true as const;
