export type Segment = "vidracaria" | "serralheria" | "marcenaria" | "marmoraria" | "completo";

export type ModuleKey =
  | "vidros"
  | "aluminios"
  | "ferragens_vidro"
  | "serralheria"
  | "aco_metalon"
  | "mdf"
  | "ferragens_moveis"
  | "marmores"
  | "quartzos"
  | "porcelanatos";

export type ModuleInfo = {
  key: ModuleKey;
  label: string;
  description: string;
  segment: Segment;
  upgradePlan: string;
};

export const MODULES: Record<ModuleKey, ModuleInfo> = {
  vidros: {
    key: "vidros",
    label: "Vidros",
    description: "Vidros comuns, temperados, laminados, espelhos e chapas.",
    segment: "vidracaria",
    upgradePlan: "Plano Vidraçaria",
  },
  aluminios: {
    key: "aluminios",
    label: "Alumínios",
    description: "Catálogo técnico de perfis, tubos, cantoneiras, barras e acessórios.",
    segment: "vidracaria",
    upgradePlan: "Plano Vidraçaria",
  },
  ferragens_vidro: {
    key: "ferragens_vidro",
    label: "Ferragens para vidro",
    description: "Dobradiças, puxadores, roldanas, fechaduras, molas e acessórios.",
    segment: "vidracaria",
    upgradePlan: "Plano Vidraçaria",
  },
  serralheria: {
    key: "serralheria",
    label: "Serralheria",
    description: "Portões, grades, galpões, estruturas e móveis industriais.",
    segment: "serralheria",
    upgradePlan: "Plano Serralheria",
  },
  aco_metalon: {
    key: "aco_metalon",
    label: "Aço e Metalon",
    description: "Tubos, barras, chapas, perfis e insumos de aço.",
    segment: "serralheria",
    upgradePlan: "Plano Serralheria",
  },
  mdf: {
    key: "mdf",
    label: "MDF e chapas",
    description: "Chapas, fitas de borda, medidas, cores e planos de corte.",
    segment: "marcenaria",
    upgradePlan: "Plano Marcenaria",
  },
  ferragens_moveis: {
    key: "ferragens_moveis",
    label: "Ferragens para móveis",
    description: "Dobradiças, corrediças, puxadores, trilhos, pés e acessórios.",
    segment: "marcenaria",
    upgradePlan: "Plano Marcenaria",
  },
  marmores: {
    key: "marmores",
    label: "Mármores e granitos",
    description: "Bancadas, soleiras, nichos, cubas, recortes e acabamentos.",
    segment: "marmoraria",
    upgradePlan: "Plano Marmoraria",
  },
  quartzos: {
    key: "quartzos",
    label: "Quartzos",
    description: "Superfícies, bancadas, acabamentos e tabelas de custo.",
    segment: "marmoraria",
    upgradePlan: "Plano Marmoraria",
  },
  porcelanatos: {
    key: "porcelanatos",
    label: "Porcelanatos",
    description: "Chapas, cortes, cubas esculpidas e marmoraria em porcelanato.",
    segment: "marmoraria",
    upgradePlan: "Plano Marmoraria",
  },
};

export const PLAN_ACCESS: Record<Segment, ModuleKey[]> = {
  vidracaria: ["vidros", "aluminios", "ferragens_vidro"],
  serralheria: ["serralheria", "aco_metalon"],
  marcenaria: ["mdf", "ferragens_moveis"],
  marmoraria: ["marmores", "quartzos", "porcelanatos"],
  completo: [
    "vidros",
    "aluminios",
    "ferragens_vidro",
    "serralheria",
    "aco_metalon",
    "mdf",
    "ferragens_moveis",
    "marmores",
    "quartzos",
    "porcelanatos",
  ],
};

export function hasModuleAccess(plan: Segment | string | undefined, module: ModuleKey) {
  // Entitlement de plano da EMPRESA — independente de `user_roles.admin`.
  // Super Admin de plataforma NÃO libera módulos tenant fora do plano.
  const safePlan = (plan || "vidracaria") as Segment;
  return (PLAN_ACCESS[safePlan] || PLAN_ACCESS.vidracaria).includes(module);
}

export function getPlanFromStorage(): Segment {
  if (typeof window === "undefined") return "vidracaria";
  const saved = window.localStorage.getItem("vmm_company_plan") as Segment | null;
  if (saved && PLAN_ACCESS[saved]) return saved;
  return "vidracaria";
}

export function setPlanInStorage(plan: Segment) {
  if (typeof window !== "undefined") window.localStorage.setItem("vmm_company_plan", plan);
}
