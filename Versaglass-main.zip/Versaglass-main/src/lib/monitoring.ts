type MonitorPayload = {
  name: string;
  value?: number | string;
  metadata?: Record<string, unknown>;
};

export function trackEvent(name: string, metadata?: Record<string, unknown>) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(
    new CustomEvent("versaglass:event", {
      detail: { name, metadata, at: new Date().toISOString() },
    }),
  );
  const gtag = (window as unknown as { gtag?: (...args: unknown[]) => void }).gtag;
  gtag?.("event", name, metadata ?? {});
}

export function trackMetric(payload: MonitorPayload) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(
    new CustomEvent("versaglass:metric", { detail: { ...payload, at: new Date().toISOString() } }),
  );
}

export function startFrontendMonitoring() {
  if (typeof window === "undefined") return;
  window.addEventListener("error", (event) => {
    trackEvent("frontend_error", {
      message: event.message,
      source: event.filename,
      line: event.lineno,
    });
  });
  window.addEventListener("unhandledrejection", (event) => {
    trackEvent("unhandled_rejection", { reason: String(event.reason) });
  });
  window.addEventListener(
    "load",
    () => {
      const nav = performance.getEntriesByType("navigation")[0] as
        | PerformanceNavigationTiming
        | undefined;
      if (nav)
        trackMetric({ name: "page_load_ms", value: Math.round(nav.loadEventEnd - nav.startTime) });
    },
    { once: true },
  );
}
