/**
 * CPF — validação de formato E de dígito verificador (módulo 11).
 *
 * ────────────────────────────────────────────────────────────────────────────
 * ALGORITMO
 * ────────────────────────────────────────────────────────────────────────────
 * O CPF tem **11 dígitos**: 9 de base + 2 verificadores. Cada DV é módulo 11:
 *
 *   · 1º DV — pesos `[10,9,8,7,6,5,4,3,2]` sobre os 9 primeiros;
 *   · 2º DV — pesos `[11,10,9,8,7,6,5,4,3,2]` sobre os 9 + o 1º DV;
 *   · resto `< 2` → dígito `0`, senão `11 − resto`.
 *
 * Diferente do CNPJ (`src/lib/cnpj.ts`), o CPF **não** aceita letras — só
 * dígitos — e a Receita não publica um pacote TypeScript de referência no
 * mesmo molde do CNPJ alfanumérico. A conta é a regra pública de módulo 11
 * usada há décadas em cadastros brasileiros.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * CONVENÇÕES (espelham `validarCnpj`)
 * ────────────────────────────────────────────────────────────────────────────
 * · Campo **opcional** por padrão — vazio é ausência legítima.
 * · Máscara (`.` `-`) e espaços são removidos antes de validar.
 * · Sequências com todos os dígitos iguais (`000…`, `111…`, …) são
 *   recusadas — fecham o DV em alguns casos e não são CPF de pessoa.
 * · Mensagens em português, dizendo o que corrigir.
 */

/** Pontuação da máscara e espaços — descartados antes de validar. */
const REGEX_MASCARA = /[.\-\s]/g;
/** Qualquer coisa fora de dígito, máscara ou espaço reprova de saída. */
const REGEX_CARACTERE_PROIBIDO = /[^\d.\-\s]/;

const CPF_ZERADO = "00000000000";

/** Tira máscara e espaços. Não valida nada. */
export function normalizarCpf(bruto: unknown): string {
  return String(bruto ?? "")
    .trim()
    .replace(REGEX_MASCARA, "");
}

/**
 * Calcula os dois dígitos verificadores dos 9 primeiros dígitos.
 * Devolve `null` se a base não tiver exatamente 9 dígitos.
 */
export function calcularDvCpf(base: string): string | null {
  const b = normalizarCpf(base);
  if (!/^\d{9}$/.test(b)) return null;

  let soma1 = 0;
  for (let i = 0; i < 9; i++) soma1 += Number(b[i]) * (10 - i);
  const resto1 = soma1 % 11;
  const dv1 = resto1 < 2 ? 0 : 11 - resto1;

  let soma2 = 0;
  for (let i = 0; i < 9; i++) soma2 += Number(b[i]) * (11 - i);
  soma2 += dv1 * 2;
  const resto2 = soma2 % 11;
  const dv2 = resto2 < 2 ? 0 : 11 - resto2;

  return `${dv1}${dv2}`;
}

/** `true` só para CPF completo e com DV correto. Sem tolerância. */
export function cpfEhValido(bruto: unknown): boolean {
  const c = normalizarCpf(bruto);
  if (!/^\d{11}$/.test(c) || /^(\d)\1{10}$/.test(c)) return false;
  return calcularDvCpf(c.substring(0, 9)) === c.substring(9);
}

/** Aplica a máscara `XXX.XXX.XXX-XX`. Fora de 11 dígitos, devolve o trim. */
export function formatarCpf(bruto: unknown): string {
  const c = normalizarCpf(bruto);
  if (c.length !== 11) return String(bruto ?? "").trim();
  return `${c.slice(0, 3)}.${c.slice(3, 6)}.${c.slice(6, 9)}-${c.slice(9)}`;
}

export type CpfValidado =
  | { ok: true; /** 11 dígitos, sem máscara. */ cpf: string; formatado: string }
  | { ok: false; erro: string };

/**
 * Valida um CPF digitado e devolve o valor canônico ou a razão da recusa.
 *
 * `obrigatorio: false` (o padrão) trata campo vazio como ausência legítima —
 * é assim que o cadastro de cliente trata o documento hoje.
 */
export function validarCpf(bruto: unknown, opcoes?: { obrigatorio?: boolean }): CpfValidado {
  const original = String(bruto ?? "").trim();
  const obrigatorio = opcoes?.obrigatorio ?? false;

  if (!original) {
    return obrigatorio
      ? { ok: false, erro: "Informe o CPF do cliente." }
      : { ok: true, cpf: "", formatado: "" };
  }

  if (REGEX_CARACTERE_PROIBIDO.test(original)) {
    return {
      ok: false,
      erro: `O CPF tem caractere que não existe neste documento ("${original}"). Use apenas números e a pontuação . -`,
    };
  }

  const c = normalizarCpf(original);

  if (c.length !== 11) {
    return {
      ok: false,
      erro: `O CPF precisa ter 11 dígitos — 9 mais os 2 dígitos verificadores. Você digitou ${c.length}.`,
    };
  }

  if (!/^\d{11}$/.test(c)) {
    return { ok: false, erro: "O CPF aceita apenas números." };
  }

  if (c === CPF_ZERADO || /^(\d)\1{10}$/.test(c)) {
    return { ok: false, erro: "CPF com todos os dígitos iguais não é um documento válido." };
  }

  const dvEsperado = calcularDvCpf(c.slice(0, 9));
  if (dvEsperado === null) {
    return { ok: false, erro: "CPF inválido." };
  }
  if (dvEsperado !== c.slice(9)) {
    return {
      ok: false,
      erro: `CPF inválido: os dígitos verificadores não conferem. Para os 9 primeiros dígitos digitados, o final correto seria "${dvEsperado}" — confira o número.`,
    };
  }

  return { ok: true, cpf: c, formatado: formatarCpf(c) };
}
