/**
 * Claim atômico awaiting_upload → processing.
 * Equivalente a UPDATE ... WHERE status = 'awaiting_upload' RETURNING *.
 */

import type { SupabaseClient } from "@supabase/supabase-js";
import { CatalogImportErrors, errorForUnclaimableJobStatus } from "./errors";

export type ClaimedCatalogImportJob = {
  id: string;
  status: string;
  storage_path: string;
  storage_bucket: string;
  original_filename: string;
  declared_size_bytes: number;
  [key: string]: unknown;
};

/**
 * Somente uma execução obtém a linha. Demais recebem erro conforme status atual.
 */
export async function claimCatalogImportJob(
  admin: SupabaseClient,
  jobId: string,
): Promise<ClaimedCatalogImportJob> {
  const { data: claimed, error } = await admin
    .from("catalog_import_jobs")
    .update({
      status: "processing",
      error_message: null,
      error_code: null,
    })
    .eq("id", jobId)
    .eq("status", "awaiting_upload")
    .select("*")
    .maybeSingle();

  if (error) throw CatalogImportErrors.processingFailed();
  if (claimed) return claimed as ClaimedCatalogImportJob;

  const { data: existing, error: selErr } = await admin
    .from("catalog_import_jobs")
    .select("id, status")
    .eq("id", jobId)
    .maybeSingle();

  if (selErr) throw CatalogImportErrors.processingFailed();
  if (!existing) throw CatalogImportErrors.jobNotFound();
  throw errorForUnclaimableJobStatus(existing.status as string);
}

/** Simula dois claims sequenciais no mesmo status (teste offline da regra). */
export function simulateExclusiveClaim(
  currentStatus: string,
): { ok: true; next: "processing" } | { ok: false; reason: string } {
  if (currentStatus === "awaiting_upload") return { ok: true, next: "processing" };
  return { ok: false, reason: currentStatus };
}
