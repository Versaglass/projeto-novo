# Regras do importador VersaGlass — Catalog Import v1

Este documento descreve como o **VersaGlass** tratará o ZIP gerado pela IA.
A IA deve produzir o pacote; a validação e a persistência ficam no VersaGlass.

## Contrato

- Nome: **VersaGlass Catalog Import**
- Versão: **1.0** (`schema_version = "1.0"`)
- Schema: `versaglass-catalog-import-v1.schema.json`
- Exemplo: `example-manifest.json`

## Limites deste ambiente (v1)

| Limite | Valor | Nota |
|--------|------:|------|
| ZIP compactado | **50 MiB** | Infra/Storage (`config.toml`); UI: “50 MB” |
| Entradas no ZIP | 2.500 | Defesa estrutural |
| Itens no manifesto | **1.000** | Contrato schema + runtime |
| Imagem individual | 5 MiB | JPEG/PNG/WebP |
| `technical_images` / item | 20 | Schema + runtime |
| Total descompactado | **250 MiB** | ZIP bomb — **não** reduzido ao teto do ZIP |
| Colisão de path / case | rejeição global | `images/A.png` vs `images/a.png` inválido |

O limite de 50 MiB do ZIP é de infraestrutura/configuração, **não** do formato lógico do catálogo. A arquitetura permite aumentar no futuro se o Storage do projeto for reconfigurado (constante centralizada + bucket + `config.toml`).

Paths no ZIP são normalizados de forma canônica (`\`, `//`, `./`). Entradas especiais (symlink), ZIP com senha e nomes duplicados/ambíguos são rejeitados.

## O que o VersaGlass fará (visão)

1. Receber `catalogo-versaglass.zip` (somente Super Admin de plataforma).
2. Validar estrutura do ZIP e o `manifest.json` em runtime.
3. Exibir prévia (válidos, duplicados, revisão, erros).
4. Persistir no **catálogo global de fabricantes** (`product_manufacturers` +
   `manufacturer_products`), **não** no estoque da empresa (`inventory_items`).

## Identidade e duplicidade

- Fabricante: `catalog.manufacturer` → entidade global `product_manufacturers`.
- Produto: chave lógica **fabricante + código original normalizado**.
- A normalização é **determinística e feita pelo VersaGlass**, não pela IA.
- A IA deve enviar `source_code` fiel ao catálogo; não inventar `normalized_*`.

## Categorias

- `suggested_category` = sugestão textual da IA.
- O Super Admin mapeia para o enum interno `inventory_category` na revisão.
- Não criar categorias novas dinamicamente.

## Imagens

- Caminhos relativos sob `images/` apenas.
- Sem URLs externas, sem path traversal (`..`), sem arquivos fora de `images/`.
- Extensões esperadas: `.png`, `.jpg`, `.jpeg`, `.webp`.

## Dados comerciais

O importador **rejeita** campos comerciais se aparecerem. O catálogo global
não armazena estoque, preços, NCM, GTIN nem fornecedor.

## Fora do escopo da IA

- Não ler ou escrever no banco VersaGlass.
- Não chamar APIs do VersaGlass.
- Não incluir credenciais no ZIP.
