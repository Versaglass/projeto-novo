/**
 * Espelha a regra de `requireAdmin` / `useAuth().isAdmin` para asserções.
 * Company admin (`company_members`) NÃO é Super Admin.
 */
export function isPlatformAdminRole(roles: readonly string[]): boolean {
  return roles.some((r) => r === "admin");
}

/** Matriz Fase 1 — quem pode acessar /app/admin/importar-catalogo e o Kit. */
export const CATALOG_IMPORT_ACCESS_MATRIX = [
  { label: "platform_admin", roles: ["admin"] as const, allowed: true },
  { label: "platform_admin_multi", roles: ["admin", "vendedor"] as const, allowed: true },
  { label: "vendedor", roles: ["vendedor"] as const, allowed: false },
  { label: "instalador", roles: ["instalador"] as const, allowed: false },
  { label: "sem_role_plataforma", roles: [] as const, allowed: false },
  /**
   * Admin da EMPRESA não aparece em user_roles como 'admin'.
   * Simula ausência de papel de plataforma.
   */
  { label: "company_admin_sem_plataforma", roles: [] as const, allowed: false },
] as const;
