/**
 * Asserções Fase 3 — revisão / publicação (offline).
 * npx tsx src/lib/catalog-import/phase3.assert.ts
 */

import assert from "node:assert/strict";
import { simulateExclusivePublishClaim } from "./claim-publish";
import { CatalogImportErrors, errorForUnclaimableJobStatus } from "./errors";
import { normalizeManufacturerName, normalizeSourceCode } from "./normalize";
import {
  assertDecisionAllowed,
  buildFinalPrimaryImagePath,
  buildFinalTechnicalImagePath,
  canApproveItem,
  canEnablePublish,
  canRejectItem,
  countApproved,
  hasPendingPublishableItems,
  isEligibleForApproveAll,
  isManufacturerResolved,
} from "./review";

function run() {
  // 1–5 decisions
  assert.equal(canApproveItem("valid"), true);
  assert.equal(canApproveItem("review"), true);
  assert.equal(canApproveItem("duplicate"), false);
  assert.equal(canApproveItem("invalid"), false);
  assert.equal(canRejectItem("invalid"), true);
  assert.equal(canRejectItem("duplicate"), false);

  assert.doesNotThrow(() => assertDecisionAllowed("valid", "approved"));
  assert.doesNotThrow(() => assertDecisionAllowed("review", "approved"));
  assert.throws(() => assertDecisionAllowed("duplicate", "approved"));
  assert.throws(() => assertDecisionAllowed("invalid", "approved"));
  assert.doesNotThrow(() => assertDecisionAllowed("invalid", "rejected"));

  // 6–7 approve-all
  assert.equal(
    isEligibleForApproveAll({ validationStatus: "valid", reviewDecision: "pending" }),
    true,
  );
  assert.equal(
    isEligibleForApproveAll({ validationStatus: "review", reviewDecision: "pending" }),
    false,
  );
  assert.equal(
    isEligibleForApproveAll({ validationStatus: "valid", reviewDecision: "approved" }),
    false,
  );

  // 8 renormalize
  assert.equal(normalizeSourceCode("AL-1629/JB"), "al 1629 jb");
  assert.equal(normalizeManufacturerName("AL  Indústria"), "al industria");

  // 11–12 category/unit preservation conceptually — paths (sem manufacturerId)
  const p = buildFinalPrimaryImagePath("prod", "png");
  assert.equal(p, "products/prod/primary.png");
  assert.ok(!p.includes("AL"));
  assert.ok(!p.startsWith("mfg/"));
  assert.equal(
    buildFinalTechnicalImagePath("prod", "img1", "jpg"),
    "products/prod/technical/img1.jpg",
  );

  // 14–15 manufacturer resolved
  assert.equal(isManufacturerResolved("id", null, null, null), true);
  assert.equal(isManufacturerResolved(null, "Novo", null, null), true);
  assert.equal(isManufacturerResolved(null, null, "exist", null), true);
  assert.equal(isManufacturerResolved(null, null, null, "Nome"), true);
  assert.equal(isManufacturerResolved(null, null, null, null), false);

  // 17–20 publish gate + claim
  const itemsOk = [
    { validationStatus: "valid" as const, reviewDecision: "approved" as const },
    { validationStatus: "duplicate" as const, reviewDecision: "pending" as const },
  ];
  assert.equal(
    canEnablePublish({
      jobStatus: "ready",
      manufacturerResolved: true,
      items: itemsOk,
    }),
    true,
  );
  assert.equal(
    canEnablePublish({
      jobStatus: "ready",
      manufacturerResolved: true,
      items: [{ validationStatus: "valid", reviewDecision: "pending" }],
    }),
    false,
  );
  assert.equal(
    canEnablePublish({
      jobStatus: "ready",
      manufacturerResolved: true,
      items: [{ validationStatus: "valid", reviewDecision: "rejected" }],
    }),
    false,
  ); // zero approved
  assert.equal(
    canEnablePublish({
      jobStatus: "completed",
      manufacturerResolved: true,
      items: itemsOk,
    }),
    false,
  );

  assert.deepEqual(simulateExclusivePublishClaim("ready"), { ok: true, next: "publishing" });
  assert.equal(simulateExclusivePublishClaim("publishing").ok, false);
  assert.equal(simulateExclusivePublishClaim("completed").ok, false);
  assert.equal(errorForUnclaimableJobStatus("publishing").code, "already_publishing");
  assert.equal(errorForUnclaimableJobStatus("completed").code, "already_completed");

  let st = "ready";
  const c1 = simulateExclusivePublishClaim(st);
  assert.equal(c1.ok, true);
  st = c1.ok ? c1.next : st;
  assert.equal(simulateExclusivePublishClaim(st).ok, false);

  // 23–26 only approved published conceptually
  assert.equal(countApproved(itemsOk), 1);
  assert.equal(
    hasPendingPublishableItems([{ validationStatus: "review", reviewDecision: "pending" }]),
    true,
  );

  // 40 zero approved rejected
  assert.equal(CatalogImportErrors.publishNotReady().code, "publish_not_ready");

  // commercial fields not in final path builder
  assert.ok(!buildFinalPrimaryImagePath("b", "png").includes("preco"));

  console.log("catalog-import phase3.assert: OK");
}

run();
