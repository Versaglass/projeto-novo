import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { CatalogImportErrors, toPublicCatalogImportError } from "@/lib/catalog-import/errors";
import { sanitizeOriginalFilename } from "@/lib/catalog-import/filename";
import {
  CATALOG_IMPORT_STAGING_BUCKET,
  ZIP_MAX_SIZE_BYTES,
  ZIP_UI_LIMIT_LABEL,
} from "@/lib/catalog-import/limits";
import { isAllowedStagingImagePath } from "@/lib/catalog-import/path-safety";

async function assertPlatformAdmin(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  supabase: { rpc: (...args: any[]) => any },
  userId: string,
): Promise<void> {
  const { data: isAdmin, error } = await supabase.rpc("has_role", {
    _user_id: userId,
    _role: "admin",
  });
  if (error) throw CatalogImportErrors.unauthorized();
  if (!isAdmin) throw CatalogImportErrors.unauthorized();
}

function asStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((v): v is string => typeof v === "string");
}

const CreateJobInput = z.object({
  originalFilename: z.string().trim().min(1).max(260),
  sizeBytes: z.number().int().positive().max(ZIP_MAX_SIZE_BYTES),
});

export type CreateCatalogImportJobResult = {
  jobId: string;
  storageBucket: string;
  storagePath: string;
  maxSizeBytes: number;
  uiLimitLabel: string;
};

export const createCatalogImportJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => CreateJobInput.parse(d))
  .handler(async ({ data, context }): Promise<CreateCatalogImportJobResult> => {
    await assertPlatformAdmin(context.supabase, context.userId);

    const originalFilename = sanitizeOriginalFilename(data.originalFilename);
    const name = originalFilename.toLowerCase();
    if (!name.endsWith(".zip")) throw CatalogImportErrors.invalidFilename();
    if (data.sizeBytes > ZIP_MAX_SIZE_BYTES) throw CatalogImportErrors.zipTooLarge();

    const jobId = crypto.randomUUID();
    const storagePath = `imports/${jobId}/source.zip`;

    const { error } = await context.supabase.from("catalog_import_jobs").insert({
      id: jobId,
      created_by: context.userId,
      original_filename: originalFilename,
      declared_size_bytes: data.sizeBytes,
      storage_path: storagePath,
      storage_bucket: CATALOG_IMPORT_STAGING_BUCKET,
      status: "awaiting_upload",
    });

    if (error) throw CatalogImportErrors.processingFailed();

    return {
      jobId,
      storageBucket: CATALOG_IMPORT_STAGING_BUCKET,
      storagePath,
      maxSizeBytes: ZIP_MAX_SIZE_BYTES,
      uiLimitLabel: ZIP_UI_LIMIT_LABEL,
    };
  });

const JobIdInput = z.object({
  jobId: z.string().uuid(),
});

export type ProcessCatalogImportResult = {
  jobId: string;
  status: "ready";
  manufacturerName: string;
  catalogName: string;
  counts: {
    total_items: number;
    valid_items: number;
    review_items: number;
    duplicate_items: number;
    invalid_items: number;
  };
};

export const processCatalogImport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => JobIdInput.parse(d))
  .handler(async ({ data, context }): Promise<ProcessCatalogImportResult> => {
    try {
      await assertPlatformAdmin(context.supabase, context.userId);

      const { data: job, error } = await context.supabase
        .from("catalog_import_jobs")
        .select("id, status, created_by")
        .eq("id", data.jobId)
        .maybeSingle();
      if (error || !job) throw CatalogImportErrors.jobNotFound();

      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const { processCatalogImportJob } = await import("@/lib/catalog-import/process-job.server");
      const result = await processCatalogImportJob({
        admin: supabaseAdmin as never,
        jobId: data.jobId,
      });

      try {
        const ingest = await import("@/lib/log-ingest.server");
        await ingest.writeAuditLog({
          actorId: context.userId,
          actorEmail: typeof context.claims?.email === "string" ? context.claims.email : null,
          action: "catalog_import_processed",
          entity: "catalog_import_jobs",
          entityId: data.jobId,
          metadata: {
            job_id: data.jobId,
            manufacturer: result.manufacturerName,
            catalog_name: result.catalogName,
            schema_version: "1.0",
            ...result.counts,
          },
        });
      } catch {
        /* audit best-effort */
      }

      return result;
    } catch (e) {
      throw toPublicCatalogImportError(e);
    }
  });

export type CatalogImportJobView = {
  id: string;
  status: string;
  original_filename: string;
  manufacturer_name: string | null;
  catalog_name: string | null;
  catalog_date: string | null;
  source_filename: string | null;
  schema_version: string | null;
  total_items: number;
  valid_items: number;
  review_items: number;
  duplicate_items: number;
  invalid_items: number;
  approved_items: number;
  rejected_items: number;
  published_items: number;
  duplicates_at_publish: number;
  warnings: string[];
  error_message: string | null;
  existing_manufacturer_id: string | null;
  resolved_manufacturer_id: string | null;
  resolved_manufacturer_name: string | null;
  created_at: string;
  processed_at: string | null;
  completed_at: string | null;
};

export const getCatalogImportJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => JobIdInput.parse(d))
  .handler(async ({ data, context }): Promise<CatalogImportJobView> => {
    await assertPlatformAdmin(context.supabase, context.userId);
    const { data: job, error } = await context.supabase
      .from("catalog_import_jobs")
      .select(
        "id, status, original_filename, manufacturer_name, catalog_name, catalog_date, source_filename, schema_version, total_items, valid_items, review_items, duplicate_items, invalid_items, approved_items, rejected_items, published_items, duplicates_at_publish, warnings, error_message, existing_manufacturer_id, resolved_manufacturer_id, resolved_manufacturer_name, created_at, processed_at, completed_at",
      )
      .eq("id", data.jobId)
      .maybeSingle();
    if (error || !job) throw CatalogImportErrors.jobNotFound();
    return {
      ...job,
      approved_items: job.approved_items ?? 0,
      rejected_items: job.rejected_items ?? 0,
      published_items: job.published_items ?? 0,
      duplicates_at_publish: job.duplicates_at_publish ?? 0,
      warnings: asStringArray(job.warnings),
    };
  });

export type CatalogImportItemView = {
  id: string;
  position: number;
  source_code: string | null;
  base_code: string | null;
  name: string | null;
  description: string | null;
  product_line: string | null;
  suggested_category: string | null;
  inventory_category: string | null;
  unit: string | null;
  source_page: number | null;
  validation_status: string;
  validation_errors: string[];
  validation_warnings: string[];
  ai_warnings: string[];
  ai_review_required: boolean;
  review_decision: string;
  primary_image_staging_path: string | null;
  duplicate_product_id: string | null;
  published_product_id: string | null;
};

export const getCatalogImportItems = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => JobIdInput.parse(d))
  .handler(async ({ data, context }): Promise<CatalogImportItemView[]> => {
    await assertPlatformAdmin(context.supabase, context.userId);
    const { data: items, error } = await context.supabase
      .from("catalog_import_items")
      .select(
        "id, position, source_code, base_code, name, description, product_line, suggested_category, inventory_category, unit, source_page, validation_status, validation_errors, validation_warnings, ai_warnings, ai_review_required, review_decision, primary_image_staging_path, duplicate_product_id, published_product_id",
      )
      .eq("import_job_id", data.jobId)
      .order("position", { ascending: true });
    if (error) throw CatalogImportErrors.processingFailed();
    return (items ?? []).map((it) => ({
      id: it.id,
      position: it.position,
      source_code: it.source_code ?? null,
      base_code: it.base_code ?? null,
      name: it.name ?? null,
      description: it.description ?? null,
      product_line: it.product_line ?? null,
      suggested_category: it.suggested_category ?? null,
      inventory_category: it.inventory_category ?? null,
      unit: it.unit ?? null,
      source_page: it.source_page ?? null,
      validation_status: it.validation_status,
      validation_errors: asStringArray(it.validation_errors),
      validation_warnings: asStringArray(
        (it as { validation_warnings?: unknown }).validation_warnings,
      ),
      ai_warnings: asStringArray(it.ai_warnings),
      ai_review_required: it.ai_review_required === true,
      review_decision: it.review_decision ?? "pending",
      primary_image_staging_path: it.primary_image_staging_path ?? null,
      duplicate_product_id: it.duplicate_product_id ?? null,
      published_product_id: it.published_product_id ?? null,
    }));
  });

const SignedUrlInput = z.object({
  jobId: z.string().uuid(),
  path: z.string().min(1).max(500),
});

export const getCatalogImportStagingSignedUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SignedUrlInput.parse(d))
  .handler(async ({ data, context }): Promise<{ url: string }> => {
    await assertPlatformAdmin(context.supabase, context.userId);

    const { data: job, error: jobErr } = await context.supabase
      .from("catalog_import_jobs")
      .select("id")
      .eq("id", data.jobId)
      .maybeSingle();
    if (jobErr || !job) throw CatalogImportErrors.jobNotFound();

    const { data: items, error: itemsErr } = await context.supabase
      .from("catalog_import_items")
      .select("primary_image_staging_path, technical_image_staging_paths")
      .eq("import_job_id", data.jobId);
    if (itemsErr) throw CatalogImportErrors.processingFailed();

    const allowed = new Set<string>();
    for (const it of items ?? []) {
      if (typeof it.primary_image_staging_path === "string" && it.primary_image_staging_path) {
        allowed.add(it.primary_image_staging_path);
      }
      for (const p of asStringArray(it.technical_image_staging_paths)) {
        allowed.add(p);
      }
    }

    if (!isAllowedStagingImagePath(data.jobId, data.path, allowed)) {
      throw CatalogImportErrors.invalidPath();
    }

    const { data: signed, error } = await context.supabase.storage
      .from(CATALOG_IMPORT_STAGING_BUCKET)
      .createSignedUrl(data.path, 60 * 60);
    if (error || !signed?.signedUrl) throw CatalogImportErrors.processingFailed();
    return { url: signed.signedUrl };
  });
