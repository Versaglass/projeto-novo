import Ajv2020, { type ErrorObject } from "ajv/dist/2020";
import schemaJson from "./kit/versaglass-catalog-import-v1.schema.json";
import { CatalogImportErrors } from "./errors";
import { MANIFEST_MAX_ITEMS } from "./limits";

export type CatalogManifest = {
  schema_version: string;
  catalog: {
    manufacturer: string;
    name: string;
    date: string;
    source_filename: string;
    language: string;
  };
  generated_by: { type: string; name: string };
  items: CatalogManifestItem[];
};

export type CatalogManifestItem = {
  source_code: string;
  base_code: string | null;
  name: string;
  description: string | null;
  product_type: string | null;
  line: string | null;
  suggested_category: string | null;
  unit: string | null;
  source: { page: number | null; excerpt: string | null };
  primary_image: string | null;
  technical_images: string[];
  attributes: unknown[];
  observations: unknown[];
  review_required: boolean;
  warnings: string[];
};

const ajv = new Ajv2020({
  allErrors: true,
  strict: false,
  validateSchema: false,
});

const validateFn = ajv.compile(schemaJson);

export function parseManifestJson(text: string): unknown {
  try {
    return JSON.parse(text) as unknown;
  } catch {
    throw CatalogImportErrors.invalidJson();
  }
}

export function validateManifestAgainstSchema(data: unknown): CatalogManifest {
  const ok = validateFn(data);
  if (!ok) {
    const errs = (validateFn.errors ?? []) as ErrorObject[];
    const versionIssue = errs.some(
      (e) => e.instancePath === "/schema_version" || e.schemaPath.includes("schema_version"),
    );
    if (versionIssue) throw CatalogImportErrors.unsupportedVersion();
    throw CatalogImportErrors.schemaInvalid();
  }

  const manifest = data as CatalogManifest;
  if (manifest.schema_version !== "1.0") {
    throw CatalogImportErrors.unsupportedVersion();
  }
  // Runtime efetivo (contrato alinhado a 1000; defesa em profundidade)
  if (manifest.items.length > MANIFEST_MAX_ITEMS) {
    throw CatalogImportErrors.tooManyItems();
  }
  return manifest;
}

/** Test helper: returns AJV errors without throwing. */
export function getManifestSchemaErrors(data: unknown): ErrorObject[] | null {
  const ok = validateFn(data);
  return ok ? null : [...(validateFn.errors ?? [])];
}
