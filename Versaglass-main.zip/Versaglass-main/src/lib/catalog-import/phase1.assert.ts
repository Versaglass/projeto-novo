/**
 * Asserções Fase 1 — Catalog Import (sem vitest no projeto).
 *
 * Lê os arquivos do Kit pelo filesystem (sem `?raw` do Vite) para rodar em Node.
 *
 * Executar na raiz do repo:
 *   npx tsx src/lib/catalog-import/phase1.assert.ts
 */

import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { CATALOG_IMPORT_ACCESS_MATRIX, isPlatformAdminRole } from "./access";
import { buildZipStore } from "./kit-builder-core";
import {
  CATALOG_IMPORT_SCHEMA_VERSION,
  normalizeManufacturerName,
  normalizeSourceCode,
} from "./normalize";

const kitDir = join(dirname(fileURLToPath(import.meta.url)), "kit");

function run() {
  // --- Normalização ---
  assert.equal(normalizeManufacturerName("AL  Indústria"), "al industria");
  assert.equal(normalizeManufacturerName("  al industria "), "al industria");
  assert.equal(normalizeSourceCode("AL 1629 JB"), "al 1629 jb");
  assert.equal(normalizeSourceCode("AL-1629/JB"), "al 1629 jb");
  assert.equal(normalizeSourceCode("al 1629 jb"), "al 1629 jb");

  // --- Contrato versionado no disco ---
  assert.equal(CATALOG_IMPORT_SCHEMA_VERSION, "1.0");
  const expected = [
    "PROMPT_IA.md",
    "REGRAS_IMPORTADOR.md",
    "example-manifest.json",
    "versaglass-catalog-import-v1.schema.json",
  ].sort();
  const onDisk = readdirSync(kitDir)
    .filter((n) => !n.startsWith("."))
    .sort();
  assert.deepEqual(onDisk, expected);

  const schema = readFileSync(join(kitDir, "versaglass-catalog-import-v1.schema.json"), "utf8");
  assert.match(schema, /"const":\s*"1\.0"/);
  assert.match(schema, /additionalProperties/);

  const example = JSON.parse(readFileSync(join(kitDir, "example-manifest.json"), "utf8")) as {
    schema_version: string;
    items: unknown[];
  };
  assert.equal(example.schema_version, "1.0");
  assert.ok(example.items.length >= 1);

  const prompt = readFileSync(join(kitDir, "PROMPT_IA.md"), "utf8");
  assert.match(prompt, /schema_version/);
  assert.match(prompt, /PROIBIDOS/i);

  // --- ZIP determinístico ---
  const files = expected.map((path) => ({
    path,
    content: readFileSync(join(kitDir, path), "utf8"),
  }));
  const zip = buildZipStore(files);
  assert.ok(zip.byteLength > 100);
  assert.equal(zip[0], 0x50);
  assert.equal(zip[1], 0x4b);
  assert.equal(zip[2], 0x03);
  assert.equal(zip[3], 0x04);
  const zip2 = buildZipStore(files);
  assert.equal(zip.byteLength, zip2.byteLength);
  for (let i = 0; i < zip.length; i++) assert.equal(zip[i], zip2[i]);

  // --- Autorização plataforma vs company / vendedor / instalador ---
  for (const row of CATALOG_IMPORT_ACCESS_MATRIX) {
    assert.equal(isPlatformAdminRole(row.roles), row.allowed, `matriz acesso: ${row.label}`);
  }

  console.log("catalog-import phase1.assert: OK");
}

run();
