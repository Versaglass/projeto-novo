/**
 * Inspeção de metadados ZIP (yauzl Entry) — encryption / tipos especiais Unix.
 */

export type ZipEntryMeta = {
  fileName: string;
  generalPurposeBitFlag: number;
  versionMadeBy: number;
  externalFileAttributes: number;
  isEncrypted?: () => boolean;
};

export function entryIsEncrypted(entry: ZipEntryMeta): boolean {
  if (typeof entry.isEncrypted === "function") return entry.isEncrypted();
  return (entry.generalPurposeBitFlag & 0x1) !== 0;
}

/**
 * Detecta symlink / device / socket via modo Unix (quando versionMadeBy indica Unix).
 * MS-DOS entries sem modo Unix são tratadas como arquivo regular (ou diretório via nome).
 *
 * S_IFMT  = 0o170000
 * S_IFREG = 0o100000
 * S_IFDIR = 0o040000
 * S_IFLNK = 0o120000
 */
export function classifyUnixEntryKind(
  entry: ZipEntryMeta,
): "regular" | "directory" | "symlink" | "special" | "unknown" {
  const host = (entry.versionMadeBy >> 8) & 0xff;
  // 3 = Unix (Info-ZIP)
  if (host !== 3) return "unknown";

  const mode = (entry.externalFileAttributes >>> 16) & 0xffff;
  const type = mode & 0o170000;
  if (type === 0) return "unknown";
  if (type === 0o100000) return "regular";
  if (type === 0o040000) return "directory";
  if (type === 0o120000) return "symlink";
  // hardlink is not a distinct IFMT; FIFO/CHR/BLK/SOCK → special
  return "special";
}

export function entryIsForbiddenSpecial(entry: ZipEntryMeta): boolean {
  const kind = classifyUnixEntryKind(entry);
  return kind === "symlink" || kind === "special";
}
