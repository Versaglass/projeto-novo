/**
 * Sanitização de metadados vindos do browser (nunca usados como path).
 */

/** Mantém só para display/audit; limita tamanho e remove controles. */
export function sanitizeOriginalFilename(raw: string, maxLen = 200): string {
  let out = "";
  for (const ch of raw) {
    const code = ch.codePointAt(0) ?? 0;
    if (code < 32 || code === 127) continue;
    out += ch;
  }
  const trimmed = out.trim();
  const base = trimmed.length > 0 ? trimmed : "catalogo.zip";
  if (base.length <= maxLen) return base;
  return base.slice(0, maxLen);
}
