/**
 * Download do ZIP para arquivo temporário controlado + checagem de assinatura.
 */

import { createWriteStream } from "node:fs";
import { mkdir, open, unlink } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { CatalogImportError, CatalogImportErrors } from "./errors";
import { ZIP_MAX_SIZE_BYTES } from "./limits";

/** Assinatura local/central ZIP (PK..). */
export function looksLikeZipMagic(header: Uint8Array): boolean {
  if (header.byteLength < 4) return false;
  return (
    header[0] === 0x50 &&
    header[1] === 0x4b &&
    (header[2] === 0x03 || header[2] === 0x05 || header[2] === 0x07 || header[2] === 0x01)
  );
}

export function assertZipMagic(header: Uint8Array): void {
  if (!looksLikeZipMagic(header)) throw CatalogImportErrors.invalidZip();
}

/**
 * Acumula bytes com teto — testável sem I/O.
 * Retorna false se ultrapassar o limite.
 */
export function acceptChunkWithinLimit(
  bytesSoFar: number,
  chunkLength: number,
  maxBytes: number = ZIP_MAX_SIZE_BYTES,
): { ok: true; next: number } | { ok: false; next: number } {
  const next = bytesSoFar + chunkLength;
  if (next > maxBytes) return { ok: false, next };
  return { ok: true, next };
}

export function buildCatalogImportTempPath(
  jobId: string,
  randomId: string = crypto.randomUUID(),
): string {
  // Nunca usa originalFilename. Nome imprevisível sob tmpdir do OS.
  const safeJob = jobId.replace(/[^a-f0-9-]/gi, "");
  const safeRnd = randomId.replace(/[^a-f0-9-]/gi, "");
  return join(tmpdir(), "versaglass-catalog-import", `${safeJob}-${safeRnd}.zip`);
}

export async function ensureTempUnlinked(tmpPath: string | null | undefined): Promise<void> {
  if (!tmpPath) return;
  await unlink(tmpPath).catch(() => undefined);
}

export async function streamUrlToTempFile(
  url: string,
  jobId: string,
): Promise<{ tmpPath: string; bytesWritten: number }> {
  const res = await fetch(url);
  if (!res.ok || !res.body) throw CatalogImportErrors.objectMissing();

  const dir = join(tmpdir(), "versaglass-catalog-import");
  await mkdir(dir, { recursive: true });
  const tmpPath = buildCatalogImportTempPath(jobId);

  let bytesWritten = 0;
  const nodeReadable = Readable.fromWeb(res.body as import("node:stream/web").ReadableStream);
  const out = createWriteStream(tmpPath);

  nodeReadable.on("data", (chunk: Buffer) => {
    const acc = acceptChunkWithinLimit(bytesWritten, chunk.length);
    if (!acc.ok) {
      nodeReadable.destroy(CatalogImportErrors.zipTooLarge());
      return;
    }
    bytesWritten = acc.next;
  });

  try {
    await pipeline(nodeReadable, out);
  } catch (e) {
    await ensureTempUnlinked(tmpPath);
    if (e instanceof CatalogImportError) throw e;
    throw CatalogImportErrors.invalidZip();
  }

  if (bytesWritten <= 0) {
    await ensureTempUnlinked(tmpPath);
    throw CatalogImportErrors.invalidZip();
  }
  if (bytesWritten > ZIP_MAX_SIZE_BYTES) {
    await ensureTempUnlinked(tmpPath);
    throw CatalogImportErrors.zipTooLarge();
  }

  // Assinatura real — não confiar em Content-Type do TUS/browser.
  try {
    const fh = await open(tmpPath, "r");
    try {
      const buf = Buffer.alloc(4);
      const { bytesRead } = await fh.read(buf, 0, 4, 0);
      assertZipMagic(buf.subarray(0, bytesRead));
    } finally {
      await fh.close();
    }
  } catch (e) {
    await ensureTempUnlinked(tmpPath);
    if (e instanceof CatalogImportError) throw e;
    throw CatalogImportErrors.invalidZip();
  }

  return { tmpPath, bytesWritten };
}
