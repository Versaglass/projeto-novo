/**
 * Leitura segura de ZIP via arquivo em disco + yauzl (random access).
 * Download: stream HTTP → temp (sem ArrayBuffer do ZIP inteiro na app).
 * Entries processadas sob demanda; imagens ≤ 5 MiB bufferizadas individualmente.
 *
 * Rejeita: encryption, symlink/special Unix, paths duplicados / colisão case-insensitive.
 */

import yauzl, { type Entry, type ZipFile } from "yauzl";
import { CatalogImportError, CatalogImportErrors } from "./errors";
import {
  IMAGE_MAX_BYTES,
  MANIFEST_MAX_BYTES,
  UNCOMPRESSED_MAX_BYTES,
  ZIP_MAX_ENTRIES,
} from "./limits";
import { classifyZipEntryPath, zipPathCaseKey } from "./path-safety";
import { entryIsEncrypted, entryIsForbiddenSpecial } from "./zip-entry-meta";

export type ZipImageEntry = {
  relative: string;
  basename: string;
  uncompressedSize: number;
};

export type OpenedCatalogZip = {
  tmpPath: string;
  manifestText: string;
  images: Map<string, ZipImageEntry>;
  totalUncompressed: number;
  entryCount: number;
  /** Fecha handle yauzl — NÃO remove o arquivo temp (caller remove no finally). */
  closeHandle: () => void;
  readImageBytes: (relative: string) => Promise<Uint8Array>;
};

function openYauzl(path: string): Promise<ZipFile> {
  return new Promise((resolve, reject) => {
    // validateEntrySizes:false — entries encrypted falham o check interno do yauzl
    // antes de expormos isEncrypted(); limites de tamanho ficam em UNCOMPRESSED_MAX / read caps.
    yauzl.open(
      path,
      { lazyEntries: true, autoClose: false, validateEntrySizes: false },
      (err, zip) => {
        if (err || !zip) reject(err ?? new Error("zip open failed"));
        else resolve(zip);
      },
    );
  });
}

function readEntryBuffer(
  zip: ZipFile,
  entry: Entry,
  maxBytes: number,
  overflowError: () => CatalogImportError = CatalogImportErrors.zipBomb,
): Promise<Uint8Array> {
  return new Promise((resolve, reject) => {
    if (entryIsEncrypted(entry)) {
      reject(CatalogImportErrors.zipEncrypted());
      return;
    }
    zip.openReadStream(entry, (err, stream) => {
      if (err || !stream) {
        // yauzl lança erro em encrypted / corrupt
        const msg = err instanceof Error ? err.message.toLowerCase() : "";
        if (msg.includes("encrypted")) {
          reject(CatalogImportErrors.zipEncrypted());
          return;
        }
        reject(err ?? CatalogImportErrors.invalidZip());
        return;
      }
      const chunks: Buffer[] = [];
      let total = 0;
      stream.on("data", (chunk: Buffer) => {
        total += chunk.length;
        if (total > maxBytes) {
          stream.destroy();
          reject(overflowError());
          return;
        }
        chunks.push(chunk);
      });
      stream.on("error", (e) => {
        const msg = e instanceof Error ? e.message.toLowerCase() : "";
        if (msg.includes("encrypted")) reject(CatalogImportErrors.zipEncrypted());
        else reject(CatalogImportErrors.invalidZip());
      });
      stream.on("end", () => resolve(new Uint8Array(Buffer.concat(chunks))));
    });
  });
}

function walkEntries(zip: ZipFile): Promise<Entry[]> {
  return new Promise((resolve, reject) => {
    const entries: Entry[] = [];
    zip.readEntry();
    zip.on("entry", (entry: Entry) => {
      entries.push(entry);
      if (entries.length > ZIP_MAX_ENTRIES) {
        reject(CatalogImportErrors.tooManyEntries());
        return;
      }
      zip.readEntry();
    });
    zip.on("end", () => resolve(entries));
    zip.on("error", () => reject(CatalogImportErrors.invalidZip()));
  });
}

export async function openCatalogZip(tmpPath: string): Promise<OpenedCatalogZip> {
  let zip: ZipFile;
  try {
    zip = await openYauzl(tmpPath);
  } catch {
    throw CatalogImportErrors.invalidZip();
  }

  let entries: Entry[];
  try {
    entries = await walkEntries(zip);
  } catch (e) {
    zip.close();
    throw e;
  }

  const images = new Map<string, ZipImageEntry>();
  const imageEntries = new Map<string, Entry>();
  const caseIndex = new Map<string, string>();
  let manifestEntry: Entry | null = null;
  let manifestCount = 0;
  let totalUncompressed = 0;

  for (const entry of entries) {
    if (entryIsEncrypted(entry)) {
      zip.close();
      throw CatalogImportErrors.zipEncrypted();
    }
    if (entryIsForbiddenSpecial(entry)) {
      zip.close();
      throw CatalogImportErrors.zipSpecialEntry();
    }

    const classified = classifyZipEntryPath(entry.fileName);
    if (classified.kind === "reject") {
      zip.close();
      throw CatalogImportErrors.invalidPath();
    }

    const unc = entry.uncompressedSize;
    if (unc < 0 || !Number.isFinite(unc)) {
      zip.close();
      throw CatalogImportErrors.invalidZip();
    }
    totalUncompressed += unc;
    if (totalUncompressed > UNCOMPRESSED_MAX_BYTES) {
      zip.close();
      throw CatalogImportErrors.zipBomb();
    }

    if (classified.kind === "directory") continue;

    if (classified.kind === "manifest") {
      manifestCount++;
      if (manifestCount > 1) {
        zip.close();
        throw CatalogImportErrors.multipleManifests();
      }
      if (unc > MANIFEST_MAX_BYTES) {
        zip.close();
        throw CatalogImportErrors.schemaInvalid();
      }
      manifestEntry = entry;
      continue;
    }

    if (classified.kind === "image") {
      // Defesa 1: tamanho declarado — rejeita antes de bufferizar.
      if (unc > IMAGE_MAX_BYTES) {
        zip.close();
        throw CatalogImportErrors.imageTooLarge();
      }

      const caseKey = zipPathCaseKey(classified.relative);
      const prior = caseIndex.get(caseKey);
      if (prior != null) {
        zip.close();
        // Mesmo path canônico OU colisão case-insensitive
        throw CatalogImportErrors.duplicateZipEntry();
      }
      caseIndex.set(caseKey, classified.relative);

      if (images.has(classified.relative)) {
        zip.close();
        throw CatalogImportErrors.duplicateZipEntry();
      }
      images.set(classified.relative, {
        relative: classified.relative,
        basename: classified.basename,
        uncompressedSize: unc,
      });
      imageEntries.set(classified.relative, entry);
    }
  }

  if (manifestCount === 0 || !manifestEntry) {
    zip.close();
    throw CatalogImportErrors.missingManifest();
  }

  let manifestText: string;
  try {
    const manifestBytes = await readEntryBuffer(zip, manifestEntry, MANIFEST_MAX_BYTES);
    manifestText = new TextDecoder("utf-8").decode(manifestBytes);
  } catch (e) {
    zip.close();
    throw e;
  }

  const closeHandle = () => {
    try {
      zip.close();
    } catch {
      /* ignore */
    }
  };

  const readImageBytes = async (relative: string): Promise<Uint8Array> => {
    const entry = imageEntries.get(relative);
    if (!entry) throw CatalogImportErrors.invalidStructure();
    // Defesa 2: hard cap no stream — aborta ao ultrapassar IMAGE_MAX_BYTES.
    return readEntryBuffer(zip, entry, IMAGE_MAX_BYTES, CatalogImportErrors.imageTooLarge);
  };

  return {
    tmpPath,
    manifestText,
    images,
    totalUncompressed,
    entryCount: entries.length,
    closeHandle,
    readImageBytes,
  };
}
