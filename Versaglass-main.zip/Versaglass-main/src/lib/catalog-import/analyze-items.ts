/**
 * Análise pura de itens do manifesto (sem I/O) — testável offline.
 */

import { TECHNICAL_IMAGES_MAX_PER_ITEM } from "./limits";
import { normalizeSourceCode } from "./normalize";
import { classifyZipEntryPath } from "./path-safety";
import { countByStatus, resolveValidationStatus, type ValidationStatus } from "./status";
import { isUnmappedManifestUnit, mapManifestUnit, UNIT_UNMAPPED_WARNING } from "./unit-map";
import type { CatalogManifest, CatalogManifestItem } from "./manifest-validate";

export type AnalyzedItem = {
  position: number;
  item: CatalogManifestItem;
  normalizedSourceCode: string;
  validationStatus: ValidationStatus;
  validationErrors: string[];
  /** Warnings do importador VersaGlass (não da IA). */
  validationWarnings: string[];
  duplicateProductId: string | null;
  unitMapped: ReturnType<typeof mapManifestUnit>;
  referencedImages: string[];
};

export type AnalyzeItemsResult = {
  analyzed: AnalyzedItem[];
  counts: ReturnType<typeof countByStatus>;
  referencedImageSet: Set<string>;
  unreferencedImages: string[];
};

function imageRefErrors(path: string | null, available: Set<string>, label: string): string[] {
  if (path == null) return [];
  const classified = classifyZipEntryPath(path);
  if (classified.kind !== "image") {
    return [`${label}: caminho inválido (${path})`];
  }
  // Referência no manifesto deve coincidir com a forma canônica (após normalize no classify).
  if (!available.has(classified.relative)) {
    return [`${label}: arquivo inexistente no ZIP (${path})`];
  }
  return [];
}

/**
 * @param existingByNormalizedCode map normalized_source_code → manufacturer_products.id
 *        (somente se fabricante já existe). Vazio se fabricante novo.
 */
export function analyzeManifestItems(
  manifest: CatalogManifest,
  availableImages: Set<string>,
  existingByNormalizedCode: Map<string, string>,
): AnalyzeItemsResult {
  const normalizedGroups = new Map<string, number[]>();
  const prelim = manifest.items.map((item, idx) => {
    const position = idx + 1;
    const normalizedSourceCode = normalizeSourceCode(item.source_code);
    const list = normalizedGroups.get(normalizedSourceCode) ?? [];
    list.push(position);
    normalizedGroups.set(normalizedSourceCode, list);
    return { position, item, normalizedSourceCode };
  });

  const internalDupPositions = new Set<number>();
  for (const positions of normalizedGroups.values()) {
    if (positions.length > 1) {
      for (const p of positions) internalDupPositions.add(p);
    }
  }

  const referencedImageSet = new Set<string>();
  const analyzed: AnalyzedItem[] = prelim.map(({ position, item, normalizedSourceCode }) => {
    const technicalErrors: string[] = [];
    const validationWarnings: string[] = [];

    if (item.technical_images.length > TECHNICAL_IMAGES_MAX_PER_ITEM) {
      technicalErrors.push(
        `Mais de ${TECHNICAL_IMAGES_MAX_PER_ITEM} imagens técnicas não são permitidas.`,
      );
    }

    technicalErrors.push(
      ...imageRefErrors(item.primary_image, availableImages, "Imagem principal"),
    );
    for (const tech of item.technical_images) {
      technicalErrors.push(...imageRefErrors(tech, availableImages, "Imagem técnica"));
    }

    if (item.primary_image) {
      const c = classifyZipEntryPath(item.primary_image);
      if (c.kind === "image") referencedImageSet.add(c.relative);
    }
    for (const tech of item.technical_images) {
      const c = classifyZipEntryPath(tech);
      if (c.kind === "image") referencedImageSet.add(c.relative);
    }

    const unitMapped = mapManifestUnit(item.unit);
    let systemReviewRequired = false;
    if (isUnmappedManifestUnit(item.unit)) {
      validationWarnings.push(UNIT_UNMAPPED_WARNING);
      systemReviewRequired = true;
    }

    const existingProductId = existingByNormalizedCode.get(normalizedSourceCode) ?? null;
    const { status, errors } = resolveValidationStatus({
      technicalErrors,
      internalDuplicate: internalDupPositions.has(position),
      existingProductId,
      aiReviewRequired: item.review_required === true,
      systemReviewRequired,
    });

    return {
      position,
      item,
      normalizedSourceCode,
      validationStatus: status,
      validationErrors: errors,
      validationWarnings,
      duplicateProductId: status === "duplicate" ? existingProductId : null,
      unitMapped,
      referencedImages: [
        ...(item.primary_image
          ? (() => {
              const c = classifyZipEntryPath(item.primary_image);
              return c.kind === "image" ? [c.relative] : [];
            })()
          : []),
        ...item.technical_images.flatMap((t) => {
          const c = classifyZipEntryPath(t);
          return c.kind === "image" ? [c.relative] : [];
        }),
      ],
    };
  });

  const unreferencedImages = [...availableImages].filter((p) => !referencedImageSet.has(p));

  return {
    analyzed,
    counts: countByStatus(analyzed.map((a) => a.validationStatus)),
    referencedImageSet,
    unreferencedImages,
  };
}
