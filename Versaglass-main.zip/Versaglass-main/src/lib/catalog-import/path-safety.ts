/**
 * Segurança de paths dentro do ZIP — rejeita traversal, absolutos e URLs.
 * Normaliza \ / // ./ para uma forma canônica única (independente do SO).
 */

const WINDOWS_ABS = /^[a-zA-Z]:[\\/]/;
const HAS_URL = /^(https?|file|ftp):/i;

export type SafeZipPath =
  | { kind: "manifest" }
  | { kind: "image"; relative: string; basename: string }
  | { kind: "directory" }
  | { kind: "reject"; reason: string };

/**
 * Canonicaliza o nome da entry:
 * - unifica separadores para /
 * - remove segmentos vazios (//) e "."
 * - rejeita ".." (retorna string vazia + caller trata via classify)
 */
export function normalizeZipEntryName(raw: string): string {
  const unified = raw.replace(/\\/g, "/");
  const trailingSlash = unified.endsWith("/") && unified.length > 1;
  const parts = unified.split("/");
  const out: string[] = [];
  for (const part of parts) {
    if (part === "" || part === ".") continue;
    if (part === "..") {
      // Sinaliza traversal; classify rejeita.
      return "..";
    }
    out.push(part);
  }
  if (out.length === 0) return trailingSlash ? "/" : "";
  return trailingSlash ? `${out.join("/")}/` : out.join("/");
}

/** Chave case-insensitive para detectar ambiguidade entre plataformas. */
export function zipPathCaseKey(normalizedRelative: string): string {
  return normalizedRelative.toLowerCase();
}

export function classifyZipEntryPath(rawName: string): SafeZipPath {
  if (!rawName || rawName.includes("\0")) {
    return { kind: "reject", reason: "nome de entrada inválido" };
  }

  if (HAS_URL.test(rawName) || rawName.includes("://")) {
    return { kind: "reject", reason: "URL não permitida" };
  }
  if (rawName.startsWith("/") || rawName.startsWith("\\") || WINDOWS_ABS.test(rawName)) {
    return { kind: "reject", reason: "caminho absoluto" };
  }

  const name = normalizeZipEntryName(rawName);
  if (!name || name === ".." || name.includes("..")) {
    return { kind: "reject", reason: "path traversal" };
  }
  if (name.startsWith("/")) {
    return { kind: "reject", reason: "caminho absoluto" };
  }

  if (name.endsWith("/")) {
    return { kind: "directory" };
  }

  if (name === "manifest.json") {
    return { kind: "manifest" };
  }

  // images/<arquivo> — um único nível sob images/
  if (name.startsWith("images/")) {
    const rest = name.slice("images/".length);
    if (!rest || rest.includes("/") || rest === "." || rest === "..") {
      return { kind: "reject", reason: "imagem deve estar diretamente em images/" };
    }
    return { kind: "image", relative: name, basename: rest };
  }

  return { kind: "reject", reason: `arquivo fora da estrutura permitida: ${name}` };
}

/**
 * Valida path de imagem de staging para signed URL:
 * deve pertencer ao conjunto de paths do job (DB), sob o prefixo do job.
 */
export function isAllowedStagingImagePath(
  jobId: string,
  path: string,
  allowedPaths: ReadonlySet<string>,
): boolean {
  if (!path || path.includes("..") || path.includes("\\") || path.includes("\0")) return false;
  const prefix = `imports/${jobId}/items/`;
  if (!path.startsWith(prefix)) return false;
  return allowedPaths.has(path);
}
