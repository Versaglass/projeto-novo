/**
 * Asserções Fase 2 — funções puras + schema (offline).
 * npx tsx src/lib/catalog-import/phase2.assert.ts
 */

import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { analyzeManifestItems } from "./analyze-items";
import { isPlatformAdminRole } from "./access";
import { getManifestSchemaErrors, validateManifestAgainstSchema } from "./manifest-validate";
import { normalizeManufacturerName, normalizeSourceCode } from "./normalize";
import { classifyZipEntryPath } from "./path-safety";
import { countByStatus, resolveValidationStatus } from "./status";
import { mapManifestUnit } from "./unit-map";
import { ZIP_MAX_SIZE_BYTES, MANIFEST_MAX_ITEMS } from "./limits";
import type { CatalogManifest } from "./manifest-validate";

const kitDir = join(dirname(fileURLToPath(import.meta.url)), "kit");

function baseItem(over: Partial<CatalogManifest["items"][0]> = {}): CatalogManifest["items"][0] {
  return {
    source_code: "AL 1",
    base_code: "1",
    name: "Item",
    description: null,
    product_type: "product",
    line: null,
    suggested_category: "Puxadores",
    unit: "un",
    source: { page: 1, excerpt: "x" },
    primary_image: null,
    technical_images: [],
    attributes: [],
    observations: [],
    review_required: false,
    warnings: [],
    ...over,
  };
}

function baseManifest(items: CatalogManifest["items"]): CatalogManifest {
  return {
    schema_version: "1.0",
    catalog: {
      manufacturer: "AL Indústria",
      name: "Cat",
      date: "2022-06",
      source_filename: "a.pdf",
      language: "pt-BR",
    },
    generated_by: { type: "ai", name: "test" },
    items,
  };
}

function run() {
  // Limits
  assert.equal(ZIP_MAX_SIZE_BYTES, 50 * 1024 * 1024);
  assert.equal(MANIFEST_MAX_ITEMS, 1000);

  // Schema maxItems aligned
  const schema = JSON.parse(
    readFileSync(join(kitDir, "versaglass-catalog-import-v1.schema.json"), "utf8"),
  ) as { properties: { items: { maxItems: number } } };
  assert.equal(schema.properties.items.maxItems, 1000);

  // Example still validates
  const example = JSON.parse(readFileSync(join(kitDir, "example-manifest.json"), "utf8"));
  validateManifestAgainstSchema(example);

  // 05 schema_version
  assert.ok(getManifestSchemaErrors({ ...example, schema_version: "2.0" }));

  // 06 additionalProperties / commercial fields
  assert.ok(
    getManifestSchemaErrors({
      ...example,
      items: [{ ...example.items[0], preco_venda: 10 }],
    }),
  );
  assert.ok(
    getManifestSchemaErrors({
      ...example,
      stock: 1,
    }),
  );

  // 07 missing source_code
  const noCode = structuredClone(example);
  delete (noCode.items[0] as { source_code?: string }).source_code;
  assert.ok(getManifestSchemaErrors(noCode));

  // Path safety 08–10
  assert.equal(classifyZipEntryPath("../secret").kind, "reject");
  assert.equal(classifyZipEntryPath("/etc/passwd").kind, "reject");
  assert.equal(classifyZipEntryPath("C:\\Windows\\a.png").kind, "reject");
  assert.equal(classifyZipEntryPath("https://evil/a.png").kind, "reject");
  assert.equal(classifyZipEntryPath("manifest.json").kind, "manifest");
  assert.equal(classifyZipEntryPath("images/a.png").kind, "image");

  // Normalization 35–36
  assert.equal(normalizeManufacturerName("AL  Indústria"), "al industria");
  assert.equal(normalizeSourceCode("AL-1629/JB"), "al 1629 jb");

  // Unit map — inequívocos apenas; ambíguos → null (review no analyze)
  assert.equal(mapManifestUnit("un"), "un");
  assert.equal(mapManifestUnit("m²"), "m2");
  assert.equal(mapManifestUnit("pc"), "pc");
  assert.equal(mapManifestUnit("foo"), null);
  assert.equal(mapManifestUnit("peça"), null);

  // Status precedence
  assert.equal(
    resolveValidationStatus({
      technicalErrors: ["x"],
      internalDuplicate: false,
      existingProductId: "p",
      aiReviewRequired: true,
    }).status,
    "invalid",
  );
  assert.equal(
    resolveValidationStatus({
      technicalErrors: [],
      internalDuplicate: true,
      existingProductId: "p",
      aiReviewRequired: true,
    }).status,
    "invalid",
  );
  assert.equal(
    resolveValidationStatus({
      technicalErrors: [],
      internalDuplicate: false,
      existingProductId: "p",
      aiReviewRequired: true,
    }).status,
    "duplicate",
  );
  assert.equal(
    resolveValidationStatus({
      technicalErrors: [],
      internalDuplicate: false,
      existingProductId: null,
      aiReviewRequired: true,
    }).status,
    "review",
  );
  assert.equal(
    resolveValidationStatus({
      technicalErrors: [],
      internalDuplicate: false,
      existingProductId: null,
      aiReviewRequired: false,
    }).status,
    "valid",
  );

  // Analyze: missing image → invalid; job counts still ready-capable
  const m1 = baseManifest([
    baseItem({ source_code: "A1", primary_image: "images/missing.png" }),
    baseItem({ source_code: "A2", primary_image: null, review_required: true }),
  ]);
  const a1 = analyzeManifestItems(m1, new Set(), new Map());
  assert.equal(a1.analyzed[0]!.validationStatus, "invalid");
  assert.equal(a1.analyzed[1]!.validationStatus, "review");
  assert.equal(a1.counts.invalid_items, 1);
  assert.equal(a1.counts.review_items, 1);

  // Internal duplicate
  const m2 = baseManifest([
    baseItem({ source_code: "AL 1629 JB" }),
    baseItem({ source_code: "AL   1629   JB" }),
  ]);
  const a2 = analyzeManifestItems(m2, new Set(), new Map());
  assert.equal(a2.analyzed[0]!.validationStatus, "invalid");
  assert.equal(a2.analyzed[1]!.validationStatus, "invalid");

  // Global duplicate
  const m3 = baseManifest([baseItem({ source_code: "X1" })]);
  const a3 = analyzeManifestItems(
    m3,
    new Set(),
    new Map([[normalizeSourceCode("X1"), "prod-uuid"]]),
  );
  assert.equal(a3.analyzed[0]!.validationStatus, "duplicate");

  // Unreferenced images
  const m4 = baseManifest([baseItem({ primary_image: "images/a.png" })]);
  const a4 = analyzeManifestItems(m4, new Set(["images/a.png", "images/b.png"]), new Map());
  assert.deepEqual(a4.unreferencedImages, ["images/b.png"]);

  // primary null valid
  const m5 = baseManifest([baseItem({ primary_image: null })]);
  assert.equal(
    analyzeManifestItems(m5, new Set(), new Map()).analyzed[0]!.validationStatus,
    "valid",
  );

  // Auth matrix
  assert.equal(isPlatformAdminRole(["admin"]), true);
  assert.equal(isPlatformAdminRole(["vendedor"]), false);
  assert.equal(isPlatformAdminRole(["instalador"]), false);
  assert.equal(isPlatformAdminRole([]), false);

  // Counts helper
  const c = countByStatus(["valid", "valid", "review", "duplicate", "invalid"]);
  assert.equal(c.total_items, 5);
  assert.equal(c.valid_items, 2);

  // 1001 items rejected by runtime validator
  const many = baseManifest(
    Array.from({ length: 1001 }, (_, i) => baseItem({ source_code: `C${i}` })),
  );
  assert.throws(() => validateManifestAgainstSchema(many));

  console.log("catalog-import phase2.assert: OK");
}

run();
