/**
 * Pipeline server-side — processa ZIP após TUS (path vem do banco).
 *
 * Idempotência:
 * - Claim atômico awaiting_upload → processing (somente um vencedor).
 * - Staging: delete items + cleanup pasta items/ antes de persistir resultados.
 * - ready/failed/processing não reprocessam.
 *
 * Temp file: removido sempre no finally (sucesso, erro, throw).
 *
 * ZIP bruto:
 * - SUCCESS: remove source.zip após ready (falha de cleanup ≠ desfaz ready).
 * - FAILED: remove source.zip por segurança após marcar failed.
 *
 * Risco conhecido: timeout abrupto da plataforma pode deixar status=processing
 * sem UPDATE failed — recuperação futura, sem worker nesta fase.
 */

import type { SupabaseClient } from "@supabase/supabase-js";
import { analyzeManifestItems } from "./analyze-items";
import { claimCatalogImportJob } from "./claim-job";
import { CatalogImportError, CatalogImportErrors } from "./errors";
import { validateImageBytes } from "./image-validate";
import { CATALOG_IMPORT_STAGING_BUCKET, ZIP_MAX_SIZE_BYTES } from "./limits";
import { parseManifestJson, validateManifestAgainstSchema } from "./manifest-validate";
import { normalizeManufacturerName } from "./normalize";
import { classifyZipEntryPath } from "./path-safety";
import { assertCountsInvariant, resolveValidationStatus } from "./status";
import { ensureTempUnlinked, streamUrlToTempFile } from "./temp-zip";
import { openCatalogZip } from "./zip-stream";

function imageRelFromManifest(path: string): string | null {
  const c = classifyZipEntryPath(path);
  return c.kind === "image" ? c.relative : null;
}

export type ProcessJobResult = {
  jobId: string;
  status: "ready";
  counts: {
    total_items: number;
    valid_items: number;
    review_items: number;
    duplicate_items: number;
    invalid_items: number;
  };
  manufacturerName: string;
  catalogName: string;
};

function asPublicError(e: unknown): CatalogImportError {
  if (e instanceof CatalogImportError) return e;
  return CatalogImportErrors.processingFailed();
}

async function removeStorageObjectBestEffort(
  admin: SupabaseClient,
  bucket: string,
  path: string,
): Promise<{ removed: boolean }> {
  const { error } = await admin.storage.from(bucket).remove([path]);
  return { removed: !error };
}

/** Remove objetos sob imports/{jobId}/items/ (compensação / idempotência). */
async function cleanupJobItemObjects(
  admin: SupabaseClient,
  bucket: string,
  jobId: string,
): Promise<void> {
  const root = `imports/${jobId}/items`;
  try {
    const { data: itemDirs } = await admin.storage.from(bucket).list(root, { limit: 1000 });
    for (const dir of itemDirs ?? []) {
      if (!dir.name) continue;
      const itemPrefix = `${root}/${dir.name}`;
      const { data: files } = await admin.storage.from(bucket).list(itemPrefix, { limit: 100 });
      const primary = (files ?? [])
        .filter((f) => f.name && !f.name.endsWith("/"))
        .map((f) => `${itemPrefix}/${f.name}`);
      const { data: tech } = await admin.storage.from(bucket).list(`${itemPrefix}/technical`, {
        limit: 100,
      });
      const techPaths = (tech ?? [])
        .filter((f) => f.name)
        .map((f) => `${itemPrefix}/technical/${f.name}`);
      const all = [...primary, ...techPaths];
      if (all.length > 0) await admin.storage.from(bucket).remove(all);
    }
  } catch {
    /* best-effort */
  }
}

/**
 * Confirma objeto exato no path do job (não prefixo ambíguo).
 * Preferência: list na pasta do job filtrando nome exato source.zip.
 */
async function resolveExactObjectSize(
  admin: SupabaseClient,
  bucket: string,
  storagePath: string,
): Promise<number | null> {
  const parts = storagePath.split("/");
  const fileName = parts.pop();
  const folder = parts.join("/");
  if (!fileName || fileName !== "source.zip") throw CatalogImportErrors.objectMissing();

  const { data: listed, error } = await admin.storage.from(bucket).list(folder, {
    search: "source.zip",
    limit: 20,
  });
  if (error) throw CatalogImportErrors.objectMissing();
  const obj = (listed ?? []).find((f) => f.name === "source.zip");
  if (!obj) throw CatalogImportErrors.objectMissing();

  const meta = obj.metadata && typeof obj.metadata === "object" ? obj.metadata : null;
  if (meta && typeof (meta as { size?: unknown }).size === "number") {
    return (meta as { size: number }).size;
  }
  return null;
}

export async function processCatalogImportJob(opts: {
  admin: SupabaseClient;
  jobId: string;
}): Promise<ProcessJobResult> {
  const { admin, jobId } = opts;

  // 1) Claim atômico — impede duplo processamento.
  const job = await claimCatalogImportJob(admin, jobId);
  const bucket = (job.storage_bucket as string) || CATALOG_IMPORT_STAGING_BUCKET;
  const storagePath = job.storage_path as string;

  let tmpPath: string | null = null;
  let opened: Awaited<ReturnType<typeof openCatalogZip>> | null = null;
  let markedReady = false;

  try {
    const metaSize = await resolveExactObjectSize(admin, bucket, storagePath);
    if (metaSize != null && metaSize > ZIP_MAX_SIZE_BYTES) {
      throw CatalogImportErrors.zipTooLarge();
    }
    if (metaSize != null) {
      await admin
        .from("catalog_import_jobs")
        .update({ actual_size_bytes: metaSize })
        .eq("id", jobId);
    }

    const { data: signed, error: signErr } = await admin.storage
      .from(bucket)
      .createSignedUrl(storagePath, 120);
    if (signErr || !signed?.signedUrl) throw CatalogImportErrors.objectMissing();

    const dl = await streamUrlToTempFile(signed.signedUrl, jobId);
    tmpPath = dl.tmpPath;

    await admin
      .from("catalog_import_jobs")
      .update({ actual_size_bytes: dl.bytesWritten })
      .eq("id", jobId);

    opened = await openCatalogZip(tmpPath);
    const manifest = validateManifestAgainstSchema(parseManifestJson(opened.manifestText));

    const manufacturerName = manifest.catalog.manufacturer;
    const normalizedManufacturer = normalizeManufacturerName(manufacturerName);

    const { data: existingMfg } = await admin
      .from("product_manufacturers")
      .select("id")
      .eq("normalized_name", normalizedManufacturer)
      .maybeSingle();

    const existingByCode = new Map<string, string>();
    if (existingMfg?.id) {
      const { data: products } = await admin
        .from("manufacturer_products")
        .select("id, normalized_source_code")
        .eq("manufacturer_id", existingMfg.id);
      for (const p of products ?? []) {
        if (p.normalized_source_code) existingByCode.set(p.normalized_source_code, p.id);
      }
    }

    const availableImages = new Set(opened.images.keys());
    const analysis = analyzeManifestItems(manifest, availableImages, existingByCode);

    const jobWarnings: string[] = [];
    if (analysis.unreferencedImages.length > 0) {
      jobWarnings.push(
        `${analysis.unreferencedImages.length} imagem(ns) em images/ não referenciada(s) pelo manifesto foram ignoradas.`,
      );
    }

    // Preparar linhas + bytes de imagem em memória; persistir só depois do cleanup.
    type Prepared = {
      row: Record<string, unknown>;
      uploads: { path: string; bytes: Uint8Array; contentType: string }[];
    };
    const prepared: Prepared[] = [];

    for (const a of analysis.analyzed) {
      const itemId = crypto.randomUUID();
      const mimeErrors: string[] = [];
      const uploads: Prepared["uploads"] = [];
      let primaryPath: string | null = null;
      const techPaths: string[] = [];

      const refsOkForRead = a.validationErrors.every(
        (e) => !e.includes("inexistente") && !e.includes("caminho inválido"),
      );

      if (refsOkForRead && a.item.primary_image) {
        const rel = imageRelFromManifest(a.item.primary_image);
        if (!rel) mimeErrors.push(`Imagem principal: caminho inválido`);
        else {
          try {
            const bytes = await opened.readImageBytes(rel);
            const check = await validateImageBytes(bytes, rel);
            if (!check.ok) mimeErrors.push(check.error);
            else {
              const path = `imports/${jobId}/items/${itemId}/primary.${check.ext}`;
              uploads.push({ path, bytes: check.bytes, contentType: check.mime });
              primaryPath = path;
            }
          } catch {
            mimeErrors.push(`Não foi possível ler a imagem principal: ${rel}`);
          }
        }
      }

      if (refsOkForRead) {
        for (const tech of a.item.technical_images) {
          const rel = imageRelFromManifest(tech);
          if (!rel) {
            mimeErrors.push(`Imagem técnica: caminho inválido`);
            continue;
          }
          try {
            const bytes = await opened.readImageBytes(rel);
            const check = await validateImageBytes(bytes, rel);
            if (!check.ok) {
              mimeErrors.push(check.error);
              continue;
            }
            const path = `imports/${jobId}/items/${itemId}/technical/${crypto.randomUUID()}.${check.ext}`;
            uploads.push({ path, bytes: check.bytes, contentType: check.mime });
            techPaths.push(path);
          } catch {
            mimeErrors.push(`Não foi possível ler a imagem técnica: ${rel}`);
          }
        }
      }

      const resolved = resolveValidationStatus({
        technicalErrors: [
          ...a.validationErrors.filter((e) => !e.includes("mesmo código")),
          ...mimeErrors,
        ],
        internalDuplicate: a.validationErrors.some((e) => e.includes("mesmo código normalizado")),
        existingProductId: a.duplicateProductId,
        aiReviewRequired: a.item.review_required === true,
        systemReviewRequired: a.validationWarnings.length > 0,
      });

      const finalErrors =
        mimeErrors.length > 0
          ? [...new Set([...a.validationErrors, ...mimeErrors])]
          : a.validationErrors;

      let status = resolved.status;
      let dupId = status === "duplicate" ? a.duplicateProductId : null;
      if (mimeErrors.length > 0) {
        status = "invalid";
        dupId = null;
      }

      prepared.push({
        uploads,
        row: {
          id: itemId,
          import_job_id: jobId,
          position: a.position,
          source_code: a.item.source_code,
          normalized_source_code: a.normalizedSourceCode,
          base_code: a.item.base_code,
          name: a.item.name,
          description: a.item.description,
          product_type: a.item.product_type,
          product_line: a.item.line,
          suggested_category: a.item.suggested_category,
          suggested_inventory_category: null,
          unit: a.unitMapped,
          source_page: a.item.source.page,
          source_excerpt: a.item.source.excerpt,
          primary_image_staging_path: primaryPath,
          technical_image_staging_paths: techPaths,
          attributes: a.item.attributes ?? [],
          observations: a.item.observations ?? [],
          ai_review_required: a.item.review_required === true,
          ai_warnings: a.item.warnings ?? [],
          validation_status: status,
          validation_errors: finalErrors,
          validation_warnings: a.validationWarnings,
          duplicate_product_id: dupId,
          raw_manifest_item: a.item,
        },
      });
    }

    const itemRows = prepared.map((p) => p.row);
    const finalCounts = {
      total_items: itemRows.length,
      valid_items: itemRows.filter((r) => r.validation_status === "valid").length,
      review_items: itemRows.filter((r) => r.validation_status === "review").length,
      duplicate_items: itemRows.filter((r) => r.validation_status === "duplicate").length,
      invalid_items: itemRows.filter((r) => r.validation_status === "invalid").length,
    };
    assertCountsInvariant(finalCounts);

    // Persistência controlada: limpa staging anterior → upload → insert → ready.
    await admin.from("catalog_import_items").delete().eq("import_job_id", jobId);
    await cleanupJobItemObjects(admin, bucket, jobId);

    for (const p of prepared) {
      for (const up of p.uploads) {
        const { error: upErr } = await admin.storage
          .from(bucket)
          .upload(up.path, Buffer.from(up.bytes), {
            contentType: up.contentType,
            upsert: false,
          });
        if (upErr) throw CatalogImportErrors.processingFailed();
      }
    }

    if (itemRows.length > 0) {
      const { error: insErr } = await admin.from("catalog_import_items").insert(itemRows);
      if (insErr) throw CatalogImportErrors.processingFailed();
    }

    const { error: updErr } = await admin
      .from("catalog_import_jobs")
      .update({
        status: "ready",
        manufacturer_name: manufacturerName,
        normalized_manufacturer_name: normalizedManufacturer,
        existing_manufacturer_id: existingMfg?.id ?? null,
        catalog_name: manifest.catalog.name,
        catalog_date: manifest.catalog.date,
        source_filename: manifest.catalog.source_filename,
        schema_version: manifest.schema_version,
        ...finalCounts,
        warnings: jobWarnings,
        error_message: null,
        error_code: null,
        processed_at: new Date().toISOString(),
      })
      .eq("id", jobId)
      .eq("status", "processing");

    if (updErr) throw CatalogImportErrors.processingFailed();
    markedReady = true;

    const zipCleanup = await removeStorageObjectBestEffort(admin, bucket, storagePath);
    if (!zipCleanup.removed) {
      jobWarnings.push("Limpeza do ZIP de origem falhou; o job permanece pronto.");
      try {
        await admin.from("catalog_import_jobs").update({ warnings: jobWarnings }).eq("id", jobId);
      } catch {
        /* best-effort */
      }
    }

    return {
      jobId,
      status: "ready",
      counts: finalCounts,
      manufacturerName,
      catalogName: manifest.catalog.name,
    };
  } catch (e) {
    const pub = asPublicError(e);
    if (!markedReady) {
      await admin
        .from("catalog_import_jobs")
        .update({
          status: "failed",
          error_code: pub.code,
          error_message: pub.message,
        })
        .eq("id", jobId)
        .eq("status", "processing");

      try {
        await admin.from("catalog_import_items").delete().eq("import_job_id", jobId);
      } catch {
        /* best-effort */
      }
      await cleanupJobItemObjects(admin, bucket, jobId);
      // Preferência de segurança: remover ZIP também em falha global.
      await removeStorageObjectBestEffort(admin, bucket, storagePath);
    }
    throw pub;
  } finally {
    if (opened) {
      try {
        opened.closeHandle();
      } catch {
        /* ignore */
      }
    }
    await ensureTempUnlinked(tmpPath);
  }
}
