/**
 * Validação pragmática de imagem:
 * - magic bytes (file-type)
 * - tamanho ≤ 5 MiB
 * - extensão coerente com MIME real (.jpg/.jpeg → jpeg, .png → png, .webp → webp)
 *
 * Limitação documentada: não decodifica pixels (sem biblioteca de decode).
 * Bytes corrompidos após a assinatura podem passar se o magic header for válido.
 */

import { fileTypeFromBuffer } from "file-type";
import { ALLOWED_IMAGE_MIME, IMAGE_MAX_BYTES, MIME_TO_EXT, type AllowedImageMime } from "./limits";

export type ImageValidationOk = {
  ok: true;
  mime: AllowedImageMime;
  ext: string;
  bytes: Uint8Array;
};

export type ImageValidationFail = {
  ok: false;
  error: string;
};

export async function validateImageBytes(
  bytes: Uint8Array,
  declaredPath: string,
): Promise<ImageValidationOk | ImageValidationFail> {
  if (bytes.byteLength === 0) {
    return { ok: false, error: `Imagem vazia: ${declaredPath}` };
  }
  if (bytes.byteLength > IMAGE_MAX_BYTES) {
    return { ok: false, error: `Imagem acima de 5 MB: ${declaredPath}` };
  }

  const detected = await fileTypeFromBuffer(bytes);
  if (!detected || !(ALLOWED_IMAGE_MIME as readonly string[]).includes(detected.mime)) {
    return {
      ok: false,
      error: `Formato de imagem inválido (apenas JPEG, PNG ou WebP): ${declaredPath}`,
    };
  }

  const mime = detected.mime as AllowedImageMime;
  const extFromPath = declaredPath.split(".").pop()?.toLowerCase() ?? "";
  const expected = MIME_TO_EXT[mime];
  const coherent =
    (mime === "image/jpeg" && (extFromPath === "jpg" || extFromPath === "jpeg")) ||
    (mime === "image/png" && extFromPath === "png") ||
    (mime === "image/webp" && extFromPath === "webp");

  if (!coherent) {
    return {
      ok: false,
      error: `Extensão incompatível com o conteúdo real da imagem: ${declaredPath}`,
    };
  }

  return { ok: true, mime, ext: expected, bytes };
}
