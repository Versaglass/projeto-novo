/**
 * Erros sanitizados para UI — sem stack, paths internos ou secrets.
 */

export class CatalogImportError extends Error {
  readonly code: string;
  readonly httpStatus: number;

  constructor(code: string, message: string, httpStatus = 400) {
    super(message);
    this.name = "CatalogImportError";
    this.code = code;
    this.httpStatus = httpStatus;
  }
}

export const CatalogImportErrors = {
  unauthorized: () =>
    new CatalogImportError(
      "unauthorized",
      "Apenas o Super Admin da plataforma pode importar catálogos.",
      403,
    ),
  zipTooLarge: () =>
    new CatalogImportError(
      "zip_too_large",
      "O arquivo ultrapassa o limite de 50 MB permitido para importação de catálogos.",
    ),
  invalidZip: () => new CatalogImportError("invalid_zip", "Arquivo ZIP inválido."),
  zipEncrypted: () =>
    new CatalogImportError(
      "zip_encrypted",
      "Arquivos ZIP protegidos por senha não são suportados.",
    ),
  zipSpecialEntry: () =>
    new CatalogImportError(
      "zip_special_entry",
      "O pacote contém entradas especiais (symlink ou dispositivo) que não são suportadas.",
    ),
  duplicateZipEntry: () =>
    new CatalogImportError(
      "duplicate_zip_entry",
      "O pacote contém entradas duplicadas ou ambíguas e não pode ser processado.",
    ),
  missingManifest: () =>
    new CatalogImportError("missing_manifest", "O pacote não contém manifest.json."),
  multipleManifests: () =>
    new CatalogImportError(
      "multiple_manifests",
      "O pacote contém mais de um manifest.json e não pode ser processado.",
    ),
  invalidJson: () =>
    new CatalogImportError("invalid_json", "O arquivo manifest.json não é um JSON válido."),
  unsupportedVersion: () =>
    new CatalogImportError("unsupported_version", "O catálogo usa uma versão não suportada."),
  schemaInvalid: () =>
    new CatalogImportError(
      "schema_invalid",
      "O manifesto não está de acordo com o contrato VersaGlass Catalog Import v1.",
    ),
  zipBomb: () =>
    new CatalogImportError(
      "zip_bomb",
      "Este arquivo ultrapassa o limite permitido de conteúdo descompactado.",
    ),
  imageTooLarge: () =>
    new CatalogImportError(
      "image_too_large",
      "Uma ou mais imagens ultrapassam o limite de 5 MB por arquivo.",
    ),
  tooManyEntries: () =>
    new CatalogImportError(
      "too_many_entries",
      "Este arquivo ultrapassa o limite permitido de entradas no ZIP.",
    ),
  tooManyItems: () =>
    new CatalogImportError(
      "too_many_items",
      "O catálogo ultrapassa o limite de 1.000 produtos por importação.",
    ),
  invalidPath: () =>
    new CatalogImportError(
      "invalid_path",
      "O pacote contém caminhos de arquivo inválidos ou inseguros.",
    ),
  invalidStructure: () =>
    new CatalogImportError(
      "invalid_structure",
      "A estrutura do pacote é inválida. Esperado: manifest.json e pasta images/.",
    ),
  objectMissing: () =>
    new CatalogImportError(
      "object_missing",
      "O arquivo ainda não está disponível no armazenamento. Conclua o upload e tente novamente.",
    ),
  alreadyProcessing: () =>
    new CatalogImportError("already_processing", "Este catálogo já está sendo processado.", 409),
  alreadyPublishing: () =>
    new CatalogImportError("already_publishing", "Este catálogo já está sendo publicado.", 409),
  alreadyReady: () =>
    new CatalogImportError(
      "already_ready",
      "Este catálogo já foi processado. Não é necessário processar novamente.",
      409,
    ),
  alreadyCompleted: () =>
    new CatalogImportError("already_completed", "Este catálogo já foi publicado.", 409),
  alreadyFailed: () =>
    new CatalogImportError(
      "already_failed",
      "Este processamento falhou anteriormente. Inicie uma nova importação.",
      409,
    ),
  publishNotReady: () =>
    new CatalogImportError(
      "publish_not_ready",
      "Ainda há itens pendentes de revisão ou nenhum item aprovado.",
    ),
  manufacturerUnresolved: () =>
    new CatalogImportError("manufacturer_unresolved", "Resolva o fabricante antes de publicar."),
  decisionNotAllowed: () =>
    new CatalogImportError(
      "decision_not_allowed",
      "Esta decisão não é permitida para o status técnico do item.",
    ),
  badJobState: () =>
    new CatalogImportError(
      "bad_job_state",
      "Este catálogo não está em um estado que permita processamento.",
    ),
  jobNotFound: () => new CatalogImportError("job_not_found", "Importação não encontrada.", 404),
  processingFailed: () =>
    new CatalogImportError(
      "processing_failed",
      "Não foi possível processar o catálogo. Tente novamente.",
      500,
    ),
  invalidFilename: () =>
    new CatalogImportError(
      "invalid_filename",
      "Selecione um arquivo .zip gerado pelo Kit para IA.",
    ),
} as const;

/** Interpreta status quando o claim atômico não obteve a linha. */
export function errorForUnclaimableJobStatus(status: string): CatalogImportError {
  switch (status) {
    case "processing":
      return CatalogImportErrors.alreadyProcessing();
    case "publishing":
      return CatalogImportErrors.alreadyPublishing();
    case "ready":
      return CatalogImportErrors.alreadyReady();
    case "completed":
      return CatalogImportErrors.alreadyCompleted();
    case "failed":
      return CatalogImportErrors.alreadyFailed();
    case "awaiting_upload":
      return CatalogImportErrors.badJobState();
    default:
      return CatalogImportErrors.badJobState();
  }
}

export function toPublicCatalogImportError(err: unknown): CatalogImportError {
  if (err instanceof CatalogImportError) return err;
  return CatalogImportErrors.processingFailed();
}
