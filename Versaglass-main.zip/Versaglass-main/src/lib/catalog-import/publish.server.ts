/**
 * Publicação Fase 3 (hardening) — orquestra Storage + RPC transacional.
 *
 * 1. claim ready→publishing
 * 2. intenção de fabricante (SEM criar product_manufacturers)
 * 3. soft-check de duplicidade só se manufacturer_id já conhecido
 * 4. gerar productIds + copiar imagens para products/{productId}/...
 * 5. RPC cria/reusa fabricante + produtos atomicamente
 * 6. RPC falha → remove TODAS imagens finais; job→ready
 * 7. RPC OK → remove só imagens de duplicate-at-publish; cleanup staging explícito
 */

import type { SupabaseClient } from "@supabase/supabase-js";
import { claimCatalogImportPublish } from "./claim-publish";
import { CatalogImportError, CatalogImportErrors } from "./errors";
import { CATALOG_IMPORT_STAGING_BUCKET } from "./limits";
import { normalizeManufacturerName, normalizeSourceCode } from "./normalize";
import {
  buildFinalPrimaryImagePath,
  buildFinalTechnicalImagePath,
  collectExplicitStagingPaths,
  countApproved,
  extFromStoragePath,
  finalPathsForDuplicateOutcomes,
  hasPendingPublishableItems,
  isManufacturerResolved,
  parsePublishRpcItems,
  resolveManufacturerPublishIntent,
} from "./review";

export const MANUFACTURER_CATALOG_BUCKET = "manufacturer-catalog" as const;

function asStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((v): v is string => typeof v === "string");
}

async function downloadStorageBytes(
  supabase: SupabaseClient,
  bucket: string,
  path: string,
): Promise<Uint8Array> {
  const { data, error } = await supabase.storage.from(bucket).download(path);
  if (error || !data) throw CatalogImportErrors.objectMissing();
  const ab = await data.arrayBuffer();
  return new Uint8Array(ab);
}

async function uploadFinalImage(
  supabase: SupabaseClient,
  path: string,
  bytes: Uint8Array,
  contentType: string,
): Promise<void> {
  const { error } = await supabase.storage.from(MANUFACTURER_CATALOG_BUCKET).upload(path, bytes, {
    contentType,
    upsert: false,
  });
  if (error) throw CatalogImportErrors.processingFailed();
}

function mimeFromExt(ext: string): string {
  if (ext === "jpg" || ext === "jpeg") return "image/jpeg";
  if (ext === "webp") return "image/webp";
  return "image/png";
}

/** Idempotente: remove em batches; arquivos já ausentes não falham o fluxo. */
export async function cleanupFinalPathsIdempotent(
  supabase: SupabaseClient,
  paths: string[],
): Promise<void> {
  const unique = [...new Set(paths.filter(Boolean))];
  for (let i = 0; i < unique.length; i += 50) {
    const chunk = unique.slice(i, i + 50);
    try {
      await supabase.storage.from(MANUFACTURER_CATALOG_BUCKET).remove(chunk);
    } catch {
      /* best-effort / idempotente */
    }
  }
}

/**
 * Cleanup staging por paths explícitos do DB (sem listagem recursiva de prefixo).
 * Idempotente: retry / arquivo já removido não desfaz publicação.
 */
export async function cleanupStagingByExplicitPaths(
  supabase: SupabaseClient,
  paths: string[],
): Promise<{ ok: boolean }> {
  try {
    const unique = [...new Set(paths.filter(Boolean))];
    for (let i = 0; i < unique.length; i += 50) {
      const chunk = unique.slice(i, i + 50);
      await supabase.storage.from(CATALOG_IMPORT_STAGING_BUCKET).remove(chunk);
    }
    return { ok: true };
  } catch {
    return { ok: false };
  }
}

export type PublishResult = {
  jobId: string;
  status: "completed";
  manufacturerId: string | null;
  manufacturerName: string | null;
  publishedCount: number;
  duplicatesAtPublish: number;
  totalItems: number;
  approvedItems: number;
  rejectedItems: number;
  duplicateItems: number;
  invalidItems: number;
  stagingCleanupOk: boolean;
};

async function countJobItemStats(
  supabase: SupabaseClient,
  jobId: string,
): Promise<{
  totalItems: number;
  approvedItems: number;
  rejectedItems: number;
  duplicateItems: number;
  invalidItems: number;
}> {
  const { data: items } = await supabase
    .from("catalog_import_items")
    .select("review_decision, validation_status")
    .eq("import_job_id", jobId);
  const list = items ?? [];
  return {
    totalItems: list.length,
    approvedItems: list.filter((i) => i.review_decision === "approved").length,
    rejectedItems: list.filter((i) => i.review_decision === "rejected").length,
    duplicateItems: list.filter((i) => i.validation_status === "duplicate").length,
    invalidItems: list.filter((i) => i.validation_status === "invalid").length,
  };
}

export async function publishCatalogImportJob(opts: {
  supabase: SupabaseClient;
  jobId: string;
  actorId: string;
}): Promise<PublishResult> {
  const { supabase, jobId, actorId } = opts;
  const preparedFinalPaths: string[] = [];
  const pathsByItemId = new Map<string, string[]>();
  let claimed = false;

  try {
    const job = await claimCatalogImportPublish(supabase, jobId);
    claimed = true;

    const { data: items, error: itemsErr } = await supabase
      .from("catalog_import_items")
      .select("*")
      .eq("import_job_id", jobId)
      .order("position", { ascending: true });
    if (itemsErr) throw CatalogImportErrors.processingFailed();

    const gateItems = (items ?? []).map((it) => ({
      validationStatus: it.validation_status as "valid" | "review" | "duplicate" | "invalid",
      reviewDecision: (it.review_decision ?? "pending") as "pending" | "approved" | "rejected",
    }));

    if (hasPendingPublishableItems(gateItems) || countApproved(gateItems) < 1) {
      throw CatalogImportErrors.publishNotReady();
    }
    if (
      !isManufacturerResolved(
        job.resolved_manufacturer_id as string | null,
        job.resolved_manufacturer_name as string | null,
        job.existing_manufacturer_id as string | null,
        job.manufacturer_name as string | null,
      )
    ) {
      throw CatalogImportErrors.manufacturerUnresolved();
    }

    const intent = resolveManufacturerPublishIntent(
      {
        resolved_manufacturer_id: job.resolved_manufacturer_id as string | null,
        resolved_manufacturer_name: job.resolved_manufacturer_name as string | null,
        existing_manufacturer_id: job.existing_manufacturer_id as string | null,
        manufacturer_name: job.manufacturer_name as string | null,
      },
      normalizeManufacturerName,
    );
    if (!intent) throw CatalogImportErrors.manufacturerUnresolved();

    // Soft-id conhecido SEM criar fabricante novo.
    // Para "new", lookup opcional por normalized_name (reuso se já existir).
    let knownMfgId: string | null = intent.kind === "existing" ? intent.manufacturerId : null;
    let knownMfgName: string | null = null;

    if (intent.kind === "existing") {
      const { data: mfg } = await supabase
        .from("product_manufacturers")
        .select("id, name")
        .eq("id", intent.manufacturerId)
        .maybeSingle();
      if (!mfg) throw CatalogImportErrors.manufacturerUnresolved();
      knownMfgId = mfg.id;
      knownMfgName = mfg.name;
    } else {
      const { data: existingByNorm } = await supabase
        .from("product_manufacturers")
        .select("id, name")
        .eq("normalized_name", intent.normalizedName)
        .maybeSingle();
      if (existingByNorm) {
        knownMfgId = existingByNorm.id;
        knownMfgName = existingByNorm.name;
      }
    }

    const approved = (items ?? []).filter(
      (it) =>
        it.review_decision === "approved" &&
        (it.validation_status === "valid" || it.validation_status === "review"),
    );
    if (approved.length === 0) throw CatalogImportErrors.publishNotReady();

    let softDupCount = 0;
    const toPublish: typeof approved = [];

    if (knownMfgId) {
      const { data: existingProducts } = await supabase
        .from("manufacturer_products")
        .select("id, normalized_source_code")
        .eq("manufacturer_id", knownMfgId);
      const globalByCode = new Map(
        (existingProducts ?? []).map((p) => [p.normalized_source_code as string, p.id as string]),
      );

      for (const it of approved) {
        const norm = normalizeSourceCode(String(it.source_code ?? ""));
        const existing = globalByCode.get(norm);
        if (existing) {
          await supabase
            .from("catalog_import_items")
            .update({
              validation_status: "duplicate",
              duplicate_product_id: existing,
              review_decision: "pending",
              published_product_id: null,
            })
            .eq("id", it.id);
          softDupCount += 1;
          continue;
        }
        toPublish.push(it);
      }
    } else {
      toPublish.push(...approved);
    }

    const stagingPaths = collectExplicitStagingPaths({
      jobId,
      storagePath: job.storage_path as string | null,
      items: items ?? [],
    });

    // Todos approved já existiam — completar SEM criar fabricante novo e SEM RPC.
    if (toPublish.length === 0) {
      const stats = await countJobItemStats(supabase, jobId);
      await supabase
        .from("catalog_import_jobs")
        .update({
          status: "completed",
          published_items: 0,
          duplicates_at_publish: softDupCount,
          approved_items: stats.approvedItems,
          rejected_items: stats.rejectedItems,
          completed_at: new Date().toISOString(),
          completed_by: actorId,
          ...(knownMfgId
            ? {
                resolved_manufacturer_id: knownMfgId,
                resolved_manufacturer_name: knownMfgName,
              }
            : {}),
          error_code: null,
          error_message: null,
        })
        .eq("id", jobId);

      const cleanup = await cleanupStagingByExplicitPaths(supabase, stagingPaths);
      return {
        jobId,
        status: "completed",
        manufacturerId: knownMfgId,
        manufacturerName: knownMfgName,
        publishedCount: 0,
        duplicatesAtPublish: softDupCount,
        totalItems: stats.totalItems,
        approvedItems: stats.approvedItems,
        rejectedItems: stats.rejectedItems,
        duplicateItems: stats.duplicateItems,
        invalidItems: stats.invalidItems,
        stagingCleanupOk: cleanup.ok,
      };
    }

    const productPayload: Record<string, unknown>[] = [];

    for (const it of toPublish) {
      const productId = crypto.randomUUID();
      const itemPaths: string[] = [];
      const ext = extFromStoragePath(it.primary_image_staging_path as string | null);
      let primaryPath: string | null = null;
      const techPaths: string[] = [];

      if (it.primary_image_staging_path) {
        const bytes = await downloadStorageBytes(
          supabase,
          CATALOG_IMPORT_STAGING_BUCKET,
          it.primary_image_staging_path as string,
        );
        primaryPath = buildFinalPrimaryImagePath(productId, ext);
        await uploadFinalImage(supabase, primaryPath, bytes, mimeFromExt(ext));
        preparedFinalPaths.push(primaryPath);
        itemPaths.push(primaryPath);
      }

      for (const tech of asStringArray(it.technical_image_staging_paths)) {
        const tExt = extFromStoragePath(tech);
        const bytes = await downloadStorageBytes(supabase, CATALOG_IMPORT_STAGING_BUCKET, tech);
        const tPath = buildFinalTechnicalImagePath(productId, crypto.randomUUID(), tExt);
        await uploadFinalImage(supabase, tPath, bytes, mimeFromExt(tExt));
        preparedFinalPaths.push(tPath);
        itemPaths.push(tPath);
        techPaths.push(tPath);
      }

      pathsByItemId.set(it.id as string, itemPaths);

      productPayload.push({
        staging_item_id: it.id,
        product_id: productId,
        source_code: it.source_code,
        normalized_source_code: normalizeSourceCode(String(it.source_code ?? "")),
        base_code: it.base_code,
        name: it.name,
        description: it.description,
        product_type: it.product_type,
        product_line: it.product_line,
        suggested_category: it.suggested_category,
        inventory_category: it.inventory_category,
        unit: it.unit,
        primary_image_path: primaryPath,
        technical_image_paths: techPaths,
        attributes: it.attributes ?? [],
        observations: it.observations ?? [],
        source_catalog_name: job.catalog_name,
        source_catalog_date: job.catalog_date,
        source_page: it.source_page,
        source_excerpt: it.source_excerpt,
      });
    }

    // RPC: cria/reusa fabricante + inserts. NÃO criamos fabricante aqui.
    const rpcArgs =
      intent.kind === "existing"
        ? {
            p_job_id: jobId,
            p_manufacturer_id: intent.manufacturerId,
            p_new_manufacturer_name: null as string | null,
            p_new_manufacturer_normalized_name: null as string | null,
            p_products: productPayload,
          }
        : {
            p_job_id: jobId,
            // Se soft-lookup achou existente, passa id; RPC ainda valida via job (novo nome).
            // Preferência: job tem resolved_manufacturer_name → RPC cria/reusa por normalized.
            p_manufacturer_id: null as string | null,
            p_new_manufacturer_name: intent.name,
            p_new_manufacturer_normalized_name: intent.normalizedName,
            p_products: productPayload,
          };

    // Se intent new mas soft-lookup achou mfg e job ainda não tem resolved id,
    // a RPC segue pelo ramo resolved_manufacturer_name / manufacturer_name (INSERT ON CONFLICT).
    // Se intent existing, RPC usa resolved/existing id do job.

    const { data: rpcResult, error: rpcErr } = await supabase.rpc(
      "publish_catalog_import_batch",
      rpcArgs,
    );

    if (rpcErr) throw CatalogImportErrors.processingFailed();

    const outcomes = parsePublishRpcItems(rpcResult);
    const orphanPaths = finalPathsForDuplicateOutcomes(outcomes, pathsByItemId);
    await cleanupFinalPathsIdempotent(supabase, orphanPaths);

    const publishedCount =
      typeof rpcResult === "object" &&
      rpcResult &&
      typeof (rpcResult as { published_count?: number }).published_count === "number"
        ? (rpcResult as { published_count: number }).published_count
        : outcomes.filter((o) => o.outcome === "published").length;

    const rpcDupCount =
      typeof rpcResult === "object" &&
      rpcResult &&
      typeof (rpcResult as { duplicates_at_publish?: number }).duplicates_at_publish === "number"
        ? (rpcResult as { duplicates_at_publish: number }).duplicates_at_publish
        : outcomes.filter((o) => o.outcome === "duplicate").length;

    const duplicatesAtPublish = softDupCount + rpcDupCount;

    // Soft-dups já contados no staging; se houve soft + rpc, atualizar contagem no job
    if (softDupCount > 0) {
      await supabase
        .from("catalog_import_jobs")
        .update({ duplicates_at_publish: duplicatesAtPublish })
        .eq("id", jobId);
    }

    const manufacturerId =
      typeof rpcResult === "object" &&
      rpcResult &&
      typeof (rpcResult as { manufacturer_id?: string }).manufacturer_id === "string"
        ? (rpcResult as { manufacturer_id: string }).manufacturer_id
        : knownMfgId;

    const manufacturerName =
      typeof rpcResult === "object" &&
      rpcResult &&
      typeof (rpcResult as { manufacturer_name?: string }).manufacturer_name === "string"
        ? (rpcResult as { manufacturer_name: string }).manufacturer_name
        : knownMfgName;

    const readNum = (key: string, fallback: number) =>
      typeof rpcResult === "object" &&
      rpcResult &&
      typeof (rpcResult as Record<string, unknown>)[key] === "number"
        ? ((rpcResult as Record<string, unknown>)[key] as number)
        : fallback;

    const statsFallback = await countJobItemStats(supabase, jobId);

    const cleanup = await cleanupStagingByExplicitPaths(supabase, stagingPaths);

    return {
      jobId,
      status: "completed",
      manufacturerId,
      manufacturerName,
      publishedCount,
      duplicatesAtPublish,
      totalItems: readNum("total_items", statsFallback.totalItems),
      approvedItems: readNum("approved_items", statsFallback.approvedItems),
      rejectedItems: readNum("rejected_items", statsFallback.rejectedItems),
      duplicateItems: readNum("duplicate_items", statsFallback.duplicateItems),
      invalidItems: readNum("invalid_items", statsFallback.invalidItems),
      stagingCleanupOk: cleanup.ok,
    };
  } catch (e) {
    await cleanupFinalPathsIdempotent(supabase, preparedFinalPaths);
    if (claimed) {
      const pub = e instanceof CatalogImportError ? e : CatalogImportErrors.processingFailed();
      await supabase
        .from("catalog_import_jobs")
        .update({
          status: "ready",
          error_code: pub.code,
          error_message: pub.message,
        })
        .eq("id", jobId)
        .eq("status", "publishing");
      throw pub;
    }
    throw e instanceof CatalogImportError ? e : CatalogImportErrors.processingFailed();
  }
}
