import type { Database } from "@/integrations/supabase/types";

type InventoryUnit = Database["public"]["Enums"]["inventory_unit"];

/**
 * Somente mapeamentos inequívocos para inventory_unit.
 * Valores comerciais ambíguos ("peça", "par", "metro linear") → null + review.
 */
const UNIT_MAP: Record<string, InventoryUnit> = {
  m: "m",
  m2: "m2",
  "m²": "m2",
  un: "un",
  und: "un",
  kg: "kg",
  pc: "pc",
  pç: "pc",
  cx: "cx",
};

export const UNIT_UNMAPPED_WARNING =
  "Unidade do manifesto não mapeada automaticamente; escolha a unidade na revisão.";

/**
 * Converte unidade do manifesto para inventory_unit somente com correspondência inequívoca.
 * Valor original permanece em raw_manifest_item — não invalidar o item só por unidade.
 */
export function mapManifestUnit(raw: string | null | undefined): InventoryUnit | null {
  if (raw == null) return null;
  const key = raw.trim().toLowerCase();
  if (!key) return null;
  return UNIT_MAP[key] ?? null;
}

/** true quando há texto de unidade no manifesto mas sem mapeamento inequívoco. */
export function isUnmappedManifestUnit(raw: string | null | undefined): boolean {
  if (raw == null) return false;
  const key = raw.trim();
  if (!key) return false;
  return mapManifestUnit(key) == null;
}
