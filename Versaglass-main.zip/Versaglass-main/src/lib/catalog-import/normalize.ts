/**
 * VersaGlass Catalog Import — contrato e helpers da Fase 1.
 *
 * Normalização determinística de fabricante e source_code.
 * Usada futuramente pelos ServerFns de criação/importação de
 * `product_manufacturers` / `manufacturer_products`.
 * NÃO confiar em valores normalizados vindos da IA.
 */

export const CATALOG_IMPORT_SCHEMA_VERSION = "1.0" as const;

export const CATALOG_IMPORT_KIT_FILENAME = "versaglass-kit-para-ia-v1.zip";

/** Remove acentos, lower-case, colapsa whitespace — base compartilhada. */
export function foldCatalogText(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Normaliza nome de fabricante para unicidade global (`normalized_name`).
 * Ex.: "AL  Indústria" → "al industria"
 */
export function normalizeManufacturerName(name: string): string {
  return foldCatalogText(name);
}

/**
 * Normaliza código original do fabricante (`normalized_source_code`).
 * Remove espaços extras e unifica separadores leves; preserva letras/dígitos.
 * Ex.: "AL  1629-JB" → "al 1629 jb"
 */
export function normalizeSourceCode(sourceCode: string): string {
  return foldCatalogText(sourceCode)
    .replace(/[_./\\-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
