export {
  CATALOG_IMPORT_KIT_FILENAME,
  CATALOG_IMPORT_SCHEMA_VERSION,
  foldCatalogText,
  normalizeManufacturerName,
  normalizeSourceCode,
} from "./normalize";

export {
  CATALOG_IMPORT_KIT_FILES,
  buildCatalogImportKitZip,
  buildZipStore,
  bytesToBase64,
} from "./kit-builder";

export { CATALOG_IMPORT_ACCESS_MATRIX, isPlatformAdminRole } from "./access";

export {
  ZIP_MAX_SIZE_BYTES,
  ZIP_UI_LIMIT_LABEL,
  MANIFEST_MAX_ITEMS,
  CATALOG_IMPORT_STAGING_BUCKET,
} from "./limits";

export { resolveValidationStatus, countByStatus } from "./status";
export { analyzeManifestItems } from "./analyze-items";
export { classifyZipEntryPath } from "./path-safety";
export { canApproveItem, canEnablePublish, isEligibleForApproveAll } from "./review";

/**
 * Revisão/publicação (manufacturer_*) e adoção → inventory_items
 * vivem nos módulos de import/review/publish e manufacturer-catalog.
 */
