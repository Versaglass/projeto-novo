/**
 * ServerFns Fase 3 — revisão, decisão, fabricante, publicação.
 */

import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { CatalogImportErrors, toPublicCatalogImportError } from "@/lib/catalog-import/errors";
import { normalizeSourceCode } from "@/lib/catalog-import/normalize";
import {
  assertDecisionAllowed,
  buildCatalogImportPublishedAuditMetadata,
  canEnablePublish,
  isEligibleForApproveAll,
  isManufacturerResolved,
  jobAllowsReviewMutation,
  type ReviewDecision,
} from "@/lib/catalog-import/review";
import { resolveValidationStatus, type ValidationStatus } from "@/lib/catalog-import/status";

async function assertPlatformAdmin(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  supabase: { rpc: (...args: any[]) => any },
  userId: string,
): Promise<void> {
  const { data: isAdmin, error } = await supabase.rpc("has_role", {
    _user_id: userId,
    _role: "admin",
  });
  if (error || !isAdmin) throw CatalogImportErrors.unauthorized();
}

function asStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((v): v is string => typeof v === "string");
}

const INVENTORY_UNITS = ["m", "m2", "un", "kg", "pc", "cx"] as const;
const INVENTORY_CATEGORIES = [
  "aluminio",
  "vidro",
  "ferragem",
  "acessorio",
  "perfil",
  "led",
  "cola",
  "outros",
  "aco_metalon",
  "chapa_aco",
  "solda",
  "mdf",
  "ferragem_moveis",
  "fita_borda",
  "marmore",
  "quartzo",
  "porcelanato",
] as const;

async function requireReadyJob(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  supabase: any,
  jobId: string,
) {
  const { data: job, error } = await supabase
    .from("catalog_import_jobs")
    .select("*")
    .eq("id", jobId)
    .maybeSingle();
  if (error || !job) throw CatalogImportErrors.jobNotFound();
  // publishing / completed / processing: nenhuma mutação de revisão
  if (!jobAllowsReviewMutation(String(job.status))) throw CatalogImportErrors.badJobState();
  return job;
}

async function refreshJobDecisionCounts(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  supabase: any,
  jobId: string,
) {
  const { data: items } = await supabase
    .from("catalog_import_items")
    .select("review_decision, validation_status")
    .eq("import_job_id", jobId);
  const list = items ?? [];
  const approved_items = list.filter(
    (i: { review_decision: string }) => i.review_decision === "approved",
  ).length;
  const rejected_items = list.filter(
    (i: { review_decision: string }) => i.review_decision === "rejected",
  ).length;
  await supabase
    .from("catalog_import_jobs")
    .update({ approved_items, rejected_items })
    .eq("id", jobId);
}

const UpdateItemInput = z.object({
  jobId: z.string().uuid(),
  itemId: z.string().uuid(),
  source_code: z.string().trim().min(1).max(120),
  base_code: z.string().trim().max(120).nullable().optional(),
  name: z.string().trim().min(1).max(200),
  description: z.string().trim().max(4000).nullable().optional(),
  product_line: z.string().trim().max(120).nullable().optional(),
  inventory_category: z.enum(INVENTORY_CATEGORIES).nullable().optional(),
  unit: z.enum(INVENTORY_UNITS).nullable().optional(),
});

export const updateCatalogImportItem = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => UpdateItemInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertPlatformAdmin(context.supabase, context.userId);
    await requireReadyJob(context.supabase, data.jobId);

    const { data: item, error } = await context.supabase
      .from("catalog_import_items")
      .select("*")
      .eq("id", data.itemId)
      .eq("import_job_id", data.jobId)
      .maybeSingle();
    if (error || !item) throw CatalogImportErrors.jobNotFound();

    const normalized = normalizeSourceCode(data.source_code);

    // Duplicidade interna
    const { data: siblings } = await context.supabase
      .from("catalog_import_items")
      .select("id, normalized_source_code")
      .eq("import_job_id", data.jobId)
      .neq("id", data.itemId);
    const internalDup = (siblings ?? []).some((s) => s.normalized_source_code === normalized);

    // Duplicidade global (se fabricante conhecido)
    const { data: job } = await context.supabase
      .from("catalog_import_jobs")
      .select(
        "existing_manufacturer_id, resolved_manufacturer_id, manufacturer_name, normalized_manufacturer_name",
      )
      .eq("id", data.jobId)
      .maybeSingle();

    const mfgId = job?.resolved_manufacturer_id ?? job?.existing_manufacturer_id ?? null;
    let existingProductId: string | null = null;
    if (mfgId && !internalDup) {
      const { data: prod } = await context.supabase
        .from("manufacturer_products")
        .select("id")
        .eq("manufacturer_id", mfgId)
        .eq("normalized_source_code", normalized)
        .maybeSingle();
      existingProductId = prod?.id ?? null;
    }

    // Preservar erros técnicos anteriores (imagens etc.) que não são de código
    const prevErrors = asStringArray(item.validation_errors).filter(
      (e) => !e.includes("mesmo código") && !e.includes("Já existe"),
    );
    const resolved = resolveValidationStatus({
      technicalErrors: prevErrors,
      internalDuplicate: internalDup,
      existingProductId,
      aiReviewRequired: item.ai_review_required === true,
      systemReviewRequired: asStringArray(item.validation_warnings).length > 0,
    });

    // Se estava approved e virou invalid/duplicate → reset decision
    let reviewDecision = item.review_decision as ReviewDecision;
    if (
      reviewDecision === "approved" &&
      (resolved.status === "invalid" || resolved.status === "duplicate")
    ) {
      reviewDecision = "pending";
    }

    const { error: updErr } = await context.supabase
      .from("catalog_import_items")
      .update({
        source_code: data.source_code.trim(),
        normalized_source_code: normalized,
        base_code: data.base_code ?? null,
        name: data.name.trim(),
        description: data.description ?? null,
        product_line: data.product_line ?? null,
        inventory_category: data.inventory_category ?? null,
        unit: data.unit ?? null,
        validation_status: resolved.status,
        validation_errors: resolved.errors,
        duplicate_product_id: resolved.status === "duplicate" ? existingProductId : null,
        review_decision: reviewDecision,
        // raw_manifest_item NÃO é alterado
      })
      .eq("id", data.itemId)
      .eq("import_job_id", data.jobId);

    if (updErr) throw CatalogImportErrors.processingFailed();
    await refreshJobDecisionCounts(context.supabase, data.jobId);
    return { ok: true as const, validationStatus: resolved.status, reviewDecision };
  });

const DecisionInput = z.object({
  jobId: z.string().uuid(),
  itemId: z.string().uuid(),
  decision: z.enum(["approved", "rejected", "pending"]),
});

export const setCatalogImportItemDecision = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => DecisionInput.parse(d))
  .handler(async ({ data, context }) => {
    try {
      await assertPlatformAdmin(context.supabase, context.userId);
      await requireReadyJob(context.supabase, data.jobId);

      const { data: item, error } = await context.supabase
        .from("catalog_import_items")
        .select("id, validation_status, review_decision")
        .eq("id", data.itemId)
        .eq("import_job_id", data.jobId)
        .maybeSingle();
      if (error || !item) throw CatalogImportErrors.jobNotFound();

      try {
        assertDecisionAllowed(
          item.validation_status as ValidationStatus,
          data.decision as ReviewDecision,
        );
      } catch {
        throw CatalogImportErrors.decisionNotAllowed();
      }

      const { error: updErr } = await context.supabase
        .from("catalog_import_items")
        .update({
          review_decision: data.decision,
          reviewed_by: context.userId,
          reviewed_at: new Date().toISOString(),
        })
        .eq("id", data.itemId)
        .eq("import_job_id", data.jobId);
      if (updErr) throw CatalogImportErrors.processingFailed();

      await refreshJobDecisionCounts(context.supabase, data.jobId);
      return { ok: true as const };
    } catch (e) {
      throw toPublicCatalogImportError(e);
    }
  });

const JobIdInput = z.object({ jobId: z.string().uuid() });

export const approveReadyCatalogImportItems = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => JobIdInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertPlatformAdmin(context.supabase, context.userId);
    await requireReadyJob(context.supabase, data.jobId);

    const { data: items, error } = await context.supabase
      .from("catalog_import_items")
      .select("id, validation_status, review_decision")
      .eq("import_job_id", data.jobId);
    if (error) throw CatalogImportErrors.processingFailed();

    const ids = (items ?? [])
      .filter((it) =>
        isEligibleForApproveAll({
          validationStatus: it.validation_status as ValidationStatus,
          reviewDecision: (it.review_decision ?? "pending") as ReviewDecision,
        }),
      )
      .map((it) => it.id as string);

    if (ids.length > 0) {
      const { error: updErr } = await context.supabase
        .from("catalog_import_items")
        .update({
          review_decision: "approved",
          reviewed_by: context.userId,
          reviewed_at: new Date().toISOString(),
        })
        .in("id", ids)
        .eq("import_job_id", data.jobId);
      if (updErr) throw CatalogImportErrors.processingFailed();
    }

    await refreshJobDecisionCounts(context.supabase, data.jobId);
    return { ok: true as const, approvedCount: ids.length };
  });

const ResolveMfgInput = z.object({
  jobId: z.string().uuid(),
  mode: z.enum(["existing", "new"]),
  manufacturerId: z.string().uuid().optional(),
  manufacturerName: z.string().trim().min(1).max(120).optional(),
});

export const resolveCatalogImportManufacturer = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ResolveMfgInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertPlatformAdmin(context.supabase, context.userId);
    await requireReadyJob(context.supabase, data.jobId);

    if (data.mode === "existing") {
      if (!data.manufacturerId) throw CatalogImportErrors.manufacturerUnresolved();
      const { data: mfg, error } = await context.supabase
        .from("product_manufacturers")
        .select("id, name")
        .eq("id", data.manufacturerId)
        .maybeSingle();
      if (error || !mfg) throw CatalogImportErrors.manufacturerUnresolved();

      await context.supabase
        .from("catalog_import_jobs")
        .update({
          resolved_manufacturer_id: mfg.id,
          resolved_manufacturer_name: mfg.name,
        })
        .eq("id", data.jobId);

      return { ok: true as const, manufacturerId: mfg.id, manufacturerName: mfg.name };
    }

    const name = data.manufacturerName?.trim();
    if (!name) throw CatalogImportErrors.manufacturerUnresolved();

    await context.supabase
      .from("catalog_import_jobs")
      .update({
        resolved_manufacturer_id: null,
        resolved_manufacturer_name: name,
      })
      .eq("id", data.jobId);

    return { ok: true as const, manufacturerId: null, manufacturerName: name };
  });

export const listProductManufacturersForImport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertPlatformAdmin(context.supabase, context.userId);
    const { data, error } = await context.supabase
      .from("product_manufacturers")
      .select("id, name, normalized_name, active")
      .order("name", { ascending: true })
      .limit(500);
    if (error) throw CatalogImportErrors.processingFailed();
    return data ?? [];
  });

export const getCatalogImportPublishGate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => JobIdInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertPlatformAdmin(context.supabase, context.userId);
    const { data: job, error } = await context.supabase
      .from("catalog_import_jobs")
      .select(
        "id, status, manufacturer_name, existing_manufacturer_id, resolved_manufacturer_id, resolved_manufacturer_name, approved_items, rejected_items, valid_items, review_items, duplicate_items, invalid_items",
      )
      .eq("id", data.jobId)
      .maybeSingle();
    if (error || !job) throw CatalogImportErrors.jobNotFound();

    const { data: items } = await context.supabase
      .from("catalog_import_items")
      .select("validation_status, review_decision")
      .eq("import_job_id", data.jobId);

    const gateItems = (items ?? []).map((it) => ({
      validationStatus: it.validation_status as ValidationStatus,
      reviewDecision: (it.review_decision ?? "pending") as ReviewDecision,
    }));

    const manufacturerResolved = isManufacturerResolved(
      job.resolved_manufacturer_id,
      job.resolved_manufacturer_name,
      job.existing_manufacturer_id,
      job.manufacturer_name,
    );

    return {
      canPublish: canEnablePublish({
        jobStatus: job.status,
        manufacturerResolved,
        items: gateItems,
      }),
      manufacturerResolved,
      approvedCount: gateItems.filter((i) => i.reviewDecision === "approved").length,
      pendingPublishable: gateItems.filter(
        (i) =>
          (i.validationStatus === "valid" || i.validationStatus === "review") &&
          i.reviewDecision === "pending",
      ).length,
    };
  });

export const publishCatalogImport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => JobIdInput.parse(d))
  .handler(async ({ data, context }) => {
    try {
      await assertPlatformAdmin(context.supabase, context.userId);

      const { publishCatalogImportJob } = await import("@/lib/catalog-import/publish.server");
      const result = await publishCatalogImportJob({
        supabase: context.supabase as never,
        jobId: data.jobId,
        actorId: context.userId,
      });

      try {
        const ingest = await import("@/lib/log-ingest.server");
        await ingest.writeAuditLog({
          actorId: context.userId,
          actorEmail: typeof context.claims?.email === "string" ? context.claims.email : null,
          action: "catalog_import_published",
          entity: "catalog_import_jobs",
          entityId: data.jobId,
          metadata: buildCatalogImportPublishedAuditMetadata({
            jobId: data.jobId,
            manufacturerId: result.manufacturerId,
            manufacturerName: result.manufacturerName,
            totalItems: result.totalItems,
            approvedItems: result.approvedItems,
            rejectedItems: result.rejectedItems,
            publishedItems: result.publishedCount,
            duplicateItems: result.duplicateItems,
            duplicatesAtPublish: result.duplicatesAtPublish,
            invalidItems: result.invalidItems,
            cleanupWarning: !result.stagingCleanupOk,
          }),
        });
      } catch {
        /* best-effort */
      }

      return result;
    } catch (e) {
      throw toPublicCatalogImportError(e);
    }
  });

export { INVENTORY_CATEGORIES, INVENTORY_UNITS };
