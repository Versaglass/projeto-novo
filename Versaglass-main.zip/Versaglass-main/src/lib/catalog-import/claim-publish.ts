/**
 * Claim atômico ready → publishing.
 */

import type { SupabaseClient } from "@supabase/supabase-js";
import { CatalogImportErrors, errorForUnclaimableJobStatus } from "./errors";

export async function claimCatalogImportPublish(
  supabase: SupabaseClient,
  jobId: string,
): Promise<Record<string, unknown>> {
  const { data: claimed, error } = await supabase
    .from("catalog_import_jobs")
    .update({
      status: "publishing",
      error_message: null,
      error_code: null,
    })
    .eq("id", jobId)
    .eq("status", "ready")
    .select("*")
    .maybeSingle();

  if (error) throw CatalogImportErrors.processingFailed();
  if (claimed) return claimed as Record<string, unknown>;

  const { data: existing, error: selErr } = await supabase
    .from("catalog_import_jobs")
    .select("id, status")
    .eq("id", jobId)
    .maybeSingle();

  if (selErr) throw CatalogImportErrors.processingFailed();
  if (!existing) throw CatalogImportErrors.jobNotFound();

  const st = existing.status as string;
  throw errorForUnclaimableJobStatus(st === "ready" ? "awaiting_upload" : st);
}

export function simulateExclusivePublishClaim(
  currentStatus: string,
): { ok: true; next: "publishing" } | { ok: false; reason: string } {
  if (currentStatus === "ready") return { ok: true, next: "publishing" };
  return { ok: false, reason: currentStatus };
}
