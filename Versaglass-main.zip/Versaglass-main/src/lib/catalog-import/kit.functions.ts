import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  CATALOG_IMPORT_KIT_FILENAME,
  CATALOG_IMPORT_SCHEMA_VERSION,
} from "@/lib/catalog-import/normalize";

export type CatalogImportKitDownload = {
  filename: string;
  schemaVersion: typeof CATALOG_IMPORT_SCHEMA_VERSION;
  contentBase64: string;
  mimeType: "application/zip";
};

/**
 * Download do Kit para IA — exclusivo Super Admin de plataforma
 * (`has_role(..., 'admin')` ≡ `is_platform_admin`).
 *
 * Company admin (`company_members.role = 'admin'`) NÃO passa.
 */
export const downloadCatalogImportKit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<CatalogImportKitDownload> => {
    const { data: isAdmin, error: roleErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (roleErr) throw new Error(roleErr.message);
    if (!isAdmin) {
      throw new Error("Apenas o Super Admin da plataforma pode baixar o Kit para IA.");
    }

    const { buildCatalogImportKitZip, bytesToBase64 } =
      await import("@/lib/catalog-import/kit-builder");
    const zip = buildCatalogImportKitZip();

    return {
      filename: CATALOG_IMPORT_KIT_FILENAME,
      schemaVersion: CATALOG_IMPORT_SCHEMA_VERSION,
      contentBase64: bytesToBase64(zip),
      mimeType: "application/zip",
    };
  });
