/**
 * Upload TUS direto ao Supabase Storage (browser → Storage, sem Vercel).
 */

import * as tus from "tus-js-client";
import { CATALOG_IMPORT_STAGING_BUCKET } from "./limits";

export type TusUploadProgress = {
  bytesUploaded: number;
  bytesTotal: number;
  percentage: number;
};

function storageProjectHost(supabaseUrl: string): string {
  // https://xyz.supabase.co → https://xyz.storage.supabase.co
  try {
    const u = new URL(supabaseUrl);
    if (u.hostname.endsWith(".supabase.co") && !u.hostname.includes(".storage.")) {
      const ref = u.hostname.split(".")[0];
      return `https://${ref}.storage.supabase.co`;
    }
    // local / custom: use same origin + /storage/v1/upload/resumable via supabase URL
    return supabaseUrl.replace(/\/$/, "");
  } catch {
    return supabaseUrl.replace(/\/$/, "");
  }
}

export function buildResumableEndpoint(supabaseUrl: string): string {
  const host = storageProjectHost(supabaseUrl);
  if (host.includes(".storage.supabase.co")) {
    return `${host}/storage/v1/upload/resumable`;
  }
  return `${host}/storage/v1/upload/resumable`;
}

export async function uploadCatalogZipWithTus(opts: {
  file: File;
  storagePath: string;
  accessToken: string;
  supabaseUrl: string;
  bucket?: string;
  onProgress?: (p: TusUploadProgress) => void;
  signal?: AbortSignal;
}): Promise<void> {
  const bucket = opts.bucket ?? CATALOG_IMPORT_STAGING_BUCKET;
  const endpoint = buildResumableEndpoint(opts.supabaseUrl);

  await new Promise<void>((resolve, reject) => {
    const upload = new tus.Upload(opts.file, {
      endpoint,
      retryDelays: [0, 3000, 5000, 10000, 20000],
      headers: {
        authorization: `Bearer ${opts.accessToken}`,
        // Path já é único por jobId; false evita sobrescrita acidental.
        "x-upsert": "false",
      },
      uploadDataDuringCreation: true,
      removeFingerprintOnSuccess: true,
      chunkSize: 6 * 1024 * 1024,
      metadata: {
        bucketName: bucket,
        // EXATAMENTE o path retornado por createCatalogImportJob — não reconstruir.
        objectName: opts.storagePath,
        contentType: "application/zip",
        cacheControl: "3600",
      },
      onError: (error) => reject(error),
      onProgress: (bytesUploaded, bytesTotal) => {
        opts.onProgress?.({
          bytesUploaded,
          bytesTotal,
          percentage: bytesTotal ? (bytesUploaded / bytesTotal) * 100 : 0,
        });
      },
      onSuccess: () => resolve(),
    });

    if (opts.signal) {
      const onAbort = () => {
        void upload.abort(true).then(() => reject(new Error("Upload cancelado.")));
      };
      if (opts.signal.aborted) onAbort();
      else opts.signal.addEventListener("abort", onAbort, { once: true });
    }

    upload.start();
  });
}
