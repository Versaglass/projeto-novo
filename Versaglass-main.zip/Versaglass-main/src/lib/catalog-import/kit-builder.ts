/**
 * Montagem determinística do Kit para IA.
 * Os arquivos-fonte vivem em `./kit/` versionados no repositório.
 * Não monta o contrato a partir de dados arbitrários do cliente.
 */

import promptIa from "./kit/PROMPT_IA.md?raw";
import regras from "./kit/REGRAS_IMPORTADOR.md?raw";
import schemaJson from "./kit/versaglass-catalog-import-v1.schema.json?raw";
import exampleManifest from "./kit/example-manifest.json?raw";
import { buildZipStore, bytesToBase64, type KitFile } from "./kit-builder-core";

export type { KitFile };
export { buildZipStore, bytesToBase64 };

export const CATALOG_IMPORT_KIT_FILES: readonly KitFile[] = [
  { path: "PROMPT_IA.md", content: promptIa },
  { path: "REGRAS_IMPORTADOR.md", content: regras },
  { path: "versaglass-catalog-import-v1.schema.json", content: schemaJson },
  { path: "example-manifest.json", content: exampleManifest },
] as const;

export function buildCatalogImportKitZip(): Uint8Array {
  return buildZipStore(CATALOG_IMPORT_KIT_FILES);
}
