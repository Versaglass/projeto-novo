/**
 * Precedência determinística de validation_status (única fonte).
 *
 * 1. erro técnico → invalid
 * 2. duplicidade no próprio arquivo → invalid
 * 3. já existe no catálogo global → duplicate
 * 4. ai_review_required OU warning de sistema que exige ação → review
 * 5. caso contrário → valid
 */

export type ValidationStatus = "valid" | "review" | "duplicate" | "invalid";

export type StatusInput = {
  technicalErrors: string[];
  internalDuplicate: boolean;
  existingProductId: string | null;
  aiReviewRequired: boolean;
  /** Warnings do importador (não da IA) que exigem revisão humana. */
  systemReviewRequired?: boolean;
};

export function resolveValidationStatus(input: StatusInput): {
  status: ValidationStatus;
  errors: string[];
} {
  const errors = [...input.technicalErrors];

  if (input.internalDuplicate) {
    errors.push("Há outro item neste catálogo com o mesmo código normalizado.");
  }

  if (errors.length > 0) {
    return { status: "invalid", errors };
  }

  if (input.existingProductId) {
    return { status: "duplicate", errors: [] };
  }

  if (input.aiReviewRequired || input.systemReviewRequired) {
    return { status: "review", errors: [] };
  }

  return { status: "valid", errors: [] };
}

export type JobStatus =
  | "awaiting_upload"
  | "processing"
  | "ready"
  | "failed"
  | "completed"
  | "cancelled";

export function countByStatus(statuses: ValidationStatus[]): {
  total_items: number;
  valid_items: number;
  review_items: number;
  duplicate_items: number;
  invalid_items: number;
} {
  const counts = {
    total_items: statuses.length,
    valid_items: 0,
    review_items: 0,
    duplicate_items: 0,
    invalid_items: 0,
  };
  for (const s of statuses) {
    if (s === "valid") counts.valid_items++;
    else if (s === "review") counts.review_items++;
    else if (s === "duplicate") counts.duplicate_items++;
    else counts.invalid_items++;
  }
  return counts;
}

/** Invariante: total = soma das quatro categorias (sem dupla contagem). */
export function assertCountsInvariant(counts: {
  total_items: number;
  valid_items: number;
  review_items: number;
  duplicate_items: number;
  invalid_items: number;
}): void {
  const sum =
    counts.valid_items + counts.review_items + counts.duplicate_items + counts.invalid_items;
  if (counts.total_items !== sum) {
    throw new Error("catalog_import counts invariant violated");
  }
}
