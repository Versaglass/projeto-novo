/**
 * Asserções comportamentais: limite individual de imagem (5 MiB).
 * npx tsx src/lib/catalog-import/phase2.image-limits.assert.ts
 */

import assert from "node:assert/strict";
import { mkdtemp, readFile, unlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { CatalogImportError } from "./errors";
import { validateImageBytes } from "./image-validate";
import { IMAGE_MAX_BYTES, UNCOMPRESSED_MAX_BYTES, ZIP_MAX_ENTRIES } from "./limits";
import { openCatalogZip } from "./zip-stream";

function crcTable() {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
}
const CRC_TABLE = crcTable();
function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]!) & 0xff]! ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

type ZipEntrySpec = {
  name: string;
  data: Buffer;
  /** Se definido, grava este valor no header (pode mentir vs data.length). */
  declaredUncompressed?: number;
  declaredCompressed?: number;
};

/** ZIP store-only; permite mentir tamanhos declarados (validateEntrySizes:false). */
function buildStoreZip(entries: ZipEntrySpec[]): Buffer {
  const parts: Buffer[] = [];
  const central: Buffer[] = [];
  let offset = 0;

  for (const e of entries) {
    const nameBuf = Buffer.from(e.name, "utf8");
    const crc = crc32(e.data);
    const declaredUnc = e.declaredUncompressed ?? e.data.length;
    const declaredComp = e.declaredCompressed ?? e.data.length;
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0, 6);
    local.writeUInt16LE(0, 8); // store
    local.writeUInt16LE(0, 10);
    local.writeUInt16LE(0, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(declaredComp, 18);
    local.writeUInt32LE(declaredUnc, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    local.writeUInt16LE(0, 28);

    const localOffset = offset;
    parts.push(local, nameBuf, e.data);
    offset += local.length + nameBuf.length + e.data.length;

    const cen = Buffer.alloc(46);
    cen.writeUInt32LE(0x02014b50, 0);
    cen.writeUInt16LE(20, 4);
    cen.writeUInt16LE(20, 6);
    cen.writeUInt16LE(0, 8);
    cen.writeUInt16LE(0, 10);
    cen.writeUInt16LE(0, 12);
    cen.writeUInt16LE(0, 14);
    cen.writeUInt32LE(crc, 16);
    cen.writeUInt32LE(declaredComp, 20);
    cen.writeUInt32LE(declaredUnc, 24);
    cen.writeUInt16LE(nameBuf.length, 28);
    cen.writeUInt16LE(0, 30);
    cen.writeUInt16LE(0, 32);
    cen.writeUInt16LE(0, 34);
    cen.writeUInt16LE(0, 36);
    cen.writeUInt32LE(0, 38);
    cen.writeUInt32LE(localOffset, 42);
    central.push(cen, nameBuf);
  }

  const centralStart = offset;
  const centralBuf = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(centralBuf.length, 12);
  end.writeUInt32LE(centralStart, 16);
  end.writeUInt16LE(0, 20);

  return Buffer.concat([...parts, centralBuf, end]);
}

const TINY_PNG = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
  "base64",
);

function pngSized(byteLength: number): Buffer {
  assert.ok(byteLength >= TINY_PNG.length);
  const out = Buffer.alloc(byteLength);
  TINY_PNG.copy(out);
  return out;
}

function isImageTooLarge(e: unknown): boolean {
  return e instanceof CatalogImportError && e.code === "image_too_large";
}

function isZipBomb(e: unknown): boolean {
  return e instanceof CatalogImportError && e.code === "zip_bomb";
}

const MANIFEST = JSON.stringify({
  schema_version: "1.0",
  catalog: {
    manufacturer: "AL",
    name: "Cat",
    date: "2022-06",
    source_filename: "a.pdf",
    language: "pt-BR",
  },
  generated_by: { type: "ai", name: "t" },
  items: [
    {
      source_code: "AL 1",
      base_code: "1",
      name: "Item",
      description: null,
      product_type: "product",
      line: null,
      suggested_category: "Puxadores",
      unit: "un",
      source: { page: 1, excerpt: "x" },
      primary_image: "images/primary.png",
      technical_images: ["images/tech.png"],
      attributes: [],
      observations: [],
      review_required: false,
      warnings: [],
    },
  ],
});

async function run() {
  // B) readImageBytes nunca usa UNCOMPRESSED_MAX_BYTES como limite de imagem
  const zipSrc = await readFile(new URL("./zip-stream.ts", import.meta.url), "utf8");
  assert.ok(
    /readEntryBuffer\(\s*zip,\s*entry,\s*IMAGE_MAX_BYTES/.test(zipSrc),
    "readImageBytes deve passar IMAGE_MAX_BYTES a readEntryBuffer",
  );
  assert.ok(
    !/readEntryBuffer\(\s*zip,\s*entry,\s*UNCOMPRESSED_MAX_BYTES/.test(zipSrc),
    "readImageBytes não pode usar UNCOMPRESSED_MAX_BYTES",
  );

  const dir = await mkdtemp(join(tmpdir(), "vg-img-lim-"));

  // A + E: primary_image declarada IMAGE_MAX_BYTES + 1 → rejeição no walk (antes de ler)
  {
    const zipPath = join(dir, "primary-over.zip");
    const over = pngSized(IMAGE_MAX_BYTES + 1);
    await writeFile(
      zipPath,
      buildStoreZip([
        { name: "manifest.json", data: Buffer.from(MANIFEST) },
        { name: "images/primary.png", data: over },
        { name: "images/tech.png", data: TINY_PNG },
      ]),
    );
    await assert.rejects(() => openCatalogZip(zipPath), isImageTooLarge);
    await unlink(zipPath).catch(() => undefined);
  }

  // F: technical_image declarada IMAGE_MAX_BYTES + 1 → mesma regra
  {
    const zipPath = join(dir, "tech-over.zip");
    const over = pngSized(IMAGE_MAX_BYTES + 1);
    await writeFile(
      zipPath,
      buildStoreZip([
        { name: "manifest.json", data: Buffer.from(MANIFEST) },
        { name: "images/primary.png", data: TINY_PNG },
        { name: "images/tech.png", data: over },
      ]),
    );
    await assert.rejects(() => openCatalogZip(zipPath), isImageTooLarge);
    await unlink(zipPath).catch(() => undefined);
  }

  // C: metadata subdeclarado (unc ≤ IMAGE_MAX) mas stream maior → abort no hard cap
  {
    const zipPath = join(dir, "lie-stream.zip");
    const actual = pngSized(IMAGE_MAX_BYTES + 1);
    await writeFile(
      zipPath,
      buildStoreZip([
        { name: "manifest.json", data: Buffer.from(MANIFEST) },
        {
          name: "images/primary.png",
          data: actual,
          declaredUncompressed: IMAGE_MAX_BYTES,
          declaredCompressed: IMAGE_MAX_BYTES + 1,
        },
        { name: "images/tech.png", data: TINY_PNG },
      ]),
    );
    const opened = await openCatalogZip(zipPath);
    try {
      await assert.rejects(() => opened.readImageBytes("images/primary.png"), isImageTooLarge);
    } finally {
      opened.closeHandle();
      await unlink(zipPath).catch(() => undefined);
    }
  }

  // D: exatamente IMAGE_MAX_BYTES + MIME/ext válidos → aceita
  {
    const zipPath = join(dir, "exact-max.zip");
    const exact = pngSized(IMAGE_MAX_BYTES);
    await writeFile(
      zipPath,
      buildStoreZip([
        { name: "manifest.json", data: Buffer.from(MANIFEST) },
        { name: "images/primary.png", data: exact },
        { name: "images/tech.png", data: TINY_PNG },
      ]),
    );
    const opened = await openCatalogZip(zipPath);
    try {
      const bytes = await opened.readImageBytes("images/primary.png");
      assert.equal(bytes.byteLength, IMAGE_MAX_BYTES);
      const check = await validateImageBytes(bytes, "images/primary.png");
      assert.equal(check.ok, true);
      const tech = await opened.readImageBytes("images/tech.png");
      assert.ok((await validateImageBytes(tech, "images/tech.png")).ok);
    } finally {
      opened.closeHandle();
      await unlink(zipPath).catch(() => undefined);
    }
  }

  // G: UNCOMPRESSED_MAX_BYTES protege o total do ZIP independentemente do limite individual
  {
    const zipPath = join(dir, "bomb-total.zip");
    // N entradas com declaredUncompressed = IMAGE_MAX (cada uma ≤ limite individual)
    // até a soma > UNCOMPRESSED_MAX — data mínima em disco (declared mentiroso).
    const per = IMAGE_MAX_BYTES;
    const need = Math.ceil((UNCOMPRESSED_MAX_BYTES + 1) / per);
    assert.ok(need > 1);
    assert.ok(need + 1 <= ZIP_MAX_ENTRIES);
    const entries: ZipEntrySpec[] = [{ name: "manifest.json", data: Buffer.from(MANIFEST) }];
    for (let i = 0; i < need; i++) {
      entries.push({
        name: `images/pad-${i}.png`,
        data: TINY_PNG,
        declaredUncompressed: per,
        declaredCompressed: TINY_PNG.length,
      });
    }
    await writeFile(zipPath, buildStoreZip(entries));
    await assert.rejects(() => openCatalogZip(zipPath), isZipBomb);
    await unlink(zipPath).catch(() => undefined);
  }

  // Imagem não referenciada oversized: walk ainda rejeita (sem bufferizar conteúdo)
  {
    const zipPath = join(dir, "unref-over.zip");
    const over = pngSized(IMAGE_MAX_BYTES + 1);
    const manifestNoImg = MANIFEST.replace(
      '"primary_image": "images/primary.png"',
      '"primary_image": null',
    ).replace('"technical_images": ["images/tech.png"]', '"technical_images": []');
    await writeFile(
      zipPath,
      buildStoreZip([
        { name: "manifest.json", data: Buffer.from(manifestNoImg) },
        { name: "images/orphan.png", data: over },
      ]),
    );
    await assert.rejects(() => openCatalogZip(zipPath), isImageTooLarge);
    await unlink(zipPath).catch(() => undefined);
  }

  console.log("catalog-import phase2.image-limits.assert: OK");
}

run().catch((e) => {
  console.error(e);
  process.exit(1);
});
