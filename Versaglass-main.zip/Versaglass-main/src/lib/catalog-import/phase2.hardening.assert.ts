/**
 * Asserções de hardening Fase 2 (offline).
 * npx tsx src/lib/catalog-import/phase2.hardening.assert.ts
 */

import assert from "node:assert/strict";
import { mkdtemp, readFile, unlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { analyzeManifestItems } from "./analyze-items";
import { simulateExclusiveClaim } from "./claim-job";
import { CatalogImportErrors, errorForUnclaimableJobStatus } from "./errors";
import { sanitizeOriginalFilename } from "./filename";
import { validateImageBytes } from "./image-validate";
import {
  classifyZipEntryPath,
  isAllowedStagingImagePath,
  normalizeZipEntryName,
  zipPathCaseKey,
} from "./path-safety";
import { assertCountsInvariant, countByStatus, resolveValidationStatus } from "./status";
import {
  acceptChunkWithinLimit,
  assertZipMagic,
  buildCatalogImportTempPath,
  ensureTempUnlinked,
  looksLikeZipMagic,
} from "./temp-zip";
import { mapManifestUnit, UNIT_UNMAPPED_WARNING } from "./unit-map";
import { classifyUnixEntryKind, entryIsEncrypted, entryIsForbiddenSpecial } from "./zip-entry-meta";
import { openCatalogZip } from "./zip-stream";
import type { CatalogManifest } from "./manifest-validate";

function crcTable() {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
}
const CRC_TABLE = crcTable();
function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]!) & 0xff]! ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

type ZipEntrySpec = {
  name: string;
  data: Buffer;
  encrypted?: boolean;
  /** Unix mode (e.g. 0o120777 symlink). When set, versionMadeBy = Unix. */
  unixMode?: number;
};

/** ZIP store-only mínimo para fixtures. */
function buildStoreZip(entries: ZipEntrySpec[]): Buffer {
  const parts: Buffer[] = [];
  const central: Buffer[] = [];
  let offset = 0;

  for (const e of entries) {
    const nameBuf = Buffer.from(e.name, "utf8");
    const gp = e.encrypted ? 1 : 0;
    const crc = crc32(e.data);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(gp, 6);
    local.writeUInt16LE(0, 8); // store
    local.writeUInt16LE(0, 10);
    local.writeUInt16LE(0, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(e.data.length, 18);
    local.writeUInt32LE(e.data.length, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    local.writeUInt16LE(0, 28);

    const localOffset = offset;
    parts.push(local, nameBuf, e.data);
    offset += local.length + nameBuf.length + e.data.length;

    const cen = Buffer.alloc(46);
    const versionMadeBy = e.unixMode != null ? 0x0314 : 20;
    const external = e.unixMode != null ? (e.unixMode & 0xffff) << 16 : 0;
    cen.writeUInt32LE(0x02014b50, 0);
    cen.writeUInt16LE(versionMadeBy, 4);
    cen.writeUInt16LE(20, 6);
    cen.writeUInt16LE(gp, 8);
    cen.writeUInt16LE(0, 10);
    cen.writeUInt16LE(0, 12);
    cen.writeUInt16LE(0, 14);
    cen.writeUInt32LE(crc, 16);
    cen.writeUInt32LE(e.data.length, 20);
    cen.writeUInt32LE(e.data.length, 24);
    cen.writeUInt16LE(nameBuf.length, 28);
    cen.writeUInt16LE(0, 30);
    cen.writeUInt16LE(0, 32);
    cen.writeUInt16LE(0, 34);
    cen.writeUInt16LE(0, 36);
    cen.writeUInt32LE(external >>> 0, 38);
    cen.writeUInt32LE(localOffset, 42);
    central.push(cen, nameBuf);
  }

  const centralStart = offset;
  const centralBuf = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(centralBuf.length, 12);
  end.writeUInt32LE(centralStart, 16);
  end.writeUInt16LE(0, 20);

  return Buffer.concat([...parts, centralBuf, end]);
}

const TINY_PNG = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
  "base64",
);

// Minimal JPEG header (not full decode) — enough for file-type
const TINY_JPEG = Buffer.from([
  0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
  0x00, 0x01, 0x00, 0x00, 0xff, 0xd9,
]);

function baseItem(over: Partial<CatalogManifest["items"][0]> = {}): CatalogManifest["items"][0] {
  return {
    source_code: "AL 1",
    base_code: "1",
    name: "Item",
    description: null,
    product_type: "product",
    line: null,
    suggested_category: "Puxadores",
    unit: "un",
    source: { page: 1, excerpt: "x" },
    primary_image: null,
    technical_images: [],
    attributes: [],
    observations: [],
    review_required: false,
    warnings: [],
    ...over,
  };
}

function baseManifest(items: CatalogManifest["items"]): CatalogManifest {
  return {
    schema_version: "1.0",
    catalog: {
      manufacturer: "AL",
      name: "Cat",
      date: "2022-06",
      source_filename: "a.pdf",
      language: "pt-BR",
    },
    generated_by: { type: "ai", name: "t" },
    items,
  };
}

async function run() {
  // --- Claim / concurrency ---
  assert.deepEqual(simulateExclusiveClaim("awaiting_upload"), {
    ok: true,
    next: "processing",
  });
  assert.equal(simulateExclusiveClaim("processing").ok, false);
  assert.equal(simulateExclusiveClaim("ready").ok, false);
  assert.equal(errorForUnclaimableJobStatus("processing").code, "already_processing");
  assert.equal(errorForUnclaimableJobStatus("ready").code, "already_ready");
  assert.equal(errorForUnclaimableJobStatus("failed").code, "already_failed");
  assert.equal(errorForUnclaimableJobStatus("completed").code, "already_completed");

  // Two sequential claims simulation
  let st = "awaiting_upload";
  const c1 = simulateExclusiveClaim(st);
  assert.equal(c1.ok, true);
  st = c1.ok ? c1.next : st;
  const c2 = simulateExclusiveClaim(st);
  assert.equal(c2.ok, false);

  // --- Path normalization / collisions ---
  assert.equal(normalizeZipEntryName("images//a.png"), "images/a.png");
  assert.equal(normalizeZipEntryName("images/./a.png"), "images/a.png");
  assert.equal(normalizeZipEntryName("images\\a.png"), "images/a.png");
  assert.equal(classifyZipEntryPath("images//a.png").kind, "image");
  assert.equal(
    (classifyZipEntryPath("images//a.png") as { relative: string }).relative,
    "images/a.png",
  );
  assert.equal(zipPathCaseKey("images/Produto.png"), zipPathCaseKey("images/produto.png"));

  // --- Signed URL allowlist ---
  const jobId = "11111111-1111-1111-1111-111111111111";
  const allowed = new Set([`imports/${jobId}/items/aaa/primary.png`]);
  assert.equal(
    isAllowedStagingImagePath(jobId, `imports/${jobId}/items/aaa/primary.png`, allowed),
    true,
  );
  assert.equal(
    isAllowedStagingImagePath(jobId, `imports/${jobId}/items/bbb/primary.png`, allowed),
    false,
  );
  assert.equal(
    isAllowedStagingImagePath(
      jobId,
      `imports/22222222-2222-2222-2222-222222222222/items/aaa/primary.png`,
      allowed,
    ),
    false,
  );

  // --- Filename sanitization ---
  assert.ok(!sanitizeOriginalFilename("evil\u0000name.zip").includes("\u0000"));
  assert.ok(!buildCatalogImportTempPath(jobId).includes("catalogo-versaglass.zip"));

  // --- Byte limit stream ---
  const over = acceptChunkWithinLimit(50 * 1024 * 1024 - 10, 20);
  assert.equal(over.ok, false);
  assert.equal(acceptChunkWithinLimit(100, 50).ok, true);

  // --- ZIP magic ---
  assert.equal(looksLikeZipMagic(Buffer.from([0x50, 0x4b, 0x03, 0x04])), true);
  assert.equal(looksLikeZipMagic(Buffer.from("HTML")), false);
  assert.throws(
    () => assertZipMagic(Buffer.from("<!DOCTYPE")),
    (e) => {
      return e instanceof Error && (e as { code?: string }).code === "invalid_zip";
    },
  );

  // --- Unit: unknown → review, not invalid ---
  assert.equal(mapManifestUnit("peça"), null);
  assert.equal(mapManifestUnit("par"), null);
  assert.equal(mapManifestUnit("pc"), "pc");
  const unitM = baseManifest([baseItem({ unit: "peça", warnings: ["ai note"] })]);
  const unitA = analyzeManifestItems(unitM, new Set(), new Map());
  assert.equal(unitA.analyzed[0]!.validationStatus, "review");
  assert.ok(unitA.analyzed[0]!.validationWarnings.includes(UNIT_UNMAPPED_WARNING));
  assert.deepEqual(unitA.analyzed[0]!.item.warnings, ["ai note"]);

  // --- Status precedence with system review ---
  assert.equal(
    resolveValidationStatus({
      technicalErrors: [],
      internalDuplicate: false,
      existingProductId: null,
      aiReviewRequired: false,
      systemReviewRequired: true,
    }).status,
    "review",
  );
  assert.equal(
    resolveValidationStatus({
      technicalErrors: [],
      internalDuplicate: false,
      existingProductId: "x",
      aiReviewRequired: false,
      systemReviewRequired: true,
    }).status,
    "duplicate",
  );

  // --- Counts invariant ---
  const counts = countByStatus(["valid", "review", "duplicate", "invalid", "valid"]);
  assertCountsInvariant(counts);
  assert.throws(() =>
    assertCountsInvariant({
      total_items: 3,
      valid_items: 1,
      review_items: 0,
      duplicate_items: 0,
      invalid_items: 0,
    }),
  );

  // --- Image MIME/extension ---
  const jpegOk = await validateImageBytes(TINY_JPEG, "images/a.jpeg");
  assert.equal(jpegOk.ok, true);
  const jpegJpg = await validateImageBytes(TINY_JPEG, "images/a.jpg");
  assert.equal(jpegJpg.ok, true);
  const pngAsJpegName = await validateImageBytes(TINY_JPEG, "images/a.png");
  assert.equal(pngAsJpegName.ok, false);
  const pngOk = await validateImageBytes(TINY_PNG, "images/a.png");
  assert.equal(pngOk.ok, true);

  // --- Entry meta: encryption / symlink ---
  assert.equal(
    entryIsEncrypted({
      fileName: "x",
      generalPurposeBitFlag: 1,
      versionMadeBy: 20,
      externalFileAttributes: 0,
    }),
    true,
  );
  assert.equal(
    classifyUnixEntryKind({
      fileName: "link",
      generalPurposeBitFlag: 0,
      versionMadeBy: 0x0314,
      externalFileAttributes: (0o120777 & 0xffff) << 16,
    }),
    "symlink",
  );
  assert.equal(
    entryIsForbiddenSpecial({
      fileName: "link",
      generalPurposeBitFlag: 0,
      versionMadeBy: 0x0314,
      externalFileAttributes: (0o120777 & 0xffff) << 16,
    }),
    true,
  );

  // --- Real ZIP fixtures via yauzl ---
  const dir = await mkdtemp(join(tmpdir(), "vg-hard-"));
  const goodManifest = JSON.stringify(
    baseManifest([baseItem({ primary_image: "images/a.png", unit: "un" })]),
  );

  // Encrypted entry
  {
    const zipPath = join(dir, "enc.zip");
    await writeFile(
      zipPath,
      buildStoreZip([
        { name: "manifest.json", data: Buffer.from(goodManifest), encrypted: true },
        { name: "images/a.png", data: TINY_PNG },
      ]),
    );
    await assert.rejects(
      () => openCatalogZip(zipPath),
      (e: unknown) => {
        return e instanceof Error && (e as { code?: string }).code === "zip_encrypted";
      },
    );
    // openCatalogZip may leave file; ensure path still there for unlink
    await unlink(zipPath).catch(() => undefined);
  }

  // Truncated / corrupt
  {
    const zipPath = join(dir, "trunc.zip");
    const full = buildStoreZip([
      { name: "manifest.json", data: Buffer.from(goodManifest) },
      { name: "images/a.png", data: TINY_PNG },
    ]);
    await writeFile(zipPath, full.subarray(0, 20));
    await assert.rejects(
      () => openCatalogZip(zipPath),
      (e: unknown) => {
        return e instanceof Error && (e as { code?: string }).code === "invalid_zip";
      },
    );
    await unlink(zipPath).catch(() => undefined);
  }

  // Duplicate entries (same name twice)
  {
    const zipPath = join(dir, "dup.zip");
    await writeFile(
      zipPath,
      buildStoreZip([
        { name: "manifest.json", data: Buffer.from(goodManifest) },
        { name: "images/a.png", data: TINY_PNG },
        { name: "images/a.png", data: TINY_PNG },
      ]),
    );
    await assert.rejects(
      () => openCatalogZip(zipPath),
      (e: unknown) => {
        return e instanceof Error && (e as { code?: string }).code === "duplicate_zip_entry";
      },
    );
    await unlink(zipPath).catch(() => undefined);
  }

  // Path equivalents colliding after normalize — two raw names → same relative
  // (images/./a.png vs images/a.png) — both become images/a.png
  {
    const zipPath = join(dir, "norm-dup.zip");
    await writeFile(
      zipPath,
      buildStoreZip([
        { name: "manifest.json", data: Buffer.from(goodManifest) },
        { name: "images/./a.png", data: TINY_PNG },
        { name: "images/a.png", data: TINY_PNG },
      ]),
    );
    await assert.rejects(
      () => openCatalogZip(zipPath),
      (e: unknown) => {
        return e instanceof Error && (e as { code?: string }).code === "duplicate_zip_entry";
      },
    );
    await unlink(zipPath).catch(() => undefined);
  }

  // Case-insensitive collision
  {
    const zipPath = join(dir, "case.zip");
    await writeFile(
      zipPath,
      buildStoreZip([
        { name: "manifest.json", data: Buffer.from(goodManifest) },
        { name: "images/Produto.png", data: TINY_PNG },
        { name: "images/produto.png", data: TINY_PNG },
      ]),
    );
    await assert.rejects(
      () => openCatalogZip(zipPath),
      (e: unknown) => {
        return e instanceof Error && (e as { code?: string }).code === "duplicate_zip_entry";
      },
    );
    await unlink(zipPath).catch(() => undefined);
  }

  // Symlink special entry
  {
    const zipPath = join(dir, "link.zip");
    await writeFile(
      zipPath,
      buildStoreZip([
        { name: "manifest.json", data: Buffer.from(goodManifest) },
        {
          name: "images/a.png",
          data: Buffer.from("not-a-real-target"),
          unixMode: 0o120777,
        },
      ]),
    );
    await assert.rejects(
      () => openCatalogZip(zipPath),
      (e: unknown) => {
        return e instanceof Error && (e as { code?: string }).code === "zip_special_entry";
      },
    );
    await unlink(zipPath).catch(() => undefined);
  }

  // Double manifest
  {
    const zipPath = join(dir, "mm.zip");
    await writeFile(
      zipPath,
      buildStoreZip([
        { name: "manifest.json", data: Buffer.from(goodManifest) },
        { name: "manifest.json", data: Buffer.from(goodManifest) },
      ]),
    );
    await assert.rejects(
      () => openCatalogZip(zipPath),
      (e: unknown) => {
        return e instanceof Error && (e as { code?: string }).code === "multiple_manifests";
      },
    );
    await unlink(zipPath).catch(() => undefined);
  }

  // Non-zip content
  {
    const zipPath = join(dir, "html.zip");
    await writeFile(zipPath, Buffer.from("<html>nope</html>"));
    // assertZipMagic path is in temp-zip; openCatalogZip fails invalid
    await assert.rejects(() => openCatalogZip(zipPath));
    await unlink(zipPath).catch(() => undefined);
  }

  // Temp cleanup on error path
  {
    const tmpPath = join(dir, "to-clean.zip");
    await writeFile(tmpPath, Buffer.from("x"));
    await ensureTempUnlinked(tmpPath);
    await assert.rejects(() => readFile(tmpPath));
  }

  // Good zip opens
  {
    const zipPath = join(dir, "good.zip");
    await writeFile(
      zipPath,
      buildStoreZip([
        { name: "manifest.json", data: Buffer.from(goodManifest) },
        { name: "images/a.png", data: TINY_PNG },
      ]),
    );
    const opened = await openCatalogZip(zipPath);
    assert.ok(opened.images.has("images/a.png"));
    opened.closeHandle();
    await unlink(zipPath).catch(() => undefined);
  }

  // CatalogImportErrors.zipEncrypted message
  assert.match(CatalogImportErrors.zipEncrypted().message, /senha/);

  console.log("catalog-import phase2.hardening.assert: OK");
}

run().catch((e) => {
  console.error(e);
  process.exit(1);
});
