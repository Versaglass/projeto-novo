/**
 * Hardening Fase 3 — integridade da publicação (offline).
 * npx tsx src/lib/catalog-import/phase3.hardening.assert.ts
 */

import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { normalizeManufacturerName } from "./normalize";
import {
  buildCatalogImportPublishedAuditMetadata,
  buildFinalPrimaryImagePath,
  buildFinalTechnicalImagePath,
  collectExplicitStagingPaths,
  finalPathsForDuplicateOutcomes,
  jobAllowsReviewMutation,
  parsePublishRpcItems,
  resolveManufacturerPublishIntent,
  type PublishItemOutcome,
} from "./review";

const here = dirname(fileURLToPath(import.meta.url));

function run() {
  // 1. Novo fabricante NÃO é criado antes da RPC (ausência de insert no ServerFn)
  const publishSrc = readFileSync(join(here, "publish.server.ts"), "utf8");
  assert.ok(!publishSrc.includes('.from("product_manufacturers")\n        .insert('));
  assert.ok(!publishSrc.includes('.from("product_manufacturers").insert('));
  assert.ok(!/product_manufacturers[\s\S]{0,80}\.insert\(/.test(publishSrc));
  assert.ok(publishSrc.includes("publish_catalog_import_batch"));
  assert.ok(
    publishSrc.includes("products/${") || publishSrc.includes("buildFinalPrimaryImagePath"),
  );

  // 2–3. Intenção: existing vs new (sem criar)
  const existing = resolveManufacturerPublishIntent(
    {
      resolved_manufacturer_id: "mfg-1",
      resolved_manufacturer_name: null,
      existing_manufacturer_id: null,
      manufacturer_name: "AL",
    },
    normalizeManufacturerName,
  );
  assert.deepEqual(existing, { kind: "existing", manufacturerId: "mfg-1" });

  const neu = resolveManufacturerPublishIntent(
    {
      resolved_manufacturer_id: null,
      resolved_manufacturer_name: "AL Indústria",
      existing_manufacturer_id: null,
      manufacturer_name: "outro",
    },
    normalizeManufacturerName,
  );
  assert.equal(neu?.kind, "new");
  if (neu?.kind === "new") {
    assert.equal(neu.name, "AL Indústria");
    assert.equal(neu.normalizedName, normalizeManufacturerName("AL Indústria"));
  }

  // 5–7. Paths sem manufacturerId; orphan cleanup só duplicate
  assert.equal(buildFinalPrimaryImagePath("p1", "png"), "products/p1/primary.png");
  assert.equal(buildFinalTechnicalImagePath("p1", "t1", "jpg"), "products/p1/technical/t1.jpg");
  assert.ok(!buildFinalPrimaryImagePath("p1", "png").includes("source_code"));

  const pathsByItem = new Map<string, string[]>([
    ["item-pub", ["products/prod-a/primary.png"]],
    ["item-dup", ["products/prod-b/primary.png", "products/prod-b/technical/x.jpg"]],
  ]);
  const outcomes: PublishItemOutcome[] = [
    { import_item_id: "item-pub", outcome: "published", product_id: "prod-a" },
    { import_item_id: "item-dup", outcome: "duplicate", duplicate_product_id: "existing-9" },
  ];
  const orphans = finalPathsForDuplicateOutcomes(outcomes, pathsByItem);
  assert.deepEqual(orphans, ["products/prod-b/primary.png", "products/prod-b/technical/x.jpg"]);
  assert.ok(!orphans.includes("products/prod-a/primary.png"));

  // 8. RPC failure → limpar todos os preparados (conceito)
  const allPrepared = ["products/a/primary.png", "products/b/primary.png"];
  assert.equal(allPrepared.length, 2);

  // 9–12. Parse RPC + published_product_id só em published
  const parsed = parsePublishRpcItems({
    items: [
      { import_item_id: "i1", outcome: "published", product_id: "p1" },
      { import_item_id: "i2", outcome: "duplicate", duplicate_product_id: "d2" },
    ],
    published_count: 1,
    duplicates_at_publish: 1,
  });
  assert.equal(parsed.filter((x) => x.outcome === "published").length, 1);
  assert.equal(parsed.filter((x) => x.outcome === "duplicate").length, 1);
  const pub = parsed.find((x) => x.outcome === "published");
  assert.ok(pub && pub.outcome === "published" && pub.product_id === "p1");
  const dup = parsed.find((x) => x.outcome === "duplicate");
  assert.ok(dup && dup.outcome === "duplicate" && dup.duplicate_product_id === "d2");

  // Todos approved → duplicate-at-publish ⇒ published 0
  const allDupOutcomes: PublishItemOutcome[] = [
    { import_item_id: "a", outcome: "duplicate", duplicate_product_id: "x" },
    { import_item_id: "b", outcome: "duplicate", duplicate_product_id: "y" },
  ];
  assert.equal(allDupOutcomes.filter((o) => o.outcome === "published").length, 0);
  assert.equal(allDupOutcomes.filter((o) => o.outcome === "duplicate").length, 2);

  // 13–14. Staging cleanup explícito + só paths do job
  const jobId = "11111111-1111-1111-1111-111111111111";
  const staging = collectExplicitStagingPaths({
    jobId,
    storagePath: `imports/${jobId}/source.zip`,
    items: [
      {
        primary_image_staging_path: `imports/${jobId}/items/aaa/primary.png`,
        technical_image_staging_paths: [`imports/${jobId}/items/aaa/technical/t1.jpg`],
      },
      {
        // path de outro job — deve ser ignorado
        primary_image_staging_path: "imports/other-job/items/x/primary.png",
        technical_image_staging_paths: [],
      },
    ],
  });
  assert.ok(staging.includes(`imports/${jobId}/source.zip`));
  assert.ok(staging.includes(`imports/${jobId}/items/aaa/primary.png`));
  assert.ok(staging.includes(`imports/${jobId}/items/aaa/technical/t1.jpg`));
  assert.ok(!staging.some((p) => p.includes("other-job")));
  // Idempotência conceitual: Set de paths únicos
  assert.equal(new Set(staging).size, staging.length);

  // 15–16. Mutações só em ready
  assert.equal(jobAllowsReviewMutation("ready"), true);
  assert.equal(jobAllowsReviewMutation("publishing"), false);
  assert.equal(jobAllowsReviewMutation("completed"), false);
  assert.equal(jobAllowsReviewMutation("processing"), false);

  // 17. Audit metadata
  const meta = buildCatalogImportPublishedAuditMetadata({
    jobId,
    manufacturerId: "m1",
    manufacturerName: "AL",
    totalItems: 10,
    approvedItems: 5,
    rejectedItems: 2,
    publishedItems: 4,
    duplicateItems: 1,
    duplicatesAtPublish: 1,
    invalidItems: 2,
    cleanupWarning: true,
  });
  assert.equal(meta.job_id, jobId);
  assert.equal(meta.published_items, 4);
  assert.equal(meta.duplicates_at_publish, 1);
  assert.equal(meta.cleanup_warning, true);
  assert.ok(!("raw_manifest" in meta));
  assert.ok(!JSON.stringify(meta).includes("raw_manifest_item"));

  // Migration hardening existe e reforça criação na RPC
  const mig = readFileSync(
    join(here, "../../../supabase/migrations/20260910170000_catalog_import_publish_hardening.sql"),
    "utf8",
  );
  assert.ok(mig.includes("on conflict (normalized_name) do nothing"));
  assert.ok(mig.includes("'outcome', 'published'"));
  assert.ok(mig.includes("'outcome', 'duplicate'"));
  assert.ok(mig.includes("resolved_manufacturer_id"));

  console.log("catalog-import phase3.hardening.assert: OK");
}

run();
