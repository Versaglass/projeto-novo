/**
 * Limites centralizados — VersaGlass Catalog Import v1 (ambiente atual).
 *
 * ZIP máximo: 50 MiB — alinhado a supabase/config.toml [storage] file_size_limit.
 * É limite de infraestrutura/configuração, não do formato lógico do catálogo.
 * Aumentar no futuro exige subir o global do Storage e esta constante.
 */

export const CATALOG_IMPORT_STAGING_BUCKET = "manufacturer-catalog-staging" as const;

/** Limite oficial v1 neste ambiente (binário). UI: "50 MB". */
export const ZIP_MAX_SIZE_BYTES = 50 * 1024 * 1024;

export const ZIP_MAX_ENTRIES = 2_500;

export const MANIFEST_MAX_ITEMS = 1_000;

/** Manifesto JSON (texto) — margem confortável para ~1000 itens. */
export const MANIFEST_MAX_BYTES = 8 * 1024 * 1024;

export const IMAGE_MAX_BYTES = 5 * 1024 * 1024;

export const TECHNICAL_IMAGES_MAX_PER_ITEM = 20;

/** Proteção ZIP bomb — total descompactado acumulado. */
export const UNCOMPRESSED_MAX_BYTES = 250 * 1024 * 1024;

export const ALLOWED_IMAGE_MIME = ["image/jpeg", "image/png", "image/webp"] as const;
export type AllowedImageMime = (typeof ALLOWED_IMAGE_MIME)[number];

export const MIME_TO_EXT: Record<AllowedImageMime, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
};

export const ZIP_UI_LIMIT_LABEL = "50 MB";

export function formatBytesForUi(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
