/**
 * Regras puras de revisão / aprovação / publicação (testáveis offline).
 */

import type { ValidationStatus } from "./status";

export type ReviewDecision = "pending" | "approved" | "rejected";

export function canApproveItem(validationStatus: ValidationStatus): boolean {
  return validationStatus === "valid" || validationStatus === "review";
}

export function canRejectItem(validationStatus: ValidationStatus): boolean {
  return (
    validationStatus === "valid" || validationStatus === "review" || validationStatus === "invalid"
  );
}

/** Approve-all: somente valid + pending. Nunca review/duplicate/invalid. */
export function isEligibleForApproveAll(opts: {
  validationStatus: ValidationStatus;
  reviewDecision: ReviewDecision;
}): boolean {
  return opts.validationStatus === "valid" && opts.reviewDecision === "pending";
}

export function assertDecisionAllowed(
  validationStatus: ValidationStatus,
  decision: ReviewDecision,
): void {
  if (decision === "pending") return;
  if (decision === "approved" && !canApproveItem(validationStatus)) {
    throw new Error("Item não pode ser aprovado neste status técnico.");
  }
  if (decision === "rejected" && !canRejectItem(validationStatus)) {
    throw new Error("Item não pode ser rejeitado neste status técnico.");
  }
  if (validationStatus === "duplicate" && decision === "approved") {
    throw new Error("Itens duplicados não podem ser aprovados.");
  }
}

export type PublishGateItem = {
  validationStatus: ValidationStatus;
  reviewDecision: ReviewDecision;
};

export function hasPendingPublishableItems(items: PublishGateItem[]): boolean {
  return items.some(
    (i) =>
      (i.validationStatus === "valid" || i.validationStatus === "review") &&
      i.reviewDecision === "pending",
  );
}

export function countApproved(items: PublishGateItem[]): number {
  return items.filter((i) => i.reviewDecision === "approved").length;
}

export function canEnablePublish(opts: {
  jobStatus: string;
  manufacturerResolved: boolean;
  items: PublishGateItem[];
}): boolean {
  if (opts.jobStatus !== "ready") return false;
  if (!opts.manufacturerResolved) return false;
  if (hasPendingPublishableItems(opts.items)) return false;
  if (countApproved(opts.items) < 1) return false;
  return true;
}

export type ManufacturerResolution =
  | { mode: "existing"; manufacturerId: string }
  | { mode: "new"; name: string };

export function isManufacturerResolved(
  resolvedId: string | null | undefined,
  resolvedName: string | null | undefined,
  fallbackExistingId: string | null | undefined,
  fallbackName: string | null | undefined,
): boolean {
  if (resolvedId) return true;
  if (resolvedName && resolvedName.trim().length > 0) return true;
  // Sem resolução explícita: se Fase 2 achou existente OU há nome do manifesto
  if (fallbackExistingId) return true;
  if (fallbackName && fallbackName.trim().length > 0) return true;
  return false;
}

/**
 * Paths finais controlados pelo VersaGlass.
 * Independentes do fabricante — permite preparar Storage antes da RPC
 * criar/reusar product_manufacturers na mesma transação dos produtos.
 * Sem source_code / nome / filename do ZIP.
 */
export function buildFinalPrimaryImagePath(productId: string, ext: string): string {
  return `products/${productId}/primary.${ext}`;
}

export function buildFinalTechnicalImagePath(
  productId: string,
  imageId: string,
  ext: string,
): string {
  return `products/${productId}/technical/${imageId}.${ext}`;
}

/** Intenção de fabricante — NÃO cria registro. */
export type ManufacturerPublishIntent =
  | { kind: "existing"; manufacturerId: string }
  | { kind: "new"; name: string; normalizedName: string };

export function resolveManufacturerPublishIntent(
  job: {
    resolved_manufacturer_id?: string | null;
    resolved_manufacturer_name?: string | null;
    existing_manufacturer_id?: string | null;
    manufacturer_name?: string | null;
  },
  normalizeName: (name: string) => string,
): ManufacturerPublishIntent | null {
  if (job.resolved_manufacturer_id) {
    return { kind: "existing", manufacturerId: job.resolved_manufacturer_id };
  }
  const resolvedName = job.resolved_manufacturer_name?.trim();
  if (resolvedName) {
    return {
      kind: "new",
      name: resolvedName,
      normalizedName: normalizeName(resolvedName),
    };
  }
  if (job.existing_manufacturer_id) {
    return { kind: "existing", manufacturerId: job.existing_manufacturer_id };
  }
  const phase2Name = job.manufacturer_name?.trim();
  if (phase2Name) {
    return {
      kind: "new",
      name: phase2Name,
      normalizedName: normalizeName(phase2Name),
    };
  }
  return null;
}

export type PublishItemOutcome =
  | { import_item_id: string; outcome: "published"; product_id: string }
  | { import_item_id: string; outcome: "duplicate"; duplicate_product_id: string | null };

/** Paths finais a remover após RPC parcial (somente duplicates). */
export function finalPathsForDuplicateOutcomes(
  outcomes: PublishItemOutcome[],
  pathsByItemId: Map<string, string[]>,
): string[] {
  const out: string[] = [];
  for (const o of outcomes) {
    if (o.outcome !== "duplicate") continue;
    const paths = pathsByItemId.get(o.import_item_id) ?? [];
    out.push(...paths);
  }
  return out;
}

/** Paths de staging conhecidos do job — sem listagem recursiva frágil. */
export function collectExplicitStagingPaths(opts: {
  jobId: string;
  storagePath: string | null | undefined;
  items: Array<{
    primary_image_staging_path?: string | null;
    technical_image_staging_paths?: unknown;
  }>;
}): string[] {
  const paths = new Set<string>();
  const prefix = `imports/${opts.jobId}/`;

  const addIfOwned = (p: string | null | undefined) => {
    if (!p || typeof p !== "string") return;
    if (!p.startsWith(prefix)) return;
    paths.add(p);
  };

  addIfOwned(opts.storagePath);
  // ZIP padrão mesmo se storage_path já foi limpo na Fase 2
  addIfOwned(`imports/${opts.jobId}/source.zip`);

  for (const it of opts.items) {
    addIfOwned(it.primary_image_staging_path ?? null);
    const tech = it.technical_image_staging_paths;
    if (Array.isArray(tech)) {
      for (const t of tech) {
        if (typeof t === "string") addIfOwned(t);
      }
    }
  }

  return [...paths];
}

export function jobAllowsReviewMutation(status: string): boolean {
  return status === "ready";
}

export function parsePublishRpcItems(raw: unknown): PublishItemOutcome[] {
  if (!raw || typeof raw !== "object") return [];
  const items = (raw as { items?: unknown }).items;
  if (!Array.isArray(items)) return [];
  const out: PublishItemOutcome[] = [];
  for (const it of items) {
    if (!it || typeof it !== "object") continue;
    const row = it as Record<string, unknown>;
    const id = typeof row.import_item_id === "string" ? row.import_item_id : null;
    if (!id) continue;
    if (row.outcome === "published" && typeof row.product_id === "string") {
      out.push({ import_item_id: id, outcome: "published", product_id: row.product_id });
    } else if (row.outcome === "duplicate") {
      out.push({
        import_item_id: id,
        outcome: "duplicate",
        duplicate_product_id:
          typeof row.duplicate_product_id === "string" ? row.duplicate_product_id : null,
      });
    }
  }
  return out;
}

export function buildCatalogImportPublishedAuditMetadata(input: {
  jobId: string;
  manufacturerId: string | null;
  manufacturerName: string | null;
  totalItems: number;
  approvedItems: number;
  rejectedItems: number;
  publishedItems: number;
  duplicateItems: number;
  duplicatesAtPublish: number;
  invalidItems: number;
  cleanupWarning: boolean;
}): Record<string, unknown> {
  return {
    job_id: input.jobId,
    manufacturer_id: input.manufacturerId,
    manufacturer_name: input.manufacturerName,
    total_items: input.totalItems,
    approved_items: input.approvedItems,
    rejected_items: input.rejectedItems,
    published_items: input.publishedItems,
    duplicate_items: input.duplicateItems,
    duplicates_at_publish: input.duplicatesAtPublish,
    invalid_items: input.invalidItems,
    ...(input.cleanupWarning ? { cleanup_warning: true } : {}),
  };
}

export function extFromStoragePath(path: string | null | undefined): string {
  if (!path) return "png";
  const m = path.toLowerCase().match(/\.([a-z0-9]+)$/);
  if (!m) return "png";
  const e = m[1]!;
  if (e === "jpeg") return "jpg";
  if (e === "jpg" || e === "png" || e === "webp") return e;
  return "png";
}
