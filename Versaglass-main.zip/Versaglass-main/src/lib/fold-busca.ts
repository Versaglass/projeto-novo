/** Busca tolerante a acento (Rev. 166) — NFD + lower. */
export function foldBusca(s: string) {
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}
