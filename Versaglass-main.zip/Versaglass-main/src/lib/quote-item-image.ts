import { supabase } from "@/integrations/supabase/client";

/** Prefixo gravado em `quote_items.imagem_url` para paths do catálogo global. */
export const QUOTE_ITEM_CATALOG_IMAGE_PREFIX = "platform-catalog/";

export type QuoteItemImageBucket = "project-images" | "platform-catalog";

export function snapshotImagemUrlFromCatalog(path: string | null | undefined): string | null {
  const p = (path ?? "").trim();
  if (!p) return null;
  if (p.startsWith(QUOTE_ITEM_CATALOG_IMAGE_PREFIX)) return p;
  return `${QUOTE_ITEM_CATALOG_IMAGE_PREFIX}${p.replace(/^\/+/, "")}`;
}

export function snapshotImagemUrlFromTemplate(path: string | null | undefined): string | null {
  const p = (path ?? "").trim();
  return p || null;
}

/**
 * Snapshot da foto do Estoque (`inventory_items.imagem_url`).
 * Mesmo bucket `project-images` e mesmo formato de path da Biblioteca
 * (`<company_id>/estoque/...`) — sem prefixo especial.
 */
export function snapshotImagemUrlFromInventory(path: string | null | undefined): string | null {
  return snapshotImagemUrlFromTemplate(path);
}

/** Path estável persistido no item (qualquer origem), ou null. */
export function obterImagemUrlDoItem(item: { imagem_url?: string | null }): string | null {
  const p = (item.imagem_url ?? "").trim();
  return p || null;
}

export function itemPossuiImagem(item: { imagem_url?: string | null }): boolean {
  return obterImagemUrlDoItem(item) !== null;
}

export function bucketForQuoteItemImage(stored: string): QuoteItemImageBucket {
  return stored.startsWith(QUOTE_ITEM_CATALOG_IMAGE_PREFIX) ? "platform-catalog" : "project-images";
}

export function pathForQuoteItemImage(stored: string): string {
  if (stored.startsWith(QUOTE_ITEM_CATALOG_IMAGE_PREFIX)) {
    return stored.slice(QUOTE_ITEM_CATALOG_IMAGE_PREFIX.length);
  }
  return stored.replace(/^\/+/, "");
}

function extractStoragePath(value: string, bucket: QuoteItemImageBucket): string | null {
  if (!value) return null;
  if (!value.startsWith("http")) return value.replace(/^\/+/, "");
  const esc = bucket.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const pub = value.match(new RegExp(`/object/public/${esc}/(.+)$`));
  if (pub) return decodeURIComponent(pub[1]);
  const sig = value.match(new RegExp(`/object/sign/${esc}/([^?]+)`));
  if (sig) return decodeURIComponent(sig[1]);
  return null;
}

async function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Falha ao ler a imagem"));
    reader.readAsDataURL(blob);
  });
}

async function measure(dataUrl: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve({ width: img.naturalWidth || 1, height: img.naturalHeight || 1 });
    img.onerror = () => reject(new Error("Imagem inválida"));
    img.src = dataUrl;
  });
}

export type QuoteItemImagePdf = {
  dataUrl: string;
  width: number;
  height: number;
};

/** Altura máxima do bloco de foto no PDF do orçamento (mm) — projetos. */
export const QUOTE_ITEM_IMAGE_MAX_H_MM = 55;

/** Limite da miniatura de item comum de estoque no PDF (mm). */
export const QUOTE_ITEM_STOCK_THUMB_MAX_MM = 28;

export type QuoteItemImageFit = {
  maxWidthMm: number;
  maxHeightMm: number;
};

function escalaImagem(img: QuoteItemImagePdf, fit: QuoteItemImageFit): { w: number; h: number } {
  const escala = Math.min(fit.maxWidthMm / img.width, fit.maxHeightMm / img.height);
  return { w: img.width * escala, h: img.height * escala };
}

function fitParaModo(larguraDisponivelMm: number, maxHeightMm: number): QuoteItemImageFit {
  if (maxHeightMm <= QUOTE_ITEM_STOCK_THUMB_MAX_MM) {
    return {
      maxWidthMm: QUOTE_ITEM_STOCK_THUMB_MAX_MM,
      maxHeightMm: QUOTE_ITEM_STOCK_THUMB_MAX_MM,
    };
  }
  return { maxWidthMm: larguraDisponivelMm, maxHeightMm };
}

/** Carrega foto do item para embutir no PDF. Falha degrada para null. */
export async function loadQuoteItemImageForPdf(
  imagemUrl: string | null | undefined,
): Promise<QuoteItemImagePdf | null> {
  const bruto = (imagemUrl ?? "").trim();
  if (!bruto) return null;

  const bucket = bucketForQuoteItemImage(bruto);
  const path = extractStoragePath(pathForQuoteItemImage(bruto), bucket);
  if (!path) return null;

  try {
    const { data: assinada, error: erroUrl } = await supabase.storage
      .from(bucket)
      .createSignedUrl(path, 60);
    if (erroUrl || !assinada?.signedUrl) throw erroUrl ?? new Error("sem URL assinada");
    const resp = await fetch(assinada.signedUrl);
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const dataUrl = await blobToDataUrl(await resp.blob());
    const { width, height } = await measure(dataUrl);
    return { dataUrl, width, height };
  } catch (err) {
    console.error("Falha ao carregar foto do item para o PDF.", err);
    return null;
  }
}

/** Reserva espaço vertical para a foto no PDF (mm). */
export function alturaBlocoImagemItem(
  larguraDisponivelMm: number,
  img: QuoteItemImagePdf,
  maxHeightMm: number = QUOTE_ITEM_IMAGE_MAX_H_MM,
): number {
  const { h } = escalaImagem(img, fitParaModo(larguraDisponivelMm, maxHeightMm));
  return h + 2;
}

/** Desenha a foto no PDF. Devolve altura usada (mm). */
export function desenharImagemItem(
  doc: import("jspdf").jsPDF,
  img: QuoteItemImagePdf,
  opts: { x: number; y: number; largura: number; maxHeightMm?: number },
): number {
  const maxH = opts.maxHeightMm ?? QUOTE_ITEM_IMAGE_MAX_H_MM;
  const { w, h } = escalaImagem(img, fitParaModo(opts.largura, maxH));
  try {
    doc.addImage(img.dataUrl, opts.x, opts.y, w, h, undefined, "FAST");
  } catch (err) {
    console.error("Não foi possível inserir a foto do item no PDF.", err);
    return 0;
  }
  return h;
}
