import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

/**
 * Snapshot de sessão para o `beforeLoad` de `/_authenticated`.
 *
 * Evita `getUser()` (rede Auth) em toda troca de rota:
 *   getSession() local → se validação server-side recente, reutiliza user
 *   senão → getUser() com TTL + dedupe inflight
 *
 * Segurança de dados continua no JWT + RLS; isto só decide navegação no cliente.
 */

export type AuthSessionSnapshot = {
  session: Session;
  user: User;
  /** Última vez que `getUser()` (ou login/refresh) confirmou a sessão no servidor. */
  lastServerValidation: number;
};

/** TTL conservador da validação server-side (`getUser`). */
export const AUTH_SESSION_VALIDATION_TTL_MS = 60_000;

let cache: AuthSessionSnapshot | null = null;
let inflightValidation: Promise<User | null> | null = null;

export function invalidateAuthSessionSnapshot() {
  cache = null;
  inflightValidation = null;
}

/** Após login / refresh / getUser ok — evita getUser redundante na entrada em `/app`. */
export function markAuthSessionValidated(session: Session | null, user: User | null) {
  if (!session?.user || !user || session.user.id !== user.id) {
    invalidateAuthSessionSnapshot();
    return;
  }
  cache = {
    session,
    user,
    lastServerValidation: Date.now(),
  };
}

/**
 * Sincroniza com `onAuthStateChange` (uma subscription — AuthContext).
 * Não marca `INITIAL_SESSION` como validado (primeira entrada ainda chama getUser).
 */
export function syncAuthSessionFromAuthEvent(event: string, session: Session | null) {
  if (event === "SIGNED_OUT") {
    invalidateAuthSessionSnapshot();
    return;
  }
  if (!session?.user) {
    if (event === "TOKEN_REFRESHED" || event === "USER_UPDATED") {
      invalidateAuthSessionSnapshot();
    }
    return;
  }
  if (event === "SIGNED_IN" || event === "TOKEN_REFRESHED" || event === "USER_UPDATED") {
    markAuthSessionValidated(session, session.user);
  }
}

function isLikelyInvalidSessionError(error: { message?: string; status?: number } | null): boolean {
  if (!error) return false;
  const status = error.status;
  if (status === 401 || status === 403) return true;
  const msg = (error.message ?? "").toLowerCase();
  return (
    msg.includes("invalid") ||
    msg.includes("jwt") ||
    msg.includes("session") ||
    msg.includes("not authenticated") ||
    msg.includes("expired") ||
    msg.includes("user from sub claim")
  );
}

async function validateWithGetUser(session: Session): Promise<User | null> {
  if (inflightValidation) return inflightValidation;

  inflightValidation = (async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error) {
      if (isLikelyInvalidSessionError(error)) {
        invalidateAuthSessionSnapshot();
        return null;
      }
      // Falha transitória de rede: não desloga; reutiliza sessão local se houver.
      return session.user;
    }
    if (!data.user) {
      invalidateAuthSessionSnapshot();
      return null;
    }
    markAuthSessionValidated(session, data.user);
    return data.user;
  })().finally(() => {
    inflightValidation = null;
  });

  return inflightValidation;
}

/**
 * Resolve o usuário autenticado para guards de rota.
 * Retorna `null` → caller redireciona para `/auth`.
 */
export async function resolveAuthenticatedUser(): Promise<User | null> {
  const { data, error } = await supabase.auth.getSession();
  if (error || !data.session?.user) {
    invalidateAuthSessionSnapshot();
    return null;
  }

  const session = data.session;
  const now = Date.now();

  if (
    cache &&
    cache.user.id === session.user.id &&
    now - cache.lastServerValidation < AUTH_SESSION_VALIDATION_TTL_MS
  ) {
    // Mantém session do storage (pode ter access_token renovado pelo client).
    cache = { ...cache, session, user: session.user };
    return cache.user;
  }

  return validateWithGetUser(session);
}
