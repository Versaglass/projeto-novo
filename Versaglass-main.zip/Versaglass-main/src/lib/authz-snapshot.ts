import { supabase } from "@/integrations/supabase/client";
import type { Permissions } from "@/contexts/auth-context";
import type { CompanyRole } from "@/contexts/company-context";
import type { AccountActiveStatus } from "@/lib/account-active";
import { normalizeFinePermissions } from "@/lib/fine-permissions";

/**
 * Snapshot de autorização para o `beforeLoad` de `/_authenticated`.
 *
 * Antes, cada navegação fazia waterfall + queries duplicadas:
 *   getUser → profiles.ativo → user_roles → (user_roles + profiles + members)
 *
 * Aqui: UMA carga paralela (profiles + roles + members), com cache curto em
 * memória para trocas rápidas de rota. A garantia de conta inativa permanece
 * (máximo atraso = TTL). Invalidar no logout/desativação.
 */

export type AuthzSnapshot = {
  userId: string;
  ativo: AccountActiveStatus;
  isPlatformAdmin: boolean;
  permissions: Permissions;
  companyRole: CompanyRole | null;
  fetchedAt: number;
};

/** Preferência de empresa ativa — mesmo prefixo de `company-context.tsx`. */
const ACTIVE_COMPANY_STORAGE_PREFIX = "vmm_active_company_id";

/** TTL curto: detecta desativação remota na próxima navegação após expirar. */
export const AUTHZ_SNAPSHOT_TTL_MS = 30_000;

let cache: AuthzSnapshot | null = null;
let inflight: Promise<AuthzSnapshot> | null = null;
let inflightUserId: string | null = null;

export function invalidateAuthzSnapshot() {
  cache = null;
  inflight = null;
  inflightUserId = null;
}

function resolveAtivo(
  prof: { ativo?: boolean | null } | null,
  error: unknown,
): AccountActiveStatus {
  if (error) return "unknown";
  if (!prof) return "active";
  if (prof.ativo === false) return "inactive";
  return "active";
}

async function fetchAuthzSnapshot(userId: string): Promise<AuthzSnapshot> {
  const [{ data: roleRows }, { data: prof, error: profError }, { data: members }] =
    await Promise.all([
      supabase.from("user_roles").select("role").eq("user_id", userId),
      supabase.from("profiles").select("permissions, ativo").eq("id", userId).maybeSingle(),
      supabase
        .from("company_members")
        .select("company_id, role")
        .eq("user_id", userId)
        .eq("status", "active"),
    ]);

  const isPlatformAdmin = (roleRows ?? []).some((r) => r.role === "admin");
  const permissions = normalizeFinePermissions(prof?.permissions);
  const list = members ?? [];
  const key = `${ACTIVE_COMPANY_STORAGE_PREFIX}:${userId}`;
  const stored = typeof localStorage !== "undefined" ? localStorage.getItem(key) : null;
  const active = list.find((m) => m.company_id === stored) ?? list[0] ?? null;

  return {
    userId,
    ativo: resolveAtivo(prof, profError),
    isPlatformAdmin,
    permissions,
    companyRole: (active?.role as CompanyRole | undefined) ?? null,
    fetchedAt: Date.now(),
  };
}

/**
 * Snapshot compartilhado pelos três enforcers do beforeLoad.
 * Cache + dedupe de inflight: 2ª/3ª chamada na mesma navegação não bate rede.
 */
export async function getAuthzSnapshot(userId: string): Promise<AuthzSnapshot> {
  if (cache && cache.userId === userId && Date.now() - cache.fetchedAt < AUTHZ_SNAPSHOT_TTL_MS) {
    return cache;
  }
  if (inflight && inflightUserId === userId) return inflight;

  inflightUserId = userId;
  inflight = fetchAuthzSnapshot(userId)
    .then((snap) => {
      cache = snap;
      return snap;
    })
    .finally(() => {
      inflight = null;
      inflightUserId = null;
    });

  return inflight;
}
