// Origens do ambiente LOCAL, acrescentadas ao `connect-src` só em desenvolvimento.
//
// POR QUE (Revisão 27): `'self'` é `http://localhost:8080`, e o Supabase local vive em
// OUTRA origem (`http://127.0.0.1:55321`). Sem estas entradas o navegador bloqueia todo
// fetch/WebSocket da aplicação para o banco local — e como `https://*.supabase.co` está
// liberado, a aplicação conseguia falar com PRODUÇÃO e não com o ambiente local.
//
// `ws://` é tão necessário quanto `http://`: o Realtime ([[P-14]] — NotificationsBell,
// canal de `server_logs`) e o HMR do Vite trafegam por WebSocket. Uma correção só com
// `http://` deixaria o Realtime quebrado no local.
//
// `import.meta.env.DEV` é substituído por `false` no build, então esta constante vira `""`
// e o cabeçalho de PRODUÇÃO sai byte a byte idêntico ao de antes desta mudança.
const CONNECT_SRC_LOCAL_DEV = import.meta.env.DEV
  ? " http://127.0.0.1:* http://localhost:* ws://127.0.0.1:* ws://localhost:*"
  : "";

const SECURITY_HEADERS: Record<string, string> = {
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=()",
  "Cross-Origin-Opener-Policy": "same-origin",
  "Cross-Origin-Resource-Policy": "same-origin",
  "Content-Security-Policy": [
    "default-src 'self'",
    "base-uri 'self'",
    "object-src 'none'",
    "frame-ancestors 'none'",
    "img-src 'self' data: blob: https:",
    "font-src 'self' https://fonts.gstatic.com data:",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "script-src 'self' 'unsafe-inline' https://www.googletagmanager.com https://analytics.tiktok.com",
    `connect-src 'self' https://*.supabase.co wss://*.supabase.co https://www.google-analytics.com https://analytics.tiktok.com${CONNECT_SRC_LOCAL_DEV}`,
    "manifest-src 'self'",
  ].join("; "),
};

export function withSecurityHeaders(response: Response): Response {
  const headers = new Headers(response.headers);
  for (const [key, value] of Object.entries(SECURITY_HEADERS)) headers.set(key, value);
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers,
  });
}

const buckets = new Map<string, { count: number; resetAt: number }>();

export function checkRateLimit(key: string, limit = 120, windowMs = 60_000) {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: limit - 1, resetAt: now + windowMs };
  }
  bucket.count += 1;
  return {
    allowed: bucket.count <= limit,
    remaining: Math.max(0, limit - bucket.count),
    resetAt: bucket.resetAt,
  };
}

export function getClientIp(request: Request) {
  return (
    request.headers.get("CF-Connecting-IP") ??
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    "unknown"
  );
}
