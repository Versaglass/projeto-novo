import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const InputSchema = z.object({
  command: z.string().min(1),
  history: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() }))
    .optional()
    .default([]),
  context: z.string().optional().default(""),
});

export type IAAdviseResult = {
  reply: string;
  suggestions: string[];
  refinedCommand: string;
  risk: "baixo" | "medio" | "alto" | "critico";
};

export const iaAdvise = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => InputSchema.parse(data))
  .handler(async ({ data }): Promise<IAAdviseResult> => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("LOVABLE_API_KEY ausente no servidor.");

    const system = `Você é a IA Intelligence do sistema Versatil (gestão de vidraçaria/alumínio). Fala em português do Brasil de forma natural, direta e humana, como uma assistente executiva do ADM.

Regras:
- Confirme o que entendeu do comando em 1-2 frases naturais.
- Dê 2 a 4 sugestões práticas de melhoria, complemento ou cuidado antes de executar (ex.: campos que faltam, riscos, boas práticas do negócio).
- Ofereça uma versão refinada e mais completa do comando que a IA executará.
- Estime o risco da ação em: baixo, medio, alto, critico.
- Nunca invente dados sensíveis. Se faltar informação essencial (preço, categoria, cliente), peça na resposta e liste em sugestões.
- Tom acolhedor, seguro, profissional. Sem emojis. Sem markdown pesado.

Contexto do usuário: ${data.context || "ADM operacional do sistema."}

Responda SOMENTE em JSON válido no formato:
{"reply": "texto conversacional curto para falar em voz alta", "suggestions": ["...", "..."], "refinedCommand": "comando reescrito pronto para executar", "risk": "baixo|medio|alto|critico"}`;

    const messages = [
      { role: "system", content: system },
      ...data.history.map((m) => ({ role: m.role, content: m.content })),
      { role: "user", content: data.command },
    ];

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages,
        response_format: { type: "json_object" },
      }),
    });

    if (res.status === 429)
      throw new Error("Limite de uso da IA atingido. Tente novamente em instantes.");
    if (res.status === 402)
      throw new Error("Créditos da IA esgotados. Adicione créditos no workspace.");
    if (!res.ok)
      throw new Error(`Falha na IA (${res.status}): ${await res.text().catch(() => "")}`);

    const json = await res.json();
    const raw = json?.choices?.[0]?.message?.content ?? "{}";
    let parsed: any = {};
    try {
      parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
    } catch {
      parsed = { reply: String(raw), suggestions: [], refinedCommand: data.command, risk: "medio" };
    }

    const risk = ["baixo", "medio", "alto", "critico"].includes(parsed.risk)
      ? parsed.risk
      : "medio";
    return {
      reply: String(parsed.reply || "Entendi seu comando.").slice(0, 800),
      suggestions: Array.isArray(parsed.suggestions)
        ? parsed.suggestions.slice(0, 6).map(String)
        : [],
      refinedCommand: String(parsed.refinedCommand || data.command).slice(0, 2000),
      risk: risk as IAAdviseResult["risk"],
    };
  });
