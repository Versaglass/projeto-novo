import type jsPDF from "jspdf";
import { num } from "./format";
import type { QuoteItemTipoProjeto } from "@/lib/tipo-projeto-orcamento";

// Desenho técnico do item no PDF do orçamento.
//
// ORIGEM DOS DADOS: `public.quote_items.drawing_data` (jsonb) e
// `quote_items.drawing_notes` (text) — exatamente o que o editor de desenho
// grava e o que a seção "Desenhos técnicos e alterações" da tela lê. Nada é
// capturado do DOM: o PDF é gerado só a partir dos dados persistidos, então
// funciona com a página fechada, após F5 e sem o card visível.
//
// RENDERIZAÇÃO: a tela monta um SVG inline (`ProjectDrawingPreview`). Aqui a
// mesma geometria é desenhada com as primitivas VETORIAIS do jsPDF (rect,
// circle, line, text). Vetor não pixeliza: medidas e textos ficam nítidos em
// qualquer zoom e na impressão, sem canvas, sem rasterização e sem imagem
// externa.
//
// ⚠️ Este módulo ESPELHA a geometria de `src/components/ProjectDrawingEditor.tsx`
// (`normalizeDrawing` + `px`). Foi duplicado de propósito para não tocar no
// componente da interface. Se a geometria do preview mudar, atualize aqui também.

type Cutout = {
  id: string;
  tipo: "retangular" | "redondo" | "meia-lua" | "rasgo";
  x: number;
  y: number;
  largura: number;
  altura: number;
  diametro?: number;
  observacao?: string;
};

type Hardware = {
  id: string;
  tipo: string;
  nome: string;
  x: number;
  y: number;
  quantidade: number;
  observacao?: string;
};

type DrawingData = {
  versao: number;
  tipoProjeto: string;
  larguraMm: number;
  alturaMm: number;
  observacoesTecnicas: string;
  recortes: Cutout[];
  ferragens: Hardware[];
};

export type DrawableItem = {
  descricao?: string | null;
  largura?: number | null; // METROS (coluna do quote_item)
  altura?: number | null; // METROS
  tipo_projeto?: QuoteItemTipoProjeto | null;
  drawing_data?: unknown;
  drawing_notes?: string | null;
};

const LETRAS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

// Paleta clara, pensada para impressão em papel — a tela continua com o tema
// escuro. Contorno escuro sobre fundo claro dá o melhor contraste.
const COR_PAPEL: [number, number, number] = [250, 250, 250];
const COR_BORDA: [number, number, number] = [205, 205, 205];
const COR_VIDRO: [number, number, number] = [226, 237, 250];
const COR_PAINEL: [number, number, number] = [30, 55, 90];
const COR_RECORTE: [number, number, number] = [185, 35, 35];
const COR_RECORTE_FUNDO: [number, number, number] = [250, 224, 224];
const COR_FERRAGEM: [number, number, number] = [168, 120, 15];
const COR_FERRAGEM_FUNDO: [number, number, number] = [252, 237, 197];
const COR_TEXTO: [number, number, number] = [35, 35, 35];
const COR_TEXTO_FRACO: [number, number, number] = [105, 105, 105];

const MAX_CAIXA_W = 92; // mm — metade esquerda do bloco
const MAX_CAIXA_H = 72; // mm
const PAD_ESQ = 13; // espaço da cota de altura (texto girado)
const PAD_DIR = 5;
const PAD_TOPO = 5;
const PAD_BASE = 8; // espaço da cota de largura
const LINHA_H = 3.8; // altura de uma linha da coluna de informações

export type DrawingPlan = {
  /** Falso quando o JSON existia mas não dá para reconstruir o desenho. */
  ok: boolean;
  drawing: DrawingData;
  tipo_projeto?: QuoteItemTipoProjeto | null;
  caixaW: number;
  caixaH: number;
  painelW: number;
  painelH: number;
  offsetX: number;
  offsetY: number;
  /** Linhas da coluna de informações, já quebradas para a largura disponível. */
  info: string[];
  infoLargura: number;
  /** Altura total do bloco (desenho + informações), em mm. */
  altura: number;
};

/**
 * Decide se o item TEM desenho e, em caso positivo, planeja o bloco inteiro
 * antes de desenhar — a altura devolvida é a que `renderItemDrawing` vai usar,
 * o que permite decidir a quebra de página sem cortar nada.
 *
 * REGRA DE EXISTÊNCIA (corrigida em 2026-07-27): basta haver GEOMETRIA VÁLIDA.
 * Recorte, ferragem e observação são complementos, nunca condição. A dimensão
 * vem de `drawing_data.larguraMm/alturaMm` (já em MILÍMETROS) e, quando o JSON
 * não as traz, do próprio item — `quote_items.largura/altura` estão em METROS,
 * então são convertidas por × 1000. As duas unidades nunca se misturam.
 *
 * Devolve `null` quando não há geometria alguma e o item não tinha `drawing_data`
 * (item puramente comercial: fica só com a linha da tabela).
 * Devolve `{ ok: false }` quando havia `drawing_data` mas ele não permite
 * reconstruir o desenho — só nesse caso o PDF avisa que está indisponível.
 */
export function planItemDrawing(
  doc: jsPDF,
  item: DrawableItem,
  larguraUtil: number,
): DrawingPlan | null {
  const raw = item.drawing_data;
  const temDrawingData = !!raw && typeof raw === "object";

  let drawing: DrawingData;
  try {
    drawing = normalizeDrawing(item);
  } catch {
    return temDrawingData ? planIndisponivel() : null;
  }

  const wMm = Number(drawing.larguraMm);
  const hMm = Number(drawing.alturaMm);
  if (!Number.isFinite(wMm) || !Number.isFinite(hMm) || wMm <= 0 || hMm <= 0) {
    return temDrawingData ? planIndisponivel() : null;
  }

  const maxCaixaW = Math.min(MAX_CAIXA_W, larguraUtil * 0.55);
  const internaW = maxCaixaW - PAD_ESQ - PAD_DIR;
  const internaH = MAX_CAIXA_H - PAD_TOPO - PAD_BASE;
  // Uma única escala para os dois eixos → proporção preservada, sem distorção.
  const escala = Math.min(internaW / wMm, internaH / hMm);
  const painelW = wMm * escala;
  const painelH = hMm * escala;
  // A caixa encolhe até o conteúdo: um painel estreito e alto (um espelho de
  // 100 × 1000 mm, por exemplo) não fica dentro de um retângulo cinza enorme.
  const caixaW = Math.min(maxCaixaW, Math.max(34, painelW + PAD_ESQ + PAD_DIR));
  const caixaH = painelH + PAD_TOPO + PAD_BASE;
  const offsetX = PAD_ESQ + (caixaW - PAD_ESQ - PAD_DIR - painelW) / 2;
  const offsetY = PAD_TOPO;

  // Coluna de informações. Dimensões sempre; recortes/ferragens/observações só
  // quando existirem — nada de legenda vazia.
  const infoLargura = larguraUtil - caixaW - 6;
  const info: string[] = [];
  const empurrar = (texto: string) => {
    for (const parte of doc.splitTextToSize(texto, infoLargura) as string[]) info.push(parte);
  };

  doc.setFontSize(8);
  if (drawing.tipoProjeto && drawing.tipoProjeto !== item.descricao) empurrar(drawing.tipoProjeto);
  empurrar(`Largura: ${Math.round(wMm)} mm`);
  empurrar(`Altura: ${Math.round(hMm)} mm`);

  if (drawing.recortes.length > 0) {
    info.push("");
    empurrar("Recortes:");
    drawing.recortes.forEach((r, idx) => {
      const medida =
        r.tipo === "redondo"
          ? `Ø ${num(Number(r.diametro) || Number(r.largura) || 0, 0)} mm`
          : `${num(Number(r.largura) || 0, 0)} × ${num(Number(r.altura) || 0, 0)} mm`;
      const obs = r.observacao ? ` - ${r.observacao}` : "";
      empurrar(
        `${idx + 1}. ${r.tipo} · ${medida} · em ${num(Number(r.x) || 0, 0)}, ${num(Number(r.y) || 0, 0)} mm${obs}`,
      );
    });
  }

  if (drawing.ferragens.length > 0) {
    info.push("");
    empurrar("Ferragens:");
    drawing.ferragens.forEach((f, idx) => {
      const letra = LETRAS[idx] ?? "•";
      const qtd = Number(f.quantidade) > 1 ? ` (${Number(f.quantidade)}×)` : "";
      const obs = f.observacao ? ` - ${f.observacao}` : "";
      empurrar(
        `${letra}. ${f.nome || f.tipo || "Ferragem"}${qtd} · em ${num(Number(f.x) || 0, 0)}, ${num(Number(f.y) || 0, 0)} mm${obs}`,
      );
    });
  }

  if (drawing.observacoesTecnicas.trim()) {
    info.push("");
    empurrar(`Observações: ${drawing.observacoesTecnicas.trim()}`);
  }

  return {
    ok: true,
    drawing,
    tipo_projeto: item.tipo_projeto ?? null,
    caixaW,
    caixaH,
    painelW,
    painelH,
    offsetX,
    offsetY,
    info,
    infoLargura,
    altura: Math.max(caixaH, info.length * LINHA_H) + 3,
  };
}

function planIndisponivel(): DrawingPlan {
  return {
    ok: false,
    drawing: {
      versao: 1,
      tipoProjeto: "",
      larguraMm: 0,
      alturaMm: 0,
      observacoesTecnicas: "",
      recortes: [],
      ferragens: [],
    },
    caixaW: 0,
    caixaH: 0,
    painelW: 0,
    painelH: 0,
    offsetX: 0,
    offsetY: 0,
    info: [],
    infoLargura: 0,
    altura: 8,
  };
}

// Espelha normalizeDrawing/defaultDrawing do componente da interface, com o
// fallback de dimensões do quote_item (metros → milímetros).
function normalizeDrawing(item: DrawableItem): DrawingData {
  const larguraItemMm = Math.round((Number(item.largura) || 0) * 1000);
  const alturaItemMm = Math.round((Number(item.altura) || 0) * 1000);

  const base: DrawingData = {
    versao: 1,
    tipoProjeto: item.descricao || "",
    larguraMm: larguraItemMm,
    alturaMm: alturaItemMm,
    observacoesTecnicas: item.drawing_notes || "",
    recortes: [],
    ferragens: [],
  };

  const raw = item.drawing_data as Partial<DrawingData> | null | undefined;
  if (raw && typeof raw === "object") {
    const larguraJson = Number(raw.larguraMm);
    const alturaJson = Number(raw.alturaMm);
    return {
      ...base,
      ...raw,
      // O JSON manda quando traz dimensão utilizável; senão, cai no item.
      larguraMm: Number.isFinite(larguraJson) && larguraJson > 0 ? larguraJson : base.larguraMm,
      alturaMm: Number.isFinite(alturaJson) && alturaJson > 0 ? alturaJson : base.alturaMm,
      tipoProjeto: (raw.tipoProjeto as string) || base.tipoProjeto,
      observacoesTecnicas: (raw.observacoesTecnicas as string) || base.observacoesTecnicas,
      recortes: Array.isArray(raw.recortes) ? raw.recortes : [],
      ferragens: Array.isArray(raw.ferragens) ? raw.ferragens : [],
    };
  }
  return base;
}

// Mesma função de mapeamento do preview: valor em mm → posição no painel.
function px(v: number, max: number, size: number) {
  if (!max) return 0;
  const valor = Number(v) || 0;
  return Math.max(0, Math.min(size, (valor / max) * size));
}

/**
 * Desenha o bloco em (x, y), respeitando a altura disponível na página.
 * O DESENHO em si nunca é partido: se não couber inteiro, o chamador já deve
 * ter aberto página nova. Só a coluna de informações pode continuar na página
 * seguinte — o que sobrar volta em `restante`.
 */
export function renderItemDrawing(
  doc: jsPDF,
  plano: DrawingPlan,
  x: number,
  y: number,
  alturaDisponivel: number,
): { y: number; restante: string[] } {
  if (!plano.ok) {
    doc.setFont("helvetica", "italic");
    doc.setFontSize(8);
    doc.setTextColor(...COR_TEXTO_FRACO);
    doc.text("Desenho técnico indisponível.", x + 2, y + 4);
    doc.setFont("helvetica", "normal");
    return { y: y + 8, restante: [] };
  }

  const { drawing } = plano;

  // Fundo claro da área do desenho (a tela usa fundo escuro; no papel, claro).
  doc.setFillColor(...COR_PAPEL);
  doc.setDrawColor(...COR_BORDA);
  doc.setLineWidth(0.2);
  doc.rect(x, y, plano.caixaW, plano.caixaH, "FD");

  const px0 = x + plano.offsetX;
  const py0 = y + plano.offsetY;

  const wMm = Number(drawing.larguraMm);
  const hMm = Number(drawing.alturaMm);

  // Painel (a peça) — retângulo genérico (silhuetas tipadas removidas, Rev. 201).
  doc.setFillColor(...COR_VIDRO);
  doc.setDrawColor(...COR_PAINEL);
  doc.setLineWidth(0.5);
  doc.rect(px0, py0, plano.painelW, plano.painelH, "FD");

  // Linha de referência do topo (mesma do preview da tela).
  doc.setLineWidth(0.15);
  doc.setDrawColor(165, 178, 195);
  const yRef = py0 + Math.min(5, plano.painelH / 6);
  doc.line(px0, yRef, px0 + plano.painelW, yRef);

  // Recortes e furos
  doc.setFontSize(6);
  drawing.recortes.forEach((r, idx) => {
    const cx = px0 + px(Number(r.x), wMm, plano.painelW);
    const cy = py0 + px(Number(r.y), hMm, plano.painelH);
    doc.setDrawColor(...COR_RECORTE);
    doc.setFillColor(...COR_RECORTE_FUNDO);
    doc.setLineWidth(0.4);
    const rotulo = String(idx + 1);
    doc.setTextColor(...COR_RECORTE);
    if (r.tipo === "redondo") {
      const raio = Math.max(
        1,
        px((Number(r.diametro) || Number(r.largura) || 60) / 2, wMm, plano.painelW),
      );
      doc.circle(cx, cy, raio, "FD");
      // Furo pequeno demais para caber o número dentro vira um borrão: nesse
      // caso o rótulo vai ao LADO da forma, preservando a legibilidade.
      if (raio >= 1.7) doc.text(rotulo, cx, cy + 0.8, { align: "center" });
      else doc.text(rotulo, cx + raio + 1, cy + 0.8);
    } else {
      const rw = Math.max(1.5, px(Number(r.largura), wMm, plano.painelW));
      const rh = Math.max(1.5, px(Number(r.altura), hMm, plano.painelH));
      doc.rect(cx, cy, rw, rh, "FD");
      if (rw >= 3.4 && rh >= 3.4)
        doc.text(rotulo, cx + rw / 2, cy + rh / 2 + 0.8, { align: "center" });
      else doc.text(rotulo, cx + rw + 1, cy + rh / 2 + 0.8);
    }
  });

  // Ferragens
  drawing.ferragens.forEach((f, idx) => {
    const cx = px0 + px(Number(f.x), wMm, plano.painelW);
    const cy = py0 + px(Number(f.y), hMm, plano.painelH);
    doc.setDrawColor(...COR_FERRAGEM);
    doc.setFillColor(...COR_FERRAGEM_FUNDO);
    doc.setLineWidth(0.4);
    doc.circle(cx, cy, 1.9, "FD");
    doc.setTextColor(...COR_FERRAGEM);
    doc.text(LETRAS[idx] ?? "•", cx, cy + 0.7, { align: "center" });
  });

  // Cotas dentro da caixa
  doc.setTextColor(...COR_TEXTO_FRACO);
  doc.setFontSize(7);
  doc.text(`${Math.round(wMm)} mm`, px0 + plano.painelW / 2, y + plano.caixaH - 2.5, {
    align: "center",
  });
  doc.text(`${Math.round(hMm)} mm`, x + 4.5, py0 + plano.painelH / 2, {
    align: "center",
    angle: 90,
  });

  // Coluna de informações — só o que couber; o resto volta ao chamador.
  const cabem = Math.max(0, Math.floor((alturaDisponivel - 2) / LINHA_H));
  const { restante } = renderInfoLines(doc, plano.info, x + plano.caixaW + 6, y + 3.5, cabem);

  return { y: y + plano.altura, restante };
}

/** Imprime até `limite` linhas de informação. Devolve o que não coube. */
export function renderInfoLines(
  doc: jsPDF,
  linhas: string[],
  x: number,
  y: number,
  limite: number,
): { y: number; restante: string[] } {
  doc.setFontSize(8);
  doc.setTextColor(...COR_TEXTO);
  doc.setFont("helvetica", "normal");
  let cursor = y;
  const impressas = linhas.slice(0, Math.max(0, limite));
  for (const linha of impressas) {
    if (linha) {
      // Rótulos de bloco ficam em negrito para separar visualmente as listas.
      const rotulo = linha === "Recortes:" || linha === "Ferragens:";
      if (rotulo) doc.setFont("helvetica", "bold");
      doc.text(linha, x, cursor);
      if (rotulo) doc.setFont("helvetica", "normal");
    }
    cursor += LINHA_H;
  }
  return { y: cursor, restante: linhas.slice(impressas.length) };
}

export const INFO_LINHA_H = LINHA_H;
