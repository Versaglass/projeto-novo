import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const InputSchema = z.object({
  prompt: z.string().min(1),
  context: z.string().optional().default(""),
});

export type GeneratedFileDTO = {
  path: string;
  language: string;
  content: string;
};

export type GeneratedCodeDTO = {
  title: string;
  description: string;
  files: GeneratedFileDTO[];
  sqlMigrations: GeneratedFileDTO[];
};

/**
 * Os três `catch` vazios abaixo são INTENCIONAIS e formam uma cascata: cada um
 * significa "esta estratégia não serviu, tente a próxima". O modelo devolve o
 * JSON ora cru, ora cercado por ``` ```, ora embutido em texto solto, e falhar
 * a análise é o caso ESPERADO nas duas primeiras tentativas, não um defeito.
 *
 * A função termina em `return null`, e o chamador (`:97`) trata esse `null` com
 * um caminho de fallback explícito — devolve a resposta bruta do modelo como
 * arquivo. Ou seja, a falha NÃO é engolida: ela é o mecanismo de controle e
 * chega ao usuário por outro caminho. Registrar cada tentativa frustrada só
 * encheria o console de ruído previsível.
 */
function extractJson(text: string): any | null {
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    // Não era JSON cru — segue para a tentativa com cerca de código.
  }
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenced) {
    try {
      return JSON.parse(fenced[1]);
    } catch {
      // A cerca existia mas o conteúdo não era JSON — segue para o recorte.
    }
  }
  const s = text.indexOf("{");
  const e = text.lastIndexOf("}");
  if (s !== -1 && e > s) {
    try {
      return JSON.parse(text.slice(s, e + 1));
    } catch {
      // Última tentativa: o recorte entre chaves também não era JSON válido.
    }
  }
  return null;
}

export const generateCode = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => InputSchema.parse(data))
  .handler(async ({ data }): Promise<GeneratedCodeDTO> => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("LOVABLE_API_KEY não configurada");

    const system = `Você é um engenheiro sênior full-stack do sistema VersaGlass (React + TypeScript + TanStack Start + Tailwind + Supabase).
Gere código real, completo e funcional para atender o pedido do usuário.

Responda APENAS com um JSON válido (sem markdown, sem \`\`\`), no formato:
{
  "title": "título curto",
  "description": "1-2 frases explicando o que foi gerado",
  "files": [
    { "path": "src/...", "language": "tsx|ts|css", "content": "conteúdo completo do arquivo" }
  ],
  "sqlMigrations": [
    { "path": "supabase/migrations/AAAAMMDDHHMMSS_nome.sql", "language": "sql", "content": "SQL completo com GRANTs, RLS e policies quando criar tabela" }
  ]
}

Regras:
- Gere 1 a 4 arquivos, cada um pronto para colar no projeto.
- Use Tailwind, shadcn (@/components/ui/*), lucide-react, e padrões TanStack já usados no projeto.
- Se o pedido exigir tabela nova no banco, inclua uma migration com CREATE TABLE + GRANT authenticated + ENABLE RLS + CREATE POLICY.
- Nunca deixe conteúdo vazio ou placeholder tipo "// TODO".`;

    const messages = [
      { role: "system", content: system },
      {
        role: "user",
        content: (data.context ? `Contexto: ${data.context}\n\n` : "") + `Pedido: ${data.prompt}`,
      },
    ];

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages,
      }),
    });

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(`Gateway ${res.status}: ${body.slice(0, 200)}`);
    }

    const json = await res.json();
    const raw = json?.choices?.[0]?.message?.content ?? "";
    const parsed = extractJson(raw);

    if (!parsed || !Array.isArray(parsed.files)) {
      return {
        title: "Código gerado pela IA",
        description: "Resposta bruta do modelo (não foi possível estruturar em arquivos).",
        files: [{ path: "resposta-ia.md", language: "md", content: String(raw).slice(0, 8000) }],
        sqlMigrations: [],
      };
    }

    return {
      title: String(parsed.title || "Código gerado pela IA"),
      description: String(parsed.description || ""),
      files: (parsed.files as unknown[])
        .slice(0, 6)
        .map((f) => {
          const row = f && typeof f === "object" ? (f as Record<string, unknown>) : {};
          return {
            path: String(row.path || "arquivo.tsx"),
            language: String(row.language || "tsx"),
            content: String(row.content || ""),
          };
        }),
      sqlMigrations: Array.isArray(parsed.sqlMigrations)
        ? (parsed.sqlMigrations as unknown[]).slice(0, 4).map((f) => {
            const row = f && typeof f === "object" ? (f as Record<string, unknown>) : {};
            return {
              path: String(row.path || "supabase/migrations/nova.sql"),
              language: "sql",
              content: String(row.content || ""),
            };
          })
        : [],
    };
  });
