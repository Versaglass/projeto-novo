/**
 * CNPJ do fornecedor — campo opcional, validado quando preenchido.
 * Reusa `src/lib/cnpj.ts` (Revisões 91–95).
 */

import { formatarCnpj, normalizarCnpj, validarCnpj } from "@/lib/cnpj";

export type CnpjFornecedorValidado =
  | { ok: true; cnpj: string | null; formatado: string }
  | { ok: false; erro: string };

export function validarCnpjFornecedor(bruto: unknown): CnpjFornecedorValidado {
  const original = String(bruto ?? "").trim();
  if (!original) return { ok: true, cnpj: null, formatado: "" };

  const cnpj = normalizarCnpj(original);
  const validacao = validarCnpj(cnpj);
  if (!validacao.ok) return { ok: false, erro: validacao.erro };

  return { ok: true, cnpj, formatado: formatarCnpj(cnpj) };
}
