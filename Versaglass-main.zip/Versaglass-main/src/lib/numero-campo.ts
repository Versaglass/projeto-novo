/**
 * Campos numéricos digitados pelo usuário — o padrão ÚNICO do projeto.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * O DEFEITO QUE ISTO RESOLVE (Revisão 31 → 32)
 * ────────────────────────────────────────────────────────────────────────────
 * No cadastro de Estoque foi digitado `89,90` no preço e o banco recebeu `0`.
 * Sem aviso, sem recusa. A causa NÃO era o `.replace(",", ".")` do handler — era
 * o `<input type="number">`:
 *
 *   Num `type="number"`, o navegador só entrega `e.target.value` quando o texto
 *   é um número VÁLIDO na notação dele (ponto decimal). "89,90" não é. O valor
 *   lido vira `""` — a vírgula é comida ANTES de qualquer código nosso rodar.
 *   Aí `"" → 0` e o zero desce até o Postgres como se fosse escolha do usuário.
 *
 * Ou seja: qualquer normalização feita no `onChange` de um `type="number"` é
 * inútil, porque o caractere que ela deveria tratar nunca chega.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * O PADRÃO (três regras, aplicadas igual em todo campo numérico)
 * ────────────────────────────────────────────────────────────────────────────
 * 1. O input é `type="text"` + `inputMode="decimal"` — NUNCA `type="number"`.
 *    `inputMode` preserva o teclado numérico no celular sem o filtro do
 *    navegador. (Um `type="number"` sem passar por aqui é o defeito de volta.)
 * 2. O estado guarda TEXTO. A conversão para número acontece uma vez só, no
 *    envio. Assim o passo intermediário "1." ou "89," não zera o campo no meio
 *    da digitação.
 * 3. Entrada inválida vira `NaN`, nunca `0`. Quem decide o que fazer com o
 *    `NaN` é `validaNumeroCampo`, que RECUSA com mensagem — o banco nunca vê um
 *    zero que o usuário não digitou.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * FORMATOS ACEITOS
 * ────────────────────────────────────────────────────────────────────────────
 *   "89,90"       → 89.9     vírgula decimal (o teclado brasileiro)
 *   "89.90"       → 89.9     ponto decimal   (o que o app já gravava)
 *   "1.234,56"    → 1234.56  ponto como separador de milhar + vírgula decimal
 *   "1.234.567"   → 1234567  dois ou mais pontos ⇒ todos são milhar
 *   "1.234"       → 1.234    UM ponto e nenhuma vírgula ⇒ ponto é DECIMAL
 *   "-5,5"        → -5.5
 *   "  89,90  "   → 89.9     espaços nas pontas são aparados
 *   ""            → NaN
 *   "abc" "12a" "R$ 90" "8,9,9" "1,234.56" → NaN
 *
 * A linha `"1.234" → 1.234` é a única ambiguidade real e a escolha é
 * deliberada: em metros (largura/altura padrão) `1.234` quer dizer 1,234 m, e é
 * também o que `Number("1.234")` já devolvia — manter isso evita reinterpretar
 * dado antigo. Quem quer mil duzentos e trinta e quatro escreve `1.234,00` ou
 * `1234`. Milhar com VÍRGULA (`1,234.56`, notação inglesa) é recusado de
 * propósito: seria indistinguível de `1,234` = um vírgula dois três quatro.
 */

/** Só dígitos, ponto, vírgula, espaço e sinal — qualquer outro caractere reprova. */
const CARACTERES_ACEITOS = /^[0-9.,\s+-]+$/;

/** `89` · `89,90` — vírgula decimal. */
const VIRGULA_DECIMAL = /^\d+(,\d+)?$/;
/** `89` · `89.90` · `1.234` — ponto decimal (um só ponto). */
const PONTO_DECIMAL = /^\d+(\.\d+)?$/;
/** `1.234` · `1.234,56` · `1.234.567,89` — ponto como separador de milhar. */
const MILHAR_COM_PONTO = /^\d{1,3}(\.\d{3})+(,\d+)?$/;

/**
 * Texto do campo → número. Devolve **NaN** para vazio ou inválido.
 *
 * Nunca devolve 0 por falta de entendimento: 0 só sai daqui se o usuário
 * realmente digitou zero. É esse contrato que impede o preço errado silencioso.
 */
export function textoParaNumero(texto: unknown): number {
  const t = String(texto ?? "").trim();
  if (!t || !CARACTERES_ACEITOS.test(t)) return NaN;

  // O sinal é retirado antes: as três formas abaixo descrevem só a parte
  // numérica, e assim "-" ou "+" no meio ("1-2") não passa despercebido.
  const negativo = t.startsWith("-");
  const corpo = (negativo || t.startsWith("+") ? t.slice(1) : t).replace(/\s/g, "");
  if (/[+-]/.test(corpo)) return NaN;

  let normalizado: string;
  if (VIRGULA_DECIMAL.test(corpo)) normalizado = corpo.replace(",", ".");
  else if (PONTO_DECIMAL.test(corpo)) normalizado = corpo;
  else if (MILHAR_COM_PONTO.test(corpo)) normalizado = corpo.replace(/\./g, "").replace(",", ".");
  else return NaN;

  const n = Number(normalizado);
  if (!Number.isFinite(n)) return NaN;
  return negativo ? -n : n;
}

/**
 * Número → texto do campo, para preencher o formulário na edição.
 *
 * Usa ponto decimal (`String(n)`) e não `toLocaleString`: o texto volta a
 * passar por `textoParaNumero`, que aceita as duas formas, e sem separador de
 * milhar não há como um valor lido do banco ser reinterpretado na volta.
 */
export function numeroParaTexto(valor: unknown): string {
  if (valor === null || valor === undefined || valor === "") return "";
  const n = typeof valor === "number" ? valor : Number(valor);
  return Number.isFinite(n) ? String(n) : "";
}

export type RegraNumero = {
  /** Nome do campo como aparece na tela — entra na mensagem de erro. */
  label: string;
  /** Mínimo aceito (inclusive). Padrão 0: os campos daqui são preço/medida/qtd. */
  min?: number;
  /** Máximo aceito (inclusive). */
  max?: number;
  /** Campo em branco é erro? Padrão `false`. */
  obrigatorio?: boolean;
  /** Recusa valor com casa decimal (quantidade de peças, dia do vencimento…). */
  inteiro?: boolean;
  /** Valor assumido quando o campo é opcional e ficou vazio. Padrão 0. */
  vazioComo?: number;
  /** Casas decimais para arredondar o resultado (`numeric` do Postgres é exato). */
  casas?: number;
};

export type ResultadoNumero = { ok: true; valor: number } | { ok: false; erro: string };

/**
 * Valida e converte um campo numérico digitado.
 *
 * Devolve `{ ok: false, erro }` com texto pronto para o `toast.error` — a
 * regra é RECUSAR, nunca "consertar" para 0. O campo vazio é o único caso em
 * que um valor é assumido, e só quando `obrigatorio` é falso.
 */
export function validaNumeroCampo(texto: unknown, regra: RegraNumero): ResultadoNumero {
  const t = String(texto ?? "").trim();
  const { label, min = 0, max, obrigatorio = false, inteiro = false, vazioComo = 0, casas } = regra;

  if (!t) {
    if (obrigatorio) return { ok: false, erro: `Informe ${label}.` };
    return { ok: true, valor: vazioComo };
  }

  const n = textoParaNumero(t);
  if (Number.isNaN(n)) {
    return {
      ok: false,
      erro: `${maiuscula(label)} não é um número válido: "${t}". Use apenas números, com vírgula ou ponto na casa decimal (ex.: 89,90).`,
    };
  }
  if (inteiro && !Number.isInteger(n)) {
    return { ok: false, erro: `${maiuscula(label)} deve ser um número inteiro, sem casa decimal.` };
  }
  if (n < min) {
    return {
      ok: false,
      erro:
        min === 0
          ? `${maiuscula(label)} não pode ser negativo.`
          : `${maiuscula(label)} deve ser no mínimo ${min}.`,
    };
  }
  if (max !== undefined && n > max) {
    return { ok: false, erro: `${maiuscula(label)} deve ser no máximo ${max}.` };
  }

  return { ok: true, valor: casas === undefined ? n : arredonda(n, casas) };
}

/**
 * Valida vários campos de uma vez e devolve o PRIMEIRO erro.
 *
 * Existe para o formulário não repetir `if (!r.ok) return toast.error(r.erro)`
 * em cada campo — e para a ordem dos erros seguir a ordem da tela.
 */
export function validaCamposNumericos<K extends string>(
  campos: Array<{ chave: K; texto: unknown; regra: RegraNumero }>,
): { ok: true; valores: Record<K, number> } | { ok: false; erro: string } {
  const valores = {} as Record<K, number>;
  for (const { chave, texto, regra } of campos) {
    const r = validaNumeroCampo(texto, regra);
    if (!r.ok) return { ok: false, erro: r.erro };
    valores[chave] = r.valor;
  }
  return { ok: true, valores };
}

/** Arredondamento por casa decimal, sem propagar lixo de ponto flutuante. */
export function arredonda(n: number, casas: number): number {
  const f = 10 ** casas;
  return Math.round(n * f) / f;
}

function maiuscula(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
