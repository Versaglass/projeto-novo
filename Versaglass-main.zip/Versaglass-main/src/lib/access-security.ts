import { supabase } from "@/integrations/supabase/client";
import { logSecurityEventAnon, logSecurityEventAuthed } from "@/lib/logging.functions";
import { runLogCall, type LogResult } from "@/lib/server-log";

export type SecurityChannel = "email" | "phone";
export type SecurityFlow = "first_password" | "password_recovery" | "admin_confirmation";

export type SecurityContact = {
  email?: string;
  phone?: string;
};

export function normalizePhone(phone: string) {
  const digits = phone.replace(/\D/g, "");
  if (!digits) return "";
  if (digits.startsWith("55")) return `+${digits}`;
  return `+55${digits}`;
}

export function validateStrongPassword(password: string) {
  const rules = [
    { ok: password.length >= 8, label: "mínimo de 8 caracteres" },
    { ok: /[A-ZÁÀÂÃÉÈÊÍÏÓÔÕÖÚÇÑ]/.test(password), label: "uma letra maiúscula" },
    { ok: /[a-záàâãéèêíïóôõöúçñ]/.test(password), label: "uma letra minúscula" },
    { ok: /\d/.test(password), label: "um número" },
    { ok: /[^A-Za-z0-9]/.test(password), label: "um símbolo" },
  ];
  const missing = rules.filter((rule) => !rule.ok).map((rule) => rule.label);
  return { valid: missing.length === 0, missing };
}

/**
 * Registra um evento em public.security_events.
 *
 * A gravação é feita por server function — o navegador não tem policy de
 * INSERT nesta tabela (P-07). Quando há sessão, `user_id`, `ip_address` e
 * `user_agent` são derivados no servidor; o `userId` recebido aqui é
 * ignorado, para que ninguém registre evento em nome de terceiro.
 *
 * Os fluxos de primeira senha e recuperação começam antes de existir sessão,
 * então há um caminho anônimo com whitelist de `flow`.
 */
export async function logSecurityEvent(event: {
  flow: SecurityFlow;
  action: string;
  email?: string;
  phone?: string;
  userId?: string;
  success?: boolean;
  metadata?: Record<string, unknown>;
}): Promise<LogResult> {
  const { data: sess } = await supabase.auth.getSession();
  const base = {
    flow: event.flow,
    action: event.action,
    success: event.success ?? true,
    metadata: event.metadata,
  };

  if (sess.session) {
    return runLogCall(
      () => logSecurityEventAuthed({ data: base }),
      `security_events:${event.action}`,
    );
  }

  return runLogCall(
    () => logSecurityEventAnon({ data: { ...base, email: event.email, phone: event.phone } }),
    `security_events:${event.action}`,
  );
}

export async function requestSecurityCode(params: {
  channel: SecurityChannel;
  flow: SecurityFlow;
  email?: string;
  phone?: string;
}) {
  if (params.channel === "email") {
    if (!params.email) throw new Error("Informe o e-mail.");
    const { error } = await supabase.auth.signInWithOtp({
      email: params.email.trim().toLowerCase(),
      options: { shouldCreateUser: false },
    });
    await logSecurityEvent({
      flow: params.flow,
      action: "request_email_code",
      email: params.email,
      success: !error,
    });
    if (error) throw error;
    return;
  }

  const phone = normalizePhone(params.phone ?? "");
  if (!phone) throw new Error("Informe um celular válido.");
  const { error } = await supabase.auth.signInWithOtp({ phone });
  await logSecurityEvent({
    flow: params.flow,
    action: "request_phone_code",
    phone,
    success: !error,
  });
  if (error) throw error;
}

export async function verifySecurityCode(params: {
  channel: SecurityChannel;
  flow: SecurityFlow;
  token: string;
  email?: string;
  phone?: string;
}) {
  if (!params.token.trim()) throw new Error("Informe o código recebido.");

  if (params.channel === "email") {
    if (!params.email) throw new Error("Informe o e-mail.");
    const { data, error } = await supabase.auth.verifyOtp({
      email: params.email.trim().toLowerCase(),
      token: params.token.trim(),
      type: "email",
    } as any);
    await logSecurityEvent({
      flow: params.flow,
      action: "verify_email_code",
      email: params.email,
      userId: data.user?.id,
      success: !error,
    });
    if (error) throw error;
    return data;
  }

  const phone = normalizePhone(params.phone ?? "");
  if (!phone) throw new Error("Informe um celular válido.");
  const { data, error } = await supabase.auth.verifyOtp({
    phone,
    token: params.token.trim(),
    type: "sms",
  } as any);
  await logSecurityEvent({
    flow: params.flow,
    action: "verify_phone_code",
    phone,
    userId: data.user?.id,
    success: !error,
  });
  if (error) throw error;
  return data;
}

export async function setSecurePassword(password: string) {
  const strength = validateStrongPassword(password);
  if (!strength.valid) {
    throw new Error(`Senha fraca. Adicione: ${strength.missing.join(", ")}.`);
  }
  const { data, error } = await supabase.auth.updateUser({ password });
  await logSecurityEvent({
    flow: "password_recovery",
    action: "set_new_password",
    userId: data.user?.id,
    success: !error,
  });
  if (error) throw error;
  return data;
}
