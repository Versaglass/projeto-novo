// Constrói uma URL do WhatsApp evitando o redirect via api.whatsapp.com
// (que costuma ser bloqueado em algumas redes/firewalls corporativos).
// - Desktop: usa web.whatsapp.com/send (abre direto o WhatsApp Web)
// - Mobile:  usa wa.me (abre o app instalado)

export function normalizeBrPhone(raw?: string | null): string {
  const phone = String(raw ?? "").replace(/\D/g, "");
  if (!phone) return "";
  return phone.startsWith("55") ? phone : `55${phone}`;
}

export type TelefoneBrValidado = { ok: true; telefone: string } | { ok: false; erro: string };

/**
 * As cinco frases de recusa, para a mesma regra servir a assuntos diferentes.
 *
 * Existe porque a Revisão 92 precisou validar o telefone DA EMPRESA com a mesma
 * lógica já provada para o telefone DO CLIENTE — e reaproveitar a função sem
 * isto faria o cadastro da empresa dizer "Cliente sem telefone cadastrado…",
 * mandando o usuário corrigir um cadastro que não é o que está na tela.
 */
export type MensagensTelefone = {
  vazio: string;
  semNumero: (original: string) => string;
  semDdd: string;
  naoBrasileiro: (original: string) => string;
  dddInvalido: (original: string) => string;
};

/**
 * Textos ORIGINAIS, validados por clique real na Revisão 58.
 *
 * ⚠️ Não altere: são o padrão de `validarTelefoneBr`, usado por Orçamentos e
 * pela Venda direta. Assunto novo cria a sua própria constante, como abaixo.
 */
export const MENSAGENS_TELEFONE_CLIENTE: MensagensTelefone = {
  vazio:
    "Cliente sem telefone cadastrado. Cadastre o telefone do cliente para enviar pelo WhatsApp.",
  semNumero: (o) =>
    `O telefone cadastrado para este cliente não tem nenhum número ("${o}"). Corrija o cadastro do cliente para enviar pelo WhatsApp.`,
  semDdd:
    "O telefone do cliente está sem DDD. Inclua o DDD no cadastro (ex.: 11 90000-0000) para enviar pelo WhatsApp.",
  naoBrasileiro: (o) =>
    `O telefone do cliente não parece um número brasileiro válido ("${o}"). Use DDD + número (ex.: 11 90000-0000).`,
  dddInvalido: (o) =>
    `O DDD do telefone do cliente é inválido ("${o}"). Informe o DDD sem o zero inicial (ex.: 11 90000-0000).`,
};

/** Mesma regra, falando do cadastro da EMPRESA (Revisão 92). */
export const MENSAGENS_TELEFONE_EMPRESA: MensagensTelefone = {
  vazio: "Informe o telefone da empresa.",
  semNumero: (o) =>
    `O telefone da empresa não tem nenhum número ("${o}"). Informe DDD + número (ex.: 11 90000-0000).`,
  semDdd: "O telefone da empresa está sem DDD. Informe DDD + número (ex.: 11 90000-0000).",
  naoBrasileiro: (o) =>
    `O telefone da empresa não parece um número brasileiro válido ("${o}"). Use DDD + número (ex.: 11 90000-0000).`,
  dddInvalido: (o) =>
    `O DDD do telefone da empresa é inválido ("${o}"). Informe o DDD sem o zero inicial (ex.: 11 90000-0000).`,
};

/**
 * Valida ANTES de montar o link, em vez de deixar passar em silêncio.
 *
 * `normalizeBrPhone` decide o DDI pelo PREFIXO (`startsWith("55")`), e isso é
 * ambíguo em dois casos reais que a Revisão 56 documentou:
 *
 *   · `5533334444` é DDD 55 (Santa Maria/RS) + fixo — mas o prefixo faz parecer
 *     DDI 55 já aplicado, e o número saía como país 55 + DDD 33 + 6 dígitos;
 *   · `999998888` (sem DDD) virava `55999998888`, um número que não existe.
 *
 * A desambiguação correta é pela QUANTIDADE de dígitos, não pelo prefixo:
 *
 *   |  8 ou  9 | sem DDD                      | irrecuperável → recusa       |
 *   |       10 | DDD + fixo (8)               | falta o DDI   → prefixa 55   |
 *   |       11 | DDD + celular (9)            | falta o DDI   → prefixa 55   |
 *   |       12 | 55 + DDD + fixo (8)          | completo      → mantém       |
 *   |       13 | 55 + DDD + celular (9)       | completo      → mantém       |
 *
 * Nada é inventado: o que não dá para resolver com certeza é RECUSADO com uma
 * mensagem que diz o que corrigir, nunca "consertado" por adivinhação.
 *
 * Esta é a regra; `validarTelefoneBr` é ela com as frases do cliente.
 */
export function validarTelefoneBrCom(
  raw: string | null | undefined,
  msgs: MensagensTelefone,
): TelefoneBrValidado {
  const original = String(raw ?? "").trim();
  if (!original) {
    return { ok: false, erro: msgs.vazio };
  }

  const digitos = original.replace(/\D/g, "");
  if (!digitos) {
    // Cobre o telefone só com espaços e o texto sem número nenhum — os dois
    // passavam pelo `Boolean(telefone)` e abriam o WhatsApp SEM destinatário.
    return { ok: false, erro: msgs.semNumero(original) };
  }

  if (digitos.length === 8 || digitos.length === 9) {
    return { ok: false, erro: msgs.semDdd };
  }

  let completo: string;
  if (digitos.length === 10 || digitos.length === 11) {
    completo = `55${digitos}`;
  } else if ((digitos.length === 12 || digitos.length === 13) && digitos.startsWith("55")) {
    completo = digitos;
  } else {
    return { ok: false, erro: msgs.naoBrasileiro(original) };
  }

  // DDD real: nenhum existe começando em 0 nem terminando em 0. Pega tanto o
  // "0" de tronco antigo (011 …) quanto dígito digitado errado.
  const ddd = completo.slice(2, 4);
  if (ddd[0] === "0" || ddd[1] === "0") {
    return { ok: false, erro: msgs.dddInvalido(original) };
  }

  return { ok: true, telefone: completo };
}

export function validarTelefoneBr(raw?: string | null): TelefoneBrValidado {
  return validarTelefoneBrCom(raw, MENSAGENS_TELEFONE_CLIENTE);
}

function isMobile(): boolean {
  if (typeof navigator === "undefined") return false;
  return /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
}

export function buildWhatsAppUrl(phone: string, message: string): string {
  const normalized = normalizeBrPhone(phone);
  const text = encodeURIComponent(message);
  if (!normalized) {
    return isMobile()
      ? `https://wa.me/?text=${text}`
      : `https://web.whatsapp.com/send?text=${text}`;
  }
  return isMobile()
    ? `https://wa.me/${normalized}?text=${text}`
    : `https://web.whatsapp.com/send?phone=${normalized}&text=${text}`;
}

/** Abre o WhatsApp como um clique de link real, sem carregar dentro do preview. */
export function openWhatsApp(phone: string, message: string): boolean {
  const url = buildWhatsAppUrl(phone, message);
  if (typeof document === "undefined") return false;

  const link = document.createElement("a");
  link.href = url;
  link.target = "_blank";
  link.rel = "noopener noreferrer";
  document.body.appendChild(link);
  link.click();
  link.remove();
  return true;
}
