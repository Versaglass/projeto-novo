// =====================================================================
// Tradução de erros de autenticação para mensagem de PRODUTO.
//
// PROBLEMA QUE ESTE MÓDULO RESOLVE (Revisão 21, Defeito 1)
//   Os fluxos de login, cadastro, primeiro acesso, recuperação de senha e
//   onboarding faziam `toast.error(err.message)`. O texto do GoTrue/PostgREST
//   ia cru para a tela: em inglês, sem contexto e sem ação — o usuário lia
//   "Failed to fetch" ou "email rate limit exceeded" e não sabia o que fazer.
//
//   Pior que a estética: `User already registered` CONFIRMA a existência de uma
//   conta. É exatamente o oráculo de enumeração que P-24 eliminou do login e
//   que voltava pela porta do cadastro.
//
// REGRAS DO TEXTO (as mesmas de P-24)
//   1. Nunca confirma nem nega que um e-mail tem conta.
//   2. Nunca cita provedor (Supabase, GoTrue, Google), tabela, código de erro
//      nem nome de campo interno.
//   3. Nunca cita número de limite do provedor — "aguarde alguns minutos" em
//      vez de "máximo de 2 por hora", que envelhece e entrega configuração.
//   4. Sempre em português e sempre com a próxima ação do usuário.
//
// DIAGNÓSTICO PRESERVADO
//   O erro original vai INTEIRO para `console.error`, com um rótulo de contexto.
//   Só o que aparece na tela muda. Nenhuma chamada de log de servidor existente
//   é removida — este módulo não substitui `logEvent`/`serverLog`, apenas
//   escolhe a frase exibida.
// =====================================================================

/** Extrai um texto pesquisável de qualquer formato de erro. */
function textoDoErro(erro: unknown): string {
  if (!erro) return "";
  if (typeof erro === "string") return erro;
  const e = erro as {
    message?: unknown;
    error_description?: unknown;
    code?: unknown;
    error?: unknown;
  };
  return [e.message, e.error_description, e.error, e.code]
    .filter((v) => typeof v === "string")
    .join(" ");
}

// Ordem IMPORTA: o primeiro padrão que casar vence. Os casos mais específicos
// (e os que mais vazam informação) vêm antes dos genéricos.
const REGRAS: { quando: RegExp; mensagem: string }[] = [
  {
    // Rede/CORS/servidor fora do ar. Foi o "Failed to fetch" visto na tela.
    quando:
      /failed to fetch|networkerror|network error|load failed|fetch failed|err_(internet|connection)|timeout|aborted/i,
    mensagem:
      "Não foi possível conectar ao servidor. Verifique sua conexão com a internet e tente novamente.",
  },
  {
    // Excesso de tentativas. Sem número, sem nome do provedor (regra 3).
    quando: /rate limit|too many requests|over_email_send|over_request_rate|over_sms_send|429/i,
    mensagem: "Muitas tentativas em pouco tempo. Aguarde alguns minutos e tente novamente.",
  },
  {
    // CONTA JÁ EXISTENTE — o caso mais sensível. A resposta é deliberadamente
    // ambígua: serve tanto para "já existe" quanto para "dado recusado", então
    // não dá para deduzir a existência do cadastro a partir dela.
    quando:
      /already registered|already exists|user_already_exists|email_exists|duplicate key|23505/i,
    mensagem:
      "Não foi possível concluir o cadastro com estes dados. Se você já tem uma conta, use a opção de entrar ou a de recuperação de senha.",
  },
  {
    // Credencial inválida, conta inexistente e e-mail não confirmado recebem a
    // MESMA resposta — é o texto de P-24, e a indistinção é o ponto.
    quando:
      /invalid login|invalid credentials|invalid_grant|email not confirmed|user not found|invalid user/i,
    mensagem:
      "Não foi possível entrar. Verifique seu e-mail e senha ou use a opção de recuperação de senha.",
  },
  {
    quando: /invalid email|email_address_invalid|unable to validate email|email.*not valid/i,
    mensagem: "Informe um e-mail válido.",
  },
  {
    quando: /weak.?password|password should be|password.*at least|password_too_short|too short/i,
    mensagem:
      "Senha muito fraca. Escolha uma senha mais longa, combinando letras, números e símbolos.",
  },
  {
    // Código de verificação e link de convite/recuperação: expirado, já usado
    // ou adulterado colapsam na mesma frase, com a ação certa (pedir outro).
    quando:
      /otp_expired|token has expired|expired|invalid token|invalid_otp|token not found|access_denied/i,
    mensagem: "Este código ou link expirou ou já foi utilizado. Solicite um novo e tente de novo.",
  },
  {
    quando: /captcha/i,
    mensagem:
      "Não foi possível validar a verificação de segurança. Recarregue a página e tente novamente.",
  },
  {
    // Sessão ausente/expirada fica por último: "session" e "jwt" aparecem dentro
    // de mensagens de outras categorias e roubariam o casamento delas.
    quando: /auth session missing|session_not_found|jwt expired|jwt|not authenticated|401/i,
    mensagem: "Sua sessão expirou. Entre novamente para continuar.",
  },
  {
    quando: /signup.*(disabled|not allowed)|signups not allowed|403/i,
    mensagem: "No momento não é possível concluir esta operação. Tente novamente mais tarde.",
  },
];

/**
 * Mensagem segura para exibir ao usuário.
 *
 * @param contexto rótulo curto do fluxo, só para o `console.error`
 *                 (ex.: "login", "cadastro", "primeira-senha").
 * @param erro     o erro original, em qualquer formato.
 * @param padrao   frase de produto quando nada casar. SEMPRE em português e
 *                 específica do fluxo — é ela que o usuário lê no caso
 *                 desconhecido, então não pode ser um genérico vazio.
 */
export function mensagemDeErroDeAuth(contexto: string, erro: unknown, padrao: string): string {
  // Diagnóstico completo continua no console — só a tela é higienizada.
  console.error(`[auth:${contexto}]`, erro);

  const texto = textoDoErro(erro);
  if (!texto) return padrao;

  // PASSTHROUGH da sentinela de ambiente (`dev-remote-guard.ts`).
  //
  // Aquela mensagem já é texto de produto: escrita por nós, em português, sem
  // nome de provedor, sem código de erro e sem detalhe interno — e diz a causa
  // ("apontado para um Supabase REMOTO") e a saída (apontar para o local ou
  // declarar `VITE_PERMITIR_SUPABASE_REMOTO=1`). Substituí-la pelo genérico
  // escondia exatamente a informação que resolve o problema (Revisão 25).
  //
  // Guardado por `import.meta.env.DEV` de propósito: a sentinela só existe em
  // desenvolvimento, então em produção esta regra nunca casaria — e o guard faz
  // o Vite eliminar o ramo INTEIRO, inclusive o literal, mantendo o bundle
  // público sem nenhuma string da sentinela (verificado na Revisão 26).
  if (import.meta.env.DEV) {
    const mensagemOriginal = (erro as { message?: unknown })?.message;
    if (typeof mensagemOriginal === "string" && mensagemOriginal.startsWith("Escrita bloqueada:")) {
      return mensagemOriginal;
    }
  }

  for (const regra of REGRAS) {
    if (regra.quando.test(texto)) return regra.mensagem;
  }
  return padrao;
}
