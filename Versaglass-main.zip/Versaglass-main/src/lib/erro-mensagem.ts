/**
 * Extrai o `.message` de um erro capturado, sem exigir que ele seja `Error`.
 *
 * POR QUE existe (Revisão 53): ao trocar `catch (e: any)` por
 * `catch (e: unknown)`, o TypeScript passa a exigir narrowing antes de ler
 * `e.message`. O idioma mais curto seria `e instanceof Error ? e.message : …`,
 * e ele **mudaria comportamento** neste projeto: o `PostgrestError` do
 * Supabase **não é** instância de `Error` — é um objeto solto
 * `{ message, details, hint, code }`. Com `instanceof`, toda mensagem vinda do
 * PostgREST cairia no texto padrão, e o usuário deixaria de ver o motivo real
 * da falha.
 *
 * Esta função reproduz exatamente o que `e?.message` fazia antes: devolve a
 * mensagem se houver uma, em `Error` ou em objeto solto, e `undefined` caso
 * contrário — para que o `|| "texto padrão"` de cada chamador continue
 * decidindo igual.
 *
 * Não confundir com `mensagemDeErroDeAuth` (`auth-error-message.ts`): aquela
 * MAPEIA o erro para uma frase de produto higienizada; esta só LÊ o campo.
 */
export function mensagemDoErro(erro: unknown): string | undefined {
  if (erro instanceof Error) return erro.message;
  return campoTextoDoErro(erro, "message");
}

/**
 * Mesma ideia, para os outros campos de texto que aparecem em erro capturado:
 * `name` do `DOMException` (é ele que distingue "permissão negada" de
 * "microfone ausente" no `getUserMedia`), e `error_description` / `hint`, que
 * o PostgREST e o GoTrue mandam.
 *
 * Existe porque `DOMException` **não** é garantidamente instância de `Error`, e
 * `PostgrestError` seguramente não é — então `instanceof` não serve para ler
 * nenhum dos dois. A leitura é estrutural, como era com `any`.
 */
export function campoTextoDoErro(erro: unknown, campo: string): string | undefined {
  if (typeof erro === "object" && erro !== null && campo in erro) {
    const v = (erro as Record<string, unknown>)[campo];
    if (typeof v === "string") return v;
  }
  return undefined;
}
