import { categoriaProjetoLabel } from "@/lib/project-category";
import { normalizaArea } from "@/lib/project-area";
import { areaDoTipoProjeto } from "@/lib/quote-item-tipo-helpers";
import type { QuoteItemTipoProjeto } from "@/lib/tipo-projeto-orcamento";
import {
  createDefaultProjectData,
  type ProjectData,
  type ProjectDataV1,
} from "@/types/project-data";

/**
 * Item de projeto de Vidraçaria para fins comerciais (PDF / snapshot).
 * Não infere por descrição. Estoque puro (sem area/tipo) não conta.
 */
export function ehItemProjetoVidracaria(item: {
  project_data?: unknown;
  tipo_projeto?: QuoteItemTipoProjeto | null;
}): boolean {
  const bruto = item.project_data;
  if (bruto && typeof bruto === "object" && !Array.isArray(bruto)) {
    const area = normalizaArea((bruto as { area?: unknown }).area);
    if (area === "vidracaria") return true;
  }
  const tipo = item.tipo_projeto;
  if (tipo && areaDoTipoProjeto(tipo) === "vidracaria") return true;
  return false;
}

/** Rótulo de tela a partir do ID canônico salvo em `project_data.vidro`. */
export function rotuloVidroPdf(vidro: string | null | undefined): string {
  const v = (vidro ?? "").trim();
  if (!v) return "—";
  return categoriaProjetoLabel(v);
}

/**
 * Normaliza espessura para exibição no PDF.
 * `6` / `"6"` / `"6mm"` / `"6 mm"` → `6 mm`; vazio → `—`.
 * Valores inesperados são devolvidos como vieram (sem parsing destrutivo).
 */
export function formatEspessuraVidroPdf(valor: string | null | undefined): string {
  const t = (valor ?? "").trim();
  if (!t) return "—";
  const soNumero = t.match(/^(\d+)\s*(mm)?$/i);
  if (soNumero) return `${soNumero[1]} mm`;
  return t;
}

/**
 * Alinha o texto de espessura aos chips do formulário (`4mm` … `12mm`).
 * Se não casar com o padrão numérico, devolve o valor trimado (ou null).
 */
export function espessuraParaChip(valor: string | null | undefined): string | null {
  const t = (valor ?? "").trim();
  if (!t) return null;
  const m = t.match(/^(\d+)\s*mm$/i) || t.match(/^(\d+)$/);
  if (m) return `${m[1]}mm`;
  return t;
}

/**
 * Anexa classificação de vidro ao snapshot do item (cópia independente).
 * Só age em área Vidraçaria. Se não houver `project_data` ainda, cria um
 * envelope mínimo (sem peças) para carregar `vidro` / `espessuraVidro`.
 */
export function anexarClassificacaoVidroAoProjectData(
  snapshot: ProjectData | null,
  opts: {
    area?: string | null;
    categoria?: string | null;
    espessura?: string | null;
    nome: string;
    larguraMetros: number;
    alturaMetros: number;
  },
): ProjectData | null {
  const area = normalizaArea(opts.area) ?? (snapshot ? normalizaArea(snapshot.area) : null);
  if (area !== "vidracaria") return snapshot;

  const base: ProjectDataV1 =
    snapshot ??
    createDefaultProjectData({
      nome: opts.nome,
      area: "vidracaria",
      larguraMetros: opts.larguraMetros,
      alturaMetros: opts.alturaMetros,
    });

  const categoria = (opts.categoria ?? "").trim() || null;
  const espBruta = (opts.espessura ?? "").trim() || null;
  const espessura = espBruta ? (espessuraParaChip(espBruta) ?? espBruta) : null;

  return {
    ...base,
    // Preferir colunas do template/catálogo no apply; preservar se já no snapshot.
    vidro: categoria ?? base.vidro ?? null,
    espessuraVidro: espessura ?? base.espessuraVidro ?? null,
  };
}

/** Atualiza só `espessuraVidro` no snapshot (edição de chip no orçamento). */
export function sincronizarEspessuraVidroNoProjectData(
  projectData: ProjectData | null | undefined,
  espessura: string | null | undefined,
  meta?: {
    tipo_projeto?: QuoteItemTipoProjeto | null;
    nome?: string;
    larguraMm?: number;
    alturaMm?: number;
  },
): ProjectData | null | undefined {
  const valor = (espessura ?? "").trim() || null;
  const ehVidra =
    (projectData && normalizaArea(projectData.area) === "vidracaria") ||
    (meta?.tipo_projeto && areaDoTipoProjeto(meta.tipo_projeto) === "vidracaria");

  if (!ehVidra) return projectData;

  if (projectData) {
    return { ...projectData, espessuraVidro: valor };
  }

  // Tipo Vidraçaria sem desenho: cria envelope mínimo para persistir a espessura.
  if (meta?.tipo_projeto && areaDoTipoProjeto(meta.tipo_projeto) === "vidracaria") {
    return {
      ...createDefaultProjectData({
        nome: meta.nome ?? "Item",
        area: "vidracaria",
        larguraMetros: (meta.larguraMm ?? 0) / 1000,
        alturaMetros: (meta.alturaMm ?? 0) / 1000,
      }),
      espessuraVidro: valor,
    };
  }

  return projectData;
}
