import type { AreaOperacional } from "@/lib/project-area";
import { ROTULO_SUBTIPO, SUBTIPOS_POR_AREA, type SubtipoDaArea } from "@/lib/project-subtypes";
import {
  TIPOS_PROJETO_ORCAMENTO,
  ehTipoProjetoVidracaria,
  type QuoteItemTipoProjeto,
} from "@/lib/tipo-projeto-orcamento";

const VALORES_ESQUADRIAS = new Set<string>(SUBTIPOS_POR_AREA.esquadrias);

const VALORES_ENUM = new Set<string>([
  ...TIPOS_PROJETO_ORCAMENTO.map((t) => t.value),
  ...SUBTIPOS_POR_AREA.esquadrias,
]);

/** Confere se o valor é um membro do enum operacional (Vidraçaria + Esquadrias). */
export function ehQuoteItemTipoProjeto(valor: string): valor is QuoteItemTipoProjeto {
  return VALORES_ENUM.has(valor);
}

/**
 * Área operacional inferida pelo ID do tipo (namespace `_esquadrias`).
 * Não usa rótulo — só IDs.
 */
export function areaDoTipoProjeto(tipo: QuoteItemTipoProjeto): AreaOperacional | null {
  if (ehTipoProjetoVidracaria(tipo)) return "vidracaria";
  if (VALORES_ESQUADRIAS.has(tipo)) return "esquadrias";
  return null;
}

/** `tipo_projeto` → subtipo canônico (identidade nas áreas operacionais). */
export function subtipoDoTipoProjeto(
  tipo: QuoteItemTipoProjeto,
): SubtipoDaArea<"vidracaria"> | SubtipoDaArea<"esquadrias"> | null {
  const area = areaDoTipoProjeto(tipo);
  if (!area) return null;
  if (area === "vidracaria") return tipo as SubtipoDaArea<"vidracaria">;
  return tipo as SubtipoDaArea<"esquadrias">;
}

/** Opções do select Tipo para uma área operacional — deriva de taxonomias centrais. */
export function tiposProjetoOrcamentoDaArea(
  area: AreaOperacional,
): ReadonlyArray<{ value: QuoteItemTipoProjeto; label: string }> {
  if (area === "vidracaria") return TIPOS_PROJETO_ORCAMENTO;
  return SUBTIPOS_POR_AREA.esquadrias.map((s) => ({
    value: s as QuoteItemTipoProjeto,
    label: ROTULO_SUBTIPO[s],
  }));
}

/** Rótulo de tela para qualquer valor do enum (Vidraçaria ou Esquadrias). */
export function rotuloTipoProjetoOrcamento(tipo: QuoteItemTipoProjeto): string {
  if (ehTipoProjetoVidracaria(tipo)) {
    return TIPOS_PROJETO_ORCAMENTO.find((t) => t.value === tipo)?.label ?? tipo;
  }
  if (VALORES_ESQUADRIAS.has(tipo)) {
    return ROTULO_SUBTIPO[tipo as SubtipoDaArea<"esquadrias">];
  }
  return tipo;
}
