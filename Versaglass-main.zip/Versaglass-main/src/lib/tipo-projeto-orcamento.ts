import type { Database } from "@/integrations/supabase/types";

/** Espelha `public.quote_item_tipo_projeto` (Vidraçaria + Esquadrias). */
export type QuoteItemTipoProjeto = Database["public"]["Enums"]["quote_item_tipo_projeto"];

/**
 * Lista fechada dos 13 tipos comerciais de **Vidraçaria** — mesma ordem/rótulos
 * históricos (Rev. 140). Fonte canônica dos subtipos de Vidraçaria em
 * `project-subtypes.ts` (alinhamento em compile-time).
 *
 * Semântica preservada: NÃO inclui Esquadrias. Para o conjunto operacional
 * completo use `tiposProjetoOrcamentoDaArea` / `ehQuoteItemTipoProjeto` /
 * `rotuloTipoProjetoOrcamento` em `quote-item-tipo-helpers.ts`.
 */
export const TIPOS_PROJETO_ORCAMENTO = [
  { value: "janela", label: "Janela" },
  { value: "porta", label: "Porta" },
  { value: "fixo", label: "Fixo" },
  { value: "box", label: "Box" },
  { value: "fechamento_pia", label: "Fechamento de Pia" },
  { value: "espelho", label: "Espelho" },
  { value: "bascula_maxiar_pivotante", label: "Bascula/Maxi-ar/Pivotante" },
  { value: "guarda_corpo", label: "Guarda-Corpo" },
  { value: "reposicao", label: "Reposição" },
  { value: "sacadas", label: "Sacadas" },
  { value: "articulados", label: "Articulados" },
  { value: "muro", label: "Muro" },
  { value: "vitrine", label: "Vitrine" },
] as const;

/** Os 13 IDs de Vidraçaria — subset de `QuoteItemTipoProjeto`. */
export type TipoProjetoVidracaria = (typeof TIPOS_PROJETO_ORCAMENTO)[number]["value"];

/** Garante que cada ID de Vidraçaria é membro do enum Postgres. */
type _VidracariaNoEnum = TipoProjetoVidracaria extends QuoteItemTipoProjeto ? true : never;
const _vidracariaNoEnum: _VidracariaNoEnum = true;
void _vidracariaNoEnum;

const ROTULO_VIDRACARIA = Object.fromEntries(
  TIPOS_PROJETO_ORCAMENTO.map((t) => [t.value, t.label]),
) as Record<TipoProjetoVidracaria, string>;

const VALORES_VIDRACARIA = new Set<string>(TIPOS_PROJETO_ORCAMENTO.map((t) => t.value));

export function ehTipoProjetoVidracaria(valor: string): valor is TipoProjetoVidracaria {
  return VALORES_VIDRACARIA.has(valor);
}

/**
 * Rótulo de Vidraçaria. Para qualquer valor do enum (incl. Esquadrias),
 * preferir `rotuloTipoProjetoOrcamento` em `quote-item-tipo-helpers.ts`.
 */
export function rotuloTipoProjeto(tipo: QuoteItemTipoProjeto): string {
  if (ehTipoProjetoVidracaria(tipo)) return ROTULO_VIDRACARIA[tipo];
  return tipo;
}
