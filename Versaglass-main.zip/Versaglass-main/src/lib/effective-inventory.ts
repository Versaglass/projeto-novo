/**
 * Estoque efetivo = inventory_items da empresa + manufacturer_products globais ativos.
 *
 * Módulo PURO (sem React/Supabase) — testável offline.
 * IDs de manufacturer_product e inventory_item NÃO são intercambiáveis.
 */

export type InventoryCategoria =
  | "aluminio"
  | "vidro"
  | "ferragem"
  | "acessorio"
  | "perfil"
  | "led"
  | "cola"
  | "outros"
  | "aco_metalon"
  | "chapa_aco"
  | "solda"
  | "mdf"
  | "ferragem_moveis"
  | "fita_borda"
  | "marmore"
  | "quartzo"
  | "porcelanato";

export type InventoryUnidade = "un" | "m" | "m2" | "kg" | "pc" | "cx";

export type InventoryManufacturerProductRef = {
  id: string;
  name: string;
  source_code: string;
  primary_image_path: string | null;
  active: boolean;
  product_manufacturers: { id: string; name: string; active: boolean } | null;
};

/** Subconjunto de inventory_items usado no merge (sem acoplar ao hook). */
export type InventoryItemLike = {
  id: string;
  categoria: InventoryCategoria;
  nome: string;
  descricao: string | null;
  unidade: InventoryUnidade;
  quantidade: number;
  estoque_minimo: number;
  custo_unit: number;
  preco_venda: number;
  fornecedor: string | null;
  supplier_id: string | null;
  localizacao: string | null;
  imagem_url: string | null;
  observacoes: string | null;
  sku: string | null;
  ncm: string | null;
  ativo: boolean;
  originado_de_projeto: boolean;
  manufacturer_product_id: string | null;
  manufacturer_product?: InventoryManufacturerProductRef | null;
};

export type EffectiveInventorySource = "inventory" | "global";

export type EffectiveInventoryItem = {
  /** Chave estável na listagem (não confundir com FK). */
  rowKey: string;
  source: EffectiveInventorySource;
  /** Presente só quando source === "inventory". */
  inventoryItemId: string | null;
  /** Presente quando o item tem origem global (virtual ou materializado). */
  manufacturerProductId: string | null;
  /** Null em virtual sem inventory_category no global — exige escolha ao salvar. */
  categoria: InventoryCategoria | null;
  nome: string;
  descricao: string | null;
  /** Null em virtual sem unit no global — exige escolha ao salvar. */
  unidade: InventoryUnidade | null;
  quantidade: number;
  estoque_minimo: number;
  custo_unit: number;
  preco_venda: number;
  fornecedor: string | null;
  supplier_id: string | null;
  localizacao: string | null;
  imagem_url: string | null;
  observacoes: string | null;
  sku: string | null;
  ncm: string | null;
  ativo: boolean;
  originado_de_projeto: boolean;
  manufacturer_product: InventoryManufacturerProductRef | null;
  /** Item persistido completo — só em source inventory. */
  inventoryItem: InventoryItemLike | null;
};

export type GlobalManufacturerProductRow = {
  id: string;
  name: string;
  description: string | null;
  source_code: string;
  inventory_category: string | null;
  unit: string | null;
  primary_image_path: string | null;
  active: boolean;
  product_manufacturers: { id: string; name: string; active: boolean } | null;
};

const CATEGORIA_SET = new Set<string>([
  "aluminio",
  "vidro",
  "ferragem",
  "acessorio",
  "perfil",
  "led",
  "cola",
  "outros",
  "aco_metalon",
  "chapa_aco",
  "solda",
  "mdf",
  "ferragem_moveis",
  "fita_borda",
  "marmore",
  "quartzo",
  "porcelanato",
]);

const UNIT_SET = new Set<string>(["un", "m", "m2", "kg", "pc", "cx"]);

export function asInventoryCategoria(value: string | null | undefined): InventoryCategoria | null {
  if (!value || !CATEGORIA_SET.has(value)) return null;
  return value as InventoryCategoria;
}

export function asInventoryUnidade(value: string | null | undefined): InventoryUnidade | null {
  if (!value || !UNIT_SET.has(value)) return null;
  return value as InventoryUnidade;
}

export function inventoryItemToEffective(item: InventoryItemLike): EffectiveInventoryItem {
  return {
    rowKey: `inv:${item.id}`,
    source: "inventory",
    inventoryItemId: item.id,
    manufacturerProductId: item.manufacturer_product_id,
    categoria: item.categoria,
    nome: item.nome,
    descricao: item.descricao,
    unidade: item.unidade,
    quantidade: Number(item.quantidade) || 0,
    estoque_minimo: Number(item.estoque_minimo) || 0,
    custo_unit: Number(item.custo_unit) || 0,
    preco_venda: Number(item.preco_venda) || 0,
    fornecedor: item.fornecedor,
    supplier_id: item.supplier_id,
    localizacao: item.localizacao,
    imagem_url: item.imagem_url,
    observacoes: item.observacoes,
    sku: item.sku,
    ncm: item.ncm,
    ativo: item.ativo,
    originado_de_projeto: item.originado_de_projeto === true,
    manufacturer_product: item.manufacturer_product ?? null,
    inventoryItem: item,
  };
}

/**
 * Produto global ainda sem inventory_item da empresa.
 * Defaults comerciais em 0 — NÃO grava no banco só por exibir.
 */
export function globalProductToEffective(
  product: GlobalManufacturerProductRow,
): EffectiveInventoryItem | null {
  if (!product.active) return null;
  if (product.product_manufacturers && product.product_manufacturers.active === false) {
    return null;
  }
  const categoria = asInventoryCategoria(product.inventory_category);
  const unidade = asInventoryUnidade(product.unit);
  const mfgRef: InventoryManufacturerProductRef = {
    id: product.id,
    name: product.name,
    source_code: product.source_code,
    primary_image_path: product.primary_image_path,
    active: product.active,
    product_manufacturers: product.product_manufacturers,
  };
  return {
    rowKey: `global:${product.id}`,
    source: "global",
    inventoryItemId: null,
    manufacturerProductId: product.id,
    categoria,
    nome: product.name,
    descricao: product.description,
    unidade,
    quantidade: 0,
    estoque_minimo: 0,
    custo_unit: 0,
    preco_venda: 0,
    fornecedor: null,
    supplier_id: null,
    localizacao: null,
    imagem_url: null,
    observacoes: null,
    sku: product.source_code || null,
    ncm: null,
    ativo: true,
    originado_de_projeto: false,
    manufacturer_product: mfgRef,
    inventoryItem: null,
  };
}

/**
 * Une inventory da empresa + globais ativos, sem duplicar quando já materializado.
 * Inventory materializado (mesmo com global inativo) permanece.
 */
export function mergeEffectiveInventory(
  inventoryItems: readonly InventoryItemLike[],
  globalProducts: readonly GlobalManufacturerProductRow[],
): EffectiveInventoryItem[] {
  const adopted = new Set<string>();
  for (const item of inventoryItems) {
    if (item.manufacturer_product_id) adopted.add(item.manufacturer_product_id);
  }

  const out: EffectiveInventoryItem[] = inventoryItems.map(inventoryItemToEffective);

  for (const product of globalProducts) {
    if (adopted.has(product.id)) continue;
    const virtual = globalProductToEffective(product);
    if (virtual) out.push(virtual);
  }

  out.sort((a, b) => {
    const ca = a.categoria ?? "";
    const cb = b.categoria ?? "";
    const cat = ca.localeCompare(cb);
    if (cat !== 0) return cat;
    return a.nome.localeCompare(b.nome, "pt-BR", { sensitivity: "base" });
  });

  return out;
}

/** Empresa pode excluir só itens manuais (sem vínculo global). */
export function canDeleteEffectiveItem(item: EffectiveInventoryItem): boolean {
  return item.source === "inventory" && !item.manufacturerProductId;
}

/** Precisa de inventory_items.id real antes de vender/baixar. */
export function requiresMaterialization(item: EffectiveInventoryItem): boolean {
  return item.source === "global" || !item.inventoryItemId;
}

export function effectiveItemToThumb(item: EffectiveInventoryItem): {
  nome: string;
  imagem_url: string | null;
  manufacturer_product: InventoryManufacturerProductRef | null;
} {
  return {
    nome: item.nome,
    imagem_url: item.imagem_url,
    manufacturer_product: item.manufacturer_product,
  };
}
