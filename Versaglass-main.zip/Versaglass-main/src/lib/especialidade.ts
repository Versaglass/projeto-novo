/**
 * Especialidades usadas no hub de Orçamentos (cards / search `esp`).
 * Superfície operacional atual — alinhada a `AREAS_OPERACIONAIS`.
 * IDs antigos (serralheria, marcenaria, marmoraria) deixam de ser válidos
 * na URL e são ignorados por `parseEspecialidade` (não quebram a página).
 */
export const ESPECIALIDADE_IDS = ["vidracaria", "esquadrias"] as const;

export type Especialidade = (typeof ESPECIALIDADE_IDS)[number];

export function isEspecialidade(value: unknown): value is Especialidade {
  return typeof value === "string" && ESPECIALIDADE_IDS.some((id) => id === value);
}

/** Valida um `esp` vindo da URL; devolve `undefined` quando não é uma especialidade conhecida. */
export function parseEspecialidade(value: unknown): Especialidade | undefined {
  return isEspecialidade(value) ? value : undefined;
}
