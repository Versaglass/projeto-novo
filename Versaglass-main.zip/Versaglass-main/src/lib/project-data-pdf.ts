// =====================================================================
// Desenho paramétrico no PDF do orçamento.
//
// VETORIAL, via primitivas do jsPDF (retângulo, linha, círculo, texto).
// Nada de screenshot do DOM, html2canvas ou canvas: o PDF é gerado sem
// depender de layout de navegador, sai nítido em qualquer zoom e continua
// leve mesmo com vários itens desenhados.
//
// A geometria vem inteira de `project-data-rendering.ts` — o mesmo módulo que
// alimenta o preview em SVG. É o que garante que o desenho impresso seja o
// mesmo que a pessoa viu na tela.
//
// REGRA DE OURO: nenhuma falha aqui pode impedir a emissão do orçamento.
// `desenharProjectData` captura os próprios erros e devolve a altura ocupada;
// no pior caso imprime uma nota curta e o documento segue.
// =====================================================================

import type jsPDF from "jspdf";
import {
  calcularLayout,
  estiloDaPeca,
  medidasDivergem,
  preenchimentoDaPeca,
  resumoDoDesenho,
  rotuloDaPeca,
} from "@/lib/project-data-rendering";
import { normalizeProjectData, type ProjectData } from "@/types/project-data";

/** Altura máxima do desenho, em mm. Impede que um item ocupe a página inteira. */
const ALTURA_MAX_MM = 78;
const MARGEM_INTERNA_MM = 6;
const TITULO = "Projeto paramétrico";

function hexParaRgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  const completo =
    h.length === 3
      ? h
          .split("")
          .map((c) => c + c)
          .join("")
      : h;
  const n = parseInt(completo, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export type OpcoesDesenho = {
  /** Canto superior esquerdo do bloco, em mm. */
  x: number;
  y: number;
  /** Largura útil disponível, em mm. */
  largura: number;
  /** Medidas comerciais do item (mm), só para sinalizar divergência. */
  larguraItemMm?: number;
  alturaItemMm?: number;
};

/**
 * Estima a altura do bloco ANTES de desenhar, para quem precisa decidir se cabe
 * na página. Não desenha nada.
 */
export function alturaDoBlocoProjectData(dados: unknown, larguraDisponivelMm: number): number {
  const valido = normalizeProjectData(dados);
  if (!valido || !valido.pecas.length) return 0;
  const layout = calcularLayout(valido, {
    larguraMax: larguraDisponivelMm,
    alturaMax: ALTURA_MAX_MM,
    margem: MARGEM_INTERNA_MM,
  });
  // título + desenho + legenda
  return 5 + layout.altura + 5;
}

/**
 * Desenha o bloco e devolve a altura consumida, em mm.
 *
 * Devolve 0 quando não há o que desenhar (sem snapshot, snapshot ilegível ou
 * sem componentes) — o chamador simplesmente não reserva espaço.
 */
export function desenharProjectData(doc: jsPDF, dados: unknown, opcoes: OpcoesDesenho): number {
  let valido: ProjectData | null = null;
  try {
    valido = normalizeProjectData(dados);
  } catch {
    valido = null;
  }
  if (!valido || !valido.pecas.length) return 0;

  try {
    return desenhar(doc, valido, opcoes);
  } catch {
    // Falha isolada: informa em uma linha e devolve o controle. O restante do
    // orçamento — itens, totais, assinaturas — continua sendo gerado.
    try {
      doc.setFontSize(8);
      doc.setTextColor(120);
      doc.text("Projeto paramétrico não pôde ser desenhado.", opcoes.x, opcoes.y + 4);
      doc.setTextColor(0);
      return 7;
    } catch {
      return 0;
    }
  }
}

function desenhar(doc: jsPDF, dados: ProjectData, opcoes: OpcoesDesenho): number {
  const layout = calcularLayout(dados, {
    larguraMax: opcoes.largura,
    alturaMax: ALTURA_MAX_MM,
    margem: MARGEM_INTERNA_MM,
  });

  let y = opcoes.y;

  // --- Título ---------------------------------------------------------
  doc.setFontSize(8.5);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(30);
  doc.text(TITULO, opcoes.x, y + 3.2);
  doc.setFont("helvetica", "normal");
  y += 5;

  const baseX = opcoes.x;
  const baseY = y;
  const px = (v: number) => baseX + v;
  const py = (v: number) => baseY + v;

  // --- Moldura clara do bloco -----------------------------------------
  // Fundo branco com borda fina: legível impresso, sem grandes áreas escuras
  // que gastam toner e prejudicam o contraste do texto.
  doc.setDrawColor(210);
  doc.setLineWidth(0.2);
  doc.rect(baseX, baseY, layout.largura, layout.altura);

  // --- Contorno do projeto (tracejado) --------------------------------
  if (layout.projeto.largura > 0 && layout.projeto.altura > 0) {
    doc.setDrawColor(190);
    doc.setLineDashPattern([1, 1], 0);
    doc.rect(
      px(layout.projeto.x),
      py(layout.projeto.y),
      layout.projeto.largura,
      layout.projeto.altura,
    );
    doc.setLineDashPattern([], 0);
  }

  // --- Peças ----------------------------------------------------------
  for (const pos of layout.pecas) {
    const p = pos.peca;
    const estilo = estiloDaPeca(p.tipo);
    const w = Math.max(0.4, pos.largura);
    const h = Math.max(0.4, pos.altura);

    if (estilo.forma === "texto") {
      doc.setFontSize(6.5);
      doc.setTextColor(...hexParaRgb(estilo.contorno));
      doc.text((p.nome ?? "").slice(0, 80), px(pos.x), py(pos.cy), { baseline: "middle" });
      continue;
    }

    if (estilo.forma === "circulo") {
      const r = Math.max(0.5, Math.min(w, h) / 2);
      doc.setDrawColor(...hexParaRgb(estilo.contorno));
      doc.setFillColor(255, 255, 255);
      doc.setLineWidth(0.3);
      doc.circle(px(pos.cx), py(pos.cy), r, "FD");
      // Cruz de centro: identifica o furo mesmo em preto e branco.
      doc.line(px(pos.cx) - r, py(pos.cy), px(pos.cx) + r, py(pos.cy));
      doc.line(px(pos.cx), py(pos.cy) - r, px(pos.cx), py(pos.cy) + r);
      continue;
    }

    const vazado = estilo.forma === "vazado";
    doc.setDrawColor(...hexParaRgb(estilo.contorno));
    doc.setLineWidth(vazado ? 0.4 : 0.25);
    if (vazado) {
      // Recorte é AUSÊNCIA de material: só contorno tracejado, sem preenchimento.
      doc.setLineDashPattern([1.2, 0.9], 0);
      doc.rect(px(pos.x), py(pos.y), w, h);
      doc.setLineDashPattern([], 0);
    } else {
      doc.setFillColor(...hexParaRgb(preenchimentoDaPeca(p)));
      doc.rect(px(pos.x), py(pos.y), w, h, "FD");
    }

    // Sigla do tipo — a distinção não depende só da cor.
    if (w > 5 && h > 4) {
      doc.setFontSize(4.6);
      doc.setTextColor(...hexParaRgb(estilo.contorno));
      doc.text(estilo.sigla, px(pos.x) + 0.8, py(pos.y) + 2.2);
    }

    // Rótulo: só quando cabe de verdade. Sem sobreposição forçada.
    const rotulo = rotuloDaPeca(p, w, h, 1.5);
    if (rotulo) {
      doc.setFontSize(5.2);
      doc.setTextColor(25);
      doc.text(rotulo, px(pos.cx), py(pos.cy), { align: "center", baseline: "middle" });
    }
  }

  y += layout.altura;

  // --- Legenda --------------------------------------------------------
  doc.setFontSize(6.6);
  doc.setTextColor(110);
  doc.text(resumoDoDesenho(dados), baseX, y + 3.4);

  if (
    opcoes.larguraItemMm !== undefined &&
    opcoes.alturaItemMm !== undefined &&
    medidasDivergem(dados, opcoes.larguraItemMm, opcoes.alturaItemMm)
  ) {
    // Sinaliza, nunca corrige: o snapshot é impresso como foi salvo.
    doc.setTextColor(150, 80, 0);
    doc.text(
      "As medidas comerciais diferem das medidas do desenho paramétrico.",
      baseX + layout.largura,
      y + 3.4,
      { align: "right" },
    );
  }

  doc.setTextColor(0);
  doc.setDrawColor(0);
  doc.setLineWidth(0.2);
  return y + 5 - opcoes.y;
}
