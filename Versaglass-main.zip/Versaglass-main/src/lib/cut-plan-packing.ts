/** Paleta compartilhada entre a tela e o PDF do plano de corte. */
export const CUT_PLAN_COLORS = [
  "#d4a84c",
  "#3b82f6",
  "#10b981",
  "#ef4444",
  "#8b5cf6",
  "#f59e0b",
  "#06b6d4",
  "#ec4899",
  "#84cc16",
  "#f97316",
];

export type SheetPiece = {
  id: string;
  w: number;
  h: number;
  qty: number;
  label: string;
  rotate: boolean;
  material: string;
};

export type BarPiece = { id: string; len: number; qty: number; label: string };

export type Placement = {
  x: number;
  y: number;
  w: number;
  h: number;
  pieceIndex: number;
  rotated: boolean;
};

export type FreeRect = { x: number; y: number; w: number; h: number };

export type PackedSheet = { placements: Placement[]; free: FreeRect[]; usedArea: number };

type ExpandedPiece = { pieceIndex: number; w: number; h: number; label: string; rotate: boolean };

export type SheetPackResult = {
  sheets: PackedSheet[];
  unplaced: { label: string; w: number; h: number }[];
  totalCount: number;
  placedCount: number;
  usagePct: number;
  wasteM2: number;
};

export type BarSegment = { start: number; len: number; cutIndex: number };

export type PackedBar = { segments: BarSegment[]; used: number; waste: number };

export type BarPackResult = {
  bars: PackedBar[];
  unplaced: { label: string; len: number }[];
  totalCuts: number;
  usagePct: number;
  wasteMm: number;
};

export function packSheets({
  sheetW,
  sheetH,
  kerf,
  allowRotate,
  considerGrain = false,
  pieces,
}: {
  sheetW: number;
  sheetH: number;
  kerf: number;
  allowRotate: boolean;
  /** Com veio ativo, rotação 90° é ignorada (fio do material fixo). */
  considerGrain?: boolean;
  pieces: SheetPiece[];
}): SheetPackResult {
  const expanded: ExpandedPiece[] = [];
  pieces.forEach((p, idx) => {
    for (let i = 0; i < p.qty; i++) {
      expanded.push({
        pieceIndex: idx,
        w: p.w,
        h: p.h,
        label: p.label,
        rotate: allowRotate && p.rotate && !considerGrain,
      });
    }
  });
  expanded.sort((a, b) => Math.max(b.w, b.h) - Math.max(a.w, a.h) || b.w * b.h - a.w * a.h);

  const sheets: PackedSheet[] = [];
  const unplaced: { label: string; w: number; h: number }[] = [];
  const fits = (p: ExpandedPiece) =>
    (p.w <= sheetW && p.h <= sheetH) || (p.rotate && p.h <= sheetW && p.w <= sheetH);

  for (const piece of expanded) {
    if (!fits(piece)) {
      unplaced.push({ label: piece.label, w: piece.w, h: piece.h });
      continue;
    }
    let placed = false;
    for (const sheet of sheets)
      if (tryPlaceGuillotine(sheet, piece, kerf)) {
        placed = true;
        break;
      }
    if (!placed) {
      const ns: PackedSheet = {
        placements: [],
        free: [{ x: 0, y: 0, w: sheetW, h: sheetH }],
        usedArea: 0,
      };
      tryPlaceGuillotine(ns, piece, kerf);
      sheets.push(ns);
    }
  }

  const totalCount = expanded.length;
  const placedCount = totalCount - unplaced.length;
  const totalArea = sheets.length * sheetW * sheetH || 1;
  const usedArea = sheets.reduce((s, x) => s + x.usedArea, 0);
  const usagePct = (usedArea / totalArea) * 100;
  const wasteM2 = (totalArea - usedArea) / 1_000_000;
  return { sheets, unplaced, totalCount, placedCount, usagePct, wasteM2 };
}

function tryPlaceGuillotine(sheet: PackedSheet, piece: ExpandedPiece, kerf: number): boolean {
  const orients =
    piece.rotate && piece.w !== piece.h
      ? [
          { w: piece.w, h: piece.h, rotated: false },
          { w: piece.h, h: piece.w, rotated: true },
        ]
      : [{ w: piece.w, h: piece.h, rotated: false }];

  let best: { idx: number; w: number; h: number; rotated: boolean; waste: number } | null = null;
  for (let i = 0; i < sheet.free.length; i++) {
    const fr = sheet.free[i];
    for (const o of orients) {
      if (o.w <= fr.w && o.h <= fr.h) {
        const waste = fr.w * fr.h - o.w * o.h;
        if (!best || waste < best.waste)
          best = { idx: i, w: o.w, h: o.h, rotated: o.rotated, waste };
      }
    }
  }
  if (!best) return false;

  const fr = sheet.free[best.idx];
  sheet.placements.push({
    x: fr.x,
    y: fr.y,
    w: best.w,
    h: best.h,
    pieceIndex: piece.pieceIndex,
    rotated: best.rotated,
  });
  sheet.usedArea += best.w * best.h;

  const rightW = fr.w - best.w - kerf;
  const topH = fr.h - best.h - kerf;
  sheet.free.splice(best.idx, 1);
  const splitHorizontal = (fr.w - best.w) * fr.h <= fr.w * (fr.h - best.h);
  if (splitHorizontal) {
    if (rightW > 0) sheet.free.push({ x: fr.x + best.w + kerf, y: fr.y, w: rightW, h: fr.h });
    if (topH > 0) sheet.free.push({ x: fr.x, y: fr.y + best.h + kerf, w: best.w, h: topH });
  } else {
    if (topH > 0) sheet.free.push({ x: fr.x, y: fr.y + best.h + kerf, w: fr.w, h: topH });
    if (rightW > 0) sheet.free.push({ x: fr.x + best.w + kerf, y: fr.y, w: rightW, h: best.h });
  }
  return true;
}

export function packBars({
  barLen,
  kerf,
  cuts,
}: {
  barLen: number;
  kerf: number;
  cuts: BarPiece[];
}): BarPackResult {
  const expanded: { cutIndex: number; len: number; label: string }[] = [];
  cuts.forEach((c, idx) => {
    for (let i = 0; i < c.qty; i++) expanded.push({ cutIndex: idx, len: c.len, label: c.label });
  });
  expanded.sort((a, b) => b.len - a.len);
  const unplaced: { label: string; len: number }[] = [];
  const bars: PackedBar[] = [];

  for (const piece of expanded) {
    if (piece.len > barLen) {
      unplaced.push({ label: piece.label, len: piece.len });
      continue;
    }
    let best: PackedBar | null = null;
    let bestRemain = Infinity;
    for (const b of bars) {
      const need = (b.segments.length ? kerf : 0) + piece.len;
      const remain = barLen - b.used - need;
      if (remain >= 0 && remain < bestRemain) {
        best = b;
        bestRemain = remain;
      }
    }
    if (!best) {
      best = { segments: [], used: 0, waste: barLen };
      bars.push(best);
    }
    const start = best.segments.length ? best.used + kerf : 0;
    best.segments.push({ start, len: piece.len, cutIndex: piece.cutIndex });
    best.used = start + piece.len;
    best.waste = barLen - best.used;
  }

  const totalCuts = expanded.length;
  const used = bars.reduce((s, b) => s + b.used, 0);
  const totalLen = bars.length * barLen || 1;
  const usagePct = (used / totalLen) * 100;
  const wasteMm = totalLen - used;
  return { bars, unplaced, totalCuts, usagePct, wasteMm };
}
