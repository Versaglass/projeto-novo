/**
 * Autorização de gestão de estoque (UI) — espelha can_manage_company_estoque no SQL.
 * Sem bypass de platform admin: exige empresa ativa + (gestor OU checkbox).
 */

/** Espelha COMPANY_ROLES_BYPASS_FINE_PERMISSIONS. */
const ESTOQUE_MANAGER_ROLES = ["owner", "admin", "manager"] as const;

export function canManageCompanyEstoque(args: {
  hasActiveCompany: boolean;
  companyRole: string | null | undefined;
  permissions: { manage_estoque?: boolean } | null | undefined;
}): boolean {
  if (!args.hasActiveCompany) return false;
  if (args.companyRole && (ESTOQUE_MANAGER_ROLES as readonly string[]).includes(args.companyRole)) {
    return true;
  }
  return args.permissions?.manage_estoque === true;
}
