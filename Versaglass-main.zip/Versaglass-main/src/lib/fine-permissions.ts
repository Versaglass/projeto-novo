import { redirect } from "@tanstack/react-router";
import type { Permissions } from "@/contexts/auth-context";
import type { CompanyRole } from "@/contexts/company-context";
import { getAuthzSnapshot } from "@/lib/authz-snapshot";
import { queueHiddenRouteToast } from "@/lib/hidden-route-guard";

/**
 * Permissões finas (`profiles.permissions`) vs papéis empresariais.
 *
 * Histórico (AppShell Rev. 76–77): o bypass `can(perm) || !!activeCompany`
 * existia porque `manage_estoque` nasce `false` e o dono da empresa não via
 * Estoque — e a Rev. 77 estendeu o atalho a TODO membro, tornando os
 * checkboxes inertes no menu.
 *
 * Regra atual: membros com papel de gestão (owner/admin/manager) mantêm
 * acesso integral às áreas cobertas por permissões finas; operator /
 * installer / seller dependem dos checkboxes. Admin de plataforma
 * (`isPlatformAdmin`) bypassa permissões finas e opera como conta normal
 * no tenant ativo, com ferramentas extras em Administração.
 */

/** Defaults iguais ao JSONB de `profiles.permissions` / auth-context. */
export const DEFAULT_FINE_PERMISSIONS: Permissions = {
  manage_projetos: false,
  manage_estoque: false,
  manage_clientes: true,
  create_orcamentos: true,
  edit_orcamentos: true,
  delete_orcamentos: false,
  use_plano_corte: true,
};

/**
 * Papéis empresariais que ignoram permissões finas (mesma família de
 * `MANAGER_ROLES` / `PAPEIS_GESTORES` usada em Projetos, Estoque, etc.).
 */
export const COMPANY_ROLES_BYPASS_FINE_PERMISSIONS: readonly CompanyRole[] = [
  "owner",
  "admin",
  "manager",
] as const;

export const FINE_PERMISSION_DENIED_TOAST = "Você não tem permissão para acessar esta área";

export function normalizeFinePermissions(raw: unknown): Permissions {
  return {
    ...DEFAULT_FINE_PERMISSIONS,
    ...((raw as Partial<Permissions> | null | undefined) ?? {}),
  };
}

export function companyRoleBypassesFinePermissions(role: CompanyRole | null | undefined): boolean {
  return !!role && (COMPANY_ROLES_BYPASS_FINE_PERMISSIONS as readonly string[]).includes(role);
}

/**
 * Decisão única: plataforma admin OU gestor empresarial OU checkbox true.
 * `false` explícito no JSON permanece false (defaults só preenchem chave ausente).
 */
export function resolvesFinePermission(
  isPlatformAdmin: boolean,
  companyRole: CompanyRole | null | undefined,
  permissions: Permissions | Partial<Permissions> | null | undefined,
  key: keyof Permissions,
): boolean {
  if (isPlatformAdmin) return true;
  if (companyRoleBypassesFinePermissions(companyRole)) return true;
  return normalizeFinePermissions(permissions)[key] === true;
}

/** Qual permissão fina (se houver) a URL exige. */
export function finePermissionRequiredForPath(
  pathname: string,
  search = "",
): keyof Permissions | null {
  const path = (pathname.split("?")[0] || pathname).replace(/\/$/, "") || "/";
  const qs = new URLSearchParams(search.startsWith("?") ? search.slice(1) : search);

  if (path === "/app/orcamentos/novo") {
    return qs.get("id") ? "edit_orcamentos" : "create_orcamentos";
  }
  if (path === "/app/orcamentos" && qs.get("view") === "adicionar") {
    return "create_orcamentos";
  }

  const modules: { prefix: string; perm: keyof Permissions }[] = [
    { prefix: "/app/projetos", perm: "manage_projetos" },
    { prefix: "/app/estoque", perm: "manage_estoque" },
    { prefix: "/app/clientes", perm: "manage_clientes" },
    { prefix: "/app/plano-corte", perm: "use_plano_corte" },
  ];
  for (const m of modules) {
    if (path === m.prefix || path.startsWith(`${m.prefix}/`)) return m.perm;
  }
  return null;
}

/** Mapa para atalhos do dashboard / links (`to` sem query). */
export function finePermissionForNavTo(to: string): keyof Permissions | null {
  const path = to.split("?")[0] || to;
  if (path === "/app/orcamentos/novo") return "create_orcamentos";
  if (path === "/app/orcamentos") return null; // lista liberada
  return finePermissionRequiredForPath(path, "");
}

/**
 * `beforeLoad` central de permissões finas.
 * Usa o snapshot compartilhado (sem trio de queries extras).
 */
export async function enforceFinePermissionAccess(
  pathname: string,
  search: string,
  userId: string,
) {
  const required = finePermissionRequiredForPath(pathname, search);
  if (!required) return;

  const snap = await getAuthzSnapshot(userId);
  if (resolvesFinePermission(snap.isPlatformAdmin, snap.companyRole, snap.permissions, required)) {
    return;
  }

  queueHiddenRouteToast(FINE_PERMISSION_DENIED_TOAST);
  throw redirect({ to: "/app", replace: true });
}
