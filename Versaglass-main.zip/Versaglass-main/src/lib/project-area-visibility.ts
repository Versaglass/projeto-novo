/**
 * Visibilidade global dos tipos de projeto no modal "Novo projeto".
 *
 * Fonte de verdade: `platform_settings` chave `project_area_visibility`
 * (migration 20260903150100). Sem tenant / localStorage.
 *
 * Fallback seguro (linha ausente, JSON parcial, falha de parse):
 *   vidraçaria sempre · esquadrias true · demais false.
 * Nunca “libera tudo” por omissão.
 */

import {
  AREAS_OPCIONAIS,
  AREAS_PROJETO,
  type AreaOpcional,
  type AreaProjeto,
} from "@/lib/project-area";

export const PROJECT_AREA_VISIBILITY_KEY = "project_area_visibility";

export type ProjectAreaVisibility = Record<AreaOpcional, boolean>;

/** Padrão alinhado ao seed da migration. */
export const DEFAULT_PROJECT_AREA_VISIBILITY: ProjectAreaVisibility = {
  esquadrias: true,
  serralheria: false,
  marcenaria: false,
  marmoraria: false,
};

export function parseProjectAreaVisibility(raw: unknown): ProjectAreaVisibility {
  const base = { ...DEFAULT_PROJECT_AREA_VISIBILITY };
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return base;
  const obj = raw as Record<string, unknown>;
  for (const area of AREAS_OPCIONAIS) {
    if (typeof obj[area] === "boolean") base[area] = obj[area];
  }
  return base;
}

/** Áreas disponíveis para criação no wizard (Vidraçaria sempre inclusa). */
export function areasDisponiveisParaCriacao(visibility: ProjectAreaVisibility): AreaProjeto[] {
  return AREAS_PROJETO.filter((a) => {
    if (a === "vidracaria") return true;
    return visibility[a as AreaOpcional] === true;
  });
}
