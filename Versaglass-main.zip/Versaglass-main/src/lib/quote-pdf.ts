import jsPDF from "jspdf";
import type { QuoteItemTipoProjeto } from "@/lib/tipo-projeto-orcamento";
import {
  alturaBlocoImagemItem,
  desenharImagemItem,
  loadQuoteItemImageForPdf,
  QUOTE_ITEM_IMAGE_MAX_H_MM,
  QUOTE_ITEM_STOCK_THUMB_MAX_MM,
  type QuoteItemImagePdf,
} from "@/lib/quote-item-image";
import { itemEhProjetoVisual } from "@/lib/quote-item-projeto-visual";
import {
  ehItemProjetoVidracaria,
  formatEspessuraVidroPdf,
  rotuloVidroPdf,
} from "@/lib/quote-item-vidro";
import { brl, num } from "./format";
import {
  loadQuoteCompany,
  composeAddress,
  formatDoc,
  formatPhone,
  docLabel,
  joinParts,
  type CompanyHeaderData,
} from "./quote-company-pdf";

type Quote = {
  numero: number;
  created_at: string;
  updated_at?: string | null;
  status: string;
  desconto: number;
  acrescimo: number;
  total: number;
  observacoes: string | null;
  validade_dias: number;
  /** Empresa DONA do orçamento — nunca a empresa ativa no momento. */
  company_id?: string | null;
};
type Customer = {
  nome: string;
  documento?: string | null;
  telefone?: string | null;
  email?: string | null;
  endereco?: string | null;
  cidade?: string | null;
};
type Item = {
  descricao: string;
  largura: number;
  altura: number;
  quantidade: number;
  m2: number;
  preco_unit: number;
  subtotal: number;
  // Desenho técnico persistido em quote_items — opcional; itens antigos não têm.
  drawing_data?: unknown;
  drawing_notes?: string | null;
  /**
   * SNAPSHOT paramétrico copiado do modelo. Independente de `drawing_data`: um
   * item pode ter os dois, e cada um é impresso em seu próprio bloco.
   */
  project_data?: unknown;
  /** Path da foto do item — exibida no PDF no lugar do desenho paramétrico (Rev. 220). */
  imagem_url?: string | null;
  tipo_projeto?: QuoteItemTipoProjeto | null;
  /** Snapshot: projeto direto ou estoque originado de projeto. */
  originado_de_projeto?: boolean | null;
};
type Profile = { nome?: string | null; empresa?: string | null; telefone?: string | null };

const MARGEM = 14;
const RODAPE = 12;

/** Layout da tabela comercial (mm) — soma 182 mm (A4 210 − 2×14). */
type TableLayout = {
  comVidro: boolean;
  desc: number;
  la: number;
  qtd: number;
  vidro: number;
  esp: number;
  unit: number;
  sub: number;
};

/** Layout clássico de 5 colunas — NÃO alterar (já está estável). */
const LAYOUT_PADRAO: TableLayout = {
  comVidro: false,
  desc: 74,
  la: 32,
  qtd: 14,
  vidro: 0,
  esp: 0,
  unit: 30,
  sub: 32,
};

/**
 * 7 colunas: espaço redistribuído para caber na largura útil sem overflow.
 * Monetários com folga para "R$ 125.999,99"; L×A para "5,00 × 2,00 m";
 * Espessura estreita com cabeçalho em 2 linhas.
 */
const LAYOUT_VIDRO: TableLayout = {
  comVidro: true,
  desc: 50,
  la: 28,
  qtd: 10,
  vidro: 24,
  esp: 18,
  unit: 26,
  sub: 26,
};

type Align = "left" | "center" | "right";
type ColKey = "desc" | "la" | "qtd" | "vidro" | "esp" | "unit" | "sub";

type CellGeom = {
  key: ColKey;
  x: number;
  width: number;
  align: Align;
};

const PAD_CELULA = 1.2;
const LINE_H = 3.8;

function larguraTabela(layout: TableLayout): number {
  return (
    layout.desc + layout.la + layout.qtd + layout.vidro + layout.esp + layout.unit + layout.sub
  );
}

/** Geometria única — header e linhas usam as mesmas bordas. */
function geometriaColunas(x0: number, layout: TableLayout): CellGeom[] {
  const specs: Array<{ key: ColKey; width: number; align: Align }> = [
    { key: "desc", width: layout.desc, align: "left" },
    { key: "la", width: layout.la, align: "center" },
    { key: "qtd", width: layout.qtd, align: "center" },
  ];
  if (layout.comVidro) {
    specs.push(
      { key: "vidro", width: layout.vidro, align: "center" },
      { key: "esp", width: layout.esp, align: "center" },
    );
  }
  specs.push(
    { key: "unit", width: layout.unit, align: "right" },
    { key: "sub", width: layout.sub, align: "right" },
  );

  let x = x0;
  return specs.map((s) => {
    const cell: CellGeom = { key: s.key, x, width: s.width, align: s.align };
    x += s.width;
    return cell;
  });
}

function mapaCelulas(cells: CellGeom[]): Record<ColKey, CellGeom | undefined> {
  const m: Partial<Record<ColKey, CellGeom>> = {};
  for (const c of cells) m[c.key] = c;
  return m as Record<ColKey, CellGeom | undefined>;
}

function larguraConteudo(cell: CellGeom): number {
  return Math.max(3, cell.width - PAD_CELULA * 2);
}

function ancoraX(cell: CellGeom): number {
  if (cell.align === "left") return cell.x + PAD_CELULA;
  if (cell.align === "center") return cell.x + cell.width / 2;
  return cell.x + cell.width - PAD_CELULA;
}

function quebrarNoCelula(doc: jsPDF, texto: string, cell: CellGeom): string[] {
  return doc.splitTextToSize(texto, larguraConteudo(cell)) as string[];
}

function desenharTextoCelula(doc: jsPDF, linhas: string[], cell: CellGeom, yPrimeiraLinha: number) {
  if (!linhas.length) return;
  doc.text(linhas, ancoraX(cell), yPrimeiraLinha, { align: cell.align });
}

/** Títulos do cabeçalho — textos longos já vêm quebrados por coluna. */
function titulosCabecalho(layout: TableLayout): Partial<Record<ColKey, string[]>> {
  if (!layout.comVidro) {
    return {
      desc: ["Descrição"],
      la: ["L × A"],
      qtd: ["Qtd"],
      unit: ["Preço unitário"],
      sub: ["Subtotal"],
    };
  }
  return {
    desc: ["Descrição"],
    la: ["L × A"],
    qtd: ["Qtd"],
    vidro: ["Vidro"],
    esp: ["Espessura", "vidro"],
    unit: ["Preço", "unitário"],
    sub: ["Subtotal"],
  };
}

// Preço UNITÁRIO exibido no PDF — derivado dos dados já persistidos, sem alterar
// nada no banco. `quote_items.preco_unit` guarda, para item dimensionado, o preço
// por m² (é assim que a RPC `save_quote_with_items` calcula: subtotal = m2 ×
// preco_unit, com m2 já multiplicado pela quantidade). O documento do cliente
// mostra o preço de UMA unidade:
//
//   com dimensões: largura × altura × preco_unit   (área de 1 peça × preço do m²)
//   sem dimensões: preco_unit                      (já é o preço por unidade)
//
// Em ambos os casos vale `subtotal = preço unitário × quantidade`, o mesmo
// subtotal persistido — a conta fecha na folha. A interface do sistema continua
// exibindo R$/m²; esta função não é usada por ela.
function precoUnitario(i: Item): number {
  const largura = Number(i.largura) || 0;
  const altura = Number(i.altura) || 0;
  const preco = Number(i.preco_unit) || 0;
  return largura > 0 && altura > 0 ? largura * altura * preco : preco;
}

function medidaItem(i: Item): string {
  return Number(i.largura) > 0 && Number(i.altura) > 0
    ? `${num(i.largura, 2)} × ${num(i.altura, 2)} m`
    : "-";
}

function celulasVidro(item: Item): { vidro: string; espessura: string } {
  if (!ehItemProjetoVidracaria(item)) {
    return { vidro: "—", espessura: "—" };
  }
  const pd =
    item.project_data && typeof item.project_data === "object" && !Array.isArray(item.project_data)
      ? (item.project_data as { vidro?: string | null; espessuraVidro?: string | null })
      : null;
  return {
    vidro: rotuloVidroPdf(pd?.vidro),
    espessura: formatEspessuraVidroPdf(pd?.espessuraVidro),
  };
}

/** Cabeçalho da tabela comercial. Repetido no topo de cada página nova. */
function drawTableHeader(doc: jsPDF, x: number, y: number, layout: TableLayout): number {
  const cells = geometriaColunas(x, layout);
  const titulos = titulosCabecalho(layout);
  const maxLinhas = Math.max(1, ...cells.map((c) => (titulos[c.key] ?? [""]).length));
  const h = Math.max(layout.comVidro ? 11 : 8, maxLinhas * LINE_H + 4);

  doc.setFillColor(15, 27, 45);
  doc.rect(x, y, larguraTabela(layout), h, "F");
  doc.setTextColor(232, 168, 56);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(layout.comVidro ? 7 : 8.5);

  const yTexto = y + 3.6;
  for (const cell of cells) {
    const linhas = titulos[cell.key] ?? [];
    desenharTextoCelula(doc, linhas, cell, yTexto);
  }
  return y + h;
}

type LinhaMedida = {
  desc: string[];
  la: string[];
  qtd: string[];
  vidro: string[];
  esp: string[];
  unit: string[];
  sub: string[];
  altura: number;
};

/** Altura da linha = máx. de linhas entre todas as células (com wrap). */
function medirLinha(doc: jsPDF, item: Item, layout: TableLayout): LinhaMedida {
  doc.setFont("helvetica", "normal");
  doc.setFontSize(layout.comVidro ? 8 : 9);
  const cells = mapaCelulas(geometriaColunas(0, layout));
  const { vidro, espessura } = celulasVidro(item);

  const desc = quebrarNoCelula(doc, item.descricao || "Item", cells.desc!);
  const la = quebrarNoCelula(doc, medidaItem(item), cells.la!);
  const qtd = quebrarNoCelula(doc, String(item.quantidade), cells.qtd!);
  const unit = quebrarNoCelula(doc, brl(precoUnitario(item)), cells.unit!);
  const sub = quebrarNoCelula(doc, brl(Number(item.subtotal)), cells.sub!);

  let linhasVidro: string[] = [];
  let linhasEsp: string[] = [];
  if (layout.comVidro && cells.vidro && cells.esp) {
    linhasVidro = quebrarNoCelula(doc, vidro, cells.vidro);
    linhasEsp = quebrarNoCelula(doc, espessura, cells.esp);
  }

  const nLinhas = Math.max(
    desc.length,
    la.length,
    qtd.length,
    unit.length,
    sub.length,
    linhasVidro.length || 1,
    linhasEsp.length || 1,
  );

  return {
    desc,
    la,
    qtd,
    vidro: linhasVidro,
    esp: linhasEsp,
    unit,
    sub,
    altura: Math.max(8, nLinhas * LINE_H + 3.5),
  };
}

function drawItemRow(
  doc: jsPDF,
  medida: LinhaMedida,
  x: number,
  y: number,
  layout: TableLayout,
): number {
  doc.setTextColor(30, 30, 30);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(layout.comVidro ? 8 : 9);

  const cells = mapaCelulas(geometriaColunas(x, layout));
  const yTexto = y + 4.2;

  desenharTextoCelula(doc, medida.desc, cells.desc!, yTexto);
  desenharTextoCelula(doc, medida.la, cells.la!, yTexto);
  desenharTextoCelula(doc, medida.qtd, cells.qtd!, yTexto);
  if (layout.comVidro && cells.vidro && cells.esp) {
    desenharTextoCelula(doc, medida.vidro.length ? medida.vidro : ["—"], cells.vidro, yTexto);
    desenharTextoCelula(doc, medida.esp.length ? medida.esp : ["—"], cells.esp, yTexto);
  }
  desenharTextoCelula(doc, medida.unit, cells.unit!, yTexto);
  doc.setFont("helvetica", "bold");
  desenharTextoCelula(doc, medida.sub, cells.sub!, yTexto);
  doc.setFont("helvetica", "normal");

  return y + medida.altura;
}

function separador(doc: jsPDF, x: number, y: number, largura: number) {
  doc.setDrawColor(215, 215, 215);
  doc.setLineWidth(0.2);
  doc.line(x, y, x + largura, y);
}

/**
 * Cabeçalho empresarial: logotipo à esquerda, dados da empresa ao lado, faixa
 * com Nº do pedido / datas / validade abaixo. Devolve o y logo após a faixa.
 *
 * Nenhum campo vazio é impresso — cada linha só existe se tiver conteúdo.
 * Formatação (CNPJ, telefone) acontece só na APRESENTAÇÃO; nada é regravado.
 */
function drawCompanyHeader(doc: jsPDF, quote: Quote, dados: CompanyHeaderData, W: number): number {
  const empresa = dados.company;
  const alturaFaixa = 32;

  doc.setFillColor(15, 27, 45);
  doc.rect(0, 0, W, alturaFaixa, "F");

  let xTexto = MARGEM;

  // Logotipo — proporção preservada dentro de uma caixa de 26 × 20 mm.
  if (dados.logo) {
    const caixaW = 26;
    const caixaH = 20;
    const escala = Math.min(caixaW / dados.logo.width, caixaH / dados.logo.height);
    const w = dados.logo.width * escala;
    const h = dados.logo.height * escala;
    try {
      doc.addImage(dados.logo.dataUrl, MARGEM, (alturaFaixa - h) / 2, w, h, undefined, "FAST");
      xTexto = MARGEM + w + 5;
    } catch (err) {
      // Logo inválido não derruba o documento.
      console.error("Não foi possível inserir o logotipo no PDF.", err);
    }
  }

  const nome = (empresa?.company_name ?? "").trim();
  doc.setTextColor(232, 168, 56);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(nome.length > 34 ? 13 : 16);
  doc.text(nome || "Orçamento", xTexto, 12);

  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  let yInfo = 18;
  const cnpj = formatDoc(empresa?.cnpj);
  if (cnpj) {
    doc.text(`${docLabel(empresa?.cnpj)}: ${cnpj}`, xTexto, yInfo);
    yInfo += 4;
  }
  const endereco = composeAddress(empresa?.address, empresa?.city, empresa?.state);
  if (endereco) {
    doc.text(endereco, xTexto, yInfo);
    yInfo += 4;
  }
  const contato = joinParts([empresa?.email, formatPhone(empresa?.phone)]);
  if (contato) doc.text(contato, xTexto, yInfo);

  // Faixa do pedido — Nº, datas e validade.
  const yFaixa = alturaFaixa + 4;
  doc.setFillColor(240, 242, 246);
  doc.setDrawColor(210, 214, 220);
  doc.setLineWidth(0.2);
  doc.rect(MARGEM, yFaixa, W - MARGEM * 2, 11, "FD");

  const criado = new Date(quote.created_at);
  const atualizado = quote.updated_at ? new Date(quote.updated_at) : null;
  const campos: Array<[string, string]> = [
    ["Nº PEDIDO", String(quote.numero)],
    ["DATA PEDIDO", criado.toLocaleDateString("pt-BR")],
    ["VALIDADE", `${quote.validade_dias} DIAS`],
  ];
  if (atualizado && atualizado.getTime() !== criado.getTime()) {
    campos.push(["ATUALIZADO EM", atualizado.toLocaleDateString("pt-BR")]);
  }

  const largura = (W - MARGEM * 2) / campos.length;
  campos.forEach(([rotulo, valor], idx) => {
    const cx = MARGEM + largura * idx + 3;
    doc.setTextColor(120, 126, 136);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(6.5);
    doc.text(rotulo, cx, yFaixa + 4);
    doc.setTextColor(20, 24, 32);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.text(valor, cx, yFaixa + 8.6);
  });

  return yFaixa + 11;
}

export async function generateQuotePdf(
  quote: Quote,
  customer: Customer,
  items: Item[],
  /** Injetável para teste; em produção é carregado a partir de quote.company_id. */
  empresaPreCarregada?: CompanyHeaderData,
) {
  // A empresa vem de `quote.company_id` — NUNCA da empresa ativa no momento.
  // Assim um orçamento antigo de outra empresa não recebe o cabeçalho errado.
  const dadosEmpresa = empresaPreCarregada ?? (await loadQuoteCompany(quote.company_id));

  const imagensItem: Array<QuoteItemImagePdf | null> = await Promise.all(
    items.map((item) => loadQuoteItemImageForPdf(item.imagem_url)),
  );

  const doc = new jsPDF();
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const larguraUtil = W - MARGEM * 2;
  const limiteY = H - RODAPE;

  const yCabecalho = drawCompanyHeader(doc, quote, dadosEmpresa, W);

  // Cliente
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  doc.text("CLIENTE", MARGEM, yCabecalho + 8);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.text(customer.nome, MARGEM, yCabecalho + 14);
  doc.setFontSize(9);
  doc.setTextColor(80, 80, 80);
  const docCliente = formatDoc(customer.documento);
  const meta = joinParts([
    docCliente ? `${docLabel(customer.documento)}: ${docCliente}` : null,
    formatPhone(customer.telefone),
    customer.email,
  ]);
  let yCliente = yCabecalho + 19;
  if (meta) {
    doc.text(meta, MARGEM, yCliente);
    yCliente += 5;
  }
  const endCliente = composeAddress(customer.endereco, customer.cidade, null);
  if (endCliente) {
    doc.text(endCliente, MARGEM, yCliente);
    yCliente += 5;
  }

  // ---------------------------------------------------------------------
  // Itens — cada linha comercial seguida da foto do item (quando houver).
  // ---------------------------------------------------------------------
  const possuiProjetoVidracaria = items.some((it) => ehItemProjetoVidracaria(it));
  const layout = possuiProjetoVidracaria ? LAYOUT_VIDRO : LAYOUT_PADRAO;

  let y = yCliente + 5;
  y = drawTableHeader(doc, MARGEM, y, layout);

  const novaPagina = () => {
    doc.addPage();
    let ny = MARGEM + 4;
    ny = drawTableHeader(doc, MARGEM, ny, layout); // cabeçalho comercial repetido
    return ny;
  };

  for (let itemIdx = 0; itemIdx < items.length; itemIdx++) {
    const item = items[itemIdx];
    const medida = medirLinha(doc, item, layout);
    const alturaLinha = medida.altura;
    const larguraFoto = larguraUtil - 4;
    const imgItem = imagensItem[itemIdx];
    const maxFotoH = itemEhProjetoVisual(item)
      ? QUOTE_ITEM_IMAGE_MAX_H_MM
      : QUOTE_ITEM_STOCK_THUMB_MAX_MM;
    const alturaFoto =
      imgItem && item.imagem_url?.trim()
        ? alturaBlocoImagemItem(larguraFoto, imgItem, maxFotoH)
        : 0;
    const alturaBloco = alturaLinha + alturaFoto + 4;

    // Linha + foto viajam juntos: se não couberem no que resta da página,
    // a quebra acontece ANTES da linha comercial.
    if (y + alturaBloco > limiteY) {
      // Exceção inevitável: bloco maior que uma página inteira. Começa numa
      // folha limpa mesmo assim; só a lista de informações continua adiante.
      y = novaPagina();
    }

    // Avança Y pelo fim REAL da linha (altura dinâmica) antes da imagem.
    y = drawItemRow(doc, medida, MARGEM, y, layout);

    // ORDEM: linha do item → foto (quando houver).
    if (alturaFoto > 0 && imgItem) {
      if (y + alturaFoto > limiteY) y = novaPagina();
      const usado = desenharImagemItem(doc, imgItem, {
        x: MARGEM + 2,
        y: y + 1,
        largura: larguraFoto,
        maxHeightMm: maxFotoH,
      });
      y += usado + 1;
    }

    y += 2;
    separador(doc, MARGEM, y, larguraUtil);
    y += 4;
  }

  // ---------------------------------------------------------------------
  // Totais — sempre DEPOIS de todos os itens (e fotos).
  // ---------------------------------------------------------------------
  const subtotal = items.reduce((s, i) => s + Number(i.subtotal), 0);
  const alturaTotais = 34;
  if (y + alturaTotais > limiteY) {
    doc.addPage();
    y = MARGEM + 4;
  }

  y += 6;
  const totalsX = W - MARGEM;
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text(`Subtotal: ${brl(subtotal)}`, totalsX, y, { align: "right" });
  y += 5;
  if (Number(quote.desconto) > 0) {
    doc.text(`Desconto: -${brl(Number(quote.desconto))}`, totalsX, y, { align: "right" });
    y += 5;
  }
  if (Number(quote.acrescimo) > 0) {
    doc.text(`Acréscimo: +${brl(Number(quote.acrescimo))}`, totalsX, y, { align: "right" });
    y += 5;
  }

  y += 4;
  doc.setFillColor(15, 27, 45);
  doc.rect(W - 90, y - 4, 76, 14, "F");
  doc.setTextColor(232, 168, 56);
  doc.setFontSize(13);
  doc.setFont("helvetica", "bold");
  doc.text(`TOTAL: ${brl(Number(quote.total))}`, totalsX - 4, y + 5, { align: "right" });
  y += 14;

  // Observações gerais — por último.
  if (quote.observacoes) {
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(9);
    const linhas = doc.splitTextToSize(quote.observacoes, larguraUtil) as string[];
    if (y + 10 + linhas.length * 4.5 > limiteY) {
      doc.addPage();
      y = MARGEM + 4;
    }
    y += 8;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.text("Observações", MARGEM, y);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(60, 60, 60);
    doc.text(linhas, MARGEM, y + 6);
    y += 6 + linhas.length * 4.5;
  }

  drawSignatures(doc, dadosEmpresa, customer, y, W, limiteY);

  doc.save(`orcamento-${quote.numero}.pdf`);
}

/**
 * Assinaturas — sempre por último, depois de itens, desenhos, totais e
 * observações. Duas colunas alinhadas, com espaço real para assinar.
 *
 * O bloco inteiro é medido antes: se não couber no que resta da página, abre
 * página nova. Nenhuma assinatura é dividida entre páginas.
 *
 * CONTRATADO vem da company_profile do ORÇAMENTO; CONTRATANTE vem do customer
 * associado. Nada é fixo no código. Quando falta o documento, a linha
 * simplesmente não é impressa — nunca sai "CPF/CNPJ: undefined".
 */
function drawSignatures(
  doc: jsPDF,
  dadosEmpresa: CompanyHeaderData,
  customer: Customer,
  yAtual: number,
  W: number,
  limiteY: number,
) {
  const ALTURA_BLOCO = 34; // espaço para assinar + rótulos
  let y = yAtual + 16;

  if (y + ALTURA_BLOCO > limiteY) {
    doc.addPage();
    y = MARGEM + 20;
  }

  const larguraUtil = W - MARGEM * 2;
  const larguraColuna = (larguraUtil - 16) / 2;
  const colunas = [
    {
      x: MARGEM,
      papel: "CONTRATADO",
      nome: (dadosEmpresa.company?.company_name ?? "").trim(),
      documento: dadosEmpresa.company?.cnpj ?? null,
    },
    {
      x: MARGEM + larguraColuna + 16,
      papel: "CONTRATANTE",
      nome: (customer.nome ?? "").trim(),
      documento: customer.documento ?? null,
    },
  ];

  for (const col of colunas) {
    // Linha da assinatura
    doc.setDrawColor(90, 90, 90);
    doc.setLineWidth(0.3);
    doc.line(col.x, y, col.x + larguraColuna, y);

    const centro = col.x + larguraColuna / 2;
    doc.setTextColor(90, 90, 90);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    doc.text(col.papel, centro, y + 5, { align: "center" });

    let yLinha = y + 10;
    if (col.nome) {
      doc.setTextColor(25, 25, 25);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(9);
      for (const parte of doc.splitTextToSize(col.nome, larguraColuna) as string[]) {
        doc.text(parte, centro, yLinha, { align: "center" });
        yLinha += 4.2;
      }
    }

    const documento = formatDoc(col.documento);
    if (documento) {
      doc.setTextColor(105, 105, 105);
      doc.setFontSize(8);
      doc.text(`${docLabel(col.documento)}: ${documento}`, centro, yLinha, { align: "center" });
    }
  }
}
