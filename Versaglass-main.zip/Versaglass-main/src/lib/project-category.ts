import type { ProjectTemplateCategoria } from "@/hooks/use-project-templates";

/** As 7 categorias de material (`public.project_category`). */
export const PROJECT_CATEGORIES: ReadonlyArray<{
  value: ProjectTemplateCategoria;
  label: string;
}> = [
  { value: "vidro_comum", label: "Vidro Comum" },
  { value: "temperado", label: "Temperado" },
  { value: "espelho", label: "Espelho" },
  { value: "esquadria", label: "Esquadria" },
  { value: "refletivo", label: "Refletivo" },
  { value: "organico", label: "Orgânico" },
  { value: "canelado", label: "Canelado" },
];

export type FiltroCategoriaProjeto = ProjectTemplateCategoria | "all";

export function categoriaProjetoLabel(value: ProjectTemplateCategoria | string): string {
  return PROJECT_CATEGORIES.find((c) => c.value === value)?.label ?? String(value);
}
