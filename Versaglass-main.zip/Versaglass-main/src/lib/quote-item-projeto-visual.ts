import { normalizaArea } from "@/lib/project-area";
import { ehQuoteItemTipoProjeto } from "@/lib/quote-item-tipo-helpers";
import type { QuoteItemTipoProjeto } from "@/lib/tipo-projeto-orcamento";

/**
 * Decide se o item do orçamento deve usar imagem GRANDE no PDF comercial.
 *
 * Ordem estruturada (sem nome/categoria/path/heurística):
 * 1. `originado_de_projeto === true` (projeto direto novo ou estoque vindo de projeto)
 * 2. evidência histórica de projeto direto: `tipo_projeto` válido OU `project_data.area` válida
 * 3. caso contrário → estoque comum / item manual → miniatura
 *
 * Cobre Vidraçaria e Esquadrias (qualquer área/tipo estruturado).
 */
export function itemEhProjetoVisual(item: {
  originado_de_projeto?: boolean | null;
  project_data?: unknown;
  tipo_projeto?: QuoteItemTipoProjeto | string | null;
}): boolean {
  if (item.originado_de_projeto === true) return true;

  const tipo = item.tipo_projeto;
  if (typeof tipo === "string" && ehQuoteItemTipoProjeto(tipo)) return true;

  const bruto = item.project_data;
  if (bruto && typeof bruto === "object" && !Array.isArray(bruto)) {
    const area = normalizaArea((bruto as { area?: unknown }).area);
    if (area != null) return true;
  }

  return false;
}
