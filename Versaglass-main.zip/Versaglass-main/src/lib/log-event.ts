import { supabase } from "@/integrations/supabase/client";
import { logAuthEventAnon, logAuthEventAuthed } from "@/lib/logging.functions";
import { runLogCall, type LogResult } from "@/lib/server-log";

export type AuthEventKind =
  | "signup"
  | "login_success"
  | "payment"
  | "subscription_created"
  | "login_error";

/** Eventos que só podem ocorrer com sessão estabelecida. */
const AUTHED: ReadonlySet<AuthEventKind> = new Set([
  "login_success",
  "payment",
  "subscription_created",
]);

/**
 * Registra um evento de autenticação em public.auth_events (e espelha em
 * public.server_logs).
 *
 * A gravação é feita por server function: o navegador não tem policy de
 * INSERT nestas tabelas, e por isso a versão anterior deste helper era um
 * no-op silencioso (ver P-07).
 *
 * `user_id` NUNCA é enviado daqui — para eventos autenticados o servidor o
 * deriva do Bearer token validado. O parâmetro `user_id` continua na
 * assinatura por compatibilidade com os call sites, mas é ignorado.
 */
export async function logEvent(
  kind: AuthEventKind,
  data: { email?: string; user_id?: string; metadata?: Record<string, unknown> } = {},
): Promise<LogResult> {
  if (AUTHED.has(kind)) {
    const { data: sess } = await supabase.auth.getSession();
    if (!sess.session) {
      // Não cai para o endpoint anônimo: `login_success` sem sessão não faz
      // sentido e a whitelist anônima não o aceita.
      console.warn(`[log:auth_events:${kind}] não registrado (unauthenticated)`);
      return { success: false, code: "unauthenticated", message: "Evento exige sessão." };
    }
    return runLogCall(
      () =>
        logAuthEventAuthed({
          data: {
            kind: kind as "login_success" | "payment" | "subscription_created",
            metadata: data.metadata,
          },
        }),
      `auth_events:${kind}`,
    );
  }

  return runLogCall(
    () => logAuthEventAnon({ data: { kind, email: data.email, metadata: data.metadata } }),
    `auth_events:${kind}`,
  );
}
