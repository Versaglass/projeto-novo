export const brl = (n: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(n || 0);

export const num = (n: number, frac = 2) =>
  new Intl.NumberFormat("pt-BR", {
    minimumFractionDigits: frac,
    maximumFractionDigits: frac,
  }).format(n || 0);

export const dateBR = (s?: string | null) => (s ? new Date(s).toLocaleDateString("pt-BR") : "—");

export const statusLabel: Record<string, string> = {
  rascunho: "Rascunho",
  enviado: "Enviado",
  aprovado: "Aprovado",
  recusado: "Recusado",
};

export const statusTone: Record<string, string> = {
  rascunho: "bg-muted text-muted-foreground",
  enviado: "bg-primary/10 text-primary",
  aprovado: "bg-[oklch(0.62_0.15_150)]/15 text-[oklch(0.40_0.13_150)]",
  recusado: "bg-destructive/10 text-destructive",
};
