/**
 * Documento do cliente — CPF ou CNPJ, despachado pelo tamanho.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * POR QUE ISTO EXISTE (Revisão 125 → 126)
 * ────────────────────────────────────────────────────────────────────────────
 * O cadastro de cliente tem um único campo "CPF/CNPJ". A empresa só precisa de
 * CNPJ (`validarCnpj`); o cliente pode ser pessoa física ou jurídica.
 *
 * A decisão é pela quantidade de caracteres de CONTEÚDO (sem máscara):
 *
 *   · vazio → ausência legítima (campo opcional);
 *   · 11 dígitos → `validarCpf`;
 *   · letra presente OU mais de 11 caracteres → `validarCnpj` (14, alfanumérico
 *     já suportado pela Revisão 92);
 *   · outro tamanho numérico (< 11) → mensagem pedindo CPF (11) ou CNPJ (14).
 *
 * Não reinventa algoritmo: reusa `src/lib/cpf.ts` e `src/lib/cnpj.ts`.
 */

import { formatarCpf, validarCpf } from "@/lib/cpf";
import { formatarCnpj, normalizarCnpj, validarCnpj } from "@/lib/cnpj";

export type DocumentoClienteValidado =
  | {
      ok: true;
      /** `null` quando o campo veio vazio. */
      tipo: "cpf" | "cnpj" | null;
      /** Canônico sem máscara (11 dígitos ou 14 caracteres). */
      documento: string;
      formatado: string;
    }
  | { ok: false; erro: string };

/**
 * Valida o documento digitado no cadastro de cliente.
 *
 * `obrigatorio: false` (padrão) — vazio é ok. Preenchido, precisa ser CPF ou
 * CNPJ com dígito verificador correto.
 */
export function validarDocumentoCliente(
  bruto: unknown,
  opcoes?: { obrigatorio?: boolean },
): DocumentoClienteValidado {
  const original = String(bruto ?? "").trim();
  const obrigatorio = opcoes?.obrigatorio ?? false;

  if (!original) {
    return obrigatorio
      ? { ok: false, erro: "Informe o CPF ou CNPJ do cliente." }
      : { ok: true, tipo: null, documento: "", formatado: "" };
  }

  const conteudo = normalizarCnpj(original); // remove . / - espaços e sobe caixa
  const soDigitos = conteudo.replace(/\D/g, "");
  const temLetra = /[A-Z]/.test(conteudo);

  // CPF: exatamente 11 dígitos, sem letra.
  if (!temLetra && soDigitos.length === 11 && conteudo === soDigitos) {
    const cpf = validarCpf(original);
    if (!cpf.ok) return cpf;
    return {
      ok: true,
      tipo: cpf.cpf ? "cpf" : null,
      documento: cpf.cpf,
      formatado: cpf.formatado || (cpf.cpf ? formatarCpf(cpf.cpf) : ""),
    };
  }

  // CNPJ: letra (alfanumérico) ou mais de 11 caracteres de conteúdo.
  // Também cobre 14 dígitos numéricos e incompletos (validarCnpj explica o tamanho).
  if (temLetra || conteudo.length > 11) {
    const cnpj = validarCnpj(original);
    if (!cnpj.ok) return cnpj;
    return {
      ok: true,
      tipo: cnpj.cnpj ? "cnpj" : null,
      documento: cnpj.cnpj,
      formatado: cnpj.formatado || (cnpj.cnpj ? formatarCnpj(cnpj.cnpj) : ""),
    };
  }

  // Menos de 11 dígitos (ou lixo que normalizou curto demais).
  return {
    ok: false,
    erro: `Informe um CPF (11 dígitos) ou um CNPJ (14 caracteres). Você digitou ${conteudo.length || soDigitos.length}.`,
  };
}
