/**
 * PDF do Plano de corte — jsPDF vetorial (mesmo caminho de `sale-pdf.ts` /
 * `quote-pdf.ts`). Substitui `window.print()` da Rev. 214: documento limpo,
 * sem menu lateral, com diagramas desenhados por primitivas (não screenshot).
 */

import jsPDF from "jspdf";
import { num } from "./format";
import {
  CUT_PLAN_COLORS,
  type BarPackResult,
  type BarPiece,
  type PackedBar,
  type PackedSheet,
  type SheetPackResult,
  type SheetPiece,
} from "./cut-plan-packing";

const MARGEM = 14;
const RODAPE = 12;

export type CutPlanPdfInput = {
  mode: "chaparia" | "barras";
  projectName: string;
  client: string;
  notes?: string;
  kerf: number;
  /** Chaparia */
  sheetW?: number;
  sheetH?: number;
  stockLabel?: string;
  stockMaterial?: string;
  pieces?: SheetPiece[];
  sheetResult?: SheetPackResult;
  /** Barras */
  barLen?: number;
  stockBarLabel?: string;
  cuts?: BarPiece[];
  barResult?: BarPackResult;
};

function hexParaRgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  const full =
    h.length === 3
      ? h
          .split("")
          .map((c) => c + c)
          .join("")
      : h.slice(0, 6);
  const n = parseInt(full, 16) || 0;
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function slugNome(nome: string): string {
  const s = nome
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
  return s || "plano";
}

function paginar(doc: jsPDF, larguraUtil: number) {
  const H = doc.internal.pageSize.getHeight();
  const paginas = doc.getNumberOfPages();
  for (let p = 1; p <= paginas; p++) {
    doc.setPage(p);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7.5);
    doc.setTextColor(130, 134, 142);
    doc.text("Plano de corte — VersaGlass", MARGEM, H - RODAPE + 5);
    doc.text(`Página ${p} de ${paginas}`, MARGEM + larguraUtil, H - RODAPE + 5, {
      align: "right",
    });
  }
}

function desenharCabecalho(doc: jsPDF, input: CutPlanPdfInput, larguraUtil: number): number {
  const modo =
    input.mode === "chaparia" ? "Chaparia (2D)" : "Barras (1D)";
  const titulo = input.projectName.trim() || "Plano de corte";
  const dataStr = new Date().toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });

  doc.setFillColor(15, 27, 45);
  doc.rect(MARGEM, MARGEM, larguraUtil, 28, "F");
  doc.setTextColor(232, 168, 56);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.text(titulo, MARGEM + 4, MARGEM + 11);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(220, 225, 235);
  doc.text(`Plano de corte · ${modo} · ${dataStr}`, MARGEM + 4, MARGEM + 19);
  if (input.client.trim()) {
    doc.text(`Cliente: ${input.client.trim()}`, MARGEM + 4, MARGEM + 25);
  }

  let y = MARGEM + 34;
  doc.setTextColor(40, 44, 52);
  doc.setFontSize(8.5);
  const detalhes: string[] = [`Kerf: ${num(input.kerf, 1)} mm`];
  if (input.mode === "chaparia" && input.sheetW && input.sheetH) {
    detalhes.push(
      `Chapa: ${input.sheetW} × ${input.sheetH} mm`,
      input.stockMaterial ? `Material: ${input.stockMaterial}` : "",
      input.stockLabel ? `(${input.stockLabel})` : "",
    );
  }
  if (input.mode === "barras" && input.barLen) {
    detalhes.push(
      `Barra: ${input.barLen} mm`,
      input.stockBarLabel ? `(${input.stockBarLabel})` : "",
    );
  }
  doc.text(detalhes.filter(Boolean).join(" · "), MARGEM, y);
  y += 8;
  return y;
}

function desenharEstatisticas(
  doc: jsPDF,
  y: number,
  larguraUtil: number,
  linhas: { rotulo: string; valor: string }[],
): number {
  const colW = larguraUtil / linhas.length;
  doc.setFillColor(245, 247, 250);
  doc.rect(MARGEM, y, larguraUtil, 18, "F");
  doc.setDrawColor(210, 214, 220);
  doc.rect(MARGEM, y, larguraUtil, 18, "S");
  linhas.forEach((l, i) => {
    const cx = MARGEM + colW * i + colW / 2;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7);
    doc.setTextColor(100, 105, 115);
    doc.text(l.rotulo.toUpperCase(), cx, y + 6, { align: "center" });
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(15, 27, 45);
    doc.text(l.valor, cx, y + 14, { align: "center" });
  });
  return y + 24;
}

function desenharTabelaPecasChaparia(
  doc: jsPDF,
  y: number,
  larguraUtil: number,
  pieces: SheetPiece[],
  limiteY: number,
): number {
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(0, 0, 0);
  doc.text("Peças a cortar", MARGEM, y);
  y += 6;

  const cols = [
    { label: "Descrição", w: 52, align: "left" as const },
    { label: "Material", w: 42, align: "left" as const },
    { label: "L × A (mm)", w: 32, align: "right" as const },
    { label: "Qtd", w: 14, align: "right" as const },
    { label: "Girar", w: 14, align: "center" as const },
  ];
  const tableW = cols.reduce((s, c) => s + c.w, 0);
  const x0 = MARGEM;

  const header = () => {
    doc.setFillColor(15, 27, 45);
    doc.rect(x0, y, tableW, 7, "F");
    doc.setTextColor(232, 168, 56);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    let x = x0 + 2;
    for (const c of cols) {
      doc.text(c.label, c.align === "right" ? x + c.w - 2 : x, y + 5, {
        align: c.align === "right" ? "right" : "left",
      });
      x += c.w;
    }
    y += 7;
  };

  header();
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(30, 34, 42);

  for (let i = 0; i < pieces.length; i++) {
    if (y + 6 > limiteY) {
      doc.addPage();
      y = MARGEM;
      header();
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8.5);
      doc.setTextColor(30, 34, 42);
    }
    const p = pieces[i];
    if (i % 2 === 1) {
      doc.setFillColor(248, 249, 251);
      doc.rect(x0, y, tableW, 6, "F");
    }
    let x = x0 + 2;
    const cells = [
      p.label,
      p.material,
      `${p.w} × ${p.h}`,
      String(p.qty),
      p.rotate ? "Sim" : "Não",
    ];
    cols.forEach((c, ci) => {
      doc.text(cells[ci], c.align === "right" ? x + c.w - 2 : x + c.w / 2, y + 4.5, {
        align: c.align,
      });
      x += c.w;
    });
    y += 6;
  }
  return y + 6;
}

function desenharTabelaCortes(
  doc: jsPDF,
  y: number,
  larguraUtil: number,
  cuts: BarPiece[],
  limiteY: number,
): number {
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(0, 0, 0);
  doc.text("Cortes necessários", MARGEM, y);
  y += 6;

  const tableW = larguraUtil;
  const cols = [
    { label: "Descrição", w: tableW * 0.52, align: "left" as const },
    { label: "Comprimento (mm)", w: tableW * 0.32, align: "right" as const },
    { label: "Qtd", w: tableW * 0.16, align: "right" as const },
  ];
  const x0 = MARGEM;
  const headerH = 9;

  const desenharHeader = () => {
    doc.setFillColor(15, 27, 45);
    doc.rect(x0, y, tableW, headerH, "F");
    doc.setTextColor(232, 168, 56);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    let xh = x0;
    for (const c of cols) {
      const lines = doc.splitTextToSize(c.label, c.w - 4) as string[];
      const lineH = 3.2;
      const blockH = lines.length * lineH;
      const ty = y + (headerH - blockH) / 2 + lineH - 0.5;
      lines.forEach((line, i) => {
        doc.text(line, xh + c.w / 2, ty + i * lineH, { align: "center" });
      });
      xh += c.w;
    }
    y += headerH;
  };

  desenharHeader();

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(30, 34, 42);
  cuts.forEach((c, i) => {
    if (y + 6 > limiteY) {
      doc.addPage();
      y = MARGEM;
      desenharHeader();
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8.5);
      doc.setTextColor(30, 34, 42);
    }
    if (i % 2 === 1) {
      doc.setFillColor(248, 249, 251);
      doc.rect(x0, y, tableW, 6, "F");
    }
    let x = x0 + 2;
    const cells = [c.label, String(c.len), String(c.qty)];
    cols.forEach((col, ci) => {
      const pad = ci === 0 ? 0 : 2;
      doc.text(cells[ci], col.align === "right" ? x + col.w - pad : x, y + 4.5, {
        align: col.align === "right" ? "right" : "left",
      });
      x += col.w;
    });
    y += 6;
  });
  return y + 6;
}

function dimChapa(input: CutPlanPdfInput): { w: number; h: number } {
  return {
    w: input.sheetW && input.sheetW > 0 ? input.sheetW : 2200,
    h: input.sheetH && input.sheetH > 0 ? input.sheetH : 1600,
  };
}

function dimBarra(input: CutPlanPdfInput): number {
  return input.barLen && input.barLen > 0 ? input.barLen : 6000;
}

/** Desenha retângulos da chapa; retorna altura ocupada (mm). */
function pintarChapa(
  doc: jsPDF,
  x0: number,
  y: number,
  drawW: number,
  drawH: number,
  scale: number,
  sheet: PackedSheet,
  pieces: SheetPiece[],
  desenharSobras: boolean,
): void {
  doc.setFillColor(26, 26, 26);
  doc.setDrawColor(80, 80, 80);
  doc.setLineWidth(0.2);
  doc.rect(x0, y, drawW, drawH, "FD");

  for (const pl of sheet.placements) {
    const pw = Math.max(pl.w * scale, 0.4);
    const ph = Math.max(pl.h * scale, 0.4);
    const px = x0 + pl.x * scale;
    const py = y + pl.y * scale;
    const [r, g, b] = hexParaRgb(CUT_PLAN_COLORS[pl.pieceIndex % CUT_PLAN_COLORS.length]);
    doc.setFillColor(r, g, b);
    doc.setDrawColor(20, 20, 20);
    doc.rect(px, py, pw, ph, "F");
    const label = pieces[pl.pieceIndex]?.label ?? "?";
    const txt = `${label} ${pl.w}×${pl.h}${pl.rotated ? " ↻" : ""}`;
    if (pw > 10 && ph > 6) {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(Math.min(7, Math.max(4.5, pw / 14)));
      doc.setTextColor(10, 10, 10);
      const lines = doc.splitTextToSize(txt, pw - 1) as string[];
      doc.text(lines.slice(0, 2), px + pw / 2, py + ph / 2 + 1, { align: "center" });
    }
  }

  if (!desenharSobras) return;

  for (const fr of sheet.free.filter((f) => f.w > 40 && f.h > 40)) {
    const fw = Math.max(fr.w * scale, 0.4);
    const fh = Math.max(fr.h * scale, 0.4);
    const fx = x0 + fr.x * scale;
    const fy = y + fr.y * scale;
    doc.setFillColor(17, 24, 39);
    doc.setDrawColor(245, 158, 11);
    doc.setLineDashPattern([2, 1.5], 0);
    doc.rect(fx, fy, fw, fh, "D");
    doc.setLineDashPattern([], 0);
    if (fw > 12 && fh > 7) {
      doc.setFont("helvetica", "normal");
      doc.setFontSize(5.5);
      doc.setTextColor(180, 130, 20);
      doc.text(
        `sobra ${Math.round(fr.w)}×${Math.round(fr.h)}`,
        fx + fw / 2,
        fy + fh / 2 + 1,
        { align: "center" },
      );
    }
  }
}

function desenharChapa(
  doc: jsPDF,
  y: number,
  larguraUtil: number,
  limiteY: number,
  index: number,
  sheet: PackedSheet,
  sheetW: number,
  sheetH: number,
  pieces: SheetPiece[],
  maxDiagramH = 110,
): number {
  const tituloH = 12;
  let maxH = Math.min(maxDiagramH, limiteY - y - tituloH - 4);
  if (maxH < 35) {
    doc.addPage();
    y = MARGEM;
    maxH = Math.min(maxDiagramH, limiteY - y - tituloH - 4);
  }
  const scale = Math.min(larguraUtil / sheetW, maxH / sheetH);
  const drawW = sheetW * scale;
  const drawH = sheetH * scale;
  const x0 = MARGEM + (larguraUtil - drawW) / 2;

  const usage = (sheet.usedArea / (sheetW * sheetH)) * 100;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(15, 27, 45);
  doc.text(`Chapa #${index + 1}`, MARGEM, y + 4);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(80, 85, 95);
  doc.text(
    `${sheet.placements.length} peças · aproveitamento ${num(usage, 1)}%`,
    MARGEM,
    y + 10,
  );
  y += tituloH;

  pintarChapa(doc, x0, y, drawW, drawH, scale, sheet, pieces, true);
  return y + drawH + 10;
}

function desenharDiagramasResumoChaparia(
  doc: jsPDF,
  y: number,
  larguraUtil: number,
  limiteY: number,
  sheets: PackedSheet[],
  sheetW: number,
  sheetH: number,
  pieces: SheetPiece[],
): number {
  if (sheets.length === 0) return y;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(15, 27, 45);
  doc.text("Diagrama de corte", MARGEM, y);
  y += 5;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  doc.setTextColor(90, 95, 105);
  doc.text(
    "Visão geral abaixo; páginas seguintes trazem chapas ampliadas.",
    MARGEM,
    y + 3,
  );
  y += 10;

  for (let i = 0; i < sheets.length; i++) {
    const tituloH = 7;
    const maxH = 38;
    if (y + tituloH + maxH + 4 > limiteY) {
      doc.addPage();
      y = MARGEM;
    }
    const scale = Math.min(larguraUtil / sheetW, maxH / sheetH);
    const drawW = sheetW * scale;
    const drawH = sheetH * scale;
    const x0 = MARGEM + (larguraUtil - drawW) / 2;

    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.setTextColor(60, 64, 72);
    doc.text(`Chapa #${i + 1}`, MARGEM, y + 4);
    y += tituloH;

    pintarChapa(doc, x0, y, drawW, drawH, scale, sheets[i], pieces, false);
    y += drawH + 6;
  }
  return y + 2;
}

function pintarBarra(
  doc: jsPDF,
  x0: number,
  y: number,
  drawW: number,
  barH: number,
  scale: number,
  bar: PackedBar,
  barLen: number,
  cuts: BarPiece[],
): void {
  doc.setFillColor(26, 26, 26);
  doc.setDrawColor(80, 80, 80);
  doc.rect(x0, y, drawW, barH, "FD");

  for (const seg of bar.segments) {
    const sw = Math.max(seg.len * scale, 0.4);
    const sx = x0 + seg.start * scale;
    const [r, g, b] = hexParaRgb(CUT_PLAN_COLORS[seg.cutIndex % CUT_PLAN_COLORS.length]);
    doc.setFillColor(r, g, b);
    doc.setDrawColor(20, 20, 20);
    doc.rect(sx, y, sw, barH, "F");
    const label = cuts[seg.cutIndex]?.label ?? "?";
    if (sw > 8) {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(Math.min(7, Math.max(5, sw / 12)));
      doc.setTextColor(10, 10, 10);
      doc.text(`${label} · ${seg.len}`, sx + sw / 2, y + barH / 2 + 1, { align: "center" });
    }
  }

  if (bar.waste > 0) {
    const wx = x0 + (barLen - bar.waste) * scale;
    const ww = Math.max(bar.waste * scale, 0.4);
    doc.setFillColor(51, 51, 51);
    doc.setDrawColor(120, 120, 120);
    doc.setLineDashPattern([1.5, 1], 0);
    doc.rect(wx, y, ww, barH, "D");
    doc.setLineDashPattern([], 0);
  }
}

function desenharBarra(
  doc: jsPDF,
  y: number,
  larguraUtil: number,
  limiteY: number,
  index: number,
  bar: PackedBar,
  barLen: number,
  cuts: BarPiece[],
): number {
  const barH = 22;
  const tituloH = 10;
  if (y + tituloH + barH + 8 > limiteY) {
    doc.addPage();
    y = MARGEM;
  }
  const scale = larguraUtil / barLen;
  const drawW = barLen * scale;
  const x0 = MARGEM + (larguraUtil - drawW) / 2;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(15, 27, 45);
  doc.text(`Barra #${index + 1}`, MARGEM, y + 4);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(80, 85, 95);
  const usoPct = (1 - bar.waste / barLen) * 100;
  doc.text(`Sobra: ${bar.waste} mm · uso ${num(usoPct, 1)}%`, MARGEM, y + 9);
  y += tituloH;

  pintarBarra(doc, x0, y, drawW, barH, scale, bar, barLen, cuts);
  return y + barH + 10;
}

function desenharDiagramasResumoBarras(
  doc: jsPDF,
  y: number,
  larguraUtil: number,
  limiteY: number,
  bars: PackedBar[],
  barLen: number,
  cuts: BarPiece[],
): number {
  if (bars.length === 0) return y;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(15, 27, 45);
  doc.text("Diagrama de corte", MARGEM, y);
  y += 5;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  doc.setTextColor(90, 95, 105);
  doc.text("Visão geral abaixo; páginas seguintes trazem barras ampliadas.", MARGEM, y + 3);
  y += 10;

  const barH = 14;
  for (let i = 0; i < bars.length; i++) {
    if (y + barH + 10 > limiteY) {
      doc.addPage();
      y = MARGEM;
    }
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.setTextColor(60, 64, 72);
    doc.text(`Barra #${i + 1}`, MARGEM, y + 4);
    y += 6;
    const scale = larguraUtil / barLen;
    pintarBarra(doc, MARGEM, y, barLen * scale, barH, scale, bars[i], barLen, cuts);
    y += barH + 8;
  }
  return y + 2;
}

export function buildCutPlanPdf(input: CutPlanPdfInput): jsPDF {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const larguraUtil = W - MARGEM * 2;
  const limiteY = H - RODAPE - 4;

  let y = desenharCabecalho(doc, input, larguraUtil);

  if (input.mode === "chaparia" && input.sheetResult && input.pieces) {
    const { w: sheetW, h: sheetH } = dimChapa(input);
    const r = input.sheetResult;

    y = desenharEstatisticas(doc, y, larguraUtil, [
      { rotulo: "Chapas usadas", valor: String(r.sheets.length) },
      { rotulo: "Peças encaixadas", valor: `${r.placedCount} / ${r.totalCount}` },
      { rotulo: "Aproveitamento", valor: `${num(r.usagePct, 1)}%` },
      { rotulo: "Sobra total", valor: `${num(r.wasteM2, 2)} m²` },
    ]);

    if (r.unplaced.length > 0) {
      doc.setFillColor(254, 226, 226);
      doc.rect(MARGEM, y, larguraUtil, 10, "F");
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(180, 40, 40);
      const txt = `Não coube: ${r.unplaced.map((u) => `${u.label} (${u.w}×${u.h})`).join(", ")}`;
      doc.text(doc.splitTextToSize(txt, larguraUtil - 4) as string[], MARGEM + 2, y + 6);
      y += 14;
    }

    y = desenharDiagramasResumoChaparia(
      doc,
      y,
      larguraUtil,
      limiteY,
      r.sheets,
      sheetW,
      sheetH,
      input.pieces,
    );

    y = desenharTabelaPecasChaparia(doc, y, larguraUtil, input.pieces, limiteY);

    if (input.notes?.trim()) {
      if (y + 14 > limiteY) {
        doc.addPage();
        y = MARGEM;
      }
      doc.setFont("helvetica", "bold");
      doc.setFontSize(9);
      doc.setTextColor(0, 0, 0);
      doc.text("Observações", MARGEM, y);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8.5);
      doc.setTextColor(60, 60, 60);
      const linhas = doc.splitTextToSize(input.notes.trim(), larguraUtil) as string[];
      doc.text(linhas, MARGEM, y + 5);
      y += 5 + linhas.length * 4;
    }

    if (r.sheets.length > 0) {
      doc.addPage();
      y = MARGEM;
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.setTextColor(15, 27, 45);
      doc.text("Layout de corte — chaparia (detalhe)", MARGEM, y + 5);
      y += 12;

      for (let i = 0; i < r.sheets.length; i++) {
        y = desenharChapa(doc, y, larguraUtil, limiteY, i, r.sheets[i], sheetW, sheetH, input.pieces);
        if (i < r.sheets.length - 1 && y + 50 > limiteY) {
          doc.addPage();
          y = MARGEM;
        }
      }
    }
  }

  if (input.mode === "barras" && input.barResult && input.cuts) {
    const barLen = dimBarra(input);
    const r = input.barResult;

    y = desenharEstatisticas(doc, y, larguraUtil, [
      { rotulo: "Barras usadas", valor: String(r.bars.length) },
      { rotulo: "Cortes", valor: String(r.totalCuts) },
      { rotulo: "Aproveitamento", valor: `${num(r.usagePct, 1)}%` },
      { rotulo: "Sobra total", valor: `${num(r.wasteMm / 1000, 2)} m` },
    ]);

    if (r.unplaced.length > 0) {
      doc.setFillColor(254, 226, 226);
      doc.rect(MARGEM, y, larguraUtil, 10, "F");
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(180, 40, 40);
      const txt = `Maior que a barra: ${r.unplaced.map((u) => `${u.label} (${u.len} mm)`).join(", ")}`;
      doc.text(doc.splitTextToSize(txt, larguraUtil - 4) as string[], MARGEM + 2, y + 6);
      y += 14;
    }

    y = desenharDiagramasResumoBarras(doc, y, larguraUtil, limiteY, r.bars, barLen, input.cuts);
    y = desenharTabelaCortes(doc, y, larguraUtil, input.cuts, limiteY);

    if (r.bars.length > 0) {
      doc.addPage();
      y = MARGEM;
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.setTextColor(15, 27, 45);
      doc.text("Layout de corte — barras (detalhe)", MARGEM, y + 5);
      y += 12;

      for (let i = 0; i < r.bars.length; i++) {
        y = desenharBarra(doc, y, larguraUtil, limiteY, i, r.bars[i], barLen, input.cuts);
      }
    }
  }

  paginar(doc, larguraUtil);
  return doc;
}

export function generateCutPlanPdf(input: CutPlanPdfInput): void {
  buildCutPlanPdf(input).save(`plano-corte-${slugNome(input.projectName)}.pdf`);
}
