/**
 * Asserções — Estoque efetivo (produtos globais + inventory overlay) + hardening.
 * npx tsx src/lib/effective-inventory.phase6.assert.ts
 */

import assert from "node:assert/strict";
import { readFileSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  canDeleteEffectiveItem,
  globalProductToEffective,
  inventoryItemToEffective,
  mergeEffectiveInventory,
  requiresMaterialization,
  type GlobalManufacturerProductRow,
} from "./effective-inventory";
import type { InventoryItemLike } from "./effective-inventory";
import { draftFromManufacturerProduct } from "./manufacturer-catalog/adopt";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "..", "..");

function baseInventory(overrides: Partial<InventoryItemLike> = {}): InventoryItemLike {
  return {
    id: "inv-1",
    categoria: "ferragem",
    nome: "Item manual",
    descricao: null,
    unidade: "un",
    quantidade: 3,
    estoque_minimo: 1,
    custo_unit: 10,
    preco_venda: 20,
    fornecedor: null,
    supplier_id: null,
    localizacao: null,
    imagem_url: null,
    observacoes: null,
    sku: "SKU-M",
    ncm: null,
    ativo: true,
    originado_de_projeto: false,
    manufacturer_product_id: null,
    manufacturer_product: null,
    ...overrides,
  };
}

function baseGlobal(
  overrides: Partial<GlobalManufacturerProductRow> = {},
): GlobalManufacturerProductRow {
  return {
    id: "mp-1",
    name: "Puxador 25mm",
    description: "Desc",
    source_code: "AL 1629 JB",
    inventory_category: "ferragem",
    unit: "un",
    primary_image_path: "mfg/a.jpg",
    active: true,
    product_manufacturers: { id: "m1", name: "Alufer", active: true },
    ...overrides,
  };
}

function run() {
  // Defaults virtuais
  const virtual = globalProductToEffective(baseGlobal());
  assert.ok(virtual);
  assert.equal(virtual!.source, "global");
  assert.equal(virtual!.inventoryItemId, null);
  assert.equal(virtual!.manufacturerProductId, "mp-1");
  assert.equal(virtual!.quantidade, 0);
  assert.equal(virtual!.estoque_minimo, 0);
  assert.equal(virtual!.custo_unit, 0);
  assert.equal(virtual!.preco_venda, 0);
  assert.equal(virtual!.sku, "AL 1629 JB");
  assert.equal(virtual!.nome, "Puxador 25mm");
  assert.equal(virtual!.categoria, "ferragem");
  assert.equal(virtual!.unidade, "un");
  assert.equal(virtual!.manufacturer_product?.primary_image_path, "mfg/a.jpg");
  assert.ok(requiresMaterialization(virtual!));
  assert.equal(canDeleteEffectiveItem(virtual!), false);

  // Sem fallback arbitrário outros/un
  const noCatUnit = globalProductToEffective(baseGlobal({ inventory_category: null, unit: null }));
  assert.ok(noCatUnit);
  assert.equal(noCatUnit!.categoria, null);
  assert.equal(noCatUnit!.unidade, null);
  const draftMissing = draftFromManufacturerProduct({
    name: "X",
    description: null,
    source_code: "C",
    inventory_category: null,
    unit: null,
  });
  assert.equal(draftMissing.categoria, undefined);
  assert.equal(draftMissing.unidade, undefined);

  // Global inativo não vira virtual
  assert.equal(globalProductToEffective(baseGlobal({ active: false })), null);
  assert.equal(
    globalProductToEffective(
      baseGlobal({ product_manufacturers: { id: "m1", name: "X", active: false } }),
    ),
    null,
  );

  // Merge: manual + global
  const manual = baseInventory();
  const merged = mergeEffectiveInventory([manual], [baseGlobal()]);
  assert.equal(merged.length, 2);
  assert.ok(merged.some((r) => r.source === "inventory" && r.inventoryItemId === "inv-1"));
  assert.ok(merged.some((r) => r.source === "global" && r.manufacturerProductId === "mp-1"));

  // Dedup exact overlay: inventory com manufacturer_product_id sobrescreve virtual
  const adopted = baseInventory({
    id: "inv-2",
    nome: "Puxador empresa",
    manufacturer_product_id: "mp-1",
    quantidade: 5,
    preco_venda: 99,
    imagem_url: "c1/estoque/x.jpg",
    manufacturer_product: {
      id: "mp-1",
      name: "Puxador 25mm",
      source_code: "AL 1629 JB",
      primary_image_path: "mfg/a.jpg",
      active: true,
      product_manufacturers: { id: "m1", name: "Alufer", active: true },
    },
  });
  const deduped = mergeEffectiveInventory([adopted], [baseGlobal()]);
  assert.equal(deduped.length, 1);
  assert.equal(deduped[0]!.source, "inventory");
  assert.equal(deduped[0]!.quantidade, 5);
  assert.equal(deduped[0]!.preco_venda, 99);
  assert.equal(deduped[0]!.imagem_url, "c1/estoque/x.jpg");
  assert.equal(canDeleteEffectiveItem(deduped[0]!), false);

  // Mesmo SKU manual/global (sem manufacturer_product_id) → duas linhas
  const sameSkuManual = baseInventory({
    id: "inv-sku",
    sku: "AL 1629 JB",
    nome: "Puxador manual",
    manufacturer_product_id: null,
  });
  const dualSku = mergeEffectiveInventory([sameSkuManual], [baseGlobal()]);
  assert.equal(dualSku.length, 2);
  assert.ok(dualSku.some((r) => r.source === "inventory" && r.sku === "AL 1629 JB"));
  assert.ok(dualSku.some((r) => r.source === "global" && r.sku === "AL 1629 JB"));

  // Manual deletável
  assert.equal(canDeleteEffectiveItem(inventoryItemToEffective(manual)), true);

  // Inventory materializado permanece mesmo se global some da lista (inativo)
  const kept = mergeEffectiveInventory([adopted], []);
  assert.equal(kept.length, 1);
  assert.equal(kept[0]!.manufacturerProductId, "mp-1");

  // Global inativo sem inventory → some; com inventory → permanece
  assert.equal(globalProductToEffective(baseGlobal({ active: false })), null);
  const inactiveGlobalKept = mergeEffectiveInventory(
    [
      baseInventory({
        id: "inv-inactive-g",
        manufacturer_product_id: "mp-dead",
        nome: "Overlay de inativo",
      }),
    ],
    [baseGlobal({ id: "mp-dead", active: false })],
  );
  assert.equal(inactiveGlobalKept.length, 1);
  assert.equal(inactiveGlobalKept[0]!.source, "inventory");

  // IDs distintos
  const row = mergeEffectiveInventory([], [baseGlobal()])[0]!;
  assert.notEqual(row.rowKey, row.manufacturerProductId);
  assert.equal(row.rowKey, "global:mp-1");
  assert.equal(row.inventoryItemId, null);

  // Menu: usuário comum não vê Catálogo de Fabricantes
  const shellPath = join(root, "src/components/AppShell.tsx");
  const shell = readFileSync(shellPath, "utf8");
  assert.equal(existsSync(shellPath), true, `AppShell missing at ${shellPath}`);
  assert.equal(shell.includes('label: "Catálogo de Fabricantes"'), false);
  assert.equal(shell.includes('to: "/app/catalogo-fabricantes"'), false);
  assert.equal(shell.includes("/app/estoque"), true);
  assert.equal(shell.includes("Estoque"), true);

  // Rotas legadas exigem platform admin
  const listRoute = readFileSync(
    join(root, "src/routes/_authenticated/app.catalogo-fabricantes.tsx"),
    "utf8",
  );
  const detailRoute = readFileSync(
    join(root, "src/routes/_authenticated/app.catalogo-fabricantes.$productId.tsx"),
    "utf8",
  );
  assert.ok(listRoute.includes("beforeLoad: requireAdmin"));
  assert.ok(detailRoute.includes("beforeLoad: requireAdmin"));
  assert.ok(!detailRoute.includes("Adicionar ao estoque"));
  assert.ok(!detailRoute.includes("useAdoptManufacturerProduct"));
  assert.ok(!listRoute.includes("useAdoptedManufacturerProductIds"));

  // Estoque: listagem efetiva + save atômico (não ensure+update)
  const estoque = readFileSync(join(root, "src/routes/_authenticated/app.estoque.tsx"), "utf8");
  assert.ok(estoque.includes("useEffectiveInventoryItems"));
  assert.ok(estoque.includes("useSaveManufacturerProductInventory"));
  assert.ok(estoque.includes("canDeleteEffectiveItem"));
  assert.ok(estoque.includes("Materialização ATÔMICA"));
  assert.ok(!estoque.includes("useEnsureManufacturerProductInventory"));
  assert.ok(!estoque.includes("/app/catalogo-fabricantes/$productId"));
  assert.ok(estoque.includes('i.source === "inventory"'));
  assert.ok(estoque.includes("inventoryItemId"));
  // Vender só com inventory real + qty > 0
  assert.ok(estoque.includes("Number(i.quantidade) > 0"));

  // Hook de leitura: sem mutação
  const effHook = readFileSync(join(root, "src/hooks/use-effective-inventory.ts"), "utf8");
  assert.ok(effHook.includes("Leitura sem side effects"));
  assert.ok(!effHook.includes(".insert("));
  assert.ok(!effHook.includes(".update("));
  assert.ok(!effHook.includes("ensure_manufacturer_product"));
  assert.ok(!effHook.includes("save_manufacturer_product"));
  // Filtro de categoria coerente nas duas fontes
  assert.ok(effHook.includes("effectiveInventoryCategoryFilter"));
  assert.ok(effHook.includes('.in("inventory_category"'));
  assert.ok(effHook.includes("filters.categoria"));

  // Hook save/ensure
  const saveHook = readFileSync(
    join(root, "src/hooks/use-ensure-manufacturer-inventory.ts"),
    "utf8",
  );
  assert.ok(saveHook.includes('rpc("save_manufacturer_product_inventory_item"'));
  assert.ok(saveHook.includes('rpc("ensure_manufacturer_product_inventory_item"'));
  assert.ok(saveHook.includes('throw new Error("Selecione uma categoria.")'));
  assert.ok(saveHook.includes('throw new Error("Selecione uma unidade.")'));
  assert.ok(!saveHook.includes("service_role"));
  assert.ok(!saveHook.includes('.from("manufacturer_products")'));

  // Migrations
  const migEnsurePath = join(
    root,
    "supabase/migrations/20260911120000_ensure_manufacturer_product_inventory.sql",
  );
  const migSavePath = join(
    root,
    "supabase/migrations/20260911130000_save_manufacturer_product_inventory.sql",
  );
  assert.ok(existsSync(migEnsurePath));
  assert.ok(existsSync(migSavePath));
  const migEnsure = readFileSync(migEnsurePath, "utf8");
  const migSave = readFileSync(migSavePath, "utf8");

  assert.ok(migEnsure.includes("ensure_manufacturer_product_inventory_item"));
  assert.ok(migEnsure.includes("unique_violation"));
  assert.ok(migEnsure.includes("can_manage_company_estoque"));
  assert.ok(migEnsure.includes("is_company_member"));
  assert.ok(migEnsure.includes("PRODUTO_INDISPONIVEL"));
  assert.ok(migEnsure.includes("security invoker"));
  assert.ok(!/raise exception\s+'JA_ADOTADO'/i.test(migEnsure));

  assert.ok(migSave.includes("save_manufacturer_product_inventory_item"));
  assert.ok(migSave.includes("created boolean"));
  assert.ok(migSave.includes("Categoria obrigatoria"));
  assert.ok(migSave.includes("Unidade obrigatoria"));
  assert.ok(migSave.includes("unique_violation"));
  assert.ok(migSave.includes("created := false"));
  assert.ok(migSave.includes("security invoker"));
  assert.ok(migSave.includes("set search_path = ''"));
  assert.ok(migSave.includes("can_manage_company_estoque"));
  assert.ok(migSave.includes("is_company_member"));
  assert.ok(migSave.includes("auth.uid()"));
  assert.ok(migSave.includes("owner_id"));
  assert.ok(migSave.includes("grant execute"));
  assert.ok(migSave.includes("to authenticated"));
  // Sem fallback outros/un na migration incremental
  assert.ok(!migSave.includes("'outros'::public.inventory_category"));
  assert.ok(!migSave.includes("'un'::public.inventory_unit"));
  // Race: sem UPDATE no caminho de unique_violation
  const raceBlock = migSave.split("when unique_violation then")[1] ?? "";
  assert.ok(raceBlock.includes("created := false") || raceBlock.includes("created=false"));
  assert.ok(!/update\s+public\.inventory_items/i.test(raceBlock.split("end;")[0] ?? ""));

  // ensure reescrito sem fallback
  assert.ok(migSave.includes("Sem fallback arbitrario"));
  assert.ok(
    migSave.includes(
      "create or replace function public.ensure_manufacturer_product_inventory_item",
    ),
  );

  // Types
  const types = readFileSync(join(root, "src/integrations/supabase/types.ts"), "utf8");
  assert.ok(types.includes("save_manufacturer_product_inventory_item"));
  assert.ok(types.includes("ensure_manufacturer_product_inventory_item"));
  assert.ok(types.includes("adopt_manufacturer_product_to_inventory"));

  // Dialog exige escolha
  const dialog = readFileSync(
    join(root, "src/components/inventory/InventoryItemDialog.tsx"),
    "utf8",
  );
  assert.ok(dialog.includes("needsCategoryChoice"));
  assert.ok(dialog.includes("needsUnitChoice"));
  assert.ok(dialog.includes("Selecione uma categoria."));
  assert.ok(dialog.includes("Selecione uma unidade."));

  // Importação admin intacta
  const adminImport = readFileSync(
    join(root, "src/routes/_authenticated/app.admin.importar-catalogo.tsx"),
    "utf8",
  );
  assert.ok(adminImport.includes("requireAdmin"));
  assert.ok(adminImport.includes("Importar catálogo"));

  // RPC adopt permanece legado (código/hook), sem CTA nas rotas de catálogo
  const adoptHook = readFileSync(join(root, "src/hooks/use-adopt-manufacturer-product.ts"), "utf8");
  assert.ok(adoptHook.includes('rpc("adopt_manufacturer_product_to_inventory"'));

  console.log("effective-inventory.phase6.assert: OK");
}

run();
