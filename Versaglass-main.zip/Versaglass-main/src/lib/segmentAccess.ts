export type SegmentSlug = "glass" | "steel" | "woodworking" | "stone" | "complete";

export type DashboardSegmentConfig = {
  slug: SegmentSlug;
  label: string;
  description: string;
  modules: string[];
  quickActions: string[];
  stockFocus: string[];
  projectFocus: string[];
};

export const SEGMENT_CONFIG: Record<SegmentSlug, DashboardSegmentConfig> = {
  glass: {
    slug: "glass",
    label: "Vidraçaria",
    description: "Box, espelhos, fachadas, guarda-corpo, alumínios e ferragens de vidro.",
    modules: [
      "Projetos de vidro",
      "Vidros",
      "Alumínios",
      "Ferragens",
      "Box",
      "Espelhos",
      "Guarda-corpo",
    ],
    quickActions: [
      "Novo orçamento",
      "Novo projeto",
      "Novo cliente",
      "Plano de corte",
      "Enviar WhatsApp",
    ],
    stockFocus: ["Vidro temperado", "Espelho", "Alumínio", "Ferragens", "Silicone"],
    projectFocus: [
      "Espelho orgânico LED",
      "Guarda-corpo inox",
      "Box até o teto",
      "Fachada glazing",
    ],
  },
  steel: {
    slug: "steel",
    label: "Serralheria",
    description: "Portões, galpões, coberturas, pergolados, escadas, aço e metalon.",
    modules: ["Portões", "Coberturas", "Galpões", "Estruturas", "Metalon", "Aço", "Plano de corte"],
    quickActions: ["Novo orçamento", "Novo portão", "Nova estrutura", "Plano de corte"],
    stockFocus: ["Metalon", "Tubo", "Chapa", "Dobradiça", "Roldana"],
    projectFocus: ["Portão basculante", "Telhado metálico", "Pergolado", "Galpão tesoura"],
  },
  woodworking: {
    slug: "woodworking",
    label: "Marcenaria",
    description: "MDF, móveis planejados, ferragens, corte, montagem e render 3D.",
    modules: [
      "Móveis planejados",
      "MDF/MDP",
      "Ferragens de móveis",
      "Plano de corte",
      "Render 3D",
      "Produção",
    ],
    quickActions: [
      "Novo orçamento",
      "Novo móvel",
      "Plano de corte",
      "Lista de ferragens",
      "Render 3D",
    ],
    stockFocus: ["MDF", "Fita de borda", "Corrediça", "Dobradiça", "Puxador"],
    projectFocus: ["Cozinha planejada", "Painel ripado", "Closet modulado", "Gabinete banheiro"],
  },
  stone: {
    slug: "stone",
    label: "Marmoraria",
    description: "Bancadas, cubas, mármores, granitos, quartzos e recortes técnicos.",
    modules: [
      "Bancadas",
      "Cubas",
      "Granitos",
      "Mármores",
      "Quartzos",
      "Recortes",
      "Plano de corte",
    ],
    quickActions: [
      "Novo orçamento",
      "Nova bancada",
      "Recorte de cuba",
      "Plano de corte",
      "Novo cliente",
    ],
    stockFocus: ["Granito", "Mármore", "Quartzo", "Porcelanato", "Cuba"],
    projectFocus: ["Bancada gourmet", "Cuba esculpida", "Escada em mármore", "Nicho de box"],
  },
  complete: {
    slug: "complete",
    label: "Empresa Multissetor",
    description: "Todos os módulos liberados para empresas que trabalham em vários segmentos.",
    modules: [
      "Vidraçaria",
      "Serralheria",
      "Marcenaria",
      "Marmoraria",
      "Fiscal",
      "Pay",
      "Marketplace",
    ],
    quickActions: [
      "Novo orçamento",
      "Novo projeto",
      "Novo cliente",
      "Nova venda",
      "Plano de corte",
    ],
    stockFocus: ["Vidros", "Alumínios", "Metalon", "MDF", "Pedras"],
    projectFocus: ["Espelho orgânico", "Portão", "Cozinha planejada", "Bancada"],
  },
};

export function getStoredSegment(): SegmentSlug {
  if (typeof window === "undefined") return "glass";
  const value = window.localStorage.getItem("versaglass:selectedSegment") as SegmentSlug | null;
  return value && value in SEGMENT_CONFIG ? value : "glass";
}

export function getDashboardSegment(): SegmentSlug {
  // Mesmo segmento do tenant — Super Admin não força "complete".
  return getStoredSegment();
}
