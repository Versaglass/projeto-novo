import { redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

/** Server-side Super Admin / platform-admin guard for TanStack `beforeLoad`.
 *
 * Fonte de verdade alinhada a `public.is_platform_admin()`:
 * papel de PLATAFORMA `admin` em `user_roles` — NÃO o admin da empresa
 * (`company_members.role`).
 */
export async function requireAdmin() {
  const { data } = await supabase.auth.getUser();
  if (!data.user) throw redirect({ to: "/auth" });
  const { data: roles } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", data.user.id);
  const isAdmin = roles?.some((r: { role: string }) => r.role === "admin");
  if (!isAdmin) throw redirect({ to: "/app" });
}
