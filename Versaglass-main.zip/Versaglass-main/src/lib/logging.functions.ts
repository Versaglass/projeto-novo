// =====================================================================
// Camada de ingestão de logs (P-07).
//
// O navegador NÃO grava mais nas tabelas de log. Ele chama estas server
// functions, que validam a entrada, derivam identidade e contexto no
// servidor e só então escrevem via `supabaseAdmin`.
//
// A escolha da tabela é feita no servidor: cada função abaixo tem um schema
// de entrada fechado e um destino fixo. O cliente não nomeia tabela.
//
// `requireSupabaseAuth` valida o Bearer token com o Supabase Auth e devolve
// `context.userId` a partir das claims. O token é anexado automaticamente
// pelo middleware global `attachSupabaseAuth` (ver src/start.ts). O token
// nunca é registrado nem devolvido.
// =====================================================================
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type LogResult = { success: true } | { success: false; code: string; message: string };

const OK: LogResult = { success: true };

/** Metadata é validada como objeto raso aqui e sanitizada no servidor. */
const MetadataSchema = z.record(z.string(), z.unknown()).optional();

const LEVELS = ["info", "warn", "error"] as const;

// Tipos que exigem sessão — o user_id vem SEMPRE do token.
const AUTHED_AUTH_KINDS = ["login_success", "payment", "subscription_created"] as const;
// Whitelist mínima e separada para eventos que ocorrem antes de existir sessão.
const ANON_AUTH_KINDS = ["signup", "login_error"] as const;

const FLOWS = ["first_password", "password_recovery", "admin_confirmation", "ia_action"] as const;

// ---------------------------------------------------------------------
// AUTH_EVENTS + SERVER_LOGS — evento autenticado
// ---------------------------------------------------------------------
const AuthedAuthEventInput = z.object({
  kind: z.enum(AUTHED_AUTH_KINDS),
  metadata: MetadataSchema,
});

export const logAuthEventAuthed = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => AuthedAuthEventInput.parse(d))
  .handler(async ({ data, context }): Promise<LogResult> => {
    const ingest = await import("@/lib/log-ingest.server");
    // Identidade derivada exclusivamente do token validado. Um `user_id` ou
    // `email` no payload seria ignorado — o schema acima nem os aceita.
    const email = typeof context.claims?.email === "string" ? context.claims.email : null;
    await ingest.writeAuthEvent({
      kind: data.kind,
      userId: context.userId,
      email,
      metadata: data.metadata,
    });
    await ingest.writeServerLog({
      action: `auth.${data.kind}`,
      level: "info",
      status: 200,
      userId: context.userId,
      userEmail: email,
      metadata: data.metadata,
    });
    return OK;
  });

// ---------------------------------------------------------------------
// AUTH_EVENTS + SERVER_LOGS — evento anônimo (pré-sessão)
//
// Endpoint deliberadamente estreito: só `signup` e `login_error`, nenhum
// user_id aceito, nenhuma senha ou token persistido. `email` é aceito porque
// a coluna existe e é o único elo utilizável para investigar tentativas —
// mas nunca é devolvido ao cliente, e a resposta é idêntica para conta
// existente ou inexistente, para não permitir enumeração.
// ---------------------------------------------------------------------
const AnonAuthEventInput = z.object({
  kind: z.enum(ANON_AUTH_KINDS),
  email: z.string().trim().email().max(255).optional(),
  metadata: MetadataSchema,
});

export const logAuthEventAnon = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => AnonAuthEventInput.parse(d))
  .handler(async ({ data }): Promise<LogResult> => {
    const ingest = await import("@/lib/log-ingest.server");
    await ingest.writeAuthEvent({
      kind: data.kind,
      userId: null, // nunca aceito de origem anônima
      email: data.email ?? null,
      metadata: data.metadata,
    });
    await ingest.writeServerLog({
      action: `auth.${data.kind}`,
      level: data.kind === "login_error" ? "error" : "info",
      status: data.kind === "login_error" ? 401 : 200,
      userId: null,
      userEmail: data.email ?? null,
      metadata: data.metadata,
    });
    return OK;
  });

// ---------------------------------------------------------------------
// SERVER_LOGS — log de aplicação autenticado
//
// `level` é restrito ao enum real da coluna. O cliente não consegue se
// declarar origem "server": a coluna não existe e a ação é prefixada com
// "app." aqui, no servidor.
// ---------------------------------------------------------------------
const ServerLogInput = z.object({
  action: z.string().trim().min(1).max(160),
  level: z.enum(LEVELS).default("info"),
  status: z.number().int().min(0).max(599).optional(),
  durationMs: z.number().int().min(0).max(86_400_000).optional(),
  message: z.string().max(2_000).optional(),
  metadata: MetadataSchema,
});

export const logServerEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ServerLogInput.parse(d))
  .handler(async ({ data, context }): Promise<LogResult> => {
    const ingest = await import("@/lib/log-ingest.server");
    await ingest.writeServerLog({
      action: `app.${data.action}`,
      level: data.level,
      status: data.status ?? null,
      durationMs: data.durationMs ?? null,
      message: data.message ?? null,
      userId: context.userId,
      userEmail: typeof context.claims?.email === "string" ? context.claims.email : null,
      metadata: data.metadata,
    });
    return OK;
  });

// ---------------------------------------------------------------------
// SECURITY_EVENTS — autenticado
//
// `user_id` vem do token. `company_id`, `ip_address` e `user_agent` não são
// aceitos do cliente. `success` é booleano; a coluna não tem "severity".
// ---------------------------------------------------------------------
const SecurityEventInput = z.object({
  flow: z.enum(FLOWS),
  action: z.string().trim().min(1).max(160),
  success: z.boolean().default(true),
  metadata: MetadataSchema,
});

export const logSecurityEventAuthed = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SecurityEventInput.parse(d))
  .handler(async ({ data, context }): Promise<LogResult> => {
    const ingest = await import("@/lib/log-ingest.server");
    await ingest.writeSecurityEvent({
      flow: data.flow,
      action: data.action,
      success: data.success,
      userId: context.userId,
      email: typeof context.claims?.email === "string" ? context.claims.email : null,
      metadata: data.metadata,
    });
    return OK;
  });

// ---------------------------------------------------------------------
// SECURITY_EVENTS — anônimo
//
// Necessário porque solicitar código de primeira senha ou de recuperação
// acontece antes de existir sessão. Nenhum user_id é aceito.
// ---------------------------------------------------------------------
const SecurityEventAnonInput = z.object({
  flow: z.enum(FLOWS),
  action: z.string().trim().min(1).max(160),
  success: z.boolean().default(true),
  email: z.string().trim().email().max(255).optional(),
  phone: z.string().trim().max(32).optional(),
  metadata: MetadataSchema,
});

export const logSecurityEventAnon = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => SecurityEventAnonInput.parse(d))
  .handler(async ({ data }): Promise<LogResult> => {
    const ingest = await import("@/lib/log-ingest.server");
    await ingest.writeSecurityEvent({
      flow: data.flow,
      action: data.action,
      success: data.success,
      userId: null,
      email: data.email ?? null,
      phone: data.phone ?? null,
      metadata: data.metadata,
    });
    return OK;
  });

// ---------------------------------------------------------------------
// AUDIT_LOGS — sempre autenticado
//
// `actor_id` vem do token: não é possível auditar em nome de terceiro.
// ---------------------------------------------------------------------
const AuditLogInput = z.object({
  action: z.string().trim().min(1).max(160),
  entity: z.string().trim().max(64).optional(),
  entityId: z.string().trim().max(64).optional(),
  metadata: MetadataSchema,
});

export const logAuditEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => AuditLogInput.parse(d))
  .handler(async ({ data, context }): Promise<LogResult> => {
    // Defesa em profundidade: as ações auditadas hoje nascem em telas já
    // protegidas por `requireAdmin` no router, mas o papel é reconferido aqui
    // contra o banco, com `has_role` avaliado no contexto do próprio usuário.
    const { data: isAdmin, error: roleErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (roleErr) throw new Error(`Forbidden: não foi possível verificar o papel.`);
    if (!isAdmin) throw new Error("Forbidden: ação administrativa exige papel admin.");

    const ingest = await import("@/lib/log-ingest.server");
    await ingest.writeAuditLog({
      actorId: context.userId,
      actorEmail: typeof context.claims?.email === "string" ? context.claims.email : null,
      action: data.action,
      entity: data.entity ?? null,
      entityId: data.entityId ?? null,
      metadata: data.metadata,
    });
    return OK;
  });
