import { cloneProjectData, type ProjectData } from "@/types/project-data";
import { rotuloSubtipo } from "@/lib/project-subtypes";
import { anexarClassificacaoVidroAoProjectData } from "@/lib/quote-item-vidro";

// Conversão MODELO TÉCNICO → item do formulário de orçamento.
//
// Função PURA: não toca no Supabase, não lê a empresa ativa, não faz insert e
// não altera o template nem itens existentes. Recebe um `project_template` e
// devolve um item novo, pronto para ser ACRESCENTADO ao formulário.
//
// O template é um MOLDE: o que sai daqui é uma cópia independente. Alterar o
// item no orçamento não volta para o template, e alterar o template depois não
// mexe em orçamento nenhum (não existe FK entre quote_items e project_templates).

export type TemplateSource = {
  nome: string;
  descricao?: string | null;
  espessura?: string | null;
  tipo?: string | null;
  /** Área do modelo (`project_templates.area` / catálogo). */
  area?: string | null;
  /** Categoria de material (`project_category`) — vira `project_data.vidro`. */
  categoria?: string | null;
  largura_padrao: number; // METROS
  altura_padrao: number; // METROS
  preco_m2: number;
  observacoes?: string | null;
  /**
   * Subtipo do modelo, cru como veio do banco. Opcional: o snapshot precisa
   * atravessar consultas que não pedem a coluna, e um item de orçamento nunca
   * dependeu dela — `quote_items` NÃO ganha coluna de subtipo, aqui ele só pode
   * enriquecer o TEXTO da descrição.
   */
  subtipo?: unknown;
  /** Desenho paramétrico do modelo, cru como veio do banco. */
  project_data?: unknown;
  /** Path da foto no Storage (Biblioteca ou catálogo, já com prefixo se necessário). */
  imagem_url?: string | null;
};

export type QuoteFormItem = {
  descricao: string;
  largura: number; // MILÍMETROS (unidade do formulário)
  altura: number; // MILÍMETROS
  quantidade: number;
  preco_unit: number;
  drawing_notes?: string | null;
  /** SNAPSHOT do desenho do modelo. `null` = item sem desenho paramétrico. */
  project_data: ProjectData | null;
  /** Snapshot do path da foto. `null` = sem foto no item. */
  imagem_url: string | null;
  /** Projeto direto / catálogo → true no orçamento (PDF imagem grande). */
  originado_de_projeto: boolean;
};

/**
 * Resultado da conversão.
 *
 * `desenhoInvalido` existe para a tela poder avisar. Um modelo com desenho
 * ilegível ainda gera um item comercial perfeitamente utilizável — seria pior
 * recusar o orçamento inteiro por causa da geometria —, mas o usuário precisa
 * saber que o desenho NÃO veio junto, em vez de descobrir depois.
 */
export type TemplateImportResult = {
  item: QuoteFormItem;
  desenhoInvalido: boolean;
};

/**
 * O `ParametricProjectEditor` grava o estado do editor dentro de `observacoes`
 * como `JSON.stringify({ editor: "realistic-2d-3d", state })`. Esse conteúdo NÃO
 * é observação humana e não pode vazar para o desenho técnico do orçamento —
 * seria impresso no PDF como texto ilegível. Qualquer coisa com cara de JSON é
 * descartada aqui.
 */
export function isHumanText(value: string | null | undefined): boolean {
  const t = (value ?? "").trim();
  if (!t) return false;
  if (t.startsWith("{") || t.startsWith("[")) return false;
  try {
    JSON.parse(t);
    return false; // parseou como JSON → não é texto humano
  } catch {
    return true;
  }
}

/** Metros → milímetros, sempre inteiro e não negativo. */
function metrosParaMm(valor: unknown): number {
  const n = Number(valor);
  if (!Number.isFinite(n) || n <= 0) return 0;
  return Math.round(n * 1000);
}

function naoNegativo(valor: unknown): number {
  const n = Number(valor);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

/**
 * O campo "Espessura (mm)" é TEXTO livre: aceita tanto "8" quanto "8mm" ou
 * "MDF 15mm" (outros segmentos). Quando vem só o número, a unidade é anexada —
 * senão a descrição do orçamento sairia "Box correr 2 folhas (8)", sem dizer de
 * que grandeza são esses 8, e é essa descrição que vai impressa no PDF.
 * Texto que já traz unidade ou material é preservado como está.
 */
function espessuraLegivel(valor: string): string {
  return /^\d+([.,]\d+)?$/.test(valor) ? `${valor}mm` : valor;
}

/** Minúsculas sem acento — só para COMPARAR texto, nunca para exibir. */
function comparavel(texto: string): string {
  return texto
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

/**
 * O rótulo do subtipo entra na descrição do item SÓ QUANDO ACRESCENTA ALGO.
 *
 * A descrição vai impressa no PDF do cliente, então repetição é custo real:
 * "Box 8mm — Box" é pior do que "Box 8mm". Duas recusas, ambas por um motivo:
 *
 *   · `outro_*` — o rótulo é "Outro", que não descreve produto nenhum. Um item
 *     chamado "Bancada cozinha — Outro" confunde quem lê o orçamento;
 *   · rótulo já contido no nome — comparação SEM acento e SEM caixa, porque
 *     "PORTAO DE VIDRO" e "Porta de vidro" são a mesma informação para quem lê
 *     e só uma comparação ingênua não perceberia.
 *
 * Nada disso altera preço, medida, quantidade ou `project_data`.
 */
function rotuloQueAjuda(subtipo: unknown, nome: string): string | null {
  if (typeof subtipo === "string" && subtipo.startsWith("outro_")) return null;
  const rotulo = rotuloSubtipo(subtipo);
  if (!rotulo) return null;
  return comparavel(nome).includes(comparavel(rotulo)) ? null : rotulo;
}

/**
 * Converte o modelo em UM item de orçamento.
 *
 * Mapeamento:
 *   nome (+ subtipo, + espessura)     → descricao (o subtipo só quando ajuda —
 *                                       ver `rotuloQueAjuda`)
 *   largura_padrao (m)                → largura (mm)
 *   altura_padrao  (m)                → altura  (mm)
 *   preco_m2                          → preco_unit  (preço por m² quando há dimensões)
 *   —                                 → quantidade = 1
 *   descricao ou observacoes (humano) → drawing_notes
 *   project_data (cópia independente) → project_data
 *   —                                 → drawing_data: NÃO. É o desenho TÉCNICO
 *                                       do próprio orçamento; o item pode ter
 *                                       os dois desenhos ao mesmo tempo.
 *
 * O snapshot é uma CÓPIA: `cloneProjectData` reconstrói o objeto e o array de
 * peças, então o item não guarda referência ao modelo. O formato não tem
 * `company_id`, `owner_id` nem id de template — é por isso que o snapshot pode
 * atravessar tabelas com segurança, e é o que deixa o orçamento autossuficiente.
 */
export function templateToQuoteItem(t: TemplateSource): TemplateImportResult {
  const nome = (t.nome ?? "").trim() || "Item";
  const espessura = (t.espessura ?? "").trim();
  const rotulo = rotuloQueAjuda(t.subtipo, nome);
  const base = rotulo ? `${nome} — ${rotulo}` : nome;
  const descricao = espessura ? `${base} (${espessuraLegivel(espessura)})` : base;

  // Observação técnica: prefere `descricao` do modelo; cai para `observacoes`.
  // Só entra se for texto humano de verdade.
  const candidatos = [t.descricao, t.observacoes];
  const notas = candidatos.find((c) => isHumanText(c));

  // Modelo SEM desenho e modelo COM desenho ilegível são casos DIFERENTES: o
  // primeiro é o normal, o segundo merece aviso. `null`/`undefined` não é erro;
  // qualquer outro valor que não passe na validação é.
  const temDesenho = t.project_data !== null && t.project_data !== undefined;
  const clonado = temDesenho ? cloneProjectData(t.project_data) : null;
  const imagem = (t.imagem_url ?? "").trim() || null;

  // Vidraçaria: categoria/espessura do modelo entram no snapshot comercial.
  // Se o modelo não tinha desenho, cria envelope mínimo só para esses campos.
  const snapshot: ProjectData | null = anexarClassificacaoVidroAoProjectData(clonado, {
    area: t.area,
    categoria: t.categoria,
    espessura: t.espessura,
    nome,
    larguraMetros: Number(t.largura_padrao) || 0,
    alturaMetros: Number(t.altura_padrao) || 0,
  });

  return {
    item: {
      descricao,
      largura: metrosParaMm(t.largura_padrao),
      altura: metrosParaMm(t.altura_padrao),
      quantidade: 1,
      preco_unit: naoNegativo(t.preco_m2),
      drawing_notes: notas ? notas.trim().slice(0, 2000) : null,
      project_data: snapshot,
      imagem_url: imagem,
      originado_de_projeto: true,
    },
    desenhoInvalido: temDesenho && clonado === null,
  };
}
