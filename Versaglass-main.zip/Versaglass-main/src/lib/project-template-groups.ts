// =====================================================================
// AGRUPAMENTO DE MODELOS TÉCNICOS POR ÁREA + SUBTIPO.
//
// Usado pelo seletor "Aplicar projeto" do orçamento, que mostra os modelos em
// dois níveis: primeiro o grupo, depois as variações dentro dele.
//
// POR QUE ISTO É UM MÓDULO, E NÃO UM `useMemo` DENTRO DA TELA
//
// Este é o ponto exato onde o seletor quebrou. O primeiro nível era montado a
// partir de `TIPOS_PROJETO`, uma lista FIXA de treze nomes — "Janela", "Porta",
// "Box", "Guarda-Corpo"… — toda ela de vidraçaria, comparada por igualdade
// exata contra `project_templates.tipo`, que é TEXTO LIVRE digitado por gente.
// Um modelo de marcenaria, marmoraria ou serralheria (`tipo` = "Armário",
// "Bancada de pedra", "Portão") não casava com item nenhum da lista e
// desaparecia da tela: os modelos existiam, a consulta os trazia, e a interface
// os escondia — sem grupo "Outros", sem aviso, sem sintoma.
//
// A regra passou a sair da classificação canônica (`area` + `subtipo`), que é
// enum e constraint no banco. Como é uma regra com ramos de verdade — par
// inválido, base legada, ordem estável — ela fica aqui, onde pode ser testada
// sem montar React, em vez de dentro do componente.
// =====================================================================

import { AREAS_PROJETO, normalizaArea, ROTULO_AREA } from "@/lib/project-area";
import { ehSubtipoDaArea, ROTULO_SUBTIPO, subtiposDaArea } from "@/lib/project-subtypes";

/**
 * Balde dos modelos sem classificação utilizável.
 *
 * Não deveria receber ninguém: `area` e `subtipo` são NOT NULL e o par é
 * validado por `project_templates_area_subtipo`. Existe para a base em que a
 * migration ainda não rodou — e porque sumir da tela foi exatamente o defeito
 * que este módulo corrige. Melhor um grupo "Sem classificação" visível do que
 * um modelo inalcançável.
 */
export const SEM_CLASSIFICACAO = "__sem_classificacao__";

/** O mínimo que este módulo precisa saber de um modelo. */
export type ModeloClassificavel = { area?: unknown; subtipo?: unknown };

export type GrupoDeModelos = {
  /** `area|subtipo`, ou `SEM_CLASSIFICACAO`. */
  chave: string;
  /** Rótulo da área, pronto para a tela. */
  area: string;
  /** Rótulo do subtipo, pronto para a tela. */
  subtipo: string;
  count: number;
};

/**
 * A chave de agrupamento de um modelo.
 *
 * Passa pelos validadores canônicos em vez de confiar no que veio do banco: a
 * consulta do seletor devolve `any`, e um par inconsistente tem de cair no
 * balde, nunca sumir. `normalizaArea` também traduz o alias legado
 * `serralheria_aco`, que ainda pode aparecer em desenho exportado.
 */
export function chaveDoGrupo(modelo: ModeloClassificavel): string {
  const area = normalizaArea(modelo.area);
  if (!area || !ehSubtipoDaArea(area, modelo.subtipo)) return SEM_CLASSIFICACAO;
  return `${area}|${modelo.subtipo}`;
}

/**
 * Os grupos que EXISTEM no acervo, na ordem canônica.
 *
 * Duas decisões:
 *
 * · só entra grupo com modelo. A lista antiga exibia os treze tipos fixos
 *   sempre, a maioria com "0 variações" — cliques que não levavam a lugar
 *   nenhum. Como a criação de modelo hoje parte de um item do orçamento
 *   ("Salvar como modelo"), navegar por grupo vazio não serve para nada;
 *
 * · a ordem é a das constantes (`AREAS_PROJETO` × `SUBTIPOS_POR_AREA`), não a de
 *   chegada dos dados nem a alfabética dos rótulos. Assim o seletor não
 *   reordena sozinho quando um modelo é criado ou excluído, e a posição de um
 *   grupo não depende de quantos modelos ele tem.
 *
 * O balde `SEM_CLASSIFICACAO` fecha a lista, quando existir.
 */
export function agrupaModelosPorTipo(modelos: readonly ModeloClassificavel[]): GrupoDeModelos[] {
  const contagem = new Map<string, number>();
  for (const m of modelos) {
    const chave = chaveDoGrupo(m);
    contagem.set(chave, (contagem.get(chave) ?? 0) + 1);
  }

  const grupos: GrupoDeModelos[] = [];
  for (const a of AREAS_PROJETO) {
    for (const s of subtiposDaArea(a)) {
      const count = contagem.get(`${a}|${s}`);
      if (count)
        grupos.push({
          chave: `${a}|${s}`,
          area: ROTULO_AREA[a],
          subtipo: ROTULO_SUBTIPO[s],
          count,
        });
    }
  }

  const soltos = contagem.get(SEM_CLASSIFICACAO);
  if (soltos) {
    grupos.push({
      chave: SEM_CLASSIFICACAO,
      area: "Sem classificação",
      subtipo: "Modelos antigos",
      count: soltos,
    });
  }
  return grupos;
}
