// @ts-nocheck
import { supabase } from "@/integrations/supabase/client";

export type IntegrationCategory =
  | "marketplace"
  | "payments"
  | "fiscal"
  | "whatsapp"
  | "google"
  | "email"
  | "api"
  | "backup";

export type IntegrationStatus =
  | "connected"
  | "disconnected"
  | "error"
  | "pending"
  | "token_expiring";

export type IntegrationProviderDefinition = {
  id: string;
  name: string;
  category: IntegrationCategory;
  description: string;
  capabilities: string[];
  requiredFields: { key: string; label: string; type?: "text" | "password" | "url" | "email" }[];
};

export type IntegrationDiagnosticFinding = {
  id: string;
  severity: "baixo" | "medio" | "alto" | "critico";
  title: string;
  problem: string;
  cause: string;
  solution: string;
  suggestedCommand: string;
  canAutoResolve: boolean;
};

export const INTEGRATION_PROVIDERS: IntegrationProviderDefinition[] = [
  {
    id: "mercado-livre",
    name: "Mercado Livre",
    category: "marketplace",
    description: "Produtos, estoque, pedidos, clientes e anúncios.",
    capabilities: ["Produtos", "Estoque", "Pedidos", "Clientes", "Categorias"],
    requiredFields: [
      { key: "client_id", label: "Client ID" },
      { key: "client_secret", label: "Client Secret", type: "password" },
      { key: "redirect_uri", label: "Redirect URI", type: "url" },
    ],
  },
  {
    id: "shopee",
    name: "Shopee",
    category: "marketplace",
    description: "Catálogo, pedidos, estoque e preço.",
    capabilities: ["Produtos", "Pedidos", "Estoque", "Preço"],
    requiredFields: [
      { key: "partner_id", label: "Partner ID" },
      { key: "partner_key", label: "Partner Key", type: "password" },
    ],
  },
  {
    id: "tiktok-shop",
    name: "TikTok Shop",
    category: "marketplace",
    description: "Produtos, vendas e sincronização de catálogo.",
    capabilities: ["Produtos", "Pedidos", "Estoque", "Marketing"],
    requiredFields: [
      { key: "app_key", label: "App Key" },
      { key: "app_secret", label: "App Secret", type: "password" },
    ],
  },
  {
    id: "shopify",
    name: "Shopify",
    category: "marketplace",
    description: "Loja virtual, produtos, estoque e pedidos.",
    capabilities: ["Produtos", "Pedidos", "Estoque", "Clientes"],
    requiredFields: [
      { key: "store_url", label: "URL da loja", type: "url" },
      { key: "access_token", label: "Access Token", type: "password" },
    ],
  },
  {
    id: "woocommerce",
    name: "WooCommerce",
    category: "marketplace",
    description: "Loja WordPress/WooCommerce.",
    capabilities: ["Produtos", "Pedidos", "Estoque"],
    requiredFields: [
      { key: "store_url", label: "URL da loja", type: "url" },
      { key: "consumer_key", label: "Consumer Key" },
      { key: "consumer_secret", label: "Consumer Secret", type: "password" },
    ],
  },
  {
    id: "asaas",
    name: "Asaas",
    category: "payments",
    description: "PIX, boleto, cartão, link e webhook.",
    capabilities: ["PIX", "Boleto", "Cartão", "Link", "Webhook"],
    requiredFields: [
      { key: "api_key", label: "API Key", type: "password" },
      { key: "webhook_url", label: "Webhook URL", type: "url" },
    ],
  },
  {
    id: "efi",
    name: "Efí/Gerencianet",
    category: "payments",
    description: "PIX, boleto, certificado e cobranças.",
    capabilities: ["PIX", "Boleto", "Webhook", "Certificado"],
    requiredFields: [
      { key: "client_id", label: "Client ID" },
      { key: "client_secret", label: "Client Secret", type: "password" },
      { key: "certificate", label: "Certificado A1" },
    ],
  },
  {
    id: "mercado-pago",
    name: "Mercado Pago",
    category: "payments",
    description: "Checkout, link, cartão e notificações.",
    capabilities: ["Link", "Cartão", "PIX", "Webhook"],
    requiredFields: [
      { key: "access_token", label: "Access Token", type: "password" },
      { key: "webhook_url", label: "Webhook URL", type: "url" },
    ],
  },
  {
    id: "pagarme",
    name: "Pagar.me",
    category: "payments",
    description: "Split, cartão, boleto, PIX e recorrência.",
    capabilities: ["Split", "Cartão", "Boleto", "PIX", "Recorrência"],
    requiredFields: [
      { key: "api_key", label: "API Key", type: "password" },
      { key: "recipient_id", label: "Recipient ID" },
    ],
  },
  {
    id: "plugnotas",
    name: "PlugNotas",
    category: "fiscal",
    description: "NF-e, NFS-e, XML, DANFE e webhooks.",
    capabilities: ["NF-e", "NFS-e", "DANFE", "XML", "Webhook"],
    requiredFields: [
      { key: "api_key", label: "API Key", type: "password" },
      { key: "environment", label: "Ambiente" },
    ],
  },
  {
    id: "tecnospeed",
    name: "TecnoSpeed",
    category: "fiscal",
    description: "Emissão fiscal e documentos eletrônicos.",
    capabilities: ["NF-e", "NFS-e", "NFC-e", "Webhook"],
    requiredFields: [
      { key: "token", label: "Token", type: "password" },
      { key: "cnpj", label: "CNPJ" },
    ],
  },
  {
    id: "nuvem-fiscal",
    name: "Nuvem Fiscal",
    category: "fiscal",
    description: "API fiscal moderna para NF-e/NFS-e.",
    capabilities: ["NF-e", "NFS-e", "Eventos", "Webhook"],
    requiredFields: [
      { key: "client_id", label: "Client ID" },
      { key: "client_secret", label: "Client Secret", type: "password" },
    ],
  },
  {
    id: "whatsapp",
    name: "WhatsApp Business API",
    category: "whatsapp",
    description: "Mensagens, templates, orçamento, cobrança e suporte.",
    capabilities: ["Templates", "Mensagens", "Webhooks", "Catálogo"],
    requiredFields: [
      { key: "phone_number_id", label: "Phone Number ID" },
      { key: "access_token", label: "Access Token", type: "password" },
      { key: "verify_token", label: "Verify Token", type: "password" },
    ],
  },
  {
    id: "google-calendar",
    name: "Google Agenda",
    category: "google",
    description: "Medições, instalações, rotas e compromissos.",
    capabilities: ["Agenda", "Instalações", "Medições"],
    requiredFields: [
      { key: "client_id", label: "Client ID" },
      { key: "client_secret", label: "Client Secret", type: "password" },
    ],
  },
  {
    id: "google-drive",
    name: "Google Drive",
    category: "google",
    description: "Backup de PDFs, XML, imagens e documentos.",
    capabilities: ["Backup", "Arquivos", "Documentos"],
    requiredFields: [
      { key: "client_id", label: "Client ID" },
      { key: "client_secret", label: "Client Secret", type: "password" },
    ],
  },
  {
    id: "smtp",
    name: "E-mail SMTP",
    category: "email",
    description: "Envio de orçamento, nota fiscal, cobrança e recibo.",
    capabilities: ["E-mail", "PDF", "Recibo", "Nota Fiscal"],
    requiredFields: [
      { key: "host", label: "Servidor SMTP" },
      { key: "port", label: "Porta" },
      { key: "username", label: "Usuário" },
      { key: "password", label: "Senha", type: "password" },
    ],
  },
];

export function getProviderById(providerId: string) {
  return INTEGRATION_PROVIDERS.find((provider) => provider.id === providerId);
}

export function buildIntegrationConfigurePlan(providerId: string, values: Record<string, any>) {
  const provider = getProviderById(providerId);
  if (!provider) throw new Error("Integração não encontrada.");
  const missing = provider.requiredFields.filter((field) => !values[field.key]);
  return {
    type: "configure_integration" as const,
    title: `Configurar integração: ${provider.name}`,
    summary: missing.length
      ? `A IA vai criar a pré-configuração de ${provider.name}, mas ainda faltam campos: ${missing.map((field) => field.label).join(", ")}.`
      : `A IA vai configurar ${provider.name}, salvar credenciais de forma protegida e preparar testes de conexão/webhook.`,
    risk: "alto" as const,
    targetTable: "integration_connections",
    operation: "upsert" as const,
    payload: {
      provider_id: provider.id,
      provider_name: provider.name,
      category: provider.category,
      status: missing.length ? "pending" : "connected",
      credentials: values,
      capabilities: provider.capabilities,
      missing_fields: missing.map((field) => field.key),
      last_action: "configured_by_ia_intelligence",
    },
  };
}

export function buildIntegrationSyncPlan(providerId: string, syncOptions: string[]) {
  const provider = getProviderById(providerId);
  if (!provider) throw new Error("Integração não encontrada.");
  return {
    type: "sync_integration" as const,
    title: `Sincronizar ${provider.name}`,
    summary: `A IA vai iniciar sincronização de ${syncOptions.join(", ")} com ${provider.name}, registrar logs e apontar divergências.`,
    risk: "medio" as const,
    targetTable: "integration_sync_jobs",
    operation: "insert" as const,
    payload: {
      provider_id: provider.id,
      provider_name: provider.name,
      category: provider.category,
      sync_options: syncOptions,
      status: "queued",
    },
  };
}

export async function runIntegrationsDiagnosis(userId: string) {
  const { data: connections } = await supabase
    .from("integration_connections" as any)
    .select("*")
    .order("created_at", { ascending: false });

  const findings: IntegrationDiagnosticFinding[] = [];
  const list = connections || [];

  if (list.length === 0) {
    findings.push({
      id: crypto.randomUUID(),
      severity: "medio",
      title: "Nenhuma integração configurada",
      problem: "A plataforma ainda não possui integrações ativas.",
      cause: "Marketplace, pagamento, fiscal, WhatsApp e Google não foram conectados.",
      solution: "Abrir o assistente de integração e configurar os provedores usados pela empresa.",
      suggestedCommand:
        "IA Intelligence, abrir assistente para configurar Mercado Livre, WhatsApp, Asaas e PlugNotas.",
      canAutoResolve: false,
    });
  }

  for (const item of list) {
    const tokenExpiresAt = item.token_expires_at ? new Date(item.token_expires_at) : null;
    const daysToExpire = tokenExpiresAt
      ? Math.ceil((tokenExpiresAt.getTime() - Date.now()) / 86400000)
      : null;
    if (["error", "failed"].includes(item.status)) {
      findings.push({
        id: crypto.randomUUID(),
        severity: "alto",
        title: `${item.provider_name || item.provider_id} com erro`,
        problem: "A integração está marcada com erro/falha.",
        cause:
          item.last_error || "Token, webhook, permissão ou resposta da API pode estar inválido.",
        solution: "Testar conexão, recriar webhook e revisar credenciais.",
        suggestedCommand: `IA Intelligence, corrigir integração ${item.provider_id}: testar conexão e recriar webhook.`,
        canAutoResolve: true,
      });
    }
    if (daysToExpire !== null && daysToExpire <= 7) {
      findings.push({
        id: crypto.randomUUID(),
        severity: "medio",
        title: `${item.provider_name || item.provider_id} com token próximo de vencer`,
        problem: `Token vence em ${daysToExpire} dia(s).`,
        cause: "A autorização da API precisa ser renovada periodicamente.",
        solution: "Renovar token antes de bloquear sincronizações.",
        suggestedCommand: `IA Intelligence, renovar token da integração ${item.provider_id}.`,
        canAutoResolve: true,
      });
    }
  }

  const result = {
    generated_at: new Date().toISOString(),
    connection_count: list.length,
    findings,
    score: Math.max(
      0,
      100 -
        findings.filter((f) => f.severity === "alto" || f.severity === "critico").length * 20 -
        findings.filter((f) => f.severity === "medio").length * 10,
    ),
  };

  await supabase.from("integration_diagnostics" as any).insert({
    user_id: userId,
    result,
    status: "completed",
    summary: `Diagnóstico concluído: ${findings.length} achado(s).`,
  });

  return result;
}
