import { jsPDF } from "jspdf";
import { brl, num, dateBR } from "@/lib/format";

export type QuoteReportKind =
  | "cliente"
  | "vidros"
  | "instalador"
  | "recibo"
  | "contrato"
  | "localizacao";

/** Campos lidos pelos PDFs de relatório — espelho mínimo do orçamento/cliente/item. */
type ReportCustomer = {
  nome?: string | null;
  documento?: string | null;
  telefone?: string | null;
  email?: string | null;
  endereco?: string | null;
  cidade?: string | null;
  observacoes?: string | null;
};

type ReportQuote = {
  numero?: string | number | null;
  created_at?: string | null;
  total?: number | string | null;
  instalador_nome?: string | null;
  instalacao_em?: string | null;
  customer?: ReportCustomer | null;
  cliente?: ReportCustomer | null;
};

type ReportItem = {
  descricao?: string | null;
  largura?: number | null;
  altura?: number | null;
  m2?: number | null;
  quantidade?: number | null;
};

type ReportProfile = {
  nome_empresa?: string | null;
  nome?: string | null;
};

const TITLES: Record<QuoteReportKind, string> = {
  cliente: "Relatório do Cliente",
  vidros: "Relação de Vidros",
  instalador: "Roteiro do Instalador",
  recibo: "Recibo",
  contrato: "Contrato de Prestação de Serviço",
  localizacao: "Localização da Obra",
};

function line(doc: jsPDF, label: string, value?: string | number | null, y = 0) {
  doc.setFont("helvetica", "bold");
  doc.text(`${label}:`, 14, y);
  doc.setFont("helvetica", "normal");
  doc.text(String(value ?? "—"), 52, y);
}

function header(doc: jsPDF, title: string, quote: ReportQuote, customer: ReportCustomer) {
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.text(title, 14, 18);
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text(`Orçamento #${quote.numero ?? "—"} • ${dateBR(quote.created_at)}`, 14, 25);
  doc.text(`Cliente: ${customer?.nome ?? "—"}`, 14, 31);
  doc.line(14, 36, 196, 36);
}

// Seção de materiais do relatório "Instalador" (Rev. 208). A Revisão 103 tirou
// o valor de cada linha: documento de chão de fábrica — separar, conferir e
// produzir —, e o preço não tem uso nessa etapa. Continuam nome do item,
// dimensões e quantidade. Preço segue no cartão "Orçamento", no Recibo e no
// Contrato.
function itemLines(items: ReportItem[]) {
  return (items ?? []).map((i, idx) => {
    const medida =
      i.largura && i.altura
        ? `${num(i.largura, 2)} x ${num(i.altura, 2)} m`
        : "medida não informada";
    return `${idx + 1}. ${i.descricao ?? "Item"} • ${medida} • qtd ${i.quantidade ?? 1}`;
  });
}

export function generateQuoteReportPdf(
  kind: QuoteReportKind,
  quote: ReportQuote,
  items: ReportItem[],
  profile: ReportProfile = {},
) {
  const customer = quote.customer ?? quote.cliente ?? {};
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  header(doc, TITLES[kind], quote, customer);

  let y = 48;
  doc.setFontSize(10);

  if (kind === "cliente") {
    line(doc, "Nome", customer.nome, y);
    y += 7;
    line(doc, "Documento", customer.documento, y);
    y += 7;
    line(doc, "Telefone", customer.telefone, y);
    y += 7;
    line(doc, "E-mail", customer.email, y);
    y += 7;
    line(doc, "Endereço", [customer.endereco, customer.cidade].filter(Boolean).join(" - "), y);
    y += 10;
    doc.text("Observações do cliente:", 14, y);
    y += 6;
    doc.text(doc.splitTextToSize(customer.observacoes ?? "—", 180), 14, y);
  }

  if (kind === "vidros") {
    doc.setFont("helvetica", "bold");
    doc.text("Vidros do orçamento", 14, y);
    y += 8;
    doc.setFont("helvetica", "normal");
    const rows = (items ?? []).map(
      (i, idx) =>
        `${idx + 1}. ${i.descricao ?? "Vidro"} • ${num(i.largura ?? 0, 2)} x ${num(i.altura ?? 0, 2)} m • área ${num(i.m2 ?? 0, 3)} m² • qtd ${i.quantidade ?? 1}`,
    );
    doc.text(
      doc.splitTextToSize(rows.length ? rows.join("\n") : "Nenhum vidro cadastrado.", 180),
      14,
      y,
    );
  }

  if (kind === "instalador") {
    line(doc, "Instalador", quote.instalador_nome ?? "A definir", y);
    y += 7;
    line(
      doc,
      "Data instalação",
      quote.instalacao_em ? dateBR(quote.instalacao_em) : "A definir",
      y,
    );
    y += 7;
    line(doc, "Endereço", [customer.endereco, customer.cidade].filter(Boolean).join(" - "), y);
    y += 10;
    doc.setFont("helvetica", "bold");
    doc.text("Lista de materiais previstos", 14, y);
    y += 8;
    doc.setFont("helvetica", "normal");
    const materialRows = itemLines(items);
    const listLines = doc.splitTextToSize(
      materialRows.length ? materialRows.join("\n") : "Nenhum material cadastrado.",
      180,
    );
    doc.text(listLines, 14, y);
    y += listLines.length * 5 + 8;
    doc.setFont("helvetica", "bold");
    doc.text("Uso na OS:", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    doc.text("Separar, conferir, produzir, embalar e liberar para instalação.", 14, y);
    y += 10;
    doc.setFont("helvetica", "bold");
    doc.text("Checklist:", 14, y);
    y += 7;
    doc.setFont("helvetica", "normal");
    doc.text(
      "[ ] Conferir medidas   [ ] Conferir ferragens   [ ] Fotografar antes/depois   [ ] Coletar assinatura",
      14,
      y,
    );
  }

  if (kind === "recibo") {
    doc.setFontSize(12);
    doc.text(
      doc.splitTextToSize(
        `Recebemos de ${customer.nome ?? "cliente"} o valor de ${brl(Number(quote.total ?? 0))}, referente ao orçamento #${quote.numero ?? "—"}.`,
        180,
      ),
      14,
      y,
    );
    y += 40;
    doc.line(54, y, 156, y);
    doc.text("Assinatura", 92, y + 6);
  }

  if (kind === "contrato") {
    const texto = `Contratante: ${customer.nome ?? "—"}. Contratada: ${profile.nome_empresa ?? profile.nome ?? "Empresa"}. Objeto: fabricação, fornecimento e/ou instalação dos itens descritos no orçamento #${quote.numero ?? "—"}. Valor total: ${brl(Number(quote.total ?? 0))}. Prazo e condições conforme aprovado pelo cliente. Alterações de medidas, ferragens, recortes, materiais ou instalação podem gerar revisão de preço e prazo.`;
    doc.text(doc.splitTextToSize(texto, 180), 14, y);
    y += 70;
    doc.line(24, y, 94, y);
    doc.line(116, y, 186, y);
    doc.text("Contratante", 44, y + 6);
    doc.text("Contratada", 138, y + 6);
  }

  if (kind === "localizacao") {
    const endereco = [customer.endereco, customer.cidade].filter(Boolean).join(" - ");
    line(doc, "Endereço", endereco, y);
    y += 8;
    doc.text(
      "Use o botão de localização na tela do orçamento para abrir o endereço no Google Maps.",
      14,
      y,
    );
  }

  doc.setFontSize(8);
  doc.text(`Gerado em ${new Date().toLocaleString("pt-BR")}`, 14, 288);
  doc.save(`${kind}_orcamento_${quote.numero ?? "sem-numero"}.pdf`);
}
