import { supabase } from "@/integrations/supabase/client";
import {
  buildIntegrationConfigurePlan,
  buildIntegrationSyncPlan,
  getProviderById,
} from "@/lib/integration-architect";

export type IAActionType =
  | "create_product"
  | "adjust_stock"
  | "update_login_template"
  | "advanced_table_operation"
  | "general_system_change"
  | "resolve_scan_finding"
  | "create_ai_agent"
  | "update_ai_agent"
  | "project_media_change"
  | "create_project_model"
  | "guided_workflow"
  | "configure_integration"
  | "diagnose_integration"
  | "sync_integration"
  | "fix_integration";

export type IAActionPlan = {
  type: IAActionType;
  title: string;
  summary: string;
  risk: "baixo" | "medio" | "alto" | "critico";
  targetTable?: string;
  operation?: "insert" | "update" | "delete" | "upsert";
  payload: Record<string, any>;
  beforeSnapshot?: Record<string, any> | null;
};

export type IAScanPeriod = 15 | 30 | 60 | 90 | 180;

export type IAGuidedOption = {
  id: string;
  label: string;
  description: string;
  children?: IAGuidedOption[];
};

export const IA_GUIDED_WORKFLOW: IAGuidedOption[] = [
  {
    id: "dashboard",
    label: "Página inicial",
    description: "Templates, cards, textos, imagens, métricas e botões.",
  },
  {
    id: "login",
    label: "Login",
    description: "Capa, textos, imagens, cores, módulos destacados e chamadas comerciais.",
  },
  {
    id: "projetos",
    label: "Projetos",
    description: "Biblioteca, editor 2D/3D, imagens, modelos e planos.",
    children: [
      {
        id: "vidracaria",
        label: "Vidraçaria",
        description: "Portas, box, espelhos, guarda-corpo, fachadas e ferragens.",
      },
      {
        id: "serralheria",
        label: "Serralheria",
        description: "Portões, galpões, coberturas, pergolados, escadas e estruturas.",
      },
      {
        id: "marcenaria",
        label: "Marcenaria",
        description: "Armários, cozinhas, painéis, closets, MDF e plano de corte.",
      },
      {
        id: "marmoraria",
        label: "Marmoraria",
        description: "Bancadas, cubas, cooktops, nichos, escadas e pedras.",
      },
      {
        id: "editor",
        label: "Editor 2D",
        description: "Cotas, objetos, componentes, renderização e plano de corte.",
      },
    ],
  },
  {
    id: "orcamentos",
    label: "Orçamentos",
    description: "Template, PDF, contrato, materiais, recibo, WhatsApp e nota fiscal.",
  },
  {
    id: "produtos",
    label: "Produtos",
    description: "Produtos próprios da empresa, imagem, SKU, preço, estoque e categoria.",
  },
  {
    id: "estoque",
    label: "Estoque",
    description: "Inventário, alumínios, vidros, ferragens, acessórios, PDF e alertas.",
  },
  {
    id: "financeiro",
    label: "Financeiro",
    description: "Gráficos, gastos pessoais, fluxo de caixa, IA financeira e boletos.",
  },
  {
    id: "planos",
    label: "Planos",
    description: "Bloqueio por assinatura, PRO, PREMIUM, limites e upgrades.",
  },
  {
    id: "ias",
    label: "Outras IAs",
    description: "Criar, editar, ativar, desativar e definir permissões de IAs.",
  },
  {
    id: "relatorios",
    label: "Relatórios",
    description: "Clientes, materiais, PDFs, instalador, localização e dashboards.",
  },
  {
    id: "fiscal",
    label: "Fiscal",
    description: "NF-e, NFS-e, XML, DANFE, certificado e provedores fiscais.",
  },
  {
    id: "pay",
    label: "VersaGlass Pay",
    description: "PIX, boleto, cartão, link, split, taxas e recorrências.",
  },
  {
    id: "integracoes",
    label: "Integrações",
    description: "Marketplace, pagamento, fiscal, WhatsApp, Google, APIs, webhooks e diagnóstico.",
  },
  {
    id: "configuracoes",
    label: "Configurações",
    description: "Empresa, usuários, permissões, segurança, tema e módulos.",
  },
];

export function isGuidedAlterationRequest(command: string) {
  const lower = command.toLowerCase();
  return [
    "quero alterar",
    "gostaria de alterar",
    "gostaria de fazer uma alteração",
    "fazer alteração",
    "modificar sistema",
    "ajustar sistema",
    "configurar sistema",
  ].some((term) => lower.includes(term));
}

export function buildGuidedWorkflowPlan(moduleId: string, childId?: string): IAActionPlan {
  const module = IA_GUIDED_WORKFLOW.find((item) => item.id === moduleId);
  const child = module?.children?.find((item) => item.id === childId);
  return {
    type: "guided_workflow",
    title: `Iniciar alteração assistida: ${module?.label || moduleId}${child ? ` > ${child.label}` : ""}`,
    summary: `A IA Intelligence vai abrir um fluxo organizado para alterar ${module?.label || moduleId}${child ? ` na área ${child.label}` : ""}. Nenhuma mudança será aplicada sem senha ADM.`,
    risk: "medio",
    targetTable: "ai_intelligence_commands",
    operation: "insert",
    payload: {
      moduleId,
      childId,
      moduleLabel: module?.label,
      childLabel: child?.label,
      mode: "guided_workflow",
    },
  };
}

export type IAScanFinding = {
  id: string;
  area: "estoque" | "financeiro" | "fiscal" | "orcamentos" | "sistema" | "comercial";
  severity: "baixo" | "medio" | "alto" | "critico";
  title: string;
  problem: string;
  cause: string;
  solution: string;
  suggestedCommand: string;
  evidence: Record<string, any>;
  canAutoResolve: boolean;
};

export type IAScanResult = {
  periodDays: IAScanPeriod;
  generatedAt: string;
  summary: string;
  findings: IAScanFinding[];
};

function extractMoney(text: string) {
  const match = text.match(/(?:r\$\s*)?(\d+[\d.,]*)/i);
  if (!match) return undefined;
  return Number(match[1].replace(/\./g, "").replace(",", "."));
}

function extractAfter(text: string, label: string) {
  const regex = new RegExp(`${label}\\s*[:=-]\\s*([^,;\\n]+)`, "i");
  return text.match(regex)?.[1]?.trim();
}

function safeSlug(text: string) {
  return text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export function buildIAActionPlan(command: string): IAActionPlan {
  const lower = command.toLowerCase();

  if (isGuidedAlterationRequest(command)) {
    return {
      type: "guided_workflow",
      title: "Abrir menu de alteração assistida",
      summary:
        "A IA vai apresentar opções organizadas por módulo para o ADM escolher o que deseja alterar. Nenhuma ação será executada sem senha.",
      risk: "baixo",
      targetTable: "ai_intelligence_commands",
      operation: "insert",
      payload: {
        command,
        mode: "open_guided_menu",
        options: IA_GUIDED_WORKFLOW.map(({ id, label, description }) => ({
          id,
          label,
          description,
        })),
      },
    };
  }

  if (
    lower.includes("integra") ||
    lower.includes("marketplace") ||
    lower.includes("webhook") ||
    lower.includes("sincronizar") ||
    lower.includes("api ") ||
    lower.includes("asaas") ||
    lower.includes("mercado livre") ||
    lower.includes("whatsapp")
  ) {
    const providerMap: Record<string, string> = {
      "mercado livre": "mercado-livre",
      shopee: "shopee",
      tiktok: "tiktok-shop",
      shopify: "shopify",
      woocommerce: "woocommerce",
      asaas: "asaas",
      efi: "efi",
      gerencianet: "efi",
      "mercado pago": "mercado-pago",
      pagarme: "pagarme",
      "pagar.me": "pagarme",
      plugnotas: "plugnotas",
      tecnospeed: "tecnospeed",
      "nuvem fiscal": "nuvem-fiscal",
      whatsapp: "whatsapp",
      "google agenda": "google-calendar",
      "google drive": "google-drive",
      smtp: "smtp",
      email: "smtp",
    };
    const providerId =
      Object.entries(providerMap).find(([label]) => lower.includes(label))?.[1] ||
      extractAfter(command, "provedor") ||
      extractAfter(command, "integração") ||
      "custom-api";
    if (
      lower.includes("diagnosticar") ||
      lower.includes("verificar") ||
      lower.includes("analisar")
    ) {
      return {
        type: "diagnose_integration",
        title: "Diagnosticar integrações",
        summary:
          "A IA vai testar conexões, tokens, webhooks, últimas sincronizações e erros das integrações configuradas.",
        risk: "medio",
        targetTable: "integration_diagnostics",
        operation: "insert",
        payload: { command, provider_id: providerId, mode: "diagnosis" },
      };
    }
    if (lower.includes("sincronizar") || lower.includes("sync")) {
      const syncOptions = [
        "produtos",
        "estoque",
        "pedidos",
        "clientes",
        "preços",
        "imagens",
      ].filter(
        (opt) =>
          lower.includes(opt) ||
          lower.includes(opt.normalize("NFD").replace(/[\u0300-\u036f]/g, "")),
      );
      return buildIntegrationSyncPlan(
        providerId,
        syncOptions.length ? syncOptions : ["produtos", "estoque"],
      );
    }
    if (
      lower.includes("corrigir") ||
      lower.includes("recriar webhook") ||
      lower.includes("renovar token")
    ) {
      const provider = getProviderById(providerId);
      return {
        type: "fix_integration",
        title: `Corrigir integração: ${provider?.name || providerId}`,
        summary:
          "A IA vai registrar uma rotina de correção: testar conexão, validar token, recriar webhook e salvar diagnóstico antes/depois.",
        risk: "alto",
        targetTable: "integration_repair_jobs",
        operation: "insert",
        payload: {
          provider_id: providerId,
          provider_name: provider?.name || providerId,
          command,
          status: "queued",
          steps: ["test_connection", "validate_token", "recreate_webhook", "write_log"],
        },
      };
    }
    const values: Record<string, any> = {};
    [
      "api_key",
      "token",
      "client_id",
      "client_secret",
      "access_token",
      "webhook_url",
      "store_url",
      "cnpj",
    ].forEach((key) => {
      const value = extractAfter(command, key) || extractAfter(command, key.replace("_", " "));
      if (value) values[key] = value;
    });
    return buildIntegrationConfigurePlan(providerId, values);
  }

  if (
    lower.includes("criar ia") ||
    lower.includes("nova ia") ||
    lower.includes("crie uma ia") ||
    lower.includes("adicionar ia")
  ) {
    const name = extractAfter(command, "nome") || extractAfter(command, "ia") || "Nova IA";
    const objective = extractAfter(command, "objetivo") || command;
    return {
      type: "create_ai_agent",
      title: `Criar IA: ${name}`,
      summary: `A IA Intelligence vai criar uma nova IA/agente chamada "${name}" com objetivo definido pelo ADM.`,
      risk: "alto",
      targetTable: "ai_agents",
      operation: "insert",
      payload: {
        name,
        slug: safeSlug(name),
        objective,
        status: "active",
        prompt_base: objective,
        modules: [],
        permissions: { controlled_by: "ia_intelligence", requires_admin_password: true },
      },
    };
  }

  if (
    lower.includes("editar ia") ||
    lower.includes("alterar ia") ||
    lower.includes("desativar ia") ||
    lower.includes("ativar ia")
  ) {
    const name = extractAfter(command, "nome") || extractAfter(command, "ia") || "IA existente";
    return {
      type: "update_ai_agent",
      title: `Alterar IA: ${name}`,
      summary: `A IA Intelligence vai registrar uma alteração em outra IA/agente. Revise a prévia antes de confirmar.`,
      risk: "alto",
      targetTable: "ai_agents",
      operation: "upsert",
      payload: {
        name,
        slug: safeSlug(name),
        requested_change: command,
        status: lower.includes("desativar") ? "inactive" : "active",
        updated_at: new Date().toISOString(),
      },
    };
  }

  if (
    lower.includes("imagem") ||
    lower.includes("realista") ||
    lower.includes("foto") ||
    lower.includes("render")
  ) {
    const project =
      extractAfter(command, "projeto") ||
      extractAfter(command, "modelo") ||
      "Projeto informado pelo ADM";
    return {
      type: "project_media_change",
      title: `Alterar imagens do projeto: ${project}`,
      summary:
        "A IA vai registrar uma solicitação para trocar/adicionar imagens realistas, criar backup da imagem anterior e padronizar miniaturas quando aplicável.",
      risk: "alto",
      targetTable: "project_media_changes",
      operation: "insert",
      payload: {
        project,
        command,
        media_style: lower.includes("realista") ? "realistic" : "standard",
        backup_previous: true,
        status: "pending_approval",
      },
    };
  }

  if (
    lower.includes("criar projeto") ||
    lower.includes("novo projeto") ||
    lower.includes("adicionar projeto")
  ) {
    const title =
      extractAfter(command, "nome") || extractAfter(command, "projeto") || "Projeto criado pela IA";
    return {
      type: "create_project_model",
      title: `Criar projeto: ${title}`,
      summary:
        "A IA vai criar um modelo de projeto com dados técnicos, imagem/preview e estrutura preparada para editor 2D/3D.",
      risk: "alto",
      targetTable: "project_models",
      operation: "insert",
      payload: {
        title,
        slug: safeSlug(title),
        description: command,
        active: true,
        created_by_ai: true,
        free_preview: false,
        is_premium: true,
      },
    };
  }

  if (lower.startsWith("resolver achado") || lower.includes("resolver varredura")) {
    return {
      type: "resolve_scan_finding",
      title: "Resolver problema encontrado na varredura",
      summary:
        "A IA vai aplicar a correção sugerida para um problema identificado em varredura. A ação só será executada após confirmação com senha ADM.",
      risk: "alto",
      targetTable: "ai_intelligence_scan_findings",
      operation: "insert",
      payload: { command, status: "resolution_requested" },
    };
  }

  if (lower.includes("produto") || lower.includes("cadastrar") || lower.includes("adicionar")) {
    const name =
      extractAfter(command, "nome") ||
      command
        .replace(/adicionar|cadastrar|criar|produto|novo/gi, "")
        .replace(/preço.*$/i, "")
        .replace(/estoque.*$/i, "")
        .trim()
        .slice(0, 90) ||
      "Produto criado pela IA";
    const price = extractAfter(command, "preço")
      ? extractMoney(extractAfter(command, "preço") || "")
      : extractMoney(command);
    const stockMatch = command.match(/estoque\s*[:=-]?\s*(\d+[\d.,]*)/i);
    const category = extractAfter(command, "categoria") || "Criado pela IA";
    return {
      type: "create_product",
      title: `Criar produto: ${name}`,
      summary: `A IA vai criar um produto no catálogo da empresa com nome "${name}", categoria "${category}", preço ${price ?? 0} e estoque ${stockMatch?.[1] ?? 0}.`,
      risk: "medio",
      targetTable: "company_products",
      operation: "insert",
      payload: {
        name,
        category,
        description: extractAfter(command, "descrição") || "Produto criado pela IA Intelligence.",
        code: extractAfter(command, "código") || `IA-${safeSlug(name).slice(0, 18).toUpperCase()}`,
        sku: extractAfter(command, "sku") || `SKU-${safeSlug(name).slice(0, 18).toUpperCase()}`,
        sale_price: price ?? 0,
        cost_price: Number(extractAfter(command, "custo")?.replace(",", ".") || 0),
        stock_quantity: Number((stockMatch?.[1] || "0").replace(",", ".")),
        unit: extractAfter(command, "unidade") || "un",
        status: "active",
      },
    };
  }

  if (lower.includes("estoque") || lower.includes("inventário") || lower.includes("inventario")) {
    const table = lower.includes("produto") ? "company_products" : "technical_stock_items";
    return {
      type: "adjust_stock",
      title: "Ajustar estoque / inventário",
      summary:
        "A IA vai registrar uma solicitação de ajuste de estoque/inventário. Para aplicar em massa, informe tabela, item, quantidade e motivo no modo avançado.",
      risk: "alto",
      targetTable: table,
      operation: "update",
      payload: { command, mode: "inventory_adjustment_request" },
    };
  }

  if (lower.includes("login") || lower.includes("template") || lower.includes("capa")) {
    return {
      type: "update_login_template",
      title: "Alterar template da tela de login",
      summary:
        "A IA vai salvar uma nova configuração de template para a tela de login. A versão anterior será mantida como snapshot.",
      risk: "medio",
      targetTable: "ai_system_settings",
      operation: "upsert",
      payload: {
        key: "login_template_request",
        value: { command, requested_at: new Date().toISOString() },
      },
    };
  }

  const advancedTable = extractAfter(command, "tabela");
  const advancedOp = (
    extractAfter(command, "operação") ||
    extractAfter(command, "operacao") ||
    "insert"
  ).toLowerCase();
  const jsonMatch = command.match(/json\s*[:=]\s*(\{[\s\S]*\})/i);
  if (advancedTable && jsonMatch) {
    let payload: Record<string, any> = {};
    try {
      payload = JSON.parse(jsonMatch[1]);
    } catch {
      payload = { raw: jsonMatch[1] };
    }
    return {
      type: "advanced_table_operation",
      title: `Operação avançada em ${advancedTable}`,
      summary: `A IA vai executar ${advancedOp} na tabela ${advancedTable}. Revise com cuidado antes de confirmar.`,
      risk: "critico",
      targetTable: advancedTable,
      operation: advancedOp as any,
      payload,
    };
  }

  return {
    type: "general_system_change",
    title: "Solicitação geral de alteração do sistema",
    summary:
      "A IA vai registrar esta solicitação como mudança administrativa. Ela ficará no histórico para execução técnica ou automação posterior.",
    risk: "alto",
    targetTable: "ai_intelligence_commands",
    operation: "insert",
    payload: { command, status: "requested" },
  };
}

export async function confirmAdminPassword(email: string, password: string) {
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw new Error("Senha do ADM inválida ou sessão expirada.");
  return true;
}

export async function saveIAKnowledge(userId: string, content: string) {
  const title = content.slice(0, 90) || "Conhecimento manual";
  const { data, error } = await supabase
    .from("ai_intelligence_knowledge" as any)
    .insert({
      user_id: userId,
      title,
      content,
      source: "manual_admin",
      tags: ["aprendizado", "admin"],
    })
    .select("*")
    .maybeSingle();
  if (error) throw error;
  return data;
}

async function safeSelect(table: string, select = "*", filters?: (query: any) => any) {
  try {
    let query = supabase.from(table as any).select(select);
    if (filters) query = filters(query);
    const { data, error } = await query;
    if (error) return [];
    return data || [];
  } catch {
    return [];
  }
}

function daysAgo(days: number) {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date.toISOString();
}

function numeric(value: any) {
  const parsed = Number(value ?? 0);
  return Number.isFinite(parsed) ? parsed : 0;
}

export async function runIAIntelligenceScan(
  userId: string,
  periodDays: IAScanPeriod,
): Promise<IAScanResult> {
  const since = daysAgo(periodDays);
  const findings: IAScanFinding[] = [];

  const products = await safeSelect("company_products", "*", (q) =>
    q.order("created_at", { ascending: false }),
  );
  const zeroStockProducts = products
    .filter((item: any) => numeric(item.stock_quantity ?? item.quantity ?? item.stock) <= 0)
    .slice(0, 12);
  const lowStockProducts = products
    .filter((item: any) => {
      const qty = numeric(item.stock_quantity ?? item.quantity ?? item.stock);
      const min = numeric(item.min_stock ?? item.stock_minimum ?? 0);
      return min > 0 && qty > 0 && qty <= min;
    })
    .slice(0, 12);

  if (zeroStockProducts.length > 0) {
    findings.push({
      id: crypto.randomUUID(),
      area: "estoque",
      severity: "alto",
      title: "Produtos próprios com estoque zerado",
      problem: `${zeroStockProducts.length} produto(s) estão com estoque igual a zero.`,
      cause:
        "Produtos foram cadastrados sem entrada de estoque ou foram totalmente consumidos/vendidos.",
      solution:
        "Fazer inventário parcial desses itens e registrar entrada, compra ou ajuste manual autorizado.",
      suggestedCommand:
        "Resolver achado: abrir inventário parcial dos produtos próprios com estoque zerado e solicitar quantidade conferida para ajuste.",
      evidence: {
        count: zeroStockProducts.length,
        items: zeroStockProducts.map((p: any) => p.name || p.title || p.code).filter(Boolean),
      },
      canAutoResolve: true,
    });
  }

  if (lowStockProducts.length > 0) {
    findings.push({
      id: crypto.randomUUID(),
      area: "estoque",
      severity: "medio",
      title: "Itens abaixo do estoque mínimo",
      problem: `${lowStockProducts.length} item(ns) estão abaixo ou próximos do estoque mínimo.`,
      cause: "Consumo maior que reposição ou estoque mínimo configurado sem compra programada.",
      solution: "Gerar sugestão de compra e revisar estoque mínimo por categoria.",
      suggestedCommand:
        "Resolver achado: gerar lista de compras dos itens abaixo do estoque mínimo.",
      evidence: {
        count: lowStockProducts.length,
        items: lowStockProducts.map((p: any) => p.name || p.title || p.code).filter(Boolean),
      },
      canAutoResolve: true,
    });
  }

  const technicalItems = await safeSelect("technical_stock_items", "*", (q) =>
    q.order("created_at", { ascending: false }),
  );
  const zeroTechnical = technicalItems
    .filter((item: any) => numeric(item.stock_quantity ?? item.quantity ?? item.current_stock) <= 0)
    .slice(0, 20);
  if (zeroTechnical.length > 0) {
    findings.push({
      id: crypto.randomUUID(),
      area: "estoque",
      severity: "medio",
      title: "Catálogo técnico com estoque zerado",
      problem: `${zeroTechnical.length} item(ns) técnicos aparecem cadastrados, mas com estoque zerado.`,
      cause:
        "O catálogo base foi carregado para consulta, porém o cliente ainda não informou as quantidades reais. Isso é esperado no primeiro uso.",
      solution:
        "Executar inventário inicial por setor: alumínios, vidros, ferragens e acessórios. O sistema deve pedir apenas a quantidade conferida de cada item.",
      suggestedCommand:
        "Resolver achado: iniciar inventário inicial do catálogo técnico com estoque zerado por setor.",
      evidence: { count: zeroTechnical.length },
      canAutoResolve: true,
    });
  }

  const charges = await safeSelect("charges", "*", (q) => q.gte("created_at", since));
  const overdueCharges = charges.filter(
    (c: any) =>
      c.status === "overdue" ||
      (c.due_date && new Date(c.due_date) < new Date() && c.status !== "paid"),
  );
  const pendingAmount = charges
    .filter((c: any) => ["pending", "overdue", "failed"].includes(c.status))
    .reduce((sum: number, c: any) => sum + numeric(c.amount), 0);
  if (overdueCharges.length > 0) {
    findings.push({
      id: crypto.randomUUID(),
      area: "financeiro",
      severity: "alto",
      title: "Cobranças vencidas no período",
      problem: `${overdueCharges.length} cobrança(s) vencidas encontradas nos últimos ${periodDays} dias.`,
      cause: "Pagamentos não foram baixados, clientes não pagaram ou há falha de webhook/provedor.",
      solution:
        "Enviar lembrete por WhatsApp/e-mail, revisar webhook e atualizar contas a receber.",
      suggestedCommand:
        "Resolver achado: gerar cobrança de lembrete para cobranças vencidas e atualizar painel financeiro.",
      evidence: { count: overdueCharges.length, pendingAmount },
      canAutoResolve: true,
    });
  }

  const invoices = await safeSelect("fiscal_invoices", "*", (q) => q.gte("created_at", since));
  const rejectedInvoices = invoices.filter((n: any) => ["rejected", "failed"].includes(n.status));
  if (rejectedInvoices.length > 0) {
    findings.push({
      id: crypto.randomUUID(),
      area: "fiscal",
      severity: "alto",
      title: "Notas fiscais rejeitadas ou com falha",
      problem: `${rejectedInvoices.length} nota(s) fiscal(is) rejeitada(s) ou com falha no período.`,
      cause:
        "Dados fiscais incompletos, certificado/configuração fiscal incorreta ou erro do provedor fiscal.",
      solution:
        "Abrir fila de correção fiscal, revisar erro retornado e permitir reemissão após ajuste.",
      suggestedCommand:
        "Resolver achado: abrir revisão das notas rejeitadas e preparar reemissão após correção dos dados fiscais.",
      evidence: {
        count: rejectedInvoices.length,
        errors: rejectedInvoices
          .map((n: any) => n.error_message)
          .filter(Boolean)
          .slice(0, 5),
      },
      canAutoResolve: true,
    });
  }

  const iaErrors = await safeSelect("ai_intelligence_logs", "*", (q) => q.gte("created_at", since));
  const failedIA = iaErrors.filter((log: any) => ["error", "failed"].includes(log.status));
  if (failedIA.length > 0) {
    findings.push({
      id: crypto.randomUUID(),
      area: "sistema",
      severity: "medio",
      title: "Falhas registradas na IA Intelligence",
      problem: `${failedIA.length} ação(ões) da IA falharam no período.`,
      cause:
        "Comandos incompletos, dados inválidos, permissão insuficiente ou tabela/campo inexistente.",
      solution:
        "Revisar logs, padronizar comandos e criar modelos de comando para ações repetidas.",
      suggestedCommand:
        "Resolver achado: criar modelos de comando para evitar falhas repetidas da IA Intelligence.",
      evidence: { count: failedIA.length },
      canAutoResolve: false,
    });
  }

  if (findings.length === 0) {
    findings.push({
      id: crypto.randomUUID(),
      area: "sistema",
      severity: "baixo",
      title: "Nenhum problema crítico encontrado",
      problem: `A varredura dos últimos ${periodDays} dias não encontrou falhas críticas nos módulos consultados.`,
      cause: "Sem divergências relevantes nos dados disponíveis ou módulos ainda sem movimentação.",
      solution:
        "Manter rotina de varredura e alimentar estoque, financeiro e fiscal com dados reais para análises mais precisas.",
      suggestedCommand: "Agendar nova varredura preventiva para o próximo período.",
      evidence: { periodDays },
      canAutoResolve: false,
    });
  }

  const result: IAScanResult = {
    periodDays,
    generatedAt: new Date().toISOString(),
    summary: `Varredura concluída: ${findings.length} achado(s) nos últimos ${periodDays} dias.`,
    findings,
  };

  await supabase.from("ai_intelligence_scans" as any).insert({
    user_id: userId,
    period_days: periodDays,
    summary: result.summary,
    result,
    status: "completed",
  });

  for (const finding of findings) {
    await supabase.from("ai_intelligence_scan_findings" as any).insert({
      user_id: userId,
      area: finding.area,
      severity: finding.severity,
      title: finding.title,
      problem: finding.problem,
      cause: finding.cause,
      solution: finding.solution,
      suggested_command: finding.suggestedCommand,
      evidence: finding.evidence,
      can_auto_resolve: finding.canAutoResolve,
      status: "open",
    });
  }

  return result;
}

export function buildPlanFromScanFinding(finding: IAScanFinding): IAActionPlan {
  return {
    type: "resolve_scan_finding",
    title: `Resolver: ${finding.title}`,
    summary: `${finding.problem} Causa provável: ${finding.cause} Solução proposta: ${finding.solution}`,
    risk:
      finding.severity === "critico" ? "critico" : finding.severity === "alto" ? "alto" : "medio",
    targetTable: "ai_intelligence_scan_findings",
    operation: "insert",
    payload: {
      finding,
      resolution_command: finding.suggestedCommand,
      status: "resolution_approved_pending_execution",
    },
  };
}

export async function saveIACommand(userId: string, command: string, plan: IAActionPlan) {
  const { data, error } = await supabase
    .from("ai_intelligence_commands" as any)
    .insert({ user_id: userId, command, action_type: plan.type, plan, status: "pending" })
    .select("id")
    .maybeSingle();
  if (error) throw error;
  return (data as any)?.id as string | undefined;
}

export async function executeIAAction(plan: IAActionPlan, userId: string, commandId?: string) {
  const snapshot = { plan, captured_at: new Date().toISOString() };
  await supabase
    .from("ai_intelligence_snapshots" as any)
    .insert({ command_id: commandId, user_id: userId, snapshot });

  let result: any = null;
  if (plan.type === "create_product") {
    const { data, error } = await supabase
      .from("company_products" as any)
      .insert({ owner_id: userId, ...plan.payload })
      .select("*")
      .maybeSingle();
    if (error) throw error;
    result = data;
  } else if (plan.type === "update_login_template") {
    const { data, error } = await supabase
      .from("ai_system_settings" as any)
      .upsert(
        { key: plan.payload.key, value: plan.payload.value, updated_by: userId },
        { onConflict: "key" },
      )
      .select("*")
      .maybeSingle();
    if (error) throw error;
    result = data;
  } else if (plan.type === "create_ai_agent") {
    const { data, error } = await supabase
      .from("ai_agents" as any)
      .insert({ owner_id: userId, ...plan.payload })
      .select("*")
      .maybeSingle();
    if (error) throw error;
    result = data;
  } else if (plan.type === "update_ai_agent") {
    const { data, error } = await supabase
      .from("ai_agents" as any)
      .upsert({ owner_id: userId, ...plan.payload }, { onConflict: "owner_id,slug" })
      .select("*")
      .maybeSingle();
    if (error) throw error;
    result = data;
  } else if (plan.type === "project_media_change") {
    const { data, error } = await supabase
      .from("project_media_changes" as any)
      .insert({ user_id: userId, ...plan.payload })
      .select("*")
      .maybeSingle();
    if (error) throw error;
    result = data;
  } else if (plan.type === "create_project_model") {
    const { data, error } = await supabase
      .from("project_models")
      .insert(plan.payload)
      .select("*")
      .maybeSingle();
    if (error) throw error;
    result = data;
  } else if (plan.type === "guided_workflow") {
    const { data, error } = await supabase
      .from("ai_guided_workflows" as any)
      .insert({ user_id: userId, ...plan.payload, status: "opened" })
      .select("*")
      .maybeSingle();
    if (error) throw error;
    result = data;
  } else if (plan.type === "configure_integration") {
    const { data, error } = await supabase
      .from("integration_connections" as any)
      .upsert(
        { user_id: userId, ...plan.payload, updated_at: new Date().toISOString() },
        { onConflict: "user_id,provider_id" },
      )
      .select("*")
      .maybeSingle();
    if (error) throw error;
    result = data;
  } else if (plan.type === "sync_integration") {
    const { data, error } = await supabase
      .from("integration_sync_jobs" as any)
      .insert({ user_id: userId, ...plan.payload })
      .select("*")
      .maybeSingle();
    if (error) throw error;
    result = data;
  } else if (plan.type === "diagnose_integration") {
    const { data, error } = await supabase
      .from("integration_diagnostics" as any)
      .insert({ user_id: userId, result: plan.payload, status: "queued", summary: plan.summary })
      .select("*")
      .maybeSingle();
    if (error) throw error;
    result = data;
  } else if (plan.type === "fix_integration") {
    const { data, error } = await supabase
      .from("integration_repair_jobs" as any)
      .insert({ user_id: userId, ...plan.payload })
      .select("*")
      .maybeSingle();
    if (error) throw error;
    result = data;
  } else if (plan.type === "resolve_scan_finding") {
    const { data, error } = await supabase
      .from("ai_intelligence_logs" as any)
      .insert({
        user_id: userId,
        action_type: plan.type,
        action_summary: plan.summary,
        before_data: snapshot,
        after_data: plan.payload,
        status: "resolution_registered",
      })
      .select("*")
      .maybeSingle();
    if (error) throw error;
    result = data;
  } else if (plan.type === "advanced_table_operation" && plan.targetTable) {
    const table = plan.targetTable as any;
    if (plan.operation === "delete") {
      const id = plan.payload.id;
      if (!id) throw new Error("Para deletar, informe id no JSON.");
      const { data, error } = await supabase.from(table).delete().eq("id", id).select("*");
      if (error) throw error;
      result = data;
    } else if (plan.operation === "update") {
      const id = plan.payload.id;
      if (!id) throw new Error("Para atualizar, informe id no JSON.");
      const { id: _id, ...payload } = plan.payload;
      const { data, error } = await supabase.from(table).update(payload).eq("id", id).select("*");
      if (error) throw error;
      result = data;
    } else if (plan.operation === "upsert") {
      const { data, error } = await supabase.from(table).upsert(plan.payload).select("*");
      if (error) throw error;
      result = data;
    } else {
      const { data, error } = await supabase.from(table).insert(plan.payload).select("*");
      if (error) throw error;
      result = data;
    }
  } else {
    const { data, error } = await supabase
      .from("ai_intelligence_logs" as any)
      .insert({
        user_id: userId,
        action_type: plan.type,
        action_summary: plan.summary,
        before_data: {},
        after_data: plan.payload,
        status: "registered",
      })
      .select("*")
      .maybeSingle();
    if (error) throw error;
    result = data;
  }

  await supabase.from("ai_intelligence_logs" as any).insert({
    command_id: commandId,
    user_id: userId,
    action_type: plan.type,
    action_summary: plan.summary,
    before_data: snapshot,
    after_data: result ?? {},
    status: "executed",
  });
  if (commandId)
    await supabase
      .from("ai_intelligence_commands" as any)
      .update({ status: "executed", executed_at: new Date().toISOString() })
      .eq("id", commandId);
  return result;
}
