import jsPDF from "jspdf";
import { brl, num } from "./format";
import {
  loadQuoteCompany,
  composeAddress,
  formatDoc,
  formatPhone,
  docLabel,
  joinParts,
  type CompanyHeaderData,
} from "./quote-company-pdf";
import type { SaleDocument } from "@/hooks/use-sales";

/**
 * "Nota simples" da Venda direta — jsPDF, mesmo caminho já provado do
 * `quote-pdf.ts` (Revisões 60 e 78: PDF gerado e baixado por clique real).
 *
 * ────────────────────────────────────────────────────────────────────────────
 * POR QUE PDF, E NÃO `window.print()`
 * ────────────────────────────────────────────────────────────────────────────
 * A tela antiga finalizava a venda com `window.print()`. A Revisão 79 mediu o
 * que isso produz: **não existe nenhum `@media print` neste arquivo nem no CSS
 * do projeto**, então a impressora recebia a aplicação inteira, menu lateral
 * incluído. Inventar CSS de impressão do zero seria mais trabalho e menos
 * previsível do que reusar o gerador que já funciona.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * A REGRA QUE ESTE ARQUIVO EXISTE PARA GARANTIR
 * ────────────────────────────────────────────────────────────────────────────
 * Todo número impresso aqui vem de `SaleDocument`, que é LIDO DO BANCO depois
 * do commit da RPC — nunca do formulário. `numero`, `m2`, `subtotal`, `total` e
 * `quantidade_baixa` só existem porque o banco os calculou. Uma venda que
 * falhou não chega até aqui, então **não há como sair nota de venda que não
 * aconteceu**.
 *
 * ⚠️ NÃO É DOCUMENTO FISCAL, e o rodapé diz isso na folha. A integração fiscal
 * do projeto é simulada (P-05); emitir algo com cara de nota fiscal seria a
 * mesma promessa vazia que as Revisões 37-44 tiraram do Dashboard.
 */

const MARGEM = 14;
const RODAPE = 12;

// Colunas (mm) — somam os 182 mm úteis do A4, mesma medida do quote-pdf.
const COL_DESC = 72;
const COL_MED = 34;
const COL_QTD = 18;
const COL_UNIT = 28;
const COL_SUB = 30;

const PAGAMENTO_LABEL: Record<string, string> = {
  pix: "Pix",
  dinheiro: "Dinheiro",
  cartao: "Cartão",
  boleto: "Boleto",
  parcelado: "Parcelado",
  outro: "Outro",
};

const UNIDADE_LABEL: Record<string, string> = {
  m: "m",
  m2: "m²",
  un: "un",
  kg: "kg",
  pc: "pç",
  cx: "cx",
};

function colunas(x: number) {
  return {
    desc: x + 2,
    med: x + COL_DESC + COL_MED - 2,
    qtd: x + COL_DESC + COL_MED + COL_QTD - 2,
    unit: x + COL_DESC + COL_MED + COL_QTD + COL_UNIT - 2,
    sub: x + COL_DESC + COL_MED + COL_QTD + COL_UNIT + COL_SUB - 2,
  };
}

/**
 * Medida da linha. Item em m² imprime L × A em metros — que é a unidade em que
 * o banco guardou (a tela digita em milímetros e converte no envio).
 */
function medida(item: SaleDocument["items"][number]): string {
  const l = Number(item.largura) || 0;
  const a = Number(item.altura) || 0;
  if (l > 0 && a > 0) return `${num(l, 3)} × ${num(a, 3)} m`;
  return "-";
}

/** Quantidade cobrada: área total para m², peças para o resto. */
function quantidadeCobrada(item: SaleDocument["items"][number]): string {
  const un = UNIDADE_LABEL[item.unidade] ?? item.unidade;
  if (item.unidade === "m2") return `${num(Number(item.m2) || 0, 4)} m²`;
  return `${num(Number(item.quantidade) || 0, 2)} ${un}`;
}

function drawTableHeader(doc: jsPDF, x: number, y: number): number {
  const h = 8;
  const c = colunas(x);
  doc.setFillColor(15, 27, 45);
  doc.rect(x, y, COL_DESC + COL_MED + COL_QTD + COL_UNIT + COL_SUB, h, "F");
  doc.setTextColor(232, 168, 56);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.text("Descrição", c.desc, y + 5.5);
  doc.text("Medida", c.med, y + 5.5, { align: "right" });
  doc.text("Qtd", c.qtd, y + 5.5, { align: "right" });
  doc.text("Preço unit.", c.unit, y + 5.5, { align: "right" });
  doc.text("Subtotal", c.sub, y + 5.5, { align: "right" });
  return y + h;
}

function drawCompanyHeader(
  doc: jsPDF,
  sale: SaleDocument["sale"],
  dados: CompanyHeaderData,
  W: number,
): number {
  const empresa = dados.company;
  const alturaFaixa = 32;

  doc.setFillColor(15, 27, 45);
  doc.rect(0, 0, W, alturaFaixa, "F");

  let xTexto = MARGEM;
  if (dados.logo) {
    const escala = Math.min(26 / dados.logo.width, 20 / dados.logo.height);
    const w = dados.logo.width * escala;
    const h = dados.logo.height * escala;
    try {
      doc.addImage(dados.logo.dataUrl, MARGEM, (alturaFaixa - h) / 2, w, h, undefined, "FAST");
      xTexto = MARGEM + w + 5;
    } catch (err) {
      // Logo inválido não derruba o documento — mesma degradação do quote-pdf.
      console.error("Não foi possível inserir o logotipo na nota.", err);
    }
  }

  const nome = (empresa?.company_name ?? "").trim();
  doc.setTextColor(232, 168, 56);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(nome.length > 34 ? 13 : 16);
  doc.text(nome || "Venda", xTexto, 12);

  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  let yInfo = 18;
  const cnpj = formatDoc(empresa?.cnpj);
  if (cnpj) {
    doc.text(`${docLabel(empresa?.cnpj)}: ${cnpj}`, xTexto, yInfo);
    yInfo += 4;
  }
  const endereco = composeAddress(empresa?.address, empresa?.city, empresa?.state);
  if (endereco) {
    doc.text(endereco, xTexto, yInfo);
    yInfo += 4;
  }
  const contato = joinParts([empresa?.email, formatPhone(empresa?.phone)]);
  if (contato) doc.text(contato, xTexto, yInfo);

  // Faixa da venda — número, data e forma de pagamento, todos do banco.
  const yFaixa = alturaFaixa + 4;
  doc.setFillColor(240, 242, 246);
  doc.setDrawColor(210, 214, 220);
  doc.setLineWidth(0.2);
  doc.rect(MARGEM, yFaixa, W - MARGEM * 2, 11, "FD");

  const criado = new Date(sale.created_at);
  const campos: Array<[string, string]> = [
    ["VENDA Nº", String(sale.numero)],
    ["DATA", criado.toLocaleDateString("pt-BR")],
    ["HORA", criado.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })],
    ["PAGAMENTO", (PAGAMENTO_LABEL[sale.forma_pagamento] ?? sale.forma_pagamento).toUpperCase()],
  ];

  const largura = (W - MARGEM * 2) / campos.length;
  campos.forEach(([rotulo, valor], idx) => {
    const cx = MARGEM + largura * idx + 3;
    doc.setTextColor(120, 126, 136);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(6.5);
    doc.text(rotulo, cx, yFaixa + 4);
    doc.setTextColor(20, 24, 32);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.text(valor, cx, yFaixa + 8.6);
  });

  return yFaixa + 11;
}

/**
 * Gera e baixa a nota simples da venda.
 *
 * `empresaPreCarregada` existe para teste; em produção a empresa vem de
 * `sale.company_id` — a empresa DONA da venda, nunca a ativa no momento, pelo
 * mesmo motivo que o `quote-pdf.ts` documenta.
 */
export async function generateSalePdf(
  documento: SaleDocument,
  empresaPreCarregada?: CompanyHeaderData,
): Promise<void> {
  const { sale, items, customer } = documento;
  const dadosEmpresa = empresaPreCarregada ?? (await loadQuoteCompany(sale.company_id));

  const doc = new jsPDF();
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const larguraUtil = W - MARGEM * 2;
  const limiteY = H - RODAPE;

  let y = drawCompanyHeader(doc, sale, dadosEmpresa, W);

  // ---- Cliente. Venda avulsa é caso NORMAL aqui: `customer_id` é opcional na
  // migration, e a tela permite vender sem cadastro. Sem cliente, o bloco diz
  // "Consumidor não identificado" em vez de imprimir um vazio sem explicação.
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  doc.text("CLIENTE", MARGEM, y + 8);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  const nomeCliente = customer?.nome ?? sale.cliente_nome ?? "Consumidor não identificado";
  doc.text(nomeCliente, MARGEM, y + 14);
  y += 19;

  if (customer) {
    doc.setFontSize(9);
    doc.setTextColor(80, 80, 80);
    const docCli = formatDoc(customer.documento);
    const meta = joinParts([
      docCli ? `${docLabel(customer.documento)}: ${docCli}` : null,
      formatPhone(customer.telefone),
      customer.email,
    ]);
    if (meta) {
      doc.text(meta, MARGEM, y);
      y += 5;
    }
    const end = composeAddress(customer.endereco, customer.cidade, null);
    if (end) {
      doc.text(end, MARGEM, y);
      y += 5;
    }
  }

  // ---- Itens
  y += 4;
  y = drawTableHeader(doc, MARGEM, y);
  doc.setTextColor(0, 0, 0);

  const c = colunas(MARGEM);
  for (const item of items) {
    const linhas = doc.splitTextToSize(item.descricao, COL_DESC - 4) as string[];
    const alturaLinha = Math.max(7, linhas.length * 4.2 + 2.8);

    if (y + alturaLinha > limiteY) {
      doc.addPage();
      y = MARGEM;
      y = drawTableHeader(doc, MARGEM, y);
      doc.setTextColor(0, 0, 0);
    }

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    doc.text(linhas, c.desc, y + 5);
    doc.text(medida(item), c.med, y + 5, { align: "right" });
    doc.text(quantidadeCobrada(item), c.qtd, y + 5, { align: "right" });
    doc.text(brl(Number(item.preco_unit) || 0), c.unit, y + 5, { align: "right" });
    doc.setFont("helvetica", "bold");
    doc.text(brl(Number(item.subtotal) || 0), c.sub, y + 5, { align: "right" });

    // Desconto da linha vira uma segunda linha só quando existe — nada de
    // "Desconto: R$ 0,00" ocupando espaço em toda venda.
    const dsc = Number(item.desconto) || 0;
    if (dsc > 0) {
      doc.setFont("helvetica", "normal");
      doc.setFontSize(7.5);
      doc.setTextColor(120, 120, 120);
      doc.text(`desconto ${brl(dsc)}`, c.med, y + 5 + linhas.length * 4.2, { align: "right" });
      doc.setTextColor(0, 0, 0);
    }

    y += alturaLinha;
    doc.setDrawColor(225, 228, 233);
    doc.setLineWidth(0.1);
    doc.line(MARGEM, y, MARGEM + larguraUtil, y);
  }

  // ---- Totais
  y += 8;
  if (y + 30 > limiteY) {
    doc.addPage();
    y = MARGEM;
  }

  const xRot = MARGEM + larguraUtil - 70;
  const xVal = MARGEM + larguraUtil;
  const linhaTotal = (rotulo: string, valor: string, forte = false) => {
    doc.setFont("helvetica", forte ? "bold" : "normal");
    doc.setFontSize(forte ? 12 : 9.5);
    doc.setTextColor(forte ? 15 : 90, forte ? 27 : 95, forte ? 45 : 105);
    doc.text(rotulo, xRot, y);
    doc.setTextColor(forte ? 15 : 30, forte ? 27 : 34, forte ? 45 : 42);
    doc.text(valor, xVal, y, { align: "right" });
    y += forte ? 8 : 5.5;
  };

  linhaTotal("Subtotal", brl(Number(sale.subtotal) || 0));
  if (Number(sale.desconto) > 0) linhaTotal("Desconto", `- ${brl(Number(sale.desconto))}`);
  if (Number(sale.acrescimo) > 0) linhaTotal("Acréscimo", brl(Number(sale.acrescimo)));
  linhaTotal("TOTAL", brl(Number(sale.total) || 0), true);

  // ---- Observações. Só entra porque tem leitor — a coluna existe na migration
  // exatamente sob essa condição (comentário de `sales.observacoes`).
  if (sale.observacoes && sale.observacoes.trim()) {
    const linhas = doc.splitTextToSize(sale.observacoes.trim(), larguraUtil) as string[];
    if (y + 10 + linhas.length * 4.5 > limiteY) {
      doc.addPage();
      y = MARGEM;
    }
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(0, 0, 0);
    doc.text("Observações", MARGEM, y);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(60, 60, 60);
    doc.text(linhas, MARGEM, y + 6);
    y += 6 + linhas.length * 4.5;
  }

  // ---- Rodapé de todas as páginas: o aviso fiscal e a paginação.
  const paginas = doc.getNumberOfPages();
  for (let p = 1; p <= paginas; p++) {
    doc.setPage(p);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7.5);
    doc.setTextColor(130, 134, 142);
    doc.text("Documento sem valor fiscal — comprovante simples de venda.", MARGEM, H - RODAPE + 5);
    doc.text(`Página ${p} de ${paginas}`, MARGEM + larguraUtil, H - RODAPE + 5, {
      align: "right",
    });
  }

  doc.save(`venda-${sale.numero}.pdf`);
}
