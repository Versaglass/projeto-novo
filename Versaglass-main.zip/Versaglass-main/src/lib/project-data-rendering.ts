// =====================================================================
// Geometria PURA do desenho paramétrico.
//
// Calcula limites, escala e posições em coordenadas de tela a partir de um
// `ProjectDataV1`. É o único lugar onde essa matemática existe: o preview em
// SVG (`ProjectDataPreview.tsx`) e o desenho no PDF (`project-data-pdf.ts`)
// consomem exatamente os mesmos números, então os dois não podem divergir.
//
// Sem React, sem jsPDF, sem DOM, sem acesso a rede. Nada aqui altera o
// `project_data` recebido.
//
// POR QUE NÃO BASTA `largura` × `altura`
//   O editor posiciona peças FORA do retângulo principal: no estado inicial de
//   vidraçaria o perfil superior fica em `y: -45` e o inferior em
//   `y: altura + 10`. Escalar só pelas dimensões gerais — que é o que o editor
//   faz — corta essas peças. Aqui os limites são a UNIÃO do retângulo do
//   projeto com o retângulo de cada peça.
// =====================================================================

import type { PecaV1, ProjectData, TipoPeca } from "@/types/project-data";

export type Limites = { minX: number; minY: number; maxX: number; maxY: number };

export type PecaPosicionada = {
  peca: PecaV1;
  /** Coordenadas já no espaço do viewport (px no SVG, mm no PDF). */
  x: number;
  y: number;
  largura: number;
  altura: number;
  /** Centro, para rótulos e para o círculo do furo. */
  cx: number;
  cy: number;
};

export type Layout = {
  /** Tamanho do viewport efetivamente ocupado, já com margens. */
  largura: number;
  altura: number;
  escala: number;
  limites: Limites;
  /** Retângulo do projeto (0,0 → largura,altura do desenho) no viewport. */
  projeto: { x: number; y: number; largura: number; altura: number };
  pecas: PecaPosicionada[];
};

const finito = (n: unknown): n is number => typeof n === "number" && Number.isFinite(n);

/**
 * União do retângulo do projeto com o de todas as peças.
 *
 * Peças com número não finito são IGNORADAS no cálculo — uma única coordenada
 * inválida arrastaria a escala para o infinito e o desenho inteiro sumiria.
 */
export function calcularLimites(dados: ProjectData): Limites {
  let minX = 0;
  let minY = 0;
  let maxX = finito(dados.largura) ? dados.largura : 0;
  let maxY = finito(dados.altura) ? dados.altura : 0;

  for (const p of dados.pecas) {
    if (!finito(p.x) || !finito(p.y) || !finito(p.largura) || !finito(p.altura)) continue;
    minX = Math.min(minX, p.x);
    minY = Math.min(minY, p.y);
    maxX = Math.max(maxX, p.x + p.largura);
    maxY = Math.max(maxY, p.y + p.altura);
  }

  // Projeto degenerado (tudo zero) ainda precisa de área > 0 para não dividir
  // por zero na escala.
  if (maxX <= minX) maxX = minX + 1;
  if (maxY <= minY) maxY = minY + 1;
  return { minX, minY, maxX, maxY };
}

export type OpcoesLayout = {
  /** Espaço disponível, na unidade do destino (px para SVG, mm para PDF). */
  larguraMax: number;
  alturaMax: number;
  /** Margem interna, na mesma unidade do destino. */
  margem?: number;
};

/**
 * Transforma o desenho para caber no espaço disponível PRESERVANDO A PROPORÇÃO.
 *
 * A escala é a menor entre as duas razões, de modo que o conteúdo cabe nos dois
 * eixos; o restante vira espaço vazio, nunca corte nem distorção. O ponto
 * (minX, minY) — que pode ser negativo — vai para o canto da margem, e é isso
 * que garante que a peça acima da origem apareça inteira.
 */
export function calcularLayout(dados: ProjectData, opcoes: OpcoesLayout): Layout {
  const margem = opcoes.margem ?? 0;
  const limites = calcularLimites(dados);
  const larguraConteudo = limites.maxX - limites.minX;
  const alturaConteudo = limites.maxY - limites.minY;

  const dispX = Math.max(1, opcoes.larguraMax - margem * 2);
  const dispY = Math.max(1, opcoes.alturaMax - margem * 2);
  const escala = Math.min(dispX / larguraConteudo, dispY / alturaConteudo);

  const paraViewport = (x: number, y: number) => ({
    x: margem + (x - limites.minX) * escala,
    y: margem + (y - limites.minY) * escala,
  });

  const pecas: PecaPosicionada[] = [];
  for (const p of dados.pecas) {
    if (!finito(p.x) || !finito(p.y) || !finito(p.largura) || !finito(p.altura)) continue;
    const canto = paraViewport(p.x, p.y);
    const largura = p.largura * escala;
    const altura = p.altura * escala;
    pecas.push({
      peca: p,
      x: canto.x,
      y: canto.y,
      largura,
      altura,
      cx: canto.x + largura / 2,
      cy: canto.y + altura / 2,
    });
  }

  const cantoProjeto = paraViewport(0, 0);
  return {
    largura: larguraConteudo * escala + margem * 2,
    altura: alturaConteudo * escala + margem * 2,
    escala,
    limites,
    projeto: {
      x: cantoProjeto.x,
      y: cantoProjeto.y,
      largura: (finito(dados.largura) ? dados.largura : 0) * escala,
      altura: (finito(dados.altura) ? dados.altura : 0) * escala,
    },
    pecas,
  };
}

// ---------------------------------------------------------------------
// Aparência por tipo de peça.
//
// Um lugar só, consumido pelo SVG e pelo PDF, para que os dois desenhos sejam
// reconhecíveis como o mesmo projeto.
//
// A distinção NUNCA depende só de cor: cada tipo tem também traço próprio
// (cheio, tracejado, círculo) e um rótulo curto, para continuar legível em
// impressão monocromática e para quem não distingue cores.
// ---------------------------------------------------------------------
export type FormaPeca = "retangulo" | "circulo" | "vazado" | "texto";

export type EstiloPeca = {
  forma: FormaPeca;
  /** Preenchimento padrão quando a peça não traz cor válida. */
  preenchimento: string;
  contorno: string;
  /** Traço tracejado (recorte) — `null` = linha cheia. */
  tracejado: [number, number] | null;
  opacidade: number;
  /** Sigla impressa quando não há espaço para o nome. */
  sigla: string;
};

const ESTILOS: Record<TipoPeca, EstiloPeca> = {
  vidro: {
    forma: "retangulo",
    preenchimento: "#cfe6e3",
    contorno: "#0f172a",
    tracejado: null,
    opacidade: 0.55,
    sigla: "V",
  },
  perfil: {
    forma: "retangulo",
    preenchimento: "#94a3b8",
    contorno: "#0f172a",
    tracejado: null,
    opacidade: 0.95,
    sigla: "P",
  },
  ferragem: {
    forma: "retangulo",
    preenchimento: "#475569",
    contorno: "#0f172a",
    tracejado: null,
    opacidade: 0.95,
    sigla: "F",
  },
  recorte: {
    forma: "vazado",
    preenchimento: "#ffffff",
    contorno: "#ea580c",
    tracejado: [6, 4],
    opacidade: 0.25,
    sigla: "R",
  },
  furo: {
    forma: "circulo",
    preenchimento: "#ffffff",
    contorno: "#15803d",
    tracejado: null,
    opacidade: 1,
    sigla: "○",
  },
  mdf: {
    forma: "retangulo",
    preenchimento: "#d6a55d",
    contorno: "#7c4a15",
    tracejado: null,
    opacidade: 0.9,
    sigla: "M",
  },
  pedra: {
    forma: "retangulo",
    preenchimento: "#a8a29e",
    contorno: "#57534e",
    tracejado: null,
    opacidade: 0.9,
    sigla: "PD",
  },
  aco: {
    forma: "retangulo",
    preenchimento: "#64748b",
    contorno: "#0f172a",
    tracejado: null,
    opacidade: 0.95,
    sigla: "A",
  },
  texto: {
    forma: "texto",
    preenchimento: "transparent",
    contorno: "#0f172a",
    tracejado: null,
    opacidade: 1,
    sigla: "T",
  },
};

export function estiloDaPeca(tipo: TipoPeca): EstiloPeca {
  return ESTILOS[tipo] ?? ESTILOS.vidro;
}

/** `#rgb`/`#rrggbb` apenas. Qualquer outra coisa cai no padrão do tipo. */
export function corValida(cor: unknown): string | null {
  if (typeof cor !== "string") return null;
  return /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(cor.trim()) ? cor.trim() : null;
}

export function preenchimentoDaPeca(p: PecaV1): string {
  const estilo = estiloDaPeca(p.tipo);
  if (estilo.forma === "vazado" || estilo.forma === "texto") return estilo.preenchimento;
  return corValida(p.cor) ?? estilo.preenchimento;
}

/**
 * Rótulo da peça, já truncado para o espaço disponível.
 *
 * Devolve `null` quando não há espaço nem para a sigla — melhor nada do que
 * texto derramando por cima da peça vizinha. Nenhuma interpretação de HTML: o
 * valor é sempre tratado como texto puro por quem desenha.
 */
export function rotuloDaPeca(
  p: PecaV1,
  larguraDisponivel: number,
  alturaDisponivel: number,
  larguraPorCaractere: number,
): string | null {
  if (alturaDisponivel < larguraPorCaractere * 1.2) return null;
  const cabe = Math.floor(larguraDisponivel / Math.max(0.1, larguraPorCaractere));
  if (cabe < 2) return null;
  const nome = (p.nome ?? "").trim();
  const base = p.qtd > 1 ? `${nome} (${p.qtd}x)` : nome;
  if (!base) return null;
  if (base.length <= cabe) return base;
  if (cabe < 4) return estiloDaPeca(p.tipo).sigla;
  return `${base.slice(0, cabe - 1)}…`;
}

/** Resumo textual do desenho, para legenda do preview e do PDF. */
export function resumoDoDesenho(dados: ProjectData): string {
  const n = dados.pecas.length;
  const medidas = `${Math.round(dados.largura)} × ${Math.round(dados.altura)} mm`;
  return `${medidas} · ${n} ${n === 1 ? "componente" : "componentes"}`;
}

/**
 * As medidas comerciais do item batem com as do desenho?
 *
 * Pelo fluxo normal batem sempre — alterar medida remove o snapshot. Serve para
 * dados antigos ou inconsistentes, que devem ser SINALIZADOS, nunca corrigidos
 * automaticamente. Compara em milímetros com 1 mm de tolerância.
 */
export function medidasDivergem(dados: ProjectData, larguraMm: number, alturaMm: number): boolean {
  if (!finito(larguraMm) || !finito(alturaMm)) return false;
  if (larguraMm <= 0 || alturaMm <= 0) return false;
  return Math.abs(dados.largura - larguraMm) > 1 || Math.abs(dados.altura - alturaMm) > 1;
}
