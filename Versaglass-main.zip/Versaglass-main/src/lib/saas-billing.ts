import type { Database } from "@/integrations/supabase/types";

export type SaasPlanSlug = "basic" | "premium";

export type SaasPlan = Database["public"]["Tables"]["saas_plans"]["Row"];

export type CompanySubscription = Database["public"]["Tables"]["company_subscriptions"]["Row"];

export type CompanySubscriptionStatus = CompanySubscription["status"];

export const SAAS_STATUS_LABELS: Record<string, string> = {
  pending: "Aguardando pagamento",
  active: "Ativa",
  past_due: "Pagamento pendente",
  suspended: "Suspensa",
  canceled: "Cancelada",
};

export function formatSaasPrice(value: number): string {
  return value.toFixed(2).replace(".", ",");
}

export function isSaasPlanSlug(value: string): value is SaasPlanSlug {
  return value === "basic" || value === "premium";
}
