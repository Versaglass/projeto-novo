import { redirect } from "@tanstack/react-router";

/**
 * Rotas ocultas por decisão do usuário (Revisão 227).
 *
 * O menu não lista mais estes caminhos; quem acessar por URL direta, favorito
 * ou link legado cai no Dashboard com toast. Os arquivos de rota permanecem no
 * repositório para reativação futura — mesmo espírito da tela D congelada
 * (Revisões 113–117).
 */
export const HIDDEN_ROUTE_TOAST_KEY = "vmm_hidden_route_toast";
export const HIDDEN_ROUTE_TOAST_MESSAGE = "Página indisponível";

export function queueHiddenRouteToast(message = HIDDEN_ROUTE_TOAST_MESSAGE) {
  if (typeof sessionStorage === "undefined") return;
  sessionStorage.setItem(HIDDEN_ROUTE_TOAST_KEY, message);
}

export function consumeHiddenRouteToast(): string | null {
  if (typeof sessionStorage === "undefined") return null;
  const msg = sessionStorage.getItem(HIDDEN_ROUTE_TOAST_KEY);
  if (msg) sessionStorage.removeItem(HIDDEN_ROUTE_TOAST_KEY);
  return msg;
}

/** `beforeLoad` compartilhado: redireciona para `/app` antes de montar a página. */
export function hiddenRouteBeforeLoad() {
  queueHiddenRouteToast();
  throw redirect({ to: "/app", replace: true });
}
