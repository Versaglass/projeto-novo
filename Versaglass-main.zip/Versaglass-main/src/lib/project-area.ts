// =====================================================================
// ÁREA do modelo técnico — a classificação principal da Biblioteca.
//
// Espelha o enum `public.project_area` (migration 20260727090000 +
// 20260903150000). Os identificadores aqui são os MESMOS valores do banco,
// na mesma grafia: é essa igualdade que permite comparar
// `project_templates.area` com `project_data.area` sem tradução no meio.
//
// ÁREA ≠ CATEGORIA. São dois eixos independentes:
//
//   área      → vidraçaria | esquadrias | serralheria | marcenaria | marmoraria
//               (o SEGMENTO do trabalho; decide card, filtro e paleta)
//   categoria → vidro_comum | temperado | espelho | refletivo | organico |
//               canelado | esquadria
//               (`public.project_category`, o MATERIAL do produto de vidraçaria)
//
// Este módulo não importa nada de propósito: ele é a base de onde
// `types/project-data.ts` e os hooks partem, e um import de volta criaria ciclo.
// =====================================================================

/** Valores de `public.project_area`, na ordem em que aparecem na tela. */
export const AREAS_PROJETO = [
  "vidracaria",
  "esquadrias",
  "serralheria",
  "marcenaria",
  "marmoraria",
] as const;

export type AreaProjeto = (typeof AREAS_PROJETO)[number];

/**
 * Áreas da superfície operacional atual (criação / seleção de projetos e itens).
 * Serralheria / Marcenaria / Marmoraria seguem no enum histórico para leitura
 * de dados antigos, mas fora desta lista.
 */
export const AREAS_OPERACIONAIS = ["vidracaria", "esquadrias"] as const;
export type AreaOperacional = (typeof AREAS_OPERACIONAIS)[number];

export function ehAreaOperacional(valor: unknown): valor is AreaOperacional {
  return typeof valor === "string" && (AREAS_OPERACIONAIS as readonly string[]).includes(valor);
}

/**
 * Áreas opcionais controláveis pelo Super Admin (visibilidade no modal
 * "Novo projeto"). Vidraçaria é sempre visível e não entra aqui.
 */
export const AREAS_OPCIONAIS = [
  "esquadrias",
  "serralheria",
  "marcenaria",
  "marmoraria",
] as const satisfies readonly AreaProjeto[];

export type AreaOpcional = (typeof AREAS_OPCIONAIS)[number];

/**
 * Rótulos de tela. "Serralheria de aço" é o que o usuário lê; `serralheria` é o
 * que o banco guarda — rótulo é da interface, identificador é do dado.
 */
export const ROTULO_AREA: Record<AreaProjeto, string> = {
  vidracaria: "Vidraçaria",
  esquadrias: "Esquadrias",
  serralheria: "Serralheria de aço",
  marcenaria: "Marcenaria",
  marmoraria: "Marmoraria",
};

/**
 * Identificador ANTIGO da serralheria, usado pelo editor antes do enum existir.
 *
 * Continua sendo aceito NA LEITURA porque ele pode estar em dois lugares fora
 * do alcance da migration: no `localStorage` de quem tem rascunho de desenho em
 * aberto, e em arquivos exportados pelo botão "Exportar". Recusá-lo faria o
 * rascunho ser descartado como "formato irreconhecível". Na ESCRITA nunca é
 * emitido — tudo o que sai daqui já sai canônico.
 */
const ALIAS_LEGADO: Record<string, AreaProjeto> = {
  serralheria_aco: "serralheria",
};

/** Confere se o valor é um dos identificadores canônicos. */
export function ehAreaProjeto(valor: unknown): valor is AreaProjeto {
  return typeof valor === "string" && (AREAS_PROJETO as readonly string[]).includes(valor);
}

/**
 * Valor desconhecido → área canônica, ou `null` quando não há tradução.
 *
 * Devolve `null` em vez de um padrão: uma área errada entrega a caixa de
 * ferramentas errada, e é melhor a tela avisar do que abrir a paleta de
 * vidraçaria num armário de MDF.
 */
export function normalizaArea(valor: unknown): AreaProjeto | null {
  if (ehAreaProjeto(valor)) return valor;
  if (typeof valor === "string" && valor in ALIAS_LEGADO) return ALIAS_LEGADO[valor];
  return null;
}

/**
 * PONTE PARA MODELOS LEGADOS — categoria → área, só onde é determinístico.
 *
 * Depois da migration 20260727090000 a coluna `area` é NOT NULL e esta função
 * não decide mais nada no fluxo normal: quem manda é `template.area`. Ela
 * permanece para o intervalo em que uma tela ainda pode receber um modelo sem
 * área (base antiga, cache de consulta anterior à migration).
 *
 *   vidro_comum | temperado | espelho | refletivo | organico | canelado
 *                                       → vidracaria  (determinístico: materiais
 *                                         de vidro só existem lá)
 *   esquadria                         → null        (AMBÍGUO)
 *
 * `esquadria` é rotulada "Esquadria / outros" e serve serralheria, marcenaria,
 * marmoraria e também a esquadria de alumínio. Não há como separá-las pelo que
 * está gravado — `tipo` e `nome` são texto livre — então a resposta é `null` e
 * quem chama PERGUNTA, em vez de chutar.
 */
export function areaDaCategoria(categoria: string): AreaProjeto | null {
  if (
    categoria === "vidro_comum" ||
    categoria === "temperado" ||
    categoria === "espelho" ||
    categoria === "refletivo" ||
    categoria === "organico" ||
    categoria === "canelado"
  ) {
    return "vidracaria";
  }
  return null;
}
