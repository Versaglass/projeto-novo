export type AiTemplate = {
  title: string;
  description: string;
  prompt: string;
};

export const AI_TEMPLATES: AiTemplate[] = [
  {
    title: "Descrição de produto",
    description: "Gera descrição comercial, SEO e técnica para vidros, alumínios e ferragens.",
    prompt:
      "Crie uma descrição profissional para o produto {produto}, com aplicação, medidas, benefícios, palavras-chave SEO e chamada para orçamento.",
  },
  {
    title: "SKU inteligente",
    description: "Cria SKU padronizado por categoria, medida, cor e fornecedor.",
    prompt:
      "Gere um SKU curto para {categoria}, código {codigo}, medida {medida}, cor {cor}. Use somente letras, números e hífen.",
  },
  {
    title: "Anúncio que converte",
    description: "Cria texto para Instagram, TikTok, Google Ads e WhatsApp.",
    prompt:
      "Crie 3 versões de anúncio para {produto}, com oferta {oferta}, público {publico}, tom profissional e chamada para WhatsApp.",
  },
  {
    title: "Análise de orçamento",
    description: "Confere margem, custo, perdas e risco de prejuízo.",
    prompt:
      "Analise este orçamento: {orcamento}. Mostre custo, margem, pontos de risco, sugestões de venda e próximos passos.",
  },
];

export function fillPrompt(template: string, values: Record<string, string>) {
  return Object.entries(values).reduce(
    (text, [key, value]) => text.replaceAll(`{${key}}`, value),
    template,
  );
}
