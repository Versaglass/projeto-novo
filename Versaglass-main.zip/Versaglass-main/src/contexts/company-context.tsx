import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { supabase } from "@/integrations/supabase/client";
import { mensagemDoErro } from "@/lib/erro-mensagem";

// Papel EMPRESARIAL (company_members.role) — distinto do papel de PLATAFORMA
// (app_role em useAuth: admin/vendedor/instalador). Nunca misture os dois.
export type CompanyRole = "owner" | "admin" | "manager" | "operator" | "installer" | "seller";

export type CompanyMembership = {
  companyId: string;
  role: CompanyRole;
  companyName: string | null;
};

type CompanyContextValue = {
  /** Empresas das quais o usuário é membro ativo. */
  companies: CompanyMembership[];
  /** Empresa ativa (preferência local validada contra as memberships). */
  activeCompany: CompanyMembership | null;
  /** Papel EMPRESARIAL do usuário na empresa ativa (≠ papel de plataforma). */
  companyRole: CompanyRole | null;
  /**
   * Administra a EMPRESA ATIVA (owner ou admin em company_members).
   * NÃO é `isAdmin` do useAuth — aquele é papel de PLATAFORMA e não dá poder
   * algum sobre uma empresa da qual a pessoa não seja membro.
   */
  isCompanyAdmin: boolean;
  hasCompany: boolean;
  loading: boolean;
  error: string | null;
  /** Troca a empresa ativa — só aceita um id que pertença às memberships. */
  setActiveCompanyId: (id: string) => void;
  /** Recarrega memberships e devolve a lista já atualizada. */
  refresh: () => Promise<CompanyMembership[]>;
};

// Preferência de empresa ativa é POR USUÁRIO. Uma chave única compartilhada
// fazia o id da empresa de quem usou o navegador antes vazar para o próximo
// login (era descartado pela validação, mas ainda assim decidia a empresa
// inicial de quem tivesse acesso às duas). O sufixo com o uid elimina isso.
const STORAGE_PREFIX = "vmm_active_company_id";
const storageKey = (uid: string) => `${STORAGE_PREFIX}:${uid}`;
const CompanyContext = createContext<CompanyContextValue | null>(null);

const ADMIN_ROLES: CompanyRole[] = ["owner", "admin"];

export function CompanyProvider({ children }: { children: React.ReactNode }) {
  const [companies, setCompanies] = useState<CompanyMembership[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const uidRef = useRef<string | undefined>(undefined);
  // Atualizado DENTRO de `load`, não no corpo do render: `setActiveCompanyId`
  // é chamado logo após `await refresh()` (onboarding), antes de o React
  // recomeçar o render — com o ref preso ao render a validação usaria a lista
  // antiga e a seleção da empresa recém-criada era silenciosamente ignorada.
  const companiesRef = useRef<CompanyMembership[]>([]);

  const load = useCallback(async (uid: string | undefined): Promise<CompanyMembership[]> => {
    if (!uid) {
      companiesRef.current = [];
      setCompanies([]);
      setActiveId(null);
      setLoading(false);
      return [];
    }
    setLoading(true);
    setError(null);
    try {
      // RLS garante: só as memberships do próprio usuário são retornadas.
      const { data: members, error: mErr } = await supabase
        .from("company_members")
        .select("company_id, role")
        .eq("user_id", uid)
        .eq("status", "active");
      if (mErr) throw mErr;

      const ids = (members ?? []).map((m) => m.company_id as string);
      const names: Record<string, string> = {};
      if (ids.length) {
        // company_profiles é legível por qualquer membro ativo (20260727020000).
        const { data: profs } = await supabase
          .from("company_profiles")
          .select("id, company_name")
          .in("id", ids);
        for (const p of profs ?? []) names[p.id as string] = p.company_name as string;
      }

      const list: CompanyMembership[] = (members ?? []).map((m) => ({
        companyId: m.company_id as string,
        role: m.role as CompanyRole,
        companyName: names[m.company_id as string] ?? null,
      }));
      companiesRef.current = list;
      setCompanies(list);

      // Empresa ativa: preferência do localStorage VALIDADA contra as memberships.
      // Valor inválido (inclusive membership perdida) cai para a primeira da
      // lista; sem membership alguma, a preferência é apagada.
      const key = storageKey(uid);
      const stored = typeof localStorage !== "undefined" ? localStorage.getItem(key) : null;
      const valid = list.find((c) => c.companyId === stored) ?? list[0] ?? null;
      setActiveId(valid ? valid.companyId : null);
      if (typeof localStorage !== "undefined") {
        if (valid) localStorage.setItem(key, valid.companyId);
        else localStorage.removeItem(key);
      }
      return list;
    } catch (e: unknown) {
      setError(mensagemDoErro(e) ?? "Falha ao carregar empresas.");
      companiesRef.current = [];
      setCompanies([]);
      setActiveId(null);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_e, s) => {
      const next = s?.user?.id;
      if (next !== uidRef.current) {
        uidRef.current = next;
        void load(next);
      }
    });
    supabase.auth.getSession().then(({ data }) => {
      // Mesma guarda do onAuthStateChange: o INITIAL_SESSION e este getSession
      // disparam quase juntos na montagem; sem comparar contra `uidRef` ambos
      // chamariam `load` para o mesmo usuário, refazendo a consulta de memberships
      // e re-renderizando à toa. Quem chegar primeiro carrega; o outro ignora.
      const next = data.session?.user?.id;
      if (next !== uidRef.current) {
        uidRef.current = next;
        void load(next);
      }
    });
    return () => subscription.unsubscribe();
  }, [load]);

  const setActiveCompanyId = useCallback((id: string) => {
    // Só troca para uma empresa que realmente pertence ao usuário.
    if (!companiesRef.current.some((c) => c.companyId === id)) return;
    setActiveId(id);
    const uid = uidRef.current;
    if (uid && typeof localStorage !== "undefined") localStorage.setItem(storageKey(uid), id);
  }, []);

  const refresh = useCallback(() => load(uidRef.current), [load]);

  const activeCompany = useMemo(
    () => companies.find((c) => c.companyId === activeId) ?? null,
    [companies, activeId],
  );

  const value: CompanyContextValue = useMemo(
    () => ({
      companies,
      activeCompany,
      companyRole: activeCompany?.role ?? null,
      isCompanyAdmin: !!activeCompany && ADMIN_ROLES.includes(activeCompany.role),
      hasCompany: companies.length > 0,
      loading,
      error,
      setActiveCompanyId,
      refresh,
    }),
    [companies, activeCompany, loading, error, setActiveCompanyId, refresh],
  );

  return <CompanyContext.Provider value={value}>{children}</CompanyContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components -- padrão canônico de Context do React: provider e hook no mesmo arquivo, como em auth-context.
export function useCompany() {
  const ctx = useContext(CompanyContext);
  if (!ctx) throw new Error("useCompany deve ser usado dentro de <CompanyProvider>.");
  return ctx;
}
