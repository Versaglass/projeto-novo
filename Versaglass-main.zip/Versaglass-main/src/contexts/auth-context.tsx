import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { signOutInactiveAccount } from "@/lib/account-active";
import { syncAuthSessionFromAuthEvent } from "@/lib/auth-session-snapshot";
import { invalidateAuthzSnapshot } from "@/lib/authz-snapshot";

/**
 * Estado de autenticação COMPARTILHADO — Revisão 45.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * O DEFEITO QUE ISTO RESOLVE
 * ────────────────────────────────────────────────────────────────────────────
 * `useAuth()` era um hook comum: `useState` + `useEffect` + assinatura própria
 * de `onAuthStateChange`, e **22 componentes** o chamavam. Cada chamada montava
 * uma cópia independente do estado E refazia as MESMAS duas consultas —
 * `user_roles` e `profiles`.
 *
 * Medido na Revisão 42, num único carregamento de `/app`:
 *   12× rest/v1/user_roles + 12× rest/v1/profiles  (29 requisições no total)
 * enquanto `company_members`, servido por um Context de verdade
 * (`company-context.tsx`), aparecia **1×** na mesma página. A diferença entre
 * as duas linhas da mesma medição é exatamente a diferença entre hook e
 * Context — e é o motivo desta refatoração.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * O QUE MUDA E O QUE NÃO MUDA
 * ────────────────────────────────────────────────────────────────────────────
 * A API pública de `useAuth()` é **idêntica** (`session`, `user`, `role`,
 * `roles`, `permissions`, `isAdmin`, `isVendedor`, `isInstalador`, `can`,
 * `loading`) — nenhum dos 22 consumidores precisou ser tocado. O que muda é
 * apenas ONDE o estado vive: aqui, uma vez só.
 *
 * A regra de autorização é a MESMA de antes, preservada literalmente: papéis
 * derivados do CONJUNTO (nunca do primeiro registro devolvido pelo banco — ver
 * P-25), `role` singular só como rótulo de exibição, e `can()` com o atalho de
 * admin. Nada de permissão foi afrouxado nem endurecido nesta rodada.
 *
 * Conta desativada (`profiles.ativo = false`): ao carregar o profile o contexto
 * encerra a sessão local. A revalidação em navegação fica em
 * `enforceAccountActive` (`/_authenticated` beforeLoad).
 */

export type Permissions = {
  manage_projetos: boolean;
  manage_estoque: boolean;
  manage_clientes: boolean;
  create_orcamentos: boolean;
  edit_orcamentos: boolean;
  delete_orcamentos: boolean;
  use_plano_corte: boolean;
};

export type AppRole = "admin" | "vendedor" | "instalador";

const DEFAULT_PERMS: Permissions = {
  manage_projetos: false,
  manage_estoque: false,
  manage_clientes: true,
  create_orcamentos: true,
  edit_orcamentos: true,
  delete_orcamentos: false,
  use_plano_corte: true,
};

// Precedência determinística para o campo singular `role`, que muitos componentes
// já consomem. NÃO é usada para autorização — esta se baseia no conjunto completo.
const ROLE_PRECEDENCE: AppRole[] = ["admin", "vendedor", "instalador"];

export type AuthContextValue = {
  session: Session | null;
  user: User | null;
  role: AppRole | null;
  roles: AppRole[] | null;
  permissions: Permissions;
  isAdmin: boolean;
  isVendedor: boolean;
  isInstalador: boolean;
  can: (p: keyof Permissions) => boolean;
  loading: boolean;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  // Conjunto completo de papéis. `null` = ainda não carregado (≠ carregado e vazio).
  const [roles, setRoles] = useState<AppRole[] | null>(null);
  const [permissions, setPermissions] = useState<Permissions>(DEFAULT_PERMS);
  const [loading, setLoading] = useState(true);

  // Guarda de carga ÚNICA por usuário.
  //
  // `onAuthStateChange` (com o eco de INITIAL_SESSION) e `getSession()` chegam
  // os dois com a mesma sessão, quase juntos — e no código anterior os dois
  // disparavam a carga, o que dava 2 pares de consultas por instância do hook.
  // Um `Symbol` como estado inicial distingue "nunca carregado" de "carregado
  // para usuário nenhum" (`undefined`), que é o caso do visitante deslogado.
  const NUNCA = useRef(Symbol("nunca")).current;
  const carregadoParaRef = useRef<string | undefined | symbol>(NUNCA);

  const carregar = useCallback(
    async (uid: string | undefined) => {
      if (!uid) {
        setRoles(null);
        setPermissions(DEFAULT_PERMS);
        return;
      }
      const [{ data: roleRows }, { data: prof, error: profError }] = await Promise.all([
        supabase.from("user_roles").select("role").eq("user_id", uid),
        supabase.from("profiles").select("permissions, ativo").eq("id", uid).maybeSingle(),
      ]);

      // Falha ao ler o profile ≠ conta desativada — não encerra a sessão.
      if (profError) {
        setRoles((roleRows ?? []).map((r) => r.role as AppRole));
        setPermissions(DEFAULT_PERMS);
        return;
      }

      // Evidência explícita: só `false` bloqueia. Ausência de linha não bloqueia.
      if (prof?.ativo === false) {
        // Libera a guarda para um login futuro do mesmo uid após reativação.
        carregadoParaRef.current = NUNCA;
        setRoles(null);
        setPermissions(DEFAULT_PERMS);
        await signOutInactiveAccount();
        return;
      }

      setRoles((roleRows ?? []).map((r) => r.role as AppRole));
      setPermissions({
        ...DEFAULT_PERMS,
        ...((prof?.permissions as Partial<Permissions> | null) ?? {}),
      });
    },
    [NUNCA],
  );

  const garantirCarga = useCallback(
    (uid: string | undefined) => {
      if (carregadoParaRef.current === uid) return Promise.resolve();
      carregadoParaRef.current = uid;
      return carregar(uid);
    },
    [carregar],
  );

  useEffect(() => {
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, s) => {
      syncAuthSessionFromAuthEvent(event, s);
      if (event === "SIGNED_OUT") invalidateAuthzSnapshot();
      setSession(s);
      setUser(s?.user ?? null);
      // A troca de usuário (login/logout) passa pela guarda e recarrega;
      // TOKEN_REFRESHED e o eco de INITIAL_SESSION não, porque o uid não mudou.
      garantirCarga(s?.user?.id);
    });
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setUser(data.session?.user ?? null);
      garantirCarga(data.session?.user?.id).finally(() => setLoading(false));
    });
    return () => subscription.unsubscribe();
  }, [garantirCarga]);

  const valor = useMemo<AuthContextValue>(() => {
    // AUTORIZAÇÃO: sempre derivada do CONJUNTO de papéis, nunca do primeiro
    // registro devolvido pelo banco — a ordem de `select` não é garantida, e um
    // usuário com 'vendedor' + 'admin' era classificado conforme o acaso da
    // ordenação (P-25).
    const isAdmin = roles?.some((r) => r === "admin") ?? false;
    const isVendedor = roles?.some((r) => r === "vendedor") ?? false;
    const isInstalador = roles?.some((r) => r === "instalador") ?? false;

    // Campo singular mantido por compatibilidade com os componentes que já o
    // usam. Permanece `null` enquanto não carregado (AppShell só mostra o badge
    // se houver valor). Carregado e sem papel algum cai em "vendedor" — isso é
    // rótulo de exibição, não autorização.
    const role: AppRole | null =
      roles === null ? null : (ROLE_PRECEDENCE.find((r) => roles.includes(r)) ?? "vendedor");

    return {
      session,
      user,
      role,
      roles,
      permissions,
      isAdmin,
      isVendedor,
      isInstalador,
      can: (p: keyof Permissions) => isAdmin || permissions[p],
      loading,
    };
  }, [session, user, roles, permissions, loading]);

  return <AuthContext.Provider value={valor}>{children}</AuthContext.Provider>;
}

/**
 * Mesma assinatura de sempre — o que mudou é que agora LÊ de um estado único.
 *
 * Lança se usado fora do provider, de propósito: um consumidor órfão voltaria
 * silenciosamente ao comportamento antigo (estado próprio, consultas próprias),
 * que é justamente o defeito corrigido aqui. Falhar alto na primeira renderização
 * é preferível a reintroduzir o problema sem ninguém notar.
 */
// eslint-disable-next-line react-refresh/only-export-components -- padrão canônico de Context do React: provider e hook no mesmo arquivo. Separá-los pioraria o código para agradar uma regra que só afeta Fast Refresh em dev. Ver Revisão 45.
export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth deve ser usado dentro de <AuthProvider>.");
  return ctx;
}
