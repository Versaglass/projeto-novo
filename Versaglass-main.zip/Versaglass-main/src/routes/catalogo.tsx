// =====================================================================
// ⚠️ BLOCO FORA DE USO — "biblioteca bloqueada por assinatura"
//
// Esta tela faz parte de um sistema de assinatura B2C (catálogo de modelos
// premium) que NASCEU NO PRIMEIRO COMMIT do projeto (`a0c7291`, "estado
// inicial recebido") e NUNCA FOI CONECTADO. Está documentado em
// `PLANOS_BIBLIOTECA_ASSINATURA.md`, na raiz do repositório.
//
// Por que "nunca conectado", em fatos (levantamento na Revisão 112):
//
//   • a migration que o documento cita — `20260703030000_subscription_locked_
//     library.sql`, "com tabelas, seeds, funções e RLS" — NÃO EXISTE em
//     `supabase/migrations/`;
//   • as tabelas sobreviveram na baseline (`project_categories`,
//     `project_models`, `plan_model_limits`, `plans`), mas NENHUMA delas tem
//     um único leitor no código, e não há seed em migration alguma;
//   • `user_subscriptions` tem UMA referência em toda a árvore: o `select` de
//     `getUserPlan`. NADA insere. Logo `getUserPlan` devolve sempre "free";
//   • `/planos` e `/upgrade-premium` não têm um `onClick` sequer — não há
//     caminho de upgrade;
//   • `/editor/$modelId` redireciona quando `plan === "free"`, ou seja, para
//     100% dos usuários. A tela do editor é INALCANÇÁVEL hoje;
//   • o bloco é um CIRCUITO FECHADO: `/catalogo`, `/editor/$modelId`,
//     `/planos`, `/upgrade-premium`, `/projeto/$projectId`, `/pdf/$projectId`
//     e as duas telas `/admin/*` só apontam umas para as outras. Nenhuma rota
//     do aplicativo autenticado aponta para dentro dele — nem o menu.
//
// 📌 MANTIDO NO CÓDIGO POR DECISÃO DO RESPONSÁVEL, SEM USO ATIVO.
//    NÃO expandir, NÃO depurar e NÃO usar como referência de padrão até
//    haver decisão de produto. O editor de desenho que funciona é outro:
//    `components/ParametricProjectEditor.tsx` (Projetos › Editar desenho) e
//    `components/engineering/UniversalEngineeringEditor.tsx` (Editor 2D/3D).
// =====================================================================

import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Crown,
  FileText,
  ImageDown,
  Layers,
  Lock,
  Ruler,
  Save,
  Scissors,
  Sparkles,
  Wand2,
} from "lucide-react";
import { AvisoBlocoForaDeUso } from "@/components/AvisoBlocoForaDeUso";
import {
  PROJECT_CATEGORIES,
  PROJECT_MODELS,
  lockedTarget,
  PLAN_PRICES,
} from "@/data/projectLibrary";
import { modelAccessForPlan } from "@/modules/subscriptions/accessControl";
import { useSubscriptionAccess } from "@/hooks/useSubscriptionAccess";

export const Route = createFileRoute("/catalogo")({ component: CatalogoPage });

function CatalogoPage() {
  const { data: access } = useSubscriptionAccess();
  const plan = access?.plan ?? "free";
  const [category, setCategory] = useState("todos");
  const models = useMemo(() => {
    return PROJECT_MODELS.filter((m) => category === "todos" || m.categorySlug === category);
  }, [category]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border bg-card/70 px-4 py-4 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-2xl font-bold">Catálogo de Projetos</h1>
            <p className="text-sm text-muted-foreground">
              Modelos visíveis para venda de assinatura: grátis, PRO e PREMIUM.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="rounded-full border border-gold/40 bg-gold/10 px-3 py-1 text-xs font-bold uppercase text-gold">
              Plano atual: {plan}
            </span>
            <Link
              to="/planos"
              className="rounded-lg bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground"
            >
              Ver planos
            </Link>
            <Link
              to="/app/projetos"
              className="rounded-lg border border-border px-4 py-2 text-sm font-semibold hover:bg-accent"
            >
              Voltar ao sistema
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6">
        <AvisoBlocoForaDeUso />
        <div className="mb-5 grid grid-cols-1 gap-3 md:grid-cols-3">
          <PlanCard
            title="Visitante"
            price="R$ 0"
            active={plan === "free"}
            items={["2 modelos demonstrativos", "Sem edição", "Sem PDF", "Redireciona para planos"]}
          />
          <PlanCard
            title="PRO"
            price={`R$ ${PLAN_PRICES.pro.toFixed(2).replace(".", ",")}/mês`}
            active={plan === "pro"}
            items={[
              "Biblioteca parcial",
              "Editar e salvar",
              "PDF ilimitado",
              "Lista de corte e materiais",
            ]}
          />
          <PlanCard
            title="PREMIUM"
            price={`R$ ${PLAN_PRICES.premium.toFixed(2).replace(".", ",")}/mês`}
            active={plan === "premium"}
            items={["Todos os modelos", "DXF/DWG/SVG", "Renderização HD", "IA de otimização"]}
          />
        </div>

        <div className="mb-5 flex gap-2 overflow-x-auto rounded-2xl border border-border bg-card p-3">
          <button
            onClick={() => setCategory("todos")}
            className={`whitespace-nowrap rounded-lg px-3 py-2 text-sm font-semibold ${category === "todos" ? "bg-gold text-gold-foreground" : "border border-border hover:bg-accent"}`}
          >
            Todos
          </button>
          {PROJECT_CATEGORIES.map((c) => (
            <button
              key={c.slug}
              onClick={() => setCategory(c.slug)}
              className={`whitespace-nowrap rounded-lg px-3 py-2 text-sm font-semibold ${category === c.slug ? "bg-gold text-gold-foreground" : "border border-border hover:bg-accent"}`}
            >
              {c.name}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {models.map((m) => {
            const index = PROJECT_MODELS.filter((x) => x.categorySlug === m.categorySlug).findIndex(
              (x) => x.id === m.id,
            );
            const gate = modelAccessForPlan(plan, m.categorySlug, index, m.freePreview);
            const categoryName =
              PROJECT_CATEGORIES.find((c) => c.slug === m.categorySlug)?.name ?? m.categorySlug;
            return (
              <ModelCard
                key={m.id}
                model={m}
                categoryName={categoryName}
                allowed={gate.allowed}
                reason={gate.reason}
                target={lockedTarget(plan)}
                plan={plan}
              />
            );
          })}
        </div>
      </main>
    </div>
  );
}

function ModelCard({ model, categoryName, allowed, reason, target, plan }: any) {
  return (
    <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition hover:border-gold/40 hover:shadow-elegant">
      <div className="relative aspect-[4/3] bg-muted/40">
        <img
          src={model.image3dUrl || model.image2dUrl}
          alt={model.title}
          className={`h-full w-full object-cover ${allowed ? "" : "blur-sm grayscale"}`}
          loading="lazy"
          decoding="async"
          onError={(e) => {
            e.currentTarget.src = "/projetos/projeto-placeholder.svg";
          }}
        />
        {!allowed && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/55 text-center text-white">
            <Lock className="mb-2 h-8 w-8 text-gold" />
            <div className="font-bold">{reason}</div>
            <Link
              to={target}
              className="mt-3 rounded-lg bg-gradient-gold px-4 py-2 text-sm font-bold text-gold-foreground"
            >
              Desbloquear agora
            </Link>
          </div>
        )}
        <div className="absolute left-3 top-3 flex gap-2">
          <span className="rounded-full bg-background/90 px-2 py-0.5 text-[10px] font-bold">
            {categoryName}
          </span>
          {model.isPremium && (
            <span className="inline-flex items-center gap-1 rounded-full bg-gold px-2 py-0.5 text-[10px] font-bold text-gold-foreground">
              <Crown className="h-3 w-3" /> PREMIUM
            </span>
          )}
        </div>
      </div>
      <div className="p-5">
        <h3 className="font-display text-lg font-bold">{model.title}</h3>
        <p className="mt-1 min-h-[40px] text-sm text-muted-foreground">{model.description}</p>
        <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
          <Feature
            ok={allowed && plan !== "free"}
            icon={<Ruler className="h-3.5 w-3.5" />}
            label="Editar"
          />
          <Feature
            ok={allowed && plan !== "free"}
            icon={<FileText className="h-3.5 w-3.5" />}
            label="PDF"
          />
          <Feature
            ok={allowed && plan !== "free"}
            icon={<Scissors className="h-3.5 w-3.5" />}
            label="Lista corte"
          />
          <Feature
            ok={allowed && plan !== "free"}
            icon={<ImageDown className="h-3.5 w-3.5" />}
            label="Imagem"
          />
          <Feature
            ok={allowed && plan === "premium"}
            icon={<Layers className="h-3.5 w-3.5" />}
            label="DXF/DWG/SVG"
          />
          <Feature
            ok={allowed && plan === "premium"}
            icon={<Sparkles className="h-3.5 w-3.5" />}
            label="IA + HD"
          />
        </div>
        <div className="mt-4 flex gap-2">
          {allowed && plan !== "free" ? (
            <Link
              to="/editor/$modelId"
              params={{ modelId: model.id }}
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-lg bg-gradient-gold px-3 py-2 text-sm font-bold text-gold-foreground"
            >
              <Wand2 className="h-4 w-4" /> Abrir editor
            </Link>
          ) : (
            <Link
              to={target}
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-lg border border-gold/40 bg-gold/10 px-3 py-2 text-sm font-bold text-gold"
            >
              <Lock className="h-4 w-4" /> Desbloquear
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}

function Feature({ ok, icon, label }: { ok: boolean; icon: React.ReactNode; label: string }) {
  return (
    <div
      className={`inline-flex items-center gap-1.5 rounded-lg border px-2 py-1 ${ok ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300" : "border-border text-muted-foreground"}`}
    >
      {icon}
      {label}
    </div>
  );
}

function PlanCard({
  title,
  price,
  active,
  items,
}: {
  title: string;
  price: string;
  active: boolean;
  items: string[];
}) {
  return (
    <div
      className={`rounded-2xl border p-4 ${active ? "border-gold bg-gold/10" : "border-border bg-card"}`}
    >
      <div className="flex items-center justify-between">
        <h2 className="font-display text-lg font-bold">{title}</h2>
        {active && (
          <span className="rounded-full bg-gold px-2 py-0.5 text-[10px] font-bold text-gold-foreground">
            ATUAL
          </span>
        )}
      </div>
      <div className="mt-1 text-2xl font-bold text-gold">{price}</div>
      <ul className="mt-3 space-y-1 text-sm text-muted-foreground">
        {items.map((i) => (
          <li key={i}>• {i}</li>
        ))}
      </ul>
    </div>
  );
}
