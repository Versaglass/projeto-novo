// =====================================================================
// ⚠️ BLOCO FORA DE USO — "biblioteca bloqueada por assinatura"
//
// Esta tela faz parte de um sistema de assinatura B2C (catálogo de modelos
// premium) que NASCEU NO PRIMEIRO COMMIT do projeto (`a0c7291`, "estado
// inicial recebido") e NUNCA FOI CONECTADO. Está documentado em
// `PLANOS_BIBLIOTECA_ASSINATURA.md`, na raiz do repositório.
//
// Por que "nunca conectado", em fatos (levantamento na Revisão 112):
//
//   • a migration que o documento cita — `20260703030000_subscription_locked_
//     library.sql`, "com tabelas, seeds, funções e RLS" — NÃO EXISTE em
//     `supabase/migrations/`;
//   • as tabelas sobreviveram na baseline (`project_categories`,
//     `project_models`, `plan_model_limits`, `plans`), mas NENHUMA delas tem
//     um único leitor no código, e não há seed em migration alguma;
//   • `user_subscriptions` tem UMA referência em toda a árvore: o `select` de
//     `getUserPlan`. NADA insere. Logo `getUserPlan` devolve sempre "free";
//   • `/planos` e `/upgrade-premium` não têm um `onClick` sequer — não há
//     caminho de upgrade;
//   • `/editor/$modelId` redireciona quando `plan === "free"`, ou seja, para
//     100% dos usuários. A tela do editor é INALCANÇÁVEL hoje;
//   • o bloco é um CIRCUITO FECHADO: `/catalogo`, `/editor/$modelId`,
//     `/planos`, `/upgrade-premium`, `/projeto/$projectId`, `/pdf/$projectId`
//     e as duas telas `/admin/*` só apontam umas para as outras. Nenhuma rota
//     do aplicativo autenticado aponta para dentro dele — nem o menu.
//
// 📌 MANTIDO NO CÓDIGO POR DECISÃO DO RESPONSÁVEL, SEM USO ATIVO.
//    NÃO expandir, NÃO depurar e NÃO usar como referência de padrão até
//    haver decisão de produto. O editor de desenho que funciona é outro:
//    `components/ParametricProjectEditor.tsx` (Projetos › Editar desenho) e
//    `components/engineering/UniversalEngineeringEditor.tsx` (Editor 2D/3D).
// =====================================================================

import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { Download, FileText, ImageDown, Lock, Ruler, Save, Scissors, Sparkles } from "lucide-react";
import { AvisoBlocoForaDeUso } from "@/components/AvisoBlocoForaDeUso";
import { PROJECT_MODELS, lockedTarget } from "@/data/projectLibrary";
import { modelAccessForPlan } from "@/modules/subscriptions/accessControl";
import { useSubscriptionAccess } from "@/hooks/useSubscriptionAccess";

export const Route = createFileRoute("/editor/$modelId")({ component: EditorModelPage });

function EditorModelPage() {
  const { modelId } = Route.useParams();
  const { data: access, isLoading } = useSubscriptionAccess();
  const model = PROJECT_MODELS.find((m) => m.id === modelId);
  if (!model) return <Navigate to="/catalogo" />;
  if (isLoading) return <div className="p-8 text-muted-foreground">Carregando assinatura...</div>;
  const plan = access?.plan ?? "free";
  const index = PROJECT_MODELS.filter((m) => m.categorySlug === model.categorySlug).findIndex(
    (m) => m.id === model.id,
  );
  const gate = modelAccessForPlan(plan, model.categorySlug, index, model.freePreview);
  if (!gate.allowed || plan === "free") return <Navigate to={lockedTarget(plan)} />;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="border-b border-border bg-card px-4 py-3">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-xl font-bold">Editor de Projeto</h1>
            <p className="text-sm text-muted-foreground">{model.title}</p>
          </div>
          <Link
            to="/catalogo"
            className="rounded-lg border border-border px-3 py-2 text-sm font-semibold hover:bg-accent"
          >
            Catálogo
          </Link>
        </div>
      </div>
      <AvisoBlocoForaDeUso />
      <main className="mx-auto grid max-w-7xl gap-4 p-4 lg:grid-cols-[260px_1fr_300px]">
        <aside className="rounded-2xl border border-border bg-card p-4">
          {/* Revisao 117 — deixaram de parecer botões (Rev. 111 §⑧ / 113).
              Continuam só como selo do plano; sem onClick, sem hover, sem pointer. */}
          <h2 className="font-bold text-muted-foreground">Incluído no seu plano</h2>
          <Tool icon={<Ruler />} label="Editar medidas" ok={access?.canEdit} />
          <Tool icon={<Save />} label="Salvar projeto" ok={access?.canSaveProject} />
          <Tool icon={<FileText />} label="Gerar PDF" ok={access?.canGeneratePdf} />
          <Tool icon={<ImageDown />} label="Baixar imagem" ok={access?.canDownloadImage} />
          <Tool icon={<Scissors />} label="Lista de corte" ok={access?.canCutList} />
          <Tool icon={<Download />} label="Lista de materiais" ok={access?.canMaterialList} />
          <Tool icon={<Sparkles />} label="IA / Render HD" ok={access?.canUseAi} />
        </aside>
        <section className="rounded-2xl border border-border bg-card p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-bold">Visualização 2D / 3D</h2>
            <span className="rounded-full bg-gold/10 px-3 py-1 text-xs font-bold text-gold">
              {plan.toUpperCase()}
            </span>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <img
              src={model.image2dUrl}
              className="h-80 w-full rounded-xl border border-border bg-muted object-contain p-3"
              onError={(e) => {
                e.currentTarget.src = "/projetos/projeto-placeholder.svg";
              }}
            />
            <img
              src={model.image3dUrl}
              className="h-80 w-full rounded-xl border border-border bg-muted object-contain p-3"
              onError={(e) => {
                e.currentTarget.src = "/projetos/projeto-placeholder.svg";
              }}
            />
          </div>
          <div className="mt-4 rounded-xl border border-dashed border-gold/40 bg-gold/10 p-4 text-sm text-gold">
            Base preparada para o editor paramétrico: alterar medidas, componentes, lista de corte,
            materiais e PDF sem bloquear funções essenciais para assinantes.
          </div>
        </section>
        <aside className="rounded-2xl border border-border bg-card p-4">
          <h2 className="font-bold text-muted-foreground">Propriedades</h2>
          <Label name="Largura" />
          <Label name="Altura" />
          <Label name="Perfil" />
          <Label name="Material" />
          {/* Revisao 117 — aparência desabilitada (padrão do Button do sistema:
              disabled:opacity-50 disabled:cursor-not-allowed). Sem onClick. */}
          <button
            type="button"
            disabled
            aria-disabled="true"
            className="mt-4 w-full cursor-not-allowed rounded-lg border border-border bg-muted px-4 py-2 text-sm font-bold text-muted-foreground opacity-50"
          >
            Atualizar projeto
          </button>
          {!access?.canExportDxf && (
            <div className="mt-4 rounded-xl border border-border bg-background p-3 text-xs text-muted-foreground">
              <Lock className="mb-1 h-4 w-4" /> DXF/DWG/SVG, IA e render HD ficam no PREMIUM.
            </div>
          )}
        </aside>
      </main>
    </div>
  );
}
function Tool({ icon, label, ok }: { icon: ReactNode; label: string; ok?: boolean }) {
  // Selo do plano, não botão: cursor e opacidade iguais ao `disabled` do
  // `components/ui/button.tsx` (opacity-50 · cursor-not-allowed · sem hover).
  return (
    <div
      role="presentation"
      aria-disabled="true"
      title="Indisponível — esta tela está fora de uso"
      className={`mt-2 flex cursor-not-allowed items-center gap-2 rounded-lg border px-3 py-2 text-sm opacity-50 pointer-events-none ${
        ok
          ? "border-emerald-500/20 bg-emerald-500/5 text-emerald-300/80"
          : "border-border text-muted-foreground"
      }`}
    >
      {icon}
      {label}
    </div>
  );
}
function Label({ name }: { name: string }) {
  return (
    <label className="mt-3 block cursor-not-allowed text-sm opacity-50">
      <span className="mb-1 block text-xs text-muted-foreground">{name}</span>
      <input
        disabled
        aria-disabled="true"
        readOnly
        tabIndex={-1}
        className="w-full cursor-not-allowed rounded-lg border border-input bg-muted px-3 py-2 text-muted-foreground outline-none"
        placeholder="Indisponível"
      />
    </label>
  );
}
