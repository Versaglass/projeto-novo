import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/contexts/company-context";
import {
  Bell,
  CheckCircle2,
  AlertTriangle,
  Clock,
  CreditCard,
  Check,
  Sparkles,
  Crown,
  type LucideIcon,
} from "lucide-react";
import { toast } from "sonner";
import { mensagemDoErro } from "@/lib/erro-mensagem";
import {
  formatSaasPrice,
  isSaasPlanSlug,
  SAAS_STATUS_LABELS,
  type CompanySubscription,
  type SaasPlan,
  type SaasPlanSlug,
} from "@/lib/saas-billing";

type CheckoutSearch = {
  checkout?: "success" | "cancel" | "expired";
};

export const Route = createFileRoute("/_authenticated/app/minha-assinatura")({
  validateSearch: (search: Record<string, unknown>): CheckoutSearch => ({
    checkout:
      search.checkout === "success" || search.checkout === "cancel" || search.checkout === "expired"
        ? search.checkout
        : undefined,
  }),
  component: MinhaAssinatura,
});

type SubWithPlan = CompanySubscription & {
  saas_plans: Pick<SaasPlan, "slug" | "name" | "price_monthly" | "cycle"> | null;
};

const PLAN_COPY: Record<
  SaasPlanSlug,
  { descricao: string; recursos: string[]; icon: LucideIcon; destaque: boolean }
> = {
  basic: {
    descricao: "Para começar a organizar sua vidraçaria",
    icon: Sparkles,
    destaque: false,
    recursos: [
      "Até 50 orçamentos por mês",
      "Cadastro de clientes ilimitado",
      "Geração de PDF dos orçamentos",
      "Controle básico de estoque",
      "Suporte por e-mail",
    ],
  },
  premium: {
    descricao: "Tudo que você precisa para crescer",
    icon: Crown,
    destaque: true,
    recursos: [
      "Orçamentos ilimitados",
      "Plano de corte automático",
      "Projetos e ambientes ilimitados",
      "Notificações por WhatsApp",
      "Múltiplos usuários (funcionários)",
      "Relatórios e dashboards avançados",
      "Suporte prioritário",
    ],
  },
};

function statusUi(status: string): { label: string; cls: string; icon: LucideIcon; desc: string } {
  const label = SAAS_STATUS_LABELS[status] ?? status;
  if (status === "active") {
    return {
      label,
      cls: "bg-emerald-500/15 text-emerald-600 border-emerald-500/30",
      icon: CheckCircle2,
      desc: "Sua assinatura está ativa.",
    };
  }
  if (status === "pending") {
    return {
      label,
      cls: "bg-amber-500/15 text-amber-700 border-amber-500/30",
      icon: Clock,
      desc: "Aguardando confirmação do pagamento pelo Asaas.",
    };
  }
  if (status === "past_due") {
    return {
      label,
      cls: "bg-red-500/15 text-red-600 border-red-500/30",
      icon: AlertTriangle,
      desc: "Há cobrança em atraso. Regularize para manter o acesso pago.",
    };
  }
  if (status === "suspended") {
    return {
      label,
      cls: "bg-zinc-500/15 text-zinc-600 border-zinc-500/30",
      icon: AlertTriangle,
      desc: "Sua assinatura está suspensa.",
    };
  }
  return {
    label,
    cls: "bg-zinc-500/15 text-zinc-600 border-zinc-500/30",
    icon: AlertTriangle,
    desc: "Sua assinatura foi cancelada.",
  };
}

function MinhaAssinatura() {
  const { activeCompany, isCompanyAdmin, loading: companyLoading } = useCompany();
  const { checkout: checkoutResult } = Route.useSearch();
  const [plans, setPlans] = useState<SaasPlan[]>([]);
  const [sub, setSub] = useState<SubWithPlan | null>(null);
  const [loading, setLoading] = useState(true);
  const [subscribing, setSubscribing] = useState<SaasPlanSlug | null>(null);
  const companyId = activeCompany?.companyId ?? null;

  const load = useCallback(async () => {
    if (!companyId) {
      setSub(null);
      setPlans([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    const [{ data: planRows, error: planErr }, { data: subRow, error: subErr }] = await Promise.all(
      [
        supabase
          .from("saas_plans")
          .select("*")
          .eq("active", true)
          .order("price_monthly", { ascending: true }),
        supabase
          .from("company_subscriptions")
          .select("*, saas_plans(slug, name, price_monthly, cycle)")
          .eq("company_id", companyId)
          .maybeSingle(),
      ],
    );
    if (planErr) toast.error(mensagemDoErro(planErr) ?? "Falha ao carregar planos.");
    if (subErr) toast.error(mensagemDoErro(subErr) ?? "Falha ao carregar assinatura.");
    setPlans((planRows ?? []) as SaasPlan[]);
    setSub((subRow as SubWithPlan | null) ?? null);
    setLoading(false);
  }, [companyId]);

  useEffect(() => {
    if (companyLoading) return;
    load();
  }, [companyLoading, load]);

  useEffect(() => {
    if (!checkoutResult) return;
    if (checkoutResult === "success") {
      toast.message("Pagamento enviado. Estamos confirmando sua assinatura.");
    } else if (checkoutResult === "cancel") {
      toast.message("Pagamento cancelado.");
    } else if (checkoutResult === "expired") {
      toast.message("O link de pagamento expirou. Gere um novo checkout para continuar.");
    }
    // Refetch — query param NÃO altera o banco.
    void load();
  }, [checkoutResult, load]);

  const canManage = isCompanyAdmin;

  const checkoutActivePending = useMemo(() => {
    if (!sub) return false;
    if (sub.status !== "pending") return false;
    if (sub.checkout_status !== "ACTIVE") return false;
    if (!sub.asaas_checkout_id) return false;
    if (!sub.checkout_expires_at) return false;
    return new Date(sub.checkout_expires_at).getTime() > Date.now();
  }, [sub]);

  async function startCheckout(planSlug: SaasPlanSlug) {
    if (!companyId) {
      toast.error("Selecione uma empresa para assinar.");
      return;
    }
    if (!canManage) {
      toast.error("Somente proprietários ou administradores podem gerenciar a assinatura.");
      return;
    }
    if (subscribing) return;
    setSubscribing(planSlug);
    try {
      const { data, error } = await supabase.functions.invoke("asaas-create-checkout", {
        body: { companyId, planSlug },
      });
      if (error) {
        const resposta = (error as { context?: Response })?.context;
        if (resposta && typeof resposta.json === "function") {
          try {
            const corpo = (await resposta.json()) as { error?: string };
            if (corpo?.error) {
              toast.error(corpo.error);
              return;
            }
          } catch {
            /* corpo ilegível — fallback abaixo */
          }
        }
        toast.error(error.message || "Não foi possível iniciar o pagamento. Tente novamente.");
        return;
      }
      const payload = data as { checkoutUrl?: string; error?: string } | null;
      if (payload?.error) {
        toast.error(payload.error);
        return;
      }
      if (!payload?.checkoutUrl) {
        toast.error("Não foi possível iniciar o pagamento. Tente novamente.");
        return;
      }
      window.location.assign(payload.checkoutUrl);
    } catch (e) {
      toast.error(mensagemDoErro(e) ?? "Não foi possível iniciar o pagamento. Tente novamente.");
    } finally {
      setSubscribing(null);
    }
  }

  if (companyLoading || loading) {
    return <div className="text-muted-foreground">Carregando…</div>;
  }

  if (!companyId) {
    return (
      <div className="space-y-4">
        <header>
          <h1 className="font-display text-3xl font-bold">Minha assinatura</h1>
          <p className="text-sm text-muted-foreground">Assinatura SaaS do VersaGlass</p>
        </header>
        <div className="rounded-xl border bg-card p-6 text-center text-sm text-muted-foreground">
          Nenhuma empresa ativa. Conclua o onboarding da empresa para assinar um plano.
        </div>
      </div>
    );
  }

  const hasActive = sub?.status === "active";
  const planName = sub?.saas_plans?.name ?? (sub ? sub.plan_slug : null);
  const planPrice = sub?.saas_plans?.price_monthly;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-3xl font-bold">Minha assinatura</h1>
        <p className="text-sm text-muted-foreground">
          Plano e status da mensalidade do VersaGlass — {activeCompany?.companyName ?? "empresa"}
        </p>
      </header>

      {!sub ? (
        <div className="rounded-xl border bg-card p-6 text-center">
          <CreditCard className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
          <h2 className="font-display text-xl font-bold">Sem assinatura ativa</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Selecione um dos planos abaixo para ativar.
          </p>
        </div>
      ) : (
        <>
          {(() => {
            const info = statusUi(sub.status);
            const Icon = info.icon;
            return (
              <div className={`rounded-xl border p-6 ${info.cls}`}>
                <div className="flex items-center gap-3">
                  <Icon className="h-6 w-6" />
                  <div>
                    <div className="text-xs uppercase tracking-wider opacity-70">Status</div>
                    <div className="text-xl font-bold">{info.label}</div>
                  </div>
                </div>
                <p className="mt-3 text-sm">{info.desc}</p>
              </div>
            );
          })()}

          <div className="grid gap-3 md:grid-cols-4">
            <Info label="Plano" value={planName ?? "—"} />
            <Info
              label="Valor mensal"
              value={planPrice != null ? `R$ ${formatSaasPrice(Number(planPrice))}` : "—"}
            />
            <Info
              label="Próximo vencimento"
              value={
                sub.next_due_date
                  ? new Date(sub.next_due_date + "T00:00:00").toLocaleDateString("pt-BR")
                  : "—"
              }
            />
            <Info
              label="Último pagamento"
              value={
                sub.last_payment_at
                  ? new Date(sub.last_payment_at).toLocaleDateString("pt-BR")
                  : "—"
              }
            />
          </div>

          {checkoutActivePending && canManage && (
            <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-4">
              <p className="text-sm">Há um checkout de pagamento ainda válido.</p>
              <button
                type="button"
                disabled={!!subscribing}
                onClick={() => {
                  const slug = isSaasPlanSlug(sub.plan_slug) ? sub.plan_slug : "basic";
                  void startCheckout(slug);
                }}
                className="mt-3 rounded-lg bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground shadow-glow disabled:opacity-60"
              >
                {subscribing ? "Preparando pagamento..." : "Continuar pagamento"}
              </button>
            </div>
          )}
        </>
      )}

      {!canManage && (
        <div className="rounded-lg border bg-muted/40 px-4 py-3 text-sm text-muted-foreground">
          Somente proprietários ou administradores podem contratar ou alterar a assinatura.
        </div>
      )}

      <PlanosDisponiveis
        plans={plans}
        planoAtual={hasActive && isSaasPlanSlug(sub?.plan_slug ?? "") ? sub!.plan_slug : null}
        canManage={canManage}
        subscribing={subscribing}
        onAssinar={startCheckout}
      />

      <section>
        <h2 className="mb-3 flex items-center gap-2 font-display text-xl font-bold">
          <Bell className="h-5 w-5" /> Notificações
        </h2>
        <div className="rounded-lg border bg-card p-4 text-center text-sm text-muted-foreground">
          Notificações de cobrança SaaS serão sincronizadas após a ativação do webhook Asaas.
        </div>
      </section>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 font-semibold">{value}</div>
    </div>
  );
}

function PlanosDisponiveis({
  plans,
  planoAtual,
  canManage,
  subscribing,
  onAssinar,
}: {
  plans: SaasPlan[];
  planoAtual: string | null;
  canManage: boolean;
  subscribing: SaasPlanSlug | null;
  onAssinar: (slug: SaasPlanSlug) => void;
}) {
  const ordered = useMemo(() => {
    const known = plans.filter((p) => isSaasPlanSlug(p.slug));
    return [...known].sort((a, b) => Number(a.price_monthly) - Number(b.price_monthly));
  }, [plans]);

  return (
    <section>
      <div className="mb-3">
        <h2 className="font-display text-xl font-bold">Planos disponíveis</h2>
        <p className="text-sm text-muted-foreground">
          Escolha o plano que melhor se encaixa no seu negócio
        </p>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {ordered.map((p) => {
          const slug = p.slug as SaasPlanSlug;
          const copy = PLAN_COPY[slug];
          const Icon = copy.icon;
          const atual = planoAtual === slug;
          const busy = subscribing === slug;
          return (
            <div
              key={p.slug}
              className={`relative rounded-2xl border bg-card p-6 transition ${
                copy.destaque ? "border-gold/50 shadow-glow" : ""
              } ${atual ? "ring-2 ring-gold" : ""}`}
            >
              {copy.destaque && (
                <span className="absolute -top-3 left-6 rounded-full bg-gradient-gold px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-gold-foreground shadow-glow">
                  Mais popular
                </span>
              )}
              {atual && (
                <span className="absolute -top-3 right-6 rounded-full bg-emerald-500 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-white">
                  Plano atual
                </span>
              )}
              <div className="flex items-center gap-3">
                <div
                  className={`grid h-11 w-11 place-items-center rounded-xl ${copy.destaque ? "bg-gradient-gold text-gold-foreground" : "bg-muted text-foreground"}`}
                >
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <div className="font-display text-xl font-bold">{p.name}</div>
                  <div className="text-xs text-muted-foreground">{copy.descricao}</div>
                </div>
              </div>

              <div className="mt-5 flex items-baseline gap-1">
                <span className="text-3xl font-bold tracking-tight">
                  R$ {formatSaasPrice(Number(p.price_monthly))}
                </span>
                <span className="text-sm text-muted-foreground">/mês</span>
              </div>

              <ul className="mt-5 space-y-2.5">
                {copy.recursos.map((r) => (
                  <li key={r} className="flex items-start gap-2 text-sm">
                    <Check
                      className={`mt-0.5 h-4 w-4 shrink-0 ${copy.destaque ? "text-gold" : "text-emerald-600"}`}
                    />
                    <span>{r}</span>
                  </li>
                ))}
              </ul>

              <button
                type="button"
                onClick={() => onAssinar(slug)}
                disabled={atual || !canManage || !!subscribing}
                className={`mt-6 w-full rounded-lg px-4 py-2.5 text-sm font-semibold transition disabled:opacity-60 ${
                  copy.destaque
                    ? "bg-gradient-gold text-gold-foreground shadow-glow hover:opacity-90"
                    : "border bg-background hover:bg-muted"
                }`}
              >
                {atual
                  ? "Plano atual"
                  : busy
                    ? "Preparando pagamento..."
                    : !canManage
                      ? "Somente owner/admin"
                      : `Assinar ${p.name}`}
              </button>
            </div>
          );
        })}
        {ordered.length === 0 && (
          <div className="col-span-full rounded-lg border bg-card p-4 text-center text-sm text-muted-foreground">
            Planos indisponíveis no momento.
          </div>
        )}
      </div>
    </section>
  );
}
