import { createFileRoute } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { requireAdmin } from "@/lib/admin-guard";
import { useAuth } from "@/hooks/use-auth";
import { AREAS_OPCIONAIS, ROTULO_AREA, type AreaOpcional } from "@/lib/project-area";
import {
  useProjectAreaVisibility,
  useUpdateProjectAreaVisibility,
} from "@/hooks/use-project-area-visibility";
import type { ProjectAreaVisibility } from "@/lib/project-area-visibility";

/**
 * Configurações GLOBAIS da plataforma.
 *
 * `requireAdmin` / `useAuth().isAdmin` = Super Admin de PLATAFORMA
 * (`user_roles.role = 'admin'` ≡ `is_platform_admin()` no banco).
 *
 * NÃO confundir com admin da EMPRESA (`company_members.role = 'admin'`),
 * que não passa neste guard e não vê o item no menu (`adminOnly: true`).
 */
export const Route = createFileRoute("/_authenticated/app/admin/configuracoes")({
  beforeLoad: requireAdmin,
  component: ConfiguracoesAdminPage,
});

const DESCRICAO_TOGGLE: Record<AreaOpcional, string> = {
  esquadrias: "Portas, janelas, fachadas e sistemas de alumínio.",
  serralheria: "Portões, grades, estruturas e esquadrias de aço.",
  marcenaria: "Armários, painéis, closets e móveis planejados.",
  marmoraria: "Bancadas, soleiras, cubas e peças em pedra.",
};

function ConfiguracoesAdminPage() {
  const { isAdmin, loading: authLoading } = useAuth();
  const { data: visibility, isLoading, isError, error } = useProjectAreaVisibility();
  const update = useUpdateProjectAreaVisibility();

  if (authLoading || !isAdmin) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center text-sm text-muted-foreground">
        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Carregando…
      </div>
    );
  }

  const current: ProjectAreaVisibility = visibility ?? {
    esquadrias: true,
    serralheria: false,
    marcenaria: false,
    marmoraria: false,
  };

  const salvar = async (area: AreaOpcional, enabled: boolean) => {
    const next = { ...current, [area]: enabled };
    try {
      await update.mutateAsync(next);
      toast.success(
        enabled
          ? `${ROTULO_AREA[area]} ativada para criação de projetos.`
          : `${ROTULO_AREA[area]} ocultada do modal Novo projeto.`,
      );
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Não foi possível salvar a configuração.");
    }
  };

  return (
    <div className="mx-auto max-w-3xl space-y-8 p-4 md:p-6">
      <header>
        <h1 className="font-display text-2xl font-bold">Configurações</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Preferências globais da plataforma. Alterações valem para todos os usuários.
        </p>
      </header>

      <section className="rounded-2xl border border-border bg-card p-5 shadow-sm">
        <h2 className="font-display text-lg font-semibold">Tipos de projeto</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Controla quais tipos aparecem no modal <strong>Novo projeto</strong>. Projetos já
          cadastrados continuam acessíveis mesmo se o tipo for desativado.
        </p>

        {isLoading ? (
          <p className="mt-6 flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Carregando configuração…
          </p>
        ) : isError ? (
          <p className="mt-6 text-sm text-destructive">
            {error instanceof Error ? error.message : "Falha ao carregar configuração."}
          </p>
        ) : (
          <ul className="mt-6 divide-y divide-border">
            <li className="flex items-start justify-between gap-4 py-4">
              <div>
                <div className="font-semibold">{ROTULO_AREA.vidracaria}</div>
                <div className="mt-0.5 text-xs text-muted-foreground">
                  Box, janelas, portas, guarda-corpos e espelhos.
                </div>
              </div>
              <span className="shrink-0 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-xs font-semibold text-emerald-700 dark:text-emerald-300">
                Ativo permanentemente
              </span>
            </li>

            {AREAS_OPCIONAIS.map((area) => (
              <li key={area} className="flex items-start justify-between gap-4 py-4">
                <div>
                  <div className="font-semibold">{ROTULO_AREA[area]}</div>
                  <div className="mt-0.5 text-xs text-muted-foreground">
                    {DESCRICAO_TOGGLE[area]}
                  </div>
                </div>
                <label className="inline-flex cursor-pointer items-center gap-2">
                  <span className="text-xs text-muted-foreground">
                    {current[area] ? "Ativo" : "Oculto"}
                  </span>
                  <input
                    type="checkbox"
                    className="h-5 w-9 cursor-pointer accent-primary"
                    checked={current[area]}
                    disabled={update.isPending}
                    onChange={(e) => void salvar(area, e.target.checked)}
                  />
                </label>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
