import { createFileRoute } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  EnterpriseCrudPage,
  type CrudItem,
  type FieldConfig,
} from "@/components/EnterpriseCrudPage";
import { getPaymentShareExample } from "@/modules/payments/paymentService";
import {
  Banknote,
  CreditCard,
  Link as LinkIcon,
  Mail,
  QrCode,
  ReceiptText,
  Repeat,
  Smartphone,
  WalletCards,
  type LucideIcon,
} from "lucide-react";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";

/** ROTA OCULTA (Revisão 227) — VersaGlass Pay. Código preservado; acesso bloqueado. */
export const Route = createFileRoute("/_authenticated/app/pay")({
  beforeLoad: hiddenRouteBeforeLoad,
  component: VersaGlassPayPage,
});

const accountFields: FieldConfig[] = [
  { key: "company_name", label: "Nome da empresa" },
  { key: "cnpj", label: "CNPJ" },
  {
    key: "provider",
    label: "Provedor",
    type: "select",
    options: ["asaas", "efi", "iugu", "mercado_pago", "pagarme"],
  },
  { key: "marketplace_account_id", label: "Marketplace Account ID" },
  { key: "bank_name", label: "Banco" },
  { key: "agency", label: "Agência" },
  { key: "account_number", label: "Conta" },
  {
    key: "account_type",
    label: "Tipo de conta",
    type: "select",
    options: ["corrente", "poupanca", "pagamento"],
  },
  { key: "pix_key", label: "Chave PIX" },
  { key: "financial_email", label: "E-mail financeiro" },
  { key: "financial_phone", label: "Telefone financeiro" },
  {
    key: "platform_fee_type",
    label: "Tipo de taxa",
    type: "select",
    options: ["fixed", "percentage"],
  },
  { key: "platform_fee_value", label: "Taxa da plataforma", type: "currency" },
  {
    key: "status",
    label: "Status",
    type: "select",
    options: ["pending", "active", "blocked", "rejected"],
  },
];

const chargeFields: FieldConfig[] = [
  { key: "customer_name", label: "Cliente" },
  { key: "sale_id", label: "Venda" },
  { key: "order_service_id", label: "Ordem de serviço" },
  {
    key: "payment_method",
    label: "Forma",
    type: "select",
    options: ["pix", "boleto", "credit_card", "debit_card", "payment_link", "recurring"],
  },
  { key: "description", label: "Descrição" },
  { key: "amount", label: "Valor bruto", type: "currency" },
  { key: "platform_fee", label: "Taxa VersaGlass", type: "currency" },
  { key: "net_amount", label: "Valor líquido", type: "currency" },
  { key: "due_date", label: "Vencimento" },
  {
    key: "status",
    label: "Status",
    type: "select",
    options: ["pending", "paid", "overdue", "canceled", "refunded", "failed"],
  },
  { key: "payment_link", label: "Link de pagamento" },
  { key: "boleto_url", label: "Boleto PDF" },
  { key: "pix_copy_paste", label: "PIX copia e cola" },
  { key: "provider_charge_id", label: "ID provedor" },
];

const recurringFields: FieldConfig[] = [
  { key: "customer_name", label: "Cliente" },
  { key: "amount", label: "Valor", type: "currency" },
  {
    key: "payment_method",
    label: "Forma",
    type: "select",
    options: ["pix", "boleto", "credit_card", "payment_link"],
  },
  {
    key: "frequency",
    label: "Frequência",
    type: "select",
    options: ["weekly", "biweekly", "monthly", "quarterly", "yearly"],
  },
  { key: "start_date", label: "Data inicial" },
  { key: "end_date", label: "Data final" },
  { key: "next_charge_date", label: "Próxima cobrança" },
  {
    key: "status",
    label: "Status",
    type: "select",
    options: ["active", "paused", "finished", "canceled"],
  },
];

const accountData: CrudItem[] = [
  {
    id: "acc1",
    company_name: "Vidraçaria Exemplo",
    cnpj: "00.000.000/0001-00",
    provider: "asaas",
    marketplace_account_id: "asaas_company_demo",
    bank_name: "Banco exemplo",
    agency: "0001",
    account_number: "12345-6",
    account_type: "corrente",
    pix_key: "financeiro@empresa.com",
    financial_email: "financeiro@empresa.com",
    financial_phone: "27999999999",
    platform_fee_type: "fixed",
    platform_fee_value: 20,
    status: "active",
  },
];

const chargeData: CrudItem[] = [
  {
    id: "ch1",
    customer_name: "Cliente exemplo",
    sale_id: "VEN-001",
    order_service_id: "OS-001",
    payment_method: "pix",
    description: "Porta de vidro temperado",
    amount: 1000,
    platform_fee: 20,
    net_amount: 980,
    due_date: "2026-07-10",
    status: "pending",
    payment_link: "https://pagamento.exemplo/ch1",
    pix_copy_paste: "000201010212...",
    provider_charge_id: "demo_ch1",
  },
  {
    id: "ch2",
    customer_name: "Cliente recorrente",
    sale_id: "",
    order_service_id: "OS-002",
    payment_method: "boleto",
    description: "Parcela instalação",
    amount: 850,
    platform_fee: 17,
    net_amount: 833,
    due_date: "2026-07-12",
    status: "paid",
    boleto_url: "https://boleto.exemplo/ch2.pdf",
    provider_charge_id: "demo_ch2",
  },
];

const recurringData: CrudItem[] = [
  {
    id: "rec1",
    customer_name: "Cliente mensal",
    amount: 499,
    payment_method: "credit_card",
    frequency: "monthly",
    start_date: "2026-07-01",
    end_date: "2027-07-01",
    next_charge_date: "2026-08-01",
    status: "active",
  },
];

function brl(v: number) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v);
}

function VersaGlassPayPage() {
  const example = getPaymentShareExample(1000, 20);
  return (
    <div className="space-y-6">
      <div>
        <Badge variant="secondary" className="mb-3">
          VersaGlass Pay
        </Badge>
        <h1 className="font-display text-3xl font-bold">Cobranças, PIX, boleto, cartão e split</h1>
        <p className="mt-2 max-w-4xl text-sm text-muted-foreground">
          Cada empresa configura a própria conta de recebimento, gera cobranças e recebe
          diretamente. A taxa da plataforma é registrada no split, mantendo isolamento multiusuário
          por empresa.
        </p>
      </div>
      <div className="grid gap-4 md:grid-cols-4">
        <Metric title="Recebido" value={brl(850)} icon={WalletCards} />
        <Metric title="Pendente" value={brl(1000)} icon={QrCode} />
        <Metric title="Taxas VersaGlass" value={brl(37)} icon={ReceiptText} />
        <Metric title="Previsão" value={brl(1833)} icon={Banknote} />
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Exemplo de split automático</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-3">
          <div className="rounded-xl border p-4">
            <div className="text-xs text-muted-foreground">Valor bruto</div>
            <div className="text-2xl font-bold">{brl(example.gross_amount)}</div>
          </div>
          <div className="rounded-xl border p-4">
            <div className="text-xs text-muted-foreground">Taxa VersaGlass</div>
            <div className="text-2xl font-bold text-amber-500">{brl(example.platform_amount)}</div>
          </div>
          <div className="rounded-xl border p-4">
            <div className="text-xs text-muted-foreground">Vidraçaria recebe</div>
            <div className="text-2xl font-bold text-emerald-500">{brl(example.company_amount)}</div>
          </div>
        </CardContent>
      </Card>
      <Tabs defaultValue="charges" className="space-y-4">
        <TabsList className="flex w-fit flex-wrap">
          <TabsTrigger value="charges">Cobranças</TabsTrigger>
          <TabsTrigger value="accounts">Conta de recebimento</TabsTrigger>
          <TabsTrigger value="recurring">Recorrência</TabsTrigger>
          <TabsTrigger value="send">Envios</TabsTrigger>
        </TabsList>
        <TabsContent value="charges">
          <EnterpriseCrudPage
            title="Cobranças"
            subtitle="Gere cobranças por PIX, boleto, cartão, débito, link de pagamento e recorrência. O webhook atualiza a baixa automática e o financeiro."
            badge="PIX • Boleto • Cartão"
            storageKey="vmm_pay_charges"
            initialData={chargeData}
            fields={chargeFields}
            highlight={[
              "customer_name",
              "payment_method",
              "amount",
              "platform_fee",
              "net_amount",
              "status",
            ]}
          />
        </TabsContent>
        <TabsContent value="accounts">
          <EnterpriseCrudPage
            title="Conta de recebimento"
            subtitle="Dados bancários e marketplace_account_id por empresa. Essas informações são isoladas por RLS no Supabase."
            badge="Configuração por empresa"
            storageKey="vmm_pay_accounts"
            initialData={accountData}
            fields={accountFields}
            highlight={[
              "company_name",
              "provider",
              "bank_name",
              "pix_key",
              "platform_fee_value",
              "status",
            ]}
          />
        </TabsContent>
        <TabsContent value="recurring">
          <EnterpriseCrudPage
            title="Cobranças recorrentes"
            subtitle="Crie cobranças semanais, quinzenais, mensais, trimestrais ou anuais com próxima cobrança automática."
            badge="Recorrência"
            storageKey="vmm_pay_recurring"
            initialData={recurringData}
            fields={recurringFields}
            highlight={[
              "customer_name",
              "amount",
              "payment_method",
              "frequency",
              "next_charge_date",
              "status",
            ]}
          />
        </TabsContent>
        <TabsContent value="send">
          <Card>
            <CardContent className="grid gap-3 p-4 md:grid-cols-3">
              <Button className="gap-2">
                <Smartphone className="h-4 w-4" /> Enviar cobrança por WhatsApp
              </Button>
              <Button variant="outline" className="gap-2">
                <Mail className="h-4 w-4" /> Enviar por e-mail
              </Button>
              <Button variant="outline" className="gap-2">
                <LinkIcon className="h-4 w-4" /> Copiar link
              </Button>
              <Button variant="outline" className="gap-2">
                <QrCode className="h-4 w-4" /> Gerar QR Code PIX
              </Button>
              <Button variant="outline" className="gap-2">
                <ReceiptText className="h-4 w-4" /> Gerar boleto PDF
              </Button>
              <Button variant="outline" className="gap-2">
                <Repeat className="h-4 w-4" /> Criar recorrência
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function Metric({ title, value, icon: Icon }: { title: string; value: string; icon: LucideIcon }) {
  return (
    <Card>
      <CardContent className="flex items-center gap-3 p-4">
        <div className="rounded-xl bg-gold/15 p-3">
          <Icon className="h-5 w-5 text-gold" />
        </div>
        <div>
          <div className="text-xs text-muted-foreground">{title}</div>
          <div className="text-xl font-bold">{value}</div>
        </div>
      </CardContent>
    </Card>
  );
}
