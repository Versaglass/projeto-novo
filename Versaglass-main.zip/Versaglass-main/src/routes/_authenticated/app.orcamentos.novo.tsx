import { createFileRoute, useNavigate, type SearchSchemaInput } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { brl } from "@/lib/format";
import {
  numeroParaTexto,
  textoParaNumero,
  validaCamposNumericos,
  arredonda,
} from "@/lib/numero-campo";
import {
  Plus,
  Trash2,
  Layers,
  Check,
  ArrowLeft,
  ImageIcon,
  Eye,
  X,
  ChevronLeft,
  ChevronRight,
  Search,
} from "lucide-react";
import { categoriaProjetoLabel } from "@/lib/project-category";
import { toast } from "sonner";
import {
  useSaveQuote,
  useCompanyCustomerOptions,
  quoteErrorMessage,
  type QuoteStatus,
} from "@/hooks/use-quotes";
import { useCompany } from "@/contexts/company-context";
import { useFinePermissions } from "@/hooks/use-fine-permission";
import { CustomerSearchField } from "@/components/quotes/CustomerSearchField";
import { CustomerDialog, type CustomerFormValues } from "@/components/customers/CustomerDialog";
import { toClientInput, clientErrorMessage } from "@/hooks/use-clients";
import {
  useProjectTemplateById,
  type ProjectTemplateCategoria,
} from "@/hooks/use-project-templates";
import { usePlatformCatalogItem } from "@/hooks/use-platform-project-catalog";
import {
  templateToQuoteItem,
  isHumanText,
  type TemplateSource,
} from "@/lib/template-to-quote-item";
import { espessuraParaChip, sincronizarEspessuraVidroNoProjectData } from "@/lib/quote-item-vidro";
import {
  AREAS_OPERACIONAIS,
  ehAreaOperacional,
  ROTULO_AREA,
  type AreaProjeto,
} from "@/lib/project-area";
import {
  ehSubtipoDaArea,
  ROTULO_SUBTIPO,
  subtiposDaArea,
  type SubtipoProjeto,
} from "@/lib/project-subtypes";
import { chaveDoGrupo } from "@/lib/project-template-groups";
import { mapearSubtipoParaTipoProjetoOrcamento } from "@/lib/mapear-subtipo-projeto";
import { normalizeProjectData, type ProjectData } from "@/types/project-data";
import { ListaRolavel } from "@/components/ui/lista-rolavel";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { StorageImage } from "@/components/StorageImage";
import {
  bucketForQuoteItemImage,
  itemPossuiImagem,
  obterImagemUrlDoItem,
  pathForQuoteItemImage,
  snapshotImagemUrlFromCatalog,
  snapshotImagemUrlFromTemplate,
} from "@/lib/quote-item-image";
import {
  useCompanyStockOptions,
  stockItemToQuoteItem,
  categoriaMeta,
  type StockPickerItem,
} from "@/hooks/use-inventory";
import {
  ehQuoteItemTipoProjeto,
  rotuloTipoProjetoOrcamento,
  tiposProjetoOrcamentoDaArea,
} from "@/lib/quote-item-tipo-helpers";
import type { QuoteItemTipoProjeto } from "@/lib/tipo-projeto-orcamento";

/**
 * Campos numéricos deste formulário — Revisão 33.
 *
 * Aqui está o dinheiro do orçamento do cliente: largura e altura formam o m²,
 * que multiplica o preço para dar o subtotal, e o desconto multiplica o total.
 * Todos usavam `<input type="number">` com `parseFloat(...) || 0`, o par exato
 * do defeito da Revisão 31 — o navegador descartava a vírgula de "89,90",
 * entregava `""` e o `|| 0` zerava, sem aviso, um valor que ia para o Postgres.
 *
 * O padrão é o mesmo dos outros 11 arquivos (`src/lib/numero-campo.ts`), na
 * variante usada onde o estado precisa ficar NUMÉRICO porque o subtotal é
 * recalculado a cada tecla (a mesma de `ProjectDrawingEditor` e `plano-corte`):
 * o texto digitado vive no campo, a conversão aceita vírgula e ponto, e o que
 * não é número NÃO é propagado — a medida anterior fica de pé.
 *
 * A diferença desta tela é que ela GRAVA. Então não basta não propagar: se o
 * campo mostra "abc" e o estado guarda a medida antiga, tela e banco divergem
 * em silêncio. Por isso cada campo se registra como inválido e o `save()`
 * RECUSA o envio nomeando o campo.
 */
type CampoInvalido = { label: string; texto: string };
type RegistroInvalido = (chave: string, invalido: CampoInvalido | null) => void;

const MSG_NUMERO_INVALIDO =
  "Valor inválido — use apenas números, com vírgula ou ponto na casa decimal (ex.: 1200 ou 89,90).";

// REMOVIDA: `TIPOS_PROJETO`, uma lista fixa de treze nomes de vidraçaria que
// agrupava o seletor de modelos comparando igualdade exata contra a coluna de
// TEXTO LIVRE `project_templates.tipo`. Modelo cujo `tipo` não estivesse na
// lista — todo o de serralheria, marcenaria e marmoraria — não aparecia em
// grupo nenhum. O agrupamento agora sai de `area` + `subtipo` (ver
// `chaveDoGrupo`), que são enum e constraint no banco, e a lista deixa de
// precisar ser mantida à mão a cada produto novo.
//
// O seletor **Tipo** usa enum fechado (`tipo_projeto`); **Descrição** é campo livre
// separado para detalhe comercial (Rev. 146).
const AMBIENTES_PRESET = [
  "Quarto",
  "Sala",
  "Cozinha",
  "Varanda",
  "Suite",
  "Hall",
  "Banheiro",
  "Lavanderia",
  "Lavabo",
  "Garagem",
  "Terraço",
  "Escada",
  "Outros",
  "Área Gourmet",
  "Closet",
  "Jardim de Inverno",
  "Escritório",
  "Loja",
  "Consultório",
] as const;

/** O que `Link`/`navigate` podem informar — tudo opcional, os defaults vêm do validateSearch. */
type NovoOrcamentoSearchInput = {
  cliente?: string;
  projeto?: string;
  templateId?: string;
  catalogId?: string;
  id?: string;
} & SearchSchemaInput;

/**
 * O que `Route.useSearch()` devolve.
 *
 * Todas as chaves são OPCIONAIS de propósito. A versão anterior devolvia
 * `string` com default `""`, e o router serializa o que recebe: uma chave com
 * string vazia vira `templateId=` na barra de endereço. Depois de importar o
 * modelo a URL ficava `?cliente=&projeto=&templateId=&id=` — a chave continuava
 * lá, só que vazia. Chave ausente é a única forma de remoção real.
 */
export type NovoOrcamentoSearch = {
  cliente?: string;
  projeto?: string;
  templateId?: string;
  /** Item do catálogo global (`platform_project_catalog`). Rev. 203. */
  catalogId?: string;
  id?: string;
};

/** Só entra no objeto de busca o que tem conteúdo — nunca `""` nem `undefined`. */
// eslint-disable-next-line react-refresh/only-export-components -- helper de search params exportado por arquivo de rota. Mover exigiria alterar `app.orcamentos.obra.tsx`, que está fora de escopo por decisão de produto pendente (Revisão 51).
export function searchOrcamentoNovo(valores: NovoOrcamentoSearch): NovoOrcamentoSearch {
  const saida: NovoOrcamentoSearch = {};
  for (const chave of ["cliente", "projeto", "templateId", "catalogId", "id"] as const) {
    const v = valores[chave];
    if (typeof v === "string" && v.trim() !== "") saida[chave] = v;
  }
  return saida;
}

export const Route = createFileRoute("/_authenticated/app/orcamentos/novo")({
  // `projeto` é o parâmetro ANTIGO do botão "Orçar". Mantido só para não
  // quebrar links já compartilhados; o fluxo atual usa `templateId`.
  // Chaves vazias são DESCARTADAS aqui também: um link antigo com
  // `?templateId=` não recria a chave na URL depois da normalização.
  validateSearch: (search: NovoOrcamentoSearchInput): NovoOrcamentoSearch =>
    searchOrcamentoNovo({
      cliente: search.cliente,
      projeto: search.projeto,
      templateId: search.templateId,
      catalogId: search.catalogId,
      id: search.id, // edição de orçamento existente
    }),
  component: NovoOrcamento,
});

// Item do formulário. `largura`/`altura` em MILÍMETROS aqui; a conversão para
// metros acontece no envio à RPC.
//
// `drawing_data`/`drawing_notes` acompanham o item apenas para serem
// DEVOLVIDOS à RPC na edição: ela apaga e regrava os itens, então o que não for
// reenviado voltaria ao estado "sem desenho" (defeito corrigido pela migration
// 20260727030000). O formulário não edita esses campos — quem edita é o
// ProjectDrawingEditor, na tela de detalhes do orçamento.
type Item = {
  descricao: string;
  /** Enum comercial opcional — grava em `quote_items.tipo_projeto`. */
  tipo_projeto?: QuoteItemTipoProjeto | null;
  ambiente?: string | null;
  espessura?: string | null;
  largura: number;
  altura: number;
  quantidade: number;
  preco_unit: number;
  drawing_data?: unknown;
  drawing_notes?: string | null;
  /**
   * SNAPSHOT do desenho paramétrico do modelo, já validado. `null` = sem
   * desenho. Viaja no estado do formulário como qualquer outro campo do item —
   * editar descrição, preço, quantidade ou cliente não o descarta, porque as
   * alterações são feitas por spread sobre o item inteiro.
   */
  project_data?: ProjectData | null;
  /** Snapshot do path da foto copiada do modelo/catálogo (Rev. 220). */
  imagem_url?: string | null;
  /**
   * O banco tem um `project_data` que ESTE código não consegue interpretar.
   *
   * Estado próprio, e não `project_data: null`, porque os dois significam
   * coisas opostas: `null` é "não tem desenho" e pode ser salvo à vontade;
   * inválido é "tem desenho e não sabemos ler". Sem essa distinção, salvar uma
   * troca de preço enviaria `project_data: null` e APAGARIA em silêncio um dado
   * que talvez uma versão futura soubesse ler. Enquanto a marca estiver ligada,
   * o salvamento fica bloqueado e a remoção precisa ser pedida explicitamente.
   */
  projectDataInvalido?: boolean;
  /**
   * Só UI (Rev. 199) — não vai para a RPC. Marca item de estoque cobrado por
   * unidade (`unidade !== "m2"`), para esconder L×A×espessura. Estoque m² e
   * modelos técnicos usam o layout completo (`"padrao"` / omitido).
   */
  origemUi?: "padrao" | "estoque_unidade";
  /**
   * Snapshot persistido: projeto direto / estoque originado de projeto → true.
   * Item manual e estoque comum → false. PDF usa este flag (+ fallback estruturado).
   */
  originado_de_projeto?: boolean;
};

/** Linha manual vazia — usada só quando o usuário pede "Adicionar item". */
function itemEmBranco(): Item {
  return {
    descricao: "",
    tipo_projeto: null,
    ambiente: null,
    largura: 0,
    altura: 0,
    quantidade: 1,
    preco_unit: 0,
    origemUi: "padrao",
    originado_de_projeto: false,
  };
}

/** Item ainda sem conteúdo — mostra "Aplicar projeto" / "+ Estoque" (Rev. 199). */
function itemEstaVazio(it: Item): boolean {
  return (
    !it.descricao.trim() &&
    !it.tipo_projeto &&
    it.largura === 0 &&
    it.altura === 0 &&
    !(it.preco_unit > 0) &&
    !it.project_data &&
    !it.projectDataInvalido
  );
}

/** Layout simplificado (sem dimensão/espessura) — estoque por unidade. */
function itemLayoutEstoqueUnidade(it: Item): boolean {
  return it.origemUi === "estoque_unidade";
}

/** Linha de quote_items carregada na edição — espelho do `.select(...)`. */
type EditingItemRow = {
  descricao: string | null;
  tipo_projeto: QuoteItemTipoProjeto | null;
  ambiente: string | null;
  largura: number;
  altura: number;
  quantidade: number;
  preco_unit: number;
  ordem: number;
  drawing_data: unknown;
  drawing_notes: string | null;
  project_data: unknown;
  imagem_url: string | null;
  originado_de_projeto?: boolean | null;
};

/** Modelo no seletor "Aplicar projeto" — colunas do `.select` + TemplateSource. */
type PickerTemplate = TemplateSource & {
  id: string;
  area: string;
  subtipo: string;
  categoria: ProjectTemplateCategoria;
  imagem_url: string | null;
  origem: "empresa" | "global";
  imageBucket: "project-images" | "platform-catalog";
};

function NovoOrcamento() {
  const navigate = useNavigate();
  const busca = Route.useSearch();
  const cliente = busca.cliente ?? "";
  const projeto = busca.projeto ?? "";
  const templateId = busca.templateId ?? "";
  const catalogId = busca.catalogId ?? "";
  const editId = busca.id ?? "";
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;
  const { create_orcamentos: canCreate, edit_orcamentos: canEdit } = useFinePermissions();
  const canSaveQuote = editId ? canEdit : canCreate;
  const saveQuote = useSaveQuote();
  const qc = useQueryClient();
  const [customerId, setCustomerId] = useState(cliente);
  const [newCustomerOpen, setNewCustomerOpen] = useState(false);
  const [projectPicker, setProjectPicker] = useState<number | null>(null);
  const [stockPicker, setStockPicker] = useState<number | null>(null);
  // Rev. 240 — modal único com a foto do item (`imagem_url` local ou do banco).
  const [fotoPreviewUrl, setFotoPreviewUrl] = useState<string | null>(null);
  const appliedRef = useRef(false);
  const editLoadedRef = useRef(false);
  const [obs, setObs] = useState("");
  const [descontoPct, setDescontoPct] = useState(0);
  // Acréscimo e validade não têm campo próprio neste formulário; preservamos os
  // valores existentes ao editar para não zerá-los na regravação.
  const [acrescimo, setAcrescimo] = useState(0);
  const [validadeDias, setValidadeDias] = useState(15);

  // Criação nova: lista realmente vazia (sem placeholder). Edição / ?catalogId /
  // ?templateId preenchem depois via efeitos ou load.
  const [items, setItems] = useState<Item[]>([]);
  const [saving, setSaving] = useState(false);

  // Campos numéricos com texto ilegível na tela (Revisão 33). Cada `NumberField`
  // /`NumberRow` se registra aqui e o `save()` recusa enquanto houver algum —
  // ver o comentário de `CampoInvalido` no topo do arquivo.
  const [camposInvalidos, setCamposInvalidos] = useState<Record<string, CampoInvalido>>({});
  const registrarInvalido = useCallback<RegistroInvalido>((chave, invalido) => {
    setCamposInvalidos((atual) => {
      if (!invalido) {
        if (!(chave in atual)) return atual; // evita re-render à toa
        const { [chave]: _removido, ...resto } = atual;
        return resto;
      }
      const anterior = atual[chave];
      if (anterior && anterior.label === invalido.label && anterior.texto === invalido.texto)
        return atual;
      return { ...atual, [chave]: invalido };
    });
  }, []);

  // Clientes SOMENTE da empresa ativa (isolamento).
  const { data: customers = [], isLoading: customersLoading } = useCompanyCustomerOptions();

  const createCustomer = useMutation({
    mutationFn: async (form: CustomerFormValues) => {
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Não autenticado");
      const { data, error } = await supabase
        .from("customers")
        .insert({ ...toClientInput(form), owner_id: u.user.id, company_id: companyId })
        .select("id")
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: (c) => {
      toast.success("Cliente cadastrado");
      qc.invalidateQueries({ queryKey: ["quote-customer-options"] });
      qc.invalidateQueries({ queryKey: ["customers-orc"] });
      qc.invalidateQueries({ queryKey: ["clients"] });
      // Seleciona o cliente recém-criado no formulário (mesmo fluxo anterior).
      setCustomerId(c.id);
      setNewCustomerOpen(false);
    },
    onError: (e: unknown) => toast.error(e instanceof Error ? e.message : clientErrorMessage(e)),
  });

  // Edição: carrega o orçamento existente, filtrado por id E company_id (empresa
  // ativa) — a RLS também impede ler de outra empresa.
  const { data: editing } = useQuery({
    queryKey: ["quote-edit-load", companyId, editId],
    enabled: !!editId && !!companyId,
    queryFn: async () => {
      if (!companyId) return null;
      const { data: quote, error } = await supabase
        .from("quotes")
        .select("id,numero,customer_id,observacoes,desconto,acrescimo,validade_dias")
        .eq("id", editId)
        .eq("company_id", companyId)
        .maybeSingle();
      if (error) throw error;
      if (!quote) return null;
      const { data: its } = await supabase
        .from("quote_items")
        // drawing_data/drawing_notes vêm junto para poderem ser DEVOLVIDOS à RPC
        // — sem isso a regravação apagaria o desenho técnico do item.
        .select(
          "descricao,tipo_projeto,ambiente,largura,altura,quantidade,preco_unit,ordem,drawing_data,drawing_notes,project_data,imagem_url",
        )
        .eq("quote_id", editId)
        .order("ordem");
      return { quote, items: its ?? [] };
    },
  });

  // Prefill único ao chegar os dados de edição (medidas em metros → mm no form).
  useEffect(() => {
    if (!editing?.quote || editLoadedRef.current) return;
    editLoadedRef.current = true;
    setCustomerId(editing.quote.customer_id);
    setObs(editing.quote.observacoes ?? "");
    setAcrescimo(Number(editing.quote.acrescimo) || 0);
    setValidadeDias(Number(editing.quote.validade_dias) || 15);
    // Snapshot validado na ENTRADA. Ilegível não derruba a tela e NÃO é
    // convertido em `null`: vira `projectDataInvalido`, que bloqueia o
    // salvamento até uma decisão explícita. Assim o valor no banco não se perde
    // por causa de uma edição de preço.
    let algumDesenhoIlegivel = false;
    const loadedItems: Item[] = (editing.items as EditingItemRow[]).map((i) => {
      const bruto = i.project_data;
      const snapshot = bruto == null ? null : normalizeProjectData(bruto);
      const invalido = bruto != null && snapshot === null;
      if (invalido) algumDesenhoIlegivel = true;
      return {
        descricao: i.descricao ?? "",
        tipo_projeto: i.tipo_projeto ?? null,
        ambiente: i.ambiente ?? null,
        // Chip de espessura: restaura de `project_data.espessuraVidro` (não da descrição).
        espessura: espessuraParaChip(snapshot?.espessuraVidro),
        largura: Math.round(Number(i.largura) * 1000),
        altura: Math.round(Number(i.altura) * 1000),
        quantidade: Number(i.quantidade) || 1,
        preco_unit: Number(i.preco_unit) || 0,
        drawing_data: i.drawing_data,
        drawing_notes: i.drawing_notes ?? null,
        project_data: snapshot,
        projectDataInvalido: invalido,
        imagem_url: i.imagem_url ?? null,
        originado_de_projeto: i.originado_de_projeto === true,
        // Sem FK de estoque no banco: heurística na reabertura — sem mm e sem
        // desenho de modelo ⇒ layout de unidade (LED etc.).
        origemUi:
          !invalido &&
          snapshot == null &&
          Math.round(Number(i.largura) * 1000) === 0 &&
          Math.round(Number(i.altura) * 1000) === 0
            ? "estoque_unidade"
            : "padrao",
      };
    });
    if (algumDesenhoIlegivel) {
      toast.warning(
        "O desenho paramétrico de um ou mais itens está inválido e não pode ser carregado.",
      );
    }
    if (loadedItems.length) setItems(loadedItems);
    const sub = loadedItems.reduce(
      (s, it) => s + (it.largura / 1000) * (it.altura / 1000) * it.quantidade * it.preco_unit,
      0,
    );
    const desc = Number(editing.quote.desconto) || 0;
    setDescontoPct(sub > 0 ? Math.round((desc / sub) * 10000) / 100 : 0);
  }, [editing]);

  // EMPRESA ATIVA NA CHAVE E NO FILTRO.
  //
  // Faltavam as duas coisas. A RLS impede LER modelo de outro tenant, então
  // nunca houve vazamento pelo servidor — mas o cache do React Query é do
  // navegador e era indexado por uma chave constante: quem trocasse de empresa
  // ativa continuava vendo a lista da empresa anterior até o cache expirar, com
  // os modelos certos só voltando depois de um refetch. `enabled` evita a
  // consulta sem empresa, e o `eq` explícito deixa de depender só da policy —
  // toda outra consulta deste módulo já escopa assim.
  // Catálogo global + modelos da empresa → picker "Aplicar projeto".
  const { data: templates = [] } = useQuery({
    queryKey: ["project-picker-unified", companyId],
    enabled: !!companyId,
    queryFn: async (): Promise<PickerTemplate[]> => {
      const [catalogRes, templatesRes] = await Promise.all([
        supabase
          .from("platform_project_catalog")
          .select(
            "id,area,subtipo,categoria,nome,descricao,espessura,largura_padrao,altura_padrao,preco_referencia_m2,imagem_url,observacoes,project_data",
          )
          .eq("ativo", true)
          .order("area")
          .order("subtipo")
          .order("nome"),
        supabase
          .from("project_templates")
          .select(
            "id,area,subtipo,categoria,nome,descricao,espessura,largura_padrao,altura_padrao,preco_m2,imagem_url,observacoes,project_data,tipo",
          )
          .eq("company_id", companyId!)
          .eq("ativo", true)
          .order("area")
          .order("subtipo")
          .order("nome"),
      ]);
      if (catalogRes.error) throw catalogRes.error;
      if (templatesRes.error) throw templatesRes.error;

      const globais: PickerTemplate[] = (
        (catalogRes.data ?? []) as Array<Record<string, unknown>>
      ).map((row) => ({
        id: String(row.id),
        area: String(row.area ?? ""),
        subtipo: String(row.subtipo ?? ""),
        categoria: row.categoria as ProjectTemplateCategoria,
        tipo: null,
        nome: String(row.nome ?? ""),
        descricao: (row.descricao as string | null) ?? null,
        espessura: (row.espessura as string | null) ?? null,
        largura_padrao: Number(row.largura_padrao) || 0,
        altura_padrao: Number(row.altura_padrao) || 0,
        preco_m2: Number(row.preco_referencia_m2) || 0,
        imagem_url: (row.imagem_url as string | null) ?? null,
        observacoes: (row.observacoes as string | null) ?? null,
        project_data: row.project_data ?? null,
        origem: "global" as const,
        imageBucket: "platform-catalog" as const,
      }));

      const empresa: PickerTemplate[] = (
        (templatesRes.data ?? []) as Array<Record<string, unknown>>
      ).map((row) => ({
        id: String(row.id),
        area: String(row.area ?? ""),
        subtipo: String(row.subtipo ?? ""),
        categoria: row.categoria as ProjectTemplateCategoria,
        tipo: (row.tipo as string | null) ?? null,
        nome: String(row.nome ?? ""),
        descricao: (row.descricao as string | null) ?? null,
        espessura: (row.espessura as string | null) ?? null,
        largura_padrao: Number(row.largura_padrao) || 0,
        altura_padrao: Number(row.altura_padrao) || 0,
        preco_m2: Number(row.preco_m2) || 0,
        imagem_url: (row.imagem_url as string | null) ?? null,
        observacoes: (row.observacoes as string | null) ?? null,
        project_data: row.project_data ?? null,
        origem: "empresa" as const,
        imageBucket: "project-images" as const,
      }));

      return [...empresa, ...globais].sort((a, b) => {
        const ka = `${a.area}|${a.subtipo}|${a.nome}`;
        const kb = `${b.area}|${b.subtipo}|${b.nome}`;
        return ka.localeCompare(kb, "pt-BR");
      });
    },
  });

  // Estoque é OPCIONAL no orçamento: só itens ATIVOS da empresa ativa. Se a lista
  // vier vazia (ou a empresa não usar estoque), o item manual continua sendo o
  // caminho normal — nada aqui bloqueia a criação do orçamento.
  const { data: stockItems = [] } = useCompanyStockOptions();

  // "Aplicar projeto" é o SEGUNDO caminho modelo → item (o primeiro é o botão
  // "Orçar", que chega por `?templateId=`). Passa pelo MESMO conversor para não
  // haver duas regras de importação: aqui também vem o snapshot paramétrico.
  //
  // Não pede confirmação de medida: o usuário não está ajustando uma dimensão,
  // está trocando a origem do item inteiro — e substituir o desenho junto é
  // justamente o que evita deixar uma geometria que não corresponde às medidas.
  // `idx < 0` = adicionar linha nova (estado vazio / CTA sem placeholder).
  const applyTemplate = (idx: number, t: PickerTemplate) => {
    const imagemSnapshot =
      t.origem === "global"
        ? (snapshotImagemUrlFromCatalog(t.imagem_url) ?? t.imagem_url ?? null)
        : (snapshotImagemUrlFromTemplate(t.imagem_url) ?? t.imagem_url ?? null);
    const { item: convertido, desenhoInvalido } = templateToQuoteItem({
      ...t,
      imagem_url: imagemSnapshot,
    });
    if (desenhoInvalido) {
      toast.warning(
        "O modelo foi importado sem o desenho paramétrico porque os dados do desenho são inválidos.",
      );
    }
    const patch: Partial<Item> = {
      descricao: convertido.descricao,
      largura: convertido.largura,
      altura: convertido.altura,
      preco_unit: convertido.preco_unit,
      project_data: convertido.project_data,
      imagem_url: convertido.imagem_url,
      // Rev. 198 — select "Tipo" pré-preenchido quando o subtipo tem par no enum.
      tipo_projeto: mapearSubtipoParaTipoProjetoOrcamento(
        typeof t.subtipo === "string" ? t.subtipo : null,
      ),
      espessura: espessuraParaChip(t.espessura),
      origemUi: "padrao",
      originado_de_projeto: true,
    };
    if (idx < 0) {
      setItems((arr) => [...arr, { ...itemEmBranco(), ...patch }]);
    } else {
      setItem(idx, patch);
    }
    setProjectPicker(null);
  };

  // Preenchimento a partir do Estoque — conveniência, não vínculo. O que for
  // gravado em `quote_items` é um SNAPSHOT: descrição, preço, dimensões e
  // quantidade continuam totalmente editáveis aqui, e alterar o item no Estoque
  // depois NÃO altera este orçamento nem os já salvos. Nenhum saldo é reservado
  // ou baixado — o Estoque não é movimentado pelo orçamento.
  // `idx < 0` = adicionar linha nova (estado vazio / CTA sem placeholder).
  const applyStockItem = (idx: number, s: StockPickerItem) => {
    const preenchido = stockItemToQuoteItem(s);
    const patch: Partial<Item> = {
      descricao: preenchido.descricao,
      largura: preenchido.largura,
      altura: preenchido.altura,
      preco_unit: preenchido.preco_unit,
      // O item passou a representar outro produto, com outras medidas: manter o
      // desenho paramétrico de um modelo anterior deixaria uma geometria que não
      // corresponde a nada. Item de estoque não tem desenho, então o slot fica
      // sem. `drawing_data`/`drawing_notes` não são tocados.
      project_data: null,
      // Snapshot do path no Storage (mesmo bucket da Biblioteca) — não signed URL.
      imagem_url: preenchido.imagem_url,
      tipo_projeto: null,
      espessura: null,
      // Rev. 199 — layout sem L×A×espessura quando cobrado por unidade (LED etc.).
      origemUi: preenchido.porM2 ? "padrao" : "estoque_unidade",
      originado_de_projeto: preenchido.originado_de_projeto,
    };
    if (idx < 0) {
      setItems((arr) => [...arr, { ...itemEmBranco(), ...patch }]);
    } else {
      setItem(idx, patch);
    }
    setStockPicker(null);
    if (preenchido.porM2) {
      // Item vendido por m²: o preço entra como preço por m² e as dimensões ficam
      // com o usuário — medida não é inventada.
      toast.success(`${s.nome} aplicado. Informe largura e altura para cobrar por m².`);
    } else {
      toast.success(`${s.nome} aplicado — preço por ${s.unidade}.`);
    }
  };

  // ---------------------------------------------------------------------
  // Importação de MODELO TÉCNICO:
  //   · Projetos → "Orçar" → ?templateId=<uuid>
  //   · Lista de Projeto (obra.tsx, Rev. 195) → clique no card → mesma URL
  //   · "Aplicar projeto" no item (abaixo) usa o MESMO `templateToQuoteItem`
  //
  // O modelo é um MOLDE: o que entra aqui é uma cópia independente no estado
  // LOCAL do formulário. Nada é gravado no banco até o usuário salvar, e nenhum
  // update volta para `project_templates`.
  //
  // Contra duplicação, duas camadas:
  //   1. `templateId` é REMOVIDO da URL (replace) assim que o item entra — é a
  //      garantia PERSISTENTE: F5 depois disso não reimporta, e o histórico não
  //      guarda a importação;
  //   2. `appliedRef` cobre a janela entre o import e a limpeza da URL, para
  //      rerenders no mesmo ciclo não duplicarem.
  //
  // O parâmetro legado `?projeto=` é aceito como sinônimo, para links antigos.
  // ---------------------------------------------------------------------
  const templateSolicitado = templateId || projeto;
  const {
    data: templateImportado,
    isLoading: templateLoading,
    isError: templateError,
    companyLoading: templateCompanyLoading,
  } = useProjectTemplateById(templateSolicitado || null);

  const {
    data: catalogImportado,
    isLoading: catalogLoading,
    isError: catalogError,
  } = usePlatformCatalogItem(catalogId || null);

  const limparImportDaUrl = useCallback(() => {
    // Chaves de importação OMITIDAS (não zeradas). Inclui `catalogId` (Rev. 203).
    navigate({
      to: "/app/orcamentos/novo",
      search: searchOrcamentoNovo({ cliente, id: editId }),
      replace: true,
    });
  }, [navigate, cliente, editId]);

  useEffect(() => {
    if (!templateSolicitado || appliedRef.current) return;
    if (templateCompanyLoading || templateLoading) return;

    appliedRef.current = true;

    if (templateError || !templateImportado) {
      toast.error("Modelo técnico não encontrado ou indisponível");
      limparImportDaUrl();
      return;
    }

    const { item: novo, desenhoInvalido } = templateToQuoteItem(templateImportado);
    if (desenhoInvalido) {
      toast.warning(
        "O modelo foi importado sem o desenho paramétrico porque os dados do desenho são inválidos.",
      );
    }
    const tipo_projeto = mapearSubtipoParaTipoProjetoOrcamento(templateImportado.subtipo);
    setItems((cur) => {
      const soUmVazio = cur.length === 1 && itemEstaVazio(cur[0]);
      const linha = {
        ...novo,
        tipo_projeto,
        espessura: espessuraParaChip(templateImportado.espessura),
        origemUi: "padrao" as const,
      };
      return soUmVazio ? [linha] : [...cur, linha];
    });
    limparImportDaUrl();
  }, [
    templateSolicitado,
    templateImportado,
    templateLoading,
    templateError,
    templateCompanyLoading,
    limparImportDaUrl,
  ]);

  // Catálogo global → item. Snapshot via templateToQuoteItem (inclui project_data).
  useEffect(() => {
    if (!catalogId || appliedRef.current) return;
    if (catalogLoading) return;

    appliedRef.current = true;

    if (catalogError || !catalogImportado) {
      toast.error("Item do catálogo não encontrado ou indisponível");
      limparImportDaUrl();
      return;
    }

    const fonte: TemplateSource = {
      nome: catalogImportado.nome,
      descricao: catalogImportado.descricao,
      area: catalogImportado.area,
      categoria: catalogImportado.categoria,
      espessura: catalogImportado.espessura,
      largura_padrao: Number(catalogImportado.largura_padrao) || 0,
      altura_padrao: Number(catalogImportado.altura_padrao) || 0,
      preco_m2: Number(catalogImportado.preco_referencia_m2) || 0,
      observacoes: catalogImportado.observacoes,
      subtipo: catalogImportado.subtipo,
      project_data: catalogImportado.project_data,
      imagem_url: snapshotImagemUrlFromCatalog(catalogImportado.imagem_url),
    };
    const { item: novo, desenhoInvalido } = templateToQuoteItem(fonte);
    const tipo_projeto = mapearSubtipoParaTipoProjetoOrcamento(catalogImportado.subtipo);
    setItems((cur) => {
      const soUmVazio = cur.length === 1 && itemEstaVazio(cur[0]);
      const linha = {
        ...novo,
        tipo_projeto,
        espessura: espessuraParaChip(catalogImportado.espessura),
        origemUi: "padrao" as const,
      };
      return soUmVazio ? [linha] : [...cur, linha];
    });
    if (desenhoInvalido) {
      toast.warning(
        "O projeto foi importado sem o desenho paramétrico porque os dados do desenho são inválidos.",
      );
    }
    toast.success(`“${catalogImportado.nome}” aplicado do catálogo`);
    limparImportDaUrl();
  }, [catalogId, catalogImportado, catalogLoading, catalogError, limparImportDaUrl]);

  // Prévia (a RPC recalcula o total definitivo). Item COM dimensões: preço por m².
  // Item manual SEM dimensões: preço por unidade (quantidade × preço) — permite
  // orçar serviços/ferragens sem depender do Estoque.
  const enriched = useMemo(
    () =>
      items.map((it) => {
        const m2 = (it.largura / 1000) * (it.altura / 1000) * it.quantidade;
        const hasDims = it.largura > 0 && it.altura > 0;
        const subtotal = hasDims ? m2 * it.preco_unit : it.quantidade * it.preco_unit;
        return { ...it, m2, subtotal };
      }),
    [items],
  );

  const subtotalGeral = enriched.reduce((s, i) => s + i.subtotal, 0);
  const descontoValor = subtotalGeral * (descontoPct / 100);
  const total = Math.max(0, subtotalGeral - descontoValor);

  const setItem = (idx: number, patch: Partial<Item>) => {
    setItems((arr) => arr.map((it, i) => (i === idx ? { ...it, ...patch } : it)));
  };

  /**
   * Edição do SUBTOTAL → deriva `preco_unit` (Rev. 197).
   *
   * O banco / RPC continuam gravando só `preco_unit` e recalculando
   * subtotal = m²×preço (com dimensões) ou qtd×preço (sem). Esta função
   * inverte a fórmula da prévia para o usuário poder digitar o total da linha.
   *
   * · Com largura e altura > 0: preço/m² = subtotal ÷ m² (m² = L·A·qtd em metros).
   * · Sem dimensão: preço unitário = subtotal ÷ quantidade (mesmo eixo da prévia).
   * · Divisor zero: recusa (NumberField desfaz o texto).
   */
  const aplicarSubtotal = (idx: number, subtotalDesejado: number): boolean => {
    const atual = items[idx];
    if (!atual) return false;
    if (subtotalDesejado < 0) {
      toast.error("Subtotal não pode ser negativo.");
      return false;
    }

    const hasDims = atual.largura > 0 && atual.altura > 0;
    if (hasDims) {
      const m2 = (atual.largura / 1000) * (atual.altura / 1000) * atual.quantidade;
      if (!(m2 > 0)) {
        toast.error(
          "Informe largura, altura e quantidade maiores que zero para definir o subtotal por m².",
        );
        return false;
      }
      setItem(idx, { preco_unit: arredonda(subtotalDesejado / m2, 2) });
      return true;
    }

    if (!(atual.quantidade > 0)) {
      toast.error("Informe a quantidade para definir o subtotal.");
      return false;
    }
    setItem(idx, { preco_unit: arredonda(subtotalDesejado / atual.quantidade, 2) });
    return true;
  };

  /**
   * Alteração de MEDIDA num item que carrega desenho paramétrico.
   *
   * O desenho não é reescalado: perfis, ferragens, furos e recortes têm
   * dimensões FIXAS (um puxador de 40 mm continua com 40 mm numa porta maior).
   * Multiplicar tudo proporcionalmente produziria um projeto tecnicamente
   * errado e de aparência plausível — o pior tipo de erro. Enquanto não existir
   * edição paramétrica dentro do orçamento, mudar a medida DESCARTA o desenho,
   * e isso é perguntado antes.
   *
   * Só largura e altura passam por aqui. Preço, quantidade, descrição, desconto
   * e cliente não têm relação com a geometria e não disparam nada.
   */
  const setMedida = (idx: number, campo: "largura" | "altura", valor: number): boolean => {
    const atual = items[idx];
    if (!atual) return false;
    if (valor === atual[campo]) return true;

    if (!atual.project_data) {
      setItem(idx, { [campo]: valor } as Partial<Item>);
      return true;
    }
    const ok = window.confirm(
      "Alterar as medidas removerá o desenho paramétrico importado deste item. Deseja continuar?",
    );
    // Recusado: devolve `false` e o campo se corrige sozinho, na hora. Medida,
    // desenho e subtotal ficam exatamente como estavam, e nada entra no payload.
    if (!ok) return false;
    // `drawing_data` e `drawing_notes` NÃO são tocados: são o desenho técnico do
    // próprio orçamento, independente do paramétrico.
    setItem(idx, { [campo]: valor, project_data: null } as Partial<Item>);
    toast.info("O desenho paramétrico foi removido porque as medidas foram alteradas.");
    return true;
  };

  /**
   * Remoção EXPLÍCITA de um snapshot ilegível. É a única forma de destravar o
   * salvamento, e é o usuário quem decide — nunca uma consequência lateral de
   * alterar preço, descrição ou cliente.
   */
  const removerDesenhoInvalido = (idx: number) => {
    const ok = window.confirm(
      "Este desenho não pode ser interpretado. Removê-lo permitirá salvar o orçamento, mas os dados paramétricos serão perdidos. Deseja continuar?",
    );
    if (!ok) return;
    setItem(idx, { project_data: null, projectDataInvalido: false });
    toast.info("Desenho inválido removido deste item.");
  };

  const itensComDesenhoInvalido = items.filter((i) => i.projectDataInvalido).length;

  const save = async (status: QuoteStatus) => {
    if (saving) return; // impede duplo envio
    if (!canSaveQuote) {
      return toast.error(
        editId
          ? "Você não tem permissão para editar orçamentos"
          : "Você não tem permissão para criar orçamentos",
      );
    }
    // Trava dura: JSON ilegível NUNCA é reenviado à RPC, e enviar `null` no
    // lugar dele apagaria o que está no banco. Enquanto houver item marcado,
    // não se salva.
    if (itensComDesenhoInvalido > 0) {
      return toast.error(
        "Há item com desenho paramétrico inválido. Use “Remover desenho inválido” antes de salvar.",
      );
    }
    if (!customerId) return toast.error("Selecione um cliente para salvar o orçamento.");
    // Revisão 33 — trava dura de campo numérico ilegível. Enquanto a tela
    // mostrar "abc" numa medida, num preço ou no desconto, o estado guarda o
    // último valor VÁLIDO; salvar assim gravaria um número que o usuário não
    // está vendo. Recusa nomeando o campo, em vez de zerar em silêncio.
    const primeiroInvalido = Object.values(camposInvalidos)[0];
    if (primeiroInvalido) {
      return toast.error(
        `${primeiroInvalido.label} não é um número válido: "${primeiroInvalido.texto}". Use apenas números, com vírgula ou ponto na casa decimal (ex.: 89,90).`,
      );
    }
    // Descrição comercial OU tipo estruturado — a RPC exige `descricao` NOT NULL;
    // se só houver tipo, enviamos o rótulo do enum como descricao mínima.
    const itemTemConteudo = (i: Item) => Boolean(i.descricao.trim() || i.tipo_projeto);
    const descricaoParaRpc = (i: Item) => {
      const d = i.descricao.trim();
      if (d) return d;
      if (i.tipo_projeto) return rotuloTipoProjetoOrcamento(i.tipo_projeto);
      return "";
    };
    const validItems = enriched.filter(itemTemConteudo);
    if (validItems.length === 0) {
      return toast.error("Adicione ao menos um item ao orçamento antes de salvar.");
    }
    setSaving(true);
    try {
      // Itens em METROS; a RPC valida cliente/empresa e RECALCULA o total no banco.
      // Não enviamos owner_id nem total — o backend é a fonte da verdade.
      const items = validItems.map((i) => ({
        descricao: descricaoParaRpc(i),
        ...(i.tipo_projeto ? { tipo_projeto: i.tipo_projeto } : {}),
        ambiente: (i.ambiente ?? "").trim() || null,
        largura: i.largura / 1000,
        altura: i.altura / 1000,
        quantidade: i.quantidade,
        preco_unit: i.preco_unit,
        // Devolve os desenhos carregados na edição. Item novo não tem nenhum e os
        // campos simplesmente não vão no payload (a RPC trata como sem desenho).
        drawing_data: i.drawing_data,
        drawing_notes: i.drawing_notes ?? null,
        // Snapshot paramétrico. Precisa ser REENVIADO em toda gravação: a RPC
        // apaga e recria os itens, então o que não voltar aqui é perdido.
        // `null` explícito é o caminho de REMOÇÃO (usado ao alterar medidas).
        project_data: i.project_data ?? null,
        imagem_url: i.imagem_url ?? null,
        originado_de_projeto: i.originado_de_projeto === true,
      }));
      const newId = await saveQuote.mutateAsync({
        quoteId: editId || null,
        customerId,
        status,
        observacoes: obs || null,
        desconto: descontoValor,
        acrescimo,
        validadeDias,
        items,
      });
      toast.success(editId ? "Orçamento atualizado" : "Orçamento salvo");

      // Salvar com status "enviado" ABRIA o WhatsApp sozinho, sem nenhum botão
      // pedir — efeito colateral de gravar, não escolha do vendedor. Removido na
      // Revisão 57: enviar pelo WhatsApp passa a ser sempre ação explícita, pelo
      // botão do detalhe do orçamento (`app.orcamentos.$id.tsx`) ou pelo da
      // listagem. O status continua sendo gravado normalmente — só o disparo
      // automático saiu.

      navigate({ to: "/app/orcamentos/$id", params: { id: newId } });
    } catch (e: unknown) {
      toast.error(quoteErrorMessage(e));
    } finally {
      setSaving(false);
    }
  };

  const voltarOuCancelar = () => {
    if (editId) {
      navigate({ to: "/app/orcamentos/$id", params: { id: editId } });
      return;
    }
    navigate({ to: "/app/orcamentos", search: { view: "lista" } });
  };

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={voltarOuCancelar}
          className="inline-flex items-center gap-1 rounded-lg border border-input px-3 py-1.5 text-xs hover:bg-accent"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Voltar
        </button>
        <h1 className="font-display text-3xl font-bold">
          {editId ? "Editar orçamento" : "Novo orçamento"}
        </h1>
        {/* Número do pedido: sequencial do banco (`quotes.numero`), exibido
            somente para leitura. Não é editável nem enviado à RPC. */}
        {editing?.quote?.numero != null && (
          <span
            title="Número do pedido (gerado pelo sistema, não editável)"
            className="rounded-lg border border-border bg-muted px-3 py-1.5 text-sm font-semibold text-muted-foreground"
          >
            Nº pedido: {editing.quote.numero}
          </span>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <div className="rounded-2xl border bg-card p-5">
            <div className="mb-1 flex flex-wrap items-end justify-between gap-2">
              <span className="text-xs font-medium text-muted-foreground">Cliente *</span>
              <button
                type="button"
                onClick={() => setNewCustomerOpen(true)}
                className="inline-flex items-center gap-1 rounded-md border border-input bg-background px-2.5 py-1 text-xs font-semibold hover:bg-accent"
              >
                <Plus className="h-3 w-3" /> Adicionar Cliente
              </button>
            </div>
            <CustomerSearchField
              customers={customers}
              value={customerId}
              onSelect={setCustomerId}
              isLoading={customersLoading}
            />
          </div>

          <div className="rounded-2xl border bg-card p-5">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold">Itens do orçamento</h2>
              <button
                type="button"
                onClick={() => setItems([...items, itemEmBranco()])}
                className="inline-flex items-center gap-1 rounded-md bg-gradient-gold px-3 py-1.5 text-xs font-semibold text-gold-foreground shadow-glow hover:opacity-95"
              >
                <Plus className="h-3 w-3" /> Adicionar item
              </button>
            </div>
            <div className="space-y-3">
              {enriched.length === 0 ? (
                <div className="rounded-xl border border-dashed border-border bg-background px-4 py-8 text-center">
                  <p className="mb-4 text-sm text-muted-foreground">Nenhum item adicionado.</p>
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    <button
                      type="button"
                      onClick={() => setProjectPicker(-1)}
                      className="inline-flex items-center gap-1.5 rounded-md border border-gold/40 bg-gold/10 px-2.5 py-1.5 text-[11px] font-semibold text-gold hover:bg-gold/20"
                    >
                      <Layers className="h-3 w-3" /> Aplicar projeto
                    </button>
                    <button
                      type="button"
                      onClick={() => setStockPicker(-1)}
                      className="inline-flex items-center gap-1.5 rounded-md bg-sky-600 px-2.5 py-1.5 text-[11px] font-semibold text-white shadow-sm hover:bg-sky-500"
                    >
                      <Plus className="h-3 w-3" /> Estoque
                    </button>
                    <button
                      type="button"
                      onClick={() => setItems([itemEmBranco()])}
                      className="inline-flex items-center gap-1.5 rounded-md border border-input px-2.5 py-1.5 text-[11px] font-semibold hover:bg-accent"
                    >
                      <Plus className="h-3 w-3" /> Adicionar item
                    </button>
                  </div>
                </div>
              ) : (
                enriched.map((it, idx) => (
                  <div key={idx} className="rounded-xl border bg-background p-4">
                    <div className="mb-3 flex items-center justify-between">
                      <span className="flex items-center gap-2 text-xs font-semibold text-muted-foreground">
                        Item {idx + 1}
                        {/* Foto do item (projeto, catálogo ou estoque) — só com
                          `imagem_url`; estilo dourado igual a "Aplicar projeto". */}
                        {itemPossuiImagem(it) && (
                          <button
                            type="button"
                            title="Visualizar imagem"
                            aria-label={`Visualizar imagem do item ${idx + 1}`}
                            onClick={() => setFotoPreviewUrl(obterImagemUrlDoItem(it)!)}
                            className="inline-flex items-center gap-1.5 rounded-md border border-gold/40 bg-gold/10 px-2.5 py-1 text-[11px] font-semibold text-gold hover:bg-gold/20"
                          >
                            <Eye className="h-3 w-3" /> Visualizar imagem
                          </button>
                        )}
                      </span>
                      <div className="flex items-center gap-2">
                        {/* Rev. 199 — Aplicar projeto / Estoque só em item VAZIO.
                          Critério: `itemEstaVazio` (descrição, tipo, L/A, preço,
                          sem project_data). Preenchido → só lixeira (+ Salvar
                          como modelo quando faz sentido). */}
                        {itemEstaVazio(it) && (
                          <>
                            <button
                              type="button"
                              onClick={() => setProjectPicker(idx)}
                              className="inline-flex items-center gap-1.5 rounded-md border border-gold/40 bg-gold/10 px-2.5 py-1 text-[11px] font-semibold text-gold hover:bg-gold/20"
                            >
                              <Layers className="h-3 w-3" /> Aplicar projeto
                            </button>
                            <button
                              type="button"
                              onClick={() => setStockPicker(idx)}
                              className="inline-flex items-center gap-1.5 rounded-md bg-sky-600 px-2.5 py-1 text-[11px] font-semibold text-white shadow-sm hover:bg-sky-500"
                            >
                              <Plus className="h-3 w-3" /> Estoque
                            </button>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() => setItems(items.filter((_, i) => i !== idx))}
                          className="text-destructive"
                          title="Remover item"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    {/* Desenho inválido: aviso + a ÚNICA ação que destrava o
                      salvamento. Nada é apagado sem este clique. */}
                    {it.projectDataInvalido && (
                      <div className="mb-3 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs text-amber-700 dark:text-amber-300">
                        <span>
                          O desenho paramétrico deste item está inválido e não pode ser carregado.
                        </span>
                        <button
                          type="button"
                          onClick={() => removerDesenhoInvalido(idx)}
                          className="rounded-md border border-amber-500/50 px-2.5 py-1 font-semibold hover:bg-amber-500/20"
                        >
                          Remover desenho inválido
                        </button>
                      </div>
                    )}

                    {/* Rev. 199 — estoque por unidade (LED etc.): sem Ambiente /
                      Tipo / Espessura / L×A. Descrição + qtd + preço unit. + subtotal. */}
                    {!itemLayoutEstoqueUnidade(it) && (
                      <>
                        <label className="mb-1 block text-[10px] uppercase tracking-wider text-muted-foreground">
                          Ambiente
                        </label>
                        <select
                          value={it.ambiente ?? ""}
                          onChange={(e) => setItem(idx, { ambiente: e.target.value || null })}
                          className="mb-3 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
                        >
                          <option value="">— Selecione o ambiente —</option>
                          {AMBIENTES_PRESET.map((nome) => (
                            <option key={nome} value={nome}>
                              {nome}
                            </option>
                          ))}
                        </select>
                        <label className="mb-1 block text-[10px] uppercase tracking-wider text-muted-foreground">
                          Tipo{" "}
                          <span className="normal-case text-muted-foreground/80">(opcional)</span>
                        </label>
                        <select
                          value={it.tipo_projeto ?? ""}
                          onChange={(e) => {
                            const v = e.target.value;
                            const tipo = v === "" ? null : ehQuoteItemTipoProjeto(v) ? v : null;
                            setItem(idx, { tipo_projeto: tipo });
                          }}
                          className="mb-3 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
                        >
                          <option value="">— Sem tipo —</option>
                          <optgroup label="Vidraçaria">
                            {tiposProjetoOrcamentoDaArea("vidracaria").map((t) => (
                              <option key={t.value} value={t.value}>
                                {t.label}
                              </option>
                            ))}
                          </optgroup>
                          <optgroup label="Esquadrias">
                            {tiposProjetoOrcamentoDaArea("esquadrias").map((t) => (
                              <option key={t.value} value={t.value}>
                                {t.label}
                              </option>
                            ))}
                          </optgroup>
                        </select>
                      </>
                    )}
                    <label className="mb-1 block text-[10px] uppercase tracking-wider text-muted-foreground">
                      Descrição comercial
                    </label>
                    <input
                      placeholder="Detalhe comercial (ex.: Porta blindex suite 302)"
                      value={it.descricao}
                      onChange={(e) => setItem(idx, { descricao: e.target.value })}
                      className="mb-3 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
                    />
                    {!itemLayoutEstoqueUnidade(it) && (
                      <div className="mb-3 flex flex-wrap gap-2">
                        <span className="self-center text-[10px] uppercase tracking-wider text-muted-foreground">
                          Espessura:
                        </span>
                        {["4mm", "6mm", "8mm", "10mm", "12mm"].map((mm) => {
                          const ativo = it.espessura === mm;
                          return (
                            <button
                              key={mm}
                              type="button"
                              onClick={() => {
                                const nova = ativo ? "" : mm;
                                const project_data = sincronizarEspessuraVidroNoProjectData(
                                  it.project_data,
                                  nova,
                                  {
                                    tipo_projeto: it.tipo_projeto,
                                    nome: it.descricao || "Item",
                                    larguraMm: it.largura,
                                    alturaMm: it.altura,
                                  },
                                );
                                setItem(idx, {
                                  espessura: nova || null,
                                  ...(project_data !== it.project_data
                                    ? { project_data: project_data ?? null }
                                    : {}),
                                });
                              }}
                              className={`inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs transition ${
                                ativo
                                  ? "border-primary bg-primary text-primary-foreground shadow-sm"
                                  : "border-input bg-background hover:border-primary/40 hover:bg-accent"
                              }`}
                            >
                              {ativo && <Check className="h-3 w-3" />}
                              {mm}
                            </button>
                          );
                        })}
                      </div>
                    )}
                    <div
                      className={
                        itemLayoutEstoqueUnidade(it)
                          ? "grid grid-cols-2 gap-2 md:grid-cols-3"
                          : "grid grid-cols-2 gap-2 md:grid-cols-5"
                      }
                    >
                      {!itemLayoutEstoqueUnidade(it) && (
                        <>
                          <NumberField
                            name={`larg-${idx}`}
                            nextName={`alt-${idx}`}
                            label="Largura (mm)"
                            value={it.largura}
                            onChange={(v) => setMedida(idx, "largura", v)}
                            step={1}
                            aoInvalidar={registrarInvalido}
                          />
                          <NumberField
                            name={`alt-${idx}`}
                            nextName={`qtd-${idx}`}
                            label="Altura (mm)"
                            value={it.altura}
                            onChange={(v) => setMedida(idx, "altura", v)}
                            step={1}
                            aoInvalidar={registrarInvalido}
                          />
                        </>
                      )}

                      <NumberField
                        name={`qtd-${idx}`}
                        nextName={`preco-${idx}`}
                        label="Quant."
                        value={it.quantidade}
                        onChange={(v) => setItem(idx, { quantidade: v })}
                        step={1}
                        aoInvalidar={registrarInvalido}
                      />
                      <NumberField
                        name={`preco-${idx}`}
                        nextName={`sub-${idx}`}
                        label={
                          itemLayoutEstoqueUnidade(it) || !(it.largura > 0 && it.altura > 0)
                            ? "Preço unit."
                            : "Preço m²"
                        }
                        value={it.preco_unit}
                        onChange={(v) => setItem(idx, { preco_unit: v })}
                        step={1}
                        aoInvalidar={registrarInvalido}
                      />
                      <div className="min-w-0">
                        <NumberField
                          name={`sub-${idx}`}
                          label="Subtotal (R$)"
                          value={arredonda(it.subtotal, 2)}
                          onChange={(v) => aplicarSubtotal(idx, v)}
                          step={0.01}
                          aoInvalidar={registrarInvalido}
                        />
                        {!itemLayoutEstoqueUnidade(it) && (
                          <div className="mt-0.5 text-[10px] text-muted-foreground tabular-nums">
                            {it.m2.toFixed(3)} m²
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="rounded-2xl border bg-card p-5">
            <label className="block">
              <span className="mb-1 block text-xs font-medium text-muted-foreground">
                Observações
              </span>
              <textarea
                value={obs}
                onChange={(e) => setObs(e.target.value)}
                rows={4}
                placeholder="Prazo de entrega, condições, etc."
                className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
              />
            </label>
          </div>
        </div>

        {/* Resumo — tokens de tema (Rev. 237 / opção B da 233; reaplicado pós-rollback) */}
        <div className="lg:sticky lg:top-6 lg:self-start">
          <div className="rounded-2xl border border-border bg-card p-6 text-foreground shadow-elegant">
            <h2 className="font-display text-lg font-semibold">Resumo</h2>
            <div className="mt-4 space-y-2 text-sm">
              <Row label="Subtotal" value={brl(subtotalGeral)} />
              <NumberRow
                name="desconto-pct"
                label="Desconto (%)"
                value={descontoPct}
                onChange={setDescontoPct}
                aoInvalidar={registrarInvalido}
              />
              <Row label="Valor desconto" value={`- ${brl(descontoValor)}`} />
            </div>
            <div className="mt-6 border-t border-border pt-4">
              <div className="text-xs text-muted-foreground">TOTAL</div>
              <div className="font-display text-4xl font-bold text-gold">{brl(total)}</div>
            </div>
            <div className="mt-6 space-y-2">
              <button
                onClick={() => save("enviado")}
                disabled={saving || !canSaveQuote}
                className="w-full rounded-lg bg-gradient-gold px-4 py-2.5 text-sm font-semibold text-gold-foreground disabled:opacity-50"
              >
                {saving ? "Salvando..." : "Enviar orçamento"}
              </button>
              <button
                onClick={() => save("rascunho")}
                disabled={saving || !canSaveQuote}
                className="w-full rounded-lg border border-border bg-background px-4 py-2.5 text-sm font-medium hover:bg-accent disabled:opacity-50"
              >
                Salvar orçamento
              </button>
              <button
                type="button"
                onClick={voltarOuCancelar}
                disabled={saving}
                className="w-full rounded-lg px-4 py-2.5 text-sm font-medium text-muted-foreground hover:bg-muted disabled:opacity-50"
              >
                Cancelar
              </button>
              {!canSaveQuote && (
                <p className="text-center text-xs text-destructive">
                  Sem permissão para {editId ? "editar" : "criar"} orçamentos.
                </p>
              )}
            </div>
          </div>
        </div>
      </div>

      {newCustomerOpen && (
        <CustomerDialog
          title="Novo cliente"
          submitLabel="Cadastrar e continuar"
          onClose={() => setNewCustomerOpen(false)}
          onSubmit={(v) => createCustomer.mutate(v)}
          loading={createCustomer.isPending}
        />
      )}

      {/* Rev. 240 — foto do item em Dialog (ui/dialog já existente; sem Popover/cmdk). */}
      <Dialog
        open={!!fotoPreviewUrl}
        onOpenChange={(open) => {
          if (!open) setFotoPreviewUrl(null);
        }}
      >
        <DialogContent className="max-w-2xl p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle>Foto do item</DialogTitle>
          </DialogHeader>
          {fotoPreviewUrl && (
            <StorageImage
              src={pathForQuoteItemImage(fotoPreviewUrl)}
              bucket={bucketForQuoteItemImage(fotoPreviewUrl)}
              alt="Foto do item do orçamento"
              className="max-h-[70vh] w-full rounded-lg object-contain"
            />
          )}
        </DialogContent>
      </Dialog>

      {projectPicker !== null && (
        <ProjectPickerModal
          templates={templates}
          onClose={() => setProjectPicker(null)}
          onPick={(t) => applyTemplate(projectPicker, t)}
        />
      )}

      {stockPicker !== null && (
        <StockPickerModal
          items={stockItems}
          onClose={() => setStockPicker(null)}
          onPick={(s) => applyStockItem(stockPicker, s)}
        />
      )}
    </div>
  );
}

/** Página do catálogo no passo final "Aplicar projeto" (grid 3 colunas). */
const PICKER_MODELOS_PAGE_SIZE = 12;

type FiltroOrigemPicker = "todos" | "global" | "empresa";

function ProjectPickerModal({
  templates,
  onClose,
  onPick,
}: {
  templates: PickerTemplate[];
  onClose: () => void;
  onPick: (t: PickerTemplate) => void;
}) {
  /**
   * Wizard em 3 passos: área → tipo/subtipo → modelo.
   * Fonte: catálogo global + modelos da empresa ativa.
   *
   * No passo "modelos", busca/filtros/paginação são CLIENT-SIDE sobre o dataset
   * unificado já carregado (precisa de `project_data` para aplicar). Server-side
   * nas duas tabelas exigiria paginação cruzada — fora do escopo desta rodada.
   */
  type Passo = "area" | "subtipo" | "modelos";
  const [passo, setPasso] = useState<Passo>("area");
  const [areaSel, setAreaSel] = useState<AreaProjeto | null>(null);
  const [subtipoSel, setSubtipoSel] = useState<SubtipoProjeto | null>(null);
  const [busca, setBusca] = useState("");
  const [origemFiltro, setOrigemFiltro] = useState<FiltroOrigemPicker>("todos");
  const [categoriaFiltro, setCategoriaFiltro] = useState<string>("todos");
  const [espessuraFiltro, setEspessuraFiltro] = useState<string>("todos");
  const [page, setPage] = useState(1);

  const resetCatalogoFiltros = () => {
    setBusca("");
    setOrigemFiltro("todos");
    setCategoriaFiltro("todos");
    setEspessuraFiltro("todos");
    setPage(1);
  };

  const contagemPorArea = useMemo(() => {
    const c: Partial<Record<AreaProjeto, number>> = {};
    for (const t of templates) {
      if (ehAreaOperacional(t.area)) c[t.area] = (c[t.area] ?? 0) + 1;
    }
    return c;
  }, [templates]);

  /** Sempre Vidraçaria + Esquadrias — tipos selecionáveis mesmo sem modelos. */
  const areasOperacionais = AREAS_OPERACIONAIS;

  const subtiposDaAreaSel = useMemo(() => {
    if (!areaSel || !ehAreaOperacional(areaSel)) return [] as SubtipoProjeto[];
    return [...subtiposDaArea(areaSel)];
  }, [areaSel]);

  const modelos = useMemo(() => {
    if (!areaSel || !subtipoSel) return [] as PickerTemplate[];
    return templates.filter((t) => chaveDoGrupo(t) === `${areaSel}|${subtipoSel}`);
  }, [areaSel, subtipoSel, templates]);

  /** Opções dinâmicas a partir do conjunto Área+Tipo (antes dos filtros extras). */
  const opcoesCategoria = useMemo(() => {
    const set = new Set<string>();
    for (const t of modelos) {
      if (t.categoria) set.add(t.categoria);
    }
    return [...set].sort((a, b) =>
      categoriaProjetoLabel(a).localeCompare(categoriaProjetoLabel(b), "pt-BR"),
    );
  }, [modelos]);

  const opcoesEspessura = useMemo(() => {
    const set = new Set<string>();
    for (const t of modelos) {
      const e = t.espessura?.trim();
      if (e) set.add(e);
    }
    return [...set].sort((a, b) => a.localeCompare(b, "pt-BR", { numeric: true }));
  }, [modelos]);

  const modelosFiltrados = useMemo(() => {
    const termo = busca.trim().toLowerCase();
    return modelos.filter((t) => {
      if (origemFiltro !== "todos" && t.origem !== origemFiltro) return false;
      if (categoriaFiltro !== "todos" && t.categoria !== categoriaFiltro) return false;
      if (espessuraFiltro !== "todos" && (t.espessura?.trim() ?? "") !== espessuraFiltro) {
        return false;
      }
      if (termo && !t.nome.toLowerCase().includes(termo)) return false;
      return true;
    });
  }, [modelos, busca, origemFiltro, categoriaFiltro, espessuraFiltro]);

  const totalFiltrado = modelosFiltrados.length;
  const totalPaginas = Math.max(1, Math.ceil(totalFiltrado / PICKER_MODELOS_PAGE_SIZE));
  const pageSegura = Math.min(page, totalPaginas);
  const modelosPagina = useMemo(() => {
    const from = (pageSegura - 1) * PICKER_MODELOS_PAGE_SIZE;
    return modelosFiltrados.slice(from, from + PICKER_MODELOS_PAGE_SIZE);
  }, [modelosFiltrados, pageSegura]);

  const filtrosAtivos =
    busca.trim() !== "" ||
    origemFiltro !== "todos" ||
    categoriaFiltro !== "todos" ||
    espessuraFiltro !== "todos";

  useEffect(() => {
    setPage(1);
  }, [busca, origemFiltro, categoriaFiltro, espessuraFiltro, areaSel, subtipoSel]);

  // Se o dataset do tipo mudar e a opção sumir, não deixa filtro órfão.
  useEffect(() => {
    if (categoriaFiltro !== "todos" && !opcoesCategoria.includes(categoriaFiltro)) {
      setCategoriaFiltro("todos");
    }
  }, [categoriaFiltro, opcoesCategoria]);

  useEffect(() => {
    if (espessuraFiltro !== "todos" && !opcoesEspessura.includes(espessuraFiltro)) {
      setEspessuraFiltro("todos");
    }
  }, [espessuraFiltro, opcoesEspessura]);

  const voltar = () => {
    if (passo === "modelos") {
      resetCatalogoFiltros();
      setSubtipoSel(null);
      setPasso("subtipo");
      return;
    }
    if (passo === "subtipo") {
      setAreaSel(null);
      setPasso("area");
    }
  };

  const titulo =
    passo === "area"
      ? "Escolha a área"
      : passo === "subtipo" && areaSel
        ? `Tipo · ${ROTULO_AREA[areaSel]}`
        : areaSel && subtipoSel
          ? `${ROTULO_AREA[areaSel]} · ${ROTULO_SUBTIPO[subtipoSel]}`
          : "Aplicar projeto";

  const selectClass =
    "h-9 w-full min-w-0 rounded-lg border border-input bg-background px-2.5 text-sm outline-none focus:ring-2 focus:ring-ring sm:w-auto sm:min-w-[9.5rem]";

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-4xl rounded-2xl border border-border bg-card p-5 shadow-elegant"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2">
            {passo !== "area" && (
              <button
                type="button"
                onClick={voltar}
                className="rounded-md p-1.5 hover:bg-accent"
                aria-label="Voltar"
              >
                <ArrowLeft className="h-4 w-4" />
              </button>
            )}
            <h2 className="font-display truncate text-lg font-bold">{titulo}</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-md p-1.5 hover:bg-accent"
              aria-label="Fechar"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="max-h-[65vh] overflow-y-auto pr-1">
          {passo === "area" ? (
            <div className="grid gap-3 sm:grid-cols-2">
              {areasOperacionais.map((a) => {
                const n = contagemPorArea[a] ?? 0;
                return (
                  <button
                    key={a}
                    type="button"
                    onClick={() => {
                      setAreaSel(a);
                      setSubtipoSel(null);
                      resetCatalogoFiltros();
                      setPasso("subtipo");
                    }}
                    className="rounded-xl border border-border bg-background px-4 py-6 text-left transition hover:border-gold/50 hover:bg-gold/10"
                  >
                    <div className="font-display text-lg font-semibold">{ROTULO_AREA[a]}</div>
                    <div className="mt-2 text-xs font-semibold text-muted-foreground">
                      {n} {n === 1 ? "modelo" : "modelos"}
                    </div>
                  </button>
                );
              })}
            </div>
          ) : passo === "subtipo" && areaSel ? (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {subtiposDaAreaSel.map((s) => {
                const n = templates.filter((t) => chaveDoGrupo(t) === `${areaSel}|${s}`).length;
                return (
                  <button
                    key={s}
                    type="button"
                    onClick={() => {
                      resetCatalogoFiltros();
                      setSubtipoSel(s);
                      setPasso("modelos");
                    }}
                    className="rounded-xl border border-border bg-background px-4 py-6 text-left transition hover:border-gold/50 hover:bg-gold/10"
                  >
                    <div className="font-display text-lg font-semibold">{ROTULO_SUBTIPO[s]}</div>
                    <div className="mt-2 text-xs text-muted-foreground">
                      {n} {n === 1 ? "variação" : "variações"}
                    </div>
                  </button>
                );
              })}
            </div>
          ) : modelos.length === 0 ? (
            <div className="rounded-xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
              {templates.length === 0 ? (
                <>
                  Nenhum projeto disponível.
                  <br />
                  Cadastre modelos em Projetos ou peça a um Super Admin para incluir itens no
                  catálogo global.
                </>
              ) : (
                "Nenhuma variação neste tipo de projeto."
              )}
            </div>
          ) : (
            <div className="space-y-3">
              <div className="space-y-2">
                <label className="relative block">
                  <span className="sr-only">Buscar projeto por nome</span>
                  <Search
                    className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
                    aria-hidden
                  />
                  <input
                    type="search"
                    value={busca}
                    onChange={(e) => setBusca(e.target.value)}
                    placeholder="Buscar projeto por nome..."
                    aria-label="Buscar projeto por nome"
                    className="w-full rounded-lg border border-input bg-background py-2 pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-ring"
                  />
                </label>

                <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-center">
                  <label className="flex min-w-0 flex-1 flex-col gap-1 text-xs text-muted-foreground sm:flex-none">
                    <span className="font-medium">Origem</span>
                    <select
                      value={origemFiltro}
                      onChange={(e) => setOrigemFiltro(e.target.value as FiltroOrigemPicker)}
                      aria-label="Filtrar por origem"
                      className={selectClass}
                    >
                      <option value="todos">Todos</option>
                      <option value="global">Catálogo Global</option>
                      <option value="empresa">Projetos da empresa</option>
                    </select>
                  </label>

                  {opcoesCategoria.length > 0 && (
                    <label className="flex min-w-0 flex-1 flex-col gap-1 text-xs text-muted-foreground sm:flex-none">
                      <span className="font-medium">Categoria</span>
                      <select
                        value={categoriaFiltro}
                        onChange={(e) => setCategoriaFiltro(e.target.value)}
                        aria-label="Filtrar por categoria"
                        className={selectClass}
                      >
                        <option value="todos">Todas</option>
                        {opcoesCategoria.map((c) => (
                          <option key={c} value={c}>
                            {categoriaProjetoLabel(c)}
                          </option>
                        ))}
                      </select>
                    </label>
                  )}

                  {opcoesEspessura.length > 0 && (
                    <label className="flex min-w-0 flex-1 flex-col gap-1 text-xs text-muted-foreground sm:flex-none">
                      <span className="font-medium">Espessura</span>
                      <select
                        value={espessuraFiltro}
                        onChange={(e) => setEspessuraFiltro(e.target.value)}
                        aria-label="Filtrar por espessura"
                        className={selectClass}
                      >
                        <option value="todos">Todas</option>
                        {opcoesEspessura.map((e) => (
                          <option key={e} value={e}>
                            {e}
                          </option>
                        ))}
                      </select>
                    </label>
                  )}

                  {filtrosAtivos && (
                    <button
                      type="button"
                      onClick={resetCatalogoFiltros}
                      className="h-9 self-stretch rounded-lg border border-border px-3 text-xs font-semibold text-muted-foreground hover:bg-accent sm:mt-5 sm:self-auto"
                    >
                      Limpar filtros
                    </button>
                  )}
                </div>
              </div>

              <div className="text-sm text-muted-foreground">
                {totalFiltrado} {totalFiltrado === 1 ? "modelo encontrado" : "modelos encontrados"}
                {totalPaginas > 1 && (
                  <>
                    {" "}
                    · página {pageSegura} de {totalPaginas}
                  </>
                )}
              </div>

              {totalFiltrado === 0 ? (
                <div className="rounded-xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
                  <p>Nenhum projeto encontrado com esses filtros.</p>
                  <button
                    type="button"
                    onClick={resetCatalogoFiltros}
                    className="mt-3 inline-flex items-center rounded-lg border border-border px-3 py-1.5 text-xs font-semibold hover:bg-accent"
                  >
                    Limpar filtros
                  </button>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                    {modelosPagina.map((t) => (
                      <div
                        key={`${t.origem}-${t.id}`}
                        className="group overflow-hidden rounded-xl border border-border bg-background transition hover:border-gold/50 hover:shadow-elegant"
                      >
                        <button
                          type="button"
                          onClick={() => onPick(t)}
                          className="block w-full text-left"
                        >
                          <div className="relative aspect-[4/3] w-full bg-muted">
                            {t.imagem_url ? (
                              <StorageImage
                                bucket={t.imageBucket}
                                src={t.imagem_url}
                                alt={t.nome}
                                className="h-full w-full object-cover"
                              />
                            ) : (
                              <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                                <ImageIcon className="h-10 w-10 opacity-40" />
                              </div>
                            )}
                          </div>
                          <div className="p-3">
                            <div className="font-semibold leading-tight">{t.nome}</div>
                            <div className="mt-1 text-xs text-muted-foreground">
                              {Number(t.largura_padrao).toFixed(2)} ×{" "}
                              {Number(t.altura_padrao).toFixed(2)} m · {brl(Number(t.preco_m2))}
                              /m²
                              {t.espessura && <> · {t.espessura}</>}
                            </div>
                          </div>
                        </button>
                      </div>
                    ))}
                  </div>

                  {totalPaginas > 1 && (
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-sm text-muted-foreground">
                      <span className="sr-only">Paginação do catálogo de modelos</span>
                      <button
                        type="button"
                        disabled={pageSegura <= 1}
                        onClick={() => setPage((p) => Math.max(1, p - 1))}
                        aria-label="Página anterior"
                        className="inline-flex items-center gap-1 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold hover:bg-accent disabled:cursor-not-allowed disabled:opacity-40"
                      >
                        <ChevronLeft className="h-4 w-4" /> Anterior
                      </button>
                      <span aria-live="polite">
                        Página {pageSegura} de {totalPaginas}
                      </span>
                      <button
                        type="button"
                        disabled={pageSegura >= totalPaginas}
                        onClick={() => setPage((p) => Math.min(totalPaginas, p + 1))}
                        aria-label="Próxima página"
                        className="inline-flex items-center gap-1 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold hover:bg-accent disabled:cursor-not-allowed disabled:opacity-40"
                      >
                        Próxima <ChevronRight className="h-4 w-4" />
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function NumberField({
  label,
  value,
  onChange,
  step,
  name,
  nextName,
  aoInvalidar,
}: {
  label: string;
  value: number;
  onChange: (v: number) => boolean | void;
  step: number;
  name?: string;
  nextName?: string;
  aoInvalidar?: RegistroInvalido;
}) {
  const [text, setText] = useState(() => numeroParaTexto(value ?? 0));
  const [focused, setFocused] = useState(false);
  useEffect(() => {
    if (!focused) setText(numeroParaTexto(value ?? 0));
  }, [value, focused]);

  // Texto preenchido que não é número em formato nenhum. Enquanto está assim, o
  // valor NÃO é propagado ao pai — ver o comentário do `onChange` abaixo.
  const invalido = text.trim() !== "" && Number.isNaN(textoParaNumero(text));

  // Avisa a página para que ela BLOQUEIE o salvamento. Sem isto, o campo
  // mostraria "abc" enquanto o estado (e o payload da RPC) guardaria em silêncio
  // a última medida válida — a tela dizendo uma coisa e o banco recebendo outra.
  const chave = name ?? label;
  useEffect(() => {
    aoInvalidar?.(chave, invalido ? { label, texto: text } : null);
    return () => aoInvalidar?.(chave, null);
  }, [aoInvalidar, chave, invalido, label, text]);

  return (
    <label className="block">
      <span className="mb-1 block text-[10px] uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      <input
        // `inputMode="decimal"` e NÃO `type="number"` (Revisão 33). Num
        // `type="number"` o navegador descarta a vírgula de "89,90" e entrega
        // `""` — era o defeito da Revisão 31, aqui em cima do preço do item e
        // das medidas que formam o m² e o subtotal.
        inputMode="decimal"
        step={step}
        value={text}
        name={name}
        title={invalido ? MSG_NUMERO_INVALIDO : undefined}
        aria-invalid={invalido || undefined}
        onFocus={(e) => {
          setFocused(true);
          e.target.select();
        }}
        onBlur={() => {
          setFocused(false);
          if (text === "") setText("0");
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter" && nextName) {
            e.preventDefault();
            const next = document.querySelector<HTMLInputElement>(`input[name="${nextName}"]`);
            next?.focus();
          }
        }}
        onChange={(e) => {
          const bruto = e.target.value;
          setText(bruto);
          if (bruto.trim() === "") {
            onChange(0);
            return;
          }
          const n = textoParaNumero(bruto);
          // Entrada ilegível NÃO vira 0 e NÃO vira nada: a medida anterior fica
          // de pé, o campo se marca em vermelho e o salvamento fica bloqueado
          // pelo efeito acima. Zerar aqui era exatamente o defeito.
          if (Number.isNaN(n)) return;
          const aceito = onChange(n);
          // Recusado: desfaz na hora, sem esperar blur nem novo render do pai.
          if (aceito === false) setText(numeroParaTexto(value ?? 0));
        }}
        className={`w-full rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring ${invalido ? "border-destructive text-destructive" : "border-input"}`}
      />
    </label>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}

function NumberRow({
  label,
  value,
  onChange,
  integer,
  name,
  aoInvalidar,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  integer?: boolean;
  name?: string;
  aoInvalidar?: RegistroInvalido;
}) {
  const [text, setText] = useState(() => numeroParaTexto(value ?? 0));
  const [focused, setFocused] = useState(false);
  useEffect(() => {
    if (!focused) setText(numeroParaTexto(value ?? 0));
  }, [value, focused]);

  const invalido = text.trim() !== "" && Number.isNaN(textoParaNumero(text));
  const chave = name ?? label;
  useEffect(() => {
    aoInvalidar?.(chave, invalido ? { label, texto: text } : null);
    return () => aoInvalidar?.(chave, null);
  }, [aoInvalidar, chave, invalido, label, text]);

  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <input
        // Mesmo motivo do `NumberField`: `type="number"` comeria a vírgula.
        // Este campo é o DESCONTO — ele multiplica o total do orçamento.
        inputMode="decimal"
        step={integer ? 1 : 0.01}
        value={text}
        name={name}
        title={invalido ? MSG_NUMERO_INVALIDO : undefined}
        aria-invalid={invalido || undefined}
        onFocus={() => setFocused(true)}
        onBlur={() => {
          setFocused(false);
          if (text === "") setText("0");
        }}
        onChange={(e) => {
          const bruto = e.target.value;
          setText(bruto);
          if (bruto.trim() === "") {
            onChange(0);
            return;
          }
          const n = textoParaNumero(bruto);
          if (Number.isNaN(n)) return; // não zera nem propaga; salvamento bloqueado
          onChange(n);
        }}
        className={`w-28 rounded-md border border-input px-2 py-1 text-right text-sm outline-none ${invalido ? "bg-destructive/30 ring-1 ring-destructive" : "bg-background focus:ring-2 focus:ring-ring"}`}
      />
    </div>
  );
}

function StockPickerModal({
  items,
  onClose,
  onPick,
}: {
  items: StockPickerItem[];
  onClose: () => void;
  onPick: (s: StockPickerItem) => void;
}) {
  const [search, setSearch] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const filtered = useMemo(
    () => items.filter((i) => !search || i.nome.toLowerCase().includes(search.toLowerCase())),
    [items, search],
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl rounded-2xl border border-border bg-card p-5 shadow-elegant"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="font-display text-lg font-bold">Selecionar item do estoque</h2>
          <button onClick={onClose} className="rounded-md p-1.5 hover:bg-accent">
            <X className="h-4 w-4" />
          </button>
        </div>
        <input
          autoFocus
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar item..."
          className="mb-3 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
        />
        {/* O modal já era mais alto que o seletor da Venda direta, mas rolava
            igualmente sem avisar (Revisão 104). Ganha as mesmas pistas: contagem
            fixa no topo e fade com rótulo enquanto sobra conteúdo abaixo. A
            altura fica em 60vh — é relativa à janela e não precisou mudar. */}
        <ListaRolavel
          className="max-h-[60vh] space-y-2"
          vazio={filtered.length === 0}
          contagem={
            search.trim()
              ? `${filtered.length} de ${items.length} ${items.length === 1 ? "item" : "itens"}`
              : `${items.length} ${items.length === 1 ? "item" : "itens"} no estoque`
          }
        >
          {filtered.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              {items.length === 0
                ? "Nenhum item ativo no estoque. O Estoque é opcional — feche e preencha o item manualmente."
                : "Nenhum item encontrado."}
            </p>
          ) : (
            filtered.map((s) => {
              const isSelected = selectedId === s.id;
              return (
                <div
                  key={s.id}
                  onClick={() => setSelectedId(s.id)}
                  className={`flex w-full items-center gap-3 rounded-xl border p-3 text-left cursor-pointer transition ${
                    isSelected
                      ? "border-primary bg-primary/10 ring-2 ring-primary/30"
                      : "border-border bg-background hover:border-primary/40 hover:bg-accent"
                  }`}
                >
                  <div className="relative">
                    {s.imagem_url ? (
                      // `imagem_url` guarda o PATH no bucket privado; StorageImage
                      // resolve para URL assinada (um <img src={path}> não carrega).
                      <StorageImage
                        src={s.imagem_url}
                        alt={s.nome}
                        className="h-12 w-12 rounded-lg object-cover border border-border"
                      />
                    ) : (
                      <div className="grid h-12 w-12 place-items-center rounded-lg border border-dashed border-border bg-muted">
                        <ImageIcon className="h-5 w-5 text-muted-foreground" />
                      </div>
                    )}
                    {isSelected && (
                      <div className="absolute -right-1 -top-1 grid h-5 w-5 place-items-center rounded-full bg-primary text-primary-foreground">
                        <Check className="h-3 w-3" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm truncate">{s.nome}</div>
                    <div className="text-xs text-muted-foreground">
                      {categoriaMeta(s.categoria)?.label ?? s.categoria} • saldo:{" "}
                      {Number(s.quantidade)} {s.unidade}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold text-primary">
                      {brl(Number(s.preco_venda))}
                    </div>
                    <div className="text-[10px] text-muted-foreground">por {s.unidade}</div>
                  </div>
                </div>
              );
            })
          )}
        </ListaRolavel>
        {selectedId && (
          <div className="mt-4 flex justify-end">
            <button
              onClick={() => {
                const item = items.find((i) => i.id === selectedId);
                if (item) onPick(item);
              }}
              className="rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
            >
              Adicionar ao orçamento
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
