import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Building2, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/contexts/company-context";
import { mensagemDeErroDeAuth } from "@/lib/auth-error-message";
import { validarCnpj } from "@/lib/cnpj";
import { validarTelefoneBrCom, MENSAGENS_TELEFONE_EMPRESA } from "@/lib/whatsapp";
import { CampoMascarado } from "@/components/CampoMascarado";
import { mascararCnpj, mascararTelefoneBr } from "@/lib/mascara-campo";
import { UFS_BRASIL } from "@/lib/uf";

export const Route = createFileRoute("/_authenticated/app/onboarding")({
  component: OnboardingPage,
});

function OnboardingPage() {
  const navigate = useNavigate();
  const { refresh, setActiveCompanyId, hasCompany, loading } = useCompany();
  const [companyName, setCompanyName] = useState("");
  const [cnpj, setCnpj] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("");
  const [uf, setUf] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  // Se já tem empresa (ex.: reload após concluir), não faz sentido ficar aqui.
  // O redirect vai para um efeito: chamar `navigate` durante o render dispara
  // atualização de outro componente (o Router) em pleno render, o que o React 19
  // rejeita e pode realimentar re-render. No efeito, roda após o commit.
  const alreadyHasCompany = !loading && hasCompany;
  useEffect(() => {
    if (alreadyHasCompany) navigate({ to: "/app" });
  }, [alreadyHasCompany, navigate]);
  if (alreadyHasCompany) return null;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return; // trava duplo clique no cliente
    const name = companyName.trim();
    if (!name) {
      setErr("Informe o nome da empresa.");
      return;
    }
    // Revisão 92 — as mesmas travas do cadastro da empresa, aqui na origem.
    //
    // Este formulário grava nas MESMAS colunas de `company_profiles` que o
    // cartão "Dados da empresa" (pela RPC `create_company_with_owner`). Validar
    // só lá deixaria a porta da frente aberta: a empresa nasceria com CNPJ
    // inválido e o defeito só apareceria quando alguém fosse editar.
    //
    // CNPJ e telefone continuam OPCIONAIS — a tela diz isso e não é esta
    // rodada que muda. Preenchidos, precisam estar certos.
    const cnpjValidado = validarCnpj(cnpj);
    if (!cnpjValidado.ok) {
      setErr(cnpjValidado.erro);
      return;
    }
    if (phone.trim()) {
      const tel = validarTelefoneBrCom(phone, MENSAGENS_TELEFONE_EMPRESA);
      if (!tel.ok) {
        setErr(tel.erro);
        return;
      }
    }

    setSubmitting(true);
    setErr(null);
    try {
      // A identidade vem da sessão validada no servidor (auth.uid() na RPC).
      // Nenhum user_id/owner_id/company_id é enviado pelo cliente.
      // `as any`: a RPC nova ainda não consta em types.ts (gerado; será
      // regenerado após o push remoto). Mesmo padrão já usado no projeto.
      const { data, error } = await (supabase.rpc as any)("create_company_with_owner", {
        p_company_name: name,
        // CNPJ canônico (14 caracteres, sem máscara, maiúsculas) — a máscara é
        // apresentação, não dado. `cnpjValidado.cnpj` é "" quando o campo veio
        // vazio, e aí grava NULL, como antes.
        p_cnpj: cnpjValidado.cnpj || null,
        p_phone: phone.trim() || null,
        p_city: city.trim() || null,
        p_state: uf.trim() || null,
      });
      if (error) throw error;
      // A RPC devolve {company_id, company_name, role: 'owner', status: 'active'}
      // — empresa e membership owner nasceram na MESMA transação, então basta
      // recarregar as memberships e ativar a que acabou de ser criada.
      const companyId = (data as { company_id?: string } | null)?.company_id ?? null;
      const lista = await refresh();
      if (companyId && lista.some((c) => c.companyId === companyId)) {
        setActiveCompanyId(companyId);
      }
      toast.success("Empresa criada! Você é o proprietário.");
      navigate({ to: "/app" });
    } catch (e: unknown) {
      // A RPC devolve mensagens próprias (sem acento, voltadas a diagnóstico) e
      // uma queda de rede devolveria "Failed to fetch". Nenhuma das duas é texto
      // de produto — o mapeador escolhe a frase e o erro inteiro vai ao console.
      setErr(
        mensagemDeErroDeAuth("onboarding", e, "Não foi possível criar a empresa. Tente novamente."),
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-xl flex-col justify-center">
      <div className="rounded-3xl border bg-card p-8 shadow-xl">
        <div className="mb-6 flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary">
            <Building2 className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Crie sua empresa</h1>
            <p className="text-sm text-muted-foreground">
              Para começar a usar o sistema, cadastre sua empresa. Você será o proprietário.
            </p>
          </div>
        </div>

        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="mb-1 block text-sm font-medium">
              Nome da empresa <span className="text-red-500">*</span>
            </label>
            <input
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              required
              autoFocus
              maxLength={160}
              placeholder="Ex.: Vidraçaria Central"
              className="w-full rounded-xl border bg-background px-3 py-2 outline-none focus:border-primary"
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {/* Máscara em tempo real (Revisão 95). Ela é APRESENTAÇÃO: não
                recusa nada — "12.AB" segue sendo um estado legítimo de
                digitação — e a validação continua acontecendo só no envio,
                logo acima, por `validarCnpj` / `validarTelefoneBrCom`. */}
            <div>
              <label className="mb-1 block text-sm font-medium">
                CNPJ <span className="text-muted-foreground">(opcional)</span>
              </label>
              <CampoMascarado
                value={cnpj}
                onChange={setCnpj}
                mascara={mascararCnpj}
                inputMode="text"
                placeholder="00.000.000/0000-00"
                className="w-full rounded-xl border bg-background px-3 py-2 outline-none focus:border-primary"
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium">
                Telefone <span className="text-muted-foreground">(opcional)</span>
              </label>
              <CampoMascarado
                value={phone}
                onChange={setPhone}
                mascara={mascararTelefoneBr}
                inputMode="tel"
                placeholder="(00) 00000-0000"
                className="w-full rounded-xl border bg-background px-3 py-2 outline-none focus:border-primary"
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium">
                Cidade <span className="text-muted-foreground">(opcional)</span>
              </label>
              <input
                value={city}
                onChange={(e) => setCity(e.target.value)}
                maxLength={80}
                className="w-full rounded-xl border bg-background px-3 py-2 outline-none focus:border-primary"
              />
            </div>
            {/* UF é conjunto FECHADO de 27 valores: um select resolve máscara e
                validação de uma vez, e o campo deixa de aceitar "XX" — o que o
                `toUpperCase().slice(0, 2)` de antes aceitava sem reclamar. */}
            <div>
              <label className="mb-1 block text-sm font-medium">
                UF <span className="text-muted-foreground">(opcional)</span>
              </label>
              <select
                value={uf}
                onChange={(e) => setUf(e.target.value)}
                className="w-full rounded-xl border bg-background px-3 py-2 outline-none focus:border-primary"
              >
                <option value="">—</option>
                {UFS_BRASIL.map((sigla) => (
                  <option key={sigla} value={sigla}>
                    {sigla}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {err && (
            <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-600 dark:text-red-300">
              {err}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 font-semibold text-primary-foreground hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {submitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> Criando…
              </>
            ) : (
              "Criar empresa e continuar"
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
