import { createFileRoute } from "@tanstack/react-router";
import { InventorySpecialtyPage } from "@/components/inventory/InventorySpecialtyPage";
import { ModuleLockedCard } from "@/components/ModuleLockedCard";
import { getPlanFromStorage, hasModuleAccess } from "@/lib/module-access";

export const Route = createFileRoute("/_authenticated/app/vidros")({ component: VidrosPage });

function VidrosPage() {
  const plan = getPlanFromStorage();
  const allowed = hasModuleAccess(plan, "vidros");

  if (!allowed) return <ModuleLockedCard moduleKey="vidros" />;

  return (
    <InventorySpecialtyPage
      title="Vidros"
      description="Gerencie os vidros disponíveis no estoque da empresa."
      lockedCategoria="vidro"
      defaultUnidade="m2"
      createLabel="Novo vidro"
      emptyTitle="Nenhum vidro cadastrado."
      emptyCta="Cadastrar vidro"
      dialogCreateTitle="Novo vidro"
    />
  );
}
