import { createFileRoute, Link, useNavigate, type SearchSchemaInput } from "@tanstack/react-router";
import { parseEspecialidade, type Especialidade } from "@/lib/especialidade";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, Check, Home, Plus, HelpCircle } from "lucide-react";
import { toast } from "sonner";

const AMBIENTES_PRESET = [
  "Quarto",
  "Sala",
  "Cozinha",
  "Varanda",
  "Suite",
  "Hall",
  "Banheiro",
  "Lavanderia",
  "Lavabo",
  "Garagem",
  "Terraço",
  "Escada",
  "Outros",
  "Área Gourmet",
  "Closet",
  "Jardim de Inverno",
  "Escritório",
  "Loja",
  "Consultório",
];

/** O que `Link`/`navigate` podem informar — tudo opcional, os defaults vêm do validateSearch. */
type AmbientesSearchInput = {
  cliente?: string;
  esp?: Especialidade;
} & SearchSchemaInput;

/** O que `Route.useSearch()` devolve — defaults já aplicados; `""` = sem especialidade. */
type AmbientesSearch = {
  cliente: string;
  esp: Especialidade | "";
};

export const Route = createFileRoute("/_authenticated/app/orcamentos/ambientes")({
  validateSearch: (search: AmbientesSearchInput): AmbientesSearch => ({
    cliente: typeof search.cliente === "string" ? search.cliente : "",
    esp: parseEspecialidade(search.esp) ?? "",
  }),
  component: AmbientesPage,
});

function AmbientesPage() {
  const { cliente, esp } = Route.useSearch();
  const navigate = useNavigate();
  const [selecionados, setSelecionados] = useState<string[]>([]);
  const [novo, setNovo] = useState("");

  const { data: customer } = useQuery({
    queryKey: ["customer-amb", cliente],
    enabled: !!cliente,
    queryFn: async () => {
      const { data } = await supabase
        .from("customers")
        .select("id,nome")
        .eq("id", cliente)
        .maybeSingle();
      return data;
    },
  });

  const toggle = (nome: string) =>
    setSelecionados((arr) => (arr.includes(nome) ? arr.filter((n) => n !== nome) : [...arr, nome]));

  const adicionarPersonalizado = () => {
    const v = novo.trim();
    if (!v) return;
    if (selecionados.includes(v)) return setNovo("");
    setSelecionados((arr) => [...arr, v]);
    setNovo("");
  };

  const continuar = () => {
    if (selecionados.length === 0) {
      return toast.error("Selecione ao menos um ambiente");
    }
    // REMOVIDA na Revisão 50: a gravação de
    // `sessionStorage["ambientes:selecionados"]`.
    //
    // Era escrita MORTA. A chave entrou no commit inicial do repositório e
    // NUNCA foi lida — conferido em toda a história (`git log -S`): nenhum
    // `getItem("ambientes:selecionados")` jamais existiu. O destino
    // (`/app/projetos`) valida apenas `cliente` no `validateSearch`, então nem
    // o `esp` passado abaixo chega lá.
    //
    // ⚠️ LACUNA DE PRODUTO, registrada e NÃO implementada: a lista de
    // ambientes que o usuário acabou de montar não chega à próxima tela. Ligar
    // os dois é feature nova, não correção; ver a Revisão 50.
    navigate({ to: "/app/projetos", search: { cliente, esp } });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Link
            to="/app/orcamentos"
            search={{ view: "lista" }}
            className="inline-flex items-center gap-1 rounded-lg border border-input px-3 py-1.5 text-xs hover:bg-accent"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Voltar
          </Link>
          <div>
            <h1 className="font-display text-2xl font-bold">Ambientes da obra</h1>
            <p className="text-xs text-muted-foreground">
              Cliente: <strong className="text-foreground">{customer?.nome ?? "—"}</strong>
              {esp && (
                <>
                  {" "}
                  · Especialidade: <strong className="text-foreground capitalize">{esp}</strong>
                </>
              )}
            </p>
          </div>
        </div>
        <button className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 px-3 py-1.5 text-xs text-primary hover:bg-primary/5">
          <HelpCircle className="h-3.5 w-3.5" /> Ajuda
        </button>
      </div>

      <div className="rounded-2xl border bg-card">
        <div className="flex items-center gap-2 border-b px-5 py-3">
          <Home className="h-4 w-4 text-primary" />
          <h2 className="font-display text-sm font-bold uppercase tracking-wide">
            Selecione os ambientes
          </h2>
          <span className="ml-auto text-xs text-muted-foreground">
            {selecionados.length} selecionado{selecionados.length === 1 ? "" : "s"}
          </span>
        </div>

        <div className="p-5">
          <div className="flex flex-wrap gap-2">
            {AMBIENTES_PRESET.map((nome) => {
              const ativo = selecionados.includes(nome);
              return (
                <button
                  key={nome}
                  onClick={() => toggle(nome)}
                  className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-2 text-sm transition ${
                    ativo
                      ? "border-primary bg-primary text-primary-foreground shadow-sm"
                      : "border-input bg-background hover:border-primary/40 hover:bg-accent"
                  }`}
                >
                  {ativo && <Check className="h-3.5 w-3.5" />}
                  {nome}
                </button>
              );
            })}
          </div>

          <div className="mt-6 flex gap-2">
            <input
              value={novo}
              onChange={(e) => setNovo(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && adicionarPersonalizado()}
              placeholder="Adicionar ambiente personalizado..."
              className="flex-1 rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            />
            <button
              onClick={adicionarPersonalizado}
              className="inline-flex items-center gap-1 rounded-lg border border-input px-3 text-sm hover:bg-accent"
            >
              <Plus className="h-4 w-4" /> Adicionar
            </button>
          </div>
        </div>
      </div>

      <div className="sticky bottom-0 -mx-4 border-t bg-card/95 px-4 py-3 backdrop-blur sm:rounded-2xl sm:border">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="text-sm text-muted-foreground">
            {selecionados.length > 0 ? (
              <>
                Ambientes: <strong className="text-foreground">{selecionados.join(", ")}</strong>
              </>
            ) : (
              "Nenhum ambiente selecionado"
            )}
          </div>
          <div className="flex gap-2">
            <Link
              to="/app/orcamentos"
              search={{ view: "lista" }}
              className="rounded-lg border border-input px-4 py-2 text-sm hover:bg-accent"
            >
              Cancelar
            </Link>
            <button
              onClick={continuar}
              className="rounded-lg bg-gradient-gold px-5 py-2 text-sm font-semibold text-gold-foreground shadow-glow hover:brightness-110"
            >
              Continuar para projetos →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
