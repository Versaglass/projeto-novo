import { createFileRoute } from "@tanstack/react-router";
import { DashboardEnterprise } from "@/pages/DashboardEnterprise";

export const Route = createFileRoute("/_authenticated/app/")({
  component: DashboardEnterprise,
});
