import { createFileRoute, Link, type SearchSchemaInput } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { brl } from "@/lib/format";
import { numeroParaTexto, textoParaNumero, validaCamposNumericos } from "@/lib/numero-campo";
import {
  Plus,
  Pencil,
  Check,
  Trash2,
  Layers,
  X,
  FileText,
  Search,
  ImageIcon,
  Upload,
  AlertTriangle,
  Building2,
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Hammer,
  Sofa,
  Gem,
  Bath,
  DoorOpen,
  AppWindow,
  Fence,
  Sparkles,
  PanelsTopLeft,
  MoreHorizontal,
  Grid3x3,
  Warehouse,
  Columns3,
  Armchair,
  PanelTop,
  Table,
  LayoutGrid,
  Box,
  Droplets,
  Footprints,
  BrickWall,
  ArrowUpDown,
  Square,
  RefreshCw,
  Link2,
  Store,
  Maximize2,
  type LucideIcon,
} from "lucide-react";
import { toast } from "sonner";
import { StorageImage } from "@/components/StorageImage";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useCompany } from "@/contexts/company-context";
import { useAuth } from "@/hooks/use-auth";
import { canManageCompanyEstoque } from "@/lib/inventory-auth";
import { searchOrcamentoNovo } from "@/routes/_authenticated/app.orcamentos.novo";
import { AREAS_PROJETO, ehAreaProjeto, ROTULO_AREA, type AreaProjeto } from "@/lib/project-area";
import {
  areasDisponiveisParaCriacao,
  DEFAULT_PROJECT_AREA_VISIBILITY,
} from "@/lib/project-area-visibility";
import { useProjectAreaVisibility } from "@/hooks/use-project-area-visibility";
import {
  ehSubtipoDaArea,
  rotuloSubtipo,
  ROTULO_SUBTIPO,
  subtiposDaArea,
  type SubtipoProjeto,
} from "@/lib/project-subtypes";
import {
  useProjectTemplates,
  useProjectTemplateAreaCounts,
  useCreateProjectTemplate,
  useUpdateProjectTemplate,
  useDeleteProjectTemplate,
  uploadTemplateImage,
  deleteTemplateImageIfOwnedByCompany,
  projectTemplateErrorMessage,
  categoriaAceitaAcabamento,
  BIBLIOTECA_PAGE_SIZE,
  type ProjectTemplate,
  type ProjectTemplateCategoria,
  type ProjectTemplateAcabamento,
  type ProjectTemplateCor,
  type ProjectTemplateInput,
} from "@/hooks/use-project-templates";
import {
  INVENTORY_CATEGORIES,
  INVENTORY_UNITS,
  inventoryErrorMessage,
  optionalText,
  useCreateInventoryItem,
  type InventoryArea,
  type InventoryCategoria,
  type InventoryItemInput,
  type InventoryUnidade,
} from "@/hooks/use-inventory";
import {
  duplicateCatalogImageToCompany,
  platformCatalogErrorMessage,
  usePlatformCatalogAreaCounts,
  usePlatformProjectCatalog,
  type PlatformCatalogItem,
} from "@/hooks/use-platform-project-catalog";
import { mensagemDoErro } from "@/lib/erro-mensagem";
/** Categorias de estoque coerentes com a área do projeto (+ Geral). */
function categoriasEstoqueParaAreaProjeto(area: AreaProjeto | null | undefined) {
  if (!area) {
    return INVENTORY_CATEGORIES.filter((c) =>
      c.areas.some((a) => a === "vidracaria" || a === "esquadrias" || a === "geral"),
    );
  }
  return INVENTORY_CATEGORIES.filter(
    (c) => c.areas.includes(area as InventoryArea) || c.areas.includes("geral"),
  );
}

/** Sugestão fraca: só vidros de projeto → categoria `vidro` do estoque. */
function sugerirCategoriaEstoque(cat: ProjectTemplateCategoria): InventoryCategoria | "" {
  if (
    cat === "temperado" ||
    cat === "vidro_comum" ||
    cat === "espelho" ||
    cat === "refletivo" ||
    cat === "organico" ||
    cat === "canelado"
  ) {
    return "vidro";
  }
  return "";
}
/**
 * Áreas do fluxo hierárquico tenant: Área → Tipo → Catálogo.
 * Serralheria / Marcenaria / Marmoraria seguem na taxonomia e no wizard,
 * mas não entram neste primeiro nível de navegação.
 */
const AREAS_NAVEGACAO = ["vidracaria", "esquadrias"] as const;
type AreaNavegacao = (typeof AREAS_NAVEGACAO)[number];

function ehAreaNavegacao(valor: unknown): valor is AreaNavegacao {
  return valor === "vidracaria" || valor === "esquadrias";
}

/** O que `Link`/`navigate` podem informar. `esp` vem de app.orcamentos.ambientes. */
type ProjetosSearchInput = {
  cliente?: string;
  esp?: string;
  area?: string;
  subtipo?: string;
} & SearchSchemaInput;

type ProjetosSearch = {
  cliente?: string;
  area?: AreaNavegacao;
  subtipo?: SubtipoProjeto;
};

/** Serializa search sem chaves vazias — evita `?cliente=&area=` na URL. */
function searchProjetos(valores: {
  cliente?: string;
  area?: string;
  subtipo?: string;
}): ProjetosSearch {
  const saida: ProjetosSearch = {};
  if (typeof valores.cliente === "string" && valores.cliente.trim() !== "") {
    saida.cliente = valores.cliente.trim();
  }
  if (ehAreaNavegacao(valores.area)) {
    saida.area = valores.area;
    if (ehSubtipoDaArea(valores.area, valores.subtipo)) {
      saida.subtipo = valores.subtipo;
    }
  }
  return saida;
}

export const Route = createFileRoute("/_authenticated/app/projetos")({
  validateSearch: (search: ProjetosSearchInput): ProjetosSearch =>
    searchProjetos({
      cliente: search.cliente,
      area: search.area,
      subtipo: search.subtipo,
    }),
  component: ProjetosPage,
});

/**
 * CATEGORIA — o MATERIAL do produto (`public.project_category`).
 *
 * Não é a área e não decide filtro, agrupamento nem paleta. Ficou como
 * informação secundária do modelo depois que a área ganhou coluna própria.
 */
const CATEGORIAS: { id: ProjectTemplateCategoria; label: string }[] = [
  { id: "vidro_comum", label: "Vidro comum" },
  { id: "temperado", label: "Temperado" },
  { id: "espelho", label: "Espelho" },
  { id: "refletivo", label: "Refletivo" },
  { id: "organico", label: "Orgânico" },
  { id: "canelado", label: "Canelado" },
  { id: "esquadria", label: "Esquadria / outros" },
];
const CAT_LABEL: Record<string, string> = Object.fromEntries(
  CATEGORIAS.map((c) => [c.id, c.label]),
);

/** Processo do vidro — alinhado a `public.project_acabamento`. Opcional. */
const ACABAMENTOS: { id: ProjectTemplateAcabamento; label: string }[] = [
  { id: "cortado", label: "Cortado" },
  { id: "lapidado", label: "Lapidado" },
  { id: "bisote", label: "Bisotê" },
  { id: "com_moldura", label: "Com moldura" },
];

/** Cor do refletivo — alinhado a `public.project_cor_refletivo`. Opcional
 *  (CHECK aceita `cor IS NULL` mesmo com categoria=refletivo). */
const CORES_REFLETIVO: { id: ProjectTemplateCor; label: string }[] = [
  { id: "prata", label: "Prata" },
  { id: "neutro", label: "Neutro" },
  { id: "champanhe", label: "Champanhe" },
  { id: "cinza", label: "Cinza" },
  { id: "verde", label: "Verde" },
  { id: "azul", label: "Azul" },
];

/** Mesmos valores do grupo de chips em Orçamentos (`app.orcamentos.novo`). */
const ESPESSURAS_VIDRO = ["4mm", "6mm", "8mm", "10mm", "12mm"] as const;

/** ÁREA — classificação principal. Usada nos chips e no wizard de criação. */
const DESCRICAO_AREA: Record<AreaProjeto, string> = {
  vidracaria: "Janelas, portas, box, espelhos, sacadas e fechamentos.",
  esquadrias: "Janelas, portas, maxim-ar, fachadas e portões de alumínio.",
  serralheria: "Portões, grades, estruturas e esquadrias de aço.",
  marcenaria: "Armários, painéis, closets e móveis planejados.",
  marmoraria: "Bancadas, soleiras, cubas e peças em pedra.",
};

const ICONE_AREA: Record<AreaProjeto, LucideIcon> = {
  vidracaria: Layers,
  esquadrias: AppWindow,
  serralheria: Hammer,
  marcenaria: Sofa,
  marmoraria: Gem,
};

const ICONE_SUBTIPO: Record<SubtipoProjeto, LucideIcon> = {
  // Vidraçaria — 13 tipos comerciais (Lucide; sem assets dedicados novos).
  janela: AppWindow,
  porta: DoorOpen,
  fixo: Square,
  box: Bath,
  fechamento_pia: Droplets,
  espelho: Sparkles,
  bascula_maxiar_pivotante: PanelTop,
  guarda_corpo: Fence,
  reposicao: RefreshCw,
  sacadas: Building2,
  articulados: Link2,
  muro: BrickWall,
  vitrine: Store,
  // Esquadrias — 13 tipos comerciais (Lucide; IDs com sufixo `_esquadrias`).
  janela_esquadrias: AppWindow,
  porta_esquadrias: DoorOpen,
  maxim_ar_esquadrias: Maximize2,
  fixos_esquadrias: Square,
  portao_esquadrias: Warehouse,
  fachada_esquadrias: Building2,
  porta_pivotante_esquadrias: DoorOpen,
  diversos_esquadrias: MoreHorizontal,
  basculantes_esquadrias: PanelTop,
  janela_pivotante_esquadrias: AppWindow,
  camarao_esquadrias: PanelsTopLeft,
  janela_abrir_esquadrias: AppWindow,
  gradil_esquadrias: Grid3x3,
  portao: Warehouse,
  grade: Grid3x3,
  corrimao: Columns3,
  estrutura_metalica: Hammer,
  cobertura: PanelTop,
  esquadria_metalica: AppWindow,
  outro_serralheria: MoreHorizontal,
  armario: Armchair,
  porta_madeira: DoorOpen,
  painel: LayoutGrid,
  bancada_madeira: Table,
  movel_planejado: Box,
  prateleira: Layers,
  outro_marcenaria: MoreHorizontal,
  bancada_pedra: Table,
  pia: Droplets,
  soleira: Footprints,
  revestimento: BrickWall,
  escada: ArrowUpDown,
  peitoril: Columns3,
  outro_marmoraria: MoreHorizontal,
};

/** Cards grandes de área — passo 1 do wizard "Novo projeto". */
function CartoesArea({
  onEscolher,
  contagens,
  areas,
}: {
  onEscolher: (area: AreaProjeto) => void;
  contagens?: Partial<Record<AreaProjeto | "todos", number>>;
  /** Áreas habilitadas pela config global (+ Vidraçaria). */
  areas: readonly AreaProjeto[];
}) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {areas.map((a) => {
        const Icon = ICONE_AREA[a];
        const n = contagens?.[a];
        return (
          <button
            key={a}
            type="button"
            onClick={() => onEscolher(a)}
            className="rounded-xl border border-border bg-background px-4 py-6 text-left transition hover:border-gold/50 hover:bg-gold/10"
          >
            <Icon className="mb-2 h-6 w-6 text-gold" />
            <div className="font-display text-lg font-semibold">{ROTULO_AREA[a]}</div>
            <div className="mt-0.5 text-xs text-muted-foreground">{DESCRICAO_AREA[a]}</div>
            {n !== undefined && (
              <div className="mt-3 text-xs font-semibold text-muted-foreground">
                {n} {n === 1 ? "modelo" : "modelos"}
              </div>
            )}
          </button>
        );
      })}
    </div>
  );
}

/** Tipos da área — passo 2 do wizard "Novo projeto". Sem atalho "Todos". */
function CartoesSubtipo({
  area,
  onEscolher,
  contagens,
}: {
  area: AreaProjeto;
  onEscolher: (s: SubtipoProjeto) => void;
  contagens?: Partial<Record<SubtipoProjeto, number>>;
}) {
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {subtiposDaArea(area).map((s) => {
        const Icon = ICONE_SUBTIPO[s];
        const n = contagens?.[s] ?? 0;
        return (
          <button
            key={s}
            type="button"
            onClick={() => onEscolher(s)}
            className="rounded-xl border border-border bg-background px-4 py-6 text-left transition hover:border-gold/50 hover:bg-gold/10"
          >
            <Icon className="mb-2 h-6 w-6 text-gold" />
            <div className="font-display text-lg font-semibold">{ROTULO_SUBTIPO[s]}</div>
            {contagens && (
              <div className="mt-2 text-xs font-semibold text-muted-foreground">
                {n} {n === 1 ? "projeto" : "projetos"}
              </div>
            )}
          </button>
        );
      })}
    </div>
  );
}

const MANAGER_ROLES = ["owner", "admin", "manager"];

function ProjetosPage() {
  const { cliente, area: areaNav, subtipo: subtipoNav } = Route.useSearch();
  const navigate = Route.useNavigate();
  const { activeCompany, companyRole } = useCompany();
  const { user, permissions } = useAuth();

  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [editing, setEditing] = useState<Partial<ProjectTemplate> | null>(null);
  const [stockFromProject, setStockFromProject] = useState<ProjectTemplate | null>(null);
  const [confirmDel, setConfirmDel] = useState<ProjectTemplate | null>(null);

  const canManageAllRole = MANAGER_ROLES.includes(companyRole ?? "");
  const canWriteStock = canManageCompanyEstoque({
    hasActiveCompany: Boolean(activeCompany?.companyId),
    companyRole,
    permissions,
  });
  const noCatalogo = !!areaNav && !!subtipoNav;

  // Nível área/tipo: carrega a área inteira (sem busca) para contagens.
  // Nível catálogo: filtra área + subtipo + busca.
  const filtroArea = areaNav ?? "todos";
  const filtroSubtipo = noCatalogo && subtipoNav ? subtipoNav : "todos";
  const filtroBusca = noCatalogo ? query : "";

  const {
    data: pagina,
    isLoading,
    isError,
    refetch,
    hasActiveCompany,
    companyLoading,
  } = useProjectTemplates(filtroBusca, filtroArea, filtroSubtipo, canManageAllRole, 1, 500);
  const del = useDeleteProjectTemplate();

  const {
    data: catalogItems = [],
    isLoading: catalogLoading,
    isError: catalogError,
    refetch: refetchCatalog,
  } = usePlatformProjectCatalog({
    incluirInativos: false,
    search: filtroBusca,
    area: filtroArea,
    subtipo: filtroSubtipo,
  });

  // Contagens dos cards de área = mesma elegibilidade dos cards de tipo
  // (`ehSubtipoDaArea` / taxonomia atual). Sem `apenasNavegaveis`, subtipos
  // legados inflavam o número (ex.: 4 modelos vs Janela+Porta = 2).
  const { data: contagensEmpresa } = useProjectTemplateAreaCounts("", canManageAllRole, {
    apenasNavegaveis: true,
  });
  const { data: contagensCatalogo } = usePlatformCatalogAreaCounts({
    search: "",
    incluirInativos: false,
    area: "todos",
    apenasNavegaveis: true,
  });

  type ProjetoListaItem =
    | { origem: "empresa"; template: ProjectTemplate }
    | { origem: "global"; catalog: PlatformCatalogItem };

  const listaUnificada = useMemo((): ProjetoListaItem[] => {
    const templates = pagina?.items ?? [];
    const empresa: ProjetoListaItem[] = hasActiveCompany
      ? templates.map((template) => ({ origem: "empresa" as const, template }))
      : [];
    const global: ProjetoListaItem[] = catalogItems.map((catalog) => ({
      origem: "global" as const,
      catalog,
    }));
    return [...empresa, ...global].sort((a, b) => {
      const nomeA = a.origem === "empresa" ? a.template.nome : a.catalog.nome;
      const nomeB = b.origem === "empresa" ? b.template.nome : b.catalog.nome;
      return nomeA.localeCompare(nomeB, "pt-BR");
    });
  }, [pagina?.items, catalogItems, hasActiveCompany]);

  const contagensArea = useMemo(() => {
    const merged: Partial<Record<AreaProjeto | "todos", number>> = {};
    const add = (src?: Partial<Record<string, number>>) => {
      if (!src) return;
      for (const [k, v] of Object.entries(src)) {
        merged[k as AreaProjeto | "todos"] = (merged[k as AreaProjeto | "todos"] ?? 0) + (v ?? 0);
      }
    };
    if (hasActiveCompany) add(contagensEmpresa);
    add(contagensCatalogo?.areas);
    return merged;
  }, [contagensEmpresa, contagensCatalogo, hasActiveCompany]);

  const contagensSubtipo = useMemo(() => {
    if (!areaNav || noCatalogo) return undefined;
    const counts: Partial<Record<SubtipoProjeto, number>> = {};
    for (const item of listaUnificada) {
      const s = item.origem === "empresa" ? item.template.subtipo : item.catalog.subtipo;
      if (!s || !ehSubtipoDaArea(areaNav, s)) continue;
      counts[s] = (counts[s] ?? 0) + 1;
    }
    return counts;
  }, [areaNav, noCatalogo, listaUnificada]);

  const total = listaUnificada.length;
  const totalPaginas = Math.max(1, Math.ceil(total / BIBLIOTECA_PAGE_SIZE));
  useEffect(() => {
    if (page > totalPaginas) setPage(totalPaginas);
  }, [page, totalPaginas]);
  useEffect(() => {
    setPage(1);
  }, [areaNav, subtipoNav, query]);

  const paginaItens = useMemo(() => {
    const from = (page - 1) * BIBLIOTECA_PAGE_SIZE;
    return listaUnificada.slice(from, from + BIBLIOTECA_PAGE_SIZE);
  }, [listaUnificada, page]);

  const canManageAll = canManageAllRole;
  const canManage = (t: ProjectTemplate) => canManageAll || t.owner_id === user?.id;
  /** Exclusão = autoria (`owner_id`), não papel manage da empresa. */
  const canDeleteOwn = (t: ProjectTemplate) => !!user?.id && t.owner_id === user.id;

  const irPara = (next: { area?: AreaNavegacao; subtipo?: SubtipoProjeto }) => {
    void navigate({
      search: searchProjetos({
        cliente,
        area: next.area,
        subtipo: next.subtipo,
      }),
    });
  };

  const { data: clienteInfo } = useQuery({
    queryKey: ["cliente-info", activeCompany?.companyId, cliente],
    enabled: !!cliente && !!activeCompany?.companyId,
    queryFn: async () => {
      const { data } = await supabase
        .from("customers")
        .select("nome")
        .eq("id", cliente!)
        .eq("company_id", activeCompany!.companyId)
        .maybeSingle();
      return data;
    },
  });

  const onDelete = () => {
    if (!confirmDel) return;
    if (!user?.id || confirmDel.owner_id !== user.id) {
      toast.error("Você só pode excluir projetos que você mesmo criou.");
      setConfirmDel(null);
      return;
    }
    del.mutate(
      { id: confirmDel.id },
      {
        onSuccess: () => {
          toast.success("Projeto excluído");
          setConfirmDel(null);
        },
        onError: (e) =>
          toast.error(e instanceof Error ? e.message : projectTemplateErrorMessage(e)),
      },
    );
  };

  const listLoading = !!areaNav && ((hasActiveCompany && isLoading) || catalogLoading);
  const listError = !!areaNav && ((hasActiveCompany && isError) || catalogError);
  const retryList = () => {
    if (hasActiveCompany) void refetch();
    void refetchCatalog();
  };

  const abrirNovoProjeto = () => {
    if (!areaNav || !subtipoNav) return;
    setEditing(novoModelo({ area: areaNav, subtipo: subtipoNav }));
  };

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Projetos</h1>
          <p className="text-sm text-muted-foreground">
            {noCatalogo
              ? `${ROTULO_AREA[areaNav]} · ${ROTULO_SUBTIPO[subtipoNav]}`
              : areaNav
                ? `Escolha o tipo em ${ROTULO_AREA[areaNav]}`
                : "Escolha uma área para ver os tipos e projetos"}
          </p>
          {(areaNav || subtipoNav) && (
            <nav className="mt-2 flex flex-wrap items-center gap-1 text-xs text-muted-foreground">
              <button
                type="button"
                onClick={() => irPara({})}
                className="font-semibold hover:text-foreground"
              >
                Projetos
              </button>
              {areaNav && (
                <>
                  <span aria-hidden>›</span>
                  <button
                    type="button"
                    onClick={() => irPara({ area: areaNav })}
                    className={
                      subtipoNav
                        ? "font-semibold hover:text-foreground"
                        : "font-semibold text-foreground"
                    }
                  >
                    {ROTULO_AREA[areaNav]}
                  </button>
                </>
              )}
              {areaNav && subtipoNav && (
                <>
                  <span aria-hidden>›</span>
                  <span className="font-semibold text-foreground">
                    {ROTULO_SUBTIPO[subtipoNav]}
                  </span>
                </>
              )}
            </nav>
          )}
        </div>
        {noCatalogo && canManageAll && hasActiveCompany && (
          <button
            onClick={abrirNovoProjeto}
            className="inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-4 py-2.5 text-sm font-semibold text-gold-foreground shadow-glow hover:opacity-95"
          >
            <Plus className="h-4 w-4" /> Novo projeto
          </button>
        )}
      </div>

      {!companyLoading && !hasActiveCompany && (
        <div className="mb-5 rounded-xl border border-border bg-card px-4 py-3 text-sm text-muted-foreground">
          Selecione ou participe de uma empresa para administrar seus modelos técnicos. O catálogo
          global continua disponível abaixo.
        </div>
      )}

      {hasActiveCompany && !canManageAll && noCatalogo && (
        <div className="mb-5 rounded-xl border border-border bg-muted/40 px-4 py-3 text-xs text-muted-foreground">
          Você pode consultar os modelos e usá-los em orçamentos. Criar, editar e excluir modelos é
          permitido a owner, admin e manager da empresa.
        </div>
      )}

      {cliente && clienteInfo && (
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-gold/40 bg-gold/10 px-4 py-3 text-sm">
          <div>
            <span className="text-muted-foreground">Selecione um projeto para o orçamento de </span>
            <strong className="text-gold">{clienteInfo.nome}</strong>
          </div>
          <Link
            to="/app/orcamentos/novo"
            search={searchOrcamentoNovo({ cliente })}
            className="rounded-md border border-gold/40 bg-background px-3 py-1.5 text-xs font-semibold text-gold hover:bg-gold/20"
          >
            Pular e criar em branco
          </Link>
        </div>
      )}

      {/* Nível 1 — áreas */}
      {!areaNav && (
        <div className="space-y-4">
          <h2 className="font-display text-xl font-semibold">Escolha uma área</h2>
          <CartoesArea
            areas={AREAS_NAVEGACAO}
            contagens={contagensArea}
            onEscolher={(a) => {
              if (ehAreaNavegacao(a)) irPara({ area: a });
            }}
          />
        </div>
      )}

      {/* Nível 2 — tipos */}
      {areaNav && !subtipoNav && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => irPara({})}
              className="inline-flex items-center gap-1 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold hover:bg-accent"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> Voltar
            </button>
            <h2 className="font-display text-xl font-semibold">
              Escolha o tipo · {ROTULO_AREA[areaNav]}
            </h2>
          </div>
          {listLoading ? (
            <p className="text-muted-foreground">Carregando...</p>
          ) : listError ? (
            <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-8 text-center">
              <AlertTriangle className="mx-auto h-8 w-8 text-destructive" />
              <p className="mt-3 text-sm text-muted-foreground">
                Não foi possível carregar os projetos.
              </p>
              <button
                onClick={retryList}
                className="mt-4 rounded-lg border border-input px-4 py-2 text-sm font-medium hover:bg-accent"
              >
                Tentar novamente
              </button>
            </div>
          ) : (
            <CartoesSubtipo
              area={areaNav}
              contagens={contagensSubtipo}
              onEscolher={(s) => irPara({ area: areaNav, subtipo: s })}
            />
          )}
        </div>
      )}

      {/* Nível 3 — catálogo unificado */}
      {noCatalogo && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => irPara({ area: areaNav })}
              className="inline-flex items-center gap-1 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold hover:bg-accent"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> Voltar
            </button>
          </div>

          <div className="relative max-w-xl">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar projeto..."
              className="w-full rounded-lg border border-input bg-background py-2 pl-9 pr-3 text-sm outline-none focus:ring-2 ring-ring"
            />
          </div>

          {listLoading ? (
            <p className="text-muted-foreground">Carregando...</p>
          ) : listError ? (
            <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-8 text-center">
              <AlertTriangle className="mx-auto h-8 w-8 text-destructive" />
              <p className="mt-3 text-sm text-muted-foreground">
                Não foi possível carregar os projetos.
              </p>
              <button
                onClick={retryList}
                className="mt-4 rounded-lg border border-input px-4 py-2 text-sm font-medium hover:bg-accent"
              >
                Tentar novamente
              </button>
            </div>
          ) : listaUnificada.length === 0 ? (
            <div className="rounded-2xl border border-border bg-card p-12 text-center">
              <Layers className="mx-auto h-10 w-10 text-muted-foreground" />
              <p className="mt-3 text-sm text-muted-foreground">
                {query
                  ? `Nenhum projeto encontrado para essa busca em ${ROTULO_AREA[areaNav]} / ${ROTULO_SUBTIPO[subtipoNav]}.`
                  : "Nenhum projeto disponível neste tipo."}
              </p>
              {!query && canManageAll && hasActiveCompany && (
                <button
                  onClick={abrirNovoProjeto}
                  className="mt-4 inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-4 py-2.5 text-sm font-semibold text-gold-foreground shadow-glow hover:opacity-95"
                >
                  <Plus className="h-4 w-4" /> Criar projeto
                </button>
              )}
              {!query && hasActiveCompany && !canManageAll && (
                <p className="mt-2 text-xs text-muted-foreground">
                  Peça a um owner, admin ou manager da empresa para cadastrar os modelos.
                </p>
              )}
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
                {paginaItens.map((item) => {
                  if (item.origem === "global") {
                    const c = item.catalog;
                    const m2 = Number(c.largura_padrao) * Number(c.altura_padrao);
                    const subtotal = m2 * Number(c.preco_referencia_m2);
                    return (
                      <div
                        key={`global-${c.id}`}
                        className="overflow-hidden rounded-2xl border border-border bg-card transition hover:border-gold/40 hover:shadow-elegant"
                      >
                        <div className="relative aspect-[4/3] bg-muted/40">
                          {c.imagem_url ? (
                            <StorageImage
                              bucket="platform-catalog"
                              src={c.imagem_url}
                              alt={c.nome}
                              className="h-full w-full object-cover"
                            />
                          ) : (
                            <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                              <ImageIcon className="h-10 w-10 opacity-40" />
                            </div>
                          )}
                          <div className="absolute left-3 top-3 z-20 flex gap-2">
                            <span className="rounded-full bg-background/90 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-foreground">
                              {ROTULO_AREA[c.area]}
                            </span>
                          </div>
                        </div>
                        <div className="p-5">
                          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                            {ROTULO_AREA[c.area]}
                          </div>
                          {rotuloSubtipo(c.subtipo) && (
                            <div className="text-sm font-semibold text-foreground">
                              {rotuloSubtipo(c.subtipo)}
                            </div>
                          )}
                          {c.area === "vidracaria" && (
                            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                              Categoria: {CAT_LABEL[c.categoria] ?? c.categoria}
                            </div>
                          )}
                          <h3 className="mt-1 font-display text-lg font-semibold leading-tight">
                            {c.nome}
                          </h3>
                          {c.espessura && (
                            <div className="mt-0.5 text-xs text-muted-foreground">
                              Espessura: {c.espessura}
                            </div>
                          )}
                          {c.descricao && (
                            <p className="mt-2 min-h-[42px] text-sm text-muted-foreground">
                              {c.descricao}
                            </p>
                          )}
                          <div className="mt-4 grid grid-cols-3 gap-2 rounded-xl bg-muted/40 p-3">
                            <Mini
                              label="Largura"
                              value={`${Number(c.largura_padrao).toFixed(2)} m`}
                            />
                            <Mini
                              label="Altura"
                              value={`${Number(c.altura_padrao).toFixed(2)} m`}
                            />
                            <Mini label="R$/m²" value={brl(Number(c.preco_referencia_m2))} />
                          </div>
                          <div className="mt-4 flex items-center justify-between gap-2">
                            <div>
                              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                                Subtotal padrão
                              </div>
                              <div className="font-display text-xl font-bold text-gold">
                                {brl(subtotal)}
                              </div>
                            </div>
                            <Link
                              to="/app/orcamentos/novo"
                              search={searchOrcamentoNovo({ cliente, catalogId: c.id })}
                              className="inline-flex items-center gap-1.5 rounded-lg border border-gold/40 bg-gold/10 px-3 py-2 text-xs font-semibold text-gold hover:bg-gold/20"
                            >
                              <FileText className="h-3.5 w-3.5" />{" "}
                              {cliente ? "Selecionar" : "Aplicar"}
                            </Link>
                          </div>
                        </div>
                      </div>
                    );
                  }

                  const t = item.template;
                  const m2 = Number(t.largura_padrao) * Number(t.altura_padrao);
                  const subtotal = m2 * Number(t.preco_m2);
                  const manage = canManage(t);
                  return (
                    <div
                      key={`empresa-${t.id}`}
                      className="group overflow-hidden rounded-2xl border border-border bg-card transition hover:border-gold/40 hover:shadow-elegant"
                    >
                      <div className="relative aspect-[4/3] bg-muted/40">
                        {t.imagem_url ? (
                          <StorageImage
                            src={t.imagem_url}
                            alt={t.nome}
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                            <ImageIcon className="h-10 w-10 opacity-40" />
                          </div>
                        )}
                        <div className="absolute left-3 top-3 z-20 flex gap-2">
                          {t.area && (
                            <span className="rounded-full bg-background/90 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-foreground">
                              {ROTULO_AREA[t.area]}
                            </span>
                          )}
                          {!t.ativo && (
                            <span className="rounded-full bg-muted px-2 py-0.5 text-[10px] font-semibold uppercase text-muted-foreground">
                              Inativo
                            </span>
                          )}
                        </div>
                        {(manage || canDeleteOwn(t)) && (
                          <div className="absolute right-3 top-3 z-20 flex gap-1 opacity-0 transition group-hover:opacity-100 max-sm:opacity-100">
                            {manage && (
                              <button
                                type="button"
                                onClick={() => setEditing(t)}
                                title="Editar dados do modelo"
                                className="rounded-md bg-background/90 p-1.5 text-muted-foreground hover:text-foreground"
                              >
                                <Pencil className="h-4 w-4" />
                              </button>
                            )}
                            {canDeleteOwn(t) && (
                              <button
                                type="button"
                                onClick={() => setConfirmDel(t)}
                                title="Excluir projeto"
                                className="rounded-md bg-background/90 p-1.5 text-muted-foreground hover:text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                      <div className="p-5">
                        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                          {t.area ? ROTULO_AREA[t.area] : "Área não definida"}
                        </div>
                        {rotuloSubtipo(t.subtipo) && (
                          <div className="text-sm font-semibold text-foreground">
                            {rotuloSubtipo(t.subtipo)}
                          </div>
                        )}
                        {(t.area === "vidracaria" || t.area === null) && (
                          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                            Categoria: {CAT_LABEL[t.categoria] ?? t.categoria}
                          </div>
                        )}
                        <h3 className="mt-1 font-display text-lg font-semibold leading-tight">
                          {t.nome}
                        </h3>
                        {t.espessura && (
                          <div className="mt-0.5 text-xs text-muted-foreground">
                            Espessura: {t.espessura}
                          </div>
                        )}
                        <div className="mt-1 text-[11px] text-muted-foreground">
                          {t.desenho_versao != null
                            ? "✓ Desenho configurado"
                            : "Sem desenho configurado"}
                        </div>
                        {t.descricao && (
                          <p className="mt-2 min-h-[42px] text-sm text-muted-foreground">
                            {t.descricao}
                          </p>
                        )}
                        <div className="mt-4 grid grid-cols-3 gap-2 rounded-xl bg-muted/40 p-3">
                          <Mini
                            label="Largura"
                            value={`${Number(t.largura_padrao).toFixed(2)} m`}
                          />
                          <Mini label="Altura" value={`${Number(t.altura_padrao).toFixed(2)} m`} />
                          <Mini label="R$/m²" value={brl(Number(t.preco_m2))} />
                        </div>
                        <div className="mt-4 flex items-center justify-between gap-2">
                          <div>
                            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                              Subtotal padrão
                            </div>
                            <div className="font-display text-xl font-bold text-gold">
                              {brl(subtotal)}
                            </div>
                          </div>
                          <div className="flex flex-wrap justify-end gap-2">
                            {manage && canWriteStock && (
                              <button
                                type="button"
                                onClick={() => setStockFromProject(t)}
                                className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-xs font-semibold hover:border-gold/40 hover:bg-gold/10"
                              >
                                <Warehouse className="h-3.5 w-3.5" /> Adicionar ao estoque
                              </button>
                            )}
                            {t.ativo ? (
                              <Link
                                to="/app/orcamentos/novo"
                                search={searchOrcamentoNovo({ cliente, templateId: t.id })}
                                className="inline-flex items-center gap-1.5 rounded-lg border border-gold/40 bg-gold/10 px-3 py-2 text-xs font-semibold text-gold hover:bg-gold/20"
                              >
                                <FileText className="h-3.5 w-3.5" />{" "}
                                {cliente ? "Selecionar" : "Orçar"}
                              </Link>
                            ) : (
                              <span
                                title="Modelo inativo não pode ser usado em orçamento"
                                className="inline-flex cursor-not-allowed items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-xs font-semibold text-muted-foreground opacity-60"
                              >
                                <FileText className="h-3.5 w-3.5" /> Orçar
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              {total > 0 && (
                <div className="mt-4 flex flex-wrap items-center justify-between gap-2 text-sm text-muted-foreground">
                  <span>
                    {total} {total === 1 ? "projeto" : "projetos"}
                    {totalPaginas > 1 && (
                      <>
                        {" "}
                        · página {page} de {totalPaginas}
                      </>
                    )}
                  </span>
                  {totalPaginas > 1 && (
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        disabled={page <= 1}
                        onClick={() => setPage((p) => Math.max(1, p - 1))}
                        className="inline-flex items-center gap-1 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold hover:bg-accent disabled:cursor-not-allowed disabled:opacity-40"
                      >
                        <ChevronLeft className="h-4 w-4" /> Anterior
                      </button>
                      <button
                        type="button"
                        disabled={page >= totalPaginas}
                        onClick={() => setPage((p) => Math.min(totalPaginas, p + 1))}
                        className="inline-flex items-center gap-1 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold hover:bg-accent disabled:cursor-not-allowed disabled:opacity-40"
                      >
                        Próxima <ChevronRight className="h-4 w-4" />
                      </button>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      )}

      {editing && (
        <EditModal
          value={editing}
          canManage={canManageAll || (!!editing.id && editing.owner_id === user?.id)}
          podeAlterarArea={canManageAll}
          onClose={() => setEditing(null)}
        />
      )}
      {stockFromProject && (
        <AddProjectToStockDialog
          template={stockFromProject}
          onClose={() => setStockFromProject(null)}
        />
      )}
      {confirmDel && (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4"
          onClick={() => setConfirmDel(null)}
        >
          <div
            className="w-full max-w-sm rounded-2xl bg-card p-6 shadow-elegant"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="font-display text-lg font-bold">Excluir projeto?</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              O projeto “{confirmDel.nome}” será removido da sua biblioteca de projetos. Esta ação
              não remove orçamentos ou itens de estoque já criados a partir dele.
            </p>
            <div className="mt-4 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmDel(null)}
                disabled={del.isPending}
                className="rounded-lg border border-input px-4 py-2 text-sm disabled:opacity-50"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={onDelete}
                disabled={del.isPending}
                className="rounded-lg bg-destructive px-4 py-2 text-sm font-semibold text-destructive-foreground disabled:cursor-not-allowed disabled:opacity-50"
              >
                {del.isPending ? "Excluindo..." : "Excluir projeto"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/**
 * Dialog para criar inventory_item a partir de um project_template já existente.
 * Sem FK — cada confirmação cria um novo item. Imagem reutiliza o mesmo path.
 */
function AddProjectToStockDialog({
  template,
  onClose,
}: {
  template: ProjectTemplate;
  onClose: () => void;
}) {
  const createStock = useCreateInventoryItem();
  const [categoria, setCategoria] = useState<InventoryCategoria | "">(() =>
    sugerirCategoriaEstoque(template.categoria),
  );
  const [unidade, setUnidade] = useState<InventoryUnidade>("un");
  const [quantidade, setQuantidade] = useState("0");
  const [estoqueMinimo, setEstoqueMinimo] = useState("0");
  const [custo, setCusto] = useState("0");
  const [precoVenda, setPrecoVenda] = useState(() =>
    numeroParaTexto(Number(template.preco_m2) || 0),
  );

  const categorias = categoriasEstoqueParaAreaProjeto(template.area);
  const saving = createStock.isPending;

  const submit = () => {
    if (saving) return;
    if (!categoria) return toast.error("Escolha a categoria do item no estoque.");
    const nums = validaCamposNumericos([
      {
        chave: "quantidade",
        texto: quantidade,
        regra: { label: "a quantidade inicial", min: 0, obrigatorio: true },
      },
      {
        chave: "estoque_minimo",
        texto: estoqueMinimo,
        regra: { label: "o estoque mínimo", min: 0, obrigatorio: true },
      },
      {
        chave: "custo_unit",
        texto: custo,
        regra: { label: "o custo unitário", min: 0, obrigatorio: true, casas: 2 },
      },
      {
        chave: "preco_venda",
        texto: precoVenda,
        regra: { label: "o preço de venda", min: 0, obrigatorio: true, casas: 2 },
      },
    ]);
    if (!nums.ok) return toast.error(nums.erro);

    const descPartes = [
      template.descricao?.trim() || "",
      template.espessura?.trim() ? `Espessura: ${template.espessura.trim()}` : "",
    ].filter(Boolean);

    const input: InventoryItemInput = {
      nome: template.nome.trim(),
      categoria,
      unidade,
      descricao: optionalText(descPartes.join(" · "), 255),
      sku: null,
      ncm: null,
      quantidade: nums.valores.quantidade,
      estoque_minimo: nums.valores.estoque_minimo,
      custo_unit: nums.valores.custo_unit,
      preco_venda: nums.valores.preco_venda,
      fornecedor: null,
      supplier_id: null,
      localizacao: null,
      observacoes: optionalText(template.observacoes, 1000),
      imagem_url: optionalText(template.imagem_url, 500),
      ativo: true,
      originado_de_projeto: true,
    };

    createStock.mutate(input, {
      onSuccess: () => {
        toast.success("Projeto adicionado ao estoque.");
        onClose();
      },
      onError: (e) => toast.error(e instanceof Error ? e.message : inventoryErrorMessage(e)),
    });
  };

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open && !saving) onClose();
      }}
    >
      <DialogContent className="max-w-lg p-5 sm:p-6">
        <DialogHeader>
          <DialogTitle>Adicionar projeto ao estoque</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">
          Crie um item de estoque a partir de <strong>{template.nome}</strong>. Nome, descrição e
          imagem do projeto serão reutilizados.
        </p>

        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <label className="block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">
              Categoria no estoque
            </span>
            <select
              value={categoria}
              onChange={(e) => setCategoria((e.target.value || "") as InventoryCategoria | "")}
              disabled={saving}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            >
              <option value="">Selecione…</option>
              {categorias.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.label}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">Unidade</span>
            <select
              value={unidade}
              onChange={(e) => setUnidade(e.target.value as InventoryUnidade)}
              disabled={saving}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            >
              {INVENTORY_UNITS.map((u) => (
                <option key={u} value={u}>
                  {u === "m2" ? "m²" : u}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">
              Quantidade inicial
            </span>
            <input
              inputMode="decimal"
              value={quantidade}
              onChange={(e) => setQuantidade(e.target.value)}
              disabled={saving}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            />
          </label>
          <label className="block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">
              Estoque mínimo
            </span>
            <input
              inputMode="decimal"
              value={estoqueMinimo}
              onChange={(e) => setEstoqueMinimo(e.target.value)}
              disabled={saving}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            />
          </label>
          <label className="block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">
              Custo unitário (R$)
            </span>
            <input
              inputMode="decimal"
              value={custo}
              onChange={(e) => setCusto(e.target.value)}
              disabled={saving}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            />
          </label>
          <label className="block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">
              Preço de venda (R$)
            </span>
            <input
              inputMode="decimal"
              value={precoVenda}
              onChange={(e) => setPrecoVenda(e.target.value)}
              disabled={saving}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            />
          </label>
        </div>

        <div className="mt-5 flex flex-wrap justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            disabled={saving}
            className="rounded-lg border border-border px-4 py-2 text-sm hover:bg-accent disabled:opacity-50"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={submit}
            disabled={saving}
            className="rounded-lg bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground disabled:opacity-50"
          >
            {saving ? "Adicionando..." : "Adicionar ao estoque"}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="text-sm font-semibold">{value}</div>
    </div>
  );
}

// Os dois auxiliares locais que existiam aqui (`numeroParaCampo` /
// `campoParaNumero`) viraram `numeroParaTexto` / `textoParaNumero` em
// `src/lib/numero-campo.ts` na Revisão 32. O comportamento é o mesmo — texto
// no estado, conversão só no envio, NaN em vez de 0 silencioso — só que agora
// é UM padrão compartilhado por Estoque, Projetos e os demais formulários, em
// vez de uma boa solução isolada nesta tela.

/**
 * Modelo em branco para "Novo projeto".
 *
 * Com `area` + `subtipo` (catálogo hierárquico): pula os passos 1–2 do wizard.
 * Sem eles: abre o wizard completo (área → tipo → catálogo → formulário).
 */
function novoModelo(seed?: {
  area?: AreaProjeto;
  subtipo?: SubtipoProjeto;
}): Partial<ProjectTemplate> {
  const area = seed?.area;
  const subtipo =
    area && seed?.subtipo && ehSubtipoDaArea(area, seed.subtipo) ? seed.subtipo : undefined;
  return {
    categoria: area && area !== "vidracaria" ? "esquadria" : "temperado",
    nome: "",
    ativo: true,
    largura_padrao: 1,
    altura_padrao: 1,
    preco_m2: 0,
    ...(area ? { area } : {}),
    ...(subtipo ? { subtipo } : {}),
  };
}

function EditModal({
  value,
  canManage,
  podeAlterarArea,
  onClose,
}: {
  value: Partial<ProjectTemplate>;
  canManage: boolean;
  podeAlterarArea: boolean;
  onClose: () => void;
}) {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;
  const create = useCreateProjectTemplate();
  const update = useUpdateProjectTemplate();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const previousImage = value.imagem_url ?? null;

  const criando = !value.id;
  const areaOriginal = value.area ?? null;
  /** O modelo já tem geometria salva? Vem de `project_data->versao`. */
  const temDesenho = value.desenho_versao != null;

  const {
    data: areaVisibility,
    isLoading: areaVisibilityLoading,
    isError: areaVisibilityError,
    error: areaVisibilityErr,
  } = useProjectAreaVisibility();
  // Fallback seguro = DEFAULT (não libera todos os tipos em caso de falha).
  const areasCriacao = areasDisponiveisParaCriacao(
    areaVisibility ?? DEFAULT_PROJECT_AREA_VISIBILITY,
  );

  // PASSO 1 da criação. `null` significa "ainda não escolheu" e é o que mantém
  // o formulário comercial fechado — a área é obrigatória, então ela vem antes.
  const [area, setArea] = useState<AreaProjeto | null>(areaOriginal);

  /**
   * SUBTIPO — obrigatório (NOT NULL + CHECK no banco).
   *
   * Na EDIÇÃO parte do valor gravado, mas só se ele pertencer à área do modelo:
   * um par inconsistente não deveria existir (a constraint
   * `project_templates_area_subtipo` o impede), e se aparecer — base sem a
   * migration, resposta em cache antiga — o campo volta a exigir escolha em vez
   * de exibir uma opção de outro segmento como se estivesse certa.
   *
   * Áreas com um único subtipo válido ainda auto-selecionam e pulam o passo 2
   * (ver `escolherArea`). Esquadrias tem sete opções — o passo 2 é exibido.
   */
  const [subtipo, setSubtipo] = useState<SubtipoProjeto | null>(
    areaOriginal && ehSubtipoDaArea(areaOriginal, value.subtipo) ? value.subtipo : null,
  );

  /**
   * PASSO 3 (só criação) — catálogo global filtrado por área+subtipo.
   * `false` = ainda nesta etapa (ou carregando / auto-pulo). `true` = formulário.
   * Rev. 204.
   */
  const [passouCatalogo, setPassouCatalogo] = useState(false);
  /** Houve itens na etapa do catálogo? Controla o Voltar do formulário. */
  const [catalogoTeveItens, setCatalogoTeveItens] = useState(false);

  /**
   * TROCAR A ÁREA LIMPA O SUBTIPO. Sempre, e sem exceção.
   *
   * É o ponto inteiro de os subtipos serem por área: se a escolha anterior
   * sobrevivesse, um modelo passado de vidraçaria para marcenaria sairia daqui
   * como `box` em marcenaria — que o banco recusa, mas com um erro de
   * constraint no `save`, longe da causa. Zerar aqui transforma isso em "escolha
   * o tipo de projeto", no campo certo, antes de qualquer ida ao servidor.
   *
   * `project_data` NÃO é tocado: trocar a área de um modelo com desenho já é
   * bloqueado antes (ver `areaEditavel`), e trocar só o subtipo não mexe em
   * geometria nenhuma.
   */
  const escolherArea = (nova: AreaProjeto | null) => {
    setArea(nova);
    if (nova !== area) {
      // Área com um único subtipo válido: seleciona automaticamente e evita um
      // passo de wizard inútil. Com vários (ex.: Esquadrias), `subtipo` fica
      // null e o passo 2 de `CartoesSubtipo` aparece.
      const lista = nova ? subtiposDaArea(nova) : [];
      setSubtipo(lista.length === 1 ? lista[0]! : null);
      setPassouCatalogo(false);
      setCatalogoTeveItens(false);
    }
  };

  const voltarDoTipo = () => {
    setSubtipo(null);
    setPassouCatalogo(false);
    setCatalogoTeveItens(false);
  };

  const [form, setForm] = useState({
    categoria: (value.categoria ?? "temperado") as ProjectTemplateCategoria,
    // "" = não informado (NULL no banco). Só enviados quando a categoria
    // permite — ver `escolherCategoria` e `toInput`.
    acabamento: (value.acabamento ?? "") as ProjectTemplateAcabamento | "",
    cor: (value.cor ?? "") as ProjectTemplateCor | "",
    nome: value.nome ?? "",
    descricao: value.descricao ?? "",
    espessura: value.espessura ?? "",
    // `tipo` (TEXT livre) saiu da UI na Rev. 196 — redundante com `subtipo`.
    // DEFEITO CORRIGIDO — os três campos numéricos guardam TEXTO, não número.
    // Antes o estado era `Number(...)` alimentado por `parseFloat(e.target.value)
    // || 0`. Num `<input type="number">` o passo intermediário "1." não é um
    // número válido, então o navegador devolve `value === ""`, `parseFloat` dá
    // NaN e o `|| 0` zerava o campo NO MEIO da digitação: quem tentasse escrever
    // "1.20" terminava com "020". Na prática era impossível cadastrar qualquer
    // medida ou preço decimal. Guardando texto, o valor só vira número na
    // validação e no envio.
    largura_padrao: numeroParaTexto(value.largura_padrao ?? 1),
    altura_padrao: numeroParaTexto(value.altura_padrao ?? 1),
    preco_m2: numeroParaTexto(value.preco_m2 ?? 0),
    observacoes: value.observacoes ?? "",
    ativo: value.ativo !== false,
    imagem_url: value.imagem_url ?? "",
  });
  // Imagem enviada nesta sessão e ainda não persistida (para limpar no cancelar).
  const pendingUpload = useRef<string | null>(null);
  const saving = create.isPending || update.isPending;

  /** Formulário em branco (após "Criar do zero" ou tipo sem catálogo). */
  const formEmBranco = (): typeof form => ({
    categoria: area && area !== "vidracaria" ? "esquadria" : "temperado",
    acabamento: "",
    cor: "",
    nome: "",
    descricao: "",
    espessura: "",
    largura_padrao: numeroParaTexto(1),
    altura_padrao: numeroParaTexto(1),
    preco_m2: numeroParaTexto(0),
    observacoes: "",
    ativo: true,
    imagem_url: "",
  });

  const catalogQueryEnabled = criando && !!area && !!subtipo && !passouCatalogo;
  const {
    data: catalogWizardItems = [],
    isLoading: catalogWizardLoading,
    isFetched: catalogWizardFetched,
    isError: catalogWizardError,
  } = usePlatformProjectCatalog({
    area: area ?? "todos",
    subtipo: subtipo ?? "todos",
    enabled: catalogQueryEnabled,
  });

  // Sem itens (ou erro de leitura): pula direto ao formulário em branco.
  useEffect(() => {
    if (!catalogQueryEnabled) return;
    if (!catalogWizardFetched || catalogWizardLoading) return;
    if (catalogWizardError || catalogWizardItems.length === 0) {
      setCatalogoTeveItens(false);
      setPassouCatalogo(true);
      return;
    }
    setCatalogoTeveItens(true);
  }, [
    catalogQueryEnabled,
    catalogWizardFetched,
    catalogWizardLoading,
    catalogWizardError,
    catalogWizardItems.length,
  ]);

  /**
   * Quando o campo de área aceita alteração.
   *
   * Na CRIAÇÃO sempre — não há desenho para ficar incompatível e a escolha do
   * passo 1 ainda pode ser corrigida sem sair da tela. Na EDIÇÃO exige papel
   * empresarial (owner/admin/manager) E ausência de desenho.
   */
  const areaEditavel = canManage && (criando || (podeAlterarArea && !temDesenho));

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  /**
   * TROCAR A CATEGORIA LIMPA ACABAMENTO/COR quando deixam de fazer sentido.
   *
   * Espelha a regra do subtipo ao mudar área: se a escolha anterior
   * sobrevivesse, o formulário enviaria `cor=prata` com `categoria=temperado`
   * e o CHECK `project_templates_cor_refletivo` recusaria longe da causa.
   * Mesma lógica para acabamento fora de vidro_comum/espelho/organico/canelado.
   */
  const escolherCategoria = (nova: ProjectTemplateCategoria) => {
    setForm((f) => ({
      ...f,
      categoria: nova,
      acabamento: categoriaAceitaAcabamento(nova) ? f.acabamento : "",
      cor: nova === "refletivo" ? f.cor : "",
    }));
  };

  const handleUpload = async (file: File) => {
    if (!companyId) return toast.error("Selecione uma empresa ativa.");
    setUploading(true);
    try {
      const path = await uploadTemplateImage(companyId, file);
      // Se havia uma imagem recém-enviada não salva, remove antes de trocar.
      if (pendingUpload.current)
        await deleteTemplateImageIfOwnedByCompany(companyId, pendingUpload.current).catch(() => {});
      pendingUpload.current = path;
      set("imagem_url", path);
      toast.success("Imagem enviada");
    } catch (e: unknown) {
      toast.error(mensagemDoErro(e) ?? "Falha ao enviar imagem");
    } finally {
      setUploading(false);
    }
  };

  const cleanupPending = async () => {
    if (pendingUpload.current && companyId)
      await deleteTemplateImageIfOwnedByCompany(companyId, pendingUpload.current).catch(() => {});
    pendingUpload.current = null;
  };

  const pularCatalogo = () => {
    void cleanupPending();
    setForm(formEmBranco());
    setPassouCatalogo(true);
  };

  const aplicarItemCatalogo = async (item: PlatformCatalogItem) => {
    if (!companyId) {
      toast.error("Selecione uma empresa ativa.");
      return;
    }
    setUploading(true);
    try {
      if (pendingUpload.current) {
        await deleteTemplateImageIfOwnedByCompany(companyId, pendingUpload.current).catch(() => {});
        pendingUpload.current = null;
      }
      const imagemLocal = await duplicateCatalogImageToCompany(companyId, item.imagem_url);
      if (imagemLocal) pendingUpload.current = imagemLocal;
      const acabamento =
        item.acabamento && categoriaAceitaAcabamento(item.categoria) ? item.acabamento : "";
      const cor = item.categoria === "refletivo" && item.cor ? item.cor : "";
      setForm({
        categoria: item.categoria,
        acabamento,
        cor,
        nome: item.nome,
        descricao: item.descricao ?? "",
        espessura: item.espessura ?? "",
        largura_padrao: numeroParaTexto(Number(item.largura_padrao) || 1),
        altura_padrao: numeroParaTexto(Number(item.altura_padrao) || 1),
        preco_m2: numeroParaTexto(Number(item.preco_referencia_m2) || 0),
        observacoes: item.observacoes ?? "",
        ativo: true,
        imagem_url: imagemLocal ?? "",
      });
      setPassouCatalogo(true);
      toast.success(`“${item.nome}” aplicado no formulário`);
    } catch (e) {
      toast.error(platformCatalogErrorMessage(e));
    } finally {
      setUploading(false);
    }
  };

  const voltarDoFormulario = () => {
    if (catalogoTeveItens) {
      void cleanupPending();
      setForm(formEmBranco());
      setPassouCatalogo(false);
      return;
    }
    voltarDoTipo();
  };

  const close = () => {
    void cleanupPending();
    onClose();
  };

  const toInput = (
    area: AreaProjeto,
    subtipo: SubtipoProjeto,
    numeros: { largura_padrao: number; altura_padrao: number; preco_m2: number },
  ): ProjectTemplateInput => ({
    area,
    subtipo,
    categoria: form.categoria,
    // Rede de segurança: mesmo se o campo ficou oculto com valor residual,
    // só envia o que o CHECK do banco aceita.
    acabamento:
      categoriaAceitaAcabamento(form.categoria) && form.acabamento ? form.acabamento : null,
    cor: form.categoria === "refletivo" && form.cor ? form.cor : null,
    nome: form.nome.trim(),
    descricao: form.descricao.trim() || null,
    espessura: form.espessura.trim() || null,
    // Coluna legada: sem campo na UI. Espelha o rótulo do `subtipo` (igual
    // "Salvar como modelo" em Orçamentos) para não deixar NULL ao criar/editar.
    tipo: ROTULO_SUBTIPO[subtipo],
    ...numeros,
    observacoes: form.observacoes.trim() || null,
    ativo: form.ativo,
    imagem_url: form.imagem_url.trim() || null,
  });

  const save = () => {
    if (saving) return; // anti-duplo-clique
    // Validação de entrada. Antes só o nome era exigido: um modelo podia ser
    // salvo com largura ou altura ZERO e, ao ser levado para o orçamento,
    // virava um item SEM dimensões — que o formulário precifica por unidade em
    // vez de por m². O erro só aparecia no total do orçamento, longe da causa.
    // `categoria` não precisa de checagem: é um <select> cujas opções são
    // exatamente os valores do enum `project_category` (7 após Rev. 182).
    //
    // `acabamento` / `cor` também não: só renderizam quando a categoria
    // permite, e `toInput` zera o que não cabe. Cor NÃO é obrigatória em
    // refletivo — o CHECK é `cor IS NULL OR categoria = refletivo`.
    //
    // `area` PRECISA: ela é obrigatória, é `null` até alguém escolher e o banco
    // recusaria a linha — melhor dizer o que falta aqui do que devolver um erro
    // de constraint. O valor vem sempre de um dos quatro botões/opções, nunca
    // de texto digitado.
    if (!area) return toast.error("Escolha a área do projeto.");
    // `subtipo` é obrigatório pela MESMA razão que `area`: a coluna é NOT NULL e
    // o par é validado por constraint. A checagem repete `ehSubtipoDaArea` (e
    // não só `!== null`) porque é ela que garante que o valor no estado ainda
    // pertence à área atual — a rede de segurança para qualquer caminho que
    // altere a área sem passar por `escolherArea`.
    if (!subtipo || !ehSubtipoDaArea(area, subtipo))
      return toast.error("Escolha o tipo de projeto.");
    if (!form.nome.trim()) return toast.error("Informe o nome");
    // Revisão 32 — antes, "abc" na largura caía no `!(NaN > 0)` e o usuário
    // lia "deve ser maior que zero", que não descreve o problema. Agora
    // `validaCamposNumericos` separa os dois casos: NÃO É NÚMERO e FORA DA
    // FAIXA têm mensagens diferentes, e as três medidas são obrigatórias
    // (largura/altura por causa do cálculo por m², preço por ser dinheiro).
    const numeros = validaCamposNumericos([
      {
        chave: "largura_padrao",
        texto: form.largura_padrao,
        regra: { label: "a largura padrão (em metros)", min: 0.001, obrigatorio: true },
      },
      {
        chave: "altura_padrao",
        texto: form.altura_padrao,
        regra: { label: "a altura padrão (em metros)", min: 0.001, obrigatorio: true },
      },
      {
        chave: "preco_m2",
        texto: form.preco_m2,
        regra: { label: "o preço por m²", min: 0, obrigatorio: true, casas: 2 },
      },
    ]);
    if (!numeros.ok) return toast.error(numeros.erro);
    const input = toInput(area, subtipo, numeros.valores);

    if (value.id) {
      update.mutate(
        { id: value.id, input, previousImage, areaAnterior: areaOriginal, temDesenho },
        {
          onSuccess: () => {
            pendingUpload.current = null;
            toast.success("Projeto salvo");
            onClose();
          },
          onError: (e) =>
            toast.error(e instanceof Error ? e.message : projectTemplateErrorMessage(e)),
        },
      );
    } else {
      create.mutate(input, {
        onSuccess: () => {
          pendingUpload.current = null;
          toast.success("Projeto criado com sucesso.");
          onClose();
        },
        onError: (e) =>
          toast.error(e instanceof Error ? e.message : projectTemplateErrorMessage(e)),
      });
    }
  };

  // PASSO 1 — ÁREA ANTES DO TIPO E DO FORMULÁRIO.
  if (criando && !area) {
    return (
      <div
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
        onClick={close}
      >
        <div
          className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-border bg-card p-6 shadow-elegant"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="mb-1 flex items-center justify-between">
            <h2 className="font-display text-xl font-bold">Novo projeto</h2>
            <button onClick={close} className="rounded-md p-1.5 hover:bg-accent">
              <X className="h-4 w-4" />
            </button>
          </div>
          <p className="mb-5 text-sm text-muted-foreground">Qual é a área deste modelo técnico?</p>
          {areaVisibilityLoading ? (
            <p className="py-8 text-center text-sm text-muted-foreground">Carregando tipos…</p>
          ) : (
            <>
              {areaVisibilityError ? (
                <p className="mb-4 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                  Não foi possível carregar a configuração de tipos
                  {areaVisibilityErr instanceof Error ? `: ${areaVisibilityErr.message}` : "."}{" "}
                  Exibindo a lista padrão (Vidraçaria e Esquadrias).
                </p>
              ) : null}
              <CartoesArea areas={areasCriacao} onEscolher={escolherArea} />
            </>
          )}
          <div className="mt-5 flex justify-end">
            <button
              onClick={close}
              className="rounded-lg border border-border px-4 py-2 text-sm hover:bg-accent"
            >
              Cancelar
            </button>
          </div>
        </div>
      </div>
    );
  }

  // PASSO 2 — os 7 tipos da área, antes do cadastro comercial.
  if (criando && area && !subtipo) {
    return (
      <div
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
        onClick={close}
      >
        <div
          className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-border bg-card p-6 shadow-elegant"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="mb-1 flex items-center justify-between">
            <h2 className="font-display text-xl font-bold">Novo projeto</h2>
            <button onClick={close} className="rounded-md p-1.5 hover:bg-accent">
              <X className="h-4 w-4" />
            </button>
          </div>
          <p className="mb-5 text-sm text-muted-foreground">
            Tipo de projeto · {ROTULO_AREA[area]}
          </p>
          <CartoesSubtipo area={area} onEscolher={setSubtipo} />
          <div className="mt-5 flex justify-between">
            <button
              type="button"
              onClick={() => escolherArea(null)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border px-4 py-2 text-sm hover:bg-accent"
            >
              <ArrowLeft className="h-4 w-4" /> Voltar
            </button>
            <button
              onClick={close}
              className="rounded-lg border border-border px-4 py-2 text-sm hover:bg-accent"
            >
              Cancelar
            </button>
          </div>
        </div>
      </div>
    );
  }

  // PASSO 3 — catálogo global (área+subtipo). Vazio → auto-pula (useEffect).
  if (criando && area && subtipo && !passouCatalogo) {
    return (
      <div
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
        onClick={close}
      >
        <div
          className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-border bg-card p-6 shadow-elegant"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="mb-1 flex items-center justify-between">
            <h2 className="font-display text-xl font-bold">Novo projeto</h2>
            <button onClick={close} className="rounded-md p-1.5 hover:bg-accent">
              <X className="h-4 w-4" />
            </button>
          </div>
          <p className="mb-5 text-sm text-muted-foreground">
            Catálogo · {ROTULO_AREA[area]} · {ROTULO_SUBTIPO[subtipo]}
          </p>

          {catalogWizardLoading || !catalogWizardFetched || catalogWizardItems.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">Carregando catálogo…</p>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {catalogWizardItems.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  disabled={uploading}
                  onClick={() => void aplicarItemCatalogo(item)}
                  className="overflow-hidden rounded-xl border border-border bg-background text-left transition hover:border-gold/50 hover:bg-gold/10 disabled:opacity-50"
                >
                  <div className="aspect-[4/3] bg-muted/40">
                    {item.imagem_url ? (
                      <StorageImage
                        bucket="platform-catalog"
                        src={item.imagem_url}
                        alt={item.nome}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                        <ImageIcon className="h-8 w-8 opacity-40" />
                      </div>
                    )}
                  </div>
                  <div className="p-3">
                    <div className="font-display text-base font-semibold leading-tight">
                      {item.nome}
                    </div>
                    {item.descricao && (
                      <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                        {item.descricao}
                      </p>
                    )}
                  </div>
                </button>
              ))}
            </div>
          )}

          {catalogWizardFetched && catalogWizardItems.length > 0 && (
            <div className="mt-5 flex flex-wrap items-center justify-between gap-2">
              <button
                type="button"
                onClick={voltarDoTipo}
                className="inline-flex items-center gap-1.5 rounded-lg border border-border px-4 py-2 text-sm hover:bg-accent"
              >
                <ArrowLeft className="h-4 w-4" /> Voltar
              </button>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={pularCatalogo}
                  disabled={uploading}
                  className="rounded-lg border border-gold/40 bg-gold/10 px-4 py-2 text-sm font-semibold text-gold hover:bg-gold/20 disabled:opacity-50"
                >
                  Criar do zero
                </button>
                <button
                  type="button"
                  onClick={close}
                  className="rounded-lg border border-border px-4 py-2 text-sm hover:bg-accent"
                >
                  Cancelar
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
      onClick={close}
    >
      {/* DEFEITO CORRIGIDO: o cartão não tinha limite de altura nem rolagem. Numa
          janela mais baixa (notebook comum) o formulário ultrapassava a tela e
          "Ativo" e "Salvar projeto" ficavam FORA de alcance — a página de fundo
          é que rolava, não o modal, então não havia como concluir o cadastro. */}
      <div
        className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-border bg-card p-6 shadow-elegant"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-xl font-bold">
            {value.id ? "Editar projeto" : "Novo projeto"}
          </h2>
          <button onClick={close} className="rounded-md p-1.5 hover:bg-accent">
            <X className="h-4 w-4" />
          </button>
        </div>

        {!canManage && (
          <div className="mb-4 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-sm text-amber-700 dark:text-amber-300">
            Você pode visualizar, mas não tem permissão para salvar alterações neste modelo.
          </div>
        )}

        <div className="mb-4">
          <div className="relative aspect-[4/3] w-full overflow-hidden rounded-lg border border-border bg-muted">
            {form.imagem_url ? (
              <StorageImage src={form.imagem_url} alt="" className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                <ImageIcon className="h-12 w-12 opacity-40" />
              </div>
            )}
            {form.imagem_url && canManage && (
              <button
                onClick={() => set("imagem_url", "")}
                className="absolute right-2 top-2 rounded-md bg-black/60 p-1.5 text-white hover:bg-black/80"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif,image/avif"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleUpload(f);
              e.currentTarget.value = "";
            }}
          />
          {canManage && (
            <button
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
              className="mt-2 inline-flex items-center gap-1.5 rounded-md border border-input px-3 py-1.5 text-xs hover:bg-accent disabled:opacity-50"
            >
              <Upload className="h-3.5 w-3.5" />{" "}
              {uploading ? "Enviando..." : form.imagem_url ? "Trocar imagem" : "Enviar imagem"}
            </button>
          )}
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          {/* ÁREA — obrigatória e vinda do enum, nunca digitada. Fica em cima e
              sozinha na linha porque é a classificação principal; "Categoria"
              vem logo abaixo e é outra coisa (o material do produto). */}
          <Field label="Área do projeto *" full>
            <select
              value={area ?? ""}
              onChange={(e) => escolherArea(ehAreaProjeto(e.target.value) ? e.target.value : null)}
              disabled={!areaEditavel}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring disabled:cursor-not-allowed disabled:opacity-70"
            >
              {/* Modelo LEGADO sem área: opção vazia explícita. Sem ela o
                  navegador mostraria a primeira da lista como se estivesse
                  escolhida, e o formulário exibiria "Vidraçaria" para um
                  registro que não tem área nenhuma. */}
              {area === null && <option value="">Selecione a área</option>}
              {AREAS_PROJETO.map((a) => (
                <option key={a} value={a}>
                  {ROTULO_AREA[a]}
                </option>
              ))}
            </select>
            {/* Bloqueio EXPLICADO, em vez de campo cinza sem motivo. Trocar a
                área de um modelo que já tem desenho tornaria a geometria
                incompatível com a nova paleta; as saídas automáticas seriam
                apagar o trabalho ou deixar card e editor discordando, e
                nenhuma das duas é do sistema para decidir. */}
            {!criando && temDesenho && podeAlterarArea && (
              <span className="mt-1 block text-xs text-amber-600 dark:text-amber-400">
                Remova ou recrie o desenho antes de alterar a área.
              </span>
            )}
            {!criando && !podeAlterarArea && canManage && (
              <span className="mt-1 block text-xs text-muted-foreground">
                Alterar a área é permitido a owner, admin e manager da empresa.
              </span>
            )}
          </Field>
          {/* TIPO DE PROJETO — o subtipo. Obrigatório, e as opções são
              EXATAMENTE as da área escolhida (`subtiposDaArea`): nenhuma opção
              de outro segmento chega a ser renderizada. O banco recusa o par
              inválido (`project_templates_area_subtipo`), mas o formulário não
              deve oferecer o que vai ser recusado.

              Continua editável quando a ÁREA está travada por causa do desenho:
              trocar só o subtipo não muda a paleta nem a geometria —
              `project_data` não é tocado. */}
          <Field label="Tipo de projeto *" full>
            <select
              value={subtipo ?? ""}
              onChange={(e) =>
                setSubtipo(area && ehSubtipoDaArea(area, e.target.value) ? e.target.value : null)
              }
              disabled={!canManage || !area}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring disabled:cursor-not-allowed disabled:opacity-70"
            >
              {/* Opção vazia EXPLÍCITA enquanto não há escolha — sem ela o
                  navegador mostraria a primeira da lista como se estivesse
                  selecionada, e o campo obrigatório pareceria já respondido. */}
              {subtipo === null && <option value="">Selecione o tipo de projeto</option>}
              {area &&
                subtiposDaArea(area).map((s) => (
                  <option key={s} value={s}>
                    {ROTULO_SUBTIPO[s]}
                  </option>
                ))}
            </select>
            {!criando && areaOriginal && area !== areaOriginal && (
              <span className="mt-1 block text-xs text-amber-600 dark:text-amber-400">
                A área mudou — escolha novamente o tipo de projeto.
              </span>
            )}
            {!criando &&
              value.subtipo &&
              area &&
              (area === "vidracaria" || area === "esquadrias") &&
              !ehSubtipoDaArea(area, value.subtipo) &&
              subtipo === null && (
                <span className="mt-1 block text-xs text-amber-600 dark:text-amber-400">
                  Tipo antigo ({rotuloSubtipo(value.subtipo) ?? value.subtipo}). Escolha um tipo da
                  nova lista para salvar.
                </span>
              )}
          </Field>
          <Field label="Categoria *">
            <select
              value={form.categoria}
              onChange={(e) => escolherCategoria(e.target.value as ProjectTemplateCategoria)}
              disabled={!canManage}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            >
              {CATEGORIAS.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
          </Field>
          {/* ACABAMENTO — só nas categorias do CHECK
              `project_templates_acabamento_categoria`. Temperado / refletivo /
              esquadria ocultam o campo (e `escolherCategoria` zera o valor).
              Opcional: NULL = não informado. */}
          {categoriaAceitaAcabamento(form.categoria) && (
            <Field label="Acabamento">
              <select
                value={form.acabamento}
                onChange={(e) =>
                  set("acabamento", e.target.value as ProjectTemplateAcabamento | "")
                }
                disabled={!canManage}
                className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
              >
                <option value="">Não informado</option>
                {ACABAMENTOS.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.label}
                  </option>
                ))}
              </select>
            </Field>
          )}
          {/* COR — só refletivo. Opcional: o CHECK do banco ACEITA
              `categoria=refletivo` com `cor IS NULL` (`cor IS NULL OR
              categoria = refletivo`). Não forçamos obrigatoriedade aqui. */}
          {form.categoria === "refletivo" && (
            <Field label="Cor">
              <select
                value={form.cor}
                onChange={(e) => set("cor", e.target.value as ProjectTemplateCor | "")}
                disabled={!canManage}
                className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
              >
                <option value="">Não informado</option>
                {CORES_REFLETIVO.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            </Field>
          )}
          <Field label="Nome *">
            <input
              value={form.nome}
              onChange={(e) => set("nome", e.target.value)}
              disabled={!canManage}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            />
          </Field>
          <Field label="Descrição" full>
            <input
              value={form.descricao}
              onChange={(e) => set("descricao", e.target.value)}
              disabled={!canManage}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            />
          </Field>
          {/* Vidraçaria: chips 4–12mm, o mesmo grupo visual de Orçamentos
              (lá o JSX é inline — não extraímos componente para não tocar
              nessa rota). Grava TEXT `"8mm"` etc., igual à coluna atual.
              As outras áreas seguem texto livre (MDF, granito, …). */}
          <Field label="Espessura (mm)">
            {area === "vidracaria" ? (
              <div className="flex flex-wrap gap-2">
                {ESPESSURAS_VIDRO.map((mm) => {
                  const ativo = form.espessura === mm;
                  return (
                    <button
                      key={mm}
                      type="button"
                      disabled={!canManage}
                      onClick={() => set("espessura", ativo ? "" : mm)}
                      className={`inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs transition disabled:cursor-not-allowed disabled:opacity-50 ${
                        ativo
                          ? "border-primary bg-primary text-primary-foreground shadow-sm"
                          : "border-input bg-background hover:border-primary/40 hover:bg-accent"
                      }`}
                    >
                      {ativo && <Check className="h-3 w-3" />}
                      {mm}
                    </button>
                  );
                })}
              </div>
            ) : (
              <input
                value={form.espessura}
                onChange={(e) => set("espessura", e.target.value)}
                placeholder="ex: 8, 8mm, MDF 15mm, granito 20mm"
                disabled={!canManage}
                className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
              />
            )}
          </Field>
          {/* `inputMode="decimal"` mantém o teclado numérico no celular sem o
              `type="number"`, cujo valor intermediário inválido zerava o campo. */}
          <Field label="Preço por m² (R$)">
            <input
              inputMode="decimal"
              placeholder="450,00"
              value={form.preco_m2}
              onChange={(e) => set("preco_m2", e.target.value)}
              disabled={!canManage}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            />
          </Field>
          <Field label="Largura padrão (m)">
            <input
              inputMode="decimal"
              placeholder="1,20"
              value={form.largura_padrao}
              onChange={(e) => set("largura_padrao", e.target.value)}
              disabled={!canManage}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            />
          </Field>
          <Field label="Altura padrão (m)">
            <input
              inputMode="decimal"
              placeholder="1,90"
              value={form.altura_padrao}
              onChange={(e) => set("altura_padrao", e.target.value)}
              disabled={!canManage}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            />
          </Field>
          <Field label="Observações" full>
            <textarea
              value={form.observacoes}
              onChange={(e) => set("observacoes", e.target.value)}
              rows={3}
              disabled={!canManage}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            />
          </Field>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.ativo}
              onChange={(e) => set("ativo", e.target.checked)}
              disabled={!canManage}
            />{" "}
            Ativo
          </label>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          {criando && (
            <button
              type="button"
              onClick={voltarDoFormulario}
              className="mr-auto inline-flex items-center gap-1.5 rounded-lg border border-border px-4 py-2 text-sm hover:bg-accent"
            >
              <ArrowLeft className="h-4 w-4" /> Voltar
            </button>
          )}
          <button
            onClick={close}
            className="rounded-lg border border-border px-4 py-2 text-sm hover:bg-accent"
          >
            Cancelar
          </button>
          {canManage && (
            <button
              onClick={save}
              disabled={saving}
              className="rounded-lg bg-gradient-gold px-5 py-2 text-sm font-semibold text-gold-foreground disabled:opacity-50"
            >
              {saving ? "Salvando..." : "Salvar projeto"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  children,
  full,
}: {
  label: string;
  children: React.ReactNode;
  full?: boolean;
}) {
  return (
    <label className={`block ${full ? "md:col-span-2" : ""}`}>
      <span className="mb-1 block text-xs font-medium text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}
