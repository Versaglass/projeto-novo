import { createFileRoute } from "@tanstack/react-router";
import { Bot, MessageCircle, Sparkles } from "lucide-react";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";

/** ROTA OCULTA (Revisão 227) — Chat IA. Código preservado; acesso bloqueado. */
export const Route = createFileRoute("/_authenticated/app/assistente")({
  beforeLoad: hiddenRouteBeforeLoad,
  component: AssistentePage,
});
function AssistentePage() {
  const qs = [
    "Quanto custa esse projeto?",
    "Qual vidro usar?",
    "Qual espessura indicada?",
    "Qual fornecedor tem melhor preço?",
    "Gerar anúncio para este orçamento",
  ];
  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-3xl font-bold">Assistente IA</h1>
        <p className="text-muted-foreground">
          Ajuda rápida para orçamento, projeto, fornecedor, materiais, anúncio e atendimento ao
          cliente.
        </p>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        {qs.map((q) => (
          <button key={q} className="rounded-2xl border bg-card p-4 text-left hover:border-gold/50">
            <Sparkles className="mb-2 h-5 w-5 text-gold" />
            <b>{q}</b>
          </button>
        ))}
      </div>
      <div className="rounded-2xl border bg-card p-5">
        <div className="flex items-center gap-2">
          <Bot className="h-5 w-5 text-gold" />
          <b>Chat interno</b>
        </div>
        <div className="mt-4 rounded-xl bg-muted p-4 text-sm text-muted-foreground">
          Digite dúvidas sobre medidas, ferragens, material, estoque, financeiro ou produção.
        </div>
        <div className="mt-3 flex gap-2">
          <input
            className="flex-1 rounded-xl border bg-background px-3 py-2"
            placeholder="Pergunte algo..."
          />
          <button className="rounded-xl bg-gold px-4 font-semibold text-gold-foreground">
            <MessageCircle className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
