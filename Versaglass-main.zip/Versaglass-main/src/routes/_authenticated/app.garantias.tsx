import { createFileRoute } from "@tanstack/react-router";
import {
  EnterpriseCrudPage,
  type CrudItem,
  type FieldConfig,
} from "@/components/EnterpriseCrudPage";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";

/** ROTA OCULTA (Revisão 227) — Garantias. Código preservado; acesso bloqueado. */
export const Route = createFileRoute("/_authenticated/app/garantias")({
  beforeLoad: hiddenRouteBeforeLoad,
  component: GarantiasPage,
});
const fields: FieldConfig[] = [
  { key: "cliente", label: "Cliente" },
  { key: "os", label: "OS" },
  { key: "produto", label: "Produto/Serviço" },
  { key: "instalacao", label: "Data instalação" },
  { key: "validade", label: "Validade garantia" },
  {
    key: "status",
    label: "Status",
    type: "select",
    options: ["Ativa", "Vencendo", "Vencida", "Acionada", "Resolvida"],
  },
  { key: "termo_pdf", label: "Termo/PDF" },
  { key: "observacoes", label: "Observações", type: "textarea" },
];
const data: CrudItem[] = [
  {
    id: "gar1",
    cliente: "Cliente exemplo",
    os: "OS-001",
    produto: "Box de vidro",
    instalacao: "2026-07-01",
    validade: "2027-07-01",
    status: "Ativa",
  },
];
function GarantiasPage() {
  return (
    <EnterpriseCrudPage
      title="Garantias"
      badge="Pós-venda"
      subtitle="Controle garantias por instalação com alertas, termo assinado e histórico de atendimento."
      storageKey="vmm_garantias"
      initialData={data}
      fields={fields}
      highlight={["cliente", "os", "produto", "validade", "status"]}
    />
  );
}
