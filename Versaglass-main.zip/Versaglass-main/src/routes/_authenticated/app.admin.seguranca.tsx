import { createFileRoute } from "@tanstack/react-router";
import { AlertTriangle, KeyRound, Lock, Shield, ShieldCheck } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { requireAdmin } from "@/lib/admin-guard";

export const Route = createFileRoute("/_authenticated/app/admin/seguranca")({
  beforeLoad: requireAdmin,
  component: SegurancaPage,
});

const checks = [
  {
    title: "Headers de segurança",
    status: "Ativo",
    desc: "CSP, X-Frame-Options, Referrer-Policy e proteção contra MIME sniffing adicionados no servidor.",
  },
  {
    title: "Rate limit",
    status: "Ativo",
    desc: "Bloqueio automático por IP para excesso de requisições.",
  },
  {
    title: "Permissões administrativas",
    status: "Reforçado",
    desc: "Ações críticas devem passar por papéis e auditoria.",
  },
  {
    title: "Variáveis de ambiente",
    status: "Seguro",
    desc: ".env removido e .env.example mantido para documentação.",
  },
];

function SegurancaPage() {
  const { isAdmin } = useAuth();
  if (!isAdmin) return null;
  return (
    <div className="space-y-6">
      <div>
        <Badge className="mb-3 gap-1">
          <Shield className="h-3.5 w-3.5" />
          Enterprise
        </Badge>
        <h1 className="font-display text-3xl font-bold">Segurança administrativa</h1>
        <p className="text-sm text-muted-foreground">
          Central para revisar proteção, sessão, risco e ações críticas.
        </p>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {checks.map((c) => (
          <Card key={c.title}>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">{c.title}</CardTitle>
              <Badge variant="secondary">{c.status}</Badge>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{c.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <KeyRound className="h-5 w-5" />
            Ações críticas recomendadas
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-3">
          <Action
            icon={Lock}
            title="Confirmar senha"
            text="Antes de excluir, alterar permissões ou chaves."
          />
          <Action
            icon={ShieldCheck}
            title="2FA"
            text="Ativar autenticação em duas etapas para administradores."
          />
          <Action
            icon={AlertTriangle}
            title="Bloqueio automático"
            text="Bloquear usuário por tentativas suspeitas."
          />
        </CardContent>
      </Card>
      <Button>Salvar política de segurança</Button>
    </div>
  );
}
function Action({ icon: Icon, title, text }: any) {
  return (
    <div className="rounded-xl border p-4">
      <Icon className="mb-3 h-5 w-5 text-gold" />
      <div className="font-semibold">{title}</div>
      <p className="mt-1 text-sm text-muted-foreground">{text}</p>
    </div>
  );
}
