import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { numeroParaTexto, textoParaNumero } from "@/lib/numero-campo";
import {
  Scissors,
  Plus,
  Trash2,
  Layers,
  Ruler,
  Download,
  Settings2,
  Package,
  ListChecks,
  Play,
  BarChart3,
  FileText,
  Copy,
} from "lucide-react";
import { toast } from "sonner";
import {
  CUT_PLAN_COLORS,
  packBars,
  packSheets,
  type BarPiece,
  type PackedBar,
  type PackedSheet,
  type SheetPiece,
} from "@/lib/cut-plan-packing";
import { generateCutPlanPdf } from "@/lib/cut-plan-pdf";

export const Route = createFileRoute("/_authenticated/app/plano-corte")({
  component: PlanoCortePage,
});

type Mode = "chaparia" | "barras";
type Tab = "projeto" | "chapas" | "pecas" | "config" | "resultado";

type Stock = { id: string; w: number; h: number; label: string; material: string };
type StockBar = { id: string; len: number; label: string };

function uid() {
  return Math.random().toString(36).slice(2, 9);
}

function PlanoCortePage() {
  const [mode, setMode] = useState<Mode>("chaparia");
  const [tab, setTab] = useState<Tab>("projeto");
  const [projectName, setProjectName] = useState("Orçamento sem nome");
  const [client, setClient] = useState("");
  const [notes, setNotes] = useState("");

  // shared config
  const [kerf, setKerf] = useState(3);
  const [allowRotate, setAllowRotate] = useState(true);
  const [considerGrain, setConsiderGrain] = useState(false);

  // chaparia
  const [stocks, setStocks] = useState<Stock[]>([
    {
      id: uid(),
      label: "Chapa padrão",
      w: 2200,
      h: 1600,
      material: "Vidro Temperado 8mm",
    },
  ]);
  const [pieces, setPieces] = useState<SheetPiece[]>([
    {
      id: uid(),
      label: "Box frontal",
      w: 1400,
      h: 1900,
      qty: 1,
      rotate: true,
      material: "Vidro Temperado 8mm",
    },
    {
      id: uid(),
      label: "Janela",
      w: 1200,
      h: 600,
      qty: 2,
      rotate: true,
      material: "Vidro Temperado 8mm",
    },
    {
      id: uid(),
      label: "Prateleira",
      w: 800,
      h: 300,
      qty: 4,
      rotate: true,
      material: "Vidro Temperado 8mm",
    },
  ]);

  // barras
  const [stockBars, setStockBars] = useState<StockBar[]>([
    { id: uid(), label: "Barra padrão", len: 6000 },
  ]);
  const [cuts, setCuts] = useState<BarPiece[]>([
    { id: uid(), label: "Verga", len: 1200, qty: 4 },
    { id: uid(), label: "Travessa", len: 980, qty: 6 },
    { id: uid(), label: "Montante", len: 2100, qty: 3 },
  ]);

  const stock = stocks[0];
  const sheetResult = useMemo(
    () =>
      packSheets({
        sheetW: stock?.w ?? 2200,
        sheetH: stock?.h ?? 1600,
        kerf,
        allowRotate,
        considerGrain,
        pieces,
      }),
    [stock?.w, stock?.h, kerf, allowRotate, considerGrain, pieces],
  );
  const barLen = stockBars[0]?.len ?? 6000;
  const barResult = useMemo(() => packBars({ barLen, kerf, cuts }), [barLen, kerf, cuts]);

  return (
    <div>
      {/* Header */}
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold flex items-center gap-2">
            <Scissors className="h-7 w-7 text-gold" /> Plano de corte
          </h1>
          <p className="text-sm text-muted-foreground">
            Otimizador de chapas e barras — calcula o melhor encaixe para reduzir desperdício.
          </p>
        </div>
        <div className="inline-flex rounded-xl border border-border bg-card p-1">
          <ModeBtn active={mode === "chaparia"} onClick={() => setMode("chaparia")}>
            <Layers className="h-4 w-4" /> Chaparia (2D)
          </ModeBtn>
          <ModeBtn active={mode === "barras"} onClick={() => setMode("barras")}>
            <Ruler className="h-4 w-4" /> Barras (1D)
          </ModeBtn>
        </div>
      </div>

      {/* Toolbar */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-border bg-card/60 p-2">
        <input
          value={projectName}
          onChange={(e) => setProjectName(e.target.value)}
          className="min-w-[200px] flex-1 rounded-md bg-transparent px-2 py-1.5 text-sm font-semibold outline-none focus:bg-background/40"
          placeholder="Nome do projeto"
        />
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setTab("resultado");
              toast.success("Cálculo otimizado");
            }}
            className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground shadow-glow hover:opacity-90"
          >
            <Play className="h-4 w-4" /> Calcular
          </button>
          <button
            onClick={() => {
              try {
                if (mode === "chaparia") {
                  generateCutPlanPdf({
                    mode: "chaparia",
                    projectName,
                    client,
                    notes,
                    kerf,
                    sheetW: stock?.w ?? 2200,
                    sheetH: stock?.h ?? 1600,
                    stockLabel: stock?.label,
                    stockMaterial: stock?.material,
                    pieces,
                    sheetResult,
                  });
                } else {
                  generateCutPlanPdf({
                    mode: "barras",
                    projectName,
                    client,
                    notes,
                    kerf,
                    barLen,
                    stockBarLabel: stockBars[0]?.label,
                    cuts,
                    barResult,
                  });
                }
                toast.success("PDF gerado");
              } catch {
                toast.error("Não foi possível gerar o PDF");
              }
            }}
            className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-2 text-sm font-semibold hover:border-gold/40"
          >
            <Download className="h-4 w-4" /> PDF
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-4 flex flex-wrap gap-1 border-b border-border">
        <TabBtn
          active={tab === "projeto"}
          onClick={() => setTab("projeto")}
          icon={<FileText className="h-4 w-4" />}
        >
          Projeto
        </TabBtn>
        <TabBtn
          active={tab === "chapas"}
          onClick={() => setTab("chapas")}
          icon={<Package className="h-4 w-4" />}
        >
          {mode === "chaparia" ? "Chapas" : "Barras brutas"}
        </TabBtn>
        <TabBtn
          active={tab === "pecas"}
          onClick={() => setTab("pecas")}
          icon={<ListChecks className="h-4 w-4" />}
        >
          {mode === "chaparia" ? "Peças" : "Cortes"}
        </TabBtn>
        <TabBtn
          active={tab === "config"}
          onClick={() => setTab("config")}
          icon={<Settings2 className="h-4 w-4" />}
        >
          Configurações
        </TabBtn>
        <TabBtn
          active={tab === "resultado"}
          onClick={() => setTab("resultado")}
          icon={<BarChart3 className="h-4 w-4" />}
        >
          Resultado
        </TabBtn>
      </div>

      {/* Tab panels */}
      {tab === "projeto" && (
        <Panel title="Dados do projeto">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Cliente">
              <input
                value={client}
                onChange={(e) => setClient(e.target.value)}
                className={inputCls}
                placeholder="Nome do cliente"
              />
            </Field>
            <Field label="Observações" className="md:col-span-2">
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={4}
                className={inputCls}
                placeholder="Anotações sobre o projeto, prazo, condições…"
              />
            </Field>
          </div>
        </Panel>
      )}

      {tab === "chapas" && mode === "chaparia" && (
        <SpreadsheetTable
          title="Chapas disponíveis"
          subtitle="Dimensões da chapa para este planejamento — não consulta o Estoque."
          columns={[
            { key: "label", label: "Descrição", type: "text", w: "w-[32%]" },
            { key: "material", label: "Material", type: "text", w: "w-[32%]" },
            { key: "w", label: "Largura (mm)", type: "number", w: "w-[18%]" },
            { key: "h", label: "Altura (mm)", type: "number", w: "w-[18%]" },
          ]}
          rows={stocks}
          setRows={setStocks}
          newRow={() => ({
            id: uid(),
            label: `Chapa ${stocks.length + 1}`,
            w: 2200,
            h: 1600,
            material: "Vidro 8mm",
          })}
        />
      )}

      {tab === "chapas" && mode === "barras" && (
        <SpreadsheetTable
          title="Barras brutas"
          subtitle="Comprimento da barra para este planejamento."
          columns={[
            { key: "label", label: "Descrição", type: "text", w: "w-[65%]" },
            { key: "len", label: "Comprimento (mm)", type: "number", w: "w-[30%]" },
          ]}
          rows={stockBars}
          setRows={setStockBars}
          newRow={() => ({ id: uid(), label: `Barra ${stockBars.length + 1}`, len: 6000 })}
        />
      )}

      {tab === "pecas" && mode === "chaparia" && (
        <SpreadsheetTable
          title="Peças a cortar"
          columns={[
            { key: "label", label: "Descrição", type: "text", w: "w-[26%]" },
            { key: "material", label: "Material", type: "text", w: "w-[24%]" },
            { key: "w", label: "Largura (mm)", type: "number", w: "w-[14%]" },
            { key: "h", label: "Altura (mm)", type: "number", w: "w-[14%]" },
            { key: "qty", label: "Qtd", type: "number", w: "w-[10%]" },
            { key: "rotate", label: "Girar 90°", type: "bool", w: "w-[10%]" },
          ]}
          rows={pieces}
          setRows={setPieces}
          colored
          newRow={() => ({
            id: uid(),
            label: `Peça ${pieces.length + 1}`,
            w: 500,
            h: 500,
            qty: 1,
            rotate: true,
            material: stocks[0]?.material ?? "Vidro 8mm",
          })}
        />
      )}

      {tab === "pecas" && mode === "barras" && (
        <SpreadsheetTable
          title="Cortes necessários"
          columns={[
            { key: "label", label: "Descrição", type: "text", w: "w-[55%]" },
            { key: "len", label: "Comprimento (mm)", type: "number", w: "w-[25%]" },
            { key: "qty", label: "Qtd", type: "number", w: "w-[15%]" },
          ]}
          rows={cuts}
          setRows={setCuts}
          colored
          newRow={() => ({ id: uid(), label: `Corte ${cuts.length + 1}`, len: 1000, qty: 1 })}
        />
      )}

      {tab === "config" && (
        <Panel title="Configurações de corte">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Espessura do corte / serra (mm)">
              {/* Revisao 32 — nao e `type="number"`: ele descartava a virgula
                  e o `|| 0` zerava o kerf calado. `NumeroCampo` aceita "," e
                  "." e recusa o que nao e numero, mantendo o valor anterior. */}
              <NumeroCampo value={kerf} onChange={setKerf} className={inputCls} />
              <span className="mt-1 block text-xs text-muted-foreground">
                Espaço perdido a cada corte (kerf).
              </span>
            </Field>
            <Field label="Opções">
              <label className="flex items-center gap-2 rounded-md border border-border bg-background/40 px-3 py-2 text-sm">
                <input
                  type="checkbox"
                  checked={allowRotate}
                  disabled={considerGrain}
                  onChange={(e) => setAllowRotate(e.target.checked)}
                />
                Permitir rotacionar peças 90°
              </label>
              <label className="mt-2 flex items-center gap-2 rounded-md border border-border bg-background/40 px-3 py-2 text-sm">
                <input
                  type="checkbox"
                  checked={considerGrain}
                  onChange={(e) => setConsiderGrain(e.target.checked)}
                />
                Respeitar veio / fio do material (sem rotação 90°)
              </label>
              {considerGrain && (
                <span className="mt-1 block text-xs text-muted-foreground">
                  Com veio ativo, peças mantêm a orientação original — rotação 90° é ignorada.
                </span>
              )}
            </Field>
          </div>
        </Panel>
      )}

      {tab === "resultado" && (
        <div className="space-y-4">
          {mode === "chaparia" ? (
            <>
              <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                <Stat label="Chapas usadas" value={String(sheetResult.sheets.length)} />
                <Stat
                  label="Peças encaixadas"
                  value={`${sheetResult.placedCount} / ${sheetResult.totalCount}`}
                />
                <Stat label="Aproveitamento" value={`${sheetResult.usagePct.toFixed(1)}%`} accent />
                <Stat label="Sobra total" value={`${sheetResult.wasteM2.toFixed(2)} m²`} />
              </div>
              {sheetResult.unplaced.length > 0 && (
                <div className="rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">
                  Não coube na chapa:{" "}
                  {sheetResult.unplaced.map((u) => `${u.label} (${u.w}×${u.h})`).join(", ")}.
                </div>
              )}
              <div className="space-y-5">
                {sheetResult.sheets.map((s, idx) => (
                  <SheetView
                    key={idx}
                    index={idx}
                    sheet={s}
                    W={stock?.w ?? 2200}
                    H={stock?.h ?? 1600}
                    pieces={pieces}
                  />
                ))}
              </div>
            </>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                <Stat label="Barras necessárias" value={String(barResult.bars.length)} />
                <Stat label="Cortes" value={String(barResult.totalCuts)} />
                <Stat label="Aproveitamento" value={`${barResult.usagePct.toFixed(1)}%`} accent />
                <Stat label="Sobra (m)" value={(barResult.wasteMm / 1000).toFixed(2)} />
              </div>
              {barResult.unplaced.length > 0 && (
                <div className="rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">
                  Corte maior que a barra:{" "}
                  {barResult.unplaced.map((u) => `${u.label} (${u.len}mm)`).join(", ")}
                </div>
              )}
              <div className="space-y-3">
                {barResult.bars.map((b, idx) => (
                  <BarView key={idx} index={idx} bar={b} barLen={barLen} cuts={cuts} />
                ))}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

/* ============================= UI ============================= */

function ModeBtn({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition ${
        active
          ? "bg-gradient-gold text-gold-foreground shadow-glow"
          : "text-muted-foreground hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}

function TabBtn({
  active,
  children,
  onClick,
  icon,
}: {
  active: boolean;
  children: React.ReactNode;
  onClick: () => void;
  icon: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-medium transition ${
        active
          ? "border-gold text-gold"
          : "border-transparent text-muted-foreground hover:text-foreground"
      }`}
    >
      {icon} {children}
    </button>
  );
}

function Panel({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <h3 className="font-display text-sm font-bold uppercase tracking-wider text-muted-foreground">
        {title}
      </h3>
      {subtitle && <p className="mt-1 text-xs text-muted-foreground">{subtitle}</p>}
      <div className="mt-4">{children}</div>
    </div>
  );
}

function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-1.5 block text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      {children}
    </label>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`mt-1 font-display text-2xl font-bold ${accent ? "text-gold" : ""}`}>
        {value}
      </div>
    </div>
  );
}

type ColType = "text" | "number" | "bool";
type ColDef = { key: string; label: string; type: ColType; w?: string };

function SpreadsheetTable<T extends { id: string }>({
  title,
  subtitle,
  columns,
  rows,
  setRows,
  newRow,
  colored,
}: {
  title: string;
  subtitle?: string;
  columns: ColDef[];
  rows: T[];
  setRows: React.Dispatch<React.SetStateAction<T[]>>;
  newRow: () => T;
  colored?: boolean;
}) {
  const update = (id: string, key: string, val: unknown) =>
    setRows((all) => all.map((r) => (r.id === id ? { ...r, [key]: val } : r)));
  const remove = (id: string) => setRows((all) => all.filter((r) => r.id !== id));
  const duplicate = (id: string) =>
    setRows((all) => {
      const r = all.find((x) => x.id === id);
      if (!r) return all;
      return [...all, { ...r, id: uid() }];
    });

  return (
    <Panel title={title} subtitle={subtitle}>
      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-background/40 text-[11px] uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="w-[40px] px-2 py-2"></th>
              {columns.map((c) => (
                <th key={c.key} className={`px-3 py-2 text-left font-semibold ${c.w ?? ""}`}>
                  {c.label}
                </th>
              ))}
              <th className="w-[80px] px-2 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => (
              <tr key={row.id} className="border-t border-border hover:bg-background/30">
                <td className="px-2 py-1.5 text-center">
                  {colored ? (
                    <span
                      className="inline-block h-3 w-3 rounded-sm"
                      style={{ background: CUT_PLAN_COLORS[i % CUT_PLAN_COLORS.length] }}
                    />
                  ) : (
                    <span className="text-xs text-muted-foreground">{i + 1}</span>
                  )}
                </td>
                {columns.map((c) => {
                  const v = (row as unknown as Record<string, unknown>)[c.key];
                  return (
                    <td key={c.key} className="px-2 py-1.5">
                      {c.type === "bool" ? (
                        <input
                          type="checkbox"
                          checked={Boolean(v)}
                          onChange={(e) => update(row.id, c.key, e.target.checked)}
                        />
                      ) : c.type === "number" ? (
                        <NumeroCampo
                          value={Number(v) || 0}
                          onChange={(n) => update(row.id, c.key, n)}
                          zeroVazio
                          className="w-full rounded-md border border-transparent bg-transparent px-2 py-1 outline-none hover:border-border focus:border-gold/60 focus:bg-background/60"
                        />
                      ) : (
                        <input
                          type="text"
                          value={v as string | number}
                          onChange={(e) => update(row.id, c.key, e.target.value)}
                          className="w-full rounded-md border border-transparent bg-transparent px-2 py-1 outline-none hover:border-border focus:border-gold/60 focus:bg-background/60"
                        />
                      )}
                    </td>
                  );
                })}
                <td className="px-2 py-1.5">
                  <div className="flex items-center justify-end gap-1">
                    <button
                      onClick={() => duplicate(row.id)}
                      className="rounded p-1 text-muted-foreground hover:text-foreground"
                      title="Duplicar"
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => remove(row.id)}
                      className="rounded p-1 text-muted-foreground hover:text-destructive"
                      title="Remover"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td
                  colSpan={columns.length + 2}
                  className="px-3 py-6 text-center text-sm text-muted-foreground"
                >
                  Nenhum item. Adicione abaixo.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <button
        onClick={() => setRows((p) => [...p, newRow()])}
        className="mt-3 inline-flex items-center gap-1.5 rounded-md bg-gold/15 px-3 py-2 text-xs font-semibold text-gold hover:bg-gold/25"
      >
        <Plus className="h-3.5 w-3.5" /> Adicionar linha
      </button>
    </Panel>
  );
}

const inputCls =
  "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring";

/* ============================= Visualizações ============================= */

function SheetView({
  index,
  sheet,
  W,
  H,
  pieces,
}: {
  index: number;
  sheet: PackedSheet;
  W: number;
  H: number;
  pieces: SheetPiece[];
}) {
  const scale = Math.min(720 / W, 420 / H);
  const labelOf = (i: number) => pieces[i]?.label ?? "?";
  const usage = (sheet.usedArea / (W * H)) * 100;
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="font-display text-lg font-bold">Chapa #{index + 1}</div>
          <div className="text-xs text-muted-foreground">
            {sheet.placements.length} peças · aproveitamento {usage.toFixed(1)}%
          </div>
        </div>
      </div>
      <div className="mb-3 grid gap-2 text-xs text-muted-foreground sm:grid-cols-2 lg:grid-cols-3">
        {sheet.free
          .filter((fr) => fr.w > 40 && fr.h > 40)
          .map((fr, i) => (
            <div
              key={i}
              className="rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-amber-200"
            >
              Sobra {i + 1}:{" "}
              <strong>
                {Math.round(fr.w)} × {Math.round(fr.h)} mm
              </strong>{" "}
              · {((fr.w * fr.h) / 1_000_000).toFixed(2)} m²
            </div>
          ))}
      </div>
      <div className="overflow-auto rounded-lg border border-border bg-[#0a0a0a] p-3">
        <svg width={W * scale} height={H * scale} className="block">
          <rect x={0} y={0} width={W * scale} height={H * scale} fill="#1a1a1a" stroke="#666" />
          {sheet.placements.map((pl, i) => (
            <g key={i}>
              <rect
                x={pl.x * scale}
                y={pl.y * scale}
                width={pl.w * scale}
                height={pl.h * scale}
                fill={CUT_PLAN_COLORS[pl.pieceIndex % CUT_PLAN_COLORS.length] + "cc"}
                stroke="#000"
                strokeWidth={1}
              />
              <text
                x={(pl.x + pl.w / 2) * scale}
                y={(pl.y + pl.h / 2) * scale}
                textAnchor="middle"
                dominantBaseline="middle"
                fontSize={Math.min(12, (pl.w * scale) / 8)}
                fill="#0a0a0a"
                fontWeight="700"
              >
                {labelOf(pl.pieceIndex)} {pl.w}×{pl.h}
                {pl.rotated ? "↻" : ""}
              </text>
            </g>
          ))}
          {sheet.free
            .filter((fr) => fr.w > 40 && fr.h > 40)
            .map((fr, i) => (
              <g key={`sobra-${i}`}>
                <rect
                  x={fr.x * scale}
                  y={fr.y * scale}
                  width={fr.w * scale}
                  height={fr.h * scale}
                  fill="#111827"
                  stroke="#f59e0b"
                  strokeDasharray="6 4"
                  strokeWidth={1}
                  opacity={0.82}
                />
                <text
                  x={(fr.x + fr.w / 2) * scale}
                  y={(fr.y + fr.h / 2) * scale}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fontSize={Math.min(12, Math.max(8, (fr.w * scale) / 12))}
                  fill="#fbbf24"
                  fontWeight="700"
                >
                  sobra {Math.round(fr.w)}×{Math.round(fr.h)}mm
                </text>
              </g>
            ))}
        </svg>
      </div>
    </div>
  );
}

function BarView({
  index,
  bar,
  barLen,
  cuts,
}: {
  index: number;
  bar: PackedBar;
  barLen: number;
  cuts: BarPiece[];
}) {
  const scale = 900 / barLen;
  const labelOf = (i: number) => cuts[i]?.label ?? "?";
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <div className="font-display text-lg font-bold">Barra #{index + 1}</div>
        <div className="text-xs text-muted-foreground">
          Sobra: {bar.waste} mm · Uso {((1 - bar.waste / barLen) * 100).toFixed(1)}%
        </div>
      </div>
      <div className="overflow-auto rounded-lg border border-border bg-[#0a0a0a] p-3">
        <svg width={barLen * scale} height={70} className="block">
          <rect x={0} y={20} width={barLen * scale} height={30} fill="#1a1a1a" stroke="#666" />
          {bar.segments.map((s, i) => (
            <g key={i}>
              <rect
                x={s.start * scale}
                y={20}
                width={s.len * scale}
                height={30}
                fill={CUT_PLAN_COLORS[s.cutIndex % CUT_PLAN_COLORS.length] + "cc"}
                stroke="#000"
              />
              <text
                x={(s.start + s.len / 2) * scale}
                y={38}
                textAnchor="middle"
                fontSize={11}
                fill="#0a0a0a"
                fontWeight="700"
              >
                {labelOf(s.cutIndex)} · {s.len}
              </text>
            </g>
          ))}
          {bar.waste > 0 && (
            <g>
              <rect
                x={(barLen - bar.waste) * scale}
                y={20}
                width={bar.waste * scale}
                height={30}
                fill="#333"
                stroke="#666"
                strokeDasharray="3 2"
              />
              <text
                x={(barLen - bar.waste / 2) * scale}
                y={38}
                textAnchor="middle"
                fontSize={11}
                fill="#888"
              >
                sobra {bar.waste}
              </text>
            </g>
          )}
        </svg>
      </div>
    </div>
  );
}

/**
 * Campo numerico do plano de corte (Revisao 32).
 *
 * O padrao unico do projeto: `inputMode="decimal"` em vez de `type="number"`,
 * rascunho em TEXTO enquanto o campo tem foco, e conversao que aceita virgula
 * e ponto. Entrada ilegivel NAO propaga — o valor anterior fica de pe e o
 * campo se sinaliza em vermelho, em vez de a medida virar 0 mm sem aviso.
 */
function NumeroCampo({
  value,
  onChange,
  className,
  zeroVazio,
}: {
  value: number;
  onChange: (v: number) => void;
  className?: string;
  zeroVazio?: boolean;
}) {
  const [draft, setDraft] = useState<string | null>(null);
  const texto = draft ?? (zeroVazio && value === 0 ? "" : numeroParaTexto(value));
  const invalido = draft !== null && draft.trim() !== "" && Number.isNaN(textoParaNumero(draft));
  return (
    <input
      inputMode="decimal"
      value={texto}
      placeholder="Digite"
      title={
        invalido
          ? "Valor inválido — use apenas números, com vírgula ou ponto na casa decimal (ex.: 1200 ou 3,2)."
          : undefined
      }
      onChange={(e) => {
        setDraft(e.target.value);
        if (e.target.value.trim() === "") return onChange(0);
        const n = textoParaNumero(e.target.value);
        if (!Number.isNaN(n)) onChange(n);
      }}
      onBlur={() => setDraft(null)}
      className={`${className ?? ""} ${invalido ? "border-destructive text-destructive" : ""}`}
    />
  );
}
