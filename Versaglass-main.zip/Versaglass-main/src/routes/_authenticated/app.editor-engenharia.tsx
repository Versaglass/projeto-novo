import { createFileRoute } from "@tanstack/react-router";
import { UniversalEngineeringEditor } from "@/components/engineering/UniversalEngineeringEditor";

export const Route = createFileRoute("/_authenticated/app/editor-engenharia")({
  component: EditorEngenhariaPage,
});

function EditorEngenhariaPage() {
  return <UniversalEngineeringEditor />;
}
