import { createFileRoute } from "@tanstack/react-router";
import { Copy, Sparkles } from "lucide-react";
import { useState } from "react";
import { AI_TEMPLATES, fillPrompt } from "@/lib/ai-assistant";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

/**
 * ROTA OCULTA (Revisão 227) — Assistente IA. Mantida no código para reativação;
 * menu removido e URL direta redireciona para `/app` com toast.
 */
export const Route = createFileRoute("/_authenticated/app/ia")({
  beforeLoad: hiddenRouteBeforeLoad,
  component: IaPage,
});

function IaPage() {
  const [values, setValues] = useState({
    produto: "Espelho orgânico com LED",
    categoria: "espelho",
    codigo: "ESP-LED-160X70",
    medida: "160x70",
    cor: "madeirada",
    oferta: "entrega e instalação grátis",
    publico: "clientes de Guarapari",
    orcamento: "",
  });
  const [selected, setSelected] = useState(AI_TEMPLATES[0]);
  const prompt = fillPrompt(selected.prompt, values);
  return (
    <div className="space-y-6">
      <div>
        <Badge className="mb-3 gap-1">
          <Sparkles className="h-3.5 w-3.5" />
          IA
        </Badge>
        <h1 className="font-display text-3xl font-bold">Assistente de IA</h1>
        <p className="text-sm text-muted-foreground">
          Modelos prontos para produto, anúncio, SKU e análise de orçamento. Conecte sua chave de IA
          na hospedagem quando quiser gerar automaticamente.
        </p>
      </div>
      <div className="grid gap-4 lg:grid-cols-[320px,1fr]">
        <div className="space-y-3">
          {AI_TEMPLATES.map((t) => (
            <button
              key={t.title}
              onClick={() => setSelected(t)}
              className={`w-full rounded-xl border p-4 text-left transition ${selected.title === t.title ? "border-gold bg-gold/10" : "hover:bg-muted/50"}`}
            >
              <div className="font-semibold">{t.title}</div>
              <p className="mt-1 text-sm text-muted-foreground">{t.description}</p>
            </button>
          ))}
        </div>
        <Card>
          <CardHeader>
            <CardTitle>{selected.title}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid gap-3 md:grid-cols-2">
              {Object.keys(values)
                .filter((k) => k !== "orcamento")
                .map((k) => (
                  <Input
                    key={k}
                    value={(values as any)[k]}
                    onChange={(e) => setValues((v) => ({ ...v, [k]: e.target.value }))}
                    placeholder={k}
                  />
                ))}
            </div>
            <Textarea value={prompt} readOnly className="min-h-40" />
            <Button
              onClick={() => {
                navigator.clipboard.writeText(prompt);
                toast.success("Prompt copiado");
              }}
              className="gap-2"
            >
              <Copy className="h-4 w-4" />
              Copiar prompt
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
