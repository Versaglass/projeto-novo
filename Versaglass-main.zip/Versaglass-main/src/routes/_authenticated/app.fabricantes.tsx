import { createFileRoute } from "@tanstack/react-router";
import {
  EnterpriseCrudPage,
  type CrudItem,
  type FieldConfig,
} from "@/components/EnterpriseCrudPage";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";

/** ROTA OCULTA (Revisão 227) — Fabricantes. Código preservado; acesso bloqueado. */
export const Route = createFileRoute("/_authenticated/app/fabricantes")({
  beforeLoad: hiddenRouteBeforeLoad,
  component: FabricantesPage,
});
const fields: FieldConfig[] = [
  { key: "empresa", label: "Fabricante" },
  { key: "cnpj", label: "CNPJ" },
  { key: "contato", label: "Contato" },
  { key: "telefone", label: "WhatsApp" },
  { key: "categoria", label: "Categoria" },
  { key: "catalogo", label: "Catálogo/Link" },
  { key: "tabela_preco", label: "Tabela de preço" },
  { key: "promocoes", label: "Promoções", type: "textarea" },
  { key: "status", label: "Status", type: "select", options: ["Ativo", "Inativo", "Pendente"] },
];
const data: CrudItem[] = [
  {
    id: "fab1",
    empresa: "Fabricante exemplo",
    contato: "Comercial",
    categoria: "Vidros e ferragens",
    status: "Ativo",
  },
];
function FabricantesPage() {
  return (
    <EnterpriseCrudPage
      title="Área do Fabricante"
      badge="Catálogos e tabelas"
      subtitle="Fabricantes podem cadastrar produtos, catálogos, tabelas de preço, promoções e materiais técnicos."
      storageKey="vmm_fabricantes"
      initialData={data}
      fields={fields}
      highlight={["empresa", "categoria", "contato", "status"]}
    />
  );
}
