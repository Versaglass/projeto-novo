import { createFileRoute } from "@tanstack/react-router";
import { DatabaseBackup, RotateCcw, Download } from "lucide-react";
import {
  EnterpriseCrudPage,
  type CrudItem,
  type FieldConfig,
} from "@/components/EnterpriseCrudPage";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";

/** ROTA OCULTA (Revisão 227) — Backups. Código preservado; acesso bloqueado. */
export const Route = createFileRoute("/_authenticated/app/backups")({
  beforeLoad: hiddenRouteBeforeLoad,
  component: BackupsPage,
});
const fields: FieldConfig[] = [
  { key: "nome", label: "Backup" },
  {
    key: "tipo",
    label: "Tipo",
    type: "select",
    options: ["Diário", "Semanal", "Mensal", "Manual"],
  },
  { key: "data", label: "Data" },
  { key: "tamanho", label: "Tamanho" },
  { key: "arquivo", label: "Arquivo" },
  {
    key: "status",
    label: "Status",
    type: "select",
    options: ["Concluído", "Falhou", "Em andamento"],
  },
  { key: "observacoes", label: "Observações", type: "textarea" },
];
const data: CrudItem[] = [
  {
    id: "bkp1",
    nome: "Backup diário",
    tipo: "Diário",
    data: "2026-07-01",
    tamanho: "12 MB",
    status: "Concluído",
  },
];
function BackupsPage() {
  return (
    <div className="space-y-5">
      <div className="grid gap-3 md:grid-cols-3">
        {[
          [DatabaseBackup, "Backup automático"],
          [Download, "Baixar cópia"],
          [RotateCcw, "Restaurar"],
        ].map(([Icon, label]: any) => (
          <div key={label} className="rounded-2xl border bg-card p-4">
            <Icon className="mb-2 h-6 w-6 text-gold" />
            <b>{label}</b>
            <p className="text-xs text-muted-foreground">diário, semanal e mensal</p>
          </div>
        ))}
      </div>
      <EnterpriseCrudPage
        title="Backups"
        badge="Segurança dos dados"
        subtitle="Controle backups automáticos, cópias manuais e restauração com um clique."
        storageKey="vmm_backups"
        initialData={data}
        fields={fields}
        highlight={["nome", "tipo", "data", "tamanho", "status"]}
      />
    </div>
  );
}
