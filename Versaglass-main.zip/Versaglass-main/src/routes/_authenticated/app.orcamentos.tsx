import {
  createFileRoute,
  Link,
  Outlet,
  useLocation,
  useNavigate,
  type SearchSchemaInput,
} from "@tanstack/react-router";
import { searchOrcamentoNovo } from "@/routes/_authenticated/app.orcamentos.novo";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { brl, dateBR } from "@/lib/format";
import {
  Plus,
  FileText,
  List,
  Search,
  Square,
  PanelTop,
  Pencil,
  AlertTriangle,
  Building2,
  Eye,
  Trash2,
  type LucideIcon,
} from "lucide-react";
import { PipelineStatus, type Stage } from "@/components/PipelineStatus";
import { toast } from "sonner";
import { parseEspecialidade, type Especialidade } from "@/lib/especialidade";
import { foldBusca } from "@/lib/fold-busca";
import {
  useQuotes,
  useDeleteQuote,
  quoteErrorMessage,
  type QuoteListRow,
} from "@/hooks/use-quotes";
import { useCompany } from "@/contexts/company-context";
import { useFinePermissions } from "@/hooks/use-fine-permission";
import { CustomerSearchField } from "@/components/quotes/CustomerSearchField";
import { CustomerDialog, type CustomerFormValues } from "@/components/customers/CustomerDialog";
import { toClientInput, clientErrorMessage } from "@/hooks/use-clients";

const ESPECIALIDADES: {
  id: Especialidade;
  label: string;
  desc: string;
  Icon: LucideIcon;
  tone: string;
}[] = [
  {
    id: "vidracaria",
    label: "Vidraçaria",
    desc: "Vidros, temperados, espelhos e box",
    Icon: Square,
    tone: "from-[oklch(0.62_0.15_220)] to-[oklch(0.50_0.18_240)]",
  },
  {
    id: "esquadrias",
    label: "Esquadrias",
    desc: "Janelas, portas e esquadrias de alumínio",
    Icon: PanelTop,
    tone: "from-[oklch(0.58_0.16_60)] to-[oklch(0.45_0.14_40)]",
  },
];

type OrcamentosView = "lista" | "adicionar";

/** O que `Link`/`navigate` podem informar — tudo opcional, os defaults vêm do validateSearch. */
type OrcamentosSearchInput = {
  view?: OrcamentosView;
  /** Só usado na aba Lista (filtro visual / contexto); ignorado em Adicionar. */
  esp?: Especialidade;
} & SearchSchemaInput;

/** O que `Route.useSearch()` devolve — defaults já aplicados. */
type OrcamentosSearch = {
  view: OrcamentosView;
  esp: Especialidade | undefined;
};

export const Route = createFileRoute("/_authenticated/app/orcamentos")({
  validateSearch: (search: OrcamentosSearchInput): OrcamentosSearch => ({
    view: search.view === "adicionar" ? "adicionar" : "lista",
    esp: search.view === "adicionar" ? undefined : parseEspecialidade(search.esp),
  }),
  component: OrcamentosPage,
});

type FaixaKey = "todos" | "rascunho" | "enviado" | "aprovado" | "recusado";

const FAIXAS: { key: FaixaKey; label: string; tone: string }[] = [
  { key: "todos", label: "Todos", tone: "bg-muted text-foreground" },
  { key: "rascunho", label: "Rascunho", tone: "bg-slate-500/15 text-slate-300" },
  { key: "enviado", label: "Enviado", tone: "bg-sky-500/15 text-sky-300" },
  { key: "aprovado", label: "Aprovado", tone: "bg-emerald-500/15 text-emerald-300" },
  { key: "recusado", label: "Recusado", tone: "bg-red-500/15 text-red-300" },
];

function matchFaixa(q: QuoteListRow, f: FaixaKey) {
  if (f === "todos") return true;
  return q.status === f;
}

/** Busca local: minúsculas + sem diacríticos (NFD) — ver `foldBusca` / Rev. 166. */
function matchCliente(q: QuoteListRow, term: string) {
  const t = term.trim();
  if (!t) return true;
  const nome = q.customer?.nome ?? "";
  return foldBusca(nome).includes(foldBusca(t));
}

function OrcamentosPage() {
  const location = useLocation();
  const { view, esp } = Route.useSearch();
  const navigate = useNavigate();
  const current = ESPECIALIDADES.find((e) => e.id === esp);
  const { create_orcamentos: canCreate } = useFinePermissions();

  if (location.pathname !== "/app/orcamentos") {
    return <Outlet />;
  }

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Orçamentos</h1>
          <p className="text-sm text-muted-foreground">
            {view === "adicionar" ? (
              "Selecione um cliente para montar o orçamento"
            ) : current ? (
              <>
                Especialidade: <strong className="text-foreground">{current.label}</strong> —{" "}
                {current.desc}
              </>
            ) : (
              "Escolha sua especialidade para começar"
            )}
          </p>
        </div>
        <div className="inline-flex rounded-lg border bg-card p-1">
          <button
            onClick={() =>
              navigate({
                to: "/app/orcamentos",
                search: esp ? { view: "lista", esp } : { view: "lista" },
              })
            }
            className={`inline-flex items-center gap-2 rounded-md px-4 py-2 text-sm font-semibold transition ${
              view === "lista"
                ? "bg-gradient-gold text-gold-foreground shadow-glow"
                : "text-muted-foreground hover:bg-muted"
            }`}
          >
            <List className="h-4 w-4" /> Lista
          </button>
          {canCreate && (
            <button
              type="button"
              onClick={() => navigate({ to: "/app/orcamentos/novo", search: {} })}
              className="inline-flex items-center gap-2 rounded-md px-4 py-2 text-sm font-semibold text-muted-foreground transition hover:bg-muted"
            >
              <Plus className="h-4 w-4" /> Adicionar
            </button>
          )}
        </div>
      </div>

      {view === "lista" && (
        <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
          {ESPECIALIDADES.map((e) => {
            const active = esp === e.id;
            return (
              <button
                key={e.id}
                onClick={() =>
                  navigate({
                    to: "/app/orcamentos",
                    search: { view: "lista", esp: active ? undefined : e.id },
                  })
                }
                className={`group relative overflow-hidden rounded-xl border p-4 text-left transition ${
                  active
                    ? "border-gold/60 shadow-glow ring-2 ring-gold/40"
                    : "border-border bg-card hover:border-gold/30 hover:shadow-elegant"
                }`}
              >
                <div className={`absolute inset-0 bg-gradient-to-br opacity-10 ${e.tone}`} />
                <div className="relative flex items-start gap-3">
                  <div className={`rounded-lg bg-gradient-to-br p-2 text-white ${e.tone}`}>
                    <e.Icon className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-display text-sm font-bold">{e.label}</div>
                    <div className="mt-0.5 text-[11px] leading-tight text-muted-foreground">
                      {e.desc}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {view === "lista" ? <ListaView /> : canCreate ? <AdicionarView /> : <ListaView />}
    </div>
  );
}

function ListaView() {
  const [faixa, setFaixa] = useState<FaixaKey>("todos");
  const [buscaCliente, setBuscaCliente] = useState("");
  const navigate = useNavigate();
  const del = useDeleteQuote();
  const [confirmDel, setConfirmDel] = useState<{ id: string; numero: number; nome: string } | null>(
    null,
  );
  const { edit_orcamentos: canEdit, delete_orcamentos: canDelete } = useFinePermissions();

  // Somente orçamentos da empresa ativa (isolamento multiempresa). Troca de
  // empresa recarrega automaticamente (queryKey inclui o companyId).
  // A consulta traz a lista INTEIRA da empresa (sem paginação) — a busca por
  // cliente e o filtro de faixa são locais em cima desse array (Rev. 166).
  const { data: quotes = [], isLoading, isError, refetch, hasActiveCompany } = useQuotes();

  const onDelete = () => {
    if (!confirmDel) return;
    del.mutate(confirmDel.id, {
      onSuccess: () => {
        toast.success("Orçamento excluído");
        setConfirmDel(null);
      },
      onError: (e) => toast.error(quoteErrorMessage(e)),
    });
  };

  // Contagens por faixa respeitam a busca ativa (ex.: "Pedro" + Enviado = N
  // orçamentos do Pedro nessa faixa), sem nova query.
  const quotesNaBusca = useMemo(
    () => quotes.filter((q) => matchCliente(q, buscaCliente)),
    [quotes, buscaCliente],
  );

  const counts = useMemo(() => {
    const c: Record<FaixaKey, number> = {
      todos: quotesNaBusca.length,
      rascunho: 0,
      enviado: 0,
      aprovado: 0,
      recusado: 0,
    };
    for (const q of quotesNaBusca) {
      for (const f of FAIXAS) if (f.key !== "todos" && matchFaixa(q, f.key)) c[f.key]++;
    }
    return c;
  }, [quotesNaBusca]);

  const filtered = useMemo(
    () => quotesNaBusca.filter((q) => matchFaixa(q, faixa)),
    [quotesNaBusca, faixa],
  );

  const buscaAtiva = buscaCliente.trim().length > 0;

  return (
    <>
      <div className="mb-4 flex flex-wrap gap-2">
        {FAIXAS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFaixa(f.key)}
            className={`inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-semibold transition ${
              faixa === f.key
                ? f.tone + " ring-2 ring-offset-1 ring-offset-background ring-current"
                : "bg-muted/50 text-muted-foreground hover:bg-muted"
            }`}
          >
            {f.label}
            <span className="rounded-full bg-background/50 px-1.5 text-[10px]">
              {counts[f.key]}
            </span>
          </button>
        ))}
      </div>

      {/* Mesmo molde visual de Estoque/Clientes: borda + lupa + input. */}
      <div className="mb-4 flex items-center gap-2 rounded-lg border bg-card px-3 py-2">
        <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
        <input
          value={buscaCliente}
          onChange={(e) => setBuscaCliente(e.target.value)}
          placeholder="Buscar por nome do cliente..."
          disabled={!hasActiveCompany}
          className="flex-1 bg-transparent text-sm outline-none disabled:cursor-not-allowed"
        />
      </div>

      {!hasActiveCompany ? (
        <div className="rounded-2xl border bg-card p-12 text-center">
          <Building2 className="mx-auto h-10 w-10 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">
            Selecione ou crie uma empresa para ver os orçamentos.
          </p>
        </div>
      ) : isLoading ? (
        <p className="text-muted-foreground">Carregando...</p>
      ) : isError ? (
        <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-8 text-center">
          <AlertTriangle className="mx-auto h-8 w-8 text-destructive" />
          <p className="mt-3 text-sm text-muted-foreground">
            Não foi possível carregar os orçamentos.
          </p>
          <button
            onClick={() => refetch()}
            className="mt-4 rounded-lg border border-input px-4 py-2 text-sm font-medium hover:bg-accent"
          >
            Tentar novamente
          </button>
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border bg-card p-12 text-center">
          <FileText className="mx-auto h-10 w-10 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">
            {buscaAtiva
              ? "Nenhum orçamento encontrado para esse cliente com os filtros atuais."
              : "Nenhum orçamento nessa faixa."}
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-2xl border bg-card">
          <table className="w-full min-w-[720px] text-sm">
            <thead className="border-b bg-muted/50 text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3">Número</th>
                <th className="px-4 py-3">Cliente</th>
                <th className="px-4 py-3">Data</th>
                <th className="px-4 py-3">Faixa</th>
                <th className="px-4 py-3">Etapa</th>
                <th className="px-4 py-3 text-right">Total</th>
                <th className="px-4 py-3 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filtered.map((q) => {
                const faixaLabel: FaixaKey = q.status;
                const tone = FAIXAS.find((f) => f.key === faixaLabel)?.tone ?? "";
                // Clicar na linha abre os detalhes (TanStack navigate). Os botões
                // de ação param a propagação para não disparar a navegação da linha.
                const openDetail = () =>
                  navigate({ to: "/app/orcamentos/$id", params: { id: q.id } });
                return (
                  <tr key={q.id} onClick={openDetail} className="cursor-pointer hover:bg-muted/30">
                    <td className="px-4 py-3">
                      <Link
                        to="/app/orcamentos/$id"
                        params={{ id: q.id }}
                        onClick={(e) => e.stopPropagation()}
                        className="font-semibold text-gold hover:underline"
                      >
                        #{q.numero}
                      </Link>
                    </td>
                    <td className="px-4 py-3">{q.customer?.nome ?? "—"}</td>
                    <td className="px-4 py-3 text-muted-foreground">{dateBR(q.created_at)}</td>
                    <td className="px-4 py-3">
                      <span className={`rounded-full px-2 py-0.5 text-xs ${tone}`}>
                        {FAIXAS.find((f) => f.key === faixaLabel)?.label}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <PipelineStatus current={(q.etapa ?? "orcamento") as Stage} compact />
                    </td>
                    <td className="px-4 py-3 text-right font-display font-semibold">
                      {brl(Number(q.total))}
                    </td>
                    <td className="px-4 py-3">
                      <div
                        className="flex items-center justify-end gap-1"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Link
                          to="/app/orcamentos/$id"
                          params={{ id: q.id }}
                          title="Visualizar"
                          className="grid h-8 w-8 place-items-center rounded-lg border bg-background text-muted-foreground hover:text-foreground"
                        >
                          <Eye className="h-3.5 w-3.5" />
                        </Link>
                        {canEdit && (
                          <Link
                            to="/app/orcamentos/novo"
                            search={searchOrcamentoNovo({ id: q.id })}
                            title="Editar"
                            className="grid h-8 w-8 place-items-center rounded-lg border bg-background text-muted-foreground hover:text-foreground"
                          >
                            <Pencil className="h-3.5 w-3.5" />
                          </Link>
                        )}
                        {canDelete && (
                          <button
                            type="button"
                            title="Excluir"
                            onClick={() =>
                              setConfirmDel({
                                id: q.id,
                                numero: q.numero,
                                nome: q.customer?.nome ?? "cliente",
                              })
                            }
                            className="grid h-8 w-8 place-items-center rounded-lg border bg-background text-destructive hover:bg-destructive hover:text-destructive-foreground"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {confirmDel && (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4"
          onClick={() => setConfirmDel(null)}
        >
          <div
            className="w-full max-w-sm rounded-2xl bg-card p-6 shadow-elegant"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="font-display text-lg font-bold">Excluir orçamento?</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Excluir o orçamento <strong>#{confirmDel.numero}</strong> de{" "}
              <strong>{confirmDel.nome}</strong>? Os itens serão removidos e esta ação não pode ser
              desfeita.
            </p>
            <div className="mt-4 flex justify-end gap-2">
              <button
                onClick={() => setConfirmDel(null)}
                className="rounded-lg border border-input px-4 py-2 text-sm"
              >
                Cancelar
              </button>
              <button
                onClick={onDelete}
                disabled={del.isPending}
                className="rounded-lg bg-destructive px-4 py-2 text-sm font-semibold text-destructive-foreground disabled:cursor-not-allowed disabled:opacity-50"
              >
                {del.isPending ? "Excluindo..." : "Excluir"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function AdicionarView() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;
  const [open, setOpen] = useState(false);

  const { data: clientes = [], isLoading } = useQuery({
    queryKey: ["customers-orc", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      if (!companyId) return [];
      const { data, error } = await supabase
        .from("customers")
        .select("id,nome,telefone")
        .eq("company_id", companyId)
        .order("nome");
      if (error) throw error;
      return data ?? [];
    },
  });

  const create = useMutation({
    mutationFn: async (form: CustomerFormValues) => {
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Não autenticado");
      const { data, error } = await supabase
        .from("customers")
        .insert({ ...toClientInput(form), owner_id: u.user.id, company_id: companyId })
        .select("id")
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: (c) => {
      toast.success("Cliente cadastrado");
      qc.invalidateQueries({ queryKey: ["customers-orc"] });
      qc.invalidateQueries({ queryKey: ["quote-customer-options"] });
      qc.invalidateQueries({ queryKey: ["clients"] });
      setOpen(false);
      // Mesmo fluxo "criar e seguir" da versão resumida: obra com o cliente novo.
      navigate({ to: "/app/orcamentos/obra", search: { cliente: c.id } });
    },
    onError: (e: unknown) => toast.error(e instanceof Error ? e.message : clientErrorMessage(e)),
  });

  const irParaCliente = (id: string) => {
    navigate({ to: "/app/orcamentos/obra", search: { cliente: id } });
  };

  return (
    <>
      <div className="rounded-2xl border bg-card p-4">
        <p className="mb-3 text-sm text-muted-foreground">
          Selecione um cliente para montar o orçamento, ou cadastre um novo sem sair desta tela.
        </p>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-sm transition hover:opacity-95"
          >
            <Plus className="h-4 w-4" /> Adicionar Cliente
          </button>
          <div className="min-w-0 flex-1">
            <CustomerSearchField
              customers={clientes}
              onSelect={irParaCliente}
              isLoading={isLoading}
              clearOnSelect
              placeholder="Buscar e selecionar cliente..."
              emptyText={
                companyId
                  ? "Nenhum cliente encontrado. Cadastre o primeiro."
                  : "Selecione uma empresa ativa."
              }
            />
          </div>
        </div>
      </div>

      {open && (
        <CustomerDialog
          title="Novo cliente"
          submitLabel="Cadastrar e continuar"
          onClose={() => setOpen(false)}
          onSubmit={(v) => create.mutate(v)}
          loading={create.isPending}
        />
      )}
    </>
  );
}
