import { createFileRoute } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  EnterpriseCrudPage,
  type CrudItem,
  type FieldConfig,
} from "@/components/EnterpriseCrudPage";
import { attachFiscalToFinancialDashboard } from "@/modules/fiscal/fiscalService";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";
import { Download, Mail, ReceiptText, RotateCcw, Send, Smartphone, XCircle } from "lucide-react";

/** ROTA OCULTA (Revisão 227) — Fiscal. Código preservado; acesso bloqueado. */
export const Route = createFileRoute("/_authenticated/app/fiscal")({
  beforeLoad: hiddenRouteBeforeLoad,
  component: FiscalPage,
});

const settingsFields: FieldConfig[] = [
  { key: "legal_name", label: "Razão social" },
  { key: "trade_name", label: "Nome fantasia" },
  { key: "cnpj", label: "CNPJ" },
  { key: "state_registration", label: "Inscrição estadual" },
  { key: "municipal_registration", label: "Inscrição municipal" },
  {
    key: "tax_regime",
    label: "Regime tributário",
    type: "select",
    options: ["simples_nacional", "lucro_presumido", "lucro_real", "mei"],
  },
  { key: "city", label: "Cidade" },
  { key: "state", label: "Estado" },
  { key: "certificate_url", label: "Certificado A1 URL" },
  { key: "certificate_password", label: "Senha do certificado" },
  {
    key: "environment",
    label: "Ambiente",
    type: "select",
    options: ["homologation", "production"],
  },
  {
    key: "provider",
    label: "Provedor fiscal",
    type: "select",
    options: ["plugnotas", "tecnospeed", "nuvem_fiscal", "manual"],
  },
];

const invoiceFields: FieldConfig[] = [
  { key: "customer_name", label: "Cliente" },
  { key: "sale_id", label: "Venda" },
  { key: "order_service_id", label: "Ordem de serviço" },
  { key: "invoice_type", label: "Tipo", type: "select", options: ["nfe", "nfse", "nfce"] },
  {
    key: "status",
    label: "Status",
    type: "select",
    options: ["draft", "processing", "authorized", "rejected", "canceled"],
  },
  { key: "invoice_number", label: "Número" },
  { key: "access_key", label: "Chave de acesso" },
  { key: "protocol", label: "Protocolo" },
  { key: "xml_url", label: "XML" },
  { key: "pdf_url", label: "DANFE PDF" },
  { key: "total_amount", label: "Valor total", type: "currency" },
  { key: "error_message", label: "Erro/rejeição", type: "textarea" },
  { key: "issued_at", label: "Emitida em" },
  { key: "canceled_at", label: "Cancelada em" },
];

const settingsData: CrudItem[] = [
  {
    id: "fs1",
    legal_name: "Vidraçaria Exemplo LTDA",
    trade_name: "Vidraçaria Exemplo",
    cnpj: "00.000.000/0001-00",
    state_registration: "",
    municipal_registration: "",
    tax_regime: "simples_nacional",
    city: "Guarapari",
    state: "ES",
    certificate_url: "",
    certificate_password: "",
    environment: "homologation",
    provider: "plugnotas",
  },
];
const invoiceData: CrudItem[] = [
  {
    id: "inv1",
    customer_name: "Cliente exemplo",
    sale_id: "VEN-001",
    order_service_id: "OS-001",
    invoice_type: "nfse",
    status: "draft",
    invoice_number: "",
    access_key: "",
    protocol: "",
    xml_url: "",
    pdf_url: "",
    total_amount: 1850,
    error_message: "",
    issued_at: "",
    canceled_at: "",
  },
  {
    id: "inv2",
    customer_name: "Cliente exemplo 2",
    sale_id: "VEN-002",
    order_service_id: "OS-002",
    invoice_type: "nfe",
    status: "authorized",
    invoice_number: "NF-0002",
    access_key: "35260700000000000100550010000000021000000020",
    protocol: "135260000000000",
    xml_url: "https://fiscal.exemplo/nf-0002.xml",
    pdf_url: "https://fiscal.exemplo/nf-0002.pdf",
    total_amount: 3200,
    error_message: "",
    issued_at: "2026-07-02T10:00:00",
    canceled_at: "",
  },
];

function FiscalPage() {
  const analytics = attachFiscalToFinancialDashboard(invoiceData as any);
  return (
    <div className="space-y-6">
      <div>
        <Badge variant="secondary" className="mb-3">
          Módulo Fiscal
        </Badge>
        <h1 className="font-display text-3xl font-bold">NF-e, NFS-e, XML e DANFE</h1>
        <p className="mt-2 max-w-4xl text-sm text-muted-foreground">
          Configuração fiscal por empresa com isolamento multiusuário. A emissão usa provedores como
          PlugNotas, TecnoSpeed ou Nuvem Fiscal através de uma interface genérica.
        </p>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">Faturamento autorizado</div>
            <div className="text-2xl font-bold">
              {analytics.authorized.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">Em processamento</div>
            <div className="text-2xl font-bold">{analytics.processing}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground">Rejeitadas</div>
            <div className="text-2xl font-bold">{analytics.rejected}</div>
          </CardContent>
        </Card>
      </div>
      <Card>
        <CardContent className="grid gap-3 p-4 md:grid-cols-6">
          <Button className="gap-2">
            <ReceiptText className="h-4 w-4" /> Emitir Nota Fiscal
          </Button>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" /> Baixar XML
          </Button>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" /> Baixar PDF
          </Button>
          <Button variant="outline" className="gap-2">
            <Mail className="h-4 w-4" /> Enviar e-mail
          </Button>
          <Button variant="outline" className="gap-2">
            <Smartphone className="h-4 w-4" /> WhatsApp
          </Button>
          <Button variant="destructive" className="gap-2">
            <XCircle className="h-4 w-4" /> Cancelar
          </Button>
          <Button variant="outline" className="gap-2">
            <RotateCcw className="h-4 w-4" /> Reemitir rejeitada
          </Button>
          <Button variant="outline" className="gap-2">
            <Send className="h-4 w-4" /> Consultar status
          </Button>
        </CardContent>
      </Card>
      <Tabs defaultValue="invoices" className="space-y-4">
        <TabsList className="flex w-fit flex-wrap">
          <TabsTrigger value="invoices">Notas fiscais</TabsTrigger>
          <TabsTrigger value="settings">Configuração fiscal</TabsTrigger>
        </TabsList>
        <TabsContent value="invoices">
          <EnterpriseCrudPage
            title="Notas fiscais"
            subtitle="Controle de NF-e e NFS-e com status, chave, XML, DANFE, protocolo e vínculo com venda ou ordem de serviço."
            badge="Emissão e histórico"
            storageKey="vmm_fiscal_invoices"
            initialData={invoiceData}
            fields={invoiceFields}
            highlight={[
              "customer_name",
              "invoice_type",
              "status",
              "invoice_number",
              "total_amount",
              "issued_at",
            ]}
          />
        </TabsContent>
        <TabsContent value="settings">
          <EnterpriseCrudPage
            title="Configuração fiscal"
            subtitle="Dados fiscais, certificado digital A1, ambiente e provedor por empresa. O certificado deve ser armazenado com segurança no storage/backend e nunca exposto entre empresas."
            badge="Por empresa"
            storageKey="vmm_fiscal_settings"
            initialData={settingsData}
            fields={settingsFields}
            highlight={["legal_name", "cnpj", "tax_regime", "city", "state", "provider"]}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
