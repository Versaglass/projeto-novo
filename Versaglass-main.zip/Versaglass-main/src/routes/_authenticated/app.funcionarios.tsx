import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Loader2, Mail, ShieldCheck, UserCog, UserPlus, X } from "lucide-react";
import { toast } from "sonner";
import { useCompany } from "@/contexts/company-context";
import {
  useCompanyMembers,
  useInviteSeller,
  type CompanyMemberRow,
} from "@/hooks/use-company-members";
import { mensagemDoErro } from "@/lib/erro-mensagem";

export const Route = createFileRoute("/_authenticated/app/funcionarios")({
  component: FuncionariosPage,
});

const ROLE_LABEL: Record<string, string> = {
  owner: "Proprietário",
  admin: "Administrador",
  manager: "Gerente",
  operator: "Operador",
  installer: "Instalador",
  seller: "Vendedor",
};

const STATUS_LABEL: Record<string, string> = {
  active: "Ativo",
  blocked: "Bloqueado",
  invited: "Convidado",
};

function FuncionariosPage() {
  const { activeCompany, isCompanyAdmin, loading: companyLoading } = useCompany();
  const companyId = activeCompany?.companyId ?? null;
  const { data: membros = [], isLoading, error } = useCompanyMembers(companyId);
  const [modalAberto, setModalAberto] = useState(false);

  if (companyLoading) {
    return (
      <p className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" /> Carregando empresa…
      </p>
    );
  }

  // Admin de PLATAFORMA sem membership cai aqui: `activeCompany` é nulo porque
  // ele não é membro de empresa alguma. O papel de plataforma não administra
  // funcionários de ninguém — a RPC recusaria a listagem de qualquer forma.
  if (!companyId) {
    return (
      <EstadoAviso
        titulo="Nenhuma empresa vinculada"
        texto="Sua conta não possui vínculo ativo com uma empresa. O painel de Funcionários pertence a uma empresa: peça ao proprietário para adicioná-lo, ou crie a sua no onboarding."
      />
    );
  }

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 font-display text-3xl font-bold">
            <UserCog className="h-7 w-7 text-gold" /> Funcionários
          </h1>
          <p className="text-sm text-muted-foreground">
            Equipe de{" "}
            <span className="font-semibold">{activeCompany?.companyName ?? "sua empresa"}</span>.
            {isCompanyAdmin
              ? " Você administra esta empresa e pode convidar vendedores."
              : " Somente o proprietário ou um administrador pode convidar novas pessoas."}
          </p>
        </div>
        {isCompanyAdmin && (
          <button
            onClick={() => setModalAberto(true)}
            className="inline-flex items-center gap-2 rounded-xl bg-gold px-4 py-2.5 text-sm font-semibold text-gold-foreground transition hover:opacity-90"
          >
            <UserPlus className="h-4 w-4" /> Adicionar vendedor
          </button>
        )}
      </div>

      {error ? (
        <EstadoAviso
          titulo="Não foi possível carregar a equipe"
          texto={(error as Error).message ?? "Tente novamente em instantes."}
        />
      ) : isLoading ? (
        <p className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Carregando equipe…
        </p>
      ) : membros.length === 0 ? (
        <div className="rounded-2xl border border-border bg-card p-10 text-center">
          <p className="font-semibold">Não há funcionários cadastrados.</p>
          {isCompanyAdmin && (
            <p className="mt-1 text-sm text-muted-foreground">
              Adicione o primeiro vendedor da empresa.
            </p>
          )}
        </div>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-border bg-card">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-semibold">Nome</th>
                {isCompanyAdmin && <th className="px-4 py-3 font-semibold">E-mail</th>}
                <th className="px-4 py-3 font-semibold">Papel</th>
                <th className="px-4 py-3 font-semibold">Situação</th>
                <th className="px-4 py-3 font-semibold">Desde</th>
              </tr>
            </thead>
            <tbody>
              {membros.map((m) => (
                <LinhaMembro key={m.user_id} membro={m} mostrarEmail={isCompanyAdmin} />
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modalAberto && companyId && (
        <ModalAdicionarVendedor companyId={companyId} onFechar={() => setModalAberto(false)} />
      )}
    </div>
  );
}

function LinhaMembro({
  membro,
  mostrarEmail,
}: {
  membro: CompanyMemberRow;
  mostrarEmail: boolean;
}) {
  const pendente = membro.convite_pendente === true;
  return (
    <tr className="border-b border-border/60 last:border-0">
      <td className="px-4 py-3">
        <span className="font-semibold">{membro.nome ?? "Sem nome"}</span>
      </td>
      {mostrarEmail && <td className="px-4 py-3 text-muted-foreground">{membro.email ?? "—"}</td>}
      <td className="px-4 py-3">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-gold/15 px-2.5 py-0.5 text-xs font-semibold text-gold">
          {membro.role === "owner" && <ShieldCheck className="h-3 w-3" />}
          {ROLE_LABEL[membro.role] ?? membro.role}
        </span>
      </td>
      <td className="px-4 py-3">
        <span
          className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${
            membro.status === "active"
              ? "bg-emerald-500/15 text-emerald-500"
              : "bg-destructive/15 text-destructive"
          }`}
        >
          {STATUS_LABEL[membro.status] ?? membro.status}
        </span>
        {pendente && (
          <span className="ml-2 rounded-full bg-amber-500/15 px-2.5 py-0.5 text-xs font-semibold text-amber-500">
            Convite pendente
          </span>
        )}
      </td>
      <td className="px-4 py-3 text-muted-foreground">
        {new Date(membro.created_at).toLocaleDateString("pt-BR")}
      </td>
    </tr>
  );
}

function EstadoAviso({ titulo, texto }: { titulo: string; texto: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-8 text-center">
      <p className="font-semibold">{titulo}</p>
      <p className="mx-auto mt-1 max-w-lg text-sm text-muted-foreground">{texto}</p>
    </div>
  );
}

/**
 * Nome e e-mail, nada mais.
 *
 * Não há campo de senha (o vendedor define a dele pelo link do convite), nem de
 * empresa, papel, status ou permissões: todos são decididos no servidor. Mesmo
 * que este formulário mandasse `role`, a Edge Function ignoraria — ela não tem
 * parâmetro de papel.
 */
function ModalAdicionarVendedor({
  companyId,
  onFechar,
}: {
  companyId: string;
  onFechar: () => void;
}) {
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const invite = useInviteSeller(companyId);

  const enviar = async (e: React.FormEvent) => {
    e.preventDefault();
    if (invite.isPending) return;
    setErro(null);

    const n = nome.trim();
    const m = email.trim().toLowerCase();
    if (n.length < 2) return setErro("Informe o nome do vendedor.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(m)) return setErro("Informe um e-mail válido.");

    try {
      const resultado = await invite.mutateAsync({ name: n, email: m });
      if (resultado === "already_member") {
        toast.info("Este usuário já faz parte da empresa.");
      } else if (resultado === "linked") {
        toast.success("Usuário já cadastrado na plataforma foi adicionado como vendedor.");
      } else if (resultado === "pending_acceptance") {
        toast.success(
          "Convite pendente criado. A pessoa precisa aceitar ao entrar na conta (e-mail de aviso enviado se o Resend estiver configurado).",
        );
      } else if (resultado === "pending_already") {
        toast.info("Já existe um convite pendente para este usuário nesta empresa.");
      } else {
        toast.success("Convite enviado. O vendedor define a própria senha pelo e-mail.");
      }
      onFechar();
    } catch (e: unknown) {
      setErro(mensagemDoErro(e) ?? "Não foi possível enviar o convite.");
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-xl">
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 className="font-display text-xl font-bold">Adicionar vendedor</h2>
            <p className="text-sm text-muted-foreground">
              Enviamos um convite por e-mail. Você não cria nem vê a senha dele.
            </p>
          </div>
          <button
            onClick={onFechar}
            aria-label="Fechar"
            className="rounded-lg p-1.5 hover:bg-muted"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={enviar} className="space-y-4">
          <div>
            <label className="mb-1 block text-sm font-medium">Nome</label>
            <input
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              required
              autoFocus
              maxLength={120}
              placeholder="Ex.: Maria Silva"
              className="w-full rounded-xl border border-input bg-background px-3 py-2 outline-none focus:border-primary"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium">E-mail</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                maxLength={160}
                placeholder="vendedor@empresa.com"
                className="w-full rounded-xl border border-input bg-background py-2 pl-9 pr-3 outline-none focus:border-primary"
              />
            </div>
          </div>

          <p className="rounded-lg bg-muted/50 px-3 py-2 text-xs text-muted-foreground">
            A pessoa entra como <strong>Vendedor</strong>. O papel é definido pelo servidor e não
            pode ser alterado por este formulário.
          </p>

          {erro && (
            <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-600 dark:text-red-300">
              {erro}
            </p>
          )}

          <div className="flex gap-2">
            <button
              type="button"
              onClick={onFechar}
              className="flex-1 rounded-xl border border-border px-4 py-2.5 text-sm font-semibold hover:bg-muted"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={invite.isPending}
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-gold px-4 py-2.5 text-sm font-semibold text-gold-foreground transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {invite.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Enviando…
                </>
              ) : (
                "Enviar convite"
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
