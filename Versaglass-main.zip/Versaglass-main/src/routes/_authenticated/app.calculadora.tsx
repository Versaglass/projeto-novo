import { createFileRoute, redirect } from "@tanstack/react-router";

/**
 * REDIRECT — `/app/calculadora` → `/app/venda-direta`.
 *
 * A tela viva é `app.venda-direta.tsx`. Este arquivo existe SÓ para não quebrar
 * quem tem o caminho antigo salvo.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * POR QUE ELE PRECISA CONTINUAR EXISTINDO
 * ────────────────────────────────────────────────────────────────────────────
 * O nome "calculadora" foi o da rota desde o início e circulou por três portas
 * (menu, Dashboard e o "Voltar" do Estoque). Duas foram atualizadas na Revisão
 * 89; a terceira — `app.estoque.tsx:227` — ficou apontando para cá **de
 * propósito**, porque aquela rodada não podia tocar o módulo de Estoque. É este
 * redirect que faz o botão "Voltar" continuar funcionando.
 *
 * 📌 Também cobre o que NÃO dá para varrer com `grep`: favorito no navegador,
 * link colado num WhatsApp, aba aberta há dias. Apagar a rota faria tudo isso
 * cair num 404.
 *
 * `beforeLoad` redireciona ANTES de montar componente — não há tela em branco
 * nem piscar de conteúdo no meio do caminho. `replace: true` troca a entrada no
 * histórico em vez de empilhar, senão o "voltar" do navegador devolveria o
 * usuário ao caminho antigo e ele redirecionaria de novo, num laço visível.
 *
 * ⚠️ Ao remover este arquivo um dia: conferir antes que `app.estoque.tsx` não
 * aponte mais para `/app/calculadora`.
 */
export const Route = createFileRoute("/_authenticated/app/calculadora")({
  beforeLoad: () => {
    throw redirect({ to: "/app/venda-direta", replace: true });
  },
});
