import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Bot,
  CheckCircle2,
  Link2,
  LockKeyhole,
  PlugZap,
  RefreshCw,
  SearchCheck,
  ShieldCheck,
  Wrench,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/use-auth";
import {
  INTEGRATION_PROVIDERS,
  buildIntegrationConfigurePlan,
  buildIntegrationSyncPlan,
  runIntegrationsDiagnosis,
  type IntegrationCategory,
} from "@/lib/integration-architect";
import {
  buildIAActionPlan,
  confirmAdminPassword,
  executeIAAction,
  saveIACommand,
  type IAActionPlan,
} from "@/lib/ia-intelligence";
import { supabase } from "@/integrations/supabase/client";
import { requireAdmin } from "@/lib/admin-guard";
import { mensagemDoErro } from "@/lib/erro-mensagem";

export const Route = createFileRoute("/_authenticated/app/integracoes")({
  beforeLoad: requireAdmin,
  component: IntegracoesPage,
});

const categories: { id: IntegrationCategory | "all"; label: string }[] = [
  { id: "all", label: "Todas" },
  { id: "marketplace", label: "Marketplace" },
  { id: "payments", label: "Pagamentos" },
  { id: "fiscal", label: "Fiscal" },
  { id: "whatsapp", label: "WhatsApp" },
  { id: "google", label: "Google" },
  { id: "email", label: "E-mail" },
  { id: "api", label: "APIs" },
  { id: "backup", label: "Backup" },
];

function IntegracoesPage() {
  const { isAdmin, user } = useAuth();
  const [category, setCategory] = useState<IntegrationCategory | "all">("all");
  const [selected, setSelected] = useState(INTEGRATION_PROVIDERS[0]?.id || "");
  const [command, setCommand] = useState("Diagnosticar integrações e corrigir webhooks com erro");
  const [plan, setPlan] = useState<IAActionPlan | null>(null);
  const [password, setPassword] = useState("");
  const [running, setRunning] = useState(false);
  const [diagnosis, setDiagnosis] = useState<any>(null);

  const visibleProviders = useMemo(() => {
    return category === "all"
      ? INTEGRATION_PROVIDERS
      : INTEGRATION_PROVIDERS.filter((p) => p.category === category);
  }, [category]);
  const provider = INTEGRATION_PROVIDERS.find((p) => p.id === selected) || INTEGRATION_PROVIDERS[0];

  if (!isAdmin) {
    return (
      <div className="rounded-2xl border bg-card p-8 text-center">
        <LockKeyhole className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
        <h1 className="text-2xl font-bold">Acesso restrito</h1>
        <p className="mt-2 text-muted-foreground">
          O Centro de Integrações Inteligentes aparece somente para ADM.
        </p>
      </div>
    );
  }

  function prepareConfigure() {
    if (!provider) return;
    const values: Record<string, any> = {};
    provider.requiredFields.forEach((field) => {
      const el = document.getElementById(`field-${field.key}`) as HTMLInputElement | null;
      if (el?.value) values[field.key] = el.value;
    });
    setPlan(buildIntegrationConfigurePlan(provider.id, values));
    toast.info("Prévia de configuração criada. Confirme com senha ADM para salvar.");
  }

  function prepareSync() {
    if (!provider) return;
    setPlan(
      buildIntegrationSyncPlan(
        provider.id,
        provider.capabilities.slice(0, 3).map((item) => item.toLowerCase()),
      ) as IAActionPlan,
    );
    toast.info("Prévia de sincronização criada.");
  }

  function prepareCommand() {
    if (!command.trim()) return toast.error("Digite um comando para a IA Intelligence.");
    setPlan(buildIAActionPlan(command));
  }

  async function runDiagnosisNow() {
    if (!user?.id) return;
    setRunning(true);
    try {
      const result = await runIntegrationsDiagnosis(user.id);
      setDiagnosis(result);
      toast.success(`Diagnóstico concluído: ${result.findings.length} achado(s).`);
    } catch (error: unknown) {
      toast.error(mensagemDoErro(error) || "Não foi possível diagnosticar integrações.");
    } finally {
      setRunning(false);
    }
  }

  async function confirmPlan() {
    if (!plan || !user?.id || !user?.email) return;
    if (!password) return toast.error("Digite a senha ADM para confirmar.");
    setRunning(true);
    try {
      await confirmAdminPassword(user.email, password);
      const commandId = await saveIACommand(user.id, plan.summary, plan);
      await supabase.from("ai_intelligence_approvals" as any).insert({
        command_id: commandId,
        user_id: user.id,
        approved: true,
        approved_at: new Date().toISOString(),
      });
      await executeIAAction(plan, user.id, commandId);
      toast.success("Ação de integração registrada/executada com segurança.");
      setPassword("");
      setPlan(null);
    } catch (error: unknown) {
      toast.error(mensagemDoErro(error) || "Não foi possível executar a ação.");
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="space-y-6">
      <section className="rounded-3xl border bg-sidebar p-8 text-sidebar-foreground shadow-xl">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <h1 className="flex items-center gap-3 text-3xl font-bold">
              <PlugZap className="text-gold" /> Centro de Integrações Inteligentes
            </h1>
            <p className="mt-3 max-w-3xl text-sidebar-foreground/80">
              A IA Intelligence configura, testa, diagnostica e corrige integrações com
              marketplaces, pagamentos, fiscal, WhatsApp, Google, e-mail, APIs e backups. Toda
              alteração exige senha ADM.
            </p>
          </div>
          <button
            onClick={runDiagnosisNow}
            disabled={running}
            className="inline-flex items-center gap-2 rounded-xl bg-gold px-5 py-3 font-semibold text-gold-foreground hover:opacity-90 disabled:opacity-60"
          >
            <SearchCheck className="h-5 w-5" /> Verificar Integrações
          </button>
        </div>
      </section>

      <div className="grid gap-4 md:grid-cols-4">
        <Card icon={<Link2 />} title="Conectar" text="Configuração guiada por provedor." />
        <Card
          icon={<SearchCheck />}
          title="Diagnosticar"
          text="Tokens, webhooks, permissões e erros."
        />
        <Card icon={<Wrench />} title="Corrigir" text="Recriar webhooks e registrar reparos." />
        <Card
          icon={<RefreshCw />}
          title="Sincronizar"
          text="Produtos, estoque, pedidos e clientes."
        />
      </div>

      <section className="grid gap-6 xl:grid-cols-[1.2fr_.8fr]">
        <div className="rounded-2xl border bg-card p-5">
          <div className="mb-4 flex flex-wrap gap-2">
            {categories.map((item) => (
              <button
                key={item.id}
                onClick={() => setCategory(item.id)}
                className={`rounded-full px-4 py-2 text-sm ${category === item.id ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80"}`}
              >
                {item.label}
              </button>
            ))}
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            {visibleProviders.map((item) => (
              <button
                key={item.id}
                onClick={() => setSelected(item.id)}
                className={`rounded-2xl border p-4 text-left transition hover:border-primary ${selected === item.id ? "border-primary bg-primary/5" : "bg-background"}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-bold">{item.name}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{item.description}</p>
                  </div>
                  <span className="rounded-full bg-muted px-2 py-1 text-[11px] uppercase">
                    {item.category}
                  </span>
                </div>
                <div className="mt-3 flex flex-wrap gap-1">
                  {item.capabilities.map((cap) => (
                    <span
                      key={cap}
                      className="rounded-full bg-primary/10 px-2 py-1 text-xs text-primary"
                    >
                      {cap}
                    </span>
                  ))}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-2xl border bg-card p-5">
            <h2 className="text-xl font-bold">{provider?.name}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{provider?.description}</p>
            <div className="mt-4 space-y-3">
              {provider?.requiredFields.map((field) => (
                <label key={field.key} className="block">
                  <span className="mb-1 block text-sm font-medium">{field.label}</span>
                  <input
                    id={`field-${field.key}`}
                    type={field.type === "password" ? "password" : field.type || "text"}
                    className="w-full rounded-xl border bg-background px-3 py-2 outline-none focus:border-primary"
                    placeholder={field.label}
                  />
                </label>
              ))}
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <button
                onClick={prepareConfigure}
                className="rounded-xl bg-primary px-4 py-2 font-semibold text-primary-foreground"
              >
                Configurar com IA
              </button>
              <button
                onClick={prepareSync}
                className="rounded-xl bg-muted px-4 py-2 font-semibold hover:bg-muted/80"
              >
                Sincronizar
              </button>
            </div>
          </div>

          <div className="rounded-2xl border bg-card p-5">
            <h2 className="flex items-center gap-2 text-xl font-bold">
              <Bot /> Comando para IA Intelligence
            </h2>
            <textarea
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              rows={3}
              className="mt-3 w-full rounded-xl border bg-background p-3 outline-none focus:border-primary"
            />
            <button
              onClick={prepareCommand}
              className="mt-3 rounded-xl bg-primary px-4 py-2 font-semibold text-primary-foreground hover:opacity-90"
            >
              Gerar prévia
            </button>
          </div>
        </div>
      </section>

      {diagnosis && (
        <section className="rounded-2xl border bg-card p-5">
          <div className="mb-4 flex items-center justify-between gap-3">
            <h2 className="text-xl font-bold">Diagnóstico das Integrações</h2>
            <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-sm font-semibold text-emerald-600">
              Score {diagnosis.score}%
            </span>
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            {diagnosis.findings.map((finding: any) => (
              <div key={finding.id} className="rounded-xl border bg-background p-4">
                <b>{finding.title}</b>
                <p className="mt-1 text-sm text-muted-foreground">{finding.problem}</p>
                <p className="mt-2 text-sm">
                  <b>Solução:</b> {finding.solution}
                </p>
                <button
                  onClick={() => {
                    setCommand(finding.suggestedCommand);
                    setPlan(buildIAActionPlan(finding.suggestedCommand));
                  }}
                  className="mt-3 rounded-lg bg-primary/10 px-3 py-2 text-sm font-semibold text-primary"
                >
                  Resolver com IA
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {plan && (
        <section className="rounded-2xl border border-orange-400/40 bg-orange-500/10 p-5">
          <h2 className="flex items-center gap-2 text-xl font-bold">
            <ShieldCheck /> Confirmação ADM obrigatória
          </h2>
          <div className="mt-3 rounded-xl bg-background p-4">
            <h3 className="font-bold">{plan.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{plan.summary}</p>
            <pre className="mt-3 max-h-56 overflow-auto rounded-xl bg-muted p-3 text-xs text-foreground">
              {JSON.stringify(plan.payload, null, 2)}
            </pre>
          </div>
          <div className="mt-4 flex flex-col gap-2 sm:flex-row">
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              type="password"
              className="flex-1 rounded-xl border bg-background px-3 py-2 outline-none focus:border-primary"
              placeholder="Senha ADM"
            />
            <button
              onClick={confirmPlan}
              disabled={running}
              className="rounded-xl bg-orange-600 px-5 py-2 font-semibold text-white hover:bg-orange-700 disabled:opacity-60"
            >
              Confirmar e executar
            </button>
          </div>
        </section>
      )}
    </div>
  );
}

function Card({ icon, title, text }: any) {
  return (
    <div className="rounded-2xl border bg-card p-5">
      <div className="mb-3 text-primary">{icon}</div>
      <h3 className="font-bold">{title}</h3>
      <p className="mt-1 text-sm text-muted-foreground">{text}</p>
    </div>
  );
}
