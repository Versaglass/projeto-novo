import { createFileRoute } from "@tanstack/react-router";
import { IAIntelligencePanel } from "@/components/ia/IAIntelligencePanel";
import { useAuth } from "@/hooks/use-auth";
import { Bot, ShieldCheck, LockKeyhole, Database, RotateCcw, Wrench } from "lucide-react";
import { requireAdmin } from "@/lib/admin-guard";
import {
  AI_ADMIN_DISABLED_MESSAGE,
  AI_ADMIN_EXECUTION_ENABLED,
} from "@/modules/ai-intelligence/config";

export const Route = createFileRoute("/_authenticated/app/ia-intelligence")({
  beforeLoad: requireAdmin,
  component: IAIntelligencePage,
});

function IAIntelligencePage() {
  const { isAdmin } = useAuth();
  if (!isAdmin) {
    return (
      <div className="rounded-2xl border bg-card p-8 text-center">
        <LockKeyhole className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
        <h1 className="text-2xl font-bold">Acesso restrito</h1>
        <p className="mt-2 text-muted-foreground">A IA Intelligence aparece somente para ADM.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {!AI_ADMIN_EXECUTION_ENABLED && (
        <div className="flex items-start gap-3 rounded-2xl border border-amber-500/30 bg-amber-500/10 p-5 text-amber-900 dark:text-amber-100">
          <Wrench className="mt-0.5 h-5 w-5 flex-shrink-0" />
          <div>
            <p className="font-semibold">{AI_ADMIN_DISABLED_MESSAGE}</p>
            <p className="mt-1 text-sm opacity-80">
              A orientação da IA e a prévia das ações continuam disponíveis, mas nenhuma alteração é
              aplicada. Os exemplos abaixo são ilustrativos.
            </p>
          </div>
        </div>
      )}

      <div className="rounded-3xl border bg-sidebar p-8 text-sidebar-foreground shadow-xl">
        <div className="flex items-start justify-between gap-6">
          <div>
            <h1 className="flex items-center gap-3 text-3xl font-bold">
              <Bot className="text-gold" /> IA Intelligence
            </h1>
            <p className="mt-3 max-w-3xl text-sidebar-foreground/80">
              Central administrativa com permissão total controlada. Ela pode alterar produtos,
              estoque, templates, financeiro, módulos, categorias e configurações, sempre com
              comando explícito e senha do ADM em toda execução.
            </p>
          </div>
          <span className="rounded-full border border-gold/30 bg-gold/10 px-4 py-2 text-sm text-gold">
            ADM
          </span>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card
          icon={<ShieldCheck />}
          title="Confirmação obrigatória"
          text="Nada é executado sem prévia e senha do ADM."
        />
        <Card
          icon={<Database />}
          title="Permissão total"
          text="Opera em qualquer módulo respeitando RLS e multiempresa."
        />
        <Card
          icon={<RotateCcw />}
          title="Snapshots"
          text="Salva versão anterior para restauração quando possível."
        />
        <Card
          icon={<LockKeyhole />}
          title="Usuário comum oculto"
          text="Funcionários e usuários comuns não visualizam esta IA."
        />
      </div>

      <div className="rounded-2xl border bg-card p-6">
        <h2 className="text-xl font-bold">Como usar</h2>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <Example text="Adicionar produto nome: Espelho Orgânico 160x70, preço: 799, categoria: Espelhos, estoque: 0" />
          <Example text="Alterar template da tela de login para destacar vidraçaria, serralheria, marcenaria e marmoraria" />
          {/* Revisão 38 — o exemplo anterior era `tabela: company_products`,
              que NUNCA existiu no schema (Revisão 37): a tela ensinava o
              administrador a mandar uma operação fadada a 404. A tabela real de
              catálogo/estoque é `inventory_items`, e o campo de preço de venda
              chama-se `preco_venda` — nomes conferidos no módulo Estoque. */}
          <Example
            text={
              'Modo avançado: tabela: inventory_items; operação: update; json: {"id":"UUID","preco_venda":899}'
            }
          />
          <Example text="Fazer inventário do estoque de alumínios e registrar divergências encontradas" />
        </div>
      </div>

      <IAIntelligencePanel />
    </div>
  );
}

function Card({ icon, title, text }: any) {
  return (
    <div className="rounded-2xl border bg-card p-5">
      <div className="mb-3 text-primary">{icon}</div>
      <h3 className="font-bold">{title}</h3>
      <p className="mt-1 text-sm text-muted-foreground">{text}</p>
    </div>
  );
}
function Example({ text }: { text: string }) {
  return (
    <div className="rounded-xl bg-muted p-4 text-sm">
      <b>Exemplo:</b>
      <br />
      {text}
    </div>
  );
}
