import { createFileRoute, Link, useNavigate, type SearchSchemaInput } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  AlertTriangle,
  Building2,
  ClipboardList,
  Copy,
  Download,
  Edit,
  Filter,
  FileText,
  Loader2,
  Plus,
  Search,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import { useCompany } from "@/contexts/company-context";
import { useCompanyCustomerOptions } from "@/hooks/use-quotes";
import {
  SERVICE_ORDER_SEGMENTS,
  SERVICE_ORDER_STAGES,
  SERVICE_ORDER_STATUSES,
  buildServiceOrderInputFromQuote,
  formatOsNumero,
  segmentLabel,
  serviceOrderErrorMessage,
  stageLabel,
  stageTone,
  statusLabel,
  statusTone,
  useCreateServiceOrder,
  useDeleteServiceOrder,
  useServiceOrders,
  useUpdateServiceOrder,
  type QuoteForServiceOrder,
  type QuoteItemForServiceOrder,
  type ServiceOrderInput,
  type ServiceOrderRow,
  type ServiceOrderSegment,
  type ServiceOrderStage,
  type ServiceOrderStatus,
} from "@/hooks/use-service-orders";
import { brl, dateBR } from "@/lib/format";
import { validaNumeroCampo } from "@/lib/numero-campo";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";

type OrdensServicoSearchInput = {
  quote?: string;
  os?: string;
} & SearchSchemaInput;

type OrdensServicoSearch = {
  quote?: string;
  os?: string;
};

export function searchOrdensServico(valores: OrdensServicoSearch): OrdensServicoSearch {
  const saida: OrdensServicoSearch = {};
  if (typeof valores.quote === "string" && valores.quote.trim()) saida.quote = valores.quote.trim();
  if (typeof valores.os === "string" && valores.os.trim()) saida.os = valores.os.trim();
  return saida;
}

export const Route = createFileRoute("/_authenticated/app/ordens-servico")({
  // Oculta para contas normais e Super Admin — menu removido; URL direta → /app.
  beforeLoad: hiddenRouteBeforeLoad,
  validateSearch: (search: OrdensServicoSearchInput): OrdensServicoSearch =>
    searchOrdensServico({ quote: search.quote, os: search.os }),
  component: OrdensServicoPage,
});

const MANAGER_ROLES = ["owner", "admin", "manager"];

type FormState = {
  id: string | null;
  titulo: string;
  segmento: ServiceOrderSegment;
  etapa: ServiceOrderStage;
  status: ServiceOrderStatus;
  responsavel: string;
  data_medicao: string;
  data_instalacao: string;
  valor: string;
  custo: string;
  observacoes: string;
  customer_id: string;
  quote_id: string;
};

function blankForm(): FormState {
  return {
    id: null,
    titulo: "",
    segmento: "vidracaria",
    etapa: "orcamento",
    status: "ativo",
    responsavel: "",
    data_medicao: "",
    data_instalacao: "",
    valor: "",
    custo: "",
    observacoes: "",
    customer_id: "",
    quote_id: "",
  };
}

function inputToForm(input: ServiceOrderInput): FormState {
  return {
    id: null,
    titulo: input.titulo,
    segmento: input.segmento,
    etapa: input.etapa,
    status: input.status,
    responsavel: input.responsavel ?? "",
    data_medicao: input.data_medicao ?? "",
    data_instalacao: input.data_instalacao ?? "",
    valor: input.valor ? String(input.valor).replace(".", ",") : "",
    custo: input.custo ? String(input.custo).replace(".", ",") : "",
    observacoes: input.observacoes ?? "",
    customer_id: input.customer_id ?? "",
    quote_id: input.quote_id ?? "",
  };
}

function rowToForm(row: ServiceOrderRow): FormState {
  return {
    id: row.id,
    titulo: row.titulo,
    segmento: row.segmento,
    etapa: row.etapa,
    status: row.status,
    responsavel: row.responsavel ?? "",
    data_medicao: row.data_medicao ?? "",
    data_instalacao: row.data_instalacao ?? "",
    valor: row.valor ? String(row.valor).replace(".", ",") : "",
    custo: row.custo ? String(row.custo).replace(".", ",") : "",
    observacoes: row.observacoes ?? "",
    customer_id: row.customer_id ?? "",
    quote_id: row.quote_id ?? "",
  };
}

function parseForm(
  form: FormState,
): { ok: true; value: ServiceOrderInput } | { ok: false; erro: string } {
  const titulo = form.titulo.trim();
  if (!titulo) return { ok: false, erro: "Informe o cliente ou a obra." };

  const valor = validaNumeroCampo(form.valor, { label: "valor", min: 0, casas: 2 });
  if (!valor.ok) return { ok: false, erro: valor.erro };

  const custo = validaNumeroCampo(form.custo, { label: "custo", min: 0, casas: 2 });
  if (!custo.ok) return { ok: false, erro: custo.erro };

  return {
    ok: true,
    value: {
      titulo,
      segmento: form.segmento,
      etapa: form.etapa,
      status: form.status,
      responsavel: form.responsavel.trim() || null,
      data_medicao: form.data_medicao || null,
      data_instalacao: form.data_instalacao || null,
      valor: form.valor.trim() === "" ? 0 : valor.valor,
      custo: form.custo.trim() === "" ? 0 : custo.valor,
      observacoes: form.observacoes.trim() || null,
      customer_id: form.customer_id || null,
      quote_id: form.quote_id || null,
    },
  };
}

function OrdensServicoPage() {
  const navigate = useNavigate();
  const { quote: quoteParam, os: osParam } = Route.useSearch();
  const urlConsumida = useRef(false);
  const { isAdmin } = useAuth();
  const { companyRole } = useCompany();
  const canEdit = isAdmin || MANAGER_ROLES.includes(companyRole ?? "");

  const {
    data: ordens = [],
    isLoading,
    isError,
    refetch,
    hasActiveCompany,
    companyId,
  } = useServiceOrders();
  const { data: clientes = [] } = useCompanyCustomerOptions();
  const createOs = useCreateServiceOrder();
  const updateOs = useUpdateServiceOrder();
  const deleteOs = useDeleteServiceOrder();

  const [query, setQuery] = useState("");
  const [etapaFiltro, setEtapaFiltro] = useState("Todas");
  const [form, setForm] = useState<FormState | null>(null);
  const [salvando, setSalvando] = useState(false);

  const { data: quoteSeed, isLoading: carregandoQuote } = useQuery({
    queryKey: ["service-order-quote-seed", companyId, quoteParam],
    enabled: !!companyId && !!quoteParam,
    queryFn: async () => {
      const { data: quote, error } = await supabase
        .from("quotes")
        .select(
          "id,numero,total,observacoes,etapa,instalacao_em,customer_id,customer:customers(nome)",
        )
        .eq("id", quoteParam!)
        .eq("company_id", companyId!)
        .maybeSingle();
      if (error) throw error;
      if (!quote) return null;
      const { data: items } = await supabase
        .from("quote_items")
        .select("descricao,project_data,tipo_projeto")
        .eq("quote_id", quoteParam!)
        .order("ordem");
      const customerRaw = quote.customer as { nome: string } | { nome: string }[] | null;
      const customer = Array.isArray(customerRaw) ? (customerRaw[0] ?? null) : customerRaw;
      return {
        quote: {
          id: quote.id,
          numero: quote.numero,
          total: Number(quote.total),
          observacoes: quote.observacoes,
          etapa: quote.etapa,
          instalacao_em: quote.instalacao_em,
          customer_id: quote.customer_id,
          customer: customer ? { nome: customer.nome } : null,
        } satisfies QuoteForServiceOrder,
        items: (items ?? []) as QuoteItemForServiceOrder[],
      };
    },
  });

  useEffect(() => {
    if (urlConsumida.current) return;

    if (osParam && ordens.length > 0) {
      const alvo = ordens.find((o) => o.id === osParam);
      if (alvo) {
        setForm(rowToForm(alvo));
        urlConsumida.current = true;
        navigate({ to: "/app/ordens-servico", search: {}, replace: true });
      }
      return;
    }

    if (quoteParam && quoteSeed === null && !carregandoQuote) {
      toast.error("Orçamento não encontrado na empresa ativa.");
      urlConsumida.current = true;
      navigate({ to: "/app/ordens-servico", search: {}, replace: true });
      return;
    }

    if (quoteParam && quoteSeed) {
      setForm(inputToForm(buildServiceOrderInputFromQuote(quoteSeed.quote, quoteSeed.items)));
      urlConsumida.current = true;
      navigate({ to: "/app/ordens-servico", search: {}, replace: true });
    }
  }, [osParam, quoteParam, ordens, quoteSeed, carregandoQuote, navigate]);

  const etapasFiltro = useMemo(() => ["Todas", ...SERVICE_ORDER_STAGES.map((s) => s.label)], []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return ordens.filter((os) => {
      const etapaOk = etapaFiltro === "Todas" || stageLabel(os.etapa) === etapaFiltro;
      if (!etapaOk) return false;
      if (!q) return true;
      const blob = [
        formatOsNumero(os.numero),
        os.titulo,
        os.responsavel,
        os.customer?.nome,
        segmentLabel(os.segmento),
        stageLabel(os.etapa),
        statusLabel(os.status),
        os.observacoes,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return blob.includes(q);
    });
  }, [ordens, query, etapaFiltro]);

  const resumo = useMemo(() => {
    const ativas = ordens.filter((o) => o.status === "ativo" || o.status === "atrasado");
    const valorTotal = ativas.reduce((acc, o) => acc + o.valor, 0);
    return { total: ordens.length, ativas: ativas.length, valorTotal };
  }, [ordens]);

  const abrirNova = () => setForm(blankForm());
  const abrirEdicao = (row: ServiceOrderRow) => setForm(rowToForm(row));

  const salvar = async () => {
    if (!form) return;
    const parsed = parseForm(form);
    if (!parsed.ok) return toast.error(parsed.erro);

    setSalvando(true);
    try {
      if (form.id) {
        await updateOs.mutateAsync({ id: form.id, input: parsed.value });
        toast.success("Ordem de serviço atualizada.");
      } else {
        await createOs.mutateAsync(parsed.value);
        toast.success("Ordem de serviço criada.");
      }
      setForm(null);
    } catch (e) {
      console.error("[ordens-servico] falha ao salvar", e);
      toast.error(serviceOrderErrorMessage(e));
    } finally {
      setSalvando(false);
    }
  };

  const excluir = async (row: ServiceOrderRow) => {
    if (!canEdit) return toast.error("Sem permissão para excluir.");
    if (
      !window.confirm(
        `Excluir a ordem ${formatOsNumero(row.numero)} (${row.titulo})? Esta ação não pode ser desfeita.`,
      )
    ) {
      return;
    }
    try {
      await deleteOs.mutateAsync(row.id);
      if (form?.id === row.id) setForm(null);
      toast.success("Ordem de serviço removida.");
    } catch (e) {
      console.error("[ordens-servico] falha ao excluir", e);
      toast.error(serviceOrderErrorMessage(e));
    }
  };

  const duplicar = (row: ServiceOrderRow) => {
    if (!canEdit) return toast.error("Sem permissão para duplicar.");
    setForm({
      ...rowToForm(row),
      id: null,
      titulo: `${row.titulo} (cópia)`,
    });
  };

  const exportCsv = () => {
    const headers = [
      "numero",
      "titulo",
      "segmento",
      "etapa",
      "status",
      "responsavel",
      "data_medicao",
      "data_instalacao",
      "valor",
      "custo",
      "cliente",
      "observacoes",
    ];
    const rows = [
      headers.join(";"),
      ...ordens.map((os) =>
        [
          formatOsNumero(os.numero),
          os.titulo,
          segmentLabel(os.segmento),
          stageLabel(os.etapa),
          statusLabel(os.status),
          os.responsavel ?? "",
          os.data_medicao ?? "",
          os.data_instalacao ?? "",
          os.valor,
          os.custo,
          os.customer?.nome ?? "",
          os.observacoes ?? "",
        ]
          .map((v) => `"${String(v).replaceAll('"', '""')}"`)
          .join(";"),
      ),
    ];
    const blob = new Blob([rows.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "ordens-servico.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <Badge variant="secondary" className="mb-3">
            Produção
          </Badge>
          <h1 className="font-display text-3xl font-bold">Ordens de Serviço</h1>
          <p className="mt-2 max-w-3xl text-sm text-muted-foreground">
            Controle por etapas: orçamento, medição, produção, corte, instalação, finalizado e pago.
            Os registros ficam salvos na empresa ativa.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={exportCsv} disabled={!ordens.length} className="gap-2">
            <Download className="h-4 w-4" /> Exportar CSV
          </Button>
          <Button onClick={abrirNova} disabled={!canEdit || !hasActiveCompany} className="gap-2">
            <Plus className="h-4 w-4" /> Nova OS
          </Button>
        </div>
      </div>

      {hasActiveCompany && ordens.length > 0 && (
        <div className="grid gap-3 sm:grid-cols-3">
          <Card>
            <CardContent className="p-4">
              <p className="text-xs uppercase tracking-wider text-muted-foreground">Total</p>
              <p className="font-display text-2xl font-bold">{resumo.total}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-xs uppercase tracking-wider text-muted-foreground">Em andamento</p>
              <p className="font-display text-2xl font-bold">{resumo.ativas}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-xs uppercase tracking-wider text-muted-foreground">
                Valor (ativas)
              </p>
              <p className="font-display text-2xl font-bold">{brl(resumo.valorTotal)}</p>
            </CardContent>
          </Card>
        </div>
      )}

      {!hasActiveCompany ? (
        <Card>
          <CardContent className="flex flex-col items-center p-12 text-center">
            <Building2 className="h-10 w-10 text-muted-foreground" />
            <p className="mt-3 text-sm text-muted-foreground">
              Selecione ou crie uma empresa para gerenciar ordens de serviço.
            </p>
          </CardContent>
        </Card>
      ) : isLoading || (quoteParam && carregandoQuote && !urlConsumida.current) ? (
        <p className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Carregando ordens de serviço…
        </p>
      ) : isError ? (
        <Card className="border-destructive/30 bg-destructive/5">
          <CardContent className="flex flex-col items-center p-8 text-center">
            <AlertTriangle className="h-8 w-8 text-destructive" />
            <p className="mt-3 text-sm text-muted-foreground">
              Não foi possível carregar as ordens de serviço.
            </p>
            <Button variant="outline" onClick={() => refetch()} className="mt-4">
              Tentar novamente
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <Card>
            <CardContent className="grid gap-3 p-4 md:grid-cols-[1fr_260px]">
              <div className="relative">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Buscar por OS, cliente, obra, responsável ou segmento"
                  className="pl-9"
                />
              </div>
              <Select value={etapaFiltro} onValueChange={setEtapaFiltro}>
                <SelectTrigger>
                  <Filter className="mr-2 h-4 w-4" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {etapasFiltro.map((e) => (
                    <SelectItem key={e} value={e}>
                      {e}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {form && (
            <Card className="border-gold/50">
              <CardHeader>
                <CardTitle>
                  {form.id ? "Editar ordem de serviço" : "Nova ordem de serviço"}
                </CardTitle>
                {form.quote_id && (
                  <p className="text-xs text-muted-foreground">
                    Vinculada ao{" "}
                    <Link
                      to="/app/orcamentos/$id"
                      params={{ id: form.quote_id }}
                      className="font-semibold text-primary hover:underline"
                    >
                      orçamento de origem
                    </Link>
                  </p>
                )}
              </CardHeader>
              <CardContent className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                <label className="md:col-span-2 xl:col-span-3">
                  <span className="mb-1 block text-xs font-medium text-muted-foreground">
                    Cliente / Obra
                  </span>
                  <Input
                    value={form.titulo}
                    onChange={(e) => setForm({ ...form, titulo: e.target.value })}
                    placeholder="Ex.: Box banheiro — cliente Silva"
                  />
                </label>

                <label>
                  <span className="mb-1 block text-xs font-medium text-muted-foreground">
                    Cliente cadastrado
                  </span>
                  <Select
                    value={form.customer_id || "__none__"}
                    onValueChange={(v) =>
                      setForm({ ...form, customer_id: v === "__none__" ? "" : v })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Opcional" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none__">Nenhum</SelectItem>
                      {clientes.map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.nome}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </label>

                <label>
                  <span className="mb-1 block text-xs font-medium text-muted-foreground">
                    Segmento
                  </span>
                  <Select
                    value={form.segmento}
                    onValueChange={(v) => setForm({ ...form, segmento: v as ServiceOrderSegment })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SERVICE_ORDER_SEGMENTS.map((s) => (
                        <SelectItem key={s.value} value={s.value}>
                          {s.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </label>

                <label>
                  <span className="mb-1 block text-xs font-medium text-muted-foreground">
                    Etapa
                  </span>
                  <Select
                    value={form.etapa}
                    onValueChange={(v) => setForm({ ...form, etapa: v as ServiceOrderStage })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SERVICE_ORDER_STAGES.map((s) => (
                        <SelectItem key={s.value} value={s.value}>
                          {s.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </label>

                <label>
                  <span className="mb-1 block text-xs font-medium text-muted-foreground">
                    Status
                  </span>
                  <Select
                    value={form.status}
                    onValueChange={(v) => setForm({ ...form, status: v as ServiceOrderStatus })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SERVICE_ORDER_STATUSES.map((s) => (
                        <SelectItem key={s.value} value={s.value}>
                          {s.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </label>

                <label>
                  <span className="mb-1 block text-xs font-medium text-muted-foreground">
                    Responsável
                  </span>
                  <Input
                    value={form.responsavel}
                    onChange={(e) => setForm({ ...form, responsavel: e.target.value })}
                  />
                </label>

                <label>
                  <span className="mb-1 block text-xs font-medium text-muted-foreground">
                    Data medição
                  </span>
                  <Input
                    type="date"
                    value={form.data_medicao}
                    onChange={(e) => setForm({ ...form, data_medicao: e.target.value })}
                  />
                </label>

                <label>
                  <span className="mb-1 block text-xs font-medium text-muted-foreground">
                    Data instalação
                  </span>
                  <Input
                    type="date"
                    value={form.data_instalacao}
                    onChange={(e) => setForm({ ...form, data_instalacao: e.target.value })}
                  />
                </label>

                <label>
                  <span className="mb-1 block text-xs font-medium text-muted-foreground">
                    Valor
                  </span>
                  <Input
                    type="text"
                    inputMode="decimal"
                    placeholder="Ex.: 1.200,00"
                    value={form.valor}
                    onChange={(e) => setForm({ ...form, valor: e.target.value })}
                  />
                </label>

                <label>
                  <span className="mb-1 block text-xs font-medium text-muted-foreground">
                    Custo
                  </span>
                  <Input
                    type="text"
                    inputMode="decimal"
                    placeholder="Ex.: 720,00"
                    value={form.custo}
                    onChange={(e) => setForm({ ...form, custo: e.target.value })}
                  />
                </label>

                <label className="md:col-span-2 xl:col-span-3">
                  <span className="mb-1 block text-xs font-medium text-muted-foreground">
                    Observações
                  </span>
                  <Textarea
                    value={form.observacoes}
                    onChange={(e) => setForm({ ...form, observacoes: e.target.value })}
                  />
                </label>

                <div className="flex gap-2 md:col-span-2 xl:col-span-3">
                  <Button onClick={salvar} disabled={salvando || !canEdit}>
                    {salvando ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Salvando…
                      </>
                    ) : (
                      "Salvar"
                    )}
                  </Button>
                  <Button variant="outline" onClick={() => setForm(null)}>
                    Cancelar
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {filtered.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center p-12 text-center">
                <ClipboardList className="h-10 w-10 text-muted-foreground" />
                <p className="mt-3 text-sm text-muted-foreground">
                  {ordens.length === 0
                    ? "Nenhuma ordem de serviço cadastrada ainda."
                    : "Nenhuma ordem encontrada com esses filtros."}
                </p>
                {ordens.length === 0 && canEdit && (
                  <Button onClick={abrirNova} className="mt-4 gap-2">
                    <Plus className="h-4 w-4" /> Criar a primeira OS
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <Tabs defaultValue="cards" className="space-y-4">
              <TabsList>
                <TabsTrigger value="cards">Cards</TabsTrigger>
                <TabsTrigger value="table">Tabela</TabsTrigger>
              </TabsList>

              <TabsContent value="cards" className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                {filtered.map((os) => (
                  <Card key={os.id}>
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                            {formatOsNumero(os.numero)}
                          </p>
                          <CardTitle className="text-base">{os.titulo}</CardTitle>
                          {os.customer?.nome && (
                            <p className="mt-1 text-xs text-muted-foreground">{os.customer.nome}</p>
                          )}
                          {os.quote_id && (
                            <Link
                              to="/app/orcamentos/$id"
                              params={{ id: os.quote_id }}
                              className="mt-1 inline-flex items-center gap-1 text-xs text-primary hover:underline"
                              onClick={(e) => e.stopPropagation()}
                            >
                              <FileText className="h-3 w-3" /> Orçamento vinculado
                            </Link>
                          )}
                        </div>
                        <span
                          className={`rounded-full px-2 py-0.5 text-xs ${statusTone(os.status)}`}
                        >
                          {statusLabel(os.status)}
                        </span>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3 text-sm">
                      <div className="flex flex-wrap gap-2">
                        <span className="rounded-full bg-muted px-2 py-0.5 text-xs">
                          {segmentLabel(os.segmento)}
                        </span>
                        <span className={`rounded-full px-2 py-0.5 text-xs ${stageTone(os.etapa)}`}>
                          {stageLabel(os.etapa)}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                        <div>
                          <span className="block uppercase tracking-wider">Responsável</span>
                          <span className="text-foreground">{os.responsavel || "—"}</span>
                        </div>
                        <div>
                          <span className="block uppercase tracking-wider">Instalação</span>
                          <span className="text-foreground">
                            {os.data_instalacao ? dateBR(os.data_instalacao) : "—"}
                          </span>
                        </div>
                        <div>
                          <span className="block uppercase tracking-wider">Valor</span>
                          <span className="font-display font-semibold text-foreground">
                            {brl(os.valor)}
                          </span>
                        </div>
                        <div>
                          <span className="block uppercase tracking-wider">Custo</span>
                          <span className="text-foreground">{brl(os.custo)}</span>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-1"
                          disabled={!canEdit}
                          onClick={() => abrirEdicao(os)}
                        >
                          <Edit className="h-3.5 w-3.5" /> Editar
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-1"
                          disabled={!canEdit}
                          onClick={() => duplicar(os)}
                        >
                          <Copy className="h-3.5 w-3.5" /> Duplicar
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-1 text-destructive hover:text-destructive"
                          disabled={!canEdit}
                          onClick={() => excluir(os)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="table">
                <div className="overflow-x-auto rounded-2xl border bg-card">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>OS</TableHead>
                        <TableHead>Cliente / Obra</TableHead>
                        <TableHead>Segmento</TableHead>
                        <TableHead>Etapa</TableHead>
                        <TableHead>Responsável</TableHead>
                        <TableHead>Instalação</TableHead>
                        <TableHead className="text-right">Valor</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filtered.map((os) => (
                        <TableRow key={os.id}>
                          <TableCell className="font-semibold">
                            {formatOsNumero(os.numero)}
                          </TableCell>
                          <TableCell>
                            <div>{os.titulo}</div>
                            {os.customer?.nome && (
                              <div className="text-xs text-muted-foreground">
                                {os.customer.nome}
                              </div>
                            )}
                            {os.quote_id && (
                              <Link
                                to="/app/orcamentos/$id"
                                params={{ id: os.quote_id }}
                                className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                              >
                                <FileText className="h-3 w-3" /> Orçamento
                              </Link>
                            )}
                          </TableCell>
                          <TableCell>{segmentLabel(os.segmento)}</TableCell>
                          <TableCell>
                            <span
                              className={`rounded-full px-2 py-0.5 text-xs ${stageTone(os.etapa)}`}
                            >
                              {stageLabel(os.etapa)}
                            </span>
                          </TableCell>
                          <TableCell>{os.responsavel || "—"}</TableCell>
                          <TableCell>
                            {os.data_instalacao ? dateBR(os.data_instalacao) : "—"}
                          </TableCell>
                          <TableCell className="text-right font-display font-semibold">
                            {brl(os.valor)}
                          </TableCell>
                          <TableCell>
                            <span
                              className={`rounded-full px-2 py-0.5 text-xs ${statusTone(os.status)}`}
                            >
                              {statusLabel(os.status)}
                            </span>
                          </TableCell>
                          <TableCell>
                            <div className="flex justify-end gap-1">
                              <Button
                                size="icon"
                                variant="outline"
                                className="h-8 w-8"
                                disabled={!canEdit}
                                onClick={() => abrirEdicao(os)}
                                title="Editar"
                              >
                                <Edit className="h-3.5 w-3.5" />
                              </Button>
                              <Button
                                size="icon"
                                variant="outline"
                                className="h-8 w-8"
                                disabled={!canEdit}
                                onClick={() => duplicar(os)}
                                title="Duplicar"
                              >
                                <Copy className="h-3.5 w-3.5" />
                              </Button>
                              <Button
                                size="icon"
                                variant="outline"
                                className="h-8 w-8 text-destructive hover:text-destructive"
                                disabled={!canEdit}
                                onClick={() => excluir(os)}
                                title="Excluir"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
            </Tabs>
          )}
        </>
      )}
    </div>
  );
}
