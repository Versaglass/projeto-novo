import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import {
  Bell,
  CheckCheck,
  Trash2,
  UserPlus,
  LogIn,
  AlertTriangle,
  CreditCard,
  type LucideIcon,
} from "lucide-react";
import { toast } from "sonner";
import { requireAdmin } from "@/lib/admin-guard";

export const Route = createFileRoute("/_authenticated/app/admin/notificacoes")({
  beforeLoad: requireAdmin,
  component: NotificacoesPage,
});

type EventKind = "signup" | "login_success" | "login_error" | "payment" | "subscription_created";

type AuthEvent = {
  id: string;
  kind: EventKind;
  email: string | null;
  user_id: string | null;
  user_agent: string | null;
  metadata: Record<string, unknown> | null;
  read_at: string | null;
  created_at: string;
};

const KIND_META: Record<EventKind, { label: string; icon: LucideIcon; tone: string }> = {
  signup: { label: "Novo cadastro", icon: UserPlus, tone: "bg-emerald-500/15 text-emerald-700" },
  login_success: { label: "Login realizado", icon: LogIn, tone: "bg-primary/15 text-primary" },
  login_error: {
    label: "Erro de login",
    icon: AlertTriangle,
    tone: "bg-destructive/15 text-destructive",
  },
  payment: { label: "Pagamento", icon: CreditCard, tone: "bg-gold/20 text-gold" },
  subscription_created: {
    label: "Nova assinatura",
    icon: CreditCard,
    tone: "bg-gold/20 text-gold",
  },
};

function NotificacoesPage() {
  const { isAdmin, loading: authLoading } = useAuth();
  const [events, setEvents] = useState<AuthEvent[]>([]);
  const [filter, setFilter] = useState<"all" | EventKind>("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (authLoading) return;
    if (!isAdmin) return;
    load();
    const ch = supabase
      .channel("auth_events")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "auth_events" },
        (payload) => {
          const ev = payload.new as AuthEvent;
          setEvents((cur) => [ev, ...cur]);
          const meta = KIND_META[ev.kind];
          toast.info(`${meta.label}: ${ev.email ?? "—"}`);
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [authLoading, isAdmin]);

  async function load() {
    setLoading(true);
    const { data, error } = await supabase
      .from("auth_events")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) toast.error(error.message);
    setEvents((data as AuthEvent[]) ?? []);
    setLoading(false);
  }

  async function markAllRead() {
    const ids = events.filter((e) => !e.read_at).map((e) => e.id);
    if (!ids.length) return;
    const { error } = await supabase
      .from("auth_events")
      .update({ read_at: new Date().toISOString() })
      .in("id", ids);
    if (error) return toast.error(error.message);
    setEvents((cur) =>
      cur.map((e) => (ids.includes(e.id) ? { ...e, read_at: new Date().toISOString() } : e)),
    );
    toast.success("Marcadas como lidas");
  }

  async function remove(id: string) {
    const { error } = await supabase.from("auth_events").delete().eq("id", id);
    if (error) return toast.error(error.message);
    setEvents((cur) => cur.filter((e) => e.id !== id));
  }

  if (!authLoading && !isAdmin) {
    return null;
  }

  const visible = filter === "all" ? events : events.filter((e) => e.kind === filter);
  const unread = events.filter((e) => !e.read_at).length;

  const counts = {
    all: events.length,
    signup: events.filter((e) => e.kind === "signup").length,
    login_success: events.filter((e) => e.kind === "login_success").length,
    login_error: events.filter((e) => e.kind === "login_error").length,
    payment: events.filter((e) => e.kind === "payment").length,
    subscription_created: events.filter((e) => e.kind === "subscription_created").length,
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="font-display text-3xl font-bold flex items-center gap-3">
            <Bell className="h-7 w-7 text-gold" />
            Notificações
            {unread > 0 && (
              <span className="inline-flex items-center justify-center rounded-full bg-destructive px-2.5 py-0.5 text-xs font-semibold text-destructive-foreground">
                {unread} nova{unread > 1 ? "s" : ""}
              </span>
            )}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Cadastros, logins, erros e pagamentos em tempo real.
          </p>
        </div>
        <button
          onClick={markAllRead}
          disabled={!unread}
          className="inline-flex items-center gap-2 rounded-lg border border-input bg-background px-3 py-2 text-sm hover:bg-accent disabled:opacity-50"
        >
          <CheckCheck className="h-4 w-4" /> Marcar todas como lidas
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {(
          [
            ["all", "Todas"],
            ["signup", "Cadastros"],
            ["login_success", "Logins"],
            ["login_error", "Erros de login"],
            ["subscription_created", "Assinaturas"],
            ["payment", "Pagamentos"],
          ] as const
        ).map(([k, label]) => (
          <button
            key={k}
            onClick={() => setFilter(k)}
            className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${
              filter === k
                ? "bg-foreground text-background"
                : "bg-muted text-muted-foreground hover:bg-accent"
            }`}
          >
            {label} <span className="opacity-60">({counts[k as keyof typeof counts]})</span>
          </button>
        ))}
      </div>

      <div className="rounded-xl border bg-card">
        {loading ? (
          <div className="p-6 text-sm text-muted-foreground">Carregando…</div>
        ) : visible.length === 0 ? (
          <div className="p-10 text-center text-sm text-muted-foreground">
            Nenhum evento ainda. Assim que houver atividade, aparecerá aqui em tempo real.
          </div>
        ) : (
          <ul className="divide-y">
            {visible.map((e) => {
              const meta = KIND_META[e.kind];
              const Icon = meta.icon;
              const unreadRow = !e.read_at;
              return (
                <li
                  key={e.id}
                  className={`flex items-start gap-3 p-4 ${unreadRow ? "bg-muted/30" : ""}`}
                >
                  <div
                    className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg ${meta.tone}`}
                  >
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold">{meta.label}</span>
                      {unreadRow && <span className="h-1.5 w-1.5 rounded-full bg-destructive" />}
                      <span className="text-xs text-muted-foreground">
                        {new Date(e.created_at).toLocaleString("pt-BR")}
                      </span>
                    </div>
                    <div className="text-sm mt-0.5 truncate">{e.email ?? "—"}</div>
                    {e.metadata && Object.keys(e.metadata).length > 0 && (
                      <div className="text-xs text-muted-foreground mt-1 truncate">
                        {Object.entries(e.metadata)
                          .map(([k, v]) => `${k}: ${String(v)}`)
                          .join(" · ")}
                      </div>
                    )}
                    {e.user_agent && (
                      <div className="text-[10px] text-muted-foreground/70 mt-1 truncate">
                        {e.user_agent}
                      </div>
                    )}
                  </div>
                  <button
                    onClick={() => remove(e.id)}
                    className="rounded-md p-2 text-muted-foreground hover:bg-accent hover:text-destructive"
                    aria-label="Apagar"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
