import { createFileRoute, Link } from "@tanstack/react-router";
import {
  MapPin,
  Camera,
  CalendarDays,
  Users,
  ClipboardList,
  DollarSign,
  FileText,
} from "lucide-react";
import {
  EnterpriseCrudPage,
  type CrudItem,
  type FieldConfig,
} from "@/components/EnterpriseCrudPage";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";

export const Route = createFileRoute("/_authenticated/app/obras")({
  // Removido do menu das contas normais — mock localStorage (Rev. 227 style).
  beforeLoad: hiddenRouteBeforeLoad,
  component: ObrasPage,
});

const fields: FieldConfig[] = [
  { key: "codigo", label: "Código" },
  { key: "cliente", label: "Cliente" },
  { key: "endereco", label: "Endereço" },
  { key: "maps_url", label: "Localização/Maps" },
  { key: "responsavel", label: "Responsável" },
  { key: "equipe", label: "Equipe" },
  { key: "inicio", label: "Início" },
  { key: "previsao", label: "Previsão" },
  {
    key: "status",
    label: "Status",
    type: "select",
    options: [
      "Orçamento",
      "Aprovada",
      "Medição",
      "Produção",
      "Instalação",
      "Concluída",
      "Garantia",
    ],
  },
  { key: "orcamento", label: "Orçamento/OS" },
  { key: "materiais", label: "Materiais usados", type: "textarea" },
  { key: "custo", label: "Custo", type: "currency" },
  { key: "valor", label: "Valor", type: "currency" },
  { key: "lucro", label: "Lucro", type: "currency" },
  { key: "fotos_antes", label: "Fotos antes" },
  { key: "fotos_depois", label: "Fotos depois" },
  { key: "observacoes", label: "Observações", type: "textarea" },
];
const data: CrudItem[] = [
  {
    id: "obra1",
    codigo: "OBR-001",
    cliente: "Cliente exemplo",
    endereco: "Guarapari - ES",
    responsavel: "Equipe 1",
    equipe: "Instalador A",
    inicio: "2026-07-02",
    previsao: "2026-07-05",
    status: "Instalação",
    orcamento: "ORC-001",
    custo: 850,
    valor: 1650,
    lucro: 800,
  },
];
const actions = [
  { label: "Localização", icon: MapPin },
  { label: "Fotos", icon: Camera },
  { label: "Agenda", icon: CalendarDays },
  { label: "Equipe", icon: Users },
  { label: "OS", icon: ClipboardList },
  { label: "Financeiro", icon: DollarSign },
  { label: "Relatórios", icon: FileText },
];
function ObrasPage() {
  return (
    <div className="space-y-5">
      <div className="grid gap-3 md:grid-cols-4">
        {actions.map(({ label, icon: Icon }) => (
          <Link
            key={label}
            to="/app/obras"
            className="rounded-2xl border bg-card p-4 hover:border-gold/50"
          >
            <Icon className="mb-2 h-6 w-6 text-gold" />
            <b>{label}</b>
            <p className="text-xs text-muted-foreground">Acesso rápido da obra</p>
          </Link>
        ))}
      </div>
      <EnterpriseCrudPage
        title="Central de Obras"
        badge="Produção e instalação"
        subtitle="Controle completo por obra com endereço, fotos, cronograma, equipe, materiais, gastos, lucro e garantia."
        storageKey="vmm_obras"
        initialData={data}
        fields={fields}
        highlight={["codigo", "cliente", "status", "previsao", "valor", "lucro"]}
      />
    </div>
  );
}
