import { createFileRoute, Link } from "@tanstack/react-router";
import { Mail, Phone, ShieldCheck } from "lucide-react";
import { requireAdmin } from "@/lib/admin-guard";

export const Route = createFileRoute("/_authenticated/app/admin/acesso-seguro")({
  beforeLoad: requireAdmin,
  component: SecureAccessAdminPage,
});

function SecureAccessAdminPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-black">Segurança de Acesso</h1>
        {/* O texto citava "Primeira senha" quando havia o cartão correspondente.
            Com ele fora (Revisão 74), a menção viraria promessa sem botão — o
            mesmo defeito que as Revisões 37-44 limparam do Dashboard. */}
        <p className="text-muted-foreground">
          Recuperação segura de senha e códigos em dois fatores para ações administrativas.
        </p>
      </div>
      {/* Eram TRÊS cartões: o primeiro levava a /first-password e foi removido
          na Revisão 74, junto com o link equivalente da tela de login. A rota
          continua existindo, só sem link — ver o comentário em AuthPage.tsx.

          A grade passou de `md:grid-cols-3` para `md:grid-cols-2` porque com
          dois cartões numa grade de três colunas sobraria um vão à direita. */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card
          icon={<Mail />}
          title="Recuperar por e-mail"
          text="Código por e-mail antes da troca de senha."
          to="/forgot-password-2fa"
        />
        <Card
          icon={<Phone />}
          title="Recuperar por celular"
          text="Código por SMS/WhatsApp, conforme provedor configurado no Supabase."
          to="/forgot-password-2fa"
        />
      </div>
      <div className="rounded-2xl border bg-card p-5 shadow-sm">
        <h2 className="mb-3 flex items-center gap-2 text-xl font-bold">
          <ShieldCheck className="text-emerald-500" /> Regras implementadas
        </h2>
        <ul className="list-disc space-y-2 pl-5 text-sm text-muted-foreground">
          <li>A IA Intelligence nunca visualiza senha em texto puro.</li>
          <li>Códigos são enviados pelo provedor de autenticação configurado.</li>
          <li>Senha forte obrigatória: 8 caracteres, maiúscula, minúscula, número e símbolo.</li>
          <li>
            Eventos de segurança são registrados em <code>security_events</code>.
          </li>
          <li>Tabelas preparadas para auditoria, bloqueio temporário e tentativas.</li>
        </ul>
      </div>
    </div>
  );
}

function Card({ icon, title, text, to }: any) {
  return (
    <Link
      to={to}
      className="rounded-2xl border bg-card p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
    >
      <div className="mb-3 text-primary">{icon}</div>
      <h2 className="text-lg font-bold">{title}</h2>
      <p className="mt-2 text-sm text-muted-foreground">{text}</p>
    </Link>
  );
}
