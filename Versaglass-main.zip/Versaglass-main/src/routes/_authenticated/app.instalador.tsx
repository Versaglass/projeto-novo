import { createFileRoute } from "@tanstack/react-router";
import { CheckSquare, Camera, MapPin, Signature, PackageCheck } from "lucide-react";
import {
  EnterpriseCrudPage,
  type CrudItem,
  type FieldConfig,
} from "@/components/EnterpriseCrudPage";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";

export const Route = createFileRoute("/_authenticated/app/instalador")({
  // Removido do menu das contas normais — mock localStorage, sem fluxo real por role.
  beforeLoad: hiddenRouteBeforeLoad,
  component: InstaladorPage,
});
const fields: FieldConfig[] = [
  { key: "os", label: "OS" },
  { key: "cliente", label: "Cliente" },
  { key: "endereco", label: "Endereço" },
  { key: "materiais", label: "Materiais", type: "textarea" },
  { key: "checklist", label: "Checklist", type: "textarea" },
  { key: "fotos", label: "Fotos da instalação" },
  { key: "assinatura", label: "Assinatura do cliente" },
  {
    key: "status",
    label: "Status",
    type: "select",
    options: ["Pendente", "Em rota", "Instalando", "Finalizado", "Garantia"],
  },
  { key: "observacoes", label: "Observações", type: "textarea" },
];
const data: CrudItem[] = [
  {
    id: "inst1",
    os: "OS-001",
    cliente: "Cliente exemplo",
    endereco: "Guarapari - ES",
    materiais: "Vidro temperado 8mm; roldanas; silicone",
    status: "Pendente",
  },
];
function InstaladorPage() {
  return (
    <div className="space-y-5">
      <div className="grid gap-3 md:grid-cols-5">
        {(
          [
            [CheckSquare, "Checklist"],
            [PackageCheck, "Materiais"],
            [Camera, "Fotos"],
            [MapPin, "Rota"],
            [Signature, "Assinatura"],
          ] as const
        ).map(([Icon, label]) => (
          <div key={label} className="rounded-2xl border bg-card p-4">
            <Icon className="mb-2 h-6 w-6 text-gold" />
            <b>{label}</b>
          </div>
        ))}
      </div>
      <EnterpriseCrudPage
        title="App do Instalador"
        badge="Operação de campo"
        subtitle="Tela simplificada para instalador ver rota, materiais, projeto, checklist, fotos e assinatura, sem acesso financeiro."
        storageKey="vmm_instalador"
        initialData={data}
        fields={fields}
        highlight={["os", "cliente", "endereco", "status"]}
      />
    </div>
  );
}
