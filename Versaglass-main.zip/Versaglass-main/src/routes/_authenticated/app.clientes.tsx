import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  Plus,
  Search,
  User,
  Phone,
  Mail,
  Pencil,
  Trash2,
  AlertTriangle,
  Building2,
} from "lucide-react";
import { toast } from "sonner";
import {
  useClients,
  useCreateClient,
  useUpdateClient,
  useDeleteClient,
  toClientInput,
  clientErrorMessage,
  type Client,
} from "@/hooks/use-clients";
import {
  CustomerDialog,
  type CustomerFormValues,
} from "@/components/customers/CustomerDialog";

export const Route = createFileRoute("/_authenticated/app/clientes")({
  component: ClientesPage,
});

function ClientesPage() {
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Client | null>(null);
  const [confirmDel, setConfirmDel] = useState<Client | null>(null);

  const { data: clientes = [], isLoading, isError, refetch, hasActiveCompany } = useClients(search);
  const create = useCreateClient();
  const update = useUpdateClient();
  const remove = useDeleteClient();

  const onCreate = (v: CustomerFormValues) =>
    create.mutate(toClientInput(v), {
      onSuccess: () => {
        toast.success("Cliente cadastrado");
        setOpen(false);
      },
      onError: (e) => toast.error(e instanceof Error ? e.message : clientErrorMessage(e)),
    });

  const onUpdate = (id: string, v: CustomerFormValues) =>
    update.mutate(
      { id, input: toClientInput(v) },
      {
        onSuccess: () => {
          toast.success("Cliente atualizado");
          setEditing(null);
        },
        onError: (e) => toast.error(e instanceof Error ? e.message : clientErrorMessage(e)),
      },
    );

  const onDelete = (id: string) =>
    remove.mutate(id, {
      onSuccess: () => {
        toast.success("Cliente removido");
        setConfirmDel(null);
      },
      onError: (e) => toast.error(clientErrorMessage(e)),
    });

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Clientes</h1>
          <p className="text-sm text-muted-foreground">
            {hasActiveCompany ? `${clientes.length} cadastrados` : "Nenhuma empresa ativa"}
          </p>
        </div>
        <button
          onClick={() => setOpen(true)}
          disabled={!hasActiveCompany}
          className="inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-4 py-2.5 text-sm font-semibold text-gold-foreground shadow-glow hover:opacity-95 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <Plus className="h-4 w-4" /> Novo cliente
        </button>
      </div>

      <div className="mb-4 flex items-center gap-2 rounded-lg border bg-card px-3 py-2">
        <Search className="h-4 w-4 text-muted-foreground" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar por nome, documento ou e-mail..."
          disabled={!hasActiveCompany}
          className="flex-1 bg-transparent text-sm outline-none disabled:cursor-not-allowed"
        />
      </div>

      {!hasActiveCompany ? (
        <div className="rounded-2xl border bg-card p-12 text-center">
          <Building2 className="mx-auto h-10 w-10 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">
            Selecione ou crie uma empresa para gerenciar seus clientes.
          </p>
        </div>
      ) : isLoading ? (
        <p className="text-muted-foreground">Carregando...</p>
      ) : isError ? (
        <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-8 text-center">
          <AlertTriangle className="mx-auto h-8 w-8 text-destructive" />
          <p className="mt-3 text-sm text-muted-foreground">
            NÃ£o foi possÃ­vel carregar os clientes.
          </p>
          <button
            onClick={() => refetch()}
            className="mt-4 rounded-lg border border-input px-4 py-2 text-sm font-medium hover:bg-accent"
          >
            Tentar novamente
          </button>
        </div>
      ) : clientes.length === 0 ? (
        <div className="rounded-2xl border bg-card p-12 text-center">
          <User className="mx-auto h-10 w-10 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">
            {search
              ? "Nenhum cliente encontrado para a busca."
              : "Nenhum cliente ainda. Cadastre o primeiro."}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
          {clientes.map((c) => (
            <div
              key={c.id}
              className="group relative rounded-2xl border bg-card p-5 transition hover:shadow-elegant"
            >
              <Link to="/app/clientes/$id" params={{ id: c.id }} className="block">
                <div className="flex items-start justify-between">
                  <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
                    <User className="h-5 w-5" />
                  </div>
                  {c.documento && (
                    <span className="text-xs text-muted-foreground">{c.documento}</span>
                  )}
                </div>
                <h3 className="mt-3 pr-16 font-semibold">{c.nome}</h3>
                <div className="mt-2 space-y-1 text-xs text-muted-foreground">
                  {c.telefone && (
                    <div className="flex items-center gap-1.5">
                      <Phone className="h-3 w-3" /> {c.telefone}
                    </div>
                  )}
                  {c.email && (
                    <div className="flex items-center gap-1.5">
                      <Mail className="h-3 w-3" /> {c.email}
                    </div>
                  )}
                </div>
              </Link>
              <div className="absolute right-3 top-3 flex gap-1 opacity-0 transition group-hover:opacity-100">
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setEditing(c);
                  }}
                  title="Editar"
                  className="grid h-8 w-8 place-items-center rounded-lg border bg-background text-muted-foreground hover:text-foreground"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setConfirmDel(c);
                  }}
                  title="Excluir"
                  className="grid h-8 w-8 place-items-center rounded-lg border bg-background text-destructive hover:bg-destructive hover:text-destructive-foreground"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {open && (
        <CustomerDialog
          title="Novo cliente"
          submitLabel="Cadastrar"
          onClose={() => setOpen(false)}
          onSubmit={onCreate}
          loading={create.isPending}
        />
      )}
      {editing && (
        <CustomerDialog
          title="Editar cliente"
          submitLabel="Salvar"
          initial={editing}
          onClose={() => setEditing(null)}
          onSubmit={(v) => onUpdate(editing.id, v)}
          loading={update.isPending}
        />
      )}
      {confirmDel && (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4"
          onClick={() => setConfirmDel(null)}
        >
          <div
            className="w-full max-w-sm rounded-2xl bg-card p-6 shadow-elegant"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="font-display text-lg font-bold">Excluir cliente?</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Tem certeza que deseja excluir <strong>{confirmDel.nome}</strong>? Esta aÃ§Ã£o nÃ£o pode
              ser desfeita.
            </p>
            <div className="mt-4 flex justify-end gap-2">
              <button
                onClick={() => setConfirmDel(null)}
                className="rounded-lg border border-input px-4 py-2 text-sm"
              >
                Cancelar
              </button>
              <button
                onClick={() => onDelete(confirmDel.id)}
                disabled={remove.isPending}
                className="rounded-lg bg-destructive px-4 py-2 text-sm font-semibold text-destructive-foreground disabled:cursor-not-allowed disabled:opacity-50"
              >
                {remove.isPending ? "Excluindo..." : "Excluir"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
