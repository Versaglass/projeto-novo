import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Bot, WandSparkles, Ruler, FileText } from "lucide-react";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";

/** ROTA OCULTA (Revisão 227) — IA Projetos. Código preservado; acesso bloqueado. */
export const Route = createFileRoute("/_authenticated/app/ia-projetos")({
  beforeLoad: hiddenRouteBeforeLoad,
  component: IaProjetosPage,
});
function IaProjetosPage() {
  const [prompt, setPrompt] = useState(
    "Porta de vidro 1200x2100, temperado 10mm, puxador H e fechadura central",
  );
  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-3xl font-bold">IA para criar projetos</h1>
        <p className="text-muted-foreground">
          Descreva o projeto e o sistema prepara desenho 2D/3D, materiais, orçamento e PDF técnico.
        </p>
      </div>
      <div className="rounded-2xl border bg-card p-5">
        <label className="text-sm font-semibold">Descrição do projeto</label>
        <textarea
          className="mt-2 min-h-32 w-full rounded-xl border bg-background p-3"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
        />
        <div className="mt-4 grid gap-3 md:grid-cols-4">
          {[
            [Bot, "Interpretar"],
            [WandSparkles, "Gerar 2D/3D"],
            [Ruler, "Lista de corte"],
            [FileText, "PDF/Orçamento"],
          ].map(([Icon, label]: any) => (
            <button key={label} className="rounded-xl border p-4 text-left hover:border-gold/50">
              <Icon className="mb-2 h-5 w-5 text-gold" />
              <b>{label}</b>
            </button>
          ))}
        </div>
      </div>
      <div className="rounded-2xl border bg-card p-5">
        <h2 className="font-bold">Prévia técnica</h2>
        <p className="text-sm text-muted-foreground">
          Módulo preparado para integrar com a IA do projeto. A saída deve salvar JSON paramétrico,
          SVG, lista de materiais e orçamento vinculado.
        </p>
        <pre className="mt-3 overflow-auto rounded-xl bg-muted p-3 text-xs">
          {JSON.stringify(
            {
              entrada: prompt,
              saidas: ["desenho_2d", "modelo_3d", "lista_materiais", "orcamento", "pdf_tecnico"],
            },
            null,
            2,
          )}
        </pre>
      </div>
    </div>
  );
}
