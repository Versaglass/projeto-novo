import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState, type ReactNode } from "react";
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, XAxis, YAxis } from "recharts";
import {
  BadgeDollarSign,
  BarChart3,
  Building2,
  CalendarDays,
  ChartPie,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Plus,
  ReceiptText,
  Trash2,
  Pencil,
  TrendingDown,
  TrendingUp,
  UserRound,
  Wallet,
  CheckCircle2,
} from "lucide-react";
import { toast } from "sonner";
import {
  CHARGE_STATUS_META,
  EXPENSE_CATEGORIES,
  PERSONAL_EXPENSE_CATEGORIES,
  currentMonthPeriod,
  expenseCategoryLabel,
  financeErrorMessage,
  periodForMonth,
  useApprovedQuoteOptions,
  useCharges,
  useCreateExpense,
  useCreateManualCharge,
  useDeleteExpense,
  useFinanceCashflow,
  useFinanceSummary,
  useMarkChargePaid,
  useOperationalExpenses,
  usePersonalExpenses,
  useUpdateExpense,
  useUpdateManualCharge,
  type ChargeRow,
  type ChargeStatus,
  type ExpenseCategory,
  type ExpenseCategoryAny,
  type ExpenseKind,
  type ExpenseRow,
  type FinancePeriod,
  type PersonalExpenseCategory,
} from "@/hooks/use-finance";
import { useCompanyCustomerOptions } from "@/hooks/use-quotes";
import { useCompany } from "@/contexts/company-context";
import {
  ChartContainer,
  ChartLegend,
  ChartLegendContent,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart";

export const Route = createFileRoute("/_authenticated/app/financeiro")({
  component: FinanceiroPage,
});

type TabKey = "resumo" | "despesas" | "cobrancas" | "pessoais";

type NavCardDef = {
  key: TabKey;
  label: string;
  desc: string;
  icon: ReactNode;
  tab: TabKey;
};

const NAV_RESUMO: NavCardDef = {
  key: "resumo",
  label: "Resumo",
  desc: "caixa, lucro e gráficos",
  icon: <BarChart3 className="h-7 w-7" />,
  tab: "resumo",
};

const NAV_DESPESAS: NavCardDef = {
  key: "despesas",
  label: "Despesas",
  desc: "saídas operacionais",
  icon: <TrendingDown className="h-7 w-7" />,
  tab: "despesas",
};

const NAV_COBRANCAS: NavCardDef = {
  key: "cobrancas",
  label: "Cobranças",
  desc: "contas a receber",
  icon: <BadgeDollarSign className="h-7 w-7" />,
  tab: "cobrancas",
};

const NAV_PESSOAIS: NavCardDef = {
  key: "pessoais",
  label: "Gastos pessoais",
  desc: "retiradas do dono",
  icon: <UserRound className="h-7 w-7" />,
  tab: "pessoais",
};

// Revisão 228 — cartão "Notas fiscais" removido: /app/fiscal está oculta (Rev. 227).

function brl(n: number) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(n || 0);
}

function formatMonthLabel(year: number, month: number) {
  return new Intl.DateTimeFormat("pt-BR", { month: "long", year: "numeric" }).format(
    new Date(year, month, 1),
  );
}

function formatDate(iso: string) {
  if (!iso) return "—";
  return new Intl.DateTimeFormat("pt-BR").format(new Date(iso.includes("T") ? iso : `${iso}T12:00:00`));
}

function categoryLabel(row: ExpenseRow) {
  return expenseCategoryLabel(row.expense_kind, row.category);
}

function FinanceiroPage() {
  const { isCompanyAdmin } = useCompany();
  const [tab, setTab] = useState<TabKey>("resumo");
  const now = new Date();
  const [monthYear, setMonthYear] = useState({ year: now.getFullYear(), month: now.getMonth() });

  const navCards = useMemo((): NavCardDef[] => {
    const cards: NavCardDef[] = [NAV_RESUMO, NAV_DESPESAS, NAV_COBRANCAS];
    if (isCompanyAdmin) cards.push(NAV_PESSOAIS);
    return cards;
  }, [isCompanyAdmin]);

  // 4 cartões (admin) em fileira no desktop; 3 cartões (seller) em três colunas — Rev. 228.
  const navGridClass =
    navCards.length === 4 ? "grid-cols-2 lg:grid-cols-4" : "grid-cols-2 sm:grid-cols-3";

  const period = useMemo(
    () => periodForMonth(monthYear.year, monthYear.month),
    [monthYear.year, monthYear.month],
  );

  const shiftMonth = (delta: number) => {
    setMonthYear((prev) => {
      const d = new Date(prev.year, prev.month + delta, 1);
      return { year: d.getFullYear(), month: d.getMonth() };
    });
  };

  const handleNavClick = (card: NavCardDef) => {
    setTab(card.tab);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold">Financeiro</h1>
          <p className="text-sm text-muted-foreground">
            Faturamento de orçamentos, caixa recebido e despesas da empresa ativa.
          </p>
        </div>
        <PeriodPicker
          label={formatMonthLabel(monthYear.year, monthYear.month)}
          onPrev={() => shiftMonth(-1)}
          onNext={() => shiftMonth(1)}
          onReset={() => {
            const c = currentMonthPeriod();
            const d = new Date(c.start);
            setMonthYear({ year: d.getFullYear(), month: d.getMonth() });
          }}
        />
      </div>

      <div className={`grid gap-3 ${navGridClass}`}>
        {navCards.map((card) => {
          const active = tab === card.tab;
          return (
            <button
              key={card.key}
              type="button"
              onClick={() => handleNavClick(card)}
              className={`flex min-h-[7.5rem] flex-col rounded-2xl border p-5 text-left transition ${
                active
                  ? "border-gold/60 bg-gold/10 shadow-glow"
                  : "border-border bg-card hover:border-gold/30 hover:bg-card/80"
              }`}
            >
              <div
                className={`mb-3 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-background ${
                  active ? "text-gold" : "text-muted-foreground"
                }`}
              >
                {card.icon}
              </div>
              <div className="font-display text-base font-bold leading-tight">{card.label}</div>
              <div className="mt-1 text-xs text-muted-foreground">{card.desc}</div>
            </button>
          );
        })}
      </div>

      {tab === "resumo" && <ResumoTab period={period} />}
      {tab === "despesas" && <DespesasTab period={period} />}
      {tab === "cobrancas" && <CobrancasTab period={period} />}
      {tab === "pessoais" && isCompanyAdmin && <GastosPessoaisTab period={period} />}
    </div>
  );
}

function PeriodPicker({
  label,
  onPrev,
  onNext,
  onReset,
}: {
  label: string;
  onPrev: () => void;
  onNext: () => void;
  onReset: () => void;
}) {
  return (
    <div className="flex items-center gap-2 rounded-2xl border bg-card px-2 py-1">
      <button type="button" onClick={onPrev} className="rounded-lg p-2 hover:bg-muted" aria-label="Mês anterior">
        <ChevronLeft className="h-4 w-4" />
      </button>
      <button
        type="button"
        onClick={onReset}
        className="flex items-center gap-2 px-2 py-1 text-sm font-medium capitalize"
        title="Voltar ao mês corrente"
      >
        <CalendarDays className="h-4 w-4 text-gold" />
        {label}
      </button>
      <button type="button" onClick={onNext} className="rounded-lg p-2 hover:bg-muted" aria-label="Próximo mês">
        <ChevronRight className="h-4 w-4" />
      </button>
    </div>
  );
}

function NoCompanyBanner() {
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm">
      <Building2 className="h-5 w-5 shrink-0 text-amber-300" />
      <p>Selecione ou crie uma empresa ativa para ver o financeiro.</p>
    </div>
  );
}

function ResumoTab({ period }: { period: FinancePeriod }) {
  const { data: expenses = [], companyId, hasActiveCompany, isLoading: loadingExpenses } =
    useOperationalExpenses();
  const { data: charges = [], isLoading: loadingCharges } = useCharges();
  const {
    data: summary,
    isLoading: loadingSummary,
    isError,
    refetch,
  } = useFinanceSummary(companyId, period);
  const {
    data: cashflow,
    isLoading: loadingCashflow,
    isError: cashflowError,
    refetch: refetchCashflow,
  } = useFinanceCashflow(companyId, period);

  if (!hasActiveCompany) return <NoCompanyBanner />;

  const loading = loadingSummary || loadingExpenses || loadingCharges;

  if (loading && !summary) {
    return (
      <div className="flex items-center justify-center gap-2 py-16 text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" />
        Carregando resumo…
      </div>
    );
  }

  if (isError || !summary) {
    return (
      <div className="rounded-2xl border border-red-500/30 bg-red-500/10 p-4 text-sm">
        Não foi possível carregar o resumo.{" "}
        <button type="button" className="underline" onClick={() => refetch()}>
          Tentar de novo
        </button>
      </div>
    );
  }

  const caixaTotal = summary.caixa_vendas + summary.caixa_cobrancas;
  const despesasNoPeriodo = expenses.filter((e) => inPeriodDate(e.expense_date, period)).length;
  const cobrancasPagasNoPeriodo = charges.filter(
    (c) => c.status === "paid" && c.paid_at && inPeriodIso(c.paid_at, period),
  ).length;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-6">
        <SummaryCard
          icon={<TrendingUp className="h-4 w-4" />}
          label="Faturamento"
          hint="Compromisso comercial — orçamentos aprovados no período, não é caixa."
          value={brl(summary.faturamento)}
          tone="text-sky-300"
          accent="sky"
        />
        <SummaryCard
          icon={<Wallet className="h-4 w-4" />}
          label="Caixa — vendas"
          hint="Recebido via vendas diretas finalizadas no período."
          value={brl(summary.caixa_vendas)}
          tone="text-emerald-300"
          accent="emerald"
        />
        <SummaryCard
          icon={<BadgeDollarSign className="h-4 w-4" />}
          label="Caixa — cobranças"
          hint="Cobranças manuais pagas no período (sem duplicar vendas)."
          value={brl(summary.caixa_cobrancas)}
          tone="text-emerald-300"
          accent="emerald"
        />
        <SummaryCard
          icon={<Wallet className="h-4 w-4" />}
          label="Caixa total"
          hint="Soma vendas + cobranças — faturamento não entra aqui."
          value={brl(caixaTotal)}
          tone="text-gold"
          accent="gold"
        />
        <SummaryCard
          icon={<TrendingDown className="h-4 w-4" />}
          label="Despesas operacionais"
          hint={`${despesasNoPeriodo} lançamento(s) no período. Retiradas pessoais não entram.`}
          value={brl(summary.despesas)}
          tone="text-red-300"
          accent="red"
        />
        <SummaryCard
          icon={<TrendingUp className="h-4 w-4" />}
          label="Lucro estimado"
          hint="Caixa total − despesas operacionais. Estimativa — não substitui contabilidade."
          value={brl(summary.lucro_estimado)}
          tone={summary.lucro_estimado >= 0 ? "text-gold" : "text-red-300"}
          accent={summary.lucro_estimado >= 0 ? "gold" : "red"}
        />
      </div>

      <div className="rounded-xl border border-gold/15 bg-gold/5 px-3 py-2 text-xs leading-relaxed text-muted-foreground">
        <strong className="font-medium text-foreground/90">Estimativa operacional</strong> (caixa −
        despesas). Não substitui contabilidade formal. Faturamento{" "}
        <strong className="font-medium text-foreground/90">não entra</strong> no lucro — mede
        compromisso comercial, não dinheiro recebido.
        {cobrancasPagasNoPeriodo > 0 && (
          <span className="ml-1">· Cobranças pagas no período: {cobrancasPagasNoPeriodo}.</span>
        )}
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <CashflowChart
          cashflow={cashflow}
          loading={loadingCashflow}
          isError={cashflowError}
          onRetry={() => refetchCashflow()}
        />
        <DistributionDonutChart
          caixaTotal={caixaTotal}
          despesas={summary.despesas}
          lucro={summary.lucro_estimado}
        />
      </div>
    </div>
  );
}

const distributionChartConfig = {
  caixa: { label: "Caixa total", color: "#22c55e" },
  despesas: { label: "Despesas operacionais", color: "#ef4444" },
  lucro: { label: "Lucro estimado", color: "#eab308" },
} satisfies ChartConfig;

function DistributionDonutChart({
  caixaTotal,
  despesas,
  lucro,
}: {
  caixaTotal: number;
  despesas: number;
  lucro: number;
}) {
  const isEmpty = caixaTotal === 0 && despesas === 0 && lucro === 0;

  const chartData = useMemo(() => {
    const slices = [
      { segment: "caixa" as const, value: caixaTotal },
      { segment: "despesas" as const, value: despesas },
      { segment: "lucro" as const, value: Math.max(lucro, 0) },
    ];
    return slices.filter((s) => s.value > 0);
  }, [caixaTotal, despesas, lucro]);

  return (
    <section className="rounded-2xl border bg-card p-5">
      <div className="mb-1 font-display text-lg font-bold">Distribuição dos valores</div>
      <p className="mb-4 text-sm text-muted-foreground">
        Proporção visual entre caixa recebido, despesas operacionais e lucro estimado no período.
      </p>

      {isEmpty ? (
        <div className="flex h-[288px] flex-col items-center justify-center rounded-xl border border-dashed bg-muted/20 px-4 text-center text-sm text-muted-foreground">
          <ChartPie className="mb-2 h-8 w-8 opacity-40" />
          Sem valores no período para distribuir.
          <span className="mt-1 text-xs">Caixa, despesas e lucro estão zerados.</span>
        </div>
      ) : chartData.length === 0 ? (
        <div className="flex h-[288px] flex-col items-center justify-center rounded-xl border border-dashed bg-muted/20 px-4 text-center text-sm text-muted-foreground">
          Lucro negativo no período ({brl(lucro)}). Caixa {brl(caixaTotal)} · Despesas{" "}
          {brl(despesas)}.
        </div>
      ) : (
        <>
          <ChartContainer config={distributionChartConfig} className="mx-auto h-[288px] w-full max-w-sm">
            <PieChart>
              <ChartTooltip
                content={
                  <ChartTooltipContent
                    formatter={(value, name) => (
                      <span className="font-medium">
                        {distributionChartConfig[name as keyof typeof distributionChartConfig]?.label ??
                          name}
                        : {brl(Number(value))}
                      </span>
                    )}
                  />
                }
              />
              <Pie
                data={chartData}
                dataKey="value"
                nameKey="segment"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={2}
                strokeWidth={2}
              >
                {chartData.map((entry) => (
                  <Cell
                    key={entry.segment}
                    fill={`var(--color-${entry.segment})`}
                  />
                ))}
              </Pie>
              <ChartLegend content={<ChartLegendContent nameKey="segment" />} />
            </PieChart>
          </ChartContainer>
          {lucro < 0 && (
            <p className="mt-3 text-center text-xs text-red-300">
              Lucro estimado negativo: {brl(lucro)} (não entra na fatia do gráfico).
            </p>
          )}
          <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs text-muted-foreground">
            <div>
              <span className="block font-medium text-emerald-300">{brl(caixaTotal)}</span>
              Caixa
            </div>
            <div>
              <span className="block font-medium text-red-300">{brl(despesas)}</span>
              Despesas
            </div>
            <div>
              <span className={`block font-medium ${lucro >= 0 ? "text-gold" : "text-red-300"}`}>
                {brl(lucro)}
              </span>
              Lucro
            </div>
          </div>
        </>
      )}
    </section>
  );
}

const cashflowChartConfig = {
  caixa_entrada: { label: "Caixa (entrada)", color: "#22c55e" },
  despesas_operacionais: { label: "Despesas operacionais", color: "#ef4444" },
} satisfies ChartConfig;

function CashflowChart({
  cashflow,
  loading,
  isError,
  onRetry,
}: {
  cashflow: ReturnType<typeof useFinanceCashflow>["data"];
  loading: boolean;
  isError: boolean;
  onRetry: () => void;
}) {
  const chartData = useMemo(
    () =>
      (cashflow?.buckets ?? []).map((b) => ({
        label: b.label,
        caixa_entrada: b.caixa_entrada,
        despesas_operacionais: b.despesas_operacionais,
      })),
    [cashflow?.buckets],
  );

  const allZero =
    chartData.length > 0 &&
    chartData.every((b) => b.caixa_entrada === 0 && b.despesas_operacionais === 0);

  return (
    <section className="rounded-2xl border bg-card p-5">
      <div className="mb-1 font-display text-lg font-bold">Fluxo de caixa real</div>
      <p className="mb-4 text-sm text-muted-foreground">
        Histórico do período — entradas de caixa vs. despesas operacionais. Não é previsão.
      </p>

      {loading && !cashflow && (
        <div className="flex h-[288px] items-center justify-center text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
        </div>
      )}

      {isError && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-sm">
          Não foi possível carregar o gráfico.{" "}
          <button type="button" className="underline" onClick={onRetry}>
            Tentar de novo
          </button>
        </div>
      )}

      {!loading && !isError && cashflow && (
        <>
          <ChartContainer config={cashflowChartConfig} className="h-[288px] w-full">
            <BarChart data={chartData} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid vertical={false} strokeDasharray="3 3" />
              <XAxis
                dataKey="label"
                tickLine={false}
                axisLine={false}
                tickMargin={8}
                interval={0}
                tick={{ fontSize: 11 }}
              />
              <YAxis
                tickLine={false}
                axisLine={false}
                tickMargin={8}
                tickFormatter={(v) =>
                  new Intl.NumberFormat("pt-BR", {
                    notation: "compact",
                    compactDisplay: "short",
                  }).format(Number(v))
                }
              />
              <ChartTooltip
                content={
                  <ChartTooltipContent
                    formatter={(value, name) => (
                      <span className="font-medium">
                        {cashflowChartConfig[name as keyof typeof cashflowChartConfig]?.label ?? name}:{" "}
                        {brl(Number(value))}
                      </span>
                    )}
                  />
                }
              />
              <Bar dataKey="caixa_entrada" fill="var(--color-caixa_entrada)" radius={[4, 4, 0, 0]} />
              <Bar
                dataKey="despesas_operacionais"
                fill="var(--color-despesas_operacionais)"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ChartContainer>
          {allZero && (
            <p className="mt-3 text-center text-sm text-muted-foreground">
              Sem movimentação de caixa neste período.
            </p>
          )}
        </>
      )}
    </section>
  );
}

const SUMMARY_ACCENT: Record<"sky" | "emerald" | "gold" | "red", string> = {
  sky: "border-sky-500/25 bg-sky-500/[0.06]",
  emerald: "border-emerald-500/25 bg-emerald-500/[0.06]",
  gold: "border-gold/30 bg-gold/[0.06]",
  red: "border-red-500/25 bg-red-500/[0.06]",
};

function SummaryCard({
  icon,
  label,
  hint,
  value,
  tone,
  accent,
}: {
  icon: ReactNode;
  label: string;
  hint: string;
  value: string;
  tone: string;
  accent: keyof typeof SUMMARY_ACCENT;
}) {
  return (
    <div className={`flex min-h-[5.75rem] flex-col rounded-xl border p-2.5 ${SUMMARY_ACCENT[accent]}`}>
      <div className="flex items-start gap-2">
        <div
          className={`inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-background/80 ${tone}`}
        >
          {icon}
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-[11px] font-medium leading-tight text-muted-foreground">{label}</div>
          <div className={`mt-0.5 truncate font-display text-lg font-bold leading-none ${tone}`}>
            {value}
          </div>
        </div>
      </div>
      <p className="mt-1.5 line-clamp-2 text-[10px] leading-snug text-muted-foreground">{hint}</p>
    </div>
  );
}

function DespesasTab({ period }: { period: FinancePeriod }) {
  const { data: rows = [], hasActiveCompany, isLoading, isError, refetch } =
    useOperationalExpenses();
  const create = useCreateExpense("operacional");
  const update = useUpdateExpense();
  const remove = useDeleteExpense();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<ExpenseRow | null>(null);
  const [confirmDel, setConfirmDel] = useState<ExpenseRow | null>(null);

  const filtered = useMemo(
    () => rows.filter((r) => inPeriodDate(r.expense_date, period)),
    [rows, period],
  );

  if (!hasActiveCompany) return <NoCompanyBanner />;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          Despesas operacionais do negócio com data contábil no período selecionado.
        </p>
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="inline-flex items-center gap-2 rounded-xl bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground"
        >
          <Plus className="h-4 w-4" />
          Nova despesa
        </button>
      </div>

      {isLoading && (
        <div className="flex justify-center py-12 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
        </div>
      )}
      {isError && (
        <div className="rounded-2xl border border-red-500/30 p-4 text-sm">
          Erro ao carregar despesas.{" "}
          <button type="button" className="underline" onClick={() => refetch()}>
            Tentar de novo
          </button>
        </div>
      )}
      {!isLoading && !isError && filtered.length === 0 && (
        <div className="rounded-2xl border border-dashed p-8 text-center text-sm text-muted-foreground">
          Nenhuma despesa neste período. Use &quot;Nova despesa&quot; para registrar uma saída de caixa.
        </div>
      )}

      <div className="space-y-2">
        {filtered.map((row) => (
          <div
            key={row.id}
            className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-card p-4"
          >
            <div>
              <div className="font-medium">{row.description}</div>
              <div className="text-xs text-muted-foreground">
                {categoryLabel(row)} · {formatDate(row.expense_date)}
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-display text-lg font-bold text-red-300">{brl(row.amount)}</span>
              <button
                type="button"
                className="rounded-lg p-2 text-muted-foreground hover:bg-primary/10 hover:text-primary"
                onClick={() => setEditing(row)}
                aria-label="Editar despesa"
              >
                <Pencil className="h-4 w-4" />
              </button>
              <button
                type="button"
                className="rounded-lg p-2 text-muted-foreground hover:bg-red-500/10 hover:text-red-300"
                onClick={() => setConfirmDel(row)}
                aria-label="Excluir despesa"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {open && (
        <ExpenseDialog
          key="new-operacional"
          kind="operacional"
          title="Nova despesa operacional"
          onClose={() => setOpen(false)}
          loading={create.isPending}
          onSubmit={(v) =>
            create.mutate(v, {
              onSuccess: () => {
                toast.success("Despesa registrada");
                setOpen(false);
              },
              onError: (e) => toast.error(financeErrorMessage(e)),
            })
          }
        />
      )}

      {editing && (
        <ExpenseDialog
          key={editing.id}
          kind="operacional"
          title="Editar despesa operacional"
          initial={editing}
          onClose={() => setEditing(null)}
          loading={update.isPending}
          onSubmit={(v) =>
            update.mutate(
              { id: editing.id, ...v },
              {
                onSuccess: () => {
                  toast.success("Despesa atualizada");
                  setEditing(null);
                },
                onError: (e) => toast.error(financeErrorMessage(e)),
              },
            )
          }
        />
      )}

      {confirmDel && (
        <ConfirmDialog
          title="Excluir despesa?"
          description={`Remover "${confirmDel.description}" (${brl(confirmDel.amount)})?`}
          loading={remove.isPending}
          onCancel={() => setConfirmDel(null)}
          onConfirm={() =>
            remove.mutate(confirmDel.id, {
              onSuccess: () => {
                toast.success("Despesa excluída");
                setConfirmDel(null);
              },
              onError: (e) => toast.error(financeErrorMessage(e)),
            })
          }
        />
      )}
    </div>
  );
}

function GastosPessoaisTab({ period }: { period: FinancePeriod }) {
  const { data: rows = [], hasActiveCompany, isLoading, isError, refetch } = usePersonalExpenses();
  const create = useCreateExpense("pessoal");
  const update = useUpdateExpense();
  const remove = useDeleteExpense();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<ExpenseRow | null>(null);
  const [confirmDel, setConfirmDel] = useState<ExpenseRow | null>(null);

  const filtered = useMemo(
    () => rows.filter((r) => inPeriodDate(r.expense_date, period)),
    [rows, period],
  );

  const totalPeriodo = useMemo(
    () => filtered.reduce((acc, r) => acc + r.amount, 0),
    [filtered],
  );

  if (!hasActiveCompany) return <NoCompanyBanner />;

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-violet-500/25 bg-violet-500/5 p-4 text-sm text-muted-foreground">
        <div className="mb-1 flex items-center gap-2 font-medium text-violet-200">
          <UserRound className="h-4 w-4" />
          Retiradas pessoais / pró-labore
        </div>
        Registros separados da operação da empresa.{" "}
        <strong className="text-foreground">Não entram</strong> no lucro estimado nem nas despesas
        operacionais do Resumo — são distribuição ao dono, não custo do negócio.
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          {filtered.length} retirada(s) no período · total {brl(totalPeriodo)}
        </p>
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="inline-flex items-center gap-2 rounded-xl bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground"
        >
          <Plus className="h-4 w-4" />
          Nova retirada
        </button>
      </div>

      {isLoading && (
        <div className="flex justify-center py-12 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
        </div>
      )}
      {isError && (
        <div className="rounded-2xl border border-red-500/30 p-4 text-sm">
          Erro ao carregar retiradas.{" "}
          <button type="button" className="underline" onClick={() => refetch()}>
            Tentar de novo
          </button>
        </div>
      )}
      {!isLoading && !isError && filtered.length === 0 && (
        <div className="rounded-2xl border border-dashed p-8 text-center text-sm text-muted-foreground">
          Nenhuma retirada pessoal neste período.
        </div>
      )}

      <div className="space-y-2">
        {filtered.map((row) => (
          <div
            key={row.id}
            className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-card p-4"
          >
            <div>
              <div className="font-medium">{row.description}</div>
              <div className="text-xs text-muted-foreground">
                {categoryLabel(row)} · {formatDate(row.expense_date)}
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-display text-lg font-bold text-violet-300">
                {brl(row.amount)}
              </span>
              <button
                type="button"
                className="rounded-lg p-2 text-muted-foreground hover:bg-primary/10 hover:text-primary"
                onClick={() => setEditing(row)}
                aria-label="Editar retirada"
              >
                <Pencil className="h-4 w-4" />
              </button>
              <button
                type="button"
                className="rounded-lg p-2 text-muted-foreground hover:bg-red-500/10 hover:text-red-300"
                onClick={() => setConfirmDel(row)}
                aria-label="Excluir retirada"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {open && (
        <ExpenseDialog
          key="new-pessoal"
          kind="pessoal"
          title="Nova retirada pessoal"
          onClose={() => setOpen(false)}
          loading={create.isPending}
          onSubmit={(v) =>
            create.mutate(v, {
              onSuccess: () => {
                toast.success("Retirada registrada");
                setOpen(false);
              },
              onError: (e) => toast.error(financeErrorMessage(e)),
            })
          }
        />
      )}

      {editing && (
        <ExpenseDialog
          key={editing.id}
          kind="pessoal"
          title="Editar retirada pessoal"
          initial={editing}
          onClose={() => setEditing(null)}
          loading={update.isPending}
          onSubmit={(v) =>
            update.mutate(
              { id: editing.id, ...v },
              {
                onSuccess: () => {
                  toast.success("Retirada atualizada");
                  setEditing(null);
                },
                onError: (e) => toast.error(financeErrorMessage(e)),
              },
            )
          }
        />
      )}

      {confirmDel && (
        <ConfirmDialog
          title="Excluir retirada?"
          description={`Remover "${confirmDel.description}" (${brl(confirmDel.amount)})?`}
          loading={remove.isPending}
          onCancel={() => setConfirmDel(null)}
          onConfirm={() =>
            remove.mutate(confirmDel.id, {
              onSuccess: () => {
                toast.success("Retirada excluída");
                setConfirmDel(null);
              },
              onError: (e) => toast.error(financeErrorMessage(e)),
            })
          }
        />
      )}
    </div>
  );
}

function CobrancasTab({ period }: { period: FinancePeriod }) {
  const { data: rows = [], hasActiveCompany, isLoading, isError, refetch } = useCharges();
  const create = useCreateManualCharge();
  const update = useUpdateManualCharge();
  const markPaid = useMarkChargePaid();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<ChargeRow | null>(null);

  if (!hasActiveCompany) return <NoCompanyBanner />;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          Cobranças manuais a receber. Marque como paga quando o valor entrar no caixa.
        </p>
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="inline-flex items-center gap-2 rounded-xl bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground"
        >
          <Plus className="h-4 w-4" />
          Nova cobrança
        </button>
      </div>

      {isLoading && (
        <div className="flex justify-center py-12 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
        </div>
      )}
      {isError && (
        <div className="rounded-2xl border border-red-500/30 p-4 text-sm">
          Erro ao carregar cobranças.{" "}
          <button type="button" className="underline" onClick={() => refetch()}>
            Tentar de novo
          </button>
        </div>
      )}
      {!isLoading && !isError && rows.length === 0 && (
        <div className="rounded-2xl border border-dashed p-8 text-center text-sm text-muted-foreground">
          Nenhuma cobrança registrada. Crie uma cobrança manual vinculada a um orçamento aprovado, se
          quiser.
        </div>
      )}

      <div className="space-y-2">
        {rows.map((row) => (
          <ChargeRowCard
            key={row.id}
            row={row}
            period={period}
            marking={markPaid.isPending}
            onMarkPaid={() =>
              markPaid.mutate(row.id, {
                onSuccess: () => toast.success("Cobrança marcada como paga"),
                onError: (e) => toast.error(financeErrorMessage(e)),
              })
            }
            onEdit={() => setEditing(row)}
          />
        ))}
      </div>

      {open && (
        <ChargeDialog
          key="new-charge"
          onClose={() => setOpen(false)}
          loading={create.isPending}
          onSubmit={(v) =>
            create.mutate(v, {
              onSuccess: () => {
                toast.success("Cobrança criada");
                setOpen(false);
              },
              onError: (e) => toast.error(financeErrorMessage(e)),
            })
          }
        />
      )}

      {editing && (
        <ChargeDialog
          key={editing.id}
          title="Editar cobrança manual"
          confirmLabel="Salvar"
          initial={editing}
          onClose={() => setEditing(null)}
          loading={update.isPending}
          onSubmit={(v) =>
            update.mutate(
              { charge_id: editing.id, ...v },
              {
                onSuccess: () => {
                  toast.success("Cobrança atualizada");
                  setEditing(null);
                },
                onError: (e) => toast.error(financeErrorMessage(e)),
              },
            )
          }
        />
      )}
    </div>
  );
}

function ChargeRowCard({
  row,
  period,
  marking,
  onMarkPaid,
  onEdit,
}: {
  row: ChargeRow;
  period: FinancePeriod;
  marking: boolean;
  onMarkPaid: () => void;
  onEdit: () => void;
}) {
  const status = CHARGE_STATUS_META[row.status as ChargeStatus] ?? {
    label: row.status,
    tone: "bg-muted",
  };
  const canEdit = row.status === "pending" || row.status === "overdue";
  const canMark = canEdit;
  const paidInPeriod = row.status === "paid" && row.paid_at && inPeriodIso(row.paid_at, period);

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-card p-4">
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-medium">{row.description ?? "Cobrança manual"}</span>
          <span className={`rounded-full px-2 py-0.5 text-xs ${status.tone}`}>{status.label}</span>
          {paidInPeriod && (
            <span className="text-xs text-emerald-300">· entrou no caixa deste período</span>
          )}
        </div>
        <div className="text-xs text-muted-foreground">
          {row.customer?.nome ?? "Sem cliente"}
          {row.quote?.numero != null && ` · Orç. #${row.quote.numero}`}
          {row.due_date && ` · Venc. ${formatDate(row.due_date)}`}
          {row.paid_at && row.status === "paid" && ` · Pago em ${formatDate(row.paid_at)}`}
        </div>
      </div>
      <div className="flex items-center gap-3">
        <span className="font-display text-lg font-bold text-emerald-300">{brl(row.amount)}</span>
        {canEdit && (
          <button
            type="button"
            className="rounded-lg p-2 text-muted-foreground hover:bg-primary/10 hover:text-primary"
            onClick={onEdit}
            aria-label="Editar cobrança"
          >
            <Pencil className="h-4 w-4" />
          </button>
        )}
        {canMark && (
          <button
            type="button"
            disabled={marking}
            onClick={onMarkPaid}
            className="inline-flex items-center gap-1 rounded-lg border border-emerald-500/40 px-3 py-1.5 text-xs font-medium text-emerald-300 hover:bg-emerald-500/10 disabled:opacity-50"
          >
            <CheckCircle2 className="h-3.5 w-3.5" />
            Marcar paga
          </button>
        )}
      </div>
    </div>
  );
}

function ExpenseDialog({
  kind,
  title,
  initial,
  onClose,
  onSubmit,
  loading,
}: {
  kind: ExpenseKind;
  title: string;
  initial?: ExpenseRow;
  onClose: () => void;
  loading: boolean;
  onSubmit: (v: {
    expense_kind: ExpenseKind;
    category: ExpenseCategoryAny;
    description: string;
    amount: number;
    expense_date: string;
    notes?: string | null;
  }) => void;
}) {
  const categories =
    kind === "pessoal" ? PERSONAL_EXPENSE_CATEGORIES : EXPENSE_CATEGORIES;
  const defaultCategory =
    kind === "pessoal"
      ? ("pro_labore" as PersonalExpenseCategory)
      : ("fornecedor" as ExpenseCategory);

  const today = new Date().toISOString().slice(0, 10);
  const [category, setCategory] = useState<ExpenseCategoryAny>(
    initial?.category ?? defaultCategory,
  );
  const [description, setDescription] = useState(initial?.description ?? "");
  const [amount, setAmount] = useState(initial ? String(initial.amount) : "");
  const [expenseDate, setExpenseDate] = useState(initial?.expense_date ?? today);
  const [notes, setNotes] = useState(initial?.notes ?? "");

  const submit = () => {
    const val = Number(amount.replace(",", "."));
    if (!description.trim()) {
      toast.error("Informe a descrição.");
      return;
    }
    if (!Number.isFinite(val) || val <= 0) {
      toast.error("Informe um valor positivo.");
      return;
    }
    onSubmit({
      expense_kind: kind,
      category,
      description: description.trim(),
      amount: Math.round(val * 100) / 100,
      expense_date: expenseDate,
      notes: notes.trim() || null,
    });
  };

  return (
    <ModalShell title={title} onClose={onClose}>
      <FormField label="Categoria">
        <select
          className="w-full rounded-xl border bg-background px-3 py-2"
          value={category}
          onChange={(e) => setCategory(e.target.value as ExpenseCategoryAny)}
        >
          {categories.map((c) => (
            <option key={c.value} value={c.value}>
              {c.label}
            </option>
          ))}
        </select>
      </FormField>
      <FormField label="Descrição">
        <input
          className="w-full rounded-xl border bg-background px-3 py-2"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          maxLength={500}
        />
      </FormField>
      <FormField label="Valor (R$)">
        <input
          className="w-full rounded-xl border bg-background px-3 py-2"
          inputMode="decimal"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
      </FormField>
      <FormField label="Data da despesa">
        <input
          type="date"
          className="w-full rounded-xl border bg-background px-3 py-2"
          value={expenseDate}
          onChange={(e) => setExpenseDate(e.target.value)}
        />
      </FormField>
      <FormField label="Observações (opcional)">
        <textarea
          className="w-full rounded-xl border bg-background px-3 py-2"
          rows={2}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />
      </FormField>
      <ModalActions loading={loading} onCancel={onClose} onConfirm={submit} confirmLabel="Salvar" />
    </ModalShell>
  );
}

function ChargeDialog({
  title = "Nova cobrança manual",
  confirmLabel = "Criar cobrança",
  initial,
  onClose,
  onSubmit,
  loading,
}: {
  title?: string;
  confirmLabel?: string;
  initial?: ChargeRow;
  onClose: () => void;
  loading: boolean;
  onSubmit: (v: {
    amount: number;
    description: string;
    customer_id?: string | null;
    quote_id?: string | null;
    due_date?: string | null;
  }) => void;
}) {
  const { data: customers = [] } = useCompanyCustomerOptions();
  const { data: quotes = [] } = useApprovedQuoteOptions();
  const [description, setDescription] = useState(initial?.description ?? "");
  const [amount, setAmount] = useState(initial ? String(initial.amount) : "");
  const [customerId, setCustomerId] = useState(initial?.customer_id ?? "");
  const [quoteId, setQuoteId] = useState(initial?.quote_id ?? "");
  const [dueDate, setDueDate] = useState(initial?.due_date ?? "");

  const submit = () => {
    const val = Number(amount.replace(",", "."));
    if (!description.trim()) {
      toast.error("Informe a descrição da cobrança.");
      return;
    }
    if (!Number.isFinite(val) || val <= 0) {
      toast.error("Informe um valor positivo.");
      return;
    }
    onSubmit({
      description: description.trim(),
      amount: Math.round(val * 100) / 100,
      customer_id: customerId || null,
      quote_id: quoteId || null,
      due_date: dueDate || null,
    });
  };

  return (
    <ModalShell title={title} onClose={onClose}>
      <FormField label="Descrição">
        <input
          className="w-full rounded-xl border bg-background px-3 py-2"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
      </FormField>
      <FormField label="Valor (R$)">
        <input
          className="w-full rounded-xl border bg-background px-3 py-2"
          inputMode="decimal"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
      </FormField>
      <FormField label="Cliente (opcional)">
        <select
          className="w-full rounded-xl border bg-background px-3 py-2"
          value={customerId}
          onChange={(e) => setCustomerId(e.target.value)}
        >
          <option value="">— Nenhum —</option>
          {customers.map((c) => (
            <option key={c.id} value={c.id}>
              {c.nome}
            </option>
          ))}
        </select>
      </FormField>
      <FormField label="Orçamento aprovado (opcional)">
        <select
          className="w-full rounded-xl border bg-background px-3 py-2"
          value={quoteId}
          onChange={(e) => setQuoteId(e.target.value)}
        >
          <option value="">— Nenhum —</option>
          {quotes.map((q) => (
            <option key={q.id} value={q.id}>
              #{q.numero} — {q.customer?.nome ?? "Cliente"} ({brl(q.total)})
            </option>
          ))}
        </select>
      </FormField>
      <FormField label="Vencimento (opcional)">
        <input
          type="date"
          className="w-full rounded-xl border bg-background px-3 py-2"
          value={dueDate}
          onChange={(e) => setDueDate(e.target.value)}
        />
      </FormField>
      <ModalActions loading={loading} onCancel={onClose} onConfirm={submit} confirmLabel={confirmLabel} />
    </ModalShell>
  );
}

function ModalShell({
  title,
  children,
  onClose,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
      <div className="max-h-[90vh] w-full max-w-md overflow-y-auto rounded-2xl border bg-card p-5 shadow-xl">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold">{title}</h2>
          <button type="button" className="text-sm text-muted-foreground hover:text-foreground" onClick={onClose}>
            Fechar
          </button>
        </div>
        <div className="space-y-3">{children}</div>
      </div>
    </div>
  );
}

function FormField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block space-y-1 text-sm">
      <span className="text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

function ModalActions({
  loading,
  onCancel,
  onConfirm,
  confirmLabel,
}: {
  loading: boolean;
  onCancel: () => void;
  onConfirm: () => void;
  confirmLabel: string;
}) {
  return (
    <div className="flex justify-end gap-2 pt-2">
      <button type="button" className="rounded-xl px-4 py-2 text-sm hover:bg-muted" onClick={onCancel}>
        Cancelar
      </button>
      <button
        type="button"
        disabled={loading}
        className="inline-flex items-center gap-2 rounded-xl bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground disabled:opacity-50"
        onClick={onConfirm}
      >
        {loading && <Loader2 className="h-4 w-4 animate-spin" />}
        {confirmLabel}
      </button>
    </div>
  );
}

function ConfirmDialog({
  title,
  description,
  loading,
  onCancel,
  onConfirm,
}: {
  title: string;
  description: string;
  loading: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
      <div className="w-full max-w-sm rounded-2xl border bg-card p-5">
        <h2 className="font-display text-lg font-bold">{title}</h2>
        <p className="mt-2 text-sm text-muted-foreground">{description}</p>
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" className="rounded-xl px-4 py-2 text-sm hover:bg-muted" onClick={onCancel}>
            Cancelar
          </button>
          <button
            type="button"
            disabled={loading}
            className="rounded-xl bg-red-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
            onClick={onConfirm}
          >
            Excluir
          </button>
        </div>
      </div>
    </div>
  );
}

function inPeriodDate(dateStr: string, period: FinancePeriod) {
  const d = dateStr.slice(0, 10);
  const start = period.start.slice(0, 10);
  const end = period.end.slice(0, 10);
  return d >= start && d < end;
}

function inPeriodIso(iso: string, period: FinancePeriod) {
  const t = new Date(iso).getTime();
  return t >= new Date(period.start).getTime() && t < new Date(period.end).getTime();
}
