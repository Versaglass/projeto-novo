/**
 * Catálogo de Fabricantes — listagem legada (somente platform admin).
 * Usuários comuns veem produtos globais diretamente em /app/estoque.
 */

import { createFileRoute, Link, useNavigate, type SearchSchemaInput } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { Factory, ImageIcon, Loader2, Search, X } from "lucide-react";
import { StorageImage } from "@/components/StorageImage";
import {
  MANUFACTURER_CATALOG_PAGE_SIZE,
  manufacturerCatalogErrorMessage,
  useManufacturerCatalogProducts,
  useManufacturerOptions,
  useManufacturerProductLines,
} from "@/hooks/use-manufacturer-catalog";
import { INVENTORY_CATEGORIES, categoriaMeta } from "@/hooks/use-inventory";
import {
  searchCatalogoFabricantes,
  type ManufacturerCatalogSearch,
} from "@/lib/manufacturer-catalog/search";
import { clampCatalogPage } from "@/lib/manufacturer-catalog/attributes";
import type { CatalogSort } from "@/lib/manufacturer-catalog/attributes";
import { requireAdmin } from "@/lib/admin-guard";

type SearchInput = ManufacturerCatalogSearch & SearchSchemaInput;

export const Route = createFileRoute("/_authenticated/app/catalogo-fabricantes")({
  beforeLoad: requireAdmin,
  validateSearch: (search: SearchInput): ManufacturerCatalogSearch =>
    searchCatalogoFabricantes({
      q: search.q,
      fabricante: search.fabricante,
      categoria: search.categoria,
      linha: search.linha,
      page: search.page,
      ordem: search.ordem,
    }),
  component: CatalogoFabricantesPage,
});

const ORDEM_OPTS: { value: CatalogSort; label: string }[] = [
  { value: "nome_asc", label: "Nome A–Z" },
  { value: "nome_desc", label: "Nome Z–A" },
  { value: "recentes", label: "Mais recentes" },
];

function CatalogoFabricantesPage() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: Route.fullPath });
  const [draftQ, setDraftQ] = useState(search.q ?? "");

  const { data, isLoading, isError, error, isFetching } = useManufacturerCatalogProducts(search);
  const { data: manufacturers = [] } = useManufacturerOptions();
  const { data: lines = [] } = useManufacturerProductLines(search.fabricante);

  const total = data?.total ?? 0;
  const items = useMemo(() => data?.items ?? [], [data?.items]);
  const page = search.page ?? 1;
  const pageCount = Math.max(1, Math.ceil(total / MANUFACTURER_CATALOG_PAGE_SIZE));

  const hasFilters = Boolean(
    search.q || search.fabricante || search.categoria || search.linha || search.ordem,
  );

  const categories = useMemo(() => INVENTORY_CATEGORIES, []);

  function patchSearch(patch: Partial<ManufacturerCatalogSearch> & { page?: number }) {
    void navigate({
      search: searchCatalogoFabricantes({
        q: patch.q !== undefined ? patch.q : search.q,
        fabricante: patch.fabricante !== undefined ? patch.fabricante : search.fabricante,
        categoria: patch.categoria !== undefined ? patch.categoria : search.categoria,
        linha: patch.linha !== undefined ? patch.linha : search.linha,
        // Filtros/ordem/busca → page 1 por padrão; paginação passa page explicitamente.
        page: patch.page !== undefined ? patch.page : 1,
        ordem: patch.ordem !== undefined ? patch.ordem : search.ordem,
      }),
    });
  }

  // page=999 com poucas páginas → normaliza sem loop (só quando total já conhecido).
  useEffect(() => {
    if (isLoading || isError) return;
    if (typeof data?.total !== "number") return;
    const clamped = clampCatalogPage(page, data.total, MANUFACTURER_CATALOG_PAGE_SIZE);
    if (clamped !== page) {
      patchSearch({ page: clamped });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- só reage a page/total
  }, [isLoading, isError, data?.total, page]);

  function submitSearch(e: FormEvent) {
    e.preventDefault();
    patchSearch({ q: draftQ, page: 1 });
  }

  function clearFilters() {
    setDraftQ("");
    void navigate({ search: {} });
  }

  return (
    <div className="mx-auto max-w-7xl space-y-6 p-4 md:p-6">
      <header className="space-y-1">
        <div className="flex items-center gap-2 text-primary">
          <Factory className="h-6 w-6" aria-hidden />
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">
            Catálogo de Fabricantes
          </h1>
        </div>
        <p className="max-w-2xl text-sm text-muted-foreground">
          Consulte produtos publicados pelos fabricantes. Com permissão de estoque, você pode
          adicionar um produto ao inventário da empresa a partir do detalhe.
        </p>
      </header>

      <section
        aria-label="Filtros do catálogo"
        className="flex flex-col gap-3 rounded-xl border border-border/60 bg-card/40 p-3 md:p-4"
      >
        <form onSubmit={submitSearch} className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <label className="sr-only" htmlFor="catalogo-q">
            Buscar produtos
          </label>
          <div className="relative min-w-0 flex-1">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden
            />
            <input
              id="catalogo-q"
              value={draftQ}
              onChange={(e) => setDraftQ(e.target.value)}
              placeholder="Buscar por nome, código ou fabricante…"
              className="h-10 w-full rounded-lg border border-border bg-background pl-9 pr-3 text-sm outline-none ring-offset-background focus-visible:ring-2 focus-visible:ring-ring"
            />
          </div>
          <button
            type="submit"
            className="inline-flex h-10 items-center justify-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground hover:opacity-90"
          >
            Buscar
          </button>
        </form>

        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-1">
            <label
              htmlFor="catalogo-fabricante"
              className="text-xs font-medium text-muted-foreground"
            >
              Fabricante
            </label>
            <select
              id="catalogo-fabricante"
              value={search.fabricante ?? ""}
              onChange={(e) =>
                patchSearch({
                  fabricante: e.target.value || undefined,
                  linha: undefined,
                  page: 1,
                })
              }
              className="h-10 w-full rounded-lg border border-border bg-background px-3 text-sm"
            >
              <option value="">Todos</option>
              {manufacturers.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label
              htmlFor="catalogo-categoria"
              className="text-xs font-medium text-muted-foreground"
            >
              Categoria
            </label>
            <select
              id="catalogo-categoria"
              value={search.categoria ?? ""}
              onChange={(e) => patchSearch({ categoria: e.target.value || undefined, page: 1 })}
              className="h-10 w-full rounded-lg border border-border bg-background px-3 text-sm"
            >
              <option value="">Todas</option>
              {categories.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label htmlFor="catalogo-linha" className="text-xs font-medium text-muted-foreground">
              Linha
            </label>
            <select
              id="catalogo-linha"
              value={search.linha ?? ""}
              onChange={(e) => patchSearch({ linha: e.target.value || undefined, page: 1 })}
              className="h-10 w-full rounded-lg border border-border bg-background px-3 text-sm"
            >
              <option value="">Todas</option>
              {lines.map((line) => (
                <option key={line} value={line}>
                  {line}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label htmlFor="catalogo-ordem" className="text-xs font-medium text-muted-foreground">
              Ordenação
            </label>
            <select
              id="catalogo-ordem"
              value={search.ordem ?? "nome_asc"}
              onChange={(e) => patchSearch({ ordem: e.target.value as CatalogSort, page: 1 })}
              className="h-10 w-full rounded-lg border border-border bg-background px-3 text-sm"
            >
              {ORDEM_OPTS.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {hasFilters ? (
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs text-muted-foreground">
              {total} produto{total === 1 ? "" : "s"} encontrado{total === 1 ? "" : "s"}
              {isFetching && !isLoading ? " · atualizando…" : ""}
            </p>
            <button
              type="button"
              onClick={clearFilters}
              className="inline-flex items-center gap-1 text-xs text-muted-foreground underline-offset-2 hover:underline"
            >
              <X className="h-3.5 w-3.5" aria-hidden />
              Limpar filtros
            </button>
          </div>
        ) : (
          <p className="text-xs text-muted-foreground">
            {total} produto{total === 1 ? "" : "s"} no catálogo
            {isFetching && !isLoading ? " · atualizando…" : ""}
          </p>
        )}
      </section>

      {isLoading ? (
        <div className="flex items-center justify-center gap-2 py-16 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" aria-hidden />
          <span>Carregando catálogo…</span>
        </div>
      ) : isError ? (
        <div
          role="alert"
          className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-6 text-sm text-rose-200"
        >
          {manufacturerCatalogErrorMessage(error)}
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border px-4 py-16 text-center">
          <Factory className="mx-auto mb-3 h-10 w-10 text-muted-foreground/50" aria-hidden />
          <p className="text-sm font-medium text-foreground">
            {hasFilters
              ? "Nenhum produto encontrado com os filtros selecionados."
              : "Nenhum produto publicado no catálogo ainda."}
          </p>
          {hasFilters ? (
            <button
              type="button"
              onClick={clearFilters}
              className="mt-3 text-sm text-primary underline-offset-2 hover:underline"
            >
              Limpar filtros
            </button>
          ) : null}
        </div>
      ) : (
        <>
          <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {items.map((item) => {
              const cat = item.inventory_category
                ? categoriaMeta(item.inventory_category)
                : undefined;
              return (
                <li key={item.id}>
                  <article className="flex h-full flex-col overflow-hidden rounded-xl border border-border/70 bg-card/50 transition hover:border-primary/40">
                    <div className="relative aspect-[4/3] bg-muted/40">
                      {item.primary_image_path ? (
                        <StorageImage
                          src={item.primary_image_path}
                          alt={item.name}
                          bucket="manufacturer-catalog"
                          className="h-full w-full object-contain p-2"
                        />
                      ) : (
                        <div className="flex h-full w-full flex-col items-center justify-center gap-1 text-muted-foreground">
                          <ImageIcon className="h-8 w-8 opacity-40" aria-hidden />
                          <span className="text-xs">Sem imagem</span>
                        </div>
                      )}
                    </div>
                    <div className="flex flex-1 flex-col gap-2 p-3">
                      <h2 className="line-clamp-2 text-sm font-semibold leading-snug text-foreground">
                        {item.name}
                      </h2>
                      <p className="font-mono text-xs text-muted-foreground">{item.source_code}</p>
                      <div className="mt-auto space-y-1 text-xs text-muted-foreground">
                        <p className="truncate font-medium text-foreground/80">
                          {item.manufacturer.name}
                        </p>
                        {item.product_line ? (
                          <p className="truncate">Linha {item.product_line}</p>
                        ) : null}
                        {cat ? (
                          <span
                            className={`inline-flex rounded-md px-1.5 py-0.5 text-[11px] ${cat.color}`}
                          >
                            {cat.label}
                          </span>
                        ) : item.suggested_category ? (
                          <p className="truncate italic">Sugestão: {item.suggested_category}</p>
                        ) : null}
                      </div>
                      <Link
                        to="/app/catalogo-fabricantes/$productId"
                        params={{ productId: item.id }}
                        search={search}
                        className="mt-2 inline-flex h-9 items-center justify-center rounded-lg border border-border bg-background text-sm font-medium hover:bg-muted"
                      >
                        Ver detalhes
                      </Link>
                    </div>
                  </article>
                </li>
              );
            })}
          </ul>

          {pageCount > 1 ? (
            <nav
              aria-label="Paginação do catálogo"
              className="flex flex-wrap items-center justify-center gap-2 pt-2"
            >
              <button
                type="button"
                disabled={page <= 1}
                onClick={() => patchSearch({ page: page - 1 })}
                className="h-9 rounded-lg border border-border px-3 text-sm disabled:opacity-40"
              >
                Anterior
              </button>
              <span className="text-sm text-muted-foreground">
                Página {page} de {pageCount}
              </span>
              <button
                type="button"
                disabled={page >= pageCount}
                onClick={() => patchSearch({ page: page + 1 })}
                className="h-9 rounded-lg border border-border px-3 text-sm disabled:opacity-40"
              >
                Próxima
              </button>
            </nav>
          ) : null}
        </>
      )}
    </div>
  );
}
