import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  Building2,
  Copy,
  Download,
  Edit,
  Filter,
  Lock,
  Plus,
  Search,
  Trash2,
  Truck,
} from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { CampoMascarado } from "@/components/CampoMascarado";
import { useAuth } from "@/hooks/use-auth";
import { useCompany } from "@/contexts/company-context";
import {
  SUPPLIER_AREAS,
  SUPPLIER_STATUSES,
  supplierAreaLabel,
  supplierErrorMessage,
  supplierStatusLabel,
  toSupplierInput,
  useCreateSupplier,
  useDeleteSupplier,
  useSuppliers,
  useUpdateSupplier,
  type Supplier,
  type SupplierArea,
  type SupplierStatus,
} from "@/hooks/use-suppliers";
import { validarCnpjFornecedor } from "@/lib/documento-fornecedor";
import { mascararCnpj, mascararSalvo, mascararTelefoneBr } from "@/lib/mascara-campo";
import { validarTelefoneBr } from "@/lib/whatsapp";
import { formatarCnpj } from "@/lib/cnpj";

export const Route = createFileRoute("/_authenticated/app/fornecedores")({
  component: FornecedoresPage,
});

const MANAGER_ROLES = ["owner", "admin", "manager"];

const AREA_VALUES = SUPPLIER_AREAS.map((a) => a.value) as [SupplierArea, ...SupplierArea[]];
const STATUS_VALUES = SUPPLIER_STATUSES.map((s) => s.value) as [
  SupplierStatus,
  ...SupplierStatus[],
];

const supplierSchema = z.object({
  codigo: z.string().trim().max(64).optional().or(z.literal("")),
  nome: z.string().trim().min(1, "Nome obrigatório").max(120),
  area: z.enum(AREA_VALUES),
  vendedor_contato: z.string().trim().max(120).optional().or(z.literal("")),
  prazo_entrega: z.string().trim().max(120).optional().or(z.literal("")),
  produtos_fornecidos: z.string().trim().max(2000).optional().or(z.literal("")),
  endereco: z.string().trim().max(255).optional().or(z.literal("")),
  cidade: z.string().trim().max(120).optional().or(z.literal("")),
  observacoes: z.string().trim().max(1000).optional().or(z.literal("")),
  status: z.enum(STATUS_VALUES),
});

type SupplierFormValues = {
  codigo: string;
  nome: string;
  area: SupplierArea;
  cnpj: string;
  telefone: string;
  whatsapp: string;
  vendedor_contato: string;
  prazo_entrega: string;
  produtos_fornecidos: string;
  endereco: string;
  cidade: string;
  observacoes: string;
  status: SupplierStatus;
};

function blankForm(): SupplierFormValues {
  return {
    codigo: "",
    nome: "",
    area: "geral",
    cnpj: "",
    telefone: "",
    whatsapp: "",
    vendedor_contato: "",
    prazo_entrega: "",
    produtos_fornecidos: "",
    endereco: "",
    cidade: "",
    observacoes: "",
    status: "ativo",
  };
}

function rowToForm(row: Supplier): SupplierFormValues {
  return {
    codigo: row.codigo ?? "",
    nome: row.nome,
    area: row.area,
    cnpj: mascararSalvo(row.cnpj, mascararCnpj),
    telefone: mascararSalvo(row.telefone, mascararTelefoneBr),
    whatsapp: mascararSalvo(row.whatsapp, mascararTelefoneBr),
    vendedor_contato: row.vendedor_contato ?? "",
    prazo_entrega: row.prazo_entrega ?? "",
    produtos_fornecidos: row.produtos_fornecidos ?? "",
    endereco: row.endereco ?? "",
    cidade: row.cidade ?? "",
    observacoes: row.observacoes ?? "",
    status: row.status,
  };
}

function exportCsv(rows: Supplier[]) {
  const header = [
    "codigo",
    "nome",
    "area",
    "cnpj",
    "telefone",
    "whatsapp",
    "vendedor_contato",
    "prazo_entrega",
    "produtos_fornecidos",
    "endereco",
    "cidade",
    "observacoes",
    "status",
  ];
  const esc = (v: string | null | undefined) => {
    const s = String(v ?? "");
    return s.includes(",") || s.includes('"') || s.includes("\n")
      ? `"${s.replace(/"/g, '""')}"`
      : s;
  };
  const lines = [
    header.join(","),
    ...rows.map((r) =>
      [
        r.codigo,
        r.nome,
        r.area,
        r.cnpj ? formatarCnpj(r.cnpj) : "",
        r.telefone,
        r.whatsapp,
        r.vendedor_contato,
        r.prazo_entrega,
        r.produtos_fornecidos,
        r.endereco,
        r.cidade,
        r.observacoes,
        r.status,
      ]
        .map(esc)
        .join(","),
    ),
  ];
  const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "fornecedores.csv";
  a.click();
  URL.revokeObjectURL(url);
}

function FornecedoresPage() {
  const { isAdmin } = useAuth();
  const { companyRole } = useCompany();
  const canEdit = isAdmin || MANAGER_ROLES.includes(companyRole ?? "");

  const [query, setQuery] = useState("");
  const [areaFiltro, setAreaFiltro] = useState("Todas");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Supplier | null>(null);
  const [confirmDel, setConfirmDel] = useState<Supplier | null>(null);
  const [duplicateSeed, setDuplicateSeed] = useState<SupplierFormValues | null>(null);

  const { data: fornecedores = [], isLoading, isError, refetch, hasActiveCompany } = useSuppliers(
    query,
    areaFiltro,
  );
  const create = useCreateSupplier();
  const update = useUpdateSupplier();
  const remove = useDeleteSupplier();

  const highlight = useMemo(
    () => ["codigo", "cnpj", "telefone", "whatsapp", "vendedor_contato", "prazo_entrega"] as const,
    [],
  );

  const onSave = (values: SupplierFormValues) => {
    const input = toSupplierInput(values);
    if (editing) {
      update.mutate(
        { id: editing.id, input },
        {
          onSuccess: () => {
            toast.success("Fornecedor atualizado");
            setFormOpen(false);
            setEditing(null);
          },
          onError: (e) =>
            toast.error(e instanceof Error ? e.message : supplierErrorMessage(e)),
        },
      );
    } else {
      create.mutate(input, {
        onSuccess: () => {
          toast.success("Fornecedor cadastrado");
          setFormOpen(false);
        },
        onError: (e) => toast.error(e instanceof Error ? e.message : supplierErrorMessage(e)),
      });
    }
  };

  const onDuplicate = (row: Supplier) => {
    if (!canEdit) return;
    setEditing(null);
    setFormOpen(true);
    const base = rowToForm(row);
    setDuplicateSeed({
      ...base,
      codigo: base.codigo ? `${base.codigo}-COPIA` : "",
      nome: `${base.nome} (cópia)`,
    });
  };

  const openNew = () => {
    setEditing(null);
    setDuplicateSeed(null);
    setFormOpen(true);
  };

  const openEdit = (row: Supplier) => {
    setEditing(row);
    setDuplicateSeed(null);
    setFormOpen(true);
  };

  const saving = create.isPending || update.isPending;

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <Badge variant="outline" className="mb-2">
            Compras
          </Badge>
          <h1 className="font-display text-3xl font-bold">Fornecedores</h1>
          <p className="text-sm text-muted-foreground">
            {hasActiveCompany
              ? `${fornecedores.length} cadastrados · CNPJ, telefone, WhatsApp, vendedor, prazo e produtos`
              : "Nenhuma empresa ativa"}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            disabled={!hasActiveCompany || fornecedores.length === 0}
            onClick={() => exportCsv(fornecedores)}
          >
            <Download className="mr-2 h-4 w-4" /> Exportar CSV
          </Button>
          <Button size="sm" disabled={!hasActiveCompany || !canEdit} onClick={openNew}>
            {!canEdit ? <Lock className="mr-2 h-4 w-4" /> : <Plus className="mr-2 h-4 w-4" />}
            Novo
          </Button>
        </div>
      </div>

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="flex min-w-[200px] flex-1 items-center gap-2 rounded-lg border bg-card px-3 py-2">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar fornecedor..."
            disabled={!hasActiveCompany}
            className="flex-1 bg-transparent text-sm outline-none disabled:cursor-not-allowed"
          />
        </div>
        <Select value={areaFiltro} onValueChange={setAreaFiltro} disabled={!hasActiveCompany}>
          <SelectTrigger className="w-[180px]">
            <Filter className="mr-2 h-4 w-4" />
            <SelectValue placeholder="Área" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Todas">Todas as áreas</SelectItem>
            {SUPPLIER_AREAS.map((a) => (
              <SelectItem key={a.value} value={a.value}>
                {a.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {!hasActiveCompany ? (
        <div className="rounded-2xl border bg-card p-12 text-center">
          <Building2 className="mx-auto h-10 w-10 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">
            Selecione ou crie uma empresa para gerenciar fornecedores.
          </p>
        </div>
      ) : isLoading ? (
        <p className="text-muted-foreground">Carregando...</p>
      ) : isError ? (
        <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-8 text-center">
          <AlertTriangle className="mx-auto h-8 w-8 text-destructive" />
          <p className="mt-3 text-sm text-muted-foreground">Não foi possível carregar fornecedores.</p>
          <Button variant="outline" className="mt-4" onClick={() => refetch()}>
            Tentar novamente
          </Button>
        </div>
      ) : (
        <Tabs defaultValue="cards">
          <TabsList>
            <TabsTrigger value="cards">Cards</TabsTrigger>
            <TabsTrigger value="table">Tabela</TabsTrigger>
          </TabsList>
          <TabsContent value="cards" className="mt-4">
            {fornecedores.length === 0 ? (
              <div className="rounded-2xl border bg-card p-12 text-center">
                <Truck className="mx-auto h-10 w-10 text-muted-foreground" />
                <p className="mt-3 text-sm text-muted-foreground">
                  {query || areaFiltro !== "Todas"
                    ? "Nenhum fornecedor encontrado para os filtros."
                    : "Nenhum fornecedor ainda. Cadastre o primeiro."}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
                {fornecedores.map((f) => (
                  <Card key={f.id} className="group relative">
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between gap-2">
                        <CardTitle className="text-base">{f.nome}</CardTitle>
                        <Badge variant="secondary">{supplierAreaLabel(f.area)}</Badge>
                      </div>
                      {f.codigo && (
                        <p className="text-xs text-muted-foreground">Código: {f.codigo}</p>
                      )}
                    </CardHeader>
                    <CardContent className="space-y-1 text-xs text-muted-foreground">
                      {highlight.map((key) => {
                        const val =
                          key === "cnpj" && f.cnpj
                            ? formatarCnpj(f.cnpj)
                            : (f[key as keyof Supplier] as string | null);
                        if (!val) return null;
                        const label =
                          key === "vendedor_contato"
                            ? "Vendedor"
                            : key.charAt(0).toUpperCase() + key.slice(1).replace("_", " ");
                        return (
                          <p key={key}>
                            <span className="font-medium text-foreground">{label}:</span> {val}
                          </p>
                        );
                      })}
                      <p className="pt-1">
                        <Badge variant="outline">{supplierStatusLabel(f.status)}</Badge>
                      </p>
                    </CardContent>
                    {canEdit && (
                      <div className="absolute right-3 top-3 flex gap-1 opacity-0 transition group-hover:opacity-100">
                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => openEdit(f)}>
                          <Edit className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => onDuplicate(f)}>
                          <Copy className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 text-destructive"
                          onClick={() => setConfirmDel(f)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
          <TabsContent value="table" className="mt-4">
            <div className="overflow-x-auto rounded-xl border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Código</TableHead>
                    <TableHead>Fornecedor</TableHead>
                    <TableHead>Área</TableHead>
                    <TableHead>CNPJ</TableHead>
                    <TableHead>Telefone</TableHead>
                    <TableHead>WhatsApp</TableHead>
                    <TableHead>Vendedor</TableHead>
                    <TableHead>Prazo</TableHead>
                    <TableHead>Status</TableHead>
                    {canEdit && <TableHead className="w-[120px]">Ações</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {fornecedores.map((f) => (
                    <TableRow key={f.id}>
                      <TableCell>{f.codigo ?? "—"}</TableCell>
                      <TableCell className="font-medium">{f.nome}</TableCell>
                      <TableCell>{supplierAreaLabel(f.area)}</TableCell>
                      <TableCell>{f.cnpj ? formatarCnpj(f.cnpj) : "—"}</TableCell>
                      <TableCell>{f.telefone ?? "—"}</TableCell>
                      <TableCell>{f.whatsapp ?? "—"}</TableCell>
                      <TableCell>{f.vendedor_contato ?? "—"}</TableCell>
                      <TableCell>{f.prazo_entrega ?? "—"}</TableCell>
                      <TableCell>{supplierStatusLabel(f.status)}</TableCell>
                      {canEdit && (
                        <TableCell>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(f)}>
                              <Edit className="h-3.5 w-3.5" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onDuplicate(f)}>
                              <Copy className="h-3.5 w-3.5" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-destructive"
                              onClick={() => setConfirmDel(f)}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        </Tabs>
      )}

      {formOpen && (
        <SupplierFormDialog
          title={editing ? "Editar fornecedor" : "Novo fornecedor"}
          submitLabel={editing ? "Salvar" : "Cadastrar"}
          initial={editing ? rowToForm(editing) : duplicateSeed ?? blankForm()}
          onClose={() => {
            setFormOpen(false);
            setEditing(null);
            setDuplicateSeed(null);
          }}
          onSubmit={onSave}
          loading={saving}
        />
      )}

      {confirmDel && (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4"
          onClick={() => setConfirmDel(null)}
        >
          <div
            className="w-full max-w-sm rounded-2xl bg-card p-6 shadow-elegant"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="font-display text-lg font-bold">Excluir fornecedor?</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Tem certeza que deseja excluir <strong>{confirmDel.nome}</strong>? Itens de estoque
              vinculados terão o vínculo removido (texto legado permanece).
            </p>
            <div className="mt-4 flex justify-end gap-2">
              <Button variant="outline" onClick={() => setConfirmDel(null)}>
                Cancelar
              </Button>
              <Button
                variant="destructive"
                disabled={remove.isPending}
                onClick={() =>
                  remove.mutate(confirmDel.id, {
                    onSuccess: () => {
                      toast.success("Fornecedor removido");
                      setConfirmDel(null);
                    },
                    onError: (e) => toast.error(supplierErrorMessage(e)),
                  })
                }
              >
                {remove.isPending ? "Excluindo..." : "Excluir"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SupplierFormDialog({
  title,
  submitLabel,
  initial,
  onClose,
  onSubmit,
  loading,
}: {
  title: string;
  submitLabel: string;
  initial: SupplierFormValues;
  onClose: () => void;
  onSubmit: (v: SupplierFormValues) => void;
  loading: boolean;
}) {
  const [form, setForm] = useState<SupplierFormValues>(initial);
  const formRef = useRef<HTMLFormElement>(null);

  const validar = (): { ok: true; values: SupplierFormValues } | { ok: false; erro: string } => {
    const parsed = supplierSchema.safeParse(form);
    if (!parsed.success) return { ok: false, erro: parsed.error.issues[0].message };

    const cnpj = validarCnpjFornecedor(form.cnpj);
    if (!cnpj.ok) return { ok: false, erro: cnpj.erro };

    let telefone = "";
    if (form.telefone.trim()) {
      const tel = validarTelefoneBr(form.telefone);
      if (!tel.ok) return { ok: false, erro: tel.erro };
      telefone = form.telefone.trim().slice(0, 20);
    }

    let whatsapp = "";
    if (form.whatsapp.trim()) {
      const w = validarTelefoneBr(form.whatsapp);
      if (!w.ok) return { ok: false, erro: w.erro };
      whatsapp = form.whatsapp.trim().slice(0, 20);
    }

    return {
      ok: true,
      values: {
        ...form,
        nome: form.nome.trim(),
        cnpj: cnpj.cnpj ?? "",
        telefone,
        whatsapp,
      },
    };
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const r = validar();
    if (!r.ok) {
      toast.error(r.erro);
      return;
    }
    onSubmit(r.values);
  };

  const inp =
    "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring";

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/50 p-4" onClick={onClose}>
      <div
        className="mx-auto my-8 w-full max-w-3xl rounded-2xl bg-card p-6 shadow-elegant"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="font-display text-xl font-bold">{title}</h2>
        <form ref={formRef} onSubmit={handleSubmit} className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
          <label className="col-span-2 block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">Código</span>
            <Input value={form.codigo} onChange={(e) => setForm({ ...form, codigo: e.target.value })} />
          </label>
          <label className="col-span-2 block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">Fornecedor *</span>
            <Input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} required />
          </label>
          <label className="col-span-2 block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">Área</span>
            <Select value={form.area} onValueChange={(v) => setForm({ ...form, area: v as SupplierArea })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SUPPLIER_AREAS.map((a) => (
                  <SelectItem key={a.value} value={a.value}>
                    {a.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </label>
          <label className="col-span-2 block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">Status</span>
            <Select
              value={form.status}
              onValueChange={(v) => setForm({ ...form, status: v as SupplierStatus })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SUPPLIER_STATUSES.map((s) => (
                  <SelectItem key={s.value} value={s.value}>
                    {s.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </label>
          <label className="col-span-2 block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">CNPJ</span>
            <CampoMascarado
              value={form.cnpj}
              onChange={(v) => setForm({ ...form, cnpj: v })}
              mascara={mascararCnpj}
              placeholder="00.000.000/0000-00"
              className={inp}
            />
          </label>
          <label className="col-span-2 block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">Telefone</span>
            <CampoMascarado
              value={form.telefone}
              onChange={(v) => setForm({ ...form, telefone: v })}
              mascara={mascararTelefoneBr}
              placeholder="(00) 0000-0000"
              className={inp}
            />
          </label>
          <label className="col-span-2 block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">WhatsApp</span>
            <CampoMascarado
              value={form.whatsapp}
              onChange={(v) => setForm({ ...form, whatsapp: v })}
              mascara={mascararTelefoneBr}
              placeholder="(00) 90000-0000"
              className={inp}
            />
          </label>
          <label className="col-span-2 block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">Vendedor</span>
            <Input
              value={form.vendedor_contato}
              onChange={(e) => setForm({ ...form, vendedor_contato: e.target.value })}
            />
          </label>
          <label className="col-span-2 block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">Prazo entrega</span>
            <Input
              value={form.prazo_entrega}
              onChange={(e) => setForm({ ...form, prazo_entrega: e.target.value })}
            />
          </label>
          <label className="col-span-4 block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">Endereço</span>
            <Input value={form.endereco} onChange={(e) => setForm({ ...form, endereco: e.target.value })} />
          </label>
          <label className="col-span-2 block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">Cidade</span>
            <Input value={form.cidade} onChange={(e) => setForm({ ...form, cidade: e.target.value })} />
          </label>
          <label className="col-span-4 block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">Produtos fornecidos</span>
            <Textarea
              value={form.produtos_fornecidos}
              onChange={(e) => setForm({ ...form, produtos_fornecidos: e.target.value })}
              rows={2}
            />
          </label>
          <label className="col-span-4 block text-sm">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">Observações</span>
            <Textarea
              value={form.observacoes}
              onChange={(e) => setForm({ ...form, observacoes: e.target.value })}
              rows={2}
            />
          </label>
          <div className="col-span-4 mt-2 flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Salvando..." : submitLabel}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
