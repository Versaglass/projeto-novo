import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { brl, dateBR, statusLabel, statusTone } from "@/lib/format";
import { ArrowLeft, FileText, Phone, Mail, MapPin, Plus } from "lucide-react";
import { useClient } from "@/hooks/use-clients";

export const Route = createFileRoute("/_authenticated/app/clientes/$id")({
  component: ClienteDetalhe,
});

function ClienteDetalhe() {
  const { id } = Route.useParams();
  const navigate = useNavigate();

  // Cliente escopado à empresa ativa (isolamento multiempresa).
  const { data: cliente, isLoading } = useClient(id);
  // Histórico de orçamentos do cliente (somente leitura; a RLS de `quotes` limita
  // o acesso). Só consulta depois que o cliente é confirmado na empresa ativa.
  const { data: quotes = [] } = useQuery({
    queryKey: ["client-quotes", id],
    enabled: !!cliente,
    queryFn: async () => {
      const { data } = await supabase
        .from("quotes")
        .select("*")
        .eq("customer_id", id)
        .order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  if (isLoading) return <p>Carregando...</p>;
  if (!cliente) return <p>Cliente não encontrado.</p>;
  const c = cliente;

  return (
    <div>
      <Link
        to="/app/clientes"
        className="mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> Voltar
      </Link>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-1">
          <div className="rounded-2xl border bg-card p-6">
            <h1 className="font-display text-2xl font-bold">{c.nome}</h1>
            {c.documento && <p className="text-sm text-muted-foreground">{c.documento}</p>}
            <div className="mt-4 space-y-2 text-sm">
              {c.telefone && (
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  {c.telefone}
                </div>
              )}
              {c.email && (
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  {c.email}
                </div>
              )}
              {(c.endereco || c.cidade) && (
                <div className="flex items-start gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <span>{[c.endereco, c.cidade].filter(Boolean).join(", ")}</span>
                </div>
              )}
            </div>
            {c.observacoes && (
              <p className="mt-4 rounded-lg bg-muted p-3 text-sm">{c.observacoes}</p>
            )}
            <button
              onClick={() =>
                navigate({ to: "/app/orcamentos/novo", search: { cliente: id } as any })
              }
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground"
            >
              <Plus className="h-4 w-4" /> Novo orçamento
            </button>
          </div>
        </div>

        <div className="md:col-span-2">
          <h2 className="mb-3 font-display text-lg font-semibold">Histórico de orçamentos</h2>
          {quotes.length === 0 ? (
            <div className="rounded-2xl border bg-card p-8 text-center text-sm text-muted-foreground">
              <FileText className="mx-auto mb-2 h-8 w-8" />
              Nenhum orçamento para este cliente.
            </div>
          ) : (
            <div className="divide-y rounded-2xl border bg-card">
              {quotes.map((q: any) => (
                <Link
                  key={q.id}
                  to="/app/orcamentos/$id"
                  params={{ id: q.id }}
                  className="flex items-center justify-between p-4 hover:bg-muted/50"
                >
                  <div>
                    <div className="font-semibold">#{q.numero}</div>
                    <div className="text-xs text-muted-foreground">{dateBR(q.created_at)}</div>
                  </div>
                  <span className={`rounded-full px-2 py-0.5 text-xs ${statusTone[q.status]}`}>
                    {statusLabel[q.status]}
                  </span>
                  <div className="font-display font-semibold">{brl(Number(q.total))}</div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
