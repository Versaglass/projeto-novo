import { createFileRoute, Link, Outlet, useChildMatches } from "@tanstack/react-router";
import { useState } from "react";
import { brl, num } from "@/lib/format";
import {
  ArrowLeft,
  FileDown,
  AlertTriangle,
  Loader2,
  User,
  Package,
  Receipt,
  Ban,
  Printer,
} from "lucide-react";
import { toast } from "sonner";
import {
  useSaleDetail,
  pagamentoLabel,
  saleErrorMessage,
  SALE_STATUS_META,
  canCancelSale,
  type SaleDocument,
} from "@/hooks/use-sales";
import { generateSalePdf } from "@/lib/sale-pdf";
import { CancelSaleDialog } from "@/components/CancelSaleDialog";
import { useCompany } from "@/contexts/company-context";

/**
 * DETALHE DE UMA VENDA — `/app/vendas/$id`. Somente leitura, por desenho.
 *
 * Rota-filha de `app.vendas.tsx`, no mesmo arranjo que `app.orcamentos.$id.tsx`
 * tem com a listagem de Orçamentos. Ter URL própria não é enfeite: é o que
 * permite recarregar a página, guardar o link e voltar a uma venda específica
 * meses depois — que era exatamente a lacuna que a Revisão 87 deixou aberta.
 *
 * Tudo que aparece aqui vem de `fetchSaleDocument`, a MESMA leitura que
 * alimenta o PDF. A tela e a nota não têm como divergir.
 *
 * Filho `/comprovante`: prévia térmica (Outlet) — layout deste arquivo não monta.
 */
export const Route = createFileRoute("/_authenticated/app/vendas/$id")({
  component: VendaIdLayout,
});

function VendaIdLayout() {
  const childMatches = useChildMatches();
  if (childMatches.length > 0) return <Outlet />;
  return <VendaDetalhe />;
}

const UNIDADE_LABEL: Record<string, string> = {
  m: "m",
  m2: "m²",
  un: "un",
  kg: "kg",
  pc: "pç",
  cx: "cx",
};

function VendaDetalhe() {
  const { id } = Route.useParams();
  const { isCompanyAdmin } = useCompany();
  const { data, isLoading, isError, refetch } = useSaleDetail(id);
  const [gerando, setGerando] = useState(false);
  const [cancelar, setCancelar] = useState(false);

  const gerarPdf = async (documento: SaleDocument) => {
    setGerando(true);
    try {
      // Mesma função da Revisão 87 e da listagem — uma nota só no projeto.
      await generateSalePdf(documento);
      toast.success(`Nota da venda nº ${documento.sale.numero} gerada.`);
    } catch (e) {
      console.error("[venda] falha ao gerar o PDF", e);
      toast.error(saleErrorMessage(e));
    } finally {
      setGerando(false);
    }
  };

  if (isLoading) return <p className="text-muted-foreground">Carregando...</p>;

  // Venda inexistente e venda de OUTRA empresa caem no mesmo lugar, de
  // propósito: a RLS não devolve linha nenhuma nos dois casos, e distinguir
  // "não existe" de "não é sua" contaria ao curioso que o id existe.
  if (isError || !data) {
    return (
      <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-8 text-center">
        <AlertTriangle className="mx-auto h-8 w-8 text-destructive" />
        <p className="mt-3 text-sm text-muted-foreground">Venda não encontrada nesta empresa.</p>
        <div className="mt-4 flex justify-center gap-2">
          <button
            onClick={() => refetch()}
            className="rounded-lg border border-input px-4 py-2 text-sm font-medium hover:bg-accent"
          >
            Tentar novamente
          </button>
          <Link
            to="/app/vendas"
            className="rounded-lg border border-input px-4 py-2 text-sm font-medium hover:bg-accent"
          >
            Voltar para as vendas
          </Link>
        </div>
      </div>
    );
  }

  const { sale, items, customer } = data;
  const comprador = customer?.nome ?? sale.cliente_nome ?? "Sem identificação";
  const avulsa = !customer;
  const statusMeta = SALE_STATUS_META[sale.status] ?? SALE_STATUS_META.finalizada;
  const cancelada = sale.status === "cancelada";

  return (
    <div className={`space-y-6 ${cancelada ? "opacity-90" : ""}`}>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <Link
            to="/app/vendas"
            className="mb-2 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" /> Vendas
          </Link>
          <div className="flex flex-wrap items-center gap-3">
            <h1
              className={`font-display text-3xl font-bold ${cancelada ? "line-through decoration-muted-foreground/60" : ""}`}
            >
              Venda #{sale.numero}
            </h1>
            <span className={`rounded-full px-2 py-0.5 text-xs ${statusMeta.tone}`}>
              {statusMeta.label}
            </span>
          </div>
          <p className="text-sm text-muted-foreground">
            {new Date(sale.created_at).toLocaleString("pt-BR")} ·{" "}
            {pagamentoLabel(sale.forma_pagamento)}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {isCompanyAdmin && canCancelSale(sale.status) && (
            <button
              type="button"
              onClick={() => setCancelar(true)}
              className="inline-flex items-center gap-2 rounded-lg border border-destructive/30 bg-background px-4 py-2 text-sm font-semibold text-destructive hover:bg-destructive/10"
            >
              <Ban className="h-4 w-4" />
              Cancelar venda
            </button>
          )}
          <Link
            to="/app/vendas/$id/comprovante"
            params={{ id: sale.id }}
            className="inline-flex items-center gap-2 rounded-lg border border-input bg-background px-4 py-2 text-sm font-semibold hover:bg-accent"
          >
            <Printer className="h-4 w-4" />
            Imprimir comprovante
          </Link>
          <button
            onClick={() => gerarPdf(data)}
            disabled={gerando}
            className="inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground shadow-glow disabled:opacity-60"
          >
            {gerando ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <FileDown className="h-4 w-4" />
            )}
            Gerar PDF novamente
          </button>
        </div>
      </div>

      {cancelada && sale.motivo_cancelamento && (
        <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-4">
          <div className="text-xs font-semibold uppercase tracking-wider text-destructive">
            Cancelamento
          </div>
          <p className="mt-1 text-sm">{sale.motivo_cancelamento}</p>
          {sale.cancelada_em && (
            <p className="mt-1 text-xs text-muted-foreground">
              Em {new Date(sale.cancelada_em).toLocaleString("pt-BR")}
            </p>
          )}
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl border bg-card p-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <User className="h-3.5 w-3.5" /> Cliente
          </div>
          <div className="mt-1 font-display text-lg font-bold">{comprador}</div>
          {avulsa && (
            <div className="mt-1 text-xs text-muted-foreground">
              Venda avulsa — sem cliente cadastrado.
            </div>
          )}
          {customer && (
            <div className="mt-1 space-y-0.5 text-xs text-muted-foreground">
              {customer.telefone && <div>{customer.telefone}</div>}
              {customer.email && <div className="truncate">{customer.email}</div>}
            </div>
          )}
        </div>
        <div className="rounded-2xl border bg-card p-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Package className="h-3.5 w-3.5" /> Itens
          </div>
          <div className="mt-1 font-display text-3xl font-bold">{items.length}</div>
        </div>
        <div className="rounded-2xl border bg-card p-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Receipt className="h-3.5 w-3.5" /> Total
          </div>
          <div className="mt-1 font-display text-3xl font-bold text-gold">
            {brl(Number(sale.total))}
          </div>
        </div>
      </div>

      <div className="overflow-x-auto rounded-2xl border bg-card">
        <table className="w-full min-w-[760px] text-sm">
          <thead className="border-b bg-muted/50 text-left text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Descrição</th>
              <th className="px-4 py-3">Medida</th>
              <th className="px-4 py-3 text-right">Qtd</th>
              <th className="px-4 py-3 text-right">Preço unit.</th>
              <th className="px-4 py-3 text-right">Desc.</th>
              <th className="px-4 py-3 text-right">Baixa no estoque</th>
              <th className="px-4 py-3 text-right">Subtotal</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {items.map((item, idx) => {
              const un = UNIDADE_LABEL[item.unidade] ?? item.unidade;
              const l = Number(item.largura) || 0;
              const a = Number(item.altura) || 0;
              const baixa = Number(item.quantidade_baixa) || 0;
              return (
                <tr key={idx}>
                  <td className="px-4 py-3 font-medium">{item.descricao}</td>
                  <td className="px-4 py-3 text-muted-foreground">
                    {l > 0 && a > 0 ? `${num(l, 3)} × ${num(a, 3)} m` : "—"}
                  </td>
                  <td className="px-4 py-3 text-right">
                    {item.unidade === "m2"
                      ? `${num(Number(item.m2), 4)} m²`
                      : `${num(Number(item.quantidade), 2)} ${un}`}
                  </td>
                  <td className="px-4 py-3 text-right">{brl(Number(item.preco_unit))}</td>
                  <td className="px-4 py-3 text-right text-muted-foreground">
                    {Number(item.desconto) > 0 ? brl(Number(item.desconto)) : "—"}
                  </td>
                  <td className="px-4 py-3 text-right text-muted-foreground">
                    {/* `quantidade_baixa = 0` é item AVULSO, não erro: a RPC só
                        debita o que veio do catálogo. Dizer "avulso" evita que
                        alguém leia o zero como baixa que falhou. */}
                    {baixa > 0 ? `${num(baixa, 4)} ${un}` : "avulso (não baixou)"}
                  </td>
                  <td className="px-4 py-3 text-right font-display font-semibold">
                    {brl(Number(item.subtotal))}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="flex flex-col items-end gap-1 rounded-2xl border bg-card p-4 text-sm">
        <div className="flex w-full max-w-xs justify-between">
          <span className="text-muted-foreground">Subtotal</span>
          <span>{brl(Number(sale.subtotal))}</span>
        </div>
        {Number(sale.desconto) > 0 && (
          <div className="flex w-full max-w-xs justify-between">
            <span className="text-muted-foreground">Desconto</span>
            <span>- {brl(Number(sale.desconto))}</span>
          </div>
        )}
        {Number(sale.acrescimo) > 0 && (
          <div className="flex w-full max-w-xs justify-between">
            <span className="text-muted-foreground">Acréscimo</span>
            <span>{brl(Number(sale.acrescimo))}</span>
          </div>
        )}
        <div className="flex w-full max-w-xs justify-between border-t pt-1 font-display text-lg font-bold">
          <span>Total</span>
          <span className="text-gold">{brl(Number(sale.total))}</span>
        </div>
      </div>

      {sale.observacoes && (
        <div className="rounded-2xl border bg-card p-4">
          <div className="text-xs text-muted-foreground">Observações</div>
          <p className="mt-1 whitespace-pre-wrap text-sm">{sale.observacoes}</p>
        </div>
      )}

      <div className="flex items-start gap-3 rounded-2xl border border-muted bg-muted/30 p-4">
        <Receipt className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
        <p className="text-sm text-muted-foreground">
          {cancelada ? (
            <>
              Esta venda foi cancelada e o estoque foi estornado. O registro permanece no histórico
              para conferência.
            </>
          ) : (
            <>
              Venda concluída com estoque já baixado.{" "}
              {isCompanyAdmin ? (
                <>
                  Como <strong className="text-foreground">owner ou admin</strong>, você pode
                  cancelá-la — o estoque será creditado automaticamente.
                </>
              ) : (
                <>
                  Somente <strong className="text-foreground">owner ou admin</strong> pode cancelar
                  com estorno de estoque.
                </>
              )}
            </>
          )}
        </p>
      </div>

      {cancelar && (
        <CancelSaleDialog
          open
          saleId={sale.id}
          saleNumero={sale.numero}
          onOpenChange={(open) => {
            if (!open) setCancelar(false);
          }}
        />
      )}
    </div>
  );
}
