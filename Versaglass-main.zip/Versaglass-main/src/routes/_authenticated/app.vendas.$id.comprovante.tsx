import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Printer, AlertTriangle, Loader2 } from "lucide-react";
import { useSaleDetail } from "@/hooks/use-sales";
import { loadSaleReceiptCompany } from "@/lib/sale-receipt";
import { SaleReceipt } from "@/components/sales/SaleReceipt";

/**
 * Prévia + impressão do comprovante térmico (80 mm) — NÃO É DOCUMENTO FISCAL.
 *
 * Lê a venda persistida por id (+ company_id ativo via useSaleDetail/RLS).
 * Reimpressão não altera estoque, pagamento nem status.
 */
export const Route = createFileRoute("/_authenticated/app/vendas/$id/comprovante")({
  component: SaleReceiptPage,
});

function SaleReceiptPage() {
  const { id } = Route.useParams();
  const { data, isLoading, isError, refetch } = useSaleDetail(id);
  const companyId = data?.sale.company_id ?? null;

  const companyQuery = useQuery({
    queryKey: ["sale-receipt-company", companyId],
    enabled: !!companyId,
    queryFn: () => loadSaleReceiptCompany(companyId),
  });

  const imprimir = () => {
    window.print();
  };

  if (isLoading) {
    return (
      <div className="sale-receipt-print-root flex min-h-[50vh] items-center justify-center">
        <p className="sale-receipt-no-print text-muted-foreground">Carregando comprovante...</p>
      </div>
    );
  }

  if (isError || !data) {
    return (
      <div className="sale-receipt-print-root rounded-2xl border border-destructive/30 bg-destructive/5 p-8 text-center">
        <AlertTriangle className="sale-receipt-no-print mx-auto h-8 w-8 text-destructive" />
        <p className="sale-receipt-no-print mt-3 text-sm text-muted-foreground">
          Venda não encontrada nesta empresa.
        </p>
        <div className="sale-receipt-no-print mt-4 flex justify-center gap-2">
          <button
            type="button"
            onClick={() => refetch()}
            className="rounded-lg border border-input px-4 py-2 text-sm font-medium hover:bg-accent"
          >
            Tentar novamente
          </button>
          <Link
            to="/app/vendas"
            className="rounded-lg border border-input px-4 py-2 text-sm font-medium hover:bg-accent"
          >
            Voltar
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="sale-receipt-print-root -mx-4 -my-6 md:-mx-8 md:-my-10">
      <div className="sale-receipt-no-print sticky top-0 z-10 border-b border-border bg-background/95 px-4 py-3 backdrop-blur md:px-8">
        <div className="mx-auto flex max-w-3xl flex-wrap items-center justify-between gap-3">
          <Link
            to="/app/vendas/$id"
            params={{ id }}
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" /> Voltar
          </Link>
          <button
            type="button"
            onClick={imprimir}
            className="inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground shadow-glow"
          >
            <Printer className="h-4 w-4" /> Imprimir
          </button>
        </div>
      </div>

      <div className="bg-muted/40 px-4 py-8 md:px-8 print:bg-transparent print:p-0">
        <p className="sale-receipt-no-print mx-auto mb-4 max-w-[80mm] text-center text-xs text-muted-foreground">
          Prévia do comprovante (80 mm) · NÃO É DOCUMENTO FISCAL
        </p>
        <div className="mx-auto max-w-[80mm] overflow-hidden rounded-sm border border-border bg-white shadow-sm print:max-w-none print:border-0 print:shadow-none">
          {companyQuery.isLoading ? (
            <div className="sale-receipt-no-print flex items-center justify-center gap-2 p-8 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> Carregando empresa...
            </div>
          ) : (
            <SaleReceipt document={data} company={companyQuery.data ?? null} />
          )}
        </div>
      </div>
    </div>
  );
}
