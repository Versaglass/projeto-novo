import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Plus,
  Search,
  Package,
  AlertTriangle,
  Pencil,
  ShoppingCart,
  Trash2,
  ArrowLeft,
  Library,
  Boxes,
  AppWindow,
  Building2,
  type LucideIcon,
} from "lucide-react";
import { toast } from "sonner";
import { brl } from "@/lib/format";
import { InventoryItemThumb } from "@/components/inventory/InventoryItemThumb";
import { InventoryItemDialog } from "@/components/inventory/InventoryItemDialog";
import {
  inventoryFormToInput,
  type InventoryItemDraft,
  type InventoryItemForm,
} from "@/components/inventory/inventory-item-form";
import { useCompany } from "@/contexts/company-context";
import { useAuth } from "@/hooks/use-auth";
import { canManageCompanyEstoque } from "@/lib/inventory-auth";
import {
  useCreateInventoryItem,
  useUpdateInventoryItem,
  useDeleteInventoryItem,
  inventoryErrorMessage,
  categoriaMeta,
  inventoryCategoriesInUiAreas,
  categoriaPertenceAArea,
  ehInventoryUiArea,
  INVENTORY_UI_AREAS,
  type InventoryItem,
  type InventoryUiArea,
} from "@/hooks/use-inventory";
import { useEffectiveInventoryItems } from "@/hooks/use-effective-inventory";
import {
  saveManufacturerProductErrorMessage,
  useSaveManufacturerProductInventory,
} from "@/hooks/use-ensure-manufacturer-inventory";
import {
  canDeleteEffectiveItem,
  effectiveItemToThumb,
  type EffectiveInventoryItem,
} from "@/lib/effective-inventory";
import { ROTULO_AREA } from "@/lib/project-area";
import { draftFromManufacturerProduct } from "@/lib/manufacturer-catalog/adopt";

export const Route = createFileRoute("/_authenticated/app/estoque")({
  component: EstoquePage,
});

const ICONE_AREA_UI: Record<InventoryUiArea, LucideIcon> = {
  vidracaria: Library,
  esquadrias: AppWindow,
  geral: Package,
};

const ROTULO_AREA_ESTOQUE: Record<InventoryUiArea, string> = {
  vidracaria: ROTULO_AREA.vidracaria,
  esquadrias: ROTULO_AREA.esquadrias,
  geral: "Geral",
};

/** Chips de área do Estoque — somente áreas habilitadas na superfície atual. */
const AREAS: ReadonlyArray<{
  value: "all" | InventoryUiArea;
  label: string;
  Icon: LucideIcon;
}> = [
  { value: "all", label: "Todas", Icon: Boxes },
  ...INVENTORY_UI_AREAS.map((value) => ({
    value,
    label: ROTULO_AREA_ESTOQUE[value],
    Icon: ICONE_AREA_UI[value],
  })),
];

/**
 * Cor de cada área nos chips de filtro (Revisão 101).
 *
 * Mesmos matizes dos cards de segmento do cadastro onde aplicável; Esquadrias
 * usa tom próprio (cyan). Geral permanece neutro (slate) — balaio de categorias
 * sem ofício (Colas/Silicones, Outros).
 */
const COR_AREA: Record<string, { inativo: string; ativo: string }> = {
  vidracaria: {
    inativo: "border-blue-500/30 bg-blue-500/10 text-blue-300 hover:bg-blue-500/20",
    ativo: "border-blue-400 bg-blue-500/30 text-blue-100",
  },
  esquadrias: {
    inativo: "border-cyan-500/30 bg-cyan-500/10 text-cyan-300 hover:bg-cyan-500/20",
    ativo: "border-cyan-400 bg-cyan-500/30 text-cyan-100",
  },
  geral: {
    inativo: "border-slate-500/30 bg-slate-500/10 text-slate-300 hover:bg-slate-500/20",
    ativo: "border-slate-400 bg-slate-500/30 text-slate-100",
  },
};

function EstoquePage() {
  const { companyRole } = useCompany();
  const { permissions } = useAuth();

  const [search, setSearch] = useState("");
  const [area, setArea] = useState<string>("all");
  const [cat, setCat] = useState<string>("todas");
  const [incluirInativos, setIncluirInativos] = useState(false);
  const [editing, setEditing] = useState<EffectiveInventoryItem | null>(null);
  const [creating, setCreating] = useState(false);
  const [confirmDel, setConfirmDel] = useState<EffectiveInventoryItem | null>(null);

  // Estado legado / valor inválido (ex. serralheria) → volta para "Todas".
  useEffect(() => {
    if (area !== "all" && !ehInventoryUiArea(area)) {
      setArea("all");
      setCat("todas");
    }
  }, [area]);

  const areaFiltro = area === "all" || ehInventoryUiArea(area) ? area : "all";

  const {
    data: itens = [],
    isLoading,
    isError,
    refetch,
    hasActiveCompany,
    companyLoading,
  } = useEffectiveInventoryItems({ search, categoria: cat, area: areaFiltro, incluirInativos });

  const create = useCreateInventoryItem();
  const update = useUpdateInventoryItem();
  const del = useDeleteInventoryItem();
  const saveGlobal = useSaveManufacturerProductInventory();

  // Alinhado à RLS (can_manage_company_estoque): sem bypass de platform admin.
  const canWriteStock = canManageCompanyEstoque({
    hasActiveCompany,
    companyRole,
    permissions,
  });
  const canManage = (_i: EffectiveInventoryItem) => canWriteStock;

  const totais = useMemo(() => {
    const ativos = itens.filter((i) => i.ativo);
    return {
      cadastrados: itens.length,
      // Valor a CUSTO — é o significado real de `custo_unit`. Não há custo médio
      // nem valorização por outro critério no schema.
      valorCusto: ativos.reduce(
        (s, i) => s + Number(i.quantidade || 0) * Number(i.custo_unit || 0),
        0,
      ),
      abaixoMinimo: ativos.filter(
        (i) => Number(i.estoque_minimo) > 0 && Number(i.quantidade) <= Number(i.estoque_minimo),
      ).length,
    };
  }, [itens]);

  // `areaStats` foi removido na Revisão 100 junto com os números que ele
  // alimentava. Ele somava por área a partir de `itens` — que já chega filtrado
  // por área da consulta —, então com um filtro ativo devolvia zero para as
  // outras quatro. Sem quem exiba o resultado, o cálculo era só trabalho por
  // tecla. As áreas agora saem direto de `AREAS`.

  const catCounts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const i of itens) {
      if (!i.categoria) continue;
      c[i.categoria] = (c[i.categoria] ?? 0) + 1;
    }
    return c;
  }, [itens]);

  const editingDraft: InventoryItemDraft | null = useMemo(() => {
    if (!editing || editing.source !== "global") return null;
    // Sem fallback: se o global não tem categoria/unidade, o dialog exige escolha.
    return draftFromManufacturerProduct({
      name: editing.nome,
      description: editing.descricao,
      source_code: editing.sku ?? "",
      inventory_category: editing.categoria,
      unit: editing.unidade,
    });
  }, [editing]);

  const onSubmit = (form: InventoryItemForm) => {
    const input = inventoryFormToInput(form);

    if (editing) {
      if (editing.source === "global" && editing.manufacturerProductId) {
        // Materialização ATÔMICA — sem ensure + update parcial.
        saveGlobal.mutate(
          { manufacturerProductId: editing.manufacturerProductId, form: input },
          {
            onSuccess: ({ created }) => {
              if (created) {
                toast.success("Item atualizado");
              } else {
                toast.message(
                  "Este produto já estava no estoque (outra ação sincronizou primeiro). Lista atualizada.",
                );
              }
              setEditing(null);
            },
            onError: (e) =>
              toast.error(e instanceof Error ? e.message : saveManufacturerProductErrorMessage(e)),
          },
        );
        return;
      }

      if (!editing.inventoryItemId) {
        toast.error("Item inválido para edição.");
        return;
      }

      update.mutate(
        {
          id: editing.inventoryItemId,
          input,
          previousImage: editing.imagem_url,
        },
        {
          onSuccess: () => {
            toast.success("Item atualizado");
            setEditing(null);
          },
          onError: (e) => toast.error(e instanceof Error ? e.message : inventoryErrorMessage(e)),
        },
      );
    } else {
      create.mutate(input, {
        onSuccess: () => {
          toast.success("Item cadastrado");
          setCreating(false);
        },
        onError: (e) => toast.error(e instanceof Error ? e.message : inventoryErrorMessage(e)),
      });
    }
  };

  const onDelete = () => {
    if (!confirmDel || !canDeleteEffectiveItem(confirmDel) || !confirmDel.inventoryItemId) return;
    del.mutate(
      { id: confirmDel.inventoryItemId, imagem_url: confirmDel.imagem_url },
      {
        onSuccess: () => {
          toast.success("Item excluído");
          setConfirmDel(null);
        },
        onError: (e) => toast.error(e instanceof Error ? e.message : inventoryErrorMessage(e)),
      },
    );
  };

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div className="flex items-center gap-3">
          <Link
            to="/app/calculadora"
            className="inline-flex items-center gap-1 rounded-lg border border-input px-3 py-1.5 text-xs hover:bg-accent"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Voltar
          </Link>
          <div>
            <h1 className="font-display text-3xl font-bold">Estoque</h1>
            <p className="text-sm text-muted-foreground">
              Materiais da sua empresa e produtos globais disponibilizados pelo Super Admin.
            </p>
          </div>
        </div>
        {/* O botão "Catálogo de alumínios" saiu daqui (Revisão 100). O catálogo
            NÃO ficou inacessível: ele é o mesmo `<AluminumCatalog />` que a rota
            `/app/aluminios` serve, e essa tem item próprio no menu lateral
            ("Alumínios", `AppShell.tsx`). A rota DUPLICADA
            `/app/estoque/aluminios` foi APAGADA na Revisão 107 — ela era filha
            desta e nunca renderizou, então "existir por URL direta" era só
            aparência: quem digitasse a URL via esta listagem. */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setCreating(true)}
            disabled={!hasActiveCompany || !canWriteStock}
            className="inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-4 py-2.5 text-sm font-semibold text-gold-foreground shadow-glow hover:opacity-95 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Plus className="h-4 w-4" /> Novo item
          </button>
        </div>
      </div>

      {hasActiveCompany && (
        <>
          {/* Áreas: filtro simples, no MESMO componente dos chips de categoria
              (Revisão 100) — o estilo vem de `CatChip`, não de uma cópia dele,
              então mexer no visual de um move os dois juntos.

              🔴 O número e o R$ que ficavam aqui dentro não eram só ruído: eles
              eram calculados sobre `itens`, que JÁ vem filtrado por área na
              consulta. Com uma área selecionada, os outros quatro cards
              mostravam `0` e `R$ 0,00` — não porque a empresa não tivesse
              aqueles itens, mas porque a lista não os continha. A contagem e o
              valor honestos continuam logo abaixo, em "Itens listados" e
              "Valor em estoque", que respeitam o filtro por construção. */}
          {/* O chip "Todas" entrou aqui na Revisão 102, e ele fecha a confusão
              que a Revisão 101 diagnosticou: a linha de CATEGORIAS sempre teve
              um "Todas", esta não tinha, e quem procurava "mostrar tudo" acabava
              clicando em "Geral" — que é uma 5ª área de verdade (Colas/Silicones
              e Outros), não um "tudo".

              📌 Nada de lógica nova: a entrada `all` JÁ existia em `AREAS` e era
              descartada por um `.filter()`. O `onClick` que já estava aqui
              resolve o caso sozinho — `area === a.value ? "all" : a.value` dá
              "all" nos dois ramos quando o próprio chip é o "all". E como
              `COR_AREA` não tem entrada para "all", ele cai no dourado padrão do
              `CatChip`, igual ao "Todas" das categorias. */}
          <div className="mb-4 flex flex-wrap gap-2">
            {AREAS.map((a) => (
              <CatChip
                key={a.value}
                label={a.label}
                Icon={a.Icon}
                cor={COR_AREA[a.value]}
                active={areaFiltro === a.value}
                onClick={() => {
                  setArea(areaFiltro === a.value ? "all" : a.value);
                  setCat("todas");
                }}
              />
            ))}
          </div>

          <div className="mb-4 grid grid-cols-1 gap-3 md:grid-cols-3">
            <div className="rounded-2xl border bg-card p-4">
              <div className="text-xs text-muted-foreground">Itens listados</div>
              <div className="font-display text-2xl font-bold">{totais.cadastrados}</div>
            </div>
            <div className="rounded-2xl border bg-card p-4">
              <div className="text-xs text-muted-foreground">Valor em estoque (custo)</div>
              <div className="font-display text-2xl font-bold">{brl(totais.valorCusto)}</div>
            </div>
            <div className="rounded-2xl border bg-card p-4">
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <AlertTriangle className="h-3 w-3" /> Abaixo do mínimo
              </div>
              <div
                className={`font-display text-2xl font-bold ${totais.abaixoMinimo > 0 ? "text-destructive" : ""}`}
              >
                {totais.abaixoMinimo}
              </div>
            </div>
          </div>

          <div className="mb-4 flex flex-wrap gap-2">
            <CatChip
              label="Todas"
              active={cat === "todas"}
              count={itens.length}
              onClick={() => setCat("todas")}
            />
            {/* Categorias das áreas habilitadas (deduplicadas). Compartilhadas
                (ex. perfil) aparecem ativas em Vidraçaria e em Esquadrias. */}
            {inventoryCategoriesInUiAreas().map((c) => {
              const foraDaArea = areaFiltro !== "all" && !categoriaPertenceAArea(c, areaFiltro);
              const primeiraUi =
                c.areas.find((a) => ehInventoryUiArea(a)) ?? c.areas[0] ?? "vidracaria";
              const areaDestino =
                AREAS.find((a) => a.value === primeiraUi)?.label ??
                ROTULO_AREA_ESTOQUE[primeiraUi as InventoryUiArea] ??
                primeiraUi;
              return (
                <CatChip
                  key={c.value}
                  label={c.label}
                  active={!foraDaArea && cat === c.value}
                  count={foraDaArea ? "—" : (catCounts[c.value] ?? 0)}
                  faded={foraDaArea}
                  title={foraDaArea ? `Trocar para ${areaDestino} e filtrar ${c.label}` : undefined}
                  onClick={() => {
                    if (foraDaArea) {
                      setArea(primeiraUi);
                      setCat(c.value);
                      return;
                    }
                    setCat(cat === c.value ? "todas" : c.value);
                  }}
                />
              );
            })}
          </div>

          <div className="mb-4 flex flex-col gap-3 rounded-lg border bg-card px-3 py-2 md:flex-row md:items-center">
            <div className="flex flex-1 items-center gap-2">
              <Search className="h-4 w-4 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar por nome, descrição ou fornecedor..."
                className="flex-1 bg-transparent text-sm outline-none"
              />
            </div>
            <label className="flex cursor-pointer items-center gap-2 text-xs text-muted-foreground">
              <input
                type="checkbox"
                checked={incluirInativos}
                onChange={(e) => setIncluirInativos(e.target.checked)}
                className="h-3.5 w-3.5 accent-current"
              />
              Mostrar inativos
            </label>
          </div>
        </>
      )}

      {companyLoading ? (
        <p className="text-muted-foreground">Carregando...</p>
      ) : !hasActiveCompany ? (
        <div className="rounded-2xl border border-border bg-card p-12 text-center">
          <Building2 className="mx-auto h-10 w-10 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">
            Selecione ou crie uma empresa para ver o estoque.
          </p>
        </div>
      ) : isLoading ? (
        <p className="text-muted-foreground">Carregando...</p>
      ) : isError ? (
        <div className="rounded-2xl border border-destructive/40 bg-card p-12 text-center">
          <AlertTriangle className="mx-auto h-10 w-10 text-destructive" />
          <p className="mt-3 text-sm text-muted-foreground">Não foi possível carregar o estoque.</p>
          <button
            onClick={() => refetch()}
            className="mt-4 rounded-lg border border-input px-4 py-2 text-sm hover:bg-accent"
          >
            Tentar novamente
          </button>
        </div>
      ) : itens.length === 0 ? (
        <div className="rounded-2xl border bg-card p-12 text-center">
          <Package className="mx-auto h-10 w-10 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">
            {search || cat !== "todas" || areaFiltro !== "all"
              ? "Nenhum item encontrado com esses filtros."
              : "Nenhum item ainda. Cadastre o primeiro."}
          </p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-2xl border bg-card">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead className="bg-muted/40 text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left">Item</th>
                  <th className="px-4 py-3 text-left">Categoria</th>
                  <th className="px-4 py-3 text-right">Estoque</th>
                  <th className="px-4 py-3 text-right">Custo</th>
                  <th className="px-4 py-3 text-right">Venda</th>
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody>
                {itens.map((i) => {
                  const cmeta = i.categoria ? categoriaMeta(i.categoria) : undefined;
                  const low =
                    Number(i.estoque_minimo) > 0 &&
                    Number(i.quantidade) <= Number(i.estoque_minimo);
                  const gerivel = canManage(i);
                  const canDelete = gerivel && canDeleteEffectiveItem(i);
                  const canSell =
                    i.source === "inventory" &&
                    !!i.inventoryItemId &&
                    i.ativo &&
                    Number(i.quantidade) > 0;
                  return (
                    // A linha inteira era clicável e levava à rota de detalhe,
                    // que NUNCA abriu (Revisões 106-107). Sem destino, sai
                    // junto o `cursor-pointer`: ponteiro de mão sobre algo que
                    // não responde é promessa falsa. O hover fica, porque
                    // ajuda a seguir a linha na horizontal.
                    <tr
                      key={i.rowKey}
                      className={`border-t transition hover:bg-muted/20 ${i.ativo ? "" : "opacity-60"}`}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <InventoryItemThumb item={effectiveItemToThumb(i)} />
                          <div>
                            <div className="flex items-center gap-2 font-medium">
                              {i.nome}
                              {!i.ativo && (
                                <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] uppercase text-muted-foreground">
                                  inativo
                                </span>
                              )}
                            </div>
                            {i.descricao && (
                              <div className="text-xs text-muted-foreground">{i.descricao}</div>
                            )}
                            {i.sku && (
                              <div className="mt-0.5 text-[11px] text-muted-foreground/80">
                                {i.sku}
                              </div>
                            )}
                            {i.manufacturerProductId &&
                            i.manufacturer_product?.product_manufacturers?.name ? (
                              <div className="mt-0.5 text-[11px] text-muted-foreground/80">
                                {i.manufacturer_product.product_manufacturers.name}
                              </div>
                            ) : i.manufacturerProductId ? (
                              <div className="mt-0.5 text-[11px] text-muted-foreground/80">
                                Catálogo global
                              </div>
                            ) : null}
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`rounded-md px-2 py-0.5 text-xs ${cmeta?.color ?? "bg-muted"}`}
                        >
                          {cmeta?.label ?? i.categoria ?? "Definir categoria"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <span className={low ? "font-semibold text-destructive" : ""}>
                          {Number(i.quantidade)} {i.unidade ?? ""}
                        </span>
                        {low && <AlertTriangle className="ml-1 inline h-3 w-3 text-destructive" />}
                      </td>
                      <td className="px-4 py-3 text-right text-muted-foreground">
                        {brl(Number(i.custo_unit))}
                      </td>
                      <td className="px-4 py-3 text-right font-medium">
                        {brl(Number(i.preco_venda))}
                      </td>
                      <td className="px-4 py-3">
                        <div
                          className="flex justify-end gap-1"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <button
                            onClick={() => setEditing(i)}
                            disabled={!gerivel}
                            title={
                              gerivel ? "Editar" : "Somente o criador ou owner/admin/manager edita"
                            }
                            className="rounded p-1.5 hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40"
                          >
                            <Pencil className="h-3.5 w-3.5" />
                          </button>
                          {/* O botão de desativar/reativar SAIU da linha na
                              Revisão 106, a pedido: numa tabela densa ele ficava
                              a um pixel do "Editar" e disparava a ação em UM
                              clique, sem confirmação — dava para desativar um
                              item sem perceber.

                              A alternativa que sobra é o checkbox "Item ativo"
                              do modal de edição: dois cliques, com Salvar no
                              meio. Foi conferida por clique real ANTES da
                              remoção, e o efeito confirmado no banco.

                              A tela de detalhe tinha um botão Desativar/Reativar,
                              mas ela nunca abriu — era filha desta rota, que não
                              renderiza <Outlet/>. A Revisão 107 APAGOU o arquivo
                              em vez de ativá-lo, por decisão de produto. O modal
                              é, e segue sendo, o ÚNICO caminho. */}
                          {/* "Vender" leva à Venda direta com o item JÁ na
                              venda (Revisão 106). Só aparece para item ATIVO e
                              com saldo: sem saldo, o seletor de lá desabilita o
                              cartão e a RPC recusaria — oferecer o atalho seria
                              prometer um caminho que termina em erro. Item
                              inativo nem chega ao seletor.
                              Produto global virtual (sem inventory_item) não
                              oferece Vender — qty 0 e sem id real. */}
                          {canSell && (
                            <Link
                              to="/app/venda-direta"
                              search={{ itemId: i.inventoryItemId! }}
                              title={`Vender "${i.nome}" — abre a Venda direta com o item já adicionado`}
                              className="rounded p-1.5 text-emerald-600 hover:bg-emerald-500/10"
                            >
                              <ShoppingCart className="h-3.5 w-3.5" />
                            </Link>
                          )}
                          {canDelete ? (
                            <button
                              onClick={() => setConfirmDel(i)}
                              title="Excluir definitivamente"
                              className="rounded p-1.5 text-destructive hover:bg-destructive/10"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          ) : i.manufacturerProductId ? (
                            <span
                              title="Produtos do catálogo global não podem ser excluídos pela empresa"
                              className="rounded p-1.5 text-muted-foreground/40"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </span>
                          ) : (
                            <button
                              disabled
                              title="Sem permissão"
                              className="rounded p-1.5 text-destructive opacity-40"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {(creating || editing) && (
        <InventoryItemDialog
          initial={(editing?.inventoryItem as InventoryItem | null) ?? null}
          draft={editing?.source === "global" ? editingDraft : null}
          dialogTitle={
            editing?.source === "global" ? "Editar produto global" : editing ? undefined : undefined
          }
          onClose={() => {
            setCreating(false);
            setEditing(null);
          }}
          onSubmit={onSubmit}
          loading={create.isPending || update.isPending || saveGlobal.isPending}
          contextBanner={
            editing?.manufacturerProductId && editing.manufacturer_product ? (
              <div className="rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
                <p>
                  Origem global:{" "}
                  <span className="text-foreground">
                    {editing.manufacturer_product.product_manufacturers?.name ?? "Catálogo global"}
                    {editing.manufacturer_product.source_code
                      ? ` · ${editing.manufacturer_product.source_code}`
                      : ""}
                  </span>
                </p>
                <p className="mt-1">
                  {editing.source === "global"
                    ? "Ao salvar, o produto passa a ter quantidade, custo e preço próprios desta empresa."
                    : "Dados comerciais desta empresa — alterações no catálogo global não atualizam este item automaticamente."}
                </p>
              </div>
            ) : null
          }
        />
      )}

      {confirmDel && (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4"
          onClick={() => setConfirmDel(null)}
        >
          <div
            className="w-full max-w-md rounded-2xl bg-card p-6 shadow-elegant"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="font-display text-lg font-bold">Excluir item?</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Excluir definitivamente <strong>{confirmDel.nome}</strong>? A imagem associada também
              será removida. Esta ação não pode ser desfeita — para apenas tirar o item de
              circulação, use <strong>Desativar</strong>.
            </p>
            <p className="mt-2 text-xs text-muted-foreground">
              Orçamentos já salvos não mudam: eles guardam a própria cópia da descrição e do preço.
            </p>
            <div className="mt-5 flex justify-end gap-2">
              <button
                onClick={() => setConfirmDel(null)}
                className="rounded-lg border border-input px-4 py-2 text-sm hover:bg-accent"
              >
                Cancelar
              </button>
              <button
                onClick={onDelete}
                disabled={del.isPending}
                className="rounded-lg bg-destructive px-4 py-2 text-sm font-semibold text-destructive-foreground disabled:cursor-not-allowed disabled:opacity-50"
              >
                {del.isPending ? "Excluindo..." : "Excluir"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/**
 * Chip de filtro — serve às DUAS linhas: áreas e categorias (Revisão 100).
 *
 * `count` e `Icon` são opcionais de propósito, e a diferença entre as linhas é
 * só isso: a de categorias mostra a contagem, a de áreas mostra o ícone da área
 * e nenhum número. **O estilo é um só**, então não há como as duas linhas
 * divergirem por descuido depois.
 */
function CatChip({
  label,
  active,
  count,
  Icon,
  cor,
  faded,
  title,
  onClick,
}: {
  label: string;
  active: boolean;
  /** Número real, ou "—" quando o filtro de área nem se aplica (Revisão 130). */
  count?: number | string;
  Icon?: LucideIcon;
  /** Cor própria do chip (Revisão 101). Sem ela, vale o dourado padrão. */
  cor?: { inativo: string; ativo: string };
  /**
   * Fora da área selecionada (Revisão 130). Visual de `disabled:opacity-50`
   * do `Button`, mas o chip CONTINUA clicável — o clique troca a área.
   * Sem `pointer-events-none` / `disabled` / `cursor-not-allowed`: esses
   * mentiriam que o controle não responde.
   */
  faded?: boolean;
  title?: string;
  onClick: () => void;
}) {
  // O dourado continua sendo o padrão: só a linha de ÁREAS passa `cor`, e a de
  // categorias segue exatamente como estava antes desta revisão.
  const padrao = {
    ativo: "border-gold bg-gold text-gold-foreground",
    inativo: "border-border bg-card text-muted-foreground hover:text-foreground",
  };
  const tom = cor ?? padrao;
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition ${
        active ? tom.ativo : tom.inativo
      } ${faded ? "opacity-50" : ""}`}
    >
      {Icon && <Icon className="h-3.5 w-3.5" />}
      {label}
      {count !== undefined && (
        <span
          className={`rounded-full px-1.5 text-[10px] ${active ? "bg-gold-foreground/20" : "bg-muted"}`}
        >
          {count}
        </span>
      )}
    </button>
  );
}
