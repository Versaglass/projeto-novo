import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useRef, useState } from "react";
import { Download, Loader2, UploadCloud } from "lucide-react";
import { toast } from "sonner";
import { requireAdmin } from "@/lib/admin-guard";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { downloadCatalogImportKit } from "@/lib/catalog-import/kit.functions";
import {
  createCatalogImportJob,
  getCatalogImportItems,
  getCatalogImportJob,
  processCatalogImport,
  type CatalogImportItemView,
  type CatalogImportJobView,
} from "@/lib/catalog-import/import.functions";
import { uploadCatalogZipWithTus } from "@/lib/catalog-import/tus-upload";
import {
  ZIP_MAX_SIZE_BYTES,
  ZIP_UI_LIMIT_LABEL,
  formatBytesForUi,
} from "@/lib/catalog-import/limits";
import { CATALOG_IMPORT_SCHEMA_VERSION } from "@/lib/catalog-import/normalize";
import { CatalogImportReviewPanel } from "./app.admin.importar-catalogo.review";

export const Route = createFileRoute("/_authenticated/app/admin/importar-catalogo")({
  beforeLoad: requireAdmin,
  component: ImportarCatalogoAdminPage,
});

function triggerBrowserDownload(filename: string, base64: string, mimeType: string) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  const blob = new Blob([bytes], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function ImportarCatalogoAdminPage() {
  const { isAdmin, loading: authLoading } = useAuth();
  const fileRef = useRef<HTMLInputElement>(null);

  const [downloading, setDownloading] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [phase, setPhase] = useState<"idle" | "uploading" | "processing">("idle");
  const [uploadPct, setUploadPct] = useState(0);
  const [job, setJob] = useState<CatalogImportJobView | null>(null);
  const [items, setItems] = useState<CatalogImportItemView[]>([]);
  /** Reutiliza job awaiting_upload se o TUS falhar (mesmo arquivo). */
  const pendingJobRef = useRef<{
    jobId: string;
    storagePath: string;
    storageBucket: string;
    fileKey: string;
  } | null>(null);

  const busy = phase !== "idle";

  const fileKeyOf = (f: File) => `${f.name}:${f.size}:${f.lastModified}`;

  const onDownloadKit = async () => {
    setDownloading(true);
    try {
      const kit = await downloadCatalogImportKit();
      triggerBrowserDownload(kit.filename, kit.contentBase64, kit.mimeType);
      toast.success("Kit para IA baixado.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Não foi possível baixar o Kit.");
    } finally {
      setDownloading(false);
    }
  };

  const onPickFile = (f: File | null) => {
    setJob(null);
    setItems([]);
    pendingJobRef.current = null;
    if (!f) {
      setFile(null);
      return;
    }
    if (!f.name.toLowerCase().endsWith(".zip")) {
      toast.error("Selecione um arquivo .zip gerado pelo Kit para IA.");
      setFile(null);
      return;
    }
    if (f.size > ZIP_MAX_SIZE_BYTES) {
      toast.error(
        `O arquivo ultrapassa o limite de ${ZIP_UI_LIMIT_LABEL} permitido para importação de catálogos.`,
      );
      setFile(null);
      return;
    }
    setFile(f);
  };

  const loadPreview = useCallback(async (jobId: string) => {
    const [j, list] = await Promise.all([
      getCatalogImportJob({ data: { jobId } }),
      getCatalogImportItems({ data: { jobId } }),
    ]);
    setJob(j);
    setItems(list);
  }, []);

  const onProcess = async () => {
    if (!file) return;
    setPhase("uploading");
    setUploadPct(0);
    setJob(null);
    setItems([]);

    try {
      const fileKey = fileKeyOf(file);
      let created = pendingJobRef.current;
      if (!created || created.fileKey !== fileKey) {
        const jobCreated = await createCatalogImportJob({
          data: { originalFilename: file.name, sizeBytes: file.size },
        });
        created = {
          jobId: jobCreated.jobId,
          storagePath: jobCreated.storagePath,
          storageBucket: jobCreated.storageBucket,
          fileKey,
        };
        pendingJobRef.current = created;
      }

      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData.session?.access_token;
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || "";
      if (!token || !supabaseUrl) throw new Error("Sessão inválida. Faça login novamente.");

      // objectName = storagePath EXATO do servidor (não reconstruir).
      await uploadCatalogZipWithTus({
        file,
        storagePath: created.storagePath,
        accessToken: token,
        supabaseUrl,
        bucket: created.storageBucket,
        onProgress: (p) => setUploadPct(p.percentage),
      });

      setPhase("processing");
      const result = await processCatalogImport({ data: { jobId: created.jobId } });
      pendingJobRef.current = null;
      await loadPreview(result.jobId);
      toast.success("Catálogo processado. Revise a prévia abaixo.");
    } catch (e) {
      // Upload interrompido: job permanece awaiting_upload; pendingJobRef permite retomar.
      toast.error(e instanceof Error ? e.message : "Falha na importação.");
    } finally {
      setPhase("idle");
      setUploadPct(0);
    }
  };

  if (authLoading || !isAdmin) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center text-sm text-muted-foreground">
        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Carregando…
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl space-y-8 p-4 md:p-6">
      <header>
        <h1 className="font-display text-2xl font-bold">Importar catálogo com IA</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Transforme catálogos de fabricantes em produtos do catálogo global do VersaGlass
          utilizando uma IA compatível.
        </p>
        <p className="mt-2 text-xs text-muted-foreground">
          Contrato: VersaGlass Catalog Import v{CATALOG_IMPORT_SCHEMA_VERSION} · Tamanho máximo:{" "}
          {ZIP_UI_LIMIT_LABEL}
        </p>
      </header>

      <section className="rounded-2xl border border-border bg-card p-5 shadow-sm">
        <h2 className="font-display text-lg font-semibold">Fluxo</h2>
        <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm text-muted-foreground">
          <li>Baixe o Kit para IA</li>
          <li>Envie o kit e o catálogo PDF para uma IA (ChatGPT, Claude, etc.)</li>
          <li>
            Receba <code className="text-foreground">catalogo-versaglass.zip</code>
          </li>
          <li>Envie o arquivo e revise a prévia (publicação na próxima etapa)</li>
        </ol>
      </section>

      <section className="space-y-4 rounded-2xl border border-border bg-card p-5 shadow-sm">
        <h2 className="font-display text-lg font-semibold">1. Kit para IA</h2>
        <button
          type="button"
          onClick={() => void onDownloadKit()}
          disabled={downloading || busy}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-gold px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-sm transition hover:opacity-95 disabled:opacity-60"
        >
          {downloading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Download className="h-4 w-4" />
          )}
          Baixar Kit para IA
        </button>
      </section>

      <section className="space-y-4 rounded-2xl border border-border bg-card p-5 shadow-sm">
        <h2 className="font-display text-lg font-semibold">2–3. Enviar catálogo gerado</h2>
        <p className="text-sm text-muted-foreground">
          Selecione o ZIP gerado pela IA. Upload direto e resumível para o Storage (TUS). Tamanho
          máximo: {ZIP_UI_LIMIT_LABEL}.
        </p>

        <input
          ref={fileRef}
          type="file"
          accept=".zip,application/zip"
          className="hidden"
          onChange={(e) => onPickFile(e.target.files?.[0] ?? null)}
        />

        <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
          <button
            type="button"
            disabled={busy}
            onClick={() => fileRef.current?.click()}
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-background px-4 py-2.5 text-sm font-medium hover:bg-muted/50 disabled:opacity-60"
          >
            <UploadCloud className="h-4 w-4" />
            Selecionar catalogo-versaglass.zip
          </button>

          <button
            type="button"
            disabled={!file || busy}
            onClick={() => void onProcess()}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-gold px-4 py-2.5 text-sm font-semibold text-primary-foreground disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            Processar catálogo
          </button>
        </div>

        {file ? (
          <p className="text-sm text-muted-foreground">
            Arquivo: <span className="text-foreground">{file.name}</span> ·{" "}
            {formatBytesForUi(file.size)}
          </p>
        ) : null}

        {phase === "uploading" ? (
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Enviando… {uploadPct.toFixed(0)}%</p>
            <div className="h-2 overflow-hidden rounded-full bg-muted">
              <div
                className="h-full bg-gradient-gold transition-all"
                style={{ width: `${Math.min(100, uploadPct)}%` }}
              />
            </div>
          </div>
        ) : null}

        {phase === "processing" ? (
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Processando catálogo…
          </p>
        ) : null}
      </section>

      {job && (job.status === "ready" || job.status === "completed") ? (
        <CatalogImportReviewPanel job={job} items={items} onRefresh={() => loadPreview(job.id)} />
      ) : null}

      {job && job.status === "failed" ? (
        <section className="rounded-2xl border border-rose-500/30 bg-card p-5 text-sm">
          <h2 className="font-display text-lg font-semibold text-rose-700 dark:text-rose-300">
            Falha no processamento
          </h2>
          <p className="mt-2 text-muted-foreground">{job.error_message ?? "Erro desconhecido."}</p>
        </section>
      ) : null}
    </div>
  );
}
