import { createFileRoute } from "@tanstack/react-router";
import {
  CalendarDays,
  MapPin,
  MessageCircle,
  Route as RouteIcon,
  type LucideIcon,
} from "lucide-react";
import {
  EnterpriseCrudPage,
  type CrudItem,
  type FieldConfig,
} from "@/components/EnterpriseCrudPage";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";

export const Route = createFileRoute("/_authenticated/app/agenda")({
  // Oculta para contas normais e Super Admin — menu removido; URL direta → /app.
  beforeLoad: hiddenRouteBeforeLoad,
  component: AgendaPage,
});
const fields: FieldConfig[] = [
  { key: "data", label: "Data" },
  { key: "hora", label: "Hora" },
  { key: "cliente", label: "Cliente" },
  { key: "servico", label: "Serviço" },
  { key: "instalador", label: "Instalador" },
  { key: "endereco", label: "Endereço" },
  { key: "maps_url", label: "Maps" },
  {
    key: "status",
    label: "Status",
    type: "select",
    options: ["Agendado", "Confirmado", "Em rota", "Executando", "Finalizado", "Reagendar"],
  },
  { key: "checklist", label: "Checklist", type: "textarea" },
  { key: "observacoes", label: "Observações", type: "textarea" },
];
const data: CrudItem[] = [
  {
    id: "ag1",
    data: "2026-07-03",
    hora: "08:00",
    cliente: "Cliente exemplo",
    servico: "Instalar box",
    instalador: "João",
    endereco: "Guarapari - ES",
    status: "Agendado",
  },
];
function AgendaPage() {
  return (
    <div className="space-y-5">
      <div className="grid gap-3 md:grid-cols-4">
        {(
          [
            [CalendarDays, "Calendário"],
            [MessageCircle, "Confirmar WhatsApp"],
            [RouteIcon, "Rota"],
            [MapPin, "Localização"],
          ] as const satisfies ReadonlyArray<readonly [LucideIcon, string]>
        ).map(([Icon, label]) => (
          <div key={label} className="rounded-2xl border bg-card p-4">
            <Icon className="mb-2 h-6 w-6 text-gold" />
            <b>{label}</b>
            <p className="text-xs text-muted-foreground">Instalações e visitas</p>
          </div>
        ))}
      </div>
      <EnterpriseCrudPage
        title="Agenda de instalação"
        badge="Calendário"
        subtitle="Organize medições, produção, instalação, rota, confirmação do cliente e equipe responsável."
        storageKey="vmm_agenda"
        initialData={data}
        fields={fields}
        highlight={["data", "hora", "cliente", "servico", "instalador", "status"]}
      />
    </div>
  );
}
