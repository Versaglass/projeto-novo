import { createFileRoute } from "@tanstack/react-router";
import {
  EnterpriseCrudPage,
  type CrudItem,
  type FieldConfig,
} from "@/components/EnterpriseCrudPage";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";

/** ROTA OCULTA (Revisão 227) — Assinaturas digitais. Código preservado; acesso bloqueado. */
export const Route = createFileRoute("/_authenticated/app/assinaturas-digitais")({
  beforeLoad: hiddenRouteBeforeLoad,
  component: AssinaturasDigitaisPage,
});
const fields: FieldConfig[] = [
  { key: "documento", label: "Documento" },
  { key: "cliente", label: "Cliente" },
  {
    key: "tipo",
    label: "Tipo",
    type: "select",
    options: ["Orçamento", "Contrato", "Entrega", "Instalação", "Garantia"],
  },
  { key: "link", label: "Link para assinatura" },
  { key: "assinado_em", label: "Assinado em" },
  { key: "ip", label: "IP" },
  {
    key: "status",
    label: "Status",
    type: "select",
    options: ["Pendente", "Assinado", "Recusado", "Expirado"],
  },
  { key: "arquivo_pdf", label: "PDF assinado" },
];
const data: CrudItem[] = [
  {
    id: "sig1",
    documento: "Contrato ORC-001",
    cliente: "Cliente exemplo",
    tipo: "Contrato",
    status: "Pendente",
  },
];
function AssinaturasDigitaisPage() {
  return (
    <EnterpriseCrudPage
      title="Assinatura eletrônica"
      badge="Documentos"
      subtitle="Envie orçamento, contrato, entrega e garantia para assinatura digital com registro de data, IP e PDF assinado."
      storageKey="vmm_assinaturas_digitais"
      initialData={data}
      fields={fields}
      highlight={["documento", "cliente", "tipo", "status", "assinado_em"]}
    />
  );
}
