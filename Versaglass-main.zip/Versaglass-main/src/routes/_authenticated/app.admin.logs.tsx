import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import {
  Activity,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Trash2,
  RefreshCw,
  Search,
} from "lucide-react";
import { toast } from "sonner";
import { requireAdmin } from "@/lib/admin-guard";

export const Route = createFileRoute("/_authenticated/app/admin/logs")({
  beforeLoad: requireAdmin,
  component: LogsPage,
});

type Level = "info" | "warn" | "error";

type Row = {
  id: string;
  action: string;
  level: Level;
  status: number | null;
  user_email: string | null;
  duration_ms: number | null;
  message: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
};

const LEVEL_META: Record<Level, { tone: string; Icon: any; label: string }> = {
  info: { tone: "bg-primary/15 text-primary", Icon: CheckCircle2, label: "Info" },
  warn: { tone: "bg-amber-500/15 text-amber-700", Icon: AlertTriangle, label: "Aviso" },
  error: { tone: "bg-destructive/15 text-destructive", Icon: XCircle, label: "Erro" },
};

function LogsPage() {
  const { isAdmin, loading: authLoading } = useAuth();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | Level>("all");
  const [q, setQ] = useState("");

  useEffect(() => {
    if (authLoading || !isAdmin) return;
    load();
    const ch = supabase
      .channel("server_logs")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "server_logs" },
        (payload) => {
          const r = payload.new as Row;
          setRows((cur) => [r, ...cur].slice(0, 500));
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [authLoading, isAdmin]);

  async function load() {
    setLoading(true);
    const { data, error } = await supabase
      .from("server_logs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(300);
    if (error) toast.error(error.message);
    setRows((data as Row[]) ?? []);
    setLoading(false);
  }

  async function clearAll() {
    if (!confirm("Apagar TODOS os registros?")) return;
    const { error } = await supabase.from("server_logs").delete().not("id", "is", null);
    if (error) return toast.error(error.message);
    setRows([]);
    toast.success("Registros apagados");
  }

  const visible = useMemo(() => {
    return rows.filter((r) => {
      if (filter !== "all" && r.level !== filter) return false;
      if (q) {
        const s = `${r.action} ${r.user_email ?? ""} ${r.message ?? ""}`.toLowerCase();
        if (!s.includes(q.toLowerCase())) return false;
      }
      return true;
    });
  }, [rows, filter, q]);

  if (!authLoading && !isAdmin) return null;

  const counts = {
    all: rows.length,
    info: rows.filter((r) => r.level === "info").length,
    warn: rows.filter((r) => r.level === "warn").length,
    error: rows.filter((r) => r.level === "error").length,
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="font-display text-3xl font-bold flex items-center gap-3">
            <Activity className="h-7 w-7 text-gold" />
            Registros do servidor
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Ações executadas no backend em tempo real — sucesso, avisos e erros.
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={load}
            className="inline-flex items-center gap-2 rounded-lg border border-input bg-background px-3 py-2 text-sm hover:bg-accent"
          >
            <RefreshCw className="h-4 w-4" /> Atualizar
          </button>
          <button
            onClick={clearAll}
            className="inline-flex items-center gap-2 rounded-lg border border-input bg-background px-3 py-2 text-sm hover:bg-accent hover:text-destructive"
          >
            <Trash2 className="h-4 w-4" /> Limpar
          </button>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {(["all", "info", "warn", "error"] as const).map((k) => (
          <button
            key={k}
            onClick={() => setFilter(k)}
            className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${
              filter === k
                ? "bg-foreground text-background"
                : "bg-muted text-muted-foreground hover:bg-accent"
            }`}
          >
            {k === "all" ? "Todos" : LEVEL_META[k].label}{" "}
            <span className="opacity-60">({counts[k]})</span>
          </button>
        ))}
        <div className="ml-auto relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar ação, e-mail, mensagem…"
            className="rounded-lg border border-input bg-background pl-8 pr-3 py-2 text-sm w-64 max-w-full"
          />
        </div>
      </div>

      <div className="rounded-xl border bg-card overflow-hidden">
        {loading ? (
          <div className="p-6 text-sm text-muted-foreground">Carregando…</div>
        ) : visible.length === 0 ? (
          <div className="p-10 text-center text-sm text-muted-foreground">
            Nenhum registro ainda. Conforme ações ocorrerem no servidor, elas aparecem aqui.
          </div>
        ) : (
          <ul className="divide-y">
            {visible.map((r) => {
              const meta = LEVEL_META[r.level];
              const Icon = meta.Icon;
              return (
                <li key={r.id} className="flex items-start gap-3 p-4">
                  <div
                    className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg ${meta.tone}`}
                  >
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap text-sm">
                      <span className="font-semibold">{r.action}</span>
                      {r.status != null && (
                        <span className="text-xs rounded-md bg-muted px-1.5 py-0.5">
                          HTTP {r.status}
                        </span>
                      )}
                      {r.duration_ms != null && (
                        <span className="text-xs text-muted-foreground">{r.duration_ms} ms</span>
                      )}
                      <span className="text-xs text-muted-foreground ml-auto">
                        {new Date(r.created_at).toLocaleString("pt-BR")}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5 truncate">
                      {r.user_email ?? "anônimo"}
                    </div>
                    {r.message && <div className="text-sm mt-1 break-words">{r.message}</div>}
                    {r.metadata && Object.keys(r.metadata).length > 0 && (
                      <pre className="mt-2 max-h-40 overflow-auto rounded-md bg-muted/50 p-2 text-[11px] leading-snug">
                        {JSON.stringify(r.metadata, null, 2)}
                      </pre>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
