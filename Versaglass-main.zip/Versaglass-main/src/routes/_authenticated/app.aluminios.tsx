import { createFileRoute } from "@tanstack/react-router";
import { AluminumCatalog } from "@/components/AluminumCatalog";
import { ModuleLockedCard } from "@/components/ModuleLockedCard";
import { getPlanFromStorage, hasModuleAccess } from "@/lib/module-access";

export const Route = createFileRoute("/_authenticated/app/aluminios")({ component: AluminiosPage });

function AluminiosPage() {
  const plan = getPlanFromStorage();
  const allowed = hasModuleAccess(plan, "aluminios");

  if (!allowed) return <ModuleLockedCard moduleKey="aluminios" />;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-3xl font-bold">Alumínios</h1>
        <p className="text-sm text-muted-foreground">
          Biblioteca técnica de alumínios com códigos, desenhos limpos, estoque e integração com
          projetos e orçamentos.
        </p>
      </div>
      <AluminumCatalog />
    </div>
  );
}
