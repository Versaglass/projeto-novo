import { createFileRoute } from "@tanstack/react-router";
import {
  EnterpriseCrudPage,
  type CrudItem,
  type FieldConfig,
} from "@/components/EnterpriseCrudPage";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";

/** ROTA OCULTA (Revisão 227) — Marketplace. Código preservado; acesso bloqueado. */
export const Route = createFileRoute("/_authenticated/app/marketplace-projetos")({
  beforeLoad: hiddenRouteBeforeLoad,
  component: MarketplaceProjetosPage,
});
const fields: FieldConfig[] = [
  { key: "titulo", label: "Projeto" },
  {
    key: "area",
    label: "Área",
    type: "select",
    options: ["Vidraçaria", "Serralheria", "Marcenaria", "Marmoraria"],
  },
  { key: "autor", label: "Autor" },
  { key: "preco", label: "Preço", type: "currency" },
  { key: "comissao", label: "Comissão plataforma", type: "currency" },
  { key: "arquivo", label: "Arquivo/Preview" },
  {
    key: "status",
    label: "Status",
    type: "select",
    options: ["Rascunho", "Em análise", "Publicado", "Vendido", "Bloqueado"],
  },
  { key: "observacoes", label: "Observações", type: "textarea" },
];
const data: CrudItem[] = [
  {
    id: "mp1",
    titulo: "Portão moderno 3D",
    area: "Serralheria",
    autor: "Usuário exemplo",
    preco: 49.9,
    comissao: 9.9,
    status: "Publicado",
  },
];
function MarketplaceProjetosPage() {
  return (
    <EnterpriseCrudPage
      title="Marketplace de Projetos"
      badge="Receita extra"
      subtitle="Usuários podem publicar e vender projetos. A plataforma recebe comissão automaticamente."
      storageKey="vmm_marketplace_projetos"
      initialData={data}
      fields={fields}
      highlight={["titulo", "area", "autor", "preco", "status"]}
    />
  );
}
