/**
 * Detalhe de produto do Catálogo de Fabricantes — legado (somente platform admin).
 * Ferramenta administrativa. Produtos publicados aparecem no Estoque das empresas.
 */

import { createFileRoute, Link, type SearchSchemaInput } from "@tanstack/react-router";
import { requireAdmin } from "@/lib/admin-guard";
import { useState } from "react";
import { ArrowLeft, Factory, ImageIcon, Loader2 } from "lucide-react";
import { StorageImage } from "@/components/StorageImage";
import {
  manufacturerCatalogErrorMessage,
  useManufacturerCatalogProduct,
} from "@/hooks/use-manufacturer-catalog";
import { categoriaMeta, INVENTORY_UNITS } from "@/hooks/use-inventory";
import {
  formatManufacturerAttributes,
  formatManufacturerObservations,
} from "@/lib/manufacturer-catalog/attributes";
import {
  searchCatalogoFabricantes,
  type ManufacturerCatalogSearch,
} from "@/lib/manufacturer-catalog/search";

type SearchInput = ManufacturerCatalogSearch & SearchSchemaInput;

export const Route = createFileRoute("/_authenticated/app/catalogo-fabricantes/$productId")({
  beforeLoad: requireAdmin,
  validateSearch: (search: SearchInput): ManufacturerCatalogSearch =>
    searchCatalogoFabricantes({
      q: search.q,
      fabricante: search.fabricante,
      categoria: search.categoria,
      linha: search.linha,
      page: search.page,
      ordem: search.ordem,
    }),
  component: CatalogoFabricanteProdutoPage,
});

function unitLabel(unit: string | null | undefined): string | null {
  if (!unit) return null;
  if ((INVENTORY_UNITS as readonly string[]).includes(unit)) return unit;
  return unit;
}

function CatalogoFabricanteProdutoPage() {
  const { productId } = Route.useParams();
  const listSearch = Route.useSearch();
  const { data, isLoading, isError, error } = useManufacturerCatalogProduct(productId);
  const [lightbox, setLightbox] = useState<string | null>(null);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center gap-2 py-24 text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" aria-hidden />
        <span>Carregando produto…</span>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="mx-auto max-w-3xl space-y-4 p-4 md:p-6">
        <BackLink search={listSearch} />
        <div
          role="alert"
          className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-6 text-sm"
        >
          {manufacturerCatalogErrorMessage(error)}
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="mx-auto max-w-3xl space-y-4 p-4 md:p-6">
        <BackLink search={listSearch} />
        <div className="rounded-xl border border-dashed border-border px-4 py-16 text-center">
          <Factory className="mx-auto mb-3 h-10 w-10 text-muted-foreground/50" aria-hidden />
          <p className="text-sm font-medium">Produto não encontrado ou indisponível.</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Ele pode estar inativo ou não existir neste catálogo.
          </p>
        </div>
      </div>
    );
  }

  const cat = data.inventory_category ? categoriaMeta(data.inventory_category) : undefined;
  const attrs = formatManufacturerAttributes(data.attributes);
  const observations = formatManufacturerObservations(data.observations);
  const unit = unitLabel(data.unit);
  const hasProvenance = Boolean(
    data.source_catalog_name || data.source_catalog_date || data.source_page || data.source_excerpt,
  );

  return (
    <div className="mx-auto max-w-5xl space-y-6 p-4 md:p-6">
      <BackLink search={listSearch} />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)]">
        <div className="space-y-3">
          <div className="relative aspect-square overflow-hidden rounded-xl border border-border/70 bg-muted/30">
            {data.primary_image_path ? (
              <button
                type="button"
                className="h-full w-full"
                onClick={() => setLightbox(data.primary_image_path)}
                aria-label="Ampliar imagem principal"
              >
                <StorageImage
                  src={data.primary_image_path}
                  alt={data.name}
                  bucket="manufacturer-catalog"
                  className="h-full w-full object-contain p-3"
                />
              </button>
            ) : (
              <div className="flex h-full flex-col items-center justify-center gap-2 text-muted-foreground">
                <ImageIcon className="h-12 w-12 opacity-40" aria-hidden />
                <span className="text-sm">Sem imagem</span>
              </div>
            )}
          </div>

          {data.technical_image_paths.length > 0 ? (
            <section aria-labelledby="tech-images-heading" className="space-y-2">
              <h2 id="tech-images-heading" className="text-sm font-semibold">
                Imagens técnicas
              </h2>
              <ul className="grid grid-cols-3 gap-2 sm:grid-cols-4">
                {data.technical_image_paths.map((path) => (
                  <li key={path}>
                    <button
                      type="button"
                      onClick={() => setLightbox(path)}
                      className="aspect-square w-full overflow-hidden rounded-lg border border-border/60 bg-muted/20"
                      aria-label="Ampliar imagem técnica"
                    >
                      <StorageImage
                        src={path}
                        alt={`Imagem técnica de ${data.name}`}
                        bucket="manufacturer-catalog"
                        className="h-full w-full object-contain p-1"
                      />
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}
        </div>

        <div className="space-y-5">
          <header className="space-y-2">
            <p className="text-sm font-medium text-primary">{data.manufacturer.name}</p>
            <h1 className="text-2xl font-semibold tracking-tight text-foreground">{data.name}</h1>
            <p className="font-mono text-sm text-muted-foreground">{data.source_code}</p>
          </header>

          <div className="rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-sm text-muted-foreground">
            <p>
              Produtos publicados aparecem automaticamente no{" "}
              <Link
                to="/app/estoque"
                className="font-medium text-primary underline-offset-2 hover:underline"
              >
                Estoque
              </Link>{" "}
              de todas as empresas. Não é necessário adicionar manualmente.
            </p>
          </div>

          <dl className="grid grid-cols-1 gap-3 text-sm sm:grid-cols-2">
            {data.base_code ? (
              <div>
                <dt className="text-xs text-muted-foreground">Código base</dt>
                <dd className="font-mono">{data.base_code}</dd>
              </div>
            ) : null}
            {data.product_line ? (
              <div>
                <dt className="text-xs text-muted-foreground">Linha</dt>
                <dd>{data.product_line}</dd>
              </div>
            ) : null}
            {cat ? (
              <div>
                <dt className="text-xs text-muted-foreground">Categoria</dt>
                <dd>
                  <span className={`inline-flex rounded-md px-1.5 py-0.5 text-xs ${cat.color}`}>
                    {cat.label}
                  </span>
                </dd>
              </div>
            ) : null}
            {data.suggested_category && !cat ? (
              <div>
                <dt className="text-xs text-muted-foreground">Categoria sugerida</dt>
                <dd>{data.suggested_category}</dd>
              </div>
            ) : null}
            {unit ? (
              <div>
                <dt className="text-xs text-muted-foreground">Unidade</dt>
                <dd>{unit}</dd>
              </div>
            ) : null}
            {data.product_type ? (
              <div>
                <dt className="text-xs text-muted-foreground">Tipo</dt>
                <dd>{data.product_type}</dd>
              </div>
            ) : null}
          </dl>

          {data.description ? (
            <section aria-labelledby="desc-heading" className="space-y-1">
              <h2 id="desc-heading" className="text-sm font-semibold">
                Descrição
              </h2>
              <p className="whitespace-pre-wrap text-sm text-muted-foreground">
                {data.description}
              </p>
            </section>
          ) : null}

          {attrs.length > 0 ? (
            <section aria-labelledby="attrs-heading" className="space-y-2">
              <h2 id="attrs-heading" className="text-sm font-semibold">
                Atributos técnicos
              </h2>
              <dl className="divide-y divide-border/60 rounded-lg border border-border/60">
                {attrs.map((row) => (
                  <div
                    key={`${row.label}-${row.value}`}
                    className="flex flex-col gap-0.5 px-3 py-2 sm:flex-row sm:justify-between sm:gap-4"
                  >
                    <dt className="text-xs text-muted-foreground">{row.label}</dt>
                    <dd className="text-sm sm:text-right">{row.value}</dd>
                  </div>
                ))}
              </dl>
            </section>
          ) : null}

          {observations.length > 0 ? (
            <section aria-labelledby="obs-heading" className="space-y-2">
              <h2 id="obs-heading" className="text-sm font-semibold">
                Observações
              </h2>
              <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">
                {observations.map((obs) => (
                  <li key={obs}>{obs}</li>
                ))}
              </ul>
            </section>
          ) : null}

          {hasProvenance ? (
            <section
              aria-labelledby="prov-heading"
              className="rounded-lg border border-border/50 bg-muted/20 px-3 py-3 text-xs text-muted-foreground"
            >
              <h2 id="prov-heading" className="mb-2 text-xs font-semibold text-foreground/80">
                Origem do catálogo
              </h2>
              <dl className="space-y-1">
                {data.source_catalog_name ? (
                  <div className="flex gap-2">
                    <dt className="shrink-0">Catálogo:</dt>
                    <dd>{data.source_catalog_name}</dd>
                  </div>
                ) : null}
                {data.source_catalog_date ? (
                  <div className="flex gap-2">
                    <dt className="shrink-0">Data:</dt>
                    <dd>{data.source_catalog_date}</dd>
                  </div>
                ) : null}
                {data.source_page != null ? (
                  <div className="flex gap-2">
                    <dt className="shrink-0">Página:</dt>
                    <dd>{data.source_page}</dd>
                  </div>
                ) : null}
                {data.source_excerpt ? (
                  <div className="flex gap-2">
                    <dt className="shrink-0">Trecho:</dt>
                    <dd className="italic">{data.source_excerpt}</dd>
                  </div>
                ) : null}
              </dl>
            </section>
          ) : null}
        </div>
      </div>

      {lightbox ? (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Visualização ampliada"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
          onClick={() => setLightbox(null)}
          onKeyDown={(e) => {
            if (e.key === "Escape") setLightbox(null);
          }}
        >
          <button
            type="button"
            className="absolute right-4 top-4 rounded-lg bg-background/90 px-3 py-1.5 text-sm"
            onClick={() => setLightbox(null)}
          >
            Fechar
          </button>
          <div
            className="max-h-[90vh] max-w-[90vw]"
            onClick={(e) => e.stopPropagation()}
            onKeyDown={(e) => e.stopPropagation()}
          >
            <StorageImage
              src={lightbox}
              alt={data.name}
              bucket="manufacturer-catalog"
              className="max-h-[90vh] max-w-[90vw] object-contain"
            />
          </div>
        </div>
      ) : null}
    </div>
  );
}

function BackLink({ search }: { search: ManufacturerCatalogSearch }) {
  return (
    <Link
      to="/app/catalogo-fabricantes"
      search={search}
      className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
    >
      <ArrowLeft className="h-4 w-4" aria-hidden />
      Voltar ao catálogo
    </Link>
  );
}
