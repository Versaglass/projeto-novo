import { createFileRoute } from "@tanstack/react-router";
import { Activity, BarChart3, Bug, Gauge, MousePointerClick } from "lucide-react";
import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";

/** ROTA OCULTA (Revisão 227) — Monitoramento. Código preservado; acesso bloqueado. */
export const Route = createFileRoute("/_authenticated/app/monitoramento")({
  beforeLoad: hiddenRouteBeforeLoad,
  component: MonitoramentoPage,
});

type EventRow = {
  name: string;
  at: string;
  metadata?: Record<string, unknown>;
  value?: number | string;
};
function MonitoramentoPage() {
  const [events, setEvents] = useState<EventRow[]>([]);
  useEffect(() => {
    const add = (e: Event) => setEvents((cur) => [(e as CustomEvent).detail, ...cur].slice(0, 50));
    window.addEventListener("versaglass:event", add);
    window.addEventListener("versaglass:metric", add);
    return () => {
      window.removeEventListener("versaglass:event", add);
      window.removeEventListener("versaglass:metric", add);
    };
  }, []);
  return (
    <div className="space-y-6">
      <div>
        <Badge className="mb-3 gap-1">
          <Activity className="h-3.5 w-3.5" />
          Monitoramento
        </Badge>
        <h1 className="font-display text-3xl font-bold">Monitoramento</h1>
        <p className="text-sm text-muted-foreground">
          Eventos de uso, erros de frontend, métricas de carregamento e conversões.
        </p>
      </div>
      <div className="grid gap-3 md:grid-cols-4">
        <Metric icon={Gauge} label="Performance" value="Ativo" />
        <Metric
          icon={Bug}
          label="Erros JS"
          value={String(events.filter((e) => e.name.includes("error")).length)}
        />
        <Metric icon={MousePointerClick} label="Eventos" value={String(events.length)} />
        <Metric icon={BarChart3} label="Analytics" value="Pronto" />
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Últimos eventos desta sessão</CardTitle>
        </CardHeader>
        <CardContent>
          {events.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Os eventos aparecerão aqui conforme o usuário navegar.
            </p>
          ) : (
            <ul className="divide-y">
              {events.map((e, i) => (
                <li key={i} className="py-3 text-sm">
                  <div className="font-medium">
                    {e.name} {e.value ? `· ${e.value}` : ""}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(e.at).toLocaleString("pt-BR")}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
function Metric({ icon: Icon, label, value }: any) {
  return (
    <Card>
      <CardContent className="p-5">
        <Icon className="mb-3 h-5 w-5 text-gold" />
        <div className="text-sm text-muted-foreground">{label}</div>
        <div className="font-display text-2xl font-bold">{value}</div>
      </CardContent>
    </Card>
  );
}
