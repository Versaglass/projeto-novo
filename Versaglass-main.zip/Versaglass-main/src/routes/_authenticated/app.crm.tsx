import { createFileRoute } from "@tanstack/react-router";
import {
  EnterpriseCrudPage,
  type CrudItem,
  type FieldConfig,
} from "@/components/EnterpriseCrudPage";
import { hiddenRouteBeforeLoad } from "@/lib/hidden-route-guard";

/** ROTA OCULTA (Revisão 227) — CRM. Código preservado; acesso bloqueado. */
export const Route = createFileRoute("/_authenticated/app/crm")({
  beforeLoad: hiddenRouteBeforeLoad,
  component: CrmPage,
});
const fields: FieldConfig[] = [
  { key: "cliente", label: "Cliente" },
  { key: "telefone", label: "WhatsApp" },
  {
    key: "origem",
    label: "Origem",
    type: "select",
    options: ["Instagram", "Google", "Indicação", "WhatsApp", "Site", "Marketplace"],
  },
  {
    key: "etapa",
    label: "Etapa",
    type: "select",
    options: [
      "Novo lead",
      "Orçamento enviado",
      "Visualizou",
      "Negociação",
      "Aprovou",
      "Pagamento",
      "Instalação",
      "Pós-venda",
      "Perdido",
    ],
  },
  { key: "valor", label: "Valor estimado", type: "currency" },
  { key: "proximo_contato", label: "Próximo contato" },
  { key: "observacoes", label: "Observações", type: "textarea" },
];
const data: CrudItem[] = [
  {
    id: "crm1",
    cliente: "Cliente exemplo",
    telefone: "",
    origem: "Instagram",
    etapa: "Orçamento enviado",
    valor: 1500,
    proximo_contato: "2026-07-02",
  },
];
function CrmPage() {
  return (
    <EnterpriseCrudPage
      title="CRM de Vendas"
      badge="Funil comercial"
      subtitle="Acompanhe lead, orçamento enviado, visualização, aprovação, pagamento, instalação e pós-venda."
      storageKey="vmm_crm"
      initialData={data}
      fields={fields}
      highlight={["cliente", "origem", "etapa", "valor", "proximo_contato"]}
    />
  );
}
