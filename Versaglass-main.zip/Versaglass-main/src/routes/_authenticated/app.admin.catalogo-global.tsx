import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import {
  DraftingCompass,
  ImageIcon,
  Loader2,
  Pencil,
  Plus,
  Power,
  PowerOff,
  Search,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { requireAdmin } from "@/lib/admin-guard";
import { useAuth } from "@/hooks/use-auth";
import { StorageImage } from "@/components/StorageImage";
import {
  ParametricProjectEditor,
  type PersistProjectDrawing,
} from "@/components/ParametricProjectEditor";
import {
  FILTROS_AREA_TODAS,
  ProjectAreaSubtypeFilters,
  type FiltroAreaProjeto,
  type FiltroSubtipoProjeto,
} from "@/components/projects/ProjectAreaSubtypeFilters";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AREAS_PROJETO, ROTULO_AREA, type AreaProjeto } from "@/lib/project-area";
import {
  ehSubtipoDaArea,
  rotuloSubtipo,
  subtiposDaArea,
  type SubtipoProjeto,
} from "@/lib/project-subtypes";
import { numeroParaTexto, validaCamposNumericos } from "@/lib/numero-campo";
import { brl } from "@/lib/format";
import {
  categoriaAceitaAcabamento,
  type ProjectTemplateAcabamento,
  type ProjectTemplateCategoria,
  type ProjectTemplateCor,
} from "@/hooks/use-project-templates";
import {
  platformCatalogErrorMessage,
  uploadPlatformCatalogImage,
  useCreatePlatformCatalogItem,
  useDeactivatePlatformCatalogItem,
  useDeletePlatformCatalogItem,
  usePlatformCatalogAreaCounts,
  usePlatformProjectCatalog,
  useReactivatePlatformCatalogItem,
  useSavePlatformCatalogDrawing,
  useUpdatePlatformCatalogItem,
  type PlatformCatalogInput,
  type PlatformCatalogItem,
} from "@/hooks/use-platform-project-catalog";
import { normalizeProjectData } from "@/types/project-data";

export const Route = createFileRoute("/_authenticated/app/admin/catalogo-global")({
  beforeLoad: requireAdmin,
  component: CatalogoGlobalAdminPage,
});

const CATEGORIAS: { id: ProjectTemplateCategoria; label: string }[] = [
  { id: "vidro_comum", label: "Vidro comum" },
  { id: "temperado", label: "Temperado" },
  { id: "espelho", label: "Espelho" },
  { id: "refletivo", label: "Refletivo" },
  { id: "organico", label: "Orgânico" },
  { id: "canelado", label: "Canelado" },
  { id: "esquadria", label: "Esquadria / outros" },
];

const ACABAMENTOS: { id: ProjectTemplateAcabamento; label: string }[] = [
  { id: "cortado", label: "Cortado" },
  { id: "lapidado", label: "Lapidado" },
  { id: "bisote", label: "Bisotê" },
  { id: "com_moldura", label: "Com moldura" },
];

const CORES: { id: ProjectTemplateCor; label: string }[] = [
  { id: "prata", label: "Prata" },
  { id: "neutro", label: "Neutro" },
  { id: "champanhe", label: "Champanhe" },
  { id: "cinza", label: "Cinza" },
  { id: "verde", label: "Verde" },
  { id: "azul", label: "Azul" },
];

function CatalogoGlobalAdminPage() {
  const { isAdmin, loading } = useAuth();
  const [query, setQuery] = useState("");
  const [area, setArea] = useState<FiltroAreaProjeto>("todos");
  const [subtipo, setSubtipo] = useState<FiltroSubtipoProjeto>("todos");

  const escolherArea = (nova: FiltroAreaProjeto) => {
    setArea(nova);
    if (nova !== area) setSubtipo("todos");
  };

  const {
    data: items = [],
    isLoading,
    refetch,
  } = usePlatformProjectCatalog({
    incluirInativos: true,
    search: query,
    area,
    subtipo,
  });
  const { data: contagensData } = usePlatformCatalogAreaCounts({
    incluirInativos: true,
    search: query,
    area,
  });
  const [editing, setEditing] = useState<PlatformCatalogItem | "novo" | null>(null);
  const [drawingItem, setDrawingItem] = useState<PlatformCatalogItem | null>(null);
  const saveDrawing = useSavePlatformCatalogDrawing();

  const persistDrawing: PersistProjectDrawing = async ({ id, dados, areaTemplate }) => {
    const salvo = await saveDrawing.mutateAsync({ id, dados, areaTemplate });
    setDrawingItem((cur) =>
      cur && cur.id === id
        ? { ...cur, project_data: salvo as unknown as typeof cur.project_data }
        : cur,
    );
    void refetch();
    return salvo;
  };

  const abrirDesenho = (item: PlatformCatalogItem) => {
    setEditing(null);
    setDrawingItem(item);
  };

  if (loading) return null;
  if (!isAdmin) return null;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Catálogo global</h1>
          <p className="text-sm text-muted-foreground">
            Gestão da biblioteca compartilhada. Itens ativos aparecem em Projetos para todas as
            empresas. Só admin de plataforma edita metadados e o desenho paramétrico.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setEditing("novo")}
          className="inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-4 py-2.5 text-sm font-semibold text-gold-foreground shadow-glow hover:opacity-95"
        >
          <Plus className="h-4 w-4" /> Novo item
        </button>
      </div>

      <div className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-3 md:flex-row md:items-center md:justify-between">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar por nome..."
            className="w-full rounded-lg border border-input bg-background py-2 pl-9 pr-3 text-sm outline-none focus:ring-2 ring-ring"
          />
        </div>
        <ProjectAreaSubtypeFilters
          area={area}
          subtipo={subtipo}
          onAreaChange={escolherArea}
          onSubtipoChange={setSubtipo}
          contagens={contagensData?.areas}
          contagensSubtipo={contagensData?.subtipos}
          filtrosArea={FILTROS_AREA_TODAS}
        />
      </div>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">Carregando…</p>
      ) : items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-12 text-center text-sm text-muted-foreground">
          {query || area !== "todos"
            ? `Nenhum item encontrado${area !== "todos" ? ` em ${ROTULO_AREA[area]}` : ""}${
                subtipo !== "todos" ? ` · ${rotuloSubtipo(subtipo)}` : ""
              }${query ? " para essa busca" : ""}.`
            : "Nenhum item no catálogo ainda."}
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item) => (
            <CatalogAdminCard
              key={item.id}
              item={item}
              onEdit={() => setEditing(item)}
              onEditDrawing={() => abrirDesenho(item)}
            />
          ))}
        </div>
      )}

      {editing && (
        <CatalogEditModal
          value={editing === "novo" ? null : editing}
          onClose={() => {
            setEditing(null);
            void refetch();
          }}
          onSaved={(item) => {
            setEditing(item);
            void refetch();
          }}
          onOpenDrawing={abrirDesenho}
        />
      )}

      {drawingItem && (
        <ParametricProjectEditor
          project={{
            id: drawingItem.id,
            nome: drawingItem.nome,
            area: drawingItem.area as AreaProjeto,
            categoria: drawingItem.categoria,
            descricao: drawingItem.descricao ?? undefined,
            espessura: drawingItem.espessura,
            largura_padrao: Number(drawingItem.largura_padrao) || 1,
            altura_padrao: Number(drawingItem.altura_padrao) || 1,
            preco_m2: Number(drawingItem.preco_referencia_m2) || 0,
          }}
          dadosIniciais={normalizeProjectData(drawingItem.project_data)}
          onClose={() => {
            setDrawingItem(null);
            void refetch();
          }}
          onPersist={persistDrawing}
          draftNamespace="platform-catalog"
        />
      )}
    </div>
  );
}

function CatalogAdminCard({
  item,
  onEdit,
  onEditDrawing,
}: {
  item: PlatformCatalogItem;
  onEdit: () => void;
  onEditDrawing: () => void;
}) {
  const deactivate = useDeactivatePlatformCatalogItem();
  const reactivate = useReactivatePlatformCatalogItem();
  const remove = useDeletePlatformCatalogItem();
  const [confirmDelete, setConfirmDelete] = useState(false);
  const busy = deactivate.isPending || reactivate.isPending || remove.isPending;
  const temDesenho = item.project_data != null;

  const fecharConfirmacao = () => {
    if (remove.isPending) return;
    setConfirmDelete(false);
  };

  const confirmarExclusao = async () => {
    try {
      await remove.mutateAsync(item.id);
      toast.success("Projeto removido do Catálogo Global.");
      setConfirmDelete(false);
    } catch (e) {
      toast.error(platformCatalogErrorMessage(e));
    }
  };

  return (
    <div
      className={`overflow-hidden rounded-2xl border bg-card ${
        item.ativo ? "border-border" : "border-dashed border-muted-foreground/40 opacity-80"
      }`}
    >
      <div className="relative aspect-[4/3] bg-muted/40">
        {item.imagem_url ? (
          <StorageImage
            bucket="platform-catalog"
            src={item.imagem_url}
            alt={item.nome}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-muted-foreground">
            <ImageIcon className="h-10 w-10 opacity-40" />
          </div>
        )}
        <span className="absolute left-2 top-2 rounded-full bg-background/90 px-2 py-0.5 text-[10px] font-semibold uppercase">
          {ROTULO_AREA[item.area]}
        </span>
        {!item.ativo && (
          <span className="absolute right-2 top-2 rounded-full bg-muted px-2 py-0.5 text-[10px] font-semibold uppercase text-muted-foreground">
            Inativo
          </span>
        )}
        {temDesenho && (
          <span className="absolute bottom-2 left-2 rounded-full bg-background/90 px-2 py-0.5 text-[10px] font-semibold text-foreground">
            Com desenho
          </span>
        )}
      </div>
      <div className="space-y-2 p-3">
        <div className="truncate font-semibold">{item.nome}</div>
        <div className="text-xs text-muted-foreground">
          {rotuloSubtipo(item.subtipo) ?? item.subtipo} · {Number(item.largura_padrao).toFixed(2)} ×{" "}
          {Number(item.altura_padrao).toFixed(2)} m
        </div>
        <div className="text-xs font-medium">{brl(Number(item.preco_referencia_m2))}/m²</div>
        <div className="flex flex-wrap gap-1 pt-1">
          <button
            type="button"
            onClick={onEdit}
            className="inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] hover:bg-accent"
          >
            <Pencil className="h-3 w-3" /> Editar
          </button>
          <button
            type="button"
            onClick={onEditDrawing}
            className="inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] hover:bg-accent"
          >
            <DraftingCompass className="h-3 w-3" />{" "}
            {temDesenho ? "Editar desenho" : "Criar desenho"}
          </button>
          {item.ativo ? (
            <button
              type="button"
              disabled={busy}
              onClick={() =>
                deactivate.mutate(item.id, {
                  onSuccess: () => toast.success("Item desativado"),
                  onError: (e) => toast.error(platformCatalogErrorMessage(e)),
                })
              }
              className="inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] hover:bg-accent"
            >
              <PowerOff className="h-3 w-3" /> Desativar
            </button>
          ) : (
            <button
              type="button"
              disabled={busy}
              onClick={() =>
                reactivate.mutate(item.id, {
                  onSuccess: () => toast.success("Item reativado"),
                  onError: (e) => toast.error(platformCatalogErrorMessage(e)),
                })
              }
              className="inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] hover:bg-accent"
            >
              <Power className="h-3 w-3" /> Reativar
            </button>
          )}
          <button
            type="button"
            disabled={busy}
            onClick={() => setConfirmDelete(true)}
            className="inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] text-muted-foreground hover:bg-accent hover:text-foreground"
          >
            <Trash2 className="h-3 w-3" /> Excluir projeto
          </button>
        </div>
      </div>

      <AlertDialog
        open={confirmDelete}
        onOpenChange={(next) => {
          if (!next) fecharConfirmacao();
          else setConfirmDelete(true);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir projeto?</AlertDialogTitle>
            <AlertDialogDescription>
              O projeto &quot;{item.nome}&quot; será removido do Catálogo Global e deixará de
              aparecer para todas as empresas. Orçamentos já criados não serão apagados.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={remove.isPending} onClick={fecharConfirmacao}>
              Cancelar
            </AlertDialogCancel>
            <button
              type="button"
              disabled={remove.isPending}
              onClick={() => void confirmarExclusao()}
              className="inline-flex items-center justify-center gap-2 rounded-md bg-destructive px-4 py-2 text-sm font-semibold text-destructive-foreground hover:bg-destructive/90 disabled:opacity-50"
            >
              {remove.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Excluindo...
                </>
              ) : (
                "Excluir projeto"
              )}
            </button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function CatalogEditModal({
  value,
  onClose,
  onSaved,
  onOpenDrawing,
}: {
  value: PlatformCatalogItem | null;
  onClose: () => void;
  onSaved: (item: PlatformCatalogItem) => void;
  onOpenDrawing: (item: PlatformCatalogItem) => void;
}) {
  const create = useCreatePlatformCatalogItem();
  const update = useUpdatePlatformCatalogItem();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const previousImage = value?.imagem_url ?? null;

  const areaInicial = (value?.area ?? "vidracaria") as AreaProjeto;
  const subtipoLegado =
    value?.subtipo && !ehSubtipoDaArea(areaInicial, value.subtipo) ? value.subtipo : null;
  const [form, setForm] = useState({
    nome: value?.nome ?? "",
    descricao: value?.descricao ?? "",
    imagem_url: value?.imagem_url ?? "",
    area: areaInicial,
    subtipo: (value?.subtipo && ehSubtipoDaArea(areaInicial, value.subtipo)
      ? value.subtipo
      : subtiposDaArea(areaInicial)[0]) as SubtipoProjeto,
    categoria: (value?.categoria ?? "temperado") as ProjectTemplateCategoria,
    acabamento: (value?.acabamento ?? "") as "" | ProjectTemplateAcabamento,
    cor: (value?.cor ?? "") as "" | ProjectTemplateCor,
    espessura: value?.espessura ?? "",
    largura_padrao: numeroParaTexto(Number(value?.largura_padrao) || 1),
    altura_padrao: numeroParaTexto(Number(value?.altura_padrao) || 1),
    preco_referencia_m2: numeroParaTexto(Number(value?.preco_referencia_m2) || 0),
    observacoes: value?.observacoes ?? "",
    ativo: value?.ativo ?? true,
    ordem: String(value?.ordem ?? 0),
  });

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) =>
    setForm((prev) => ({ ...prev, [k]: v }));

  const escolherArea = (area: AreaProjeto) => {
    const subs = subtiposDaArea(area);
    setForm((prev) => ({
      ...prev,
      area,
      subtipo: ehSubtipoDaArea(area, prev.subtipo) ? prev.subtipo : subs[0],
    }));
  };

  const escolherCategoria = (categoria: ProjectTemplateCategoria) => {
    setForm((prev) => ({
      ...prev,
      categoria,
      acabamento: categoriaAceitaAcabamento(categoria) ? prev.acabamento : "",
      cor: categoria === "refletivo" ? prev.cor : "",
    }));
  };

  const onUpload = async (file: File) => {
    setUploading(true);
    try {
      const path = await uploadPlatformCatalogImage(file);
      set("imagem_url", path);
      toast.success("Foto enviada");
    } catch (e) {
      toast.error(platformCatalogErrorMessage(e));
    } finally {
      setUploading(false);
    }
  };

  const onSave = () => {
    const numeros = validaCamposNumericos([
      {
        chave: "largura_padrao",
        texto: form.largura_padrao,
        regra: { label: "a largura padrão (em metros)", min: 0.001, obrigatorio: true },
      },
      {
        chave: "altura_padrao",
        texto: form.altura_padrao,
        regra: { label: "a altura padrão (em metros)", min: 0.001, obrigatorio: true },
      },
      {
        chave: "preco_referencia_m2",
        texto: form.preco_referencia_m2,
        regra: { label: "o preço de referência por m²", min: 0, casas: 2 },
      },
    ]);
    if (!numeros.ok) {
      toast.error(numeros.erro);
      return;
    }
    const nome = form.nome.trim();
    if (!nome) {
      toast.error("Informe o nome.");
      return;
    }
    if (!ehSubtipoDaArea(form.area, form.subtipo)) {
      toast.error("Tipo de projeto inválido para a área.");
      return;
    }

    const input: PlatformCatalogInput = {
      nome,
      descricao: form.descricao.trim() || null,
      imagem_url: form.imagem_url.trim() || null,
      area: form.area,
      subtipo: form.subtipo,
      categoria: form.categoria,
      acabamento: form.acabamento || null,
      cor: form.cor || null,
      espessura: form.espessura.trim() || null,
      largura_padrao: numeros.valores.largura_padrao,
      altura_padrao: numeros.valores.altura_padrao,
      preco_referencia_m2: numeros.valores.preco_referencia_m2,
      observacoes: form.observacoes.trim() || null,
      ativo: form.ativo,
      ordem: Number.parseInt(form.ordem, 10) || 0,
    };

    if (value) {
      update.mutate(
        { id: value.id, input, previousImage },
        {
          onSuccess: (item) => {
            toast.success("Item atualizado");
            onSaved(item);
          },
          onError: (e) => toast.error(platformCatalogErrorMessage(e)),
        },
      );
    } else {
      create.mutate(input, {
        onSuccess: (item) => {
          toast.success("Item criado — agora você pode configurar o desenho paramétrico.");
          onSaved(item);
        },
        onError: (e) => toast.error(platformCatalogErrorMessage(e)),
      });
    }
  };

  const saving = create.isPending || update.isPending;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-border bg-card p-5 shadow-xl">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-xl font-bold">
            {value ? "Editar item" : "Novo item do catálogo"}
          </h2>
          <button type="button" onClick={onClose} className="rounded-md p-1.5 hover:bg-accent">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mb-4">
          <div className="relative aspect-[4/3] w-full overflow-hidden rounded-lg border bg-muted">
            {form.imagem_url ? (
              <StorageImage
                bucket="platform-catalog"
                src={form.imagem_url}
                alt=""
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                <ImageIcon className="h-12 w-12 opacity-40" />
              </div>
            )}
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif,image/avif"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void onUpload(f);
              e.target.value = "";
            }}
          />
          <button
            type="button"
            disabled={uploading}
            onClick={() => fileRef.current?.click()}
            className="mt-2 inline-flex items-center gap-2 rounded-lg border px-3 py-2 text-sm hover:bg-accent"
          >
            {uploading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Upload className="h-4 w-4" />
            )}
            {uploading ? "Enviando…" : form.imagem_url ? "Trocar foto" : "Enviar foto"}
          </button>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <label className="sm:col-span-2 text-sm">
            <span className="mb-1 block text-muted-foreground">Nome *</span>
            <input
              value={form.nome}
              onChange={(e) => set("nome", e.target.value)}
              className="w-full rounded-lg border bg-background px-3 py-2"
            />
          </label>
          <label className="sm:col-span-2 text-sm">
            <span className="mb-1 block text-muted-foreground">Descrição</span>
            <textarea
              value={form.descricao}
              onChange={(e) => set("descricao", e.target.value)}
              rows={3}
              className="w-full rounded-lg border bg-background px-3 py-2"
            />
          </label>
          <label className="text-sm">
            <span className="mb-1 block text-muted-foreground">Área *</span>
            <select
              value={form.area}
              onChange={(e) => escolherArea(e.target.value as AreaProjeto)}
              className="w-full rounded-lg border bg-background px-3 py-2"
            >
              {AREAS_PROJETO.map((a) => (
                <option key={a} value={a}>
                  {ROTULO_AREA[a]}
                </option>
              ))}
            </select>
          </label>
          <label className="text-sm">
            <span className="mb-1 block text-muted-foreground">Tipo *</span>
            <select
              value={form.subtipo}
              onChange={(e) => set("subtipo", e.target.value as SubtipoProjeto)}
              className="w-full rounded-lg border bg-background px-3 py-2"
            >
              {subtiposDaArea(form.area).map((s) => (
                <option key={s} value={s}>
                  {rotuloSubtipo(s)}
                </option>
              ))}
            </select>
            {subtipoLegado && (
              <span className="mt-1 block text-xs text-amber-600 dark:text-amber-400">
                Tipo antigo ({rotuloSubtipo(subtipoLegado) ?? subtipoLegado}). Confirme o tipo da
                nova lista antes de salvar.
              </span>
            )}
          </label>
          <label className="text-sm">
            <span className="mb-1 block text-muted-foreground">Categoria *</span>
            <select
              value={form.categoria}
              onChange={(e) => escolherCategoria(e.target.value as ProjectTemplateCategoria)}
              className="w-full rounded-lg border bg-background px-3 py-2"
            >
              {CATEGORIAS.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
          </label>
          {categoriaAceitaAcabamento(form.categoria) && (
            <label className="text-sm">
              <span className="mb-1 block text-muted-foreground">Acabamento</span>
              <select
                value={form.acabamento}
                onChange={(e) =>
                  set("acabamento", e.target.value as "" | ProjectTemplateAcabamento)
                }
                className="w-full rounded-lg border bg-background px-3 py-2"
              >
                <option value="">—</option>
                {ACABAMENTOS.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.label}
                  </option>
                ))}
              </select>
            </label>
          )}
          {form.categoria === "refletivo" && (
            <label className="text-sm">
              <span className="mb-1 block text-muted-foreground">Cor</span>
              <select
                value={form.cor}
                onChange={(e) => set("cor", e.target.value as "" | ProjectTemplateCor)}
                className="w-full rounded-lg border bg-background px-3 py-2"
              >
                <option value="">—</option>
                {CORES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            </label>
          )}
          <label className="text-sm">
            <span className="mb-1 block text-muted-foreground">Espessura</span>
            <input
              value={form.espessura}
              onChange={(e) => set("espessura", e.target.value)}
              placeholder="8mm"
              className="w-full rounded-lg border bg-background px-3 py-2"
            />
          </label>
          <label className="text-sm">
            <span className="mb-1 block text-muted-foreground">Largura (m)</span>
            <input
              value={form.largura_padrao}
              onChange={(e) => set("largura_padrao", e.target.value)}
              className="w-full rounded-lg border bg-background px-3 py-2"
            />
          </label>
          <label className="text-sm">
            <span className="mb-1 block text-muted-foreground">Altura (m)</span>
            <input
              value={form.altura_padrao}
              onChange={(e) => set("altura_padrao", e.target.value)}
              className="w-full rounded-lg border bg-background px-3 py-2"
            />
          </label>
          <label className="text-sm">
            <span className="mb-1 block text-muted-foreground">Preço ref. R$/m²</span>
            <input
              value={form.preco_referencia_m2}
              onChange={(e) => set("preco_referencia_m2", e.target.value)}
              className="w-full rounded-lg border bg-background px-3 py-2"
            />
          </label>
          <label className="text-sm">
            <span className="mb-1 block text-muted-foreground">Ordem</span>
            <input
              value={form.ordem}
              onChange={(e) => set("ordem", e.target.value)}
              className="w-full rounded-lg border bg-background px-3 py-2"
            />
          </label>
          <label className="sm:col-span-2 flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.ativo}
              onChange={(e) => set("ativo", e.target.checked)}
            />
            Ativo (visível para as empresas)
          </label>
          <label className="sm:col-span-2 text-sm">
            <span className="mb-1 block text-muted-foreground">Observações</span>
            <textarea
              value={form.observacoes}
              onChange={(e) => set("observacoes", e.target.value)}
              rows={2}
              className="w-full rounded-lg border bg-background px-3 py-2"
            />
          </label>
        </div>

        <div className="mt-5 flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap gap-2">
            {value && (
              <button
                type="button"
                onClick={() => onOpenDrawing(value)}
                className="inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-sm hover:bg-accent"
              >
                <DraftingCompass className="h-4 w-4" />
                {value.project_data != null ? "Editar desenho" : "Criar desenho"}
              </button>
            )}
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border px-4 py-2 text-sm hover:bg-accent"
            >
              Fechar
            </button>
            <button
              type="button"
              disabled={saving}
              onClick={onSave}
              className="rounded-lg bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground disabled:opacity-60"
            >
              {saving ? "Salvando…" : "Salvar"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
