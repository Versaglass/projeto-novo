import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { useCompany } from "@/contexts/company-context";
import { StorageImage } from "@/components/StorageImage";
import { toast } from "sonner";
import { z } from "zod";
import { validarCnpj, formatarCnpj } from "@/lib/cnpj";
import { validarTelefoneBrCom, MENSAGENS_TELEFONE_EMPRESA } from "@/lib/whatsapp";
import { CampoMascarado } from "@/components/CampoMascarado";
import { mascararCnpj, mascararTelefoneBr, mascararSalvo } from "@/lib/mascara-campo";
import { UFS_BRASIL, ehUfValida } from "@/lib/uf";
import {
  User,
  Mail,
  Phone,
  Building2,
  Shield,
  Save,
  KeyRound,
  Eye,
  EyeOff,
  Image as ImageIcon,
  MapPin,
  FileText,
  type LucideIcon,
} from "lucide-react";

export const Route = createFileRoute("/_authenticated/app/conta")({
  component: ContaPage,
});

function ContaPage() {
  const { user, role, isAdmin } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [nome, setNome] = useState("");
  const [empresa, setEmpresa] = useState("");
  const [telefone, setTelefone] = useState("");
  const [createdAt, setCreatedAt] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase
        .from("profiles")
        .select("nome, empresa, telefone, created_at")
        .eq("id", user.id)
        .maybeSingle();
      if (data) {
        setNome(data.nome ?? "");
        setEmpresa(data.empresa ?? "");
        setTelefone(data.telefone ?? "");
        setCreatedAt(data.created_at ?? null);
      }
      setLoading(false);
    })();
  }, [user]);

  const salvar = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({ nome, empresa, telefone })
      .eq("id", user.id);
    setSaving(false);
    if (error) toast.error("Erro ao salvar: " + error.message);
    else toast.success("Dados atualizados");
  };

  if (loading) return <div className="text-muted-foreground">Carregando…</div>;

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">Minha conta</h1>
        <p className="text-muted-foreground mt-1">Dados da conta logada</p>
      </div>

      <div className="rounded-xl border bg-card p-6 space-y-5">
        <div className="flex items-center gap-4 pb-4 border-b">
          <div className="grid h-14 w-14 place-items-center rounded-full bg-gold/15 text-gold">
            <User className="h-6 w-6" />
          </div>
          <div className="flex-1">
            <div className="font-semibold">{nome || user?.email}</div>
            <div className="text-sm text-muted-foreground flex items-center gap-1.5">
              <Mail className="h-3.5 w-3.5" /> {user?.email}
            </div>
          </div>
          {role && (
            <span className="inline-flex items-center gap-1 rounded-full bg-gold/15 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-gold">
              <Shield className="h-3 w-3" /> {role}
            </span>
          )}
        </div>

        <Field label="Nome" icon={User}>
          <input
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            className="w-full rounded-lg border bg-background px-3 py-2 text-sm"
          />
        </Field>

        <Field label="Empresa" icon={Building2}>
          <input
            value={empresa}
            onChange={(e) => setEmpresa(e.target.value)}
            className="w-full rounded-lg border bg-background px-3 py-2 text-sm"
          />
        </Field>

        <Field label="Telefone" icon={Phone}>
          <input
            value={telefone}
            onChange={(e) => setTelefone(e.target.value)}
            className="w-full rounded-lg border bg-background px-3 py-2 text-sm"
          />
        </Field>

        <Field label="E-mail" icon={Mail}>
          <input
            value={user?.email ?? ""}
            disabled
            className="w-full rounded-lg border bg-muted px-3 py-2 text-sm text-muted-foreground"
          />
        </Field>

        <div className="grid grid-cols-2 gap-3 pt-2 text-xs text-muted-foreground">
          <div>
            <div className="uppercase tracking-wider">ID do usuário</div>
            <div className="font-mono truncate">{user?.id}</div>
          </div>
          {createdAt && (
            <div>
              <div className="uppercase tracking-wider">Conta criada em</div>
              <div>{new Date(createdAt).toLocaleDateString("pt-BR")}</div>
            </div>
          )}
        </div>

        <div className="flex justify-end pt-2">
          <button
            onClick={salvar}
            disabled={saving}
            className="inline-flex items-center gap-2 rounded-lg bg-gold px-4 py-2 text-sm font-semibold text-gold-foreground shadow-glow hover:opacity-90 disabled:opacity-50"
          >
            <Save className="h-4 w-4" />
            {saving ? "Salvando…" : "Salvar alterações"}
          </button>
        </div>
      </div>

      <CompanyDataCard />

      {isAdmin && (
        <div className="rounded-xl border bg-card p-4 text-sm text-muted-foreground">
          Você é administrador desta conta.
        </div>
      )}

      <ChangePasswordCard />
    </div>
  );
}

/**
 * Dados da empresa — grava em `public.company_profiles`, a MESMA linha que o PDF
 * do orçamento usa no cabeçalho e na seção CONTRATADO.
 *
 * Campos: só os que existem de verdade na tabela (company_name, cnpj, phone,
 * email, address, city, state, logo_url). Nenhum campo foi inventado.
 *
 * A RLS permite LEITURA a qualquer membro ativo (desde 20260727020000), mas a
 * ESCRITA continua restrita ao criador da empresa (`user_id = auth.uid()`) —
 * então o formulário fica somente-leitura para os demais membros, com aviso.
 */
/**
 * E-mail da empresa — mesmo validador que o cadastro de Clientes já usa
 * (`app.clientes.tsx`), que era a régua que o cadastro da própria empresa não
 * cumpria. `trim` + minúsculas antes de gravar: e-mail não diferencia caixa, e
 * guardar duas grafias do mesmo endereço só cria divergência depois.
 */
const emailEmpresaSchema = z
  .string()
  .trim()
  .toLowerCase()
  .email("O e-mail da empresa não é válido. Use o formato nome@dominio.com.br.")
  .max(160, "O e-mail da empresa passa de 160 caracteres.");

function CompanyDataCard() {
  const { user } = useAuth();
  const { activeCompany, loading: companyLoading } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [podeEditar, setPodeEditar] = useState(false);
  const [erroCnpj, setErroCnpj] = useState<string | null>(null);
  const [erroPhone, setErroPhone] = useState<string | null>(null);
  const [erroEmail, setErroEmail] = useState<string | null>(null);
  const [form, setForm] = useState({
    company_name: "",
    cnpj: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    state: "",
    logo_url: "",
  });

  useEffect(() => {
    if (!companyId) {
      setLoading(false);
      return;
    }
    let ativo = true;
    (async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from("company_profiles")
        .select("user_id, company_name, cnpj, phone, email, address, city, state, logo_url")
        .eq("id", companyId)
        .maybeSingle();
      if (!ativo) return;
      if (error) {
        toast.error("Não foi possível carregar os dados da empresa.");
      } else if (data) {
        // `types.ts` ainda não conhece `logo_url` (será regenerado após o push
        // da 20260727020000). Mesmo padrão já usado nos outros módulos.
        const d = data as unknown as Record<string, string | null>;
        setPodeEditar(d.user_id === user?.id);
        // `mascararSalvo` (e não a máscara direta): o que já está gravado só é
        // mascarado quando a máscara representa o valor INTEIRO. Um telefone
        // com mais dígitos do que o formato comporta apareceria encurtado, e o
        // próximo "Salvar" gravaria a versão mutilada por cima do original.
        setForm({
          company_name: d.company_name ?? "",
          cnpj: mascararSalvo(d.cnpj, mascararCnpj),
          phone: mascararSalvo(d.phone, mascararTelefoneBr),
          email: d.email ?? "",
          address: d.address ?? "",
          city: d.city ?? "",
          // Sigla válida é canonizada em maiúsculas para casar com uma opção do
          // select ("sp" gravado → "SP"); o que NÃO é sigla fica intacto, para
          // a opção "(fora da lista)" poder mostrá-lo em vez de perdê-lo.
          state: ehUfValida(d.state) ? String(d.state).trim().toUpperCase() : (d.state ?? ""),
          logo_url: d.logo_url ?? "",
        });
      }
      setLoading(false);
    })();
    return () => {
      ativo = false;
    };
  }, [companyId, user?.id]);

  // Vazio vira NULL — o PDF omite linhas ausentes em vez de imprimir vazio.
  const limpar = (v: string, max: number) => {
    const t = v.trim().slice(0, max);
    return t === "" ? null : t;
  };

  /**
   * Travas de validação (Revisão 92).
   *
   * Antes daqui, o `salvar` tinha UMA trava — nome não-vazio — e todo o resto
   * passava por `trim().slice(max)`. A Revisão 91 mediu o efeito: `abc` no
   * CNPJ, `banana` no telefone e `não-é-email` no e-mail eram gravados em
   * silêncio, com toast de sucesso, e o CNPJ inválido ainda ia impresso no PDF
   * entregue ao cliente.
   *
   * Os três campos continuam OPCIONAIS — vazio é ausência legítima e vira
   * NULL. O que mudou é que, **preenchido, precisa estar certo**.
   *
   * A validação acontece no ENVIO, não a cada tecla: é a regra que a Revisão 32
   * fixou para campo numérico (estado em texto, conversão só no envio), e vale
   * pelo mesmo motivo — validar enquanto se digita acusa erro em "12.AB" que
   * ainda vai virar um CNPJ inteiro.
   */
  const validarFormulario = ():
    | { ok: true; cnpj: string | null; phone: string | null; email: string | null }
    | { ok: false; erro: string } => {
    if (!form.company_name.trim()) return { ok: false, erro: "O nome da empresa é obrigatório." };

    const cnpj = validarCnpj(form.cnpj);
    if (!cnpj.ok) return { ok: false, erro: cnpj.erro };

    // Telefone opcional: só valida o que foi preenchido. A regra é a mesma das
    // Revisões 56-59 já usada no cliente, com as frases desta tela.
    let phone: string | null = null;
    if (form.phone.trim()) {
      const tel = validarTelefoneBrCom(form.phone, MENSAGENS_TELEFONE_EMPRESA);
      if (!tel.ok) return { ok: false, erro: tel.erro };
      // Guarda o que o usuário digitou, não o E.164 do WhatsApp: este campo
      // vai IMPRESSO no PDF, e `formatPhone` já cuida da apresentação.
      phone = form.phone.trim().slice(0, 32);
    }

    let email: string | null = null;
    if (form.email.trim()) {
      const parsed = emailEmpresaSchema.safeParse(form.email);
      if (!parsed.success) return { ok: false, erro: parsed.error.issues[0].message };
      email = parsed.data;
    }

    return { ok: true, cnpj: cnpj.ok && cnpj.cnpj ? cnpj.cnpj : null, phone, email };
  };

  const salvar = async () => {
    if (!companyId || saving) return;
    const v = validarFormulario();
    if (!v.ok) {
      toast.error(v.erro);
      return;
    }
    setSaving(true);
    const { error } = await supabase
      .from("company_profiles")
      .update({
        company_name: form.company_name.trim().slice(0, 120),
        // CNPJ gravado SEM máscara e em maiúsculas — forma canônica. A máscara
        // é apresentação (`formatarCnpj`/`formatDoc`), não dado.
        cnpj: v.cnpj,
        phone: v.phone,
        email: v.email,
        address: limpar(form.address, 240),
        city: limpar(form.city, 120),
        state: limpar(form.state, 40),
      } as never)
      .eq("id", companyId);
    setSaving(false);
    if (error) {
      toast.error("Erro ao salvar: " + error.message);
      return;
    }
    // Reflete na tela o que foi gravado: o campo passa a mostrar o CNPJ
    // formatado, em vez de continuar exibindo o que foi digitado.
    setForm((f) => ({ ...f, cnpj: v.cnpj ? formatarCnpj(v.cnpj) : "", email: v.email ?? "" }));
    toast.success("Dados da empresa atualizados");
  };

  // Logotipo no prefixo da própria empresa — as policies empresariais do bucket
  // já cobrem `<company_id>/…`, e a CHECK do banco recusa qualquer outro path.
  const enviarLogo = async (file: File) => {
    if (!companyId) return;
    const permitidos = ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"];
    if (!permitidos.includes(file.type)) {
      toast.error("Formato não permitido (use JPG, PNG, WEBP, GIF ou AVIF).");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Imagem acima de 5 MB.");
      return;
    }
    setUploading(true);
    const anterior = form.logo_url;
    try {
      const ext =
        (file.name.split(".").pop() || "png").toLowerCase().replace(/[^a-z0-9]/g, "") || "png";
      const path = `${companyId}/logo/${crypto.randomUUID()}.${ext}`;
      const { error: upErro } = await supabase.storage
        .from("project-images")
        .upload(path, file, { upsert: false, contentType: file.type });
      if (upErro) throw upErro;

      const { error } = await supabase
        .from("company_profiles")
        .update({ logo_url: path } as never)
        .eq("id", companyId);
      if (error) {
        // Rollback: não deixa arquivo órfão se o banco recusar.
        await supabase.storage
          .from("project-images")
          .remove([path])
          .catch(() => {});
        throw error;
      }
      setForm((f) => ({ ...f, logo_url: path }));
      if (anterior && anterior.startsWith(`${companyId}/`)) {
        await supabase.storage
          .from("project-images")
          .remove([anterior])
          .catch(() => {});
      }
      toast.success("Logotipo atualizado");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Falha ao enviar o logotipo.");
    } finally {
      setUploading(false);
    }
  };

  if (companyLoading || loading) {
    return (
      <div className="rounded-xl border bg-card p-6 text-sm text-muted-foreground">
        Carregando dados da empresa…
      </div>
    );
  }

  if (!companyId) {
    return (
      <div className="rounded-xl border bg-card p-6 text-sm text-muted-foreground">
        Selecione ou crie uma empresa para preencher os dados que aparecem no PDF do orçamento.
      </div>
    );
  }

  return (
    <div className="space-y-5 rounded-xl border bg-card p-6">
      <div className="flex items-start justify-between gap-3 border-b pb-4">
        <div>
          <h2 className="font-semibold">Dados da empresa</h2>
          <p className="mt-0.5 text-sm text-muted-foreground">
            Aparecem no cabeçalho e na assinatura do PDF dos orçamentos.
          </p>
        </div>
        <Building2 className="h-5 w-5 text-muted-foreground" />
      </div>

      {!podeEditar && (
        <div className="rounded-lg border border-border bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
          Somente quem criou a empresa pode alterar estes dados. Você está vendo os valores atuais.
        </div>
      )}

      <div className="flex items-center gap-4">
        {form.logo_url ? (
          <StorageImage
            src={form.logo_url}
            alt="Logotipo"
            className="h-16 w-16 rounded-lg border border-border object-contain bg-background"
          />
        ) : (
          <div className="grid h-16 w-16 place-items-center rounded-lg border border-dashed border-border bg-muted text-muted-foreground">
            <ImageIcon className="h-6 w-6" />
          </div>
        )}
        <label
          className={`inline-flex items-center gap-2 rounded-lg border border-input bg-background px-3 py-2 text-sm ${
            podeEditar ? "cursor-pointer hover:bg-accent" : "cursor-not-allowed opacity-50"
          }`}
        >
          <ImageIcon className="h-4 w-4" />
          {uploading ? "Enviando…" : form.logo_url ? "Trocar logotipo" : "Adicionar logotipo"}
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif,image/avif"
            className="hidden"
            disabled={!podeEditar || uploading}
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) enviarLogo(f);
              e.target.value = "";
            }}
          />
        </label>
      </div>

      <Field label="Nome da empresa *" icon={Building2}>
        <input
          value={form.company_name}
          disabled={!podeEditar}
          onChange={(e) => setForm({ ...form, company_name: e.target.value })}
          className={inputCls(podeEditar)}
        />
      </Field>

      {/* A MÁSCARA é a cada tecla (Revisão 95); o AVISO continua só ao sair do
          campo (`onBlur`). A distinção é o ponto: mascarar é apresentação e
          nunca recusa nada, enquanto validar durante a digitação acusaria erro
          em "12.AB", que ainda vai virar um CNPJ inteiro — a razão da regra da
          Revisão 32, que segue de pé. */}
      <div className="grid gap-4 md:grid-cols-2">
        <Field label="CNPJ" icon={FileText}>
          <CampoMascarado
            value={form.cnpj}
            disabled={!podeEditar}
            mascara={mascararCnpj}
            inputMode="text"
            onChange={(v) => setForm({ ...form, cnpj: v })}
            onBlur={() => {
              const r = validarCnpj(form.cnpj);
              // Válido: mostra formatado, para o usuário ver o que foi entendido.
              if (r.ok && r.cnpj) setForm((f) => ({ ...f, cnpj: r.formatado }));
              setErroCnpj(r.ok ? null : r.erro);
            }}
            placeholder="00.000.000/0000-00 ou 12.ABC.345/01DE-35"
            className={inputCls(podeEditar)}
          />
          <Aviso texto={erroCnpj} />
        </Field>
        <Field label="Telefone" icon={Phone}>
          <CampoMascarado
            value={form.phone}
            disabled={!podeEditar}
            mascara={mascararTelefoneBr}
            inputMode="tel"
            onChange={(v) => setForm({ ...form, phone: v })}
            onBlur={() => {
              if (!form.phone.trim()) return setErroPhone(null);
              const r = validarTelefoneBrCom(form.phone, MENSAGENS_TELEFONE_EMPRESA);
              setErroPhone(r.ok ? null : r.erro);
            }}
            placeholder="(00) 00000-0000"
            className={inputCls(podeEditar)}
          />
          <Aviso texto={erroPhone} />
        </Field>
      </div>

      <Field label="E-mail" icon={Mail}>
        <input
          value={form.email}
          disabled={!podeEditar}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          onBlur={() => {
            if (!form.email.trim()) return setErroEmail(null);
            const r = emailEmpresaSchema.safeParse(form.email);
            setErroEmail(r.success ? null : r.error.issues[0].message);
          }}
          placeholder="contato@suaempresa.com.br"
          className={inputCls(podeEditar)}
        />
        <Aviso texto={erroEmail} />
      </Field>

      <Field label="Endereço" icon={MapPin}>
        <input
          value={form.address}
          disabled={!podeEditar}
          onChange={(e) => setForm({ ...form, address: e.target.value })}
          placeholder="Rua, número, complemento e bairro"
          className={inputCls(podeEditar)}
        />
      </Field>

      <div className="grid gap-4 md:grid-cols-[1fr_120px]">
        <Field label="Cidade" icon={MapPin}>
          <input
            value={form.city}
            disabled={!podeEditar}
            onChange={(e) => setForm({ ...form, city: e.target.value })}
            className={inputCls(podeEditar)}
          />
        </Field>
        {/* UF é conjunto FECHADO de 27 valores: o select resolve máscara e
            validação de uma vez. O `toUpperCase().slice(0, 2)` de antes deixava
            passar "XX" e "ZZ" sem uma palavra. */}
        <Field label="UF" icon={MapPin}>
          <select
            value={form.state}
            disabled={!podeEditar}
            onChange={(e) => setForm({ ...form, state: e.target.value })}
            className={inputCls(podeEditar)}
          >
            <option value="">—</option>
            {/* Valor JÁ GRAVADO fora da lista continua aparecendo, marcado como
                tal. Sem isto o select nasceria vazio e o primeiro "Salvar"
                apagaria a UF do cadastro sem ninguém pedir — máscara nova não
                pode descartar dado antigo em silêncio. */}
            {form.state && !ehUfValida(form.state) && (
              <option value={form.state}>{form.state} (fora da lista)</option>
            )}
            {UFS_BRASIL.map((sigla) => (
              <option key={sigla} value={sigla}>
                {sigla}
              </option>
            ))}
          </select>
        </Field>
      </div>

      {podeEditar && (
        <div className="flex justify-end pt-1">
          <button
            onClick={salvar}
            disabled={saving}
            className="inline-flex items-center gap-2 rounded-lg bg-gold px-4 py-2 text-sm font-semibold text-gold-foreground shadow-glow hover:opacity-90 disabled:opacity-50"
          >
            <Save className="h-4 w-4" />
            {saving ? "Salvando…" : "Salvar dados da empresa"}
          </button>
        </div>
      )}
    </div>
  );
}

/** Aviso de campo — some quando não há erro, sem ocupar espaço. */
function Aviso({ texto }: { texto: string | null }) {
  if (!texto) return null;
  return <p className="mt-1.5 text-xs font-medium text-destructive">{texto}</p>;
}

const inputCls = (habilitado: boolean) =>
  habilitado
    ? "w-full rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
    : "w-full rounded-lg border bg-muted px-3 py-2 text-sm text-muted-foreground";

function ChangePasswordCard() {
  const [pwd, setPwd] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [saving, setSaving] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pwd.length < 6) return toast.error("Senha deve ter ao menos 6 caracteres");
    if (pwd !== confirm) return toast.error("As senhas não coincidem");
    setSaving(true);
    const { error } = await supabase.auth.updateUser({ password: pwd });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Senha alterada com sucesso");
    setPwd("");
    setConfirm("");
  };

  return (
    <form onSubmit={submit} className="rounded-xl border bg-card p-6 space-y-4 max-w-2xl">
      <div className="flex items-center gap-2">
        <KeyRound className="h-5 w-5 text-gold" />
        <h2 className="font-semibold">Alterar senha</h2>
      </div>
      <p className="text-sm text-muted-foreground -mt-2">
        Defina uma nova senha de acesso à conta.
      </p>

      <PwdInput label="Nova senha" value={pwd} onChange={setPwd} show={show} setShow={setShow} />
      <PwdInput
        label="Confirmar nova senha"
        value={confirm}
        onChange={setConfirm}
        show={show}
        setShow={setShow}
      />

      <div className="flex justify-end">
        <button
          type="submit"
          disabled={saving}
          className="inline-flex items-center gap-2 rounded-lg bg-gold px-4 py-2 text-sm font-semibold text-gold-foreground shadow-glow hover:opacity-90 disabled:opacity-50"
        >
          <KeyRound className="h-4 w-4" />
          {saving ? "Salvando…" : "Alterar senha"}
        </button>
      </div>
    </form>
  );
}

function PwdInput({
  label,
  value,
  onChange,
  show,
  setShow,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  show: boolean;
  setShow: (v: boolean) => void;
}) {
  return (
    <div>
      <label className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        <KeyRound className="h-3 w-3" /> {label}
      </label>
      <div className="relative">
        <input
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          minLength={6}
          className="w-full rounded-lg border bg-background px-3 py-2 pr-10 text-sm"
        />
        <button
          type="button"
          onClick={() => setShow(!show)}
          aria-label={show ? "Ocultar senha" : "Mostrar senha"}
          className="absolute right-1 top-1/2 -translate-y-1/2 rounded p-1.5 text-muted-foreground hover:text-foreground"
        >
          {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>
    </div>
  );
}

function Field({
  label,
  icon: Icon,
  children,
}: {
  label: string;
  icon: LucideIcon;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        <Icon className="h-3 w-3" /> {label}
      </label>
      {children}
    </div>
  );
}
