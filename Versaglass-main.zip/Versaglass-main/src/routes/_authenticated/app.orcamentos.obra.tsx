import { createFileRoute, Link, useNavigate, type SearchSchemaInput } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, HelpCircle } from "lucide-react";
import { toast } from "sonner";
import { useCompany } from "@/contexts/company-context";
import { usePlatformCatalogPicker } from "@/hooks/use-platform-project-catalog";
import {
  ProjectAreaSubtypeFilters,
  type FiltroAreaProjeto,
  type FiltroSubtipoProjeto,
} from "@/components/projects/ProjectAreaSubtypeFilters";
import { ProjectCategoryChips } from "@/components/quotes/ProjectCategoryChips";
import { ProjectTemplatePickerGrid } from "@/components/quotes/ProjectTemplatePickerGrid";
import { AREAS_OPERACIONAIS, ehAreaOperacional } from "@/lib/project-area";
import type { FiltroCategoriaProjeto } from "@/lib/project-category";
import { categoriaProjetoLabel } from "@/lib/project-category";
import { searchOrcamentoNovo } from "@/routes/_authenticated/app.orcamentos.novo";

/** O que `Link`/`navigate` podem informar — tudo opcional, os defaults vêm do validateSearch. */
type ObraSearchInput = {
  cliente?: string;
} & SearchSchemaInput;

/** O que `Route.useSearch()` devolve — defaults já aplicados. */
type ObraSearch = {
  cliente: string;
};

export const Route = createFileRoute("/_authenticated/app/orcamentos/obra")({
  validateSearch: (search: ObraSearchInput): ObraSearch => ({
    cliente: typeof search.cliente === "string" ? search.cliente : "",
  }),
  component: ObraForm,
});

/**
 * Lista de Projeto — seletor de UM modelo do catálogo global.
 *
 * Clique no card → `/app/orcamentos/novo?cliente=&catalogId=` (mesmo contrato
 * do "Aplicar no orçamento" em Projetos). Snapshot no item; sem cópia por empresa.
 */
function ObraForm() {
  const { cliente } = Route.useSearch();
  const navigate = useNavigate();
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  // Eixo principal = área → subtipo. Categoria de material só em vidracaria.
  const [filtroArea, setFiltroArea] = useState<FiltroAreaProjeto>("todos");
  const [filtroSubtipo, setFiltroSubtipo] = useState<FiltroSubtipoProjeto>("todos");
  const [filtroCategoria, setFiltroCategoria] = useState<FiltroCategoriaProjeto>("all");
  const [buscaModelos, setBuscaModelos] = useState("");

  const { data: modelos = [], isLoading: carregandoModelos } = usePlatformCatalogPicker();

  const { data: customer, isLoading: carregandoCliente } = useQuery({
    queryKey: ["customer-obra", companyId, cliente],
    enabled: !!companyId && !!cliente,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("customers")
        .select("id,nome,telefone,email")
        .eq("id", cliente)
        .eq("company_id", companyId!)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  /** Catálogo operacional: só áreas habilitadas (Vidraçaria + Esquadrias). */
  const modelosOperacionais = useMemo(
    () => modelos.filter((m) => ehAreaOperacional(m.area)),
    [modelos],
  );

  const contagensArea = useMemo(() => {
    const c: Partial<Record<FiltroAreaProjeto, number>> = {
      todos: modelosOperacionais.length,
    };
    for (const a of AREAS_OPERACIONAIS) {
      c[a] = 0;
    }
    for (const m of modelosOperacionais) {
      if (m.area) c[m.area] = (c[m.area] ?? 0) + 1;
    }
    return c;
  }, [modelosOperacionais]);

  const escolherArea = (nova: FiltroAreaProjeto) => {
    // Área histórica em estado residual → volta para "todos".
    const areaSegura: FiltroAreaProjeto =
      nova === "todos" || ehAreaOperacional(nova) ? nova : "todos";
    setFiltroArea(areaSegura);
    if (areaSegura !== filtroArea) {
      setFiltroSubtipo("todos");
      setFiltroCategoria("all");
    }
  };

  /** Modelos após área + subtipo (antes de material/busca) — base do grid e dos chips de material. */
  const modelosPorAreaSubtipo = useMemo(() => {
    let list = modelosOperacionais;
    if (filtroArea !== "todos") {
      list = list.filter((m) => m.area === filtroArea);
    }
    if (filtroArea !== "todos" && filtroSubtipo !== "todos") {
      list = list.filter((m) => m.subtipo === filtroSubtipo);
    }
    return list;
  }, [modelosOperacionais, filtroArea, filtroSubtipo]);

  const mostrarFiltroMaterial = filtroArea === "vidracaria";

  const modelosFiltrados = useMemo(() => {
    let list = modelosPorAreaSubtipo;
    if (mostrarFiltroMaterial && filtroCategoria !== "all") {
      list = list.filter((m) => m.categoria === filtroCategoria);
    }
    const termo = buscaModelos.trim().toLowerCase();
    if (!termo) return list;
    return list.filter(
      (m) =>
        m.nome.toLowerCase().includes(termo) ||
        (m.descricao ?? "").toLowerCase().includes(termo) ||
        categoriaProjetoLabel(m.categoria).toLowerCase().includes(termo),
    );
  }, [modelosPorAreaSubtipo, mostrarFiltroMaterial, filtroCategoria, buscaModelos]);

  const abrirFormularioComModelo = (modelo: { id: string }) => {
    if (!cliente) {
      toast.error("Selecione um cliente antes.");
      return;
    }
    if (!customer) {
      toast.error("Cliente não encontrado nesta empresa.");
      return;
    }
    navigate({
      to: "/app/orcamentos/novo",
      search: searchOrcamentoNovo({ cliente, catalogId: modelo.id }),
    });
  };

  return (
    <div className="space-y-6 pb-8">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Link
            to="/app/orcamentos"
            search={{ view: "lista" }}
            className="inline-flex items-center gap-1 rounded-lg border border-input px-3 py-1.5 text-xs hover:bg-accent"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Voltar
          </Link>
          <div>
            <h1 className="font-display text-2xl font-bold">Lista de Projeto</h1>
            <p className="text-xs text-muted-foreground">
              Cliente:{" "}
              <strong className="text-foreground">
                {carregandoCliente ? "…" : (customer?.nome ?? "—")}
              </strong>
              <span className="text-muted-foreground">
                {" "}
                · Escolha um modelo para abrir o formulário de orçamento
              </span>
            </p>
          </div>
        </div>
        <button
          type="button"
          className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 px-3 py-1.5 text-xs text-primary hover:bg-primary/5"
        >
          <HelpCircle className="h-3.5 w-3.5" /> Ajuda
        </button>
      </div>

      {!cliente && (
        <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive">
          Nenhum cliente informado. Volte e selecione um cliente antes de montar o orçamento.
        </div>
      )}

      <div className="space-y-3 rounded-2xl border border-border bg-card p-3">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Área e tipo de projeto
        </div>
        <ProjectAreaSubtypeFilters
          area={filtroArea}
          subtipo={filtroSubtipo}
          onAreaChange={escolherArea}
          onSubtipoChange={setFiltroSubtipo}
          contagens={contagensArea}
          disabled={!companyId}
        />
        {mostrarFiltroMaterial && (
          <div className="space-y-2 border-t border-border pt-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Material (Vidraçaria)
            </div>
            <ProjectCategoryChips
              modelos={modelosPorAreaSubtipo}
              selected={filtroCategoria}
              onSelect={setFiltroCategoria}
            />
          </div>
        )}
      </div>

      <ProjectTemplatePickerGrid
        items={modelosFiltrados}
        totalItems={modelosPorAreaSubtipo.length}
        busca={buscaModelos}
        onBuscaChange={setBuscaModelos}
        onPick={abrirFormularioComModelo}
        pickTitle="Abrir no formulário de orçamento"
        loading={carregandoModelos}
        disabled={!cliente || !customer}
        imageBucket="platform-catalog"
      />
    </div>
  );
}
