import { createFileRoute, Outlet, useLocation } from "@tanstack/react-router";
import { DashboardEnterprise } from "@/pages/DashboardEnterprise";

function AppRouteShell() {
  const location = useLocation();
  // Garantia extra: mesmo que o index route não seja carregado pelo TanStack,
  // a rota /app sempre renderiza a nova tela inicial Enterprise.
  if (location.pathname === "/app" || location.pathname === "/app/") {
    return <DashboardEnterprise />;
  }
  return <Outlet />;
}

export const Route = createFileRoute("/_authenticated/app")({
  component: AppRouteShell,
});
