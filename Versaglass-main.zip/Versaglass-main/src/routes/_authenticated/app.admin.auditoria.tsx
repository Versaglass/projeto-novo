import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Activity, Search, ShieldCheck } from "lucide-react";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { requireAdmin } from "@/lib/admin-guard";

export const Route = createFileRoute("/_authenticated/app/admin/auditoria")({
  beforeLoad: requireAdmin,
  component: AuditoriaPage,
});

type AuditRow = {
  id: string;
  action: string;
  actor_email?: string;
  entity?: string;
  entity_id?: string;
  ip?: string;
  created_at: string;
  metadata?: Record<string, unknown>;
};

function AuditoriaPage() {
  const { isAdmin } = useAuth();
  const [q, setQ] = useState("");
  const { data = [], isLoading } = useQuery({
    queryKey: ["audit_logs"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("audit_logs")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(300);
      if (error) throw error;
      return (data ?? []) as AuditRow[];
    },
  });
  const rows = useMemo(
    () =>
      data.filter((r) =>
        `${r.action} ${r.actor_email ?? ""} ${r.entity ?? ""}`
          .toLowerCase()
          .includes(q.toLowerCase()),
      ),
    [data, q],
  );
  if (!isAdmin) return null;
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <Badge className="mb-3 gap-1">
            <ShieldCheck className="h-3.5 w-3.5" />
            Admin
          </Badge>
          <h1 className="font-display text-3xl font-bold">Auditoria</h1>
          <p className="text-sm text-muted-foreground">
            Histórico de alterações críticas, acessos e ações dos usuários.
          </p>
        </div>
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar ação, usuário ou entidade"
            className="pl-9"
          />
        </div>
      </div>
      <div className="grid gap-3 md:grid-cols-3">
        <Metric label="Eventos" value={data.length} />
        <Metric
          label="Usuários únicos"
          value={new Set(data.map((r) => r.actor_email).filter(Boolean)).size}
        />
        <Metric
          label="Hoje"
          value={
            data.filter((r) => new Date(r.created_at).toDateString() === new Date().toDateString())
              .length
          }
        />
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Eventos recentes
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-sm text-muted-foreground">Carregando…</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Ação</TableHead>
                  <TableHead>Usuário</TableHead>
                  <TableHead>Entidade</TableHead>
                  <TableHead>IP</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell>{new Date(r.created_at).toLocaleString("pt-BR")}</TableCell>
                    <TableCell className="font-medium">{r.action}</TableCell>
                    <TableCell>{r.actor_email ?? "—"}</TableCell>
                    <TableCell>{r.entity ?? "—"}</TableCell>
                    <TableCell>{r.ip ?? "—"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
function Metric({ label, value }: { label: string; value: number }) {
  return (
    <Card>
      <CardContent className="p-5">
        <div className="text-sm text-muted-foreground">{label}</div>
        <div className="mt-1 font-display text-3xl font-bold">{value}</div>
      </CardContent>
    </Card>
  );
}
