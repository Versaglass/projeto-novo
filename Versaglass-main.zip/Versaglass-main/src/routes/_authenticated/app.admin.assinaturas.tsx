import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";
import {
  Bell,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Users,
  RefreshCw,
  Send,
  Plus,
  MessageCircle,
  type LucideIcon,
} from "lucide-react";
import { normalizeBrPhone, openWhatsApp } from "@/lib/whatsapp";
import { validaCamposNumericos } from "@/lib/numero-campo";
import { requireAdmin } from "@/lib/admin-guard";

export const Route = createFileRoute("/_authenticated/app/admin/assinaturas")({
  beforeLoad: requireAdmin,
  component: AdminAssinaturas,
});

type Sub = {
  id: string;
  user_id: string;
  plano: string;
  valor: number;
  dia_vencimento: number;
  proximo_vencimento: string;
  ultimo_pagamento: string | null;
  status: "ativo" | "suspenso" | "cancelado";
  observacoes: string | null;
};

type Profile = { id: string; nome: string | null; empresa: string | null; telefone: string | null };

function computeState(s: Sub) {
  if (s.status === "cancelado") return "cancelado";
  if (s.status === "suspenso") return "suspenso";
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const due = new Date(s.proximo_vencimento + "T00:00:00");
  const diff = Math.floor((due.getTime() - today.getTime()) / 86400000);
  if (diff < 0) return "atrasado";
  if (diff <= 5) return "proximo";
  return "em_dia";
}

const stateLabel: Record<string, { label: string; cls: string; icon: LucideIcon }> = {
  em_dia: { label: "Em dia", cls: "bg-emerald-500/15 text-emerald-600", icon: CheckCircle2 },
  proximo: { label: "Próximo do venc.", cls: "bg-amber-500/15 text-amber-600", icon: Clock },
  atrasado: { label: "Atrasado", cls: "bg-red-500/15 text-red-600", icon: AlertTriangle },
  suspenso: { label: "Suspenso", cls: "bg-zinc-500/15 text-zinc-600", icon: AlertTriangle },
  cancelado: { label: "Cancelado", cls: "bg-zinc-500/15 text-zinc-600", icon: AlertTriangle },
};

function AdminAssinaturas() {
  const { isAdmin, loading } = useAuth();
  const [subs, setSubs] = useState<Sub[]>([]);
  const [profiles, setProfiles] = useState<Record<string, Profile>>({});
  const [busy, setBusy] = useState(false);
  const [showNew, setShowNew] = useState(false);

  async function load() {
    const [{ data: s }, { data: p }] = await Promise.all([
      supabase
        .from("subscriptions")
        .select("*")
        .order("proximo_vencimento", { ascending: true }),
      supabase.from("profiles").select("id, nome, empresa, telefone"),
    ]);
    setSubs((s ?? []) as Sub[]);
    const map: Record<string, Profile> = {};
    (p ?? []).forEach((x) => {
      map[x.id] = x;
    });
    setProfiles(map);
  }

  useEffect(() => {
    if (!isAdmin) return;
    load();
    // auto-generate notifications on open
    supabase.rpc("generate_billing_notifications").then(({ data, error }) => {
      if (!error && data && data > 0)
        toast.success(`${data} notificação(ões) automática(s) geradas`);
    });
  }, [isAdmin]);

  const stats = useMemo(() => {
    const out = {
      total: subs.length,
      em_dia: 0,
      proximo: 0,
      atrasado: 0,
      suspenso: 0,
      cancelado: 0,
      receita: 0,
    };
    subs.forEach((s) => {
      const st = computeState(s);
      if (st === "em_dia" || st === "proximo" || st === "atrasado" || st === "suspenso" || st === "cancelado") {
        out[st] += 1;
      }
      if (s.status === "ativo") out.receita += Number(s.valor || 0);
    });
    return out;
  }, [subs]);

  if (loading) return <div className="text-muted-foreground">Carregando…</div>;
  if (!isAdmin) return null;

  async function regenerate() {
    setBusy(true);
    const { data, error } = await supabase.rpc("generate_billing_notifications");
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(`${data ?? 0} notificação(ões) geradas`);
  }

  async function sendNotif(sub: Sub, kind: "atraso" | "lembrete" | "aviso") {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(sub.proximo_vencimento + "T00:00:00");
    const diff = Math.floor((due.getTime() - today.getTime()) / 86400000);
    const titulo =
      kind === "atraso"
        ? "Mensalidade em atraso"
        : kind === "lembrete"
          ? "Lembrete de vencimento"
          : "Aviso da administração";
    const mensagem =
      kind === "atraso"
        ? `Sua mensalidade ${sub.plano} venceu há ${Math.max(0, -diff)} dia(s). Valor: R$ ${Number(sub.valor).toFixed(2)}. Regularize para evitar suspensão.`
        : kind === "lembrete"
          ? `Sua mensalidade ${sub.plano} vence em ${Math.max(0, diff)} dia(s) (${new Date(sub.proximo_vencimento + "T00:00:00").toLocaleDateString("pt-BR")}). Valor: R$ ${Number(sub.valor).toFixed(2)}.`
          : `Mensagem da administração sobre sua assinatura ${sub.plano}.`;
    const { error } = await supabase.from("billing_notifications").insert({
      user_id: sub.user_id,
      subscription_id: sub.id,
      kind,
      titulo,
      mensagem,
      valor: sub.valor,
      vencimento: sub.proximo_vencimento,
      dias_atraso: Math.max(0, -diff),
      status: "enviada",
    });
    if (error) return toast.error(error.message);
    toast.success("Notificação enviada");
  }

  function buildMsg(sub: Sub, kind: "atraso" | "lembrete") {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(sub.proximo_vencimento + "T00:00:00");
    const diff = Math.floor((due.getTime() - today.getTime()) / 86400000);
    const valor = Number(sub.valor).toFixed(2).replace(".", ",");
    const venc = due.toLocaleDateString("pt-BR");
    if (kind === "atraso") {
      return `Olá! 👋 Sua mensalidade *${sub.plano}* da Versátil Vidros venceu há ${Math.max(0, -diff)} dia(s) (${venc}).\n\n💰 Valor: R$ ${valor}\n\nPor favor, regularize para evitar a suspensão dos serviços. Qualquer dúvida estamos à disposição!`;
    }
    return `Olá! 👋 Passando para lembrar que sua mensalidade *${sub.plano}* da Versátil Vidros vence em ${Math.max(0, diff)} dia(s) (${venc}).\n\n💰 Valor: R$ ${valor}\n\nAgradecemos a parceria! 🙏`;
  }

  function onlyDigits(s: string | null | undefined) {
    return (s ?? "").replace(/\D/g, "");
  }

  async function sendWhatsApp(sub: Sub, kind: "atraso" | "lembrete") {
    const prof = profiles[sub.user_id];
    const phone = onlyDigits(prof?.telefone);
    if (!phone) return toast.error("Assinante não tem telefone cadastrado no perfil");
    const num = normalizeBrPhone(phone);
    const msg = buildMsg(sub, kind);
    openWhatsApp(num, msg);
    // also log notification as sent
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(sub.proximo_vencimento + "T00:00:00");
    const diff = Math.floor((due.getTime() - today.getTime()) / 86400000);
    await supabase.from("billing_notifications").insert({
      user_id: sub.user_id,
      subscription_id: sub.id,
      kind,
      titulo: kind === "atraso" ? "Cobrança enviada via WhatsApp" : "Lembrete enviado via WhatsApp",
      mensagem: msg,
      valor: sub.valor,
      vencimento: sub.proximo_vencimento,
      dias_atraso: Math.max(0, -diff),
      status: "enviada",
    });
    toast.success("WhatsApp aberto e notificação registrada");
  }

  async function markPaid(sub: Sub) {
    const next = new Date(sub.proximo_vencimento + "T00:00:00");
    next.setMonth(next.getMonth() + 1);
    const { error } = await supabase
      .from("subscriptions")
      .update({
        ultimo_pagamento: new Date().toISOString().slice(0, 10),
        proximo_vencimento: next.toISOString().slice(0, 10),
        status: "ativo",
      })
      .eq("id", sub.id);
    if (error) return toast.error(error.message);
    toast.success("Pagamento registrado");
    load();
  }

  async function updateSub(id: string, patch: Partial<Sub>) {
    const { error } = await supabase.from("subscriptions").update(patch).eq("id", id);
    if (error) return toast.error(error.message);
    load();
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Assinaturas</h1>
          <p className="text-sm text-muted-foreground">
            Controle de mensalidades e cobranças automáticas
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={regenerate}
            disabled={busy}
            className="inline-flex items-center gap-2 rounded-lg bg-muted px-3 py-2 text-sm hover:bg-muted/70"
          >
            <RefreshCw className="h-4 w-4" /> Gerar notificações
          </button>
          <button
            onClick={() => setShowNew(true)}
            className="inline-flex items-center gap-2 rounded-lg bg-gold px-3 py-2 text-sm font-semibold text-gold-foreground"
          >
            <Plus className="h-4 w-4" /> Nova assinatura
          </button>
        </div>
      </header>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        <Stat
          icon={Users}
          label="Ativos"
          value={stats.em_dia + stats.proximo}
          accent="text-emerald-600"
        />
        <Stat icon={Clock} label="Próx. venc." value={stats.proximo} accent="text-amber-600" />
        <Stat icon={AlertTriangle} label="Atrasados" value={stats.atrasado} accent="text-red-600" />
        <Stat icon={Bell} label="Suspensos" value={stats.suspenso} accent="text-zinc-600" />
        <Stat
          icon={CheckCircle2}
          label="Receita mensal"
          value={`R$ ${stats.receita.toFixed(2)}`}
          accent="text-foreground"
        />
      </div>

      <div className="overflow-hidden rounded-xl border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Assinante</th>
              <th className="px-4 py-3">Plano</th>
              <th className="px-4 py-3">Valor</th>
              <th className="px-4 py-3">Vencimento</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {subs.map((s) => {
              const st = computeState(s);
              const info = stateLabel[st];
              const Icon = info.icon;
              const prof = profiles[s.user_id];
              return (
                <tr key={s.id} className="border-t">
                  <td className="px-4 py-3">
                    <div className="font-medium">{prof?.nome ?? "—"}</div>
                    <div className="text-xs text-muted-foreground">{prof?.empresa ?? ""}</div>
                  </td>
                  <td className="px-4 py-3">{s.plano}</td>
                  <td className="px-4 py-3">R$ {Number(s.valor).toFixed(2)}</td>
                  <td className="px-4 py-3">
                    {new Date(s.proximo_vencimento + "T00:00:00").toLocaleDateString("pt-BR")}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${info.cls}`}
                    >
                      <Icon className="h-3 w-3" /> {info.label}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap justify-end gap-1.5">
                      {st === "atrasado" && (
                        <>
                          <button
                            onClick={() => sendWhatsApp(s, "atraso")}
                            className="inline-flex items-center gap-1 rounded-md bg-emerald-500/10 px-2 py-1 text-xs text-emerald-600 hover:bg-emerald-500/20"
                          >
                            <MessageCircle className="h-3 w-3" /> WhatsApp
                          </button>
                          <button
                            onClick={() => sendNotif(s, "atraso")}
                            className="inline-flex items-center gap-1 rounded-md bg-red-500/10 px-2 py-1 text-xs text-red-600 hover:bg-red-500/20"
                          >
                            <Send className="h-3 w-3" /> Cobrar
                          </button>
                        </>
                      )}
                      {st === "proximo" && (
                        <>
                          <button
                            onClick={() => sendWhatsApp(s, "lembrete")}
                            className="inline-flex items-center gap-1 rounded-md bg-emerald-500/10 px-2 py-1 text-xs text-emerald-600 hover:bg-emerald-500/20"
                          >
                            <MessageCircle className="h-3 w-3" /> WhatsApp
                          </button>
                          <button
                            onClick={() => sendNotif(s, "lembrete")}
                            className="inline-flex items-center gap-1 rounded-md bg-amber-500/10 px-2 py-1 text-xs text-amber-600 hover:bg-amber-500/20"
                          >
                            <Send className="h-3 w-3" /> Lembrar
                          </button>
                        </>
                      )}
                      <button
                        onClick={() => markPaid(s)}
                        className="rounded-md bg-emerald-500/10 px-2 py-1 text-xs text-emerald-600 hover:bg-emerald-500/20"
                      >
                        Pago
                      </button>
                      <select
                        value={s.status}
                        onChange={(e) =>
                          updateSub(s.id, {
                            status: e.target.value as Sub["status"],
                          })
                        }
                        className="rounded-md border bg-background px-1 py-1 text-xs"
                      >
                        <option value="ativo">Ativo</option>
                        <option value="suspenso">Suspender</option>
                        <option value="cancelado">Cancelar</option>
                      </select>
                    </div>
                  </td>
                </tr>
              );
            })}
            {subs.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">
                  Nenhuma assinatura cadastrada
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {showNew && (
        <NewSubModal
          profiles={profiles}
          onClose={() => setShowNew(false)}
          onSaved={() => {
            setShowNew(false);
            load();
          }}
        />
      )}
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: LucideIcon;
  label: string;
  value: string | number;
  accent?: string;
}) {
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Icon className="h-4 w-4" /> {label}
      </div>
      <div className={`mt-2 text-2xl font-bold ${accent}`}>{value}</div>
    </div>
  );
}

function NewSubModal({
  profiles,
  onClose,
  onSaved,
}: {
  profiles: Record<string, Profile>;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [user_id, setUser] = useState("");
  const [plano, setPlano] = useState("Mensal");
  // Texto, não número — ver `src/lib/numero-campo.ts`. O padrao usa virgula
  // porque e o formato que o usuario brasileiro digita.
  const [valor, setValor] = useState("99,90");
  const [dia, setDia] = useState("10");
  const [venc, setVenc] = useState(() => {
    const d = new Date();
    d.setDate(10);
    d.setMonth(d.getMonth() + 1);
    return d.toISOString().slice(0, 10);
  });

  async function save() {
    if (!user_id) return toast.error("Selecione o assinante");
    // Revisao 32 — `valor` e dinheiro e vai para o Postgres. Antes era
    // `Number(valor)` num `<input type="number">`: "99,90" chegava como `""` e
    // a assinatura era criada com mensalidade ZERO, sem aviso.
    const numeros = validaCamposNumericos([
      {
        chave: "valor",
        texto: valor,
        regra: { label: "o valor da mensalidade", min: 0, obrigatorio: true, casas: 2 },
      },
      {
        chave: "dia_vencimento",
        texto: dia,
        regra: { label: "o dia do vencimento", min: 1, max: 28, obrigatorio: true, inteiro: true },
      },
    ]);
    if (!numeros.ok) return toast.error(numeros.erro);
    const { error } = await supabase.from("subscriptions").insert({
      user_id,
      plano,
      valor: numeros.valores.valor,
      dia_vencimento: numeros.valores.dia_vencimento,
      proximo_vencimento: venc,
      status: "ativo",
    });
    if (error) return toast.error(error.message);
    toast.success("Assinatura criada");
    onSaved();
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div
        className="w-full max-w-md rounded-xl bg-card p-6 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="mb-4 font-display text-xl font-bold">Nova assinatura</h3>
        <div className="space-y-3 text-sm">
          <label className="block">
            <span className="text-muted-foreground">Assinante</span>
            <select
              value={user_id}
              onChange={(e) => setUser(e.target.value)}
              className="mt-1 w-full rounded-md border bg-background px-3 py-2"
            >
              <option value="">Selecione…</option>
              {Object.values(profiles).map((p) => (
                <option key={p.id} value={p.id}>
                  {p.nome ?? p.id}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="text-muted-foreground">Plano</span>
            <input
              value={plano}
              onChange={(e) => setPlano(e.target.value)}
              className="mt-1 w-full rounded-md border bg-background px-3 py-2"
            />
          </label>
          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="text-muted-foreground">Valor (R$)</span>
              <input
                inputMode="decimal"
                placeholder="99,90"
                value={valor}
                onChange={(e) => setValor(e.target.value)}
                className="mt-1 w-full rounded-md border bg-background px-3 py-2"
              />
            </label>
            <label className="block">
              <span className="text-muted-foreground">Dia venc.</span>
              <input
                inputMode="numeric"
                placeholder="10"
                value={dia}
                onChange={(e) => setDia(e.target.value)}
                className="mt-1 w-full rounded-md border bg-background px-3 py-2"
              />
            </label>
          </div>
          <label className="block">
            <span className="text-muted-foreground">Próximo vencimento</span>
            <input
              type="date"
              value={venc}
              onChange={(e) => setVenc(e.target.value)}
              className="mt-1 w-full rounded-md border bg-background px-3 py-2"
            />
          </label>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <button onClick={onClose} className="rounded-md px-3 py-2 text-sm">
            Cancelar
          </button>
          <button
            onClick={save}
            className="rounded-md bg-gold px-3 py-2 text-sm font-semibold text-gold-foreground"
          >
            Salvar
          </button>
        </div>
      </div>
    </div>
  );
}
