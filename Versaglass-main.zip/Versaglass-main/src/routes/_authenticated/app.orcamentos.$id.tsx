import { createFileRoute, Link } from "@tanstack/react-router";
import { searchOrcamentoNovo } from "@/routes/_authenticated/app.orcamentos.novo";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { brl, num, dateBR, statusLabel, statusTone } from "@/lib/format";
import {
  ArrowLeft,
  FileDown,
  MessageCircle,
  Trash2,
  Calendar,
  User,
  HardHat,
  ReceiptText,
  FileSignature,
  MapPin,
  StickyNote,
  ImagePlus,
  Edit3,
  type LucideIcon,
} from "lucide-react";
import { PipelineStatus, type Stage } from "@/components/PipelineStatus";
import { toast } from "sonner";
import { generateQuotePdf } from "@/lib/quote-pdf";
import { useNavigate } from "@tanstack/react-router";
import { openWhatsApp, validarTelefoneBr } from "@/lib/whatsapp";
import { StorageImage } from "@/components/StorageImage";
import {
  bucketForQuoteItemImage,
  itemPossuiImagem,
  pathForQuoteItemImage,
} from "@/lib/quote-item-image";
import { useState } from "react";
import { generateQuoteReportPdf, type QuoteReportKind } from "@/lib/quote-reports";
import { useCompany } from "@/contexts/company-context";
import { useFinePermissions } from "@/hooks/use-fine-permission";
import {
  useSetQuoteStatus,
  useSetQuoteStage,
  useSetQuoteInstalacao,
  useDeleteQuote,
  quoteErrorMessage,
  type QuoteStatus,
  type QuoteItem,
} from "@/hooks/use-quotes";
import { InstrucaoWhatsAppPdf } from "@/components/InstrucaoWhatsAppPdf";

export const Route = createFileRoute("/_authenticated/app/orcamentos/$id")({
  component: OrcamentoDetalhe,
});

/** Foto do item (snapshot projeto/catálogo/estoque). Silencioso sem imagem_url. */
function BlocoFotoItem({ item }: { item: { imagem_url?: string | null } }) {
  const bruto = (item.imagem_url ?? "").trim();
  if (!bruto) return null;
  return (
    <div className="mt-1">
      <StorageImage
        src={pathForQuoteItemImage(bruto)}
        bucket={bucketForQuoteItemImage(bruto)}
        alt=""
        className="max-h-[230px] w-full rounded-lg object-contain"
      />
    </div>
  );
}

function OrcamentoDetalhe() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const notesKey = `vmm_quote_notes_${id}`;
  const [noteText, setNoteText] = useState(() =>
    typeof window === "undefined" ? "" : (localStorage.getItem(notesKey) ?? ""),
  );
  const [noteImage, setNoteImage] = useState<string | null>(() =>
    typeof window === "undefined" ? null : localStorage.getItem(`${notesKey}_image`),
  );

  const { activeCompany, loading: companyLoading } = useCompany();
  const companyId = activeCompany?.companyId ?? null;
  const { edit_orcamentos: canEdit, delete_orcamentos: canDelete } = useFinePermissions();

  const { data, isLoading } = useQuery({
    queryKey: ["quote", companyId, id],
    enabled: !!companyId,
    queryFn: async () => {
      if (!companyId) return null;
      // Escopado à empresa ativa: um orçamento de outra empresa retorna null.
      const { data: quote, error } = await supabase
        .from("quotes")
        .select("*, customer:customers(*)")
        .eq("id", id)
        .eq("company_id", companyId)
        .maybeSingle();
      if (error) throw error;
      if (!quote) return null;
      const { data: items } = await supabase
        .from("quote_items")
        .select("*")
        .eq("quote_id", id)
        .order("ordem");
      const { data: profile } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", quote.owner_id)
        .maybeSingle();
      return {
        quote,
        items: (items ?? []) as unknown as QuoteItem[],
        profile: profile ?? {},
      };
    },
  });

  const setStatusM = useSetQuoteStatus();
  const setStageM = useSetQuoteStage();
  const setInstalacaoM = useSetQuoteInstalacao();
  const removeM = useDeleteQuote();

  const setStatus = (status: QuoteStatus) =>
    setStatusM.mutate(
      { id, value: status },
      {
        onSuccess: () => toast.success("Status atualizado"),
        onError: (e) => toast.error(quoteErrorMessage(e)),
      },
    );
  const setStage = (etapa: Stage) =>
    setStageM.mutate(
      { id, value: etapa },
      {
        onSuccess: () => toast.success("Etapa atualizada"),
        onError: (e) => toast.error(quoteErrorMessage(e)),
      },
    );
  const setInstalacaoEm = (date: string | null) =>
    setInstalacaoM.mutate(
      { id, value: date },
      {
        onSuccess: () => toast.success("Data de instalação salva"),
        onError: (e) => toast.error(quoteErrorMessage(e)),
      },
    );
  const remove = () =>
    removeM.mutate(id, {
      onSuccess: () => {
        toast.success("Orçamento excluído");
        navigate({ to: "/app/orcamentos" });
      },
      onError: (e) => toast.error(quoteErrorMessage(e)),
    });

  if (companyLoading || isLoading) return <p>Carregando...</p>;
  if (!companyId) return <p>Selecione uma empresa ativa para ver o orçamento.</p>;
  if (!data?.quote) return <p>Orçamento não encontrado.</p>;
  const { quote, items, profile } = data;
  const itensComFoto = items.filter((i) => itemPossuiImagem(i));

  const saveNote = () => {
    localStorage.setItem(notesKey, noteText);
    if (noteImage) localStorage.setItem(`${notesKey}_image`, noteImage);
    toast.success("Notas salvas no orçamento");
  };

  const openMap = () => {
    const address = [quote.customer?.endereco, quote.customer?.cidade].filter(Boolean).join(" ");
    if (!address) {
      toast.error("Cliente sem endereço cadastrado");
      return;
    }
    window.open(
      `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`,
      "_blank",
    );
  };

  const waMessage = `Olá ${quote.customer.nome}! Segue o orçamento #${quote.numero} no valor de ${brl(Number(quote.total))}. Validade: ${quote.validade_dias} dias.`;

  // O PDF busca a empresa pelo `quote.company_id` (e não pela empresa ativa),
  // então a chamada é assíncrona: carrega os dados empresariais e o logotipo
  // antes de montar o documento. Falha no logo não impede a geração.
  const downloadPdf = () => {
    type PdfArgs = Parameters<typeof generateQuotePdf>;
    generateQuotePdf(quote as PdfArgs[0], quote.customer as PdfArgs[1], items as PdfArgs[2]).catch(
      (e) => {
        console.error("Falha ao gerar o PDF do orçamento", e);
        toast.error("Não foi possível gerar o PDF.");
      },
    );
  };

  /**
   * Abrir o WhatsApp é ação EXPLÍCITA do vendedor e faz uma coisa só: abre a
   * conversa com a mensagem do orçamento. Não gera, não baixa e não anexa PDF —
   * quem quer o documento usa o cartão "PDF", ao lado (Revisão 60; até ali os
   * dois eram botões no cabeçalho).
   *
   * A validação vem ANTES de qualquer efeito: telefone irrecuperável recusa com
   * mensagem e nada acontece. Antes, um telefone só com espaços passava no
   * `Boolean(...)` e o WhatsApp abria SEM destinatário, em silêncio.
   */
  const sendWhatsApp = () => {
    const validado = validarTelefoneBr(quote.customer?.telefone);
    if (!validado.ok) {
      toast.error(validado.erro);
      return;
    }
    openWhatsApp(validado.telefone, waMessage);
  };

  const reportCards: {
    // A Revisão 57 estreitou este tipo para `QuoteReportKind` porque, com o
    // cartão combinado fora, os 7 restantes eram todos relatório em PDF. A
    // Revisão 60 traz de volta "pdf" e "whatsapp" — mas agora são DOIS cartões
    // separados, um por ação, e não o combinado que a Rev. 57 removeu.
    // O campo é só rótulo interno: nada no componente lê `kind`.
    kind: QuoteReportKind | "pdf" | "whatsapp";
    label: string;
    desc: string;
    Icon: LucideIcon;
    action: () => void;
    tone: string;
  }[] = [
    // Os dois primeiros vieram do cabeçalho na Revisão 60, a pedido. Chamam
    // exatamente as mesmas funções que os botões chamavam — `sendWhatsApp`
    // continua validando o telefone ANTES de qualquer efeito (Revisões 57-59)
    // e o cartão de WhatsApp continua NÃO gerando PDF. Mudou o lugar na tela,
    // não a lógica.
    // A Revisão 78 renomeou o rótulo de "PDF" para "Orçamento": ao lado de
    // "Materiais", "Recibo" e "Contrato" — que dizem QUAL documento é —,
    // "PDF" era genérico, já que todos os outros também saem em PDF. O `kind`
    // continua "pdf" de propósito: é identificador interno, não texto de tela.
    {
      kind: "pdf",
      label: "Orçamento",
      // Revisao 114 — o `desc` passa a dizer o VERBO. "PDF completo" descrevia o
      // arquivo; quem procura o passo 1 da instrução acima precisa reconhecer
      // aqui a ação de BAIXAR.
      desc: "baixa o PDF completo",
      Icon: FileDown,
      action: downloadPdf,
      tone: "from-slate-500 to-zinc-600",
    },
    {
      kind: "whatsapp",
      label: "WhatsApp",
      // Revisao 114 — "enviar ao cliente" sugeria que o documento ia junto.
      // Agora o próprio cartão avisa o que o link do WhatsApp faz e não faz.
      desc: "abre só a mensagem",
      Icon: MessageCircle,
      action: sendWhatsApp,
      tone: "from-green-500 to-emerald-600",
    },
    {
      kind: "cliente",
      label: "Cliente",
      desc: "dados e contato",
      Icon: User,
      action: () => generateQuoteReportPdf("cliente", quote, items, profile),
      tone: "from-blue-500 to-cyan-500",
    },
    // Cartão "Vidros" removido da UI (decisão de escopo). `generateQuoteReportPdf("vidros")`
    // permanece em `quote-reports.ts` para outros consumidores / reativação futura.
    {
      kind: "instalador",
      label: "Instalador",
      desc: "roteiro, materiais e checklist",
      Icon: HardHat,
      action: () => generateQuoteReportPdf("instalador", quote, items, profile),
      tone: "from-yellow-500 to-stone-500",
    },
    {
      kind: "recibo",
      label: "Recibo",
      desc: "com assinatura",
      Icon: ReceiptText,
      action: () => generateQuoteReportPdf("recibo", quote, items, profile),
      tone: "from-emerald-500 to-teal-500",
    },
    {
      kind: "contrato",
      label: "Contrato",
      desc: "termo do serviço",
      Icon: FileSignature,
      action: () => generateQuoteReportPdf("contrato", quote, items, profile),
      tone: "from-purple-500 to-fuchsia-500",
    },
    {
      kind: "localizacao",
      label: "Localização",
      desc: "abrir rota",
      Icon: MapPin,
      action: openMap,
      tone: "from-red-500 to-rose-500",
    },
    // ⚠️ Os cartões de PDF e WhatsApp estão no INÍCIO desta lista, e são DOIS
    // separados de propósito. O que a Revisão 57 removeu foi um cartão único
    // "Enviar PDF" que fazia as duas coisas no mesmo clique: baixava o PDF antes
    // de checar o telefone e afirmava "O PDF foi gerado" antes de a geração
    // terminar. Não reintroduza um cartão combinado achando que é conveniência —
    // é exatamente o defeito que as Revisões 56-57 levantaram e fecharam.
  ];

  return (
    <div>
      <Link
        to="/app/orcamentos"
        className="mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> Voltar
      </Link>

      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="font-display text-3xl font-bold">Orçamento #{quote.numero}</h1>
            <span
              className={`rounded-full px-2.5 py-1 text-xs font-semibold ${statusTone[quote.status]}`}
            >
              {statusLabel[quote.status]}
            </span>
          </div>
          <p className="text-sm text-muted-foreground">Criado em {dateBR(quote.created_at)}</p>
        </div>
        {/* Era um `flex flex-col` porque havia uma segunda linha abaixo dos
            botões: a frase de instrução, removida a pedido na Revisão 60.
            Sem ela, a coluna passou a ter um filho só e voltou a ser a fileira
            de botões direta. */}
        <div className="flex flex-wrap gap-2">
          <select
            value={quote.status}
            disabled={!canEdit}
            onChange={(e) => setStatus(e.target.value as QuoteStatus)}
            className="rounded-lg border border-input bg-background px-3 py-2 text-sm disabled:opacity-50"
          >
            <option value="rascunho">Rascunho</option>
            <option value="enviado">Enviado</option>
            <option value="aprovado">Aprovado</option>
            <option value="recusado">Recusado</option>
          </select>
          {/* "PDF" e "WhatsApp" saíram daqui na Revisão 60 e viraram os dois
                primeiros cartões de Relatórios rápidos. Só o LUGAR mudou: as
                mesmas funções `downloadPdf` e `sendWhatsApp` são chamadas de lá,
                com a mesma validação de telefone das Revisões 57-59. */}
          {canEdit && (
            <Link
              to="/app/orcamentos/novo"
              search={searchOrcamentoNovo({ id: quote.id })}
              className="inline-flex items-center gap-2 rounded-lg border border-input bg-background px-4 py-2 text-sm hover:bg-accent"
            >
              <Edit3 className="h-4 w-4" /> Editar
            </Link>
          )}
          {canDelete && (
            <button
              onClick={() => {
                if (removeM.isPending) return; // impede clique duplo
                if (
                  confirm(
                    `Excluir o orçamento #${quote.numero} de ${quote.customer?.nome ?? "cliente"}? Os itens serão removidos.`,
                  )
                )
                  remove();
              }}
              disabled={removeM.isPending}
              className="rounded-lg border border-destructive/30 px-3 py-2 text-destructive hover:bg-destructive/10 disabled:opacity-50"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      <div className="mb-6 rounded-2xl border bg-card p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Status de produção
            </h2>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Acompanhe a obra do orçamento até a entrega.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={quote.etapa ?? "orcamento"}
              disabled={!canEdit}
              onChange={(e) => setStage(e.target.value as Stage)}
              className="rounded-lg border border-input bg-background px-3 py-2 text-sm disabled:opacity-50"
            >
              <option value="orcamento">Orçamento</option>
              <option value="producao">Produção</option>
              <option value="instalacao">Instalação</option>
              <option value="pago">Pago</option>
            </select>
            <label className="inline-flex items-center gap-2 rounded-lg border border-input bg-background px-3 py-2 text-sm">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <input
                type="date"
                value={quote.instalacao_em ?? ""}
                disabled={!canEdit}
                onChange={(e) => setInstalacaoEm(e.target.value || null)}
                className="bg-transparent outline-none disabled:opacity-50"
              />
            </label>
          </div>
        </div>
        <PipelineStatus current={(quote.etapa ?? "orcamento") as Stage} />
      </div>

      <div className="mb-6 rounded-2xl border bg-card p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Relatórios rápidos
            </h2>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Botões em formato visual para gerar documentos, enviar ao cliente e acessar
              localização.
            </p>
          </div>
        </div>
        {/* A orientação volta ao detalhe (Revisao 114), e é preciso dizer que
            isto NÃO desfaz a Revisao 60.
            Lá a frase saiu do CABEÇALHO, a pedido, junto com os botões "PDF" e
            "WhatsApp" que moraram ali — e a Revisao 61 registrou que a listagem
            ficou orientando e o detalhe não, "aguardando decisão". A decisão
            veio: orientar nos dois. E agora a orientação fica ONDE ESTÃO OS
            BOTÕES, logo acima dos cartões que ela manda clicar, em vez de solta
            num cabeçalho que não tem mais ação nenhuma. */}
        <InstrucaoWhatsAppPdf contexto="detalhe" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {reportCards.map((card) => (
            <button
              key={card.label}
              onClick={card.action}
              className="group relative overflow-hidden rounded-2xl border p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-elegant"
            >
              <div className={`absolute inset-0 bg-gradient-to-br opacity-15 ${card.tone}`} />
              <div
                className={`relative mb-3 grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br text-white shadow ${card.tone}`}
              >
                <card.Icon className="h-5 w-5" />
              </div>
              <div className="relative font-display text-sm font-bold">{card.label}</div>
              <div className="relative mt-0.5 text-xs text-muted-foreground">{card.desc}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <div className="rounded-2xl border bg-card p-5">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="font-display text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                  Notas do orçamento
                </h2>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  Insira notas de texto ou uma imagem/foto do cliente, medição, comprovante, croqui
                  ou detalhe da obra.
                </p>
              </div>
              <button
                onClick={saveNote}
                className="inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground"
              >
                <StickyNote className="h-4 w-4" /> Salvar notas
              </button>
            </div>
            <textarea
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              rows={4}
              className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm"
              placeholder="Ex.: cliente pediu recorte adicional, trocar puxador, conferir nível do piso..."
            />
            <div className="mt-3 flex flex-wrap items-center gap-3">
              <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-input px-3 py-2 text-sm hover:bg-accent">
                <ImagePlus className="h-4 w-4" /> Inserir nota em imagem
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = () => setNoteImage(String(reader.result));
                    reader.readAsDataURL(file);
                  }}
                />
              </label>
              {noteImage && (
                <button
                  onClick={() => {
                    setNoteImage(null);
                    localStorage.removeItem(`${notesKey}_image`);
                  }}
                  className="rounded-lg border border-destructive/30 px-3 py-2 text-sm text-destructive hover:bg-destructive/10"
                >
                  Remover imagem
                </button>
              )}
            </div>
            {noteImage && (
              <img
                src={noteImage}
                alt="Nota visual do orçamento"
                className="mt-3 max-h-72 rounded-xl border object-contain"
              />
            )}
          </div>

          <div className="rounded-2xl border bg-card p-5">
            <div className="mb-3">
              <h2 className="font-display text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                Cliente
              </h2>
            </div>
            <Link
              to="/app/clientes/$id"
              params={{ id: quote.customer.id }}
              className="font-display text-xl font-bold hover:underline"
            >
              {quote.customer.nome}
            </Link>
            <div className="mt-1 text-sm text-muted-foreground">
              {[quote.customer.documento, quote.customer.telefone, quote.customer.email]
                .filter(Boolean)
                .join(" · ")}
            </div>
            <div className="mt-2 text-sm text-muted-foreground">
              {[quote.customer.endereco, quote.customer.cidade].filter(Boolean).join(" - ")}
            </div>
          </div>

          <div className="overflow-hidden rounded-2xl border bg-card">
            <table className="w-full text-sm">
              <thead className="border-b bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 text-left">Descrição</th>
                  <th className="px-4 py-3 text-right">L × A</th>
                  <th className="px-4 py-3 text-right">Qtd</th>
                  <th className="px-4 py-3 text-right">m²</th>
                  <th className="px-4 py-3 text-right">R$/m²</th>
                  <th className="px-4 py-3 text-right">Subtotal</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {items.map((i) => (
                  <tr key={i.id}>
                    <td className="px-4 py-3 font-medium">{i.descricao}</td>
                    <td className="px-4 py-3 text-right text-muted-foreground">
                      {num(i.largura, 2)} × {num(i.altura, 2)}
                    </td>
                    <td className="px-4 py-3 text-right">{i.quantidade}</td>
                    <td className="px-4 py-3 text-right">{num(i.m2, 3)}</td>
                    <td className="px-4 py-3 text-right">{brl(Number(i.preco_unit))}</td>
                    <td className="px-4 py-3 text-right font-semibold">
                      {brl(Number(i.subtotal))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {quote.observacoes && (
            <div className="rounded-2xl border bg-card p-5">
              <h2 className="mb-2 font-display text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                Observações
              </h2>
              <p className="whitespace-pre-wrap text-sm">{quote.observacoes}</p>
            </div>
          )}

          {itensComFoto.length > 0 && (
            <div className="rounded-2xl border bg-card p-5">
              <div className="mb-3">
                <h2 className="font-display text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                  Imagens dos itens
                </h2>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  Imagens de referência dos itens deste orçamento.
                </p>
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                {itensComFoto.map((i) => {
                  const temDimensao = Number(i.largura) > 0 && Number(i.altura) > 0;
                  return (
                    <div key={i.id} className="rounded-xl border border-border bg-background p-3">
                      <div className="mb-2 min-w-0">
                        <div className="truncate text-sm font-semibold">{i.descricao}</div>
                        {temDimensao && (
                          <div className="text-xs text-muted-foreground">
                            {num(i.largura, 2)} × {num(i.altura, 2)} m
                          </div>
                        )}
                      </div>
                      <BlocoFotoItem item={i} />
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div className="lg:sticky lg:top-6 lg:self-start">
          <div className="rounded-2xl border border-border bg-card p-6 text-foreground shadow-elegant">
            <h2 className="font-display text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Total
            </h2>
            <div className="mt-2 font-display text-5xl font-bold text-gold">
              {brl(Number(quote.total))}
            </div>
            <div className="mt-6 space-y-2 border-t border-border pt-4 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Desconto</span>
                <span>{brl(Number(quote.desconto))}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Acréscimo</span>
                <span>{brl(Number(quote.acrescimo))}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Validade</span>
                <span>{quote.validade_dias} dias</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
