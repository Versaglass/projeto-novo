/**
 * Painel de revisão / aprovação / publicação — Fase 3.
 */

import { useEffect, useMemo, useState } from "react";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import type {
  CatalogImportItemView,
  CatalogImportJobView,
} from "@/lib/catalog-import/import.functions";
import {
  INVENTORY_CATEGORIES,
  INVENTORY_UNITS,
  approveReadyCatalogImportItems,
  listProductManufacturersForImport,
  publishCatalogImport,
  resolveCatalogImportManufacturer,
  setCatalogImportItemDecision,
  updateCatalogImportItem,
} from "@/lib/catalog-import/review.functions";
import { getCatalogImportStagingSignedUrl } from "@/lib/catalog-import/import.functions";
import {
  canApproveItem,
  canEnablePublish,
  canRejectItem,
  isManufacturerResolved,
} from "@/lib/catalog-import/review";
import type { ValidationStatus } from "@/lib/catalog-import/status";

function statusLabel(s: string) {
  switch (s) {
    case "valid":
      return {
        text: "Pronto",
        className: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300",
      };
    case "review":
      return { text: "Revisar", className: "bg-amber-500/15 text-amber-700 dark:text-amber-300" };
    case "duplicate":
      return {
        text: "Já cadastrado",
        className: "bg-sky-500/15 text-sky-700 dark:text-sky-300",
      };
    case "invalid":
      return { text: "Inválido", className: "bg-rose-500/15 text-rose-700 dark:text-rose-300" };
    default:
      return { text: s, className: "bg-muted text-muted-foreground" };
  }
}

function decisionLabel(d: string) {
  switch (d) {
    case "approved":
      return "Aprovado";
    case "rejected":
      return "Rejeitado";
    default:
      return "Pendente";
  }
}

function StagingThumb({ jobId, path }: { jobId: string; path: string | null }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let cancelled = false;
    if (!path) {
      setUrl(null);
      return;
    }
    void getCatalogImportStagingSignedUrl({ data: { jobId, path } })
      .then((r) => {
        if (!cancelled) setUrl(r.url);
      })
      .catch(() => {
        if (!cancelled) setUrl(null);
      });
    return () => {
      cancelled = true;
    };
  }, [jobId, path]);

  if (!url) return <div className="h-14 w-14 rounded-md bg-muted" />;
  return (
    <img
      src={url}
      alt=""
      className="h-14 w-14 rounded-md object-cover"
      loading="lazy"
      referrerPolicy="no-referrer"
    />
  );
}

const CATEGORY_LABELS: Record<string, string> = {
  aluminio: "Alumínio",
  vidro: "Vidro",
  ferragem: "Ferragem",
  acessorio: "Acessório",
  perfil: "Perfil",
  led: "LED",
  cola: "Cola",
  outros: "Outros",
  aco_metalon: "Aço / Metalon",
  chapa_aco: "Chapa de aço",
  solda: "Solda",
  mdf: "MDF",
  ferragem_moveis: "Ferragem móveis",
  fita_borda: "Fita de borda",
  marmore: "Mármore",
  quartzo: "Quartzo",
  porcelanato: "Porcelanato",
};

type Props = {
  job: CatalogImportJobView;
  items: CatalogImportItemView[];
  onRefresh: () => Promise<void>;
};

export function CatalogImportReviewPanel({ job, items, onRefresh }: Props) {
  const [busy, setBusy] = useState(false);
  const [editItem, setEditItem] = useState<CatalogImportItemView | null>(null);
  const [confirmPublish, setConfirmPublish] = useState(false);
  const [mfgOpen, setMfgOpen] = useState(false);
  const [manufacturers, setManufacturers] = useState<
    { id: string; name: string; normalized_name: string; active: boolean }[]
  >([]);
  const [newMfgName, setNewMfgName] = useState("");

  const completed = job.status === "completed";

  const manufacturerResolved = isManufacturerResolved(
    job.resolved_manufacturer_id,
    job.resolved_manufacturer_name,
    job.existing_manufacturer_id,
    job.manufacturer_name,
  );

  const displayMfg = job.resolved_manufacturer_name || job.manufacturer_name || "—";

  const mfgMode = job.resolved_manufacturer_id
    ? "existing"
    : job.existing_manufacturer_id && !job.resolved_manufacturer_name
      ? "existing"
      : job.resolved_manufacturer_name
        ? "new"
        : job.existing_manufacturer_id
          ? "existing"
          : "new";

  const gateItems = useMemo(
    () =>
      items.map((it) => ({
        validationStatus: it.validation_status as ValidationStatus,
        reviewDecision: (it.review_decision || "pending") as "pending" | "approved" | "rejected",
      })),
    [items],
  );

  const approvedCount = gateItems.filter((i) => i.reviewDecision === "approved").length;
  const rejectedCount = gateItems.filter((i) => i.reviewDecision === "rejected").length;
  const canPublish =
    !completed &&
    canEnablePublish({
      jobStatus: job.status,
      manufacturerResolved,
      items: gateItems,
    });

  const run = async (fn: () => Promise<void>, okMsg?: string) => {
    setBusy(true);
    try {
      await fn();
      await onRefresh();
      if (okMsg) toast.success(okMsg);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Operação falhou.");
    } finally {
      setBusy(false);
    }
  };

  const openMfg = async () => {
    setMfgOpen(true);
    try {
      const list = await listProductManufacturersForImport();
      setManufacturers(list);
    } catch {
      toast.error("Não foi possível carregar fabricantes.");
    }
  };

  if (completed) {
    return (
      <section className="space-y-4 rounded-2xl border border-border bg-card p-5 shadow-sm">
        <h2 className="font-display text-lg font-semibold">Catálogo publicado</h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 text-sm">
          <div>
            <p className="text-muted-foreground">Fabricante</p>
            <p className="font-medium">{displayMfg}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Produtos publicados</p>
            <p className="font-medium">{job.published_items}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Rejeitados</p>
            <p className="font-medium">{job.rejected_items}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Já cadastrados</p>
            <p className="font-medium">{job.duplicate_items + (job.duplicates_at_publish || 0)}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Inválidos</p>
            <p className="font-medium">{job.invalid_items}</p>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">
          Esta importação foi concluída e não pode ser publicada novamente.
        </p>
      </section>
    );
  }

  return (
    <section className="space-y-5 rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="font-display text-lg font-semibold">Revisão dos itens</h2>
          <p className="text-sm text-muted-foreground">
            {job.catalog_name ?? "Catálogo"} · status {job.status}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            disabled={busy}
            onClick={() =>
              void run(async () => {
                const r = await approveReadyCatalogImportItems({ data: { jobId: job.id } });
                toast.success(`${r.approvedCount} item(ns) prontos aprovados.`);
              })
            }
            className="rounded-xl border border-border px-3 py-2 text-sm font-medium hover:bg-muted disabled:opacity-60"
          >
            Aprovar todos os prontos
          </button>
          <button
            type="button"
            disabled={busy || !canPublish}
            onClick={() => setConfirmPublish(true)}
            className="rounded-xl bg-gradient-gold px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60"
          >
            Publicar catálogo
          </button>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 text-sm">
        <div>
          <p className="text-muted-foreground">Prontos</p>
          <p className="font-medium">{job.valid_items}</p>
        </div>
        <div>
          <p className="text-muted-foreground">Revisão necessária</p>
          <p className="font-medium">{job.review_items}</p>
        </div>
        <div>
          <p className="text-muted-foreground">Já cadastrados</p>
          <p className="font-medium">{job.duplicate_items}</p>
        </div>
        <div>
          <p className="text-muted-foreground">Inválidos</p>
          <p className="font-medium">{job.invalid_items}</p>
        </div>
      </div>

      {/* Fabricante */}
      <div className="rounded-xl border border-border/80 bg-muted/30 p-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Fabricante</p>
            <p className="font-display text-base font-semibold">{displayMfg}</p>
            <p className="mt-1 text-sm text-muted-foreground">
              {mfgMode === "existing" ||
              job.existing_manufacturer_id ||
              job.resolved_manufacturer_id
                ? "Fabricante já cadastrado / será reutilizado"
                : "Novo fabricante será criado"}
            </p>
            {job.manufacturer_name &&
            job.resolved_manufacturer_name &&
            job.manufacturer_name !== job.resolved_manufacturer_name ? (
              <p className="mt-1 text-xs text-muted-foreground">
                Original no catálogo: {job.manufacturer_name}
              </p>
            ) : null}
          </div>
          <button
            type="button"
            disabled={busy}
            onClick={() => void openMfg()}
            className="rounded-lg border border-border px-3 py-1.5 text-sm hover:bg-background"
          >
            Alterar fabricante
          </button>
        </div>
      </div>

      {job.warnings.length > 0 ? (
        <ul className="list-disc pl-5 text-sm text-amber-700 dark:text-amber-300">
          {job.warnings.map((w) => (
            <li key={w}>{w}</li>
          ))}
        </ul>
      ) : null}

      <div className="space-y-3">
        {items.map((it) => {
          const st = statusLabel(it.validation_status);
          const vs = it.validation_status as ValidationStatus;
          return (
            <article key={it.id} className="rounded-xl border border-border/70 p-3 sm:p-4">
              <div className="flex gap-3">
                <StagingThumb jobId={job.id} path={it.primary_image_staging_path} />
                <div className="min-w-0 flex-1 space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-xs">{it.source_code}</span>
                    <span className={`rounded-md px-2 py-0.5 text-xs font-medium ${st.className}`}>
                      {st.text}
                    </span>
                    <span className="rounded-md bg-muted px-2 py-0.5 text-xs">
                      {decisionLabel(it.review_decision)}
                    </span>
                  </div>
                  <p className="font-medium">{it.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {it.product_line ?? "—"} · sugestão: {it.suggested_category ?? "—"} · cat.:{" "}
                    {it.inventory_category
                      ? (CATEGORY_LABELS[it.inventory_category] ?? it.inventory_category)
                      : "—"}{" "}
                    · un: {it.unit ?? "—"} · pág. {it.source_page ?? "—"}
                  </p>
                  {it.validation_errors.length > 0 ? (
                    <ul className="list-disc pl-4 text-xs text-rose-600 dark:text-rose-300">
                      {it.validation_errors.map((e) => (
                        <li key={e}>{e}</li>
                      ))}
                    </ul>
                  ) : null}
                  {it.validation_warnings.length > 0 ? (
                    <div className="text-xs text-amber-700 dark:text-amber-300">
                      <p className="font-medium">Avisos do VersaGlass</p>
                      <ul className="list-disc pl-4">
                        {it.validation_warnings.map((e) => (
                          <li key={e}>{e}</li>
                        ))}
                      </ul>
                    </div>
                  ) : null}
                  {it.ai_warnings.length > 0 ? (
                    <div className="text-xs text-amber-700/90 dark:text-amber-200/90">
                      <p className="font-medium">Avisos da IA</p>
                      <ul className="list-disc pl-4">
                        {it.ai_warnings.map((e) => (
                          <li key={e}>{e}</li>
                        ))}
                      </ul>
                    </div>
                  ) : null}
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                {canApproveItem(vs) ? (
                  <button
                    type="button"
                    disabled={busy || it.review_decision === "approved"}
                    onClick={() =>
                      void run(async () => {
                        await setCatalogImportItemDecision({
                          data: { jobId: job.id, itemId: it.id, decision: "approved" },
                        });
                      }, "Item aprovado.")
                    }
                    className="rounded-lg bg-emerald-600/90 px-2.5 py-1.5 text-xs font-medium text-white disabled:opacity-50"
                  >
                    {vs === "review" ? "Revisar e aprovar" : "Aprovar"}
                  </button>
                ) : null}
                {canApproveItem(vs) ? (
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => setEditItem(it)}
                    className="rounded-lg border border-border px-2.5 py-1.5 text-xs font-medium hover:bg-muted"
                  >
                    Editar
                  </button>
                ) : null}
                {canRejectItem(vs) ? (
                  <button
                    type="button"
                    disabled={busy || it.review_decision === "rejected"}
                    onClick={() =>
                      void run(async () => {
                        await setCatalogImportItemDecision({
                          data: { jobId: job.id, itemId: it.id, decision: "rejected" },
                        });
                      }, "Item rejeitado.")
                    }
                    className="rounded-lg border border-rose-300/60 px-2.5 py-1.5 text-xs font-medium text-rose-700 dark:text-rose-300"
                  >
                    Rejeitar
                  </button>
                ) : null}
                {vs === "duplicate" ? (
                  <span className="text-xs text-sky-700 dark:text-sky-300">
                    Já cadastrado — não publicável
                  </span>
                ) : null}
                {vs === "invalid" ? (
                  <span className="text-xs text-rose-600">Inválido — apenas rejeição</span>
                ) : null}
              </div>
            </article>
          );
        })}
      </div>

      {/* Edit dialog */}
      {editItem ? (
        <EditItemDialog
          item={editItem}
          busy={busy}
          onClose={() => setEditItem(null)}
          onSave={(payload) =>
            void run(async () => {
              await updateCatalogImportItem({
                data: { jobId: job.id, itemId: editItem.id, ...payload },
              });
              setEditItem(null);
            }, "Item atualizado.")
          }
        />
      ) : null}

      {/* Manufacturer dialog */}
      {mfgOpen ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="max-h-[80vh] w-full max-w-lg overflow-auto rounded-2xl border border-border bg-card p-5 shadow-lg">
            <h3 className="font-display text-lg font-semibold">Alterar fabricante</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Original: {job.manufacturer_name ?? "—"}
            </p>
            <div className="mt-4 space-y-2">
              <p className="text-sm font-medium">Selecionar existente</p>
              <ul className="max-h-48 space-y-1 overflow-auto text-sm">
                {manufacturers.map((m) => (
                  <li key={m.id}>
                    <button
                      type="button"
                      disabled={busy}
                      className="w-full rounded-lg px-2 py-1.5 text-left hover:bg-muted"
                      onClick={() =>
                        void run(async () => {
                          await resolveCatalogImportManufacturer({
                            data: {
                              jobId: job.id,
                              mode: "existing",
                              manufacturerId: m.id,
                            },
                          });
                          setMfgOpen(false);
                        }, "Fabricante atualizado.")
                      }
                    >
                      {m.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            <div className="mt-4 space-y-2">
              <p className="text-sm font-medium">Ou criar novo com nome corrigido</p>
              <input
                value={newMfgName}
                onChange={(e) => setNewMfgName(e.target.value)}
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm"
                placeholder="Nome do fabricante"
              />
              <button
                type="button"
                disabled={busy || !newMfgName.trim()}
                className="rounded-lg bg-gradient-gold px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60"
                onClick={() =>
                  void run(async () => {
                    await resolveCatalogImportManufacturer({
                      data: {
                        jobId: job.id,
                        mode: "new",
                        manufacturerName: newMfgName.trim(),
                      },
                    });
                    setMfgOpen(false);
                    setNewMfgName("");
                  }, "Fabricante definido.")
                }
              >
                Usar este nome
              </button>
            </div>
            <button
              type="button"
              className="mt-4 text-sm text-muted-foreground underline"
              onClick={() => setMfgOpen(false)}
            >
              Cancelar
            </button>
          </div>
        </div>
      ) : null}

      {/* Publish confirm */}
      {confirmPublish ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-lg">
            <h3 className="font-display text-lg font-semibold">Publicar catálogo</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Você está prestes a publicar {approvedCount} produtos no catálogo global do
              VersaGlass.
            </p>
            <ul className="mt-3 space-y-1 text-sm">
              <li>Fabricante: {displayMfg}</li>
              <li>Produtos aprovados: {approvedCount}</li>
              <li>Rejeitados: {rejectedCount}</li>
              <li>Duplicados: {job.duplicate_items}</li>
              <li>Inválidos: {job.invalid_items}</li>
            </ul>
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                className="rounded-lg border border-border px-3 py-2 text-sm"
                onClick={() => setConfirmPublish(false)}
              >
                Cancelar
              </button>
              <button
                type="button"
                disabled={busy}
                className="inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60"
                onClick={() =>
                  void run(async () => {
                    setConfirmPublish(false);
                    await publishCatalogImport({ data: { jobId: job.id } });
                  }, "Catálogo publicado.")
                }
              >
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                Publicar {approvedCount} produtos
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </section>
  );
}

function EditItemDialog({
  item,
  busy,
  onClose,
  onSave,
}: {
  item: CatalogImportItemView;
  busy: boolean;
  onClose: () => void;
  onSave: (p: {
    source_code: string;
    base_code: string | null;
    name: string;
    description: string | null;
    product_line: string | null;
    inventory_category: (typeof INVENTORY_CATEGORIES)[number] | null;
    unit: (typeof INVENTORY_UNITS)[number] | null;
  }) => void;
}) {
  const [source_code, setSourceCode] = useState(item.source_code ?? "");
  const [base_code, setBaseCode] = useState(item.base_code ?? "");
  const [name, setName] = useState(item.name ?? "");
  const [description, setDescription] = useState(item.description ?? "");
  const [product_line, setProductLine] = useState(item.product_line ?? "");
  const [inventory_category, setInventoryCategory] = useState(item.inventory_category ?? "");
  const [unit, setUnit] = useState(item.unit ?? "");

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="max-h-[90vh] w-full max-w-lg overflow-auto rounded-2xl border border-border bg-card p-5 shadow-lg">
        <h3 className="font-display text-lg font-semibold">Editar item</h3>
        <p className="mt-1 text-xs text-muted-foreground">
          Sugestão da IA: {item.suggested_category ?? "—"}
        </p>
        <div className="mt-4 grid gap-3 text-sm">
          <label className="grid gap-1">
            <span>Código do fabricante</span>
            <input
              className="rounded-lg border border-border bg-background px-3 py-2"
              value={source_code}
              onChange={(e) => setSourceCode(e.target.value)}
            />
          </label>
          <label className="grid gap-1">
            <span>Nome</span>
            <input
              className="rounded-lg border border-border bg-background px-3 py-2"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </label>
          <label className="grid gap-1">
            <span>Descrição</span>
            <textarea
              className="rounded-lg border border-border bg-background px-3 py-2"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </label>
          <label className="grid gap-1">
            <span>Código base</span>
            <input
              className="rounded-lg border border-border bg-background px-3 py-2"
              value={base_code}
              onChange={(e) => setBaseCode(e.target.value)}
            />
          </label>
          <label className="grid gap-1">
            <span>Linha</span>
            <input
              className="rounded-lg border border-border bg-background px-3 py-2"
              value={product_line}
              onChange={(e) => setProductLine(e.target.value)}
            />
          </label>
          <label className="grid gap-1">
            <span>Categoria VersaGlass</span>
            <select
              className="rounded-lg border border-border bg-background px-3 py-2"
              value={inventory_category}
              onChange={(e) => setInventoryCategory(e.target.value)}
            >
              <option value="">(não definir)</option>
              {INVENTORY_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {CATEGORY_LABELS[c] ?? c}
                </option>
              ))}
            </select>
          </label>
          <label className="grid gap-1">
            <span>Unidade</span>
            <select
              className="rounded-lg border border-border bg-background px-3 py-2"
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
            >
              <option value="">(não definir)</option>
              {INVENTORY_UNITS.map((u) => (
                <option key={u} value={u}>
                  {u}
                </option>
              ))}
            </select>
          </label>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <button type="button" className="rounded-lg border px-3 py-2 text-sm" onClick={onClose}>
            Cancelar
          </button>
          <button
            type="button"
            disabled={busy || !source_code.trim() || !name.trim()}
            className="rounded-lg bg-gradient-gold px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60"
            onClick={() =>
              onSave({
                source_code: source_code.trim(),
                name: name.trim(),
                description: description.trim() || null,
                base_code: base_code.trim() || null,
                product_line: product_line.trim() || null,
                inventory_category: (inventory_category || null) as
                  | (typeof INVENTORY_CATEGORIES)[number]
                  | null,
                unit: (unit || null) as (typeof INVENTORY_UNITS)[number] | null,
              })
            }
          >
            Salvar
          </button>
        </div>
      </div>
    </div>
  );
}
