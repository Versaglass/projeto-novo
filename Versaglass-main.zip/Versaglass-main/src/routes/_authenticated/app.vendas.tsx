import { createFileRoute, Link, Outlet, useLocation, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { brl, dateBR } from "@/lib/format";
import {
  Receipt,
  Eye,
  FileDown,
  AlertTriangle,
  Building2,
  Plus,
  Loader2,
  Ban,
  Search,
  Calendar,
  Printer,
} from "lucide-react";
import { toast } from "sonner";
import {
  useSales,
  fetchSaleDocument,
  pagamentoLabel,
  compradorLabel,
  saleErrorMessage,
  SALE_STATUS_META,
  SALE_PAYMENT_METHODS,
  canCancelSale,
  type SaleListRow,
  type SalePaymentMethod,
  type SaleStatus,
} from "@/hooks/use-sales";
import { generateSalePdf } from "@/lib/sale-pdf";
import { CancelSaleDialog } from "@/components/CancelSaleDialog";
import { useCompany } from "@/contexts/company-context";

/**
 * HISTÓRICO DE VENDAS — `/app/vendas`.
 *
 * A Revisão 87 deixou a Venda direta gravando de verdade, e deixou uma lacuna
 * declarada: a venda existia no banco e virava PDF na hora, mas **não havia
 * onde consultá-la depois**. Quem fechasse a aba só reencontrava a venda pelo
 * arquivo baixado. Esta tela fecha isso.
 *
 * Segue o padrão de `app.orcamentos.tsx`, inclusive nos estados que ninguém
 * lembra de fazer: sem empresa ativa, carregando, erro com "Tentar novamente" e
 * lista vazia — cada um com o seu cartão, em vez de tela branca.
 *
 * 🔒 O isolamento entre empresas é da RLS (`sales_select_company`), não desta
 * tela. O filtro por empresa ativa no hook é escopo de interface.
 *
 * ⚠️ NÃO HÁ Editar nem Excluir. Cancelamento com estorno automático existe
 * desde a Revisão 137 (RPC `cancel_sale`), restrito a owner/admin e vendas
 * finalizadas — o botão e o chip de status refletem isso na interface.
 */
export const Route = createFileRoute("/_authenticated/app/vendas")({
  component: VendasPage,
});

type StatusFilter = "todos" | SaleStatus;
type PaymentFilter = "todos" | SalePaymentMethod;
type PeriodoSelect = "todos" | "mes" | "30d" | "personalizado";

type DataFiltro =
  | { mode: "todos" }
  | { mode: "preset"; preset: "mes" | "30d" }
  | { mode: "manual"; de: string; ate: string };

const STATUS_OPCOES: { key: StatusFilter; label: string }[] = [
  { key: "todos", label: "Todas" },
  { key: "finalizada", label: "Finalizada" },
  { key: "cancelada", label: "Cancelada" },
];

const PAGAMENTO_OPCOES: { key: PaymentFilter; label: string }[] = [
  { key: "todos", label: "Todas" },
  ...SALE_PAYMENT_METHODS.map((p) => ({ key: p.value, label: p.label })),
];

const PERIODO_OPCOES: { key: PeriodoSelect; label: string }[] = [
  { key: "todos", label: "Todas" },
  { key: "mes", label: "Este mês" },
  { key: "30d", label: "Últimos 30 dias" },
  { key: "personalizado", label: "Personalizado" },
];

const selectClass =
  "w-full min-w-0 rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring/30";

/** Converte ISO do banco para meia-noite local — comparação por dia civil. */
function diaLocal(iso: string) {
  const d = new Date(iso);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

/** `YYYY-MM-DD` do `<input type="date">` → Date local. */
function parseInputDate(s: string) {
  if (!s.trim()) return null;
  const [y, m, d] = s.split("-").map(Number);
  if (!y || !m || !d) return null;
  return new Date(y, m - 1, d);
}

function resolveDataFiltro(periodo: PeriodoSelect, de: string, ate: string): DataFiltro {
  if (periodo === "personalizado") return { mode: "manual", de, ate };
  if (periodo === "todos") return { mode: "todos" };
  return { mode: "preset", preset: periodo };
}

function opcaoComContagem(label: string, count: number) {
  return `${label} (${count})`;
}

function matchData(v: SaleListRow, filtro: DataFiltro, ref = new Date()) {
  if (filtro.mode === "todos") return true;
  const venda = diaLocal(v.created_at);
  if (filtro.mode === "preset") {
    if (filtro.preset === "mes") {
      return venda.getMonth() === ref.getMonth() && venda.getFullYear() === ref.getFullYear();
    }
    const cutoff = new Date(ref.getFullYear(), ref.getMonth(), ref.getDate() - 30);
    return venda >= cutoff;
  }
  const de = parseInputDate(filtro.de);
  if (!de) return true;
  const ate = parseInputDate(filtro.ate) ?? de;
  const fim = ate >= de ? ate : de;
  const inicio = ate >= de ? de : ate;
  return venda >= inicio && venda <= fim;
}

/** Mesmo `foldBusca` da listagem de Orçamentos (Rev. 166): tolerante a acento. */
function foldBusca(s: string) {
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function matchCliente(v: SaleListRow, term: string) {
  const t = term.trim();
  if (!t) return true;
  const nome = v.customer?.nome ?? v.cliente_nome ?? "";
  return foldBusca(nome).includes(foldBusca(t));
}

function matchStatus(v: SaleListRow, f: StatusFilter) {
  if (f === "todos") return true;
  return v.status === f;
}

function matchPagamento(v: SaleListRow, f: PaymentFilter) {
  if (f === "todos") return true;
  return v.forma_pagamento === f;
}

function VendasPage() {
  const location = useLocation();

  // `/app/vendas/$id` é rota-filha desta: quando o caminho não é exatamente a
  // listagem, quem manda na tela é o detalhe. Mesmo arranjo de Orçamentos.
  if (location.pathname !== "/app/vendas") {
    return <Outlet />;
  }

  return <ListaVendas />;
}

function ListaVendas() {
  const navigate = useNavigate();
  const { isCompanyAdmin } = useCompany();
  const {
    data: vendas = [],
    isLoading,
    isError,
    refetch,
    hasActiveCompany,
    companyId,
  } = useSales();
  const [gerando, setGerando] = useState<string | null>(null);
  const [cancelar, setCancelar] = useState<{ id: string; numero: number } | null>(null);
  const [statusFiltro, setStatusFiltro] = useState<StatusFilter>("todos");
  const [pagamentoFiltro, setPagamentoFiltro] = useState<PaymentFilter>("todos");
  const [periodoSelect, setPeriodoSelect] = useState<PeriodoSelect>("todos");
  const [dataDe, setDataDe] = useState("");
  const [dataAte, setDataAte] = useState("");
  const [buscaCliente, setBuscaCliente] = useState("");

  const dataFiltro = useMemo(
    () => resolveDataFiltro(periodoSelect, dataDe, dataAte),
    [periodoSelect, dataDe, dataAte],
  );

  // Consulta traz a lista inteira da empresa — filtros locais, como Orçamentos (Rev. 166).
  const vendasNoPeriodo = useMemo(
    () => vendas.filter((v) => matchData(v, dataFiltro)),
    [vendas, dataFiltro],
  );

  const vendasNaBusca = useMemo(
    () => vendasNoPeriodo.filter((v) => matchCliente(v, buscaCliente)),
    [vendasNoPeriodo, buscaCliente],
  );

  const statusCounts = useMemo(() => {
    const base = vendasNaBusca.filter((v) => matchPagamento(v, pagamentoFiltro));
    const c: Record<StatusFilter, number> = { todos: base.length, finalizada: 0, cancelada: 0 };
    for (const v of base) {
      if (v.status === "finalizada") c.finalizada++;
      else if (v.status === "cancelada") c.cancelada++;
    }
    return c;
  }, [vendasNaBusca, pagamentoFiltro]);

  const pagamentoCounts = useMemo(() => {
    const base = vendasNaBusca.filter((v) => matchStatus(v, statusFiltro));
    const c = Object.fromEntries(PAGAMENTO_OPCOES.map((f) => [f.key, 0])) as Record<
      PaymentFilter,
      number
    >;
    c.todos = base.length;
    for (const v of base) c[v.forma_pagamento]++;
    return c;
  }, [vendasNaBusca, statusFiltro]);

  const filtered = useMemo(
    () =>
      vendasNaBusca.filter(
        (v) => matchStatus(v, statusFiltro) && matchPagamento(v, pagamentoFiltro),
      ),
    [vendasNaBusca, statusFiltro, pagamentoFiltro],
  );

  const buscaAtiva = buscaCliente.trim().length > 0;
  const filtrosAtivos =
    buscaAtiva ||
    statusFiltro !== "todos" ||
    pagamentoFiltro !== "todos" ||
    periodoSelect !== "todos";

  const handlePeriodoChange = (value: PeriodoSelect) => {
    setPeriodoSelect(value);
    if (value !== "personalizado") {
      setDataDe("");
      setDataAte("");
    }
  };

  /**
   * "Gerar PDF novamente" — relê do banco e chama a MESMA função da Revisão 87.
   *
   * Nada aqui remonta a nota: `fetchSaleDocument` + `generateSalePdf` são
   * exatamente as duas chamadas que a tela de venda faz ao finalizar. Se a nota
   * mudar um dia, muda nos dois lugares de uma vez — e o documento reimpresso
   * meses depois continua saindo com o que o banco guardou, não com o que a
   * listagem exibia.
   */
  const gerarPdf = async (id: string, numero: number) => {
    setGerando(id);
    try {
      const documento = await fetchSaleDocument(id, companyId);
      await generateSalePdf(documento);
      toast.success(`Nota da venda nº ${numero} gerada.`);
    } catch (e) {
      console.error("[vendas] falha ao gerar o PDF da venda", e);
      toast.error(saleErrorMessage(e));
    } finally {
      setGerando(null);
    }
  };

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Vendas</h1>
          <p className="text-sm text-muted-foreground">
            Histórico das vendas de balcão registradas por esta empresa.
          </p>
        </div>
        <Link
          to="/app/venda-direta"
          className="inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground shadow-glow"
        >
          <Plus className="h-4 w-4" /> Nova venda
        </Link>
      </div>

      <div className="mb-4 flex items-start gap-3 rounded-2xl border border-muted bg-muted/30 p-4">
        <Receipt className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
        <p className="text-sm text-muted-foreground">
          Vendas registradas ficam no histórico.{" "}
          {isCompanyAdmin ? (
            <>
              Como <strong className="text-foreground">owner ou admin</strong>, você pode cancelar
              uma venda finalizada — o estoque é estornado automaticamente.
            </>
          ) : (
            <>
              Somente <strong className="text-foreground">owner ou admin</strong> da empresa pode
              cancelar uma venda com estorno de estoque.
            </>
          )}
        </p>
      </div>

      {!hasActiveCompany ? (
        <div className="rounded-2xl border bg-card p-12 text-center">
          <Building2 className="mx-auto h-10 w-10 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">
            Selecione ou crie uma empresa para ver as vendas.
          </p>
        </div>
      ) : isLoading ? (
        <p className="text-muted-foreground">Carregando...</p>
      ) : isError ? (
        <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-8 text-center">
          <AlertTriangle className="mx-auto h-8 w-8 text-destructive" />
          <p className="mt-3 text-sm text-muted-foreground">Não foi possível carregar as vendas.</p>
          <button
            onClick={() => refetch()}
            className="mt-4 rounded-lg border border-input px-4 py-2 text-sm font-medium hover:bg-accent"
          >
            Tentar novamente
          </button>
        </div>
      ) : vendas.length === 0 ? (
        <div className="rounded-2xl border bg-card p-12 text-center">
          <Receipt className="mx-auto h-10 w-10 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">
            Nenhuma venda registrada ainda. As vendas aparecem aqui assim que forem finalizadas na
            tela de Venda direta.
          </p>
          <Link
            to="/app/venda-direta"
            className="mt-4 inline-flex items-center gap-2 rounded-lg border border-input px-4 py-2 text-sm font-medium hover:bg-accent"
          >
            <Plus className="h-4 w-4" /> Registrar a primeira venda
          </Link>
        </div>
      ) : (
        <>
          <div className="mb-4 space-y-3">
            {/* Uma linha em desktop; flex-wrap quebra em tablet/mobile (Rev. 211). */}
            <div className="flex flex-wrap items-end gap-3">
              <label className="flex min-w-[9.5rem] flex-1 basis-[calc(50%-0.375rem)] flex-col gap-1 sm:basis-auto sm:flex-none sm:min-w-[11rem]">
                <span className="text-xs font-medium text-muted-foreground">Status</span>
                <select
                  value={statusFiltro}
                  onChange={(e) => setStatusFiltro(e.target.value as StatusFilter)}
                  className={selectClass}
                >
                  {STATUS_OPCOES.map((o) => (
                    <option key={o.key} value={o.key}>
                      {opcaoComContagem(o.label, statusCounts[o.key])}
                    </option>
                  ))}
                </select>
              </label>

              <label className="flex min-w-[9.5rem] flex-1 basis-[calc(50%-0.375rem)] flex-col gap-1 sm:basis-auto sm:flex-none sm:min-w-[11rem]">
                <span className="text-xs font-medium text-muted-foreground">Pagamento</span>
                <select
                  value={pagamentoFiltro}
                  onChange={(e) => setPagamentoFiltro(e.target.value as PaymentFilter)}
                  className={selectClass}
                >
                  {PAGAMENTO_OPCOES.map((o) => (
                    <option key={o.key} value={o.key}>
                      {opcaoComContagem(o.label, pagamentoCounts[o.key])}
                    </option>
                  ))}
                </select>
              </label>

              <label className="flex min-w-[9.5rem] flex-1 basis-full flex-col gap-1 sm:basis-auto sm:flex-none sm:min-w-[11rem]">
                <span className="text-xs font-medium text-muted-foreground">Período</span>
                <select
                  value={periodoSelect}
                  onChange={(e) => handlePeriodoChange(e.target.value as PeriodoSelect)}
                  className={selectClass}
                >
                  {PERIODO_OPCOES.map((o) => (
                    <option key={o.key} value={o.key}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            {periodoSelect === "personalizado" && (
              <div className="flex flex-wrap items-end gap-3">
                <label className="flex min-w-[9.5rem] flex-1 flex-col gap-1 sm:flex-none sm:min-w-[11rem]">
                  <span className="text-xs font-medium text-muted-foreground">De</span>
                  <div className="inline-flex items-center gap-2 rounded-lg border border-input bg-background px-3 py-2 text-sm">
                    <Calendar className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                    <input
                      type="date"
                      value={dataDe}
                      onChange={(e) => setDataDe(e.target.value)}
                      className="min-w-0 flex-1 bg-transparent outline-none"
                    />
                  </div>
                </label>
                <label className="flex min-w-[9.5rem] flex-1 flex-col gap-1 sm:flex-none sm:min-w-[11rem]">
                  <span className="text-xs font-medium text-muted-foreground">Até</span>
                  <div className="inline-flex items-center gap-2 rounded-lg border border-input bg-background px-3 py-2 text-sm">
                    <Calendar className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                    <input
                      type="date"
                      value={dataAte}
                      onChange={(e) => setDataAte(e.target.value)}
                      className="min-w-0 flex-1 bg-transparent outline-none"
                    />
                  </div>
                </label>
              </div>
            )}

            <div className="flex items-center gap-2 rounded-lg border bg-card px-3 py-2">
              <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
              <input
                value={buscaCliente}
                onChange={(e) => setBuscaCliente(e.target.value)}
                placeholder="Buscar por nome do cliente..."
                disabled={!hasActiveCompany}
                className="flex-1 bg-transparent text-sm outline-none disabled:cursor-not-allowed"
              />
            </div>
          </div>

          {filtered.length === 0 ? (
            <div className="rounded-2xl border bg-card p-12 text-center">
              <Receipt className="mx-auto h-10 w-10 text-muted-foreground" />
              <p className="mt-3 text-sm text-muted-foreground">
                {filtrosAtivos
                  ? "Nenhuma venda encontrada com os filtros atuais."
                  : "Nenhuma venda nessa combinação."}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-2xl border bg-card">
              <table className="w-full min-w-[720px] text-sm">
                <thead className="border-b bg-muted/50 text-left text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3">Número</th>
                    <th className="px-4 py-3">Data</th>
                    <th className="px-4 py-3">Cliente</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Pagamento</th>
                    <th className="px-4 py-3 text-right">Total</th>
                    <th className="px-4 py-3 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filtered.map((v) => {
                    const comprador = compradorLabel(v);
                    const statusMeta = SALE_STATUS_META[v.status] ?? SALE_STATUS_META.finalizada;
                    const cancelada = v.status === "cancelada";
                    const abrir = () => navigate({ to: "/app/vendas/$id", params: { id: v.id } });
                    return (
                      <tr
                        key={v.id}
                        onClick={abrir}
                        className={`cursor-pointer hover:bg-muted/30 ${cancelada ? "opacity-70" : ""}`}
                      >
                        <td className="px-4 py-3">
                          <Link
                            to="/app/vendas/$id"
                            params={{ id: v.id }}
                            onClick={(e) => e.stopPropagation()}
                            className={`font-semibold text-primary hover:underline ${cancelada ? "line-through decoration-muted-foreground/60" : ""}`}
                          >
                            #{v.numero}
                          </Link>
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">{dateBR(v.created_at)}</td>
                        <td className="px-4 py-3">
                          {comprador.texto}
                          {comprador.avulsa && (
                            <span className="ml-2 rounded-full bg-muted px-2 py-0.5 text-[10px] font-semibold uppercase text-muted-foreground">
                              avulsa
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <span className={`rounded-full px-2 py-0.5 text-xs ${statusMeta.tone}`}>
                            {statusMeta.label}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">
                          {pagamentoLabel(v.forma_pagamento)}
                        </td>
                        <td className="px-4 py-3 text-right font-display font-semibold">
                          {brl(Number(v.total))}
                        </td>
                        <td className="px-4 py-3">
                          <div
                            className="flex items-center justify-end gap-1"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <Link
                              to="/app/vendas/$id"
                              params={{ id: v.id }}
                              title="Visualizar"
                              className="grid h-8 w-8 place-items-center rounded-lg border bg-background text-muted-foreground hover:text-foreground"
                            >
                              <Eye className="h-3.5 w-3.5" />
                            </Link>
                            <Link
                              to="/app/vendas/$id/comprovante"
                              params={{ id: v.id }}
                              title="Imprimir comprovante"
                              className="grid h-8 w-8 place-items-center rounded-lg border bg-background text-muted-foreground hover:text-foreground"
                            >
                              <Printer className="h-3.5 w-3.5" />
                            </Link>
                            <button
                              type="button"
                              title="Gerar PDF novamente"
                              disabled={gerando === v.id}
                              onClick={() => gerarPdf(v.id, v.numero)}
                              className="grid h-8 w-8 place-items-center rounded-lg border bg-background text-muted-foreground hover:text-foreground disabled:opacity-50"
                            >
                              {gerando === v.id ? (
                                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                              ) : (
                                <FileDown className="h-3.5 w-3.5" />
                              )}
                            </button>
                            {isCompanyAdmin && canCancelSale(v.status) && (
                              <button
                                type="button"
                                title="Cancelar venda"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setCancelar({ id: v.id, numero: v.numero });
                                }}
                                className="grid h-8 w-8 place-items-center rounded-lg border border-destructive/30 bg-background text-destructive hover:bg-destructive/10"
                              >
                                <Ban className="h-3.5 w-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}

      {cancelar && (
        <CancelSaleDialog
          open
          saleId={cancelar.id}
          saleNumero={cancelar.numero}
          onOpenChange={(open) => {
            if (!open) setCancelar(null);
          }}
        />
      )}
    </div>
  );
}
