import { createFileRoute } from "@tanstack/react-router";
import { InventorySpecialtyPage } from "@/components/inventory/InventorySpecialtyPage";
import { ModuleLockedCard } from "@/components/ModuleLockedCard";
import { getPlanFromStorage, hasModuleAccess } from "@/lib/module-access";

export const Route = createFileRoute("/_authenticated/app/ferragens")({ component: FerragensPage });

function FerragensPage() {
  const plan = getPlanFromStorage();
  const allowed = hasModuleAccess(plan, "ferragens_vidro");

  if (!allowed) return <ModuleLockedCard moduleKey="ferragens_vidro" />;

  return (
    <InventorySpecialtyPage
      title="Ferragens para vidro"
      description="Gerencie ferragens e acessórios utilizados em projetos de vidraçaria."
      lockedCategoria="ferragem"
      defaultUnidade="un"
      createLabel="Nova ferragem"
      emptyTitle="Nenhuma ferragem cadastrada."
      emptyCta="Cadastrar ferragem"
      dialogCreateTitle="Nova ferragem"
    />
  );
}
