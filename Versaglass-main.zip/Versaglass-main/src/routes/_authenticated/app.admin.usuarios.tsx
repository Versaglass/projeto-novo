import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, type Permissions, type AppRole } from "@/hooks/use-auth";
import type { CompanyRole } from "@/contexts/company-context";
import {
  Shield,
  ShieldCheck,
  ShieldOff,
  Search,
  ChevronRight,
  Loader2,
  ArrowLeft,
  Building2,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { requireAdmin } from "@/lib/admin-guard";
import { DEFAULT_FINE_PERMISSIONS } from "@/lib/fine-permissions";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/app/admin/usuarios")({
  beforeLoad: requireAdmin,
  component: UsersAdminPage,
});

const DEFAULT_PERMS = DEFAULT_FINE_PERMISSIONS;

const ROLE_PRECEDENCE: AppRole[] = ["admin", "vendedor", "instalador"];

const PLATFORM_ROLE_LABEL: Record<AppRole, string> = {
  admin: "Admin (plataforma)",
  vendedor: "Vendedor (plataforma)",
  instalador: "Instalador (plataforma)",
};

const COMPANY_ROLE_LABEL: Record<string, string> = {
  owner: "Proprietário",
  admin: "Administrador",
  manager: "Gerente",
  operator: "Operador",
  installer: "Instalador",
  seller: "Vendedor",
};

const PERM_LABELS: { key: keyof Permissions; label: string; desc: string }[] = [
  {
    key: "manage_projetos",
    label: "Gerenciar projetos",
    desc: "Criar/editar catálogo de vidros e esquadrias",
  },
  {
    key: "manage_estoque",
    label: "Gerenciar estoque",
    desc: "Lançar entradas/saídas de aluminios, vidros e acessórios",
  },
  { key: "manage_clientes", label: "Gerenciar clientes", desc: "Cadastrar e editar clientes" },
  { key: "create_orcamentos", label: "Criar orçamentos", desc: "Gerar novos orçamentos" },
  { key: "edit_orcamentos", label: "Editar orçamentos", desc: "Alterar orçamentos existentes" },
  { key: "delete_orcamentos", label: "Excluir orçamentos", desc: "Apagar orçamentos do sistema" },
  { key: "use_plano_corte", label: "Plano de corte", desc: "Usar otimizador de chaparia e barras" },
];

type UserRow = {
  id: string;
  nome: string | null;
  telefone: string | null;
  ativo: boolean;
  permissions: Permissions;
  platformRole: AppRole;
};

type CompanyRow = {
  id: string;
  company_name: string;
  cnpj: string | null;
  segment: string | null;
  city: string | null;
  state: string | null;
  email: string | null;
  phone: string | null;
};

type CompanyMemberView = {
  user: UserRow;
  companyRole: CompanyRole;
  membershipStatus: string;
};

type AdminDirectory = {
  companies: CompanyRow[];
  membersByCompany: Record<string, CompanyMemberView[]>;
  orphans: UserRow[];
  usersById: Record<string, UserRow>;
};

const ORPHAN_KEY = "__sem_empresa__";

function normalizePermissions(raw: unknown): Permissions {
  return {
    ...DEFAULT_PERMS,
    ...((raw as Partial<Permissions> | null) ?? {}),
  };
}

function pickPlatformRole(roles: AppRole[]): AppRole {
  return ROLE_PRECEDENCE.find((r) => roles.includes(r)) ?? "vendedor";
}

function companyRoleLabel(role: string) {
  return COMPANY_ROLE_LABEL[role] ?? role;
}

function UsersAdminPage() {
  const qc = useQueryClient();
  const { user: me } = useAuth();
  const [search, setSearch] = useState("");
  const [selectedCompanyId, setSelectedCompanyId] = useState<string | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["admin-users-directory"],
    queryFn: async (): Promise<AdminDirectory> => {
      const [
        { data: companies, error: companiesError },
        { data: members, error: membersError },
        { data: profiles, error: profilesError },
        { data: roles, error: rolesError },
      ] = await Promise.all([
        supabase
          .from("company_profiles")
          .select("id, company_name, cnpj, segment, city, state, email, phone")
          .order("company_name"),
        supabase.from("company_members").select("company_id, user_id, role, status"),
        supabase.from("profiles").select("id, nome, telefone, ativo, permissions").order("nome"),
        supabase.from("user_roles").select("user_id, role"),
      ]);
      if (companiesError) throw companiesError;
      if (membersError) throw membersError;
      if (profilesError) throw profilesError;
      if (rolesError) throw rolesError;

      const rolesByUser = new Map<string, AppRole[]>();
      for (const row of roles ?? []) {
        const list = rolesByUser.get(row.user_id) ?? [];
        list.push(row.role as AppRole);
        rolesByUser.set(row.user_id, list);
      }

      const usersById: Record<string, UserRow> = {};
      for (const p of profiles ?? []) {
        usersById[p.id] = {
          id: p.id,
          nome: p.nome,
          telefone: p.telefone,
          ativo: p.ativo,
          permissions: normalizePermissions(p.permissions),
          platformRole: pickPlatformRole(rolesByUser.get(p.id) ?? []),
        };
      }

      const membersByCompany: Record<string, CompanyMemberView[]> = {};
      const userIdsInAnyCompany = new Set<string>();

      for (const m of members ?? []) {
        if (!m.company_id || !m.user_id) continue;
        const user = usersById[m.user_id];
        if (!user) continue;
        userIdsInAnyCompany.add(m.user_id);
        const list = membersByCompany[m.company_id] ?? [];
        list.push({
          user,
          companyRole: m.role as CompanyRole,
          membershipStatus: m.status,
        });
        membersByCompany[m.company_id] = list;
      }

      for (const companyId of Object.keys(membersByCompany)) {
        membersByCompany[companyId].sort((a, b) =>
          (a.user.nome ?? "").localeCompare(b.user.nome ?? "", "pt-BR"),
        );
      }

      const orphans = Object.values(usersById)
        .filter((u) => !userIdsInAnyCompany.has(u.id))
        .sort((a, b) => (a.nome ?? "").localeCompare(b.nome ?? "", "pt-BR"));

      return {
        companies: (companies ?? []) as CompanyRow[],
        membersByCompany,
        orphans,
        usersById,
      };
    },
  });

  const selectedCompany = useMemo(
    () =>
      selectedCompanyId && selectedCompanyId !== ORPHAN_KEY
        ? ((data?.companies ?? []).find((c) => c.id === selectedCompanyId) ?? null)
        : null,
    [data?.companies, selectedCompanyId],
  );

  const companyMembers: CompanyMemberView[] = useMemo(() => {
    if (!selectedCompanyId || selectedCompanyId === ORPHAN_KEY) return [];
    return data?.membersByCompany?.[selectedCompanyId] ?? [];
  }, [data?.membersByCompany, selectedCompanyId]);

  const filteredCompanies = useMemo(() => {
    const list = data?.companies ?? [];
    const q = search.trim().toLowerCase();
    if (!q) return list;
    return list.filter((c) =>
      [c.company_name, c.cnpj, c.city, c.state, c.segment].some((v) =>
        v?.toLowerCase().includes(q),
      ),
    );
  }, [data?.companies, search]);

  const filteredCompanyMembers = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return companyMembers;
    return companyMembers.filter((m) =>
      [
        m.user.nome,
        m.user.telefone,
        companyRoleLabel(m.companyRole),
        PLATFORM_ROLE_LABEL[m.user.platformRole],
        m.membershipStatus,
      ].some((v) => v?.toLowerCase().includes(q)),
    );
  }, [companyMembers, search]);

  const filteredOrphans = useMemo(() => {
    const list = data?.orphans ?? [];
    const q = search.trim().toLowerCase();
    if (!q) return list;
    return list.filter((u) =>
      [u.nome, u.telefone, PLATFORM_ROLE_LABEL[u.platformRole]].some((v) =>
        v?.toLowerCase().includes(q),
      ),
    );
  }, [data?.orphans, search]);

  const usersById = data?.usersById ?? {};
  const selectedUser = selectedUserId ? (usersById[selectedUserId] ?? null) : null;
  const selectedMembership = useMemo(() => {
    if (!selectedUserId || !selectedCompanyId || selectedCompanyId === ORPHAN_KEY) return null;
    return (
      (data?.membersByCompany?.[selectedCompanyId] ?? []).find(
        (m) => m.user.id === selectedUserId,
      ) ?? null
    );
  }, [data?.membersByCompany, selectedCompanyId, selectedUserId]);

  const openCompany = (id: string) => {
    setSelectedCompanyId(id);
    setSelectedUserId(null);
    setSearch("");
  };

  const backToCompanies = () => {
    setSelectedCompanyId(null);
    setSelectedUserId(null);
    setSearch("");
  };

  const updateRole = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: AppRole }) => {
      const { error: upsertError } = await supabase
        .from("user_roles")
        .upsert({ user_id: userId, role }, { onConflict: "user_id,role" });
      if (upsertError) throw upsertError;

      const { error: deleteError } = await supabase
        .from("user_roles")
        .delete()
        .eq("user_id", userId)
        .neq("role", role);
      if (deleteError) throw deleteError;
    },
    onSuccess: (_data, vars) => {
      toast.success(`Papel de plataforma atualizado para ${PLATFORM_ROLE_LABEL[vars.role]}`);
      qc.invalidateQueries({ queryKey: ["admin-users-directory"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const togglePerm = useMutation({
    mutationFn: async ({ user, key }: { user: UserRow; key: keyof Permissions }) => {
      const base = normalizePermissions(user.permissions);
      const next: Permissions = { ...base, [key]: !base[key] };
      const { error } = await supabase
        .from("profiles")
        .update({ permissions: next })
        .eq("id", user.id);
      if (error) throw error;
      return next;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-users-directory"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const toggleActive = useMutation({
    mutationFn: async (user: UserRow) => {
      if (user.id === me?.id) {
        throw new Error("Você não pode desativar a própria conta nesta tela.");
      }
      const next = !user.ativo;
      const { error } = await supabase.from("profiles").update({ ativo: next }).eq("id", user.id);
      if (error) throw error;
      return next;
    },
    onSuccess: (next) => {
      toast.success(next ? "Usuário ativado" : "Usuário desativado");
      qc.invalidateQueries({ queryKey: ["admin-users-directory"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const busy = updateRole.isPending || togglePerm.isPending || toggleActive.isPending;
  const busyUserId = updateRole.isPending
    ? updateRole.variables?.userId
    : togglePerm.isPending
      ? togglePerm.variables?.user.id
      : toggleActive.isPending
        ? toggleActive.variables?.id
        : null;

  const inCompanyView = selectedCompanyId !== null;
  const inOrphanView = selectedCompanyId === ORPHAN_KEY;

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold flex items-center gap-2">
            <Shield className="h-7 w-7 text-gold" /> Usuários & permissões
          </h1>
          <p className="text-sm text-muted-foreground">
            {inCompanyView
              ? "Selecione um usuário da empresa para editar papel de plataforma e permissões."
              : "Selecione uma empresa para ver os membros vinculados."}
          </p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={
              inOrphanView
                ? "Buscar usuário..."
                : inCompanyView
                  ? "Buscar usuário da empresa..."
                  : "Buscar empresa..."
            }
            className="w-full rounded-lg border border-input bg-background pl-9 pr-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
          />
        </div>
      </div>

      {isLoading ? (
        <p className="text-muted-foreground">Carregando...</p>
      ) : !inCompanyView ? (
        <CompaniesList
          companies={filteredCompanies}
          membersByCompany={data?.membersByCompany ?? {}}
          orphanCount={(data?.orphans ?? []).length}
          onOpenCompany={openCompany}
          onOpenOrphans={() => openCompany(ORPHAN_KEY)}
        />
      ) : inOrphanView ? (
        <OrphanUsersView
          users={filteredOrphans}
          meId={me?.id}
          onBack={backToCompanies}
          onSelectUser={setSelectedUserId}
          selectedUserId={selectedUserId}
        />
      ) : (
        <CompanyUsersView
          company={selectedCompany}
          members={filteredCompanyMembers}
          meId={me?.id}
          onBack={backToCompanies}
          onSelectUser={setSelectedUserId}
          selectedUserId={selectedUserId}
        />
      )}

      <Sheet
        open={!!selectedUser}
        onOpenChange={(open) => {
          if (!open) setSelectedUserId(null);
        }}
      >
        <SheetContent
          side="right"
          className="flex w-full flex-col gap-0 overflow-y-auto sm:max-w-lg"
        >
          {selectedUser ? (
            <UserDetailPanel
              user={selectedUser}
              companyName={selectedCompany?.company_name ?? null}
              companyRole={selectedMembership?.companyRole ?? null}
              isMe={selectedUser.id === me?.id}
              busy={busy && busyUserId === selectedUser.id}
              onRoleChange={(role) => updateRole.mutate({ userId: selectedUser.id, role })}
              onTogglePerm={(key) => togglePerm.mutate({ user: selectedUser, key })}
              onToggleActive={() => toggleActive.mutate(selectedUser)}
            />
          ) : null}
        </SheetContent>
      </Sheet>
    </div>
  );
}

function CompaniesList({
  companies,
  membersByCompany,
  orphanCount,
  onOpenCompany,
  onOpenOrphans,
}: {
  companies: CompanyRow[];
  membersByCompany: Record<string, CompanyMemberView[]>;
  orphanCount: number;
  onOpenCompany: (id: string) => void;
  onOpenOrphans: () => void;
}) {
  return (
    <div className="space-y-4">
      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <ul className="divide-y divide-border">
          {companies.map((c) => {
            const count = membersByCompany[c.id]?.length ?? 0;
            return (
              <li key={c.id}>
                <button
                  type="button"
                  onClick={() => onOpenCompany(c.id)}
                  className="flex w-full items-center gap-3 px-4 py-3 text-left transition hover:bg-muted/40"
                >
                  <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-muted">
                    <Building2 className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-semibold">{c.company_name}</div>
                    <div className="mt-0.5 truncate text-sm text-muted-foreground">
                      {[c.cnpj, [c.city, c.state].filter(Boolean).join("/")]
                        .filter(Boolean)
                        .join(" · ") || "Sem CNPJ / cidade"}
                    </div>
                  </div>
                  <span className="shrink-0 text-sm text-muted-foreground">
                    {count} {count === 1 ? "usuário" : "usuários"}
                  </span>
                  <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                </button>
              </li>
            );
          })}
        </ul>
        {companies.length === 0 && (
          <p className="p-8 text-center text-sm text-muted-foreground">
            Nenhuma empresa encontrada.
          </p>
        )}
      </div>

      {orphanCount > 0 && (
        <button
          type="button"
          onClick={onOpenOrphans}
          className="flex w-full items-center gap-3 rounded-2xl border border-dashed border-border bg-card px-4 py-3 text-left transition hover:bg-muted/40"
        >
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-muted">
            <Users className="h-4 w-4 text-muted-foreground" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="font-semibold">Usuários sem empresa</div>
            <div className="text-sm text-muted-foreground">
              Contas em profiles sem vínculo em company_members
            </div>
          </div>
          <span className="shrink-0 text-sm text-muted-foreground">
            {orphanCount} {orphanCount === 1 ? "usuário" : "usuários"}
          </span>
          <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
        </button>
      )}
    </div>
  );
}

function CompanyUsersView({
  company,
  members,
  meId,
  onBack,
  onSelectUser,
  selectedUserId,
}: {
  company: CompanyRow | null;
  members: CompanyMemberView[];
  meId?: string;
  onBack: () => void;
  onSelectUser: (id: string) => void;
  selectedUserId: string | null;
}) {
  if (!company) {
    return (
      <div className="space-y-4">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Voltar para empresas
        </button>
        <p className="text-sm text-muted-foreground">Empresa não encontrada.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> Voltar para empresas
      </button>

      <div className="rounded-2xl border border-border bg-card p-4">
        <h2 className="font-display text-xl font-bold">{company.company_name}</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          {members.length} {members.length === 1 ? "usuário" : "usuários"} vinculados
        </p>
        <dl className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
          {company.cnpj ? (
            <div>
              <dt className="text-xs text-muted-foreground">CNPJ</dt>
              <dd>{company.cnpj}</dd>
            </div>
          ) : null}
          {company.segment ? (
            <div>
              <dt className="text-xs text-muted-foreground">Segmento</dt>
              <dd>{company.segment}</dd>
            </div>
          ) : null}
          {(company.city || company.state) && (
            <div>
              <dt className="text-xs text-muted-foreground">Local</dt>
              <dd>{[company.city, company.state].filter(Boolean).join(" / ")}</dd>
            </div>
          )}
          {company.email ? (
            <div>
              <dt className="text-xs text-muted-foreground">E-mail</dt>
              <dd className="truncate">{company.email}</dd>
            </div>
          ) : null}
          {company.phone ? (
            <div>
              <dt className="text-xs text-muted-foreground">Telefone</dt>
              <dd>{company.phone}</dd>
            </div>
          ) : null}
        </dl>
        <p className="mt-3 text-xs text-muted-foreground">
          Dados cadastrais de `company_profiles` (somente leitura nesta tela). Não há painel
          administrativo de configurações de empresa reutilizável além destes campos.
        </p>
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <ul className="divide-y divide-border">
          {members.map((m) => {
            const isMe = m.user.id === meId;
            return (
              <li key={`${m.user.id}-${m.companyRole}`}>
                <button
                  type="button"
                  onClick={() => onSelectUser(m.user.id)}
                  className={cn(
                    "flex w-full items-center gap-3 px-4 py-3 text-left transition hover:bg-muted/40",
                    selectedUserId === m.user.id && "bg-muted/50",
                  )}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="truncate font-semibold">{m.user.nome ?? "Sem nome"}</span>
                      {isMe && (
                        <span className="rounded-full bg-gold/15 px-2 py-0.5 text-[10px] font-semibold text-gold">
                          você
                        </span>
                      )}
                      {!m.user.ativo && (
                        <span className="rounded-full bg-destructive/15 px-2 py-0.5 text-[10px] font-semibold text-destructive">
                          inativo
                        </span>
                      )}
                      {m.membershipStatus !== "active" && (
                        <span className="rounded-full bg-muted px-2 py-0.5 text-[10px] font-semibold text-muted-foreground">
                          {m.membershipStatus}
                        </span>
                      )}
                      {m.user.platformRole === "admin" && (
                        <span className="rounded-full bg-gold/15 px-2 py-0.5 text-[10px] font-semibold text-gold">
                          Super Admin
                        </span>
                      )}
                    </div>
                    <div className="mt-0.5 truncate text-sm text-muted-foreground">
                      {companyRoleLabel(m.companyRole)}
                      {m.user.telefone ? ` · ${m.user.telefone}` : null}
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                </button>
              </li>
            );
          })}
        </ul>
        {members.length === 0 && (
          <p className="p-8 text-center text-sm text-muted-foreground">
            Esta empresa ainda não possui membros vinculados.
          </p>
        )}
      </div>
    </div>
  );
}

function OrphanUsersView({
  users,
  meId,
  onBack,
  onSelectUser,
  selectedUserId,
}: {
  users: UserRow[];
  meId?: string;
  onBack: () => void;
  onSelectUser: (id: string) => void;
  selectedUserId: string | null;
}) {
  return (
    <div className="space-y-4">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> Voltar para empresas
      </button>

      <div>
        <h2 className="font-display text-xl font-bold">Usuários sem empresa</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Agrupamento administrativo — não é um registro em `company_profiles`.
        </p>
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <ul className="divide-y divide-border">
          {users.map((u) => {
            const isMe = u.id === meId;
            return (
              <li key={u.id}>
                <button
                  type="button"
                  onClick={() => onSelectUser(u.id)}
                  className={cn(
                    "flex w-full items-center gap-3 px-4 py-3 text-left transition hover:bg-muted/40",
                    selectedUserId === u.id && "bg-muted/50",
                  )}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="truncate font-semibold">{u.nome ?? "Sem nome"}</span>
                      {isMe && (
                        <span className="rounded-full bg-gold/15 px-2 py-0.5 text-[10px] font-semibold text-gold">
                          você
                        </span>
                      )}
                      {!u.ativo && (
                        <span className="rounded-full bg-destructive/15 px-2 py-0.5 text-[10px] font-semibold text-destructive">
                          inativo
                        </span>
                      )}
                      {u.platformRole === "admin" && (
                        <span className="rounded-full bg-gold/15 px-2 py-0.5 text-[10px] font-semibold text-gold">
                          Super Admin
                        </span>
                      )}
                    </div>
                    <div className="mt-0.5 truncate text-sm text-muted-foreground">
                      {PLATFORM_ROLE_LABEL[u.platformRole]}
                      {u.telefone ? ` · ${u.telefone}` : null}
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                </button>
              </li>
            );
          })}
        </ul>
        {users.length === 0 && (
          <p className="p-8 text-center text-sm text-muted-foreground">
            Nenhum usuário encontrado.
          </p>
        )}
      </div>
    </div>
  );
}

function UserDetailPanel({
  user,
  companyName,
  companyRole,
  isMe,
  busy,
  onRoleChange,
  onTogglePerm,
  onToggleActive,
}: {
  user: UserRow;
  companyName: string | null;
  companyRole: CompanyRole | null;
  isMe: boolean;
  busy: boolean;
  onRoleChange: (role: AppRole) => void;
  onTogglePerm: (key: keyof Permissions) => void;
  onToggleActive: () => void;
}) {
  return (
    <>
      <SheetHeader className="border-b border-border pb-4 text-left">
        <SheetTitle className="font-display text-xl">{user.nome ?? "Sem nome"}</SheetTitle>
        <SheetDescription asChild>
          <div className="space-y-1 text-sm text-muted-foreground">
            {companyName ? (
              <p>
                <span className="font-medium text-foreground">Empresa: </span>
                {companyName}
              </p>
            ) : (
              <p>
                <span className="font-medium text-foreground">Empresa: </span>
                Sem vínculo
              </p>
            )}
            {companyRole ? (
              <p>
                <span className="font-medium text-foreground">Papel na empresa: </span>
                {companyRoleLabel(companyRole)}
              </p>
            ) : null}
            {user.telefone ? (
              <p>
                <span className="font-medium text-foreground">Telefone: </span>
                {user.telefone}
              </p>
            ) : null}
            <p className="font-mono text-xs opacity-70">ID {user.id}</p>
          </div>
        </SheetDescription>
      </SheetHeader>

      <div className="mt-5 space-y-6">
        <section className="space-y-3">
          <h3 className="text-sm font-semibold">Função de plataforma</h3>
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={user.platformRole}
              disabled={isMe || busy}
              onChange={(e) => onRoleChange(e.target.value as AppRole)}
              className="rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring disabled:opacity-50"
            >
              <option value="admin">Admin</option>
              <option value="vendedor">Vendedor</option>
              <option value="instalador">Instalador</option>
            </select>
            {isMe ? (
              <p className="text-xs text-muted-foreground">
                Sua própria conta não pode ser desativada nesta tela.
              </p>
            ) : (
              <button
                type="button"
                onClick={onToggleActive}
                disabled={busy}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold transition disabled:opacity-50",
                  user.ativo
                    ? "border-border hover:border-destructive/40 hover:text-destructive"
                    : "border-emerald-500/40 text-emerald-400",
                )}
              >
                {busy ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : user.ativo ? (
                  <>
                    <ShieldOff className="h-3.5 w-3.5" /> Desativar
                  </>
                ) : (
                  <>
                    <ShieldCheck className="h-3.5 w-3.5" /> Ativar
                  </>
                )}
              </button>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            Papéis de plataforma (`user_roles`): Admin, Vendedor ou Instalador. O papel na empresa
            (`company_members`) é exibido acima e não é editado nesta tela.
          </p>
        </section>

        <section className="space-y-3">
          <h3 className="text-sm font-semibold">Permissões / configurações</h3>
          {user.platformRole === "admin" ? (
            <div className="rounded-lg border border-gold/30 bg-gold/5 p-3 text-sm text-gold">
              Admin de plataforma tem acesso total — permissões finas liberadas automaticamente.
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-2">
              {PERM_LABELS.map((p) => {
                const checked = user.permissions[p.key] ?? false;
                return (
                  <label
                    key={p.key}
                    className={cn(
                      "flex cursor-pointer items-start gap-3 rounded-lg border border-border bg-background/40 p-3 hover:border-gold/40",
                      busy && "pointer-events-none opacity-60",
                    )}
                  >
                    <Checkbox
                      checked={checked}
                      disabled={busy}
                      onCheckedChange={() => onTogglePerm(p.key)}
                      className="mt-0.5"
                    />
                    <div>
                      <div className="text-sm font-semibold">{p.label}</div>
                      <div className="text-xs text-muted-foreground">{p.desc}</div>
                    </div>
                  </label>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </>
  );
}
