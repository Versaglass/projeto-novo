import { createFileRoute, useNavigate, Link, type SearchSchemaInput } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { textoParaNumero, validaCamposNumericos } from "@/lib/numero-campo";
import { num } from "@/lib/format";
import {
  Plus,
  Trash2,
  PackageSearch,
  MessageCircle,
  Loader2,
  FileDown,
  CheckCircle2,
  X,
  Search,
  ImageIcon,
  Printer,
} from "lucide-react";
import { toast } from "sonner";
import { useCompany } from "@/contexts/company-context";
import { useCompanyStockOptions, useInventoryItem, categoriaMeta } from "@/hooks/use-inventory";
import { ListaRolavel } from "@/components/ui/lista-rolavel";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { StorageImage } from "@/components/StorageImage";
import { itemPossuiImagem, obterImagemUrlDoItem } from "@/lib/quote-item-image";
import { useCompanyCustomerOptions } from "@/hooks/use-quotes";
import {
  useCreateSale,
  saleErrorMessage,
  SALE_PAYMENT_METHODS,
  type SalePaymentMethod,
  type SaleUnit,
  type SaleDocument,
  type SaleItemInput,
} from "@/hooks/use-sales";
import { generateSalePdf } from "@/lib/sale-pdf";
import { validarTelefoneBr, openWhatsApp } from "@/lib/whatsapp";

/**
 * VENDA DIRETA — venda de balcão persistida em `public.sales` / `public.sale_items`.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * O ARQUIVO SE CHAMAVA `app.calculadora.tsx` ATÉ A REVISÃO 89
 * ────────────────────────────────────────────────────────────────────────────
 * A Revisão 79 registrou o incômodo: quem procurava "venda" em `src/routes` não
 * achava esta tela, porque arquivo, rota e componente diziam "calculadora"
 * enquanto o título dizia "Venda direta". A Revisão 87 avaliou renomear e
 * ADIOU — não por inércia, mas porque dois dos três pontos de entrada estavam
 * em arquivos fora do alcance daquela rodada.
 *
 * A Revisão 89 renomeou: o arquivo virou `app.venda-direta.tsx` e a rota,
 * **`/app/venda-direta`**. `/app/calculadora` continua existindo como
 * **redirect**, para não quebrar link salvo nem favorito — o arquivo antigo
 * ficou no lugar com um `beforeLoad` que redireciona e nada mais.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * O QUE MUDOU EM RELAÇÃO À MAQUETE (Revisão 79 → 87)
 * ────────────────────────────────────────────────────────────────────────────
 * O layout é o mesmo — tabela editável, unidades, busca de estoque, desconto por
 * linha. O motor é outro:
 *
 *   · "Finalizar venda" chama `create_sale_with_items` e SÓ ENTÃO gera o PDF, a
 *     partir do que o banco confirmou. Antes era `window.print()`.
 *   · "Salvar rascunho" FOI REMOVIDO. Ele dizia "Venda salva no rascunho local"
 *     e não salvava nada (0 requisições, 0 chaves novas). A v1 da RPC não tem
 *     status nem rascunho, então a promessa não tinha como ser cumprida. O que
 *     ficou no lugar é um rascunho de memória, honestamente rotulado.
 *   · "Buscar no estoque" ABRE UM SELETOR AQUI DENTRO. Antes navegava para
 *     `/app/estoque` e a navegação desmontava o componente, apagando cliente,
 *     observações e medidas.
 *   · O fallback `(area || 1)` saiu: item em m² sem medida agora é ERRO na tela,
 *     antes de chegar à RPC — que também o recusa (22023).
 *   · `observacoes` é enviada à RPC e sai impressa na nota.
 *   · WhatsApp usa `validarTelefoneBr` + `openWhatsApp` (Revisões 56-59).
 */

/**
 * `?itemId=` — atalho "Vender" da tela de Estoque (Revisão 106).
 *
 * Segue o contrato que `app.orcamentos.novo.tsx` estabeleceu para `?templateId=`,
 * e pelo mesmo motivo: chave AUSENTE é a única remoção real. Devolver `""` faria
 * o router serializar `?itemId=` e a chave ficaria pendurada na barra de endereço
 * depois que o item já entrou na venda — e um F5 ali tentaria adicionar de novo.
 */
type VendaDiretaSearchInput = { itemId?: string } & SearchSchemaInput;
export type VendaDiretaSearch = { itemId?: string };

export const Route = createFileRoute("/_authenticated/app/venda-direta")({
  validateSearch: (search: VendaDiretaSearchInput): VendaDiretaSearch =>
    typeof search.itemId === "string" && search.itemId.trim() !== ""
      ? { itemId: search.itemId }
      : {},
  component: VendaDiretaPage,
});

type LinhaVenda = {
  id: string;
  /** Item do catálogo que originou a linha; `null` = avulso, não baixa estoque. */
  inventoryItemId: string | null;
  nome: string;
  categoria: string;
  unidade: SaleUnit;
  /** Milímetros — como o balcão mede. Convertido para metros no envio. */
  largura: string;
  altura: string;
  qtd: string;
  valorUnit: string;
  desconto: string;
  /** Saldo do catálogo no momento em que a linha foi criada. Só para aviso. */
  saldoDisponivel: number | null;
};

const UNIDADES: ReadonlyArray<{ value: SaleUnit; label: string }> = [
  { value: "un", label: "un" },
  { value: "m", label: "m" },
  { value: "m2", label: "m²" },
  { value: "kg", label: "kg" },
  { value: "pc", label: "pç" },
  { value: "cx", label: "cx" },
];

function uid() {
  return crypto.randomUUID?.() ?? Math.random().toString(36).slice(2);
}

function brl(n: number) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(n || 0);
}

/** Texto preenchido E não numérico — o que a linha deve acusar (Revisão 32). */
function entradaInvalida(v: string) {
  return v.trim() !== "" && Number.isNaN(textoParaNumero(v));
}

const CAMPOS_NUMERICOS = [
  { chave: "largura", rotulo: "Largura" },
  { chave: "altura", rotulo: "Altura" },
  { chave: "qtd", rotulo: "Qtd" },
  { chave: "valorUnit", rotulo: "Valor" },
  { chave: "desconto", rotulo: "Desc." },
] as const;

/**
 * Prévia da linha — espelha o cálculo da RPC, sem inventar nada.
 *
 * 🔴 O `(area || 1)` da versão anterior SAIU. Era ele que fazia a tela abrir
 * cobrando R$ 350,00 com "Área vendida 0,00 m²": sem medida, o item em m² era
 * cobrado como se fosse 1 m². Agora, sem medida, a área é 0, o subtotal é 0 e a
 * linha aponta o que falta — igual ao que a RPC faz (22023).
 */
function calcLinha(item: LinhaVenda) {
  const invalidos = CAMPOS_NUMERICOS.filter((c) => entradaInvalida(item[c.chave])).map(
    (c) => c.rotulo,
  );

  const qtd = textoParaNumero(item.qtd) || 0;
  const valorUnit = textoParaNumero(item.valorUnit) || 0;
  const desconto = textoParaNumero(item.desconto) || 0;
  const larguraMm = textoParaNumero(item.largura) || 0;
  const alturaMm = textoParaNumero(item.altura) || 0;

  // Milímetros na tela → metros no cálculo, a mesma unidade que a RPC recebe.
  const larguraM = larguraMm / 1000;
  const alturaM = alturaMm / 1000;
  const areaUnitaria = item.unidade === "m2" ? larguraM * alturaM : 0;
  const area = areaUnitaria * qtd;

  const base = item.unidade === "m2" ? area : qtd;
  const subtotal = invalidos.length ? 0 : Math.max(0, base * valorUnit - desconto);

  // Falta de medida em m² é ERRO, não um zero silencioso.
  const faltaMedida = item.unidade === "m2" && (larguraMm <= 0 || alturaMm <= 0);
  // Quanto sairia do estoque se a venda fosse agora.
  const baixa = item.inventoryItemId ? base : 0;
  const excedeSaldo =
    item.inventoryItemId !== null &&
    item.saldoDisponivel !== null &&
    baixa > item.saldoDisponivel + 1e-9;

  return {
    qtd,
    valorUnit,
    desconto,
    larguraM,
    alturaM,
    area,
    base,
    subtotal,
    invalidos,
    faltaMedida,
    baixa,
    excedeSaldo,
  };
}

function linhaVazia(partial: Partial<LinhaVenda> = {}): LinhaVenda {
  return {
    id: uid(),
    inventoryItemId: partial.inventoryItemId ?? null,
    nome: partial.nome ?? "",
    categoria: partial.categoria ?? "Geral",
    unidade: partial.unidade ?? "un",
    largura: partial.largura ?? "",
    altura: partial.altura ?? "",
    qtd: partial.qtd ?? "1",
    valorUnit: partial.valorUnit ?? "",
    desconto: partial.desconto ?? "",
    saldoDisponivel: partial.saldoDisponivel ?? null,
  };
}

/**
 * RASCUNHO EM MEMÓRIA — e a palavra "salvo" não aparece em lugar nenhum.
 *
 * É uma variável de módulo: sobrevive a sair da tela e voltar dentro do sistema
 * (o React desmonta o componente, o módulo continua carregado), e **morre em
 * F5, em nova aba e ao fechar o navegador**. Não é persistência, não vai ao
 * banco e não vai ao `localStorage`.
 *
 * Existe porque a Revisão 79 mediu a venda inteira sendo perdida numa
 * navegação. O seletor de estoque interno já elimina a causa principal, mas
 * qualquer outra saída (menu, F5 acidental não, mas voltar/avançar sim) tinha o
 * mesmo efeito. O rótulo na tela diz exatamente isto — o defeito do botão
 * antigo não era não persistir, era AFIRMAR que persistia.
 */
type RascunhoMemoria = {
  linhas: LinhaVenda[];
  customerId: string;
  clienteAvulso: string;
  pagamento: SalePaymentMethod;
  observacoes: string;
};
let rascunhoEmMemoria: RascunhoMemoria | null = null;

function VendaDiretaPage() {
  const { activeCompany, loading: companyLoading } = useCompany();
  const { itemId } = Route.useSearch();
  const navigate = useNavigate();
  const criarVenda = useCreateSale();
  const { data: estoque = [], isLoading: carregandoEstoque } = useCompanyStockOptions();
  const { data: clientes = [] } = useCompanyCustomerOptions();

  const [linhas, setLinhas] = useState<LinhaVenda[]>(
    () => rascunhoEmMemoria?.linhas ?? [linhaVazia()],
  );
  const [customerId, setCustomerId] = useState(() => rascunhoEmMemoria?.customerId ?? "");
  const [clienteAvulso, setClienteAvulso] = useState(() => rascunhoEmMemoria?.clienteAvulso ?? "");
  const [pagamento, setPagamento] = useState<SalePaymentMethod>(
    () => rascunhoEmMemoria?.pagamento ?? "pix",
  );
  const [observacoes, setObservacoes] = useState(() => rascunhoEmMemoria?.observacoes ?? "");

  const [buscaEstoque, setBuscaEstoque] = useState("");
  const [fotoPreview, setFotoPreview] = useState<{ src: string; nome: string } | null>(null);
  const [ultimaVenda, setUltimaVenda] = useState<SaleDocument | null>(null);
  const [gerandoPdf, setGerandoPdf] = useState(false);

  // Espelha o formulário no rascunho de memória a cada mudança.
  useEffect(() => {
    rascunhoEmMemoria = { linhas, customerId, clienteAvulso, pagamento, observacoes };
  }, [linhas, customerId, clienteAvulso, pagamento, observacoes]);

  const totais = useMemo(() => {
    const calc = linhas.map(calcLinha);
    return {
      calc,
      total: calc.reduce((s, x) => s + x.subtotal, 0),
      itens: linhas.length,
      area: calc.reduce((s, x) => s + x.area, 0),
    };
  }, [linhas]);

  const clienteSelecionado = clientes.find((c) => c.id === customerId) ?? null;

  const atualizar = (id: string, patch: Partial<LinhaVenda>) =>
    setLinhas((list) => list.map((l) => (l.id === id ? { ...l, ...patch } : l)));

  const remover = (id: string) => setLinhas((list) => list.filter((l) => l.id !== id));

  /**
   * Item do estoque entra na venda EM ANDAMENTO.
   *
   * 🔴 Este é o defeito 3 da Revisão 79 pela raiz: antes, o único caminho para o
   * estoque era `navigate({ to: "/app/estoque" })`, e voltar trazia a tela
   * zerada — cliente, observações e medidas perdidos. Aqui nada além da lista de
   * linhas é tocado.
   *
   * A unidade vem do catálogo e fica TRAVADA na linha: unidade divergente faria
   * a RPC recusar (22023) porque debitaria a grandeza errada — vender "1 un" de
   * um item cadastrado em m² tiraria 1 do saldo em vez da área.
   */
  const adicionarDoEstoque = (item: (typeof estoque)[number]) => {
    setLinhas((list) => [
      ...list,
      linhaVazia({
        inventoryItemId: item.id,
        nome: item.nome,
        categoria: categoriaMeta(item.categoria)?.label ?? "Geral",
        unidade: item.unidade as SaleUnit,
        valorUnit: String(Number(item.preco_venda) || 0),
        saldoDisponivel: Number(item.quantidade) || 0,
      }),
    ]);
    toast.success(`${item.nome} adicionado à venda`);
  };

  /**
   * Atalho "Vender", vindo da tela de Estoque (Revisão 106).
   *
   * A tela de origem só mostra o botão para item ATIVO e COM saldo, mas isso é
   * conveniência da origem, não garantia: o link pode ser colado, guardado nos
   * favoritos ou aberto minutos depois de outra pessoa desativar o item. Por
   * isso o estado é reconferido AQUI, contra o banco, antes de adicionar.
   *
   * `useInventoryItem` busca por id escopado à empresa ativa (a RLS reforça).
   * Item de OUTRA empresa volta nulo e colapsa na mesma mensagem de
   * "não encontrado" — a interface não confirma que o id existe em outro
   * tenant, mesma regra que o `templateId` do Novo orçamento segue.
   */
  const { data: itemAtalho, isLoading: carregandoAtalho } = useInventoryItem(itemId);
  const atalhoAplicadoRef = useRef(false);

  useEffect(() => {
    if (!itemId || atalhoAplicadoRef.current) return;
    // Espera a empresa ativa e a consulta resolverem: agir antes disso diria
    // "não encontrado" para um item que existe.
    if (companyLoading || carregandoAtalho) return;

    atalhoAplicadoRef.current = true;

    if (!itemAtalho) {
      toast.error("Item não encontrado no estoque desta empresa.");
    } else if (!itemAtalho.ativo) {
      // Mensagem própria, e não a genérica: aqui o item EXISTE e é da empresa,
      // então dizer o motivo é ajuda, não vazamento. E aponta a saída.
      toast.error(
        `"${itemAtalho.nome}" está inativo no estoque. Reative-o em Estoque para vender.`,
      );
    } else if (Number(itemAtalho.quantidade) <= 0) {
      toast.error(`"${itemAtalho.nome}" está sem saldo em estoque — a venda seria recusada.`);
    } else {
      adicionarDoEstoque(itemAtalho);
    }

    // A chave sai da URL em qualquer desfecho, inclusive nos de erro: mantê-la
    // faria o F5 repetir o atalho — e, no caminho feliz, duplicar a linha.
    navigate({ to: "/app/venda-direta", search: {}, replace: true });
  }, [itemId, companyLoading, carregandoAtalho, itemAtalho, navigate]);

  const estoqueFiltrado = useMemo(() => {
    const termo = buscaEstoque.trim().toLowerCase();
    if (!termo) return estoque;
    return estoque.filter(
      (i) =>
        i.nome.toLowerCase().includes(termo) ||
        (i.descricao ?? "").toLowerCase().includes(termo) ||
        (categoriaMeta(i.categoria)?.label ?? "").toLowerCase().includes(termo),
    );
  }, [estoque, buscaEstoque]);

  /**
   * Valida TUDO antes de chamar a RPC e devolve os itens no formato dela.
   *
   * A RPC continua sendo a autoridade — ela revalida cada item e é a única que
   * enxerga o saldo real no instante do commit. O que esta função faz é impedir
   * que o operador descubra um erro de digitação depois de uma ida ao servidor,
   * e traduzir o erro para o campo que ele precisa corrigir.
   */
  const montarItens = (): { ok: true; itens: SaleItemInput[] } | { ok: false; erro: string } => {
    if (linhas.length === 0) return { ok: false, erro: "Adicione ao menos um item à venda." };

    if (customerId && clienteAvulso.trim()) {
      return {
        ok: false,
        erro: "Escolha o cliente cadastrado OU digite um nome avulso — não os dois.",
      };
    }

    const itens: SaleItemInput[] = [];

    for (let i = 0; i < linhas.length; i++) {
      const linha = linhas[i];
      const posicao = `Item ${i + 1}`;
      const nome = linha.nome.trim();
      if (!nome) return { ok: false, erro: `${posicao}: informe a descrição do produto.` };

      // Revisões 32-33: vírgula e ponto aceitos, entrada ilegível RECUSADA com
      // mensagem — nunca convertida em 0 em silêncio.
      const numeros = validaCamposNumericos([
        { chave: "largura", texto: linha.largura, regra: { label: "a largura", min: 0 } },
        { chave: "altura", texto: linha.altura, regra: { label: "a altura", min: 0 } },
        {
          chave: "qtd",
          texto: linha.qtd,
          regra: { label: "a quantidade", min: 0, obrigatorio: true },
        },
        { chave: "valorUnit", texto: linha.valorUnit, regra: { label: "o valor", min: 0 } },
        { chave: "desconto", texto: linha.desconto, regra: { label: "o desconto", min: 0 } },
      ]);
      if (!numeros.ok) return { ok: false, erro: `${posicao} (${nome}): ${numeros.erro}` };

      const { largura, altura, qtd, valorUnit, desconto } = numeros.valores;

      if (qtd <= 0)
        return { ok: false, erro: `${posicao} (${nome}): a quantidade deve ser maior que zero.` };

      // Defeito 4 da Revisão 79, pego AQUI e não só no banco.
      if (linha.unidade === "m2" && (largura <= 0 || altura <= 0)) {
        return {
          ok: false,
          erro: `${posicao} (${nome}): item vendido em m² precisa de largura e altura maiores que zero. Sem medida não há área para cobrar.`,
        };
      }

      const base = linha.unidade === "m2" ? (largura / 1000) * (altura / 1000) * qtd : qtd;

      if (
        linha.inventoryItemId &&
        linha.saldoDisponivel !== null &&
        base > linha.saldoDisponivel + 1e-9
      ) {
        return {
          ok: false,
          erro: `${posicao} (${nome}): estoque insuficiente — disponível ${base > 0 ? linha.saldoDisponivel : 0}, a venda pede ${Number(base.toFixed(4))}.`,
        };
      }

      itens.push({
        inventory_item_id: linha.inventoryItemId,
        descricao: nome,
        unidade: linha.unidade,
        // Metros: a convenção da RPC. A tela digita milímetros.
        largura: largura / 1000,
        altura: altura / 1000,
        quantidade: qtd,
        preco_unit: valorUnit,
        desconto,
      });
    }

    return { ok: true, itens };
  };

  const baixarNota = async (documento: SaleDocument) => {
    setGerandoPdf(true);
    try {
      await generateSalePdf(documento);
      toast.success(`Nota da venda nº ${documento.sale.numero} gerada.`);
    } catch (e) {
      console.error("Falha ao gerar a nota da venda", e);
      toast.error(
        "A venda foi registrada, mas não foi possível gerar o PDF. Tente baixar de novo.",
      );
    } finally {
      setGerandoPdf(false);
    }
  };

  /**
   * Finalizar: RPC primeiro, documento depois.
   *
   * A ordem é o ponto do item 2 do pedido. O PDF só é gerado com o que o banco
   * devolveu (número da venda, m², subtotal e total recalculados) — assim não
   * existe documento de venda que falhou, nem número que ninguém gravou.
   */
  const finalizar = async () => {
    if (!activeCompany?.companyId) {
      toast.error("Selecione uma empresa ativa para registrar a venda.");
      return;
    }

    const montado = montarItens();
    if (!montado.ok) {
      toast.error(montado.erro);
      return;
    }

    try {
      const documento = await criarVenda.mutateAsync({
        items: montado.itens,
        customerId: customerId || null,
        clienteNome: customerId ? null : clienteAvulso.trim() || null,
        formaPagamento: pagamento,
        observacoes: observacoes.trim() || null,
      });

      setUltimaVenda(documento);
      toast.success(
        `Venda nº ${documento.sale.numero} registrada — ${brl(Number(documento.sale.total))}.`,
      );

      // Formulário limpo só DEPOIS do sucesso: se a RPC recusar, o operador
      // continua com tudo digitado para corrigir.
      setLinhas([linhaVazia()]);
      setCustomerId("");
      setClienteAvulso("");
      setObservacoes("");

      await baixarNota(documento);
    } catch (e) {
      console.error("[venda-direta] falha ao registrar a venda", e);
      toast.error(saleErrorMessage(e));
    }
  };

  /**
   * WhatsApp — o padrão das Revisões 56-59, sem exceção.
   *
   * A validação vem ANTES de qualquer efeito. A tela antiga usava
   * `wa.me/?text=` sem telefone nenhum: abria a conversa SEM destinatário, em
   * silêncio. Aqui, sem telefone válido nada acontece além de uma mensagem que
   * diz o que corrigir.
   */
  const enviarWhatsApp = (telefone: string | null | undefined, mensagem: string) => {
    const validado = validarTelefoneBr(telefone);
    if (!validado.ok) {
      toast.error(validado.erro);
      return;
    }
    openWhatsApp(validado.telefone, mensagem);
  };

  const mensagemCarrinho = () => {
    const linhasTexto = linhas
      .map((l, idx) => {
        const c = totais.calc[idx];
        const medida =
          l.unidade === "m2" && c.larguraM > 0 && c.alturaM > 0
            ? ` (${textoParaNumero(l.largura)}×${textoParaNumero(l.altura)}mm)`
            : "";
        return `${idx + 1}. ${l.nome || "Item"}${medida} — ${l.qtd || 0} ${l.unidade === "m2" ? "m²" : l.unidade} — ${brl(c.subtotal)}`;
      })
      .join("\n");
    const pgto = SALE_PAYMENT_METHODS.find((p) => p.value === pagamento)?.label ?? pagamento;
    return `Olá! Segue o resumo da venda:\n\n${linhasTexto}\n\nTotal: ${brl(totais.total)}\nPagamento: ${pgto}`;
  };

  const mensagemVendaConfirmada = (d: SaleDocument) => {
    const pgto =
      SALE_PAYMENT_METHODS.find((p) => p.value === d.sale.forma_pagamento)?.label ??
      d.sale.forma_pagamento;
    return (
      `Olá! Sua compra foi registrada.\n\nVenda nº ${d.sale.numero}\n` +
      `Itens: ${d.items.length}\nTotal: ${brl(Number(d.sale.total))}\nPagamento: ${pgto}`
    );
  };

  const salvando = criarVenda.isPending;
  const linhasComProblema = totais.calc.filter(
    (c) => c.invalidos.length > 0 || c.faltaMedida || c.excedeSaldo,
  ).length;
  const temLinhaInvalida = linhasComProblema > 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Venda direta</h1>
          <p className="text-sm text-muted-foreground">
            Venda de balcão registrada no sistema, com baixa automática do estoque.
          </p>
        </div>
      </div>

      {/* Venda recém-registrada: o número existe no banco, não na tela. */}
      {ultimaVenda && (
        <div className="rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="h-6 w-6 text-emerald-500" />
              <div>
                <div className="font-display font-bold">
                  Venda nº {ultimaVenda.sale.numero} registrada
                </div>
                <div className="text-sm text-muted-foreground">
                  {ultimaVenda.items.length} {ultimaVenda.items.length === 1 ? "item" : "itens"} ·{" "}
                  {brl(Number(ultimaVenda.sale.total))} ·{" "}
                  {ultimaVenda.customer?.nome ??
                    ultimaVenda.sale.cliente_nome ??
                    "Consumidor não identificado"}
                </div>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Link
                to="/app/vendas/$id/comprovante"
                params={{ id: ultimaVenda.sale.id }}
                className="inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-3 py-2 text-sm font-semibold text-gold-foreground shadow-glow"
              >
                <Printer className="h-4 w-4" />
                Imprimir comprovante
              </Link>
              <button
                onClick={() => baixarNota(ultimaVenda)}
                disabled={gerandoPdf}
                className="inline-flex items-center gap-2 rounded-lg border px-3 py-2 text-sm font-semibold hover:bg-accent disabled:opacity-60"
              >
                {gerandoPdf ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <FileDown className="h-4 w-4" />
                )}
                Baixar nota
              </button>
              <button
                onClick={() =>
                  enviarWhatsApp(
                    ultimaVenda.customer?.telefone,
                    mensagemVendaConfirmada(ultimaVenda),
                  )
                }
                className="inline-flex items-center gap-2 rounded-lg bg-green-600 px-3 py-2 text-sm font-semibold text-white hover:bg-green-500"
              >
                <MessageCircle className="h-4 w-4" /> WhatsApp
              </button>
              <button
                onClick={() => setUltimaVenda(null)}
                className="rounded-lg p-2 text-muted-foreground hover:bg-accent"
                aria-label="Fechar aviso"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-4">
        <div className="rounded-2xl border bg-card p-4">
          <div className="text-xs text-muted-foreground">Total da venda</div>
          <div className="font-display text-3xl font-bold text-gold">{brl(totais.total)}</div>
        </div>
        <div className="rounded-2xl border bg-card p-4">
          <div className="text-xs text-muted-foreground">Itens</div>
          <div className="font-display text-3xl font-bold">{totais.itens}</div>
        </div>
        <div className="rounded-2xl border bg-card p-4">
          <div className="text-xs text-muted-foreground">Área vendida</div>
          {/* Era `toFixed(2)`, que imprime "0.00" com PONTO ao lado de um total
              em "R$ 0,00" com VÍRGULA. `num` usa pt-BR, como o resto do app. */}
          <div className="font-display text-3xl font-bold">{num(totais.area, 2)} m²</div>
        </div>
        <div className="rounded-2xl border bg-card p-4">
          <div className="text-xs text-muted-foreground">Pagamento</div>
          <select
            value={pagamento}
            onChange={(e) => setPagamento(e.target.value as SalePaymentMethod)}
            className="mt-2 w-full rounded-lg border bg-background px-3 py-2 text-sm"
          >
            {SALE_PAYMENT_METHODS.map((p) => (
              <option key={p.value} value={p.value}>
                {p.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Busca de estoque — sempre visível, no lugar dos antigos atalhos. */}
      <div className="rounded-2xl border-2 border-gold/30 bg-card p-5 shadow-sm">
        <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 font-display text-lg font-bold">
              <PackageSearch className="h-6 w-6 text-gold" /> Buscar no estoque
            </div>
            <p className="mt-1 text-sm text-muted-foreground">
              Selecione itens do catálogo para baixa automática de saldo. Itens avulsos (sem
              estoque) podem ser digitados na tabela abaixo com &quot;Adicionar linha&quot;.
            </p>
          </div>
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <input
              value={buscaEstoque}
              onChange={(e) => setBuscaEstoque(e.target.value)}
              placeholder="Buscar por nome, descrição ou categoria"
              className="w-full rounded-xl border border-gold/20 bg-background py-2.5 pl-10 pr-3 text-sm focus:border-gold/50 focus:outline-none focus:ring-2 focus:ring-gold/20"
            />
          </div>
        </div>

        {carregandoEstoque ? (
          <div className="flex items-center gap-2 py-8 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Carregando o estoque…
          </div>
        ) : estoqueFiltrado.length === 0 ? (
          <p className="py-8 text-sm text-muted-foreground">
            {estoque.length === 0
              ? "Nenhum item ativo no estoque desta empresa. Cadastre em Estoque para vender com baixa automática."
              : "Nenhum item corresponde à busca."}
          </p>
        ) : (
          <ListaRolavel
            className="grid max-h-[32rem] gap-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
            contagem={
              buscaEstoque.trim()
                ? `${estoqueFiltrado.length} de ${estoque.length} ${estoque.length === 1 ? "item" : "itens"}`
                : `${estoque.length} ${estoque.length === 1 ? "item" : "itens"} no estoque`
            }
          >
            {estoqueFiltrado.map((item) => {
              const saldo = Number(item.quantidade) || 0;
              const semSaldo = saldo <= 0;
              const temImagem = itemPossuiImagem(item);
              const imagemSrc = obterImagemUrlDoItem(item);
              return (
                <div
                  key={item.id}
                  className={`flex items-center gap-3 rounded-xl border bg-background p-3 ${
                    semSaldo ? "opacity-50" : "hover:border-gold/50 hover:bg-gold/5"
                  }`}
                >
                  {temImagem && imagemSrc ? (
                    <button
                      type="button"
                      onClick={() => setFotoPreview({ src: imagemSrc, nome: item.nome })}
                      title={`Visualizar imagem de ${item.nome}`}
                      aria-label={`Visualizar imagem de ${item.nome}`}
                      className="shrink-0 overflow-hidden rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-gold/40"
                    >
                      <StorageImage
                        src={imagemSrc}
                        alt={`Imagem de ${item.nome}`}
                        className="h-14 w-14 object-cover"
                      />
                    </button>
                  ) : (
                    <div
                      className="grid h-14 w-14 shrink-0 place-items-center rounded-lg border border-dashed border-border bg-muted"
                      aria-hidden
                    >
                      <ImageIcon className="h-5 w-5 text-muted-foreground opacity-70" />
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={() => adicionarDoEstoque(item)}
                    disabled={semSaldo}
                    title={
                      semSaldo
                        ? "Sem saldo em estoque — a venda seria recusada."
                        : "Adicionar à venda"
                    }
                    className="flex min-w-0 flex-1 items-center justify-between gap-3 text-left disabled:cursor-not-allowed"
                  >
                    <div className="min-w-0">
                      <div className="truncate text-sm font-semibold">{item.nome}</div>
                      <div className="text-xs text-muted-foreground">
                        {categoriaMeta(item.categoria)?.label ?? item.categoria} ·{" "}
                        {brl(Number(item.preco_venda) || 0)}/
                        {item.unidade === "m2" ? "m²" : item.unidade}
                      </div>
                    </div>
                    <span
                      className={`shrink-0 rounded-full px-2 py-1 text-xs font-semibold ${
                        semSaldo
                          ? "bg-destructive/10 text-destructive"
                          : "bg-emerald-500/10 text-emerald-600"
                      }`}
                    >
                      {saldo} {item.unidade === "m2" ? "m²" : item.unidade}
                    </span>
                  </button>
                </div>
              );
            })}
          </ListaRolavel>
        )}
      </div>

      <div className="rounded-2xl border bg-card p-4">
        <div className="mb-4 grid gap-3 md:grid-cols-3">
          <label>
            <span className="mb-1 block text-xs text-muted-foreground">Cliente cadastrado</span>
            <select
              value={customerId}
              onChange={(e) => {
                setCustomerId(e.target.value);
                if (e.target.value) setClienteAvulso("");
              }}
              className="w-full rounded-lg border bg-background px-3 py-2 text-sm"
            >
              <option value="">Sem cadastro (venda avulsa)</option>
              {clientes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.nome}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span className="mb-1 block text-xs text-muted-foreground">
              Nome avulso {customerId && "(desativado — há cliente selecionado)"}
            </span>
            <input
              value={clienteAvulso}
              onChange={(e) => setClienteAvulso(e.target.value)}
              disabled={!!customerId}
              placeholder="Nome de quem está comprando"
              className="w-full rounded-lg border bg-background px-3 py-2 text-sm disabled:opacity-50"
            />
          </label>
          <label>
            <span className="mb-1 block text-xs text-muted-foreground">Observações</span>
            <input
              value={observacoes}
              onChange={(e) => setObservacoes(e.target.value)}
              placeholder="Prazo, entrega, instalação..."
              className="w-full rounded-lg border bg-background px-3 py-2 text-sm"
            />
          </label>
        </div>

        <div className="overflow-x-auto rounded-xl border">
          <table className="w-full min-w-[1040px] text-sm">
            <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-3 py-3 text-left">Produto</th>
                {/* Era "Área" e sempre foi Categoria — defeito 3 da Revisão 79. */}
                <th className="px-3 py-3 text-left">Categoria</th>
                <th className="px-3 py-3 text-left">Un.</th>
                <th className="px-3 py-3 text-right">Largura (mm)</th>
                <th className="px-3 py-3 text-right">Altura (mm)</th>
                <th className="px-3 py-3 text-right">Qtd</th>
                <th className="px-3 py-3 text-right">Valor</th>
                <th className="px-3 py-3 text-right">Desc.</th>
                <th className="px-3 py-3 text-right">Subtotal</th>
                <th className="px-3 py-3" />
              </tr>
            </thead>
            <tbody>
              {linhas.map((linha, idx) => {
                const c = totais.calc[idx];
                const doEstoque = linha.inventoryItemId !== null;
                return (
                  <tr key={linha.id} className="border-t align-top">
                    <td className="px-2 py-2">
                      <input
                        value={linha.nome}
                        onChange={(e) => atualizar(linha.id, { nome: e.target.value })}
                        placeholder="Produto"
                        className="w-full rounded-md border bg-background px-2 py-1.5"
                      />
                      {doEstoque && (
                        <span className="mt-1 block text-[11px] font-semibold text-emerald-600">
                          do estoque · saldo {linha.saldoDisponivel}
                        </span>
                      )}
                    </td>
                    <td className="px-2 py-2">
                      <input
                        value={linha.categoria}
                        onChange={(e) => atualizar(linha.id, { categoria: e.target.value })}
                        placeholder="Categoria"
                        className="w-full rounded-md border bg-background px-2 py-1.5"
                      />
                    </td>
                    <td className="px-2 py-2">
                      <select
                        value={linha.unidade}
                        onChange={(e) =>
                          atualizar(linha.id, { unidade: e.target.value as SaleUnit })
                        }
                        /* Item do catálogo: a unidade é a do cadastro. Trocar
                           debitaria a grandeza errada e a RPC recusa (22023). */
                        disabled={doEstoque}
                        title={
                          doEstoque
                            ? "A unidade vem do cadastro do item no estoque e não pode ser trocada aqui."
                            : undefined
                        }
                        className="w-full rounded-md border bg-background px-2 py-1.5 disabled:opacity-60"
                      >
                        {UNIDADES.map((u) => (
                          <option key={u.value} value={u.value}>
                            {u.label}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className="px-2 py-2">
                      <input
                        inputMode="decimal"
                        value={linha.largura}
                        onChange={(e) => atualizar(linha.id, { largura: e.target.value })}
                        placeholder={linha.unidade === "m2" ? "obrigatório" : "—"}
                        className="w-24 rounded-md border bg-background px-2 py-1.5 text-right"
                      />
                    </td>
                    <td className="px-2 py-2">
                      <input
                        inputMode="decimal"
                        value={linha.altura}
                        onChange={(e) => atualizar(linha.id, { altura: e.target.value })}
                        placeholder={linha.unidade === "m2" ? "obrigatório" : "—"}
                        className="w-24 rounded-md border bg-background px-2 py-1.5 text-right"
                      />
                    </td>
                    <td className="px-2 py-2">
                      <input
                        inputMode="decimal"
                        value={linha.qtd}
                        onChange={(e) => atualizar(linha.id, { qtd: e.target.value })}
                        placeholder="Digite"
                        className="w-20 rounded-md border bg-background px-2 py-1.5 text-right"
                      />
                    </td>
                    <td className="px-2 py-2">
                      <input
                        inputMode="decimal"
                        value={linha.valorUnit}
                        onChange={(e) => atualizar(linha.id, { valorUnit: e.target.value })}
                        placeholder="Digite"
                        className="w-24 rounded-md border bg-background px-2 py-1.5 text-right"
                      />
                    </td>
                    <td className="px-2 py-2">
                      <input
                        inputMode="decimal"
                        value={linha.desconto}
                        onChange={(e) => atualizar(linha.id, { desconto: e.target.value })}
                        placeholder="Digite"
                        className="w-24 rounded-md border bg-background px-2 py-1.5 text-right"
                      />
                    </td>
                    <td className="px-3 py-2 text-right font-semibold">
                      {c.invalidos.length ? (
                        <span
                          className="text-xs font-semibold text-destructive"
                          title="Use apenas números, com vírgula ou ponto na casa decimal (ex.: 89,90)."
                        >
                          Valor inválido em {c.invalidos.join(", ")}
                        </span>
                      ) : c.faltaMedida ? (
                        <span className="text-xs font-semibold text-destructive">
                          Informe largura e altura
                        </span>
                      ) : (
                        <>
                          {brl(c.subtotal)}
                          {c.excedeSaldo && (
                            <span className="mt-1 block text-[11px] font-semibold text-destructive">
                              pede {Number(c.baixa.toFixed(4))}, há {linha.saldoDisponivel}
                            </span>
                          )}
                        </>
                      )}
                    </td>
                    <td className="px-2 py-2">
                      <button
                        onClick={() => remover(linha.id)}
                        className="rounded p-1.5 text-destructive hover:bg-destructive/10"
                        aria-label="Remover item"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="mt-4 flex flex-wrap justify-between gap-2">
          <button
            onClick={() => setLinhas((list) => [...list, linhaVazia()])}
            className="inline-flex items-center gap-2 rounded-lg border px-4 py-2 text-sm font-semibold hover:bg-accent"
          >
            <Plus className="h-4 w-4" /> Adicionar linha
          </button>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => enviarWhatsApp(clienteSelecionado?.telefone, mensagemCarrinho())}
              disabled={!clienteSelecionado}
              title={
                clienteSelecionado
                  ? `Enviar o resumo para ${clienteSelecionado.nome}`
                  : "Selecione um cliente cadastrado: o WhatsApp precisa de um telefone para enviar."
              }
              className="inline-flex items-center gap-2 rounded-lg bg-green-600 px-4 py-2 text-sm font-semibold text-white hover:bg-green-500 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <MessageCircle className="h-4 w-4" /> Enviar WhatsApp
            </button>
            {/* O botão fica HABILITADO mesmo com linha inválida, de propósito.
                Desabilitar era o primeiro desenho, e o teste da Revisão 87
                mostrou o problema: o clique não fazia nada e a tela não dizia
                POR QUE — o operador ficava adivinhando. Clicando, `montarItens`
                devolve a mensagem exata, nomeando o item e o campo. O aviso
                vermelho abaixo dá o mesmo recado antes mesmo do clique. */}
            <button
              onClick={finalizar}
              disabled={salvando}
              title="Registrar a venda e baixar o estoque"
              className="inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground shadow-glow disabled:cursor-not-allowed disabled:opacity-60"
            >
              {salvando && <Loader2 className="h-4 w-4 animate-spin" />}
              {salvando ? "Registrando…" : "Finalizar venda"}
            </button>
          </div>
        </div>

        {temLinhaInvalida && (
          <p className="mt-3 text-sm font-semibold text-destructive">
            Há {linhasComProblema} {linhasComProblema === 1 ? "linha" : "linhas"} com problema
            (marcadas em vermelho na coluna Subtotal). Corrija antes de finalizar.
          </p>
        )}

        <p className="mt-3 text-xs text-muted-foreground">
          Finalizar registra a venda, <strong>baixa o estoque</strong> dos itens vindos do catálogo
          e gera a nota em PDF (sem valor fiscal). O que está digitado aqui{" "}
          <strong>não está salvo</strong>: o rascunho fica só na memória desta aba e é descartado ao
          recarregar a página.
        </p>
      </div>

      <Dialog
        open={!!fotoPreview}
        onOpenChange={(open) => {
          if (!open) setFotoPreview(null);
        }}
      >
        <DialogContent className="max-w-2xl p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle>{fotoPreview ? `Foto · ${fotoPreview.nome}` : "Foto do item"}</DialogTitle>
          </DialogHeader>
          {fotoPreview && (
            <StorageImage
              src={fotoPreview.src}
              alt={`Imagem de ${fotoPreview.nome}`}
              className="max-h-[70vh] w-full rounded-lg object-contain"
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
