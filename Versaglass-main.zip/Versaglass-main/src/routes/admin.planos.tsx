import { createFileRoute, Link } from "@tanstack/react-router";
import { PLAN_PRICES, PRO_LIMITS } from "@/data/projectLibrary";
import { requireAdmin } from "@/lib/admin-guard";

export const Route = createFileRoute("/admin/planos")({
  // A sessão do Supabase vive em localStorage e o servidor não a enxerga; sem
  // `ssr: false` o guard rodaria no servidor, não acharia sessão alguma e mandaria
  // até o administrador para /auth. Mesmo motivo documentado em `_authenticated.tsx`.
  ssr: false,
  beforeLoad: requireAdmin,
  component: AdminPlanosPage,
});

function AdminPlanosPage() {
  return (
    <div className="min-h-screen bg-background p-6 text-foreground">
      <div className="mx-auto max-w-5xl">
        <div className="mb-5 flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold">Admin • Planos</h1>
            <p className="text-sm text-muted-foreground">
              Controle de acesso: FREE, PRO e PREMIUM.
            </p>
          </div>
          <Link
            to="/admin/modelos"
            className="rounded-lg border border-border px-4 py-2 text-sm font-semibold hover:bg-accent"
          >
            Modelos
          </Link>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <Card
            title="PRO"
            price={PLAN_PRICES.pro}
            items={Object.entries(PRO_LIMITS).map(([k, v]) => `${k}: ${v} modelos`)}
          />
          <Card
            title="PREMIUM"
            price={PLAN_PRICES.premium}
            items={[
              "Todos os modelos",
              "Todas as categorias",
              "DXF/DWG/SVG",
              "Renderização HD",
              "IA",
              "Suporte prioritário",
            ]}
          />
        </div>
      </div>
    </div>
  );
}
function Card({ title, price, items }: any) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <h2 className="font-display text-2xl font-bold">{title}</h2>
      <div className="mt-1 text-2xl font-bold text-gold">
        R$ {price.toFixed(2).replace(".", ",")}/mês
      </div>
      <ul className="mt-4 space-y-1 text-sm text-muted-foreground">
        {items.map((i: string) => (
          <li key={i}>• {i}</li>
        ))}
      </ul>
    </div>
  );
}
