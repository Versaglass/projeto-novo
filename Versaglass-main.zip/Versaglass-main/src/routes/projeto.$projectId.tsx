import { createFileRoute, Link } from "@tanstack/react-router";
import { FileText, ImageDown, Save, Scissors } from "lucide-react";

export const Route = createFileRoute("/projeto/$projectId")({ component: ProjetoPage });

function ProjetoPage() {
  const { projectId } = Route.useParams();
  return (
    <div className="min-h-screen bg-background p-6 text-foreground">
      <div className="mx-auto max-w-5xl rounded-3xl border border-border bg-card p-6">
        <h1 className="font-display text-2xl font-bold">Projeto salvo</h1>
        <p className="text-sm text-muted-foreground">ID: {projectId}</p>
        <div className="mt-5 grid gap-3 md:grid-cols-4">
          <Action icon={<Save />} label="Salvar versão" />
          <Action icon={<FileText />} label="Gerar PDF" />
          <Action icon={<ImageDown />} label="Baixar imagem" />
          <Action icon={<Scissors />} label="Lista de corte" />
        </div>
        <Link
          to="/catalogo"
          className="mt-6 inline-flex rounded-lg bg-gradient-gold px-4 py-2 text-sm font-bold text-gold-foreground"
        >
          Voltar ao catálogo
        </Link>
      </div>
    </div>
  );
}
function Action({ icon, label }: any) {
  return (
    <button className="flex items-center justify-center gap-2 rounded-xl border border-border bg-background px-4 py-3 text-sm font-semibold hover:border-gold/40 hover:bg-gold/10">
      {icon}
      {label}
    </button>
  );
}
