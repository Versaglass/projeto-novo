// =====================================================================
// ⚠️ BLOCO FORA DE USO — "biblioteca bloqueada por assinatura"
//
// Esta tela faz parte de um sistema de assinatura B2C (catálogo de modelos
// premium) que NASCEU NO PRIMEIRO COMMIT do projeto (`a0c7291`, "estado
// inicial recebido") e NUNCA FOI CONECTADO. Está documentado em
// `PLANOS_BIBLIOTECA_ASSINATURA.md`, na raiz do repositório.
//
// Por que "nunca conectado", em fatos (levantamento na Revisão 112):
//
//   • a migration que o documento cita — `20260703030000_subscription_locked_
//     library.sql`, "com tabelas, seeds, funções e RLS" — NÃO EXISTE em
//     `supabase/migrations/`;
//   • as tabelas sobreviveram na baseline (`project_categories`,
//     `project_models`, `plan_model_limits`, `plans`), mas NENHUMA delas tem
//     um único leitor no código, e não há seed em migration alguma;
//   • `user_subscriptions` tem UMA referência em toda a árvore: o `select` de
//     `getUserPlan`. NADA insere. Logo `getUserPlan` devolve sempre "free";
//   • `/planos` e `/upgrade-premium` não têm um `onClick` sequer — não há
//     caminho de upgrade;
//   • `/editor/$modelId` redireciona quando `plan === "free"`, ou seja, para
//     100% dos usuários. A tela do editor é INALCANÇÁVEL hoje;
//   • o bloco é um CIRCUITO FECHADO: `/catalogo`, `/editor/$modelId`,
//     `/planos`, `/upgrade-premium`, `/projeto/$projectId`, `/pdf/$projectId`
//     e as duas telas `/admin/*` só apontam umas para as outras. Nenhuma rota
//     do aplicativo autenticado aponta para dentro dele — nem o menu.
//
// 📌 MANTIDO NO CÓDIGO POR DECISÃO DO RESPONSÁVEL, SEM USO ATIVO.
//    NÃO expandir, NÃO depurar e NÃO usar como referência de padrão até
//    haver decisão de produto. O editor de desenho que funciona é outro:
//    `components/ParametricProjectEditor.tsx` (Projetos › Editar desenho) e
//    `components/engineering/UniversalEngineeringEditor.tsx` (Editor 2D/3D).
// =====================================================================

import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Crown, Lock } from "lucide-react";
import { AvisoBlocoForaDeUso } from "@/components/AvisoBlocoForaDeUso";
import { PLAN_PRICES } from "@/data/projectLibrary";

export const Route = createFileRoute("/planos")({ component: PlanosPage });

function PlanosPage() {
  return (
    <div className="min-h-screen bg-background px-4 py-10 text-foreground">
      <div className="mx-auto max-w-6xl">
        <AvisoBlocoForaDeUso />
        <div className="mb-8 text-center">
          <h1 className="font-display text-4xl font-bold">Planos da Biblioteca VersaGlass</h1>
          <p className="mt-2 text-muted-foreground">
            Venda assinatura mensal com modelos bloqueados em blur e upgrade imediato.
          </p>
        </div>
        <div className="grid gap-5 md:grid-cols-3">
          <Plan
            title="Visitante"
            price="Grátis"
            icon={<Lock />}
            cta="Ver demonstração"
            href="/catalogo"
            items={["2 modelos gratuitos", "Sem edição", "Sem PDF", "Sem download"]}
          />
          <Plan
            title="PRO"
            price={`R$ ${PLAN_PRICES.pro.toFixed(2).replace(".", ",")}/mês`}
            highlight
            cta="Assinar PRO"
            href="/app/minha-assinatura"
            items={[
              "5 portões",
              "10 telhados",
              "5 pergolados",
              "5 coberturas",
              "5 portas metálicas",
              "3 escadas",
              "2 mezaninos",
              "Editar, PDF, imagem, lista de corte e materiais",
            ]}
          />
          <Plan
            title="PREMIUM"
            price={`R$ ${PLAN_PRICES.premium.toFixed(2).replace(".", ",")}/mês`}
            icon={<Crown />}
            cta="Assinar PREMIUM"
            href="/app/minha-assinatura"
            items={[
              "Todos os modelos",
              "Todas as categorias",
              "Galpões e estruturas industriais",
              "Energia solar",
              "DXF/DWG/SVG",
              "Renderização HD",
              "IA de otimização",
              "Suporte prioritário",
            ]}
          />
        </div>
      </div>
    </div>
  );
}

function Plan({ title, price, items, cta, href, highlight, icon }: any) {
  return (
    <div
      className={`rounded-3xl border p-6 ${highlight ? "border-gold bg-gold/10 shadow-glow" : "border-border bg-card"}`}
    >
      <div className="mb-3 flex items-center justify-between">
        <h2 className="font-display text-2xl font-bold">{title}</h2>
        <span className="text-gold">{icon}</span>
      </div>
      <div className="text-3xl font-bold text-gold">{price}</div>
      <ul className="mt-5 space-y-2 text-sm">
        {items.map((i: string) => (
          <li key={i} className="flex gap-2">
            <Check className="h-4 w-4 text-emerald-400" />
            {i}
          </li>
        ))}
      </ul>
      <Link
        to={href}
        className="mt-6 inline-flex w-full items-center justify-center rounded-xl bg-gradient-gold px-4 py-3 text-sm font-bold text-gold-foreground"
      >
        {cta}
      </Link>
    </div>
  );
}
