// =====================================================================
// ⚠️ BLOCO FORA DE USO — "biblioteca bloqueada por assinatura"
//
// Esta tela faz parte de um sistema de assinatura B2C (catálogo de modelos
// premium) que NASCEU NO PRIMEIRO COMMIT do projeto (`a0c7291`, "estado
// inicial recebido") e NUNCA FOI CONECTADO. Está documentado em
// `PLANOS_BIBLIOTECA_ASSINATURA.md`, na raiz do repositório.
//
// Por que "nunca conectado", em fatos (levantamento na Revisão 112):
//
//   • a migration que o documento cita — `20260703030000_subscription_locked_
//     library.sql`, "com tabelas, seeds, funções e RLS" — NÃO EXISTE em
//     `supabase/migrations/`;
//   • as tabelas sobreviveram na baseline (`project_categories`,
//     `project_models`, `plan_model_limits`, `plans`), mas NENHUMA delas tem
//     um único leitor no código, e não há seed em migration alguma;
//   • `user_subscriptions` tem UMA referência em toda a árvore: o `select` de
//     `getUserPlan`. NADA insere. Logo `getUserPlan` devolve sempre "free";
//   • `/planos` e `/upgrade-premium` não têm um `onClick` sequer — não há
//     caminho de upgrade;
//   • `/editor/$modelId` redireciona quando `plan === "free"`, ou seja, para
//     100% dos usuários. A tela do editor é INALCANÇÁVEL hoje;
//   • o bloco é um CIRCUITO FECHADO: `/catalogo`, `/editor/$modelId`,
//     `/planos`, `/upgrade-premium`, `/projeto/$projectId`, `/pdf/$projectId`
//     e as duas telas `/admin/*` só apontam umas para as outras. Nenhuma rota
//     do aplicativo autenticado aponta para dentro dele — nem o menu.
//
// 📌 MANTIDO NO CÓDIGO POR DECISÃO DO RESPONSÁVEL, SEM USO ATIVO.
//    NÃO expandir, NÃO depurar e NÃO usar como referência de padrão até
//    haver decisão de produto. O editor de desenho que funciona é outro:
//    `components/ParametricProjectEditor.tsx` (Projetos › Editar desenho) e
//    `components/engineering/UniversalEngineeringEditor.tsx` (Editor 2D/3D).
// =====================================================================

import { createFileRoute, Link } from "@tanstack/react-router";
import { Crown, FileType, Sparkles, Zap } from "lucide-react";
import { AvisoBlocoForaDeUso } from "@/components/AvisoBlocoForaDeUso";
import { PLAN_PRICES } from "@/data/projectLibrary";

export const Route = createFileRoute("/upgrade-premium")({ component: UpgradePremiumPage });

function UpgradePremiumPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <div className="max-w-2xl rounded-3xl border border-gold/40 bg-card p-8 text-center shadow-glow">
        <AvisoBlocoForaDeUso />
        <Crown className="mx-auto h-14 w-14 text-gold" />
        <h1 className="mt-4 font-display text-3xl font-bold">Desbloqueie o PREMIUM</h1>
        <p className="mt-2 text-muted-foreground">
          Seu PRO já libera edição, PDF, imagem, lista de corte e materiais. O PREMIUM libera toda a
          biblioteca e recursos avançados.
        </p>
        <div className="my-6 grid gap-3 text-left md:grid-cols-3">
          <Box icon={<FileType />} text="DXF, DWG e SVG" />
          <Box icon={<Zap />} text="Renderização HD" />
          <Box icon={<Sparkles />} text="IA de otimização" />
        </div>
        <div className="text-3xl font-bold text-gold">
          R$ {PLAN_PRICES.premium.toFixed(2).replace(".", ",")}/mês
        </div>
        <div className="mt-6 flex justify-center gap-2">
          <Link
            to="/app/minha-assinatura"
            className="rounded-xl bg-gradient-gold px-5 py-3 text-sm font-bold text-gold-foreground"
          >
            Fazer upgrade
          </Link>
          <Link
            to="/catalogo"
            className="rounded-xl border border-border px-5 py-3 text-sm font-bold hover:bg-accent"
          >
            Voltar ao catálogo
          </Link>
        </div>
      </div>
    </div>
  );
}
function Box({ icon, text }: any) {
  return (
    <div className="rounded-2xl border border-border bg-background p-4">
      <span className="text-gold">{icon}</span>
      <div className="mt-2 text-sm font-semibold">{text}</div>
    </div>
  );
}
