import { createFileRoute, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { AuthPage } from "@/components/auth/AuthPage";

// Rota raiz — ENTRADA PÚBLICA do sistema.
//
// Antes, "/" servia `HomeEnterprise`: uma dashboard DEMONSTRATIVA com menu
// lateral próprio, módulos (Vidraçaria/Serralheria/Marcenaria/Marmoraria),
// métricas, gráfico e plano "Premium" totalmente hardcoded, que só depois da
// montagem chamava `navigate("/auth")` num `useEffect` — por isso o conteúdo
// fictício chegava a piscar. O componente e os dados fictícios foram removidos.
//
// Agora o usuário SEM sessão vê a autenticação já em "/", sem o salto
// intermediário "/" → "/auth" que causava o atraso visual. O usuário COM sessão
// nem chega a renderizar: o `beforeLoad` o manda para "/app".
//
// A verificação usa o MESMO helper do restante do app (`supabase.auth.getUser()`,
// igual ao `beforeLoad` de `_authenticated` e ao `requireAdmin`) — não há segunda
// implementação de leitura de sessão. E o formulário é o MESMO componente de
// "/auth" (`AuthPage`), não uma cópia.
//
// `ssr: false` é essencial aqui: a sessão do Supabase vive em localStorage e o
// servidor não a enxerga. Com SSR, o servidor renderizaria o formulário de login
// para todo mundo — inclusive para quem já está logado, que veria o login piscar
// antes de ir para "/app". Sem SSR, a rota decide no cliente e só então pinta:
// ou redireciona, ou mostra a autenticação. Nunca as duas coisas.
export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Vidro & Metal Mestre — Entrar" },
      {
        name: "description",
        content:
          "Acesse a plataforma de gestão para vidraçaria, serralheria, marcenaria e marmoraria.",
      },
    ],
  }),
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    // Com sessão → área autenticada. Sem sessão → segue e renderiza AuthPage
    // aqui mesmo, sem navegação intermediária.
    if (!error && data.user) throw redirect({ to: "/app" });
  },
  component: AuthPage,
});
