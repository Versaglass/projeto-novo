import { createFileRoute, Link } from "@tanstack/react-router";
import { PROJECT_CATEGORIES, PROJECT_MODELS } from "@/data/projectLibrary";
import { requireAdmin } from "@/lib/admin-guard";

export const Route = createFileRoute("/admin/modelos")({
  // Ver nota em `admin.planos.tsx`: o guard precisa rodar no cliente, onde a
  // sessão do Supabase existe.
  ssr: false,
  beforeLoad: requireAdmin,
  component: AdminModelosPage,
});

function AdminModelosPage() {
  return (
    <div className="min-h-screen bg-background p-6 text-foreground">
      <div className="mx-auto max-w-7xl">
        <div className="mb-5 flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold">Admin • Modelos</h1>
            <p className="text-sm text-muted-foreground">
              Cadastro e organização da biblioteca bloqueada por assinatura.
            </p>
          </div>
          <Link
            to="/admin/planos"
            className="rounded-lg border border-border px-4 py-2 text-sm font-semibold hover:bg-accent"
          >
            Planos
          </Link>
        </div>
        <div className="overflow-hidden rounded-2xl border border-border bg-card">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-left">
              <tr>
                <th className="p-3">Modelo</th>
                <th className="p-3">Categoria</th>
                <th className="p-3">Preview grátis</th>
                <th className="p-3">Premium</th>
              </tr>
            </thead>
            <tbody>
              {PROJECT_MODELS.map((m) => (
                <tr key={m.id} className="border-t border-border">
                  <td className="p-3 font-semibold">{m.title}</td>
                  <td className="p-3 text-muted-foreground">
                    {PROJECT_CATEGORIES.find((c) => c.slug === m.categorySlug)?.name}
                  </td>
                  <td className="p-3">{m.freePreview ? "Sim" : "Não"}</td>
                  <td className="p-3">{m.isPremium ? "Sim" : "Não"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
