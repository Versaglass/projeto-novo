import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, CheckCircle2, Mail, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { mensagemDeErroDeAuth } from "@/lib/auth-error-message";
import {
  requestSecurityCode,
  verifySecurityCode,
  setSecurePassword,
  validateStrongPassword,
} from "@/lib/access-security";

export const Route = createFileRoute("/forgot-password-2fa")({ component: ForgotPassword2FAPage });

type Step = "request" | "verify" | "reset" | "done";

/**
 * Recuperação de senha — **somente e-mail**.
 *
 * Os cartões "Celular" e "E-mail + celular" saíram na Rev. 244: em produção o
 * canal SMS do GoTrue está desligado (`phone: false`, Twilio `enabled = false`
 * no `config.toml`), então aquelas opções eram fachada. O motor
 * `requestSecurityCode` / `verifySecurityCode` com `channel: "phone"` permanece
 * em `access-security.ts` (ainda usado por `/first-password`); só a UI desta
 * rota deixou de oferecer o caminho.
 */
function ForgotPassword2FAPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>("request");
  const [email, setEmail] = useState("");
  const [emailCode, setEmailCode] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);

  async function requestCode() {
    setLoading(true);
    try {
      await requestSecurityCode({ channel: "email", flow: "password_recovery", email });
      setStep("verify");
      toast.success("Código enviado. Verifique seu e-mail.");
    } catch (e: unknown) {
      toast.error(
        mensagemDeErroDeAuth(
          "recuperacao:enviar-codigo",
          e,
          "Não foi possível enviar o código. Tente novamente em instantes.",
        ),
      );
    } finally {
      setLoading(false);
    }
  }

  async function verifyCode() {
    setLoading(true);
    try {
      await verifySecurityCode({
        channel: "email",
        flow: "password_recovery",
        email,
        token: emailCode,
      });
      setStep("reset");
      toast.success("Código validado. Crie sua nova senha.");
    } catch (e: unknown) {
      toast.error(
        mensagemDeErroDeAuth(
          "recuperacao:validar-codigo",
          e,
          "Código inválido ou expirado. Solicite um novo e tente de novo.",
        ),
      );
    } finally {
      setLoading(false);
    }
  }

  async function saveNewPassword() {
    if (password !== confirmPassword) return toast.error("As senhas não conferem.");
    const strength = validateStrongPassword(password);
    if (!strength.valid)
      return toast.error(`Senha fraca. Adicione: ${strength.missing.join(", ")}.`);
    setLoading(true);
    try {
      await setSecurePassword(password);
      setStep("done");
      toast.success("Senha alterada com segurança.");
    } catch (e: unknown) {
      toast.error(
        mensagemDeErroDeAuth(
          "recuperacao:salvar-senha",
          e,
          "Não foi possível alterar a senha. Tente novamente em instantes.",
        ),
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#050b14] px-4 py-8 text-white">
      <div className="mx-auto max-w-3xl">
        <Link
          to="/auth"
          className="mb-6 inline-flex items-center gap-2 text-sm text-slate-300 hover:text-white"
        >
          <ArrowLeft className="h-4 w-4" /> Voltar ao login
        </Link>
        <div className="rounded-[2rem] border border-white/10 bg-white/[0.06] p-6 shadow-2xl backdrop-blur-xl md:p-9">
          <div className="mb-8 flex items-start gap-4">
            <div className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600">
              <ShieldCheck className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl font-black">Recuperação segura de senha</h1>
              <p className="mt-2 text-slate-300">
                Enviaremos um código para o e-mail cadastrado. Confirme o código e crie uma nova
                senha.
              </p>
            </div>
          </div>

          {step === "request" && (
            <div className="space-y-5">
              <div className="flex items-center gap-3 rounded-2xl border border-blue-400 bg-blue-500/20 p-4">
                <Mail className="h-5 w-5 shrink-0 text-blue-300" />
                <b>Recuperação por e-mail</b>
              </div>
              <Field
                label="E-mail cadastrado"
                value={email}
                onChange={setEmail}
                placeholder="seu@email.com"
              />
              <button
                disabled={loading}
                onClick={requestCode}
                className="h-14 w-full rounded-2xl bg-gradient-to-r from-blue-500 to-purple-500 font-black disabled:opacity-50"
              >
                {loading ? "Enviando..." : "Enviar código"}
              </button>
            </div>
          )}

          {step === "verify" && (
            <div className="space-y-5">
              <div className="rounded-2xl border border-blue-500/20 bg-blue-500/10 p-4 text-blue-100">
                Confirme o código recebido por <b>e-mail</b>.
              </div>
              <Field
                label="Código do e-mail"
                value={emailCode}
                onChange={setEmailCode}
                placeholder="Digite o código"
              />
              <button
                disabled={loading}
                onClick={verifyCode}
                className="h-14 w-full rounded-2xl bg-gradient-to-r from-blue-500 to-purple-500 font-black disabled:opacity-50"
              >
                {loading ? "Validando..." : "Validar código"}
              </button>
            </div>
          )}

          {step === "reset" && (
            <div className="space-y-5">
              <Field
                type="password"
                label="Nova senha"
                value={password}
                onChange={setPassword}
                placeholder="Crie uma senha forte"
              />
              <Field
                type="password"
                label="Confirmar nova senha"
                value={confirmPassword}
                onChange={setConfirmPassword}
                placeholder="Repita a nova senha"
              />
              <div className="rounded-2xl border border-white/10 bg-black/20 p-4 text-sm text-slate-300">
                A senha precisa ter 8+ caracteres, maiúscula, minúscula, número e símbolo.
              </div>
              <button
                disabled={loading}
                onClick={saveNewPassword}
                className="h-14 w-full rounded-2xl bg-gradient-to-r from-emerald-500 to-blue-500 font-black disabled:opacity-50"
              >
                {loading ? "Salvando..." : "Salvar nova senha"}
              </button>
            </div>
          )}

          {step === "done" && (
            <div className="text-center">
              <CheckCircle2 className="mx-auto h-16 w-16 text-emerald-400" />
              <h2 className="mt-4 text-2xl font-black">Senha alterada</h2>
              <p className="mt-2 text-slate-300">
                Agora você pode entrar novamente com sua nova senha.
              </p>
              <button
                onClick={() => navigate({ to: "/auth" })}
                className="mt-6 h-14 w-full rounded-2xl bg-blue-600 font-black"
              >
                Ir para login
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  helper,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  helper?: string;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-semibold text-slate-200">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="h-14 w-full rounded-2xl border border-white/10 bg-[#0b1628] px-4 outline-none focus:border-blue-400"
      />
      {helper && <span className="mt-1 block text-xs text-slate-400">{helper}</span>}
    </label>
  );
}
