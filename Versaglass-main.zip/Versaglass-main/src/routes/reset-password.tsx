import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Eye, EyeOff, Hammer, KeyRound, Loader2, TriangleAlert, UserPlus } from "lucide-react";

export const Route = createFileRoute("/reset-password")({
  component: ResetPasswordPage,
});

// Esta rota atende DOIS links do Supabase que caem no mesmo lugar:
//   · recuperação de senha  (type=recovery)  — usuário já existente;
//   · convite de vendedor   (type=invite)    — conta criada pela Edge Function
//     invite-company-seller, ainda SEM senha.
// O que muda entre eles é só o texto: em ambos o GoTrue já validou o token e
// devolveu uma sessão; o trabalho da página é a mesma chamada updateUser.
//
// O QUE ESTA PÁGINA NÃO FAZ, DE PROPÓSITO
//   · não lê papel, empresa nem membership da URL — nada vindo do link é fonte
//     de autorização. O papel EMPRESARIAL mora só em public.company_members;
//   · não cria empresa, não cria conta, não altera membership alguma. A única
//     escrita é a senha do próprio usuário, via sessão dele;
//   · não usa service role (não existe no navegador) e não persiste token à
//     mão: quem guarda a sessão é o supabase-js, como em todo o resto do app;
//   · não imprime a URL, o hash nem qualquer token em log.

const MIN_SENHA = 6;
// Mesmo teto do schema de cadastro (`z.string().min(6).max(72)` em AuthPage) —
// é o limite do bcrypt e o GoTrue recusa acima disso.
const MAX_SENHA = 72;

type Fase = "validando" | "pronto" | "erro";
type Origem = "invite" | "recovery";

/** Lê hash e query ANTES de tocar no supabase-js. */
function lerParametrosDaUrl() {
  if (typeof window === "undefined")
    return { hash: new URLSearchParams(), query: new URLSearchParams() };
  return {
    hash: new URLSearchParams(window.location.hash.replace(/^#/, "")),
    query: new URLSearchParams(window.location.search),
  };
}

function mensagemDeErroDoLink(codigo: string | null, descricao: string | null): string {
  // `otp_expired` cobre tanto expiração quanto link já consumido — o GoTrue
  // invalida o token no primeiro uso e devolve o mesmo código nos dois casos.
  if (codigo === "otp_expired" || /expired/i.test(descricao ?? "")) {
    return "Este link expirou ou já foi utilizado. Peça um novo convite ao responsável pela empresa.";
  }
  if (codigo === "access_denied") {
    return "Este link não é mais válido. Peça um novo convite ao responsável pela empresa.";
  }
  return "Não foi possível validar este link. Peça um novo convite ao responsável pela empresa.";
}

function ResetPasswordPage() {
  const navigate = useNavigate();
  // Capturado no inicializador de estado: roda no render, antes de qualquer
  // efeito e antes do primeiro acesso ao `supabase` (que é um Proxy preguiçoso
  // — só então o cliente é criado e limpa o hash da barra de endereço).
  const [params] = useState(lerParametrosDaUrl);
  const [fase, setFase] = useState<Fase>("validando");
  const [erro, setErro] = useState<string | null>(null);
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [salvando, setSalvando] = useState(false);
  const resolvidoRef = useRef(false);

  const origem: Origem =
    params.hash.get("type") === "invite" || params.query.get("type") === "invite"
      ? "invite"
      : "recovery";

  useEffect(() => {
    let vivo = true;
    const resolver = (proximo: Fase, msg?: string) => {
      if (!vivo || resolvidoRef.current) return;
      resolvidoRef.current = true;
      if (msg) setErro(msg);
      setFase(proximo);
    };

    // 1. O GoTrue devolve a falha no PRÓPRIO redirect, sem sessão: link expirado,
    //    já usado ou revogado chegam como `error`/`error_code` no hash ou na query.
    const errCode = params.hash.get("error_code") ?? params.query.get("error_code");
    const errDesc = params.hash.get("error_description") ?? params.query.get("error_description");
    const err = params.hash.get("error") ?? params.query.get("error");
    if (err || errCode) {
      resolver("erro", mensagemDeErroDoLink(errCode, errDesc));
      return;
    }

    // 2. Sessão. O caminho normal deste projeto é o token no HASH: o cliente usa
    //    o flowType padrão (implicit) e `detectSessionInUrl` ligado, então o
    //    supabase-js consome `#access_token` sozinho e emite SIGNED_IN (convite)
    //    ou PASSWORD_RECOVERY (recuperação). O ramo PKCE abaixo existe para o
    //    caso de o projeto passar a emitir `?code=` — sem ele a página ficaria
    //    presa em "validando" para sempre.
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((evento, sessao) => {
      if (
        sessao &&
        (evento === "SIGNED_IN" || evento === "PASSWORD_RECOVERY" || evento === "INITIAL_SESSION")
      ) {
        resolver("pronto");
      }
    });

    (async () => {
      const code = params.query.get("code");
      if (code) {
        const { error } = await supabase.auth.exchangeCodeForSession(code);
        if (error) {
          resolver("erro", mensagemDeErroDoLink(null, error.message));
          return;
        }
        resolver("pronto");
        return;
      }
      const { data } = await supabase.auth.getSession();
      if (data.session) resolver("pronto");
    })();

    // 3. Sem sessão e sem erro explícito: o link não trouxe token nenhum (URL
    //    digitada à mão, hash perdido por um redirect intermediário). Sem este
    //    limite a página exibiria "Validando…" indefinidamente.
    const limite = setTimeout(() => {
      resolver(
        "erro",
        "Não encontramos um link válido nesta página. Abra o link do e-mail novamente ou peça um novo convite.",
      );
    }, 8000);

    return () => {
      vivo = false;
      clearTimeout(limite);
      subscription.unsubscribe();
    };
  }, [params]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (salvando) return;
    if (password.length < MIN_SENHA) {
      toast.error(`Senha deve ter ao menos ${MIN_SENHA} caracteres`);
      return;
    }
    if (password.length > MAX_SENHA) {
      toast.error(`Senha deve ter no máximo ${MAX_SENHA} caracteres`);
      return;
    }

    setSalvando(true);
    const { error } = await supabase.auth.updateUser({ password });
    if (error) {
      setSalvando(false);
      const m = error.message ?? "";
      if (/session|jwt|expired/i.test(m)) {
        setFase("erro");
        setErro("Sua sessão de convite expirou antes de salvar. Abra o link do e-mail novamente.");
      } else if (/weak|password/i.test(m)) {
        toast.error("Senha muito fraca. Escolha outra.");
      } else {
        toast.error("Não foi possível salvar a senha. Tente novamente.");
      }
      return;
    }

    // Autenticação atualizada a partir do servidor (a sessão em memória mudou
    // com a troca de senha). Daqui sai o uid usado logo abaixo.
    const { data: userData } = await supabase.auth.getUser();
    const uid = userData?.user?.id;

    // Empresa ativa. O CompanyProvider só monta dentro de `_authenticated`, ou
    // seja, depois do navigate — então aqui apenas LEMOS as memberships (RLS
    // devolve só as do próprio usuário) e deixamos a preferência pronta na
    // mesma chave que o provider lê. Ele revalida esse id contra as memberships
    // antes de usar, então nada é assumido: se o vínculo sumir, ele descarta.
    // Nenhuma escrita em company_members acontece aqui.
    if (uid) {
      const { data: membros } = await supabase
        .from("company_members")
        .select("company_id")
        .eq("user_id", uid)
        .eq("status", "active")
        .limit(1);
      const companyId = membros?.[0]?.company_id as string | undefined;
      if (companyId && typeof localStorage !== "undefined") {
        localStorage.setItem(`vmm_active_company_id:${uid}`, companyId);
      }
    }

    setSalvando(false);
    toast.success(
      origem === "invite" ? "Senha criada! Bem-vindo." : "Senha redefinida com sucesso!",
    );
    // Com membership ativa o gate do AppShell mantém o usuário em /app; sem
    // nenhuma, é ele quem decide levar ao onboarding. Esta página não decide
    // isso — não é dela a regra.
    navigate({ to: "/app" });
  };

  const convite = origem === "invite";

  return (
    <div className="min-h-screen bg-[#0a0a14] grid place-items-center p-4">
      <div className="w-full max-w-md rounded-3xl border border-white/10 bg-white/[0.04] p-8 backdrop-blur-2xl">
        <Link to="/" className="mb-6 flex items-center gap-2">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-gold shadow-glow">
            <Hammer className="h-5 w-5 text-gold-foreground" />
          </div>
          <span className="font-display text-lg font-bold text-white">VersaGlass</span>
        </Link>

        <div className="mb-1 inline-flex items-center gap-2 rounded-full bg-gold/10 px-3 py-1 text-xs font-medium text-gold">
          {convite ? <UserPlus className="h-3 w-3" /> : <KeyRound className="h-3 w-3" />}
          {convite ? "Convite da empresa" : "Redefinir senha"}
        </div>

        <h1 className="mt-2 font-display text-2xl font-bold text-white">
          {convite ? "Crie sua senha de acesso" : "Defina sua nova senha"}
        </h1>

        {fase === "erro" ? (
          <div className="mt-4 flex items-start gap-3 rounded-xl border border-red-500/30 bg-red-500/10 p-4">
            <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0 text-red-300" />
            <p className="text-sm text-red-200">{erro}</p>
          </div>
        ) : (
          <>
            <p className="mt-1 text-sm text-white/60">
              {fase === "validando"
                ? convite
                  ? "Validando seu convite…"
                  : "Validando link de recuperação…"
                : `Escolha uma senha de ${MIN_SENHA} a ${MAX_SENHA} caracteres.`}
            </p>

            {fase === "validando" && (
              <p className="mt-5 flex items-center gap-2 text-sm text-white/50">
                <Loader2 className="h-4 w-4 animate-spin" /> Aguarde
              </p>
            )}

            {fase === "pronto" && (
              <form onSubmit={submit} className="mt-6 space-y-3">
                <label className="block">
                  <span className="mb-1.5 block text-xs font-medium text-white/60">
                    {convite ? "Sua senha" : "Nova senha"}
                  </span>
                  <div className="relative">
                    <input
                      type={show ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      minLength={MIN_SENHA}
                      maxLength={MAX_SENHA}
                      autoComplete="new-password"
                      className="w-full rounded-xl border border-white/15 bg-white/[0.05] px-3.5 py-3 pr-11 text-sm text-white outline-none focus:border-gold/50 focus:ring-2 focus:ring-gold/20"
                    />
                    <button
                      type="button"
                      onClick={() => setShow((s) => !s)}
                      aria-label={show ? "Ocultar senha" : "Mostrar senha"}
                      className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-2 text-white/50 hover:bg-white/10 hover:text-gold"
                    >
                      {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </label>
                <button
                  type="submit"
                  disabled={salvando}
                  className="w-full rounded-xl bg-gradient-gold px-4 py-3 text-sm font-semibold text-gold-foreground shadow-glow hover:opacity-95 disabled:opacity-50"
                >
                  {salvando ? "Salvando…" : convite ? "Criar senha e entrar" : "Salvar nova senha"}
                </button>
              </form>
            )}
          </>
        )}

        <Link to="/auth" className="mt-5 block text-center text-sm text-white/60 hover:text-gold">
          ← Voltar para o login
        </Link>
      </div>
    </div>
  );
}
