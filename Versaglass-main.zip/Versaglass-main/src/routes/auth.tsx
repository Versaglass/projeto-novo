import { createFileRoute } from "@tanstack/react-router";
import { AuthPage } from "@/components/auth/AuthPage";

// "/auth" — rota de COMPATIBILIDADE. A entrada principal do sistema passou a ser
// "/", mas esta rota continua existindo e renderizando EXATAMENTE o mesmo
// componente, sem duplicar código.
//
// Por que alias e não `redirect` para "/": o retorno do provedor OAuth aponta
// para `origin + "/auth"` e o Supabase entrega os tokens no FRAGMENTO da URL
// (`#access_token=...`), que um redirect de rota não carrega. Além disso,
// `_authenticated` já encaminha para cá com `?redirect=<rota pedida>` e links
// existentes (first-password, forgot-password-2fa, reset-password) apontam para
// "/auth". Mantendo o alias, nenhum desses fluxos muda e nenhum parâmetro se
// perde — o próprio `AuthPage` lê `redirect` da location atual.
export const Route = createFileRoute("/auth")({
  component: AuthPage,
});
