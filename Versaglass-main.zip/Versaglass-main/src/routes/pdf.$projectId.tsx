import { createFileRoute, Link } from "@tanstack/react-router";
import { Download, FileText } from "lucide-react";

export const Route = createFileRoute("/pdf/$projectId")({ component: PdfPage });

function PdfPage() {
  const { projectId } = Route.useParams();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4 text-foreground">
      <div className="max-w-lg rounded-3xl border border-border bg-card p-8 text-center">
        <FileText className="mx-auto h-12 w-12 text-gold" />
        <h1 className="mt-4 font-display text-2xl font-bold">PDF do Projeto</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          PDF liberado para todos os assinantes PRO e PREMIUM. Projeto: {projectId}
        </p>
        <button className="mt-5 inline-flex items-center gap-2 rounded-xl bg-gradient-gold px-5 py-3 text-sm font-bold text-gold-foreground">
          <Download className="h-4 w-4" /> Baixar PDF
        </button>
        <div>
          <Link to="/catalogo" className="mt-3 inline-block text-sm text-gold hover:underline">
            Voltar ao catálogo
          </Link>
        </div>
      </div>
    </div>
  );
}
