import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, KeyRound, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { mensagemDeErroDeAuth } from "@/lib/auth-error-message";
import {
  requestSecurityCode,
  verifySecurityCode,
  setSecurePassword,
  validateStrongPassword,
  type SecurityChannel,
} from "@/lib/access-security";

export const Route = createFileRoute("/first-password")({ component: FirstPasswordPage });

function FirstPasswordPage() {
  const navigate = useNavigate();
  const [channel, setChannel] = useState<SecurityChannel>("email");
  const [step, setStep] = useState<"request" | "verify" | "password" | "done">("request");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);

  async function requestCode() {
    setLoading(true);
    try {
      await requestSecurityCode({ channel, flow: "first_password", email, phone });
      setStep("verify");
      toast.success("Código enviado para criar a primeira senha.");
    } catch (e: unknown) {
      toast.error(
        mensagemDeErroDeAuth(
          "primeira-senha:enviar-codigo",
          e,
          "Não foi possível enviar o código. Tente novamente em instantes.",
        ),
      );
    } finally {
      setLoading(false);
    }
  }

  async function verifyCode() {
    setLoading(true);
    try {
      await verifySecurityCode({ channel, flow: "first_password", email, phone, token: code });
      setStep("password");
      toast.success("Código validado. Crie sua primeira senha.");
    } catch (e: unknown) {
      toast.error(
        mensagemDeErroDeAuth(
          "primeira-senha:validar-codigo",
          e,
          "Código inválido. Confira os dígitos ou solicite um novo.",
        ),
      );
    } finally {
      setLoading(false);
    }
  }

  async function savePassword() {
    if (password !== confirmPassword) return toast.error("As senhas não conferem.");
    const strength = validateStrongPassword(password);
    if (!strength.valid)
      return toast.error(`Senha fraca. Adicione: ${strength.missing.join(", ")}.`);
    setLoading(true);
    try {
      await setSecurePassword(password);
      setStep("done");
      toast.success("Primeira senha criada com segurança.");
    } catch (e: unknown) {
      toast.error(
        mensagemDeErroDeAuth(
          "primeira-senha:salvar",
          e,
          "Não foi possível criar a senha. Tente novamente em instantes.",
        ),
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#050b14] px-4 py-8 text-white">
      <div className="mx-auto max-w-2xl">
        <Link
          to="/auth"
          className="mb-6 inline-flex items-center gap-2 text-sm text-slate-300 hover:text-white"
        >
          <ArrowLeft className="h-4 w-4" /> Voltar
        </Link>
        <div className="rounded-[2rem] border border-white/10 bg-white/[0.06] p-6 shadow-2xl backdrop-blur-xl md:p-9">
          <div className="mb-8 flex items-start gap-4">
            <div className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-emerald-500 to-blue-600">
              <KeyRound className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl font-black">Criar primeira senha</h1>
              <p className="mt-2 text-slate-300">
                Use e-mail ou celular cadastrado para validar sua identidade antes de definir a
                senha.
              </p>
            </div>
          </div>
          {step === "request" && (
            <div className="space-y-5">
              <div className="grid gap-3 md:grid-cols-2">
                <button
                  onClick={() => setChannel("email")}
                  className={`rounded-2xl border p-4 text-left ${channel === "email" ? "border-blue-400 bg-blue-500/20" : "border-white/10 bg-white/[0.04]"}`}
                >
                  E-mail
                </button>
                <button
                  onClick={() => setChannel("phone")}
                  className={`rounded-2xl border p-4 text-left ${channel === "phone" ? "border-blue-400 bg-blue-500/20" : "border-white/10 bg-white/[0.04]"}`}
                >
                  Celular
                </button>
              </div>
              {channel === "email" ? (
                <Field label="E-mail" value={email} onChange={setEmail} />
              ) : (
                <Field label="Celular" value={phone} onChange={setPhone} />
              )}
              <button
                disabled={loading}
                onClick={requestCode}
                className="h-14 w-full rounded-2xl bg-blue-600 font-black disabled:opacity-50"
              >
                Enviar código
              </button>
            </div>
          )}
          {step === "verify" && (
            <div className="space-y-5">
              <Field label="Código recebido" value={code} onChange={setCode} />
              <button
                disabled={loading}
                onClick={verifyCode}
                className="h-14 w-full rounded-2xl bg-blue-600 font-black disabled:opacity-50"
              >
                Validar código
              </button>
            </div>
          )}
          {step === "password" && (
            <div className="space-y-5">
              <Field type="password" label="Senha" value={password} onChange={setPassword} />
              <Field
                type="password"
                label="Confirmar senha"
                value={confirmPassword}
                onChange={setConfirmPassword}
              />
              <button
                disabled={loading}
                onClick={savePassword}
                className="h-14 w-full rounded-2xl bg-emerald-600 font-black disabled:opacity-50"
              >
                Criar senha
              </button>
            </div>
          )}
          {step === "done" && (
            <div className="text-center">
              <ShieldCheck className="mx-auto h-16 w-16 text-emerald-400" />
              <h2 className="mt-4 text-2xl font-black">Senha criada</h2>
              <p className="mt-2 text-slate-300">Agora você pode entrar no sistema.</p>
              <button
                onClick={() => navigate({ to: "/auth" })}
                className="mt-6 h-14 w-full rounded-2xl bg-blue-600 font-black"
              >
                Ir para login
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-semibold text-slate-200">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-14 w-full rounded-2xl border border-white/10 bg-[#0b1628] px-4 outline-none focus:border-blue-400"
      />
    </label>
  );
}
