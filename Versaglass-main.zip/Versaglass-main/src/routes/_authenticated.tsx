import { createFileRoute, redirect } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { CompanyProvider } from "@/contexts/company-context";
import { enforceFinePermissionAccess } from "@/lib/fine-permissions";
import { enforceAccountActive } from "@/lib/account-active";
import { resolveAuthenticatedUser } from "@/lib/auth-session-snapshot";

export const Route = createFileRoute("/_authenticated")({
  // Sessão do Supabase vive em localStorage; o servidor não a enxerga.
  // Renderizar este layout só no cliente evita loop de redirect em hard-refresh.
  ssr: false,
  beforeLoad: async ({ location }) => {
    // getSession local + getUser só se a validação server-side expirou (TTL 60s).
    // Preload `intent` e clique real compartilham cache/inflight.
    const user = await resolveAuthenticatedUser();
    if (!user) {
      throw redirect({ to: "/auth", search: { redirect: location.href } });
    }
    // Conta desativada (`profiles.ativo = false`): encerra sessão e vai para /auth.
    await enforceAccountActive(user.id);
    // Permissões finas (`profiles.permissions`) — menu não basta.
    // Super Admin (`isPlatformAdmin`) bypassa via `resolvesFinePermission`.
    // `ssr: false`: lemos a query da URL do browser (search tipado do pai é objeto).
    const search = typeof window !== "undefined" ? window.location.search.replace(/^\?/, "") : "";
    await enforceFinePermissionAccess(location.pathname, search, user.id);
    return { user };
  },
  // Contexto de empresa carregado uma vez para toda a árvore autenticada
  // (evita reconsultar memberships em cada página).
  component: () => (
    <CompanyProvider>
      <AppShell />
    </CompanyProvider>
  ),
});
