import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { AuthProvider } from "@/contexts/auth-context";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect } from "react";
import { Toaster } from "sonner";
import { ThemeProvider } from "@/components/theme-provider";
import { startFrontendMonitoring } from "@/lib/monitoring";

import appCss from "../styles.css?url";
import { supabase } from "@/integrations/supabase/client";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-7xl font-bold text-primary">404</h1>
        <h2 className="mt-4 text-xl font-semibold">Página não encontrada</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          A página que você procura não existe ou foi movida.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90"
          >
            Voltar ao início
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold">Algo deu errado</h1>
        <p className="mt-2 text-sm text-muted-foreground">{error.message}</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90"
          >
            Tentar novamente
          </button>
          <a
            href="/"
            className="rounded-md border border-input bg-background px-4 py-2 text-sm font-medium hover:bg-accent"
          >
            Início
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      {
        title: "VersaGlass Enterprise — Gestão para Vidraçarias e Esquadrias",
      },
      {
        name: "description",
        content:
          "Sistema completo para vidraçarias e empresas de esquadrias. Gerencie projetos, orçamentos, estoque, vendas e financeiro em um só lugar.",
      },
      {
        property: "og:title",
        content: "VersaGlass Enterprise — Gestão para Vidraçarias e Esquadrias",
      },
      {
        name: "twitter:title",
        content: "VersaGlass Enterprise — Gestão para Vidraçarias e Esquadrias",
      },
      {
        property: "og:description",
        content:
          "Sistema completo para vidraçarias e empresas de esquadrias. Gerencie projetos, orçamentos, estoque, vendas e financeiro em um só lugar.",
      },
      {
        name: "twitter:description",
        content:
          "Sistema completo para vidraçarias e empresas de esquadrias. Gerencie projetos, orçamentos, estoque, vendas e financeiro em um só lugar.",
      },
      {
        property: "og:image",
        content:
          "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/e574e8bb-96fa-414f-8bb7-5990c9c35659/id-preview-1c5c0026--af45fe97-b740-4204-95b5-2190caeaeb67.lovable.app-1779163698019.png",
      },
      {
        name: "twitter:image",
        content:
          "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/e574e8bb-96fa-414f-8bb7-5990c9c35659/id-preview-1c5c0026--af45fe97-b740-4204-95b5-2190caeaeb67.lovable.app-1779163698019.png",
      },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:type", content: "website" },
      { name: "robots", content: "index, follow" },
      { name: "theme-color", content: "#050b14" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "icon", href: "/icon-192.png", type: "image/png" },
      { rel: "apple-touch-icon", href: "/icon-192.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap",
      },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "SoftwareApplication",
          name: "VersaGlass",
          applicationCategory: "BusinessApplication",
          operatingSystem: "Web",
          offers: { "@type": "Offer", priceCurrency: "BRL" },
        }),
      },
      // Revisão 55 — porteiro de ambiente para a telemetria de PRODUÇÃO.
      // O GA e o pixel do TikTok são a conta REAL de anúncios/analytics. Sem
      // esta guarda eles carregavam também em `localhost`, e percorrer o fluxo
      // de assinatura em desenvolvimento mandava conversão `Purchase` falsa
      // para a conta de produção (achado da Revisão 54). `import.meta.env.PROD`
      // é substituído estaticamente pelo Vite nos dois bundles (cliente e
      // servidor de SSR), então em dev o ramo inteiro é eliminado e nenhuma
      // requisição sai para `googletagmanager.com`/`analytics.tiktok.com`.
      // Os consumidores já toleram a ausência: `ttCall` (`lib/tiktok.ts`)
      // devolve cedo quando `window.ttq` não existe, e `trackEvent`
      // (`lib/monitoring.ts`) chama `gtag?.()` com encadeamento opcional.
      ...(import.meta.env.PROD
        ? [
            { src: "https://www.googletagmanager.com/gtag/js?id=G-6JMVFHW9H2", async: true },
            {
              children: `window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'G-6JMVFHW9H2');`,
            },
            {
              children: `!function (w, d, t) {
  w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie","holdConsent","revokeConsent","grantConsent"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var r="https://analytics.tiktok.com/i18n/pixel/events.js",o=n&&n.partner;ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=r,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};n=document.createElement("script");n.type="text/javascript",n.async=!0,n.src=r+"?sdkid="+e+"&lib="+t;e=document.getElementsByTagName("script")[0];e.parentNode.insertBefore(n,e)};
  ttq.load('D87VEJJC77U91RGCUL00');
  ttq.page();
}(window, document, 'ttq');`,
            },
          ]
        : []),
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

const themeInitScript = `(function(){try{var k='vmm-theme';var t=localStorage.getItem(k);var d=window.matchMedia('(prefers-color-scheme: dark)').matches;var r=t==='dark'||(t!=='light'&&(t==='system'||!t)&&d);document.documentElement.classList.toggle('dark',r);}catch(e){document.documentElement.classList.add('dark');}})();`;

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <HeadContent />
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function AuthSync() {
  const router = useRouter();
  const qc = useQueryClient();
  useEffect(() => {
    startFrontendMonitoring();
    // Only react to real auth transitions. SIGNED_IN fires on INITIAL_SESSION
    // and on every TOKEN_REFRESHED, which would cause the whole app to refetch
    // continuously. We only need to invalidate on logout or user updates.
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_OUT" || event === "USER_UPDATED") {
        router.invalidate();
        qc.invalidateQueries();
      }
    });
    return () => subscription.unsubscribe();
  }, [router, qc]);
  return null;
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      {/* Revisão 45 — o AuthProvider fica AQUI, na raiz, e não em
          `_authenticated`: a landing (`/`) e `/auth` também consomem
          `useAuth()`, e um provider mais abaixo deixaria essas telas sem
          contexto. É o nível certo para um estado que vale para o app todo. */}
      <ThemeProvider>
        <AuthProvider>
          <AuthSync />
          <Outlet />
          <Toaster richColors position="top-right" />
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}
