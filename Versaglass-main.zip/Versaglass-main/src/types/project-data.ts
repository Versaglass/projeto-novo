// =====================================================================
// Formato PERSISTENTE do desenho paramétrico de um modelo técnico.
//
// Guardado em `public.project_templates.project_data` e, após
// `20260904140000_platform_catalog_project_data`, também em
// `public.platform_project_catalog.project_data` (jsonb, NULL = sem desenho).
// Este arquivo é a ÚNICA definição do formato: o banco valida
// apenas o envelope (objeto, versão, tamanho) e a validação detalhada mora
// aqui, em TypeScript, compartilhada por quem lê e por quem grava.
//
// ---------------------------------------------------------------------
// AUDITORIA QUE ORIGINOU ESTE FORMATO (ParametricProjectEditor.tsx)
//
//   type ParamState = { nome, largura, altura, profundidade, material,
//                       acabamento, pecas: Piece[], versao }
//   type Piece = { id, tipo, nome, x, y, largura, altura, qtd, material,
//                  cor, locked?, obs? }
//
// DOIS PONTOS QUE MUDAM O DESENHO DO FORMATO:
//
// 1. `ParamState.versao` NÃO É VERSÃO DE FORMATO. O editor faz
//    `versao: s.versao + 1` a cada alteração (linha 188): é um CONTADOR DE
//    EDIÇÕES. Persistir esse número como versão de schema quebraria qualquer
//    checagem `versao === 1` no primeiro clique do usuário. Aqui o contador
//    vira `revisao`, e `versao` passa a significar exclusivamente a versão do
//    FORMATO — o que permite migrar para `versao: 2` no futuro.
//
// 2. COORDENADAS NEGATIVAS SÃO LEGÍTIMAS. O estado inicial de vidraçaria
//    posiciona o perfil superior em `y: -45` (linha 98), acima da origem.
//    Recusar negativo invalidaria o desenho que o próprio editor cria. Por
//    isso `x`/`y` exigem apenas número FINITO; só as DIMENSÕES exigem > 0.
//
// UNIDADES (conferidas no código, não presumidas)
//   · `largura`/`altura`/`profundidade` do estado e `x`/`y`/`largura`/`altura`
//     das peças estão em MILÍMETROS. Prova: `initialState` faz
//     `largura_padrao * 1000` (linhas 82-83) e as métricas dividem
//     `largura * altura` por 1.000.000 para chegar a m² (linha 181).
//   · `project_templates.largura_padrao`/`altura_padrao` estão em METROS.
//     A conversão entre os dois mundos é sempre explícita.
// =====================================================================

import { normalizaArea, type AreaProjeto } from "@/lib/project-area";

/**
 * A área do DESENHO é a mesma área do MODELO (`public.project_area`).
 *
 * Não existe mais um vocabulário próprio do editor: `project_data.area` e
 * `project_templates.area` são comparados diretamente pelo banco (constraint
 * `project_templates_project_data_area`), então tinham de deixar de ser dois
 * conjuntos parecidos — o antigo `serralheria_aco` daqui nunca casaria com o
 * `serralheria` de lá.
 */
export type { AreaProjeto };

/** Tipos de peça aceitos pelo editor (`PieceType`). */
export const TIPOS_PECA = [
  "vidro",
  "perfil",
  "ferragem",
  "recorte",
  "furo",
  "mdf",
  "pedra",
  "aco",
  "texto",
] as const;
export type TipoPeca = (typeof TIPOS_PECA)[number];

export type PecaV1 = {
  id: string;
  tipo: TipoPeca;
  nome: string;
  /** Milímetros a partir da origem do desenho. Pode ser NEGATIVO. */
  x: number;
  y: number;
  /** Milímetros, sempre > 0. */
  largura: number;
  altura: number;
  qtd: number;
  material: string;
  cor: string;
  locked?: boolean;
  obs?: string;
};

export type ProjectDataV1 = {
  /** Versão do FORMATO (não do conteúdo). Ver nota 1 no topo. */
  versao: 1;
  /** Sempre igual a `project_templates.area` — o banco recusa divergência. */
  area: AreaProjeto;
  nome: string;
  /** Milímetros. */
  largura: number;
  altura: number;
  profundidade: number;
  material: string;
  acabamento: string;
  /** Contador de edições do editor (o antigo `ParamState.versao`). */
  revisao: number;
  pecas: PecaV1[];
  /**
   * Snapshot comercial no orçamento (opcional, retrocompatível).
   * ID de `project_category` (ex.: `temperado`) no momento do apply.
   */
  vidro?: string | null;
  /**
   * Espessura do vidro no momento do apply / edição no orçamento
   * (ex.: `6mm`). Independente do template original.
   */
  espessuraVidro?: string | null;
};

export type ProjectData = ProjectDataV1;

export const VERSAO_ATUAL = 1;

/**
 * Limites. Existem para que um JSON absurdo não trave a tela nem estoure o
 * limite do banco, e são deliberadamente FOLGADOS frente ao uso real: o estado
 * inicial mais pesado do editor (marcenaria) tem 12 peças e as paletas
 * oferecem no máximo 6 componentes por vez.
 */
export const MAX_PECAS = 200;
export const MAX_TEXTO = 200;
/** Espelha `project_templates_project_data_size` (256 KB) no banco. */
export const MAX_BYTES = 256 * 1024;
/** Milímetros. 100 m cobre qualquer fachada; acima disso é erro de digitação. */
const MAX_DIMENSAO_MM = 100_000;
const MAX_COORD_MM = 1_000_000;
const MAX_QTD = 10_000;

const ehObjeto = (v: unknown): v is Record<string, unknown> =>
  typeof v === "object" && v !== null && !Array.isArray(v);

const numeroFinito = (v: unknown): v is number => typeof v === "number" && Number.isFinite(v);

const texto = (v: unknown, padrao = ""): string => {
  if (typeof v !== "string") return padrao;
  return v.slice(0, MAX_TEXTO);
};

/**
 * Verifica se o valor é um `project_data` utilizável.
 *
 * Rejeita array e primitivo na raiz, versão não suportada, número não finito,
 * dimensão <= 0 e excesso de peças. Nada aqui EXECUTA o conteúdo: só lê campos
 * e compara tipos — não há `eval`, `Function`, acesso dinâmico a protótipo nem
 * `JSON.parse` de trecho interno.
 */
export function isProjectData(valor: unknown): valor is ProjectDataV1 {
  if (!ehObjeto(valor)) return false;
  if (valor.versao !== VERSAO_ATUAL) return false;
  // `normalizaArea` e não uma comparação direta: um rascunho salvo no
  // localStorage antes da migração ainda diz `serralheria_aco`, e recusá-lo
  // faria o editor descartar trabalho do usuário como "formato ilegível".
  if (normalizaArea(valor.area) === null) return false;

  for (const campo of ["largura", "altura", "profundidade"] as const) {
    const n = valor[campo];
    if (!numeroFinito(n)) return false;
    if (campo === "profundidade" ? n < 0 : n <= 0) return false;
    if (n > MAX_DIMENSAO_MM) return false;
  }

  if (!Array.isArray(valor.pecas)) return false;
  if (valor.pecas.length > MAX_PECAS) return false;

  for (const peca of valor.pecas) {
    if (!ehObjeto(peca)) return false;
    if (typeof peca.id !== "string" || peca.id === "") return false;
    if (typeof peca.tipo !== "string" || !(TIPOS_PECA as readonly string[]).includes(peca.tipo))
      return false;
    // x/y podem ser negativos de propósito (ver nota 2 no topo).
    if (!numeroFinito(peca.x) || !numeroFinito(peca.y)) return false;
    if (Math.abs(peca.x) > MAX_COORD_MM || Math.abs(peca.y) > MAX_COORD_MM) return false;
    if (!numeroFinito(peca.largura) || peca.largura <= 0 || peca.largura > MAX_DIMENSAO_MM)
      return false;
    if (!numeroFinito(peca.altura) || peca.altura <= 0 || peca.altura > MAX_DIMENSAO_MM)
      return false;
    if (!numeroFinito(peca.qtd) || peca.qtd <= 0 || peca.qtd > MAX_QTD) return false;
  }
  return true;
}

/**
 * Devolve uma cópia SANEADA e válida, ou `null` se o valor for irrecuperável.
 *
 * Campos textuais ausentes viram string vazia e são truncados; `locked`/`obs`
 * só entram quando presentes. Peças inválidas NÃO são silenciosamente
 * descartadas — a função inteira devolve `null`, para que a tela possa avisar
 * em vez de mostrar um desenho pela metade.
 */
export function normalizeProjectData(valor: unknown): ProjectDataV1 | null {
  if (!isProjectData(valor)) return null;
  // A saída é SEMPRE canônica: o alias legado entra na leitura e sai traduzido,
  // então nada abaixo desta função precisa saber que ele existiu.
  const area = normalizaArea(valor.area);
  if (area === null) return null;
  const saneado: ProjectDataV1 = {
    versao: VERSAO_ATUAL,
    area,
    nome: texto(valor.nome),
    largura: valor.largura,
    altura: valor.altura,
    profundidade: valor.profundidade,
    material: texto(valor.material),
    acabamento: texto(valor.acabamento),
    revisao: numeroFinito(valor.revisao) && valor.revisao >= 0 ? Math.floor(valor.revisao) : 0,
    pecas: valor.pecas.map(
      (p): PecaV1 => ({
        id: p.id,
        tipo: p.tipo,
        nome: texto(p.nome),
        x: p.x,
        y: p.y,
        largura: p.largura,
        altura: p.altura,
        qtd: Math.floor(p.qtd),
        material: texto(p.material),
        cor: texto(p.cor, "#94a3b8"),
        ...(typeof p.locked === "boolean" ? { locked: p.locked } : {}),
        ...(typeof p.obs === "string" ? { obs: texto(p.obs) } : {}),
      }),
    ),
  };
  // Campos comerciais opcionais — preservados quando presentes (legado sem eles segue válido).
  if (typeof valor.vidro === "string") saneado.vidro = texto(valor.vidro) || null;
  else if (valor.vidro === null) saneado.vidro = null;
  if (typeof valor.espessuraVidro === "string") {
    saneado.espessuraVidro = texto(valor.espessuraVidro) || null;
  } else if (valor.espessuraVidro === null) {
    saneado.espessuraVidro = null;
  }
  return saneado;
}

/**
 * Estado inicial de um modelo que ainda não tem desenho.
 *
 * Recebe as medidas COMERCIAIS em METROS (`largura_padrao`/`altura_padrao`) e
 * devolve milímetros, com os mesmos pisos do editor (900 × 700 mm) para que um
 * modelo minúsculo não gere um desenho impossível de manipular.
 */
export function createDefaultProjectData(base: {
  nome: string;
  area: AreaProjeto;
  larguraMetros: number;
  alturaMetros: number;
  material?: string | null;
}): ProjectDataV1 {
  const largura = Math.max(900, Math.round((base.larguraMetros || 0) * 1000));
  const altura = Math.max(700, Math.round((base.alturaMetros || 0) * 1000));
  return {
    versao: VERSAO_ATUAL,
    area: base.area,
    nome: texto(base.nome),
    largura,
    altura,
    profundidade: base.area === "marcenaria" ? 450 : 80,
    material: texto(base.material ?? ""),
    acabamento: "",
    revisao: 0,
    pecas: [],
  };
}

/** Tamanho serializado em BYTES, para recusar antes de bater na constraint do banco. */
export function tamanhoEmBytes(dados: ProjectData): number {
  return new TextEncoder().encode(JSON.stringify(dados)).length;
}

/**
 * Cópia INDEPENDENTE de um desenho — usada para levar o desenho do modelo
 * técnico para dentro do item do orçamento.
 *
 * O resultado não compartilha nenhuma referência com a origem: `normalizeProjectData`
 * reconstrói o objeto e remonta o array de peças item a item, então mexer no
 * snapshot do orçamento não toca no modelo, e vice-versa. Devolve `null` quando
 * o valor não é um desenho legível — o chamador decide se avisa ou ignora.
 *
 * Não acessa Supabase e não copia `company_id`/`owner_id`: esses campos nem
 * existem no formato, e é justamente por isso que o snapshot é seguro de mover
 * entre tabelas.
 */
export function cloneProjectData(valor: unknown): ProjectDataV1 | null {
  return normalizeProjectData(valor);
}
