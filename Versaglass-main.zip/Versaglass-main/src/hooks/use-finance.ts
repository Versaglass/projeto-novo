import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/contexts/company-context";

// Financeiro Nível 2 / 2.1 — expenses (operacional + pessoal), charges (RPCs),
// resumo G4 e fluxo de caixa real (Rev. 154–161).

export type ExpenseKind = "operacional" | "pessoal";

export type ExpenseCategory =
  | "fornecedor"
  | "frete"
  | "combustivel"
  | "salario"
  | "imposto"
  | "aluguel"
  | "servico"
  | "compra"
  | "outros";

export type PersonalExpenseCategory =
  | "alimentacao"
  | "casa"
  | "transporte"
  | "cartao"
  | "emprestimo"
  | "lazer"
  | "pro_labore"
  | "outros_pessoal";

export type ExpenseCategoryAny = ExpenseCategory | PersonalExpenseCategory;

export const EXPENSE_CATEGORIES: ReadonlyArray<{ value: ExpenseCategory; label: string }> = [
  { value: "fornecedor", label: "Fornecedor" },
  { value: "frete", label: "Frete" },
  { value: "combustivel", label: "Combustível" },
  { value: "salario", label: "Salário" },
  { value: "imposto", label: "Imposto" },
  { value: "aluguel", label: "Aluguel" },
  { value: "servico", label: "Serviço" },
  { value: "compra", label: "Compra" },
  { value: "outros", label: "Outros" },
];

export const PERSONAL_EXPENSE_CATEGORIES: ReadonlyArray<{
  value: PersonalExpenseCategory;
  label: string;
}> = [
  { value: "pro_labore", label: "Pró-labore" },
  { value: "alimentacao", label: "Alimentação" },
  { value: "casa", label: "Casa" },
  { value: "transporte", label: "Transporte" },
  { value: "cartao", label: "Cartão" },
  { value: "emprestimo", label: "Empréstimo" },
  { value: "lazer", label: "Lazer" },
  { value: "outros_pessoal", label: "Outros (pessoal)" },
];

export type ChargeStatus = "pending" | "paid" | "overdue" | "canceled" | "refunded" | "failed";

export const CHARGE_STATUS_META: Record<
  ChargeStatus,
  { label: string; tone: string }
> = {
  pending: { label: "Pendente", tone: "bg-amber-500/15 text-amber-300" },
  overdue: { label: "Vencida", tone: "bg-red-500/15 text-red-300" },
  paid: { label: "Paga", tone: "bg-emerald-500/15 text-emerald-300" },
  canceled: { label: "Cancelada", tone: "bg-muted text-muted-foreground" },
  refunded: { label: "Estornada", tone: "bg-violet-500/15 text-violet-300" },
  failed: { label: "Falhou", tone: "bg-red-500/15 text-red-300" },
};

/** Período [start, end) — mesmo contrato da RPC (end exclusive). */
export type FinancePeriod = {
  start: string;
  end: string;
};

/** Resumo financeiro — cinco métricas separadas (G4). Sem total pré-misturado. */
export type FinanceSummary = {
  faturamento: number;
  caixa_vendas: number;
  caixa_cobrancas: number;
  despesas: number;
  lucro_estimado: number;
  period: FinancePeriod;
};

export type FinanceCashflowBucket = {
  label: string;
  bucket_start: string;
  bucket_end: string;
  caixa_entrada: number;
  despesas_operacionais: number;
};

export type FinanceCashflow = {
  granularity: string;
  buckets: FinanceCashflowBucket[];
  totals: {
    caixa_entrada: number;
    despesas_operacionais: number;
  };
  period: FinancePeriod;
};

export type ExpenseRow = {
  id: string;
  company_id: string;
  owner_id: string;
  expense_kind: ExpenseKind;
  category: ExpenseCategoryAny;
  description: string;
  amount: number;
  expense_date: string;
  quote_id: string | null;
  notes: string | null;
  created_at: string;
};

export type ExpenseInput = {
  expense_kind?: ExpenseKind;
  category: ExpenseCategoryAny;
  description: string;
  amount: number;
  expense_date: string;
  quote_id?: string | null;
  notes?: string | null;
};

export type ChargeRow = {
  id: string;
  company_id: string;
  owner_id: string;
  customer_id: string | null;
  quote_id: string | null;
  description: string | null;
  amount: number;
  status: ChargeStatus;
  due_date: string | null;
  paid_at: string | null;
  created_at: string;
  customer: { nome: string } | null;
  quote: { numero: number } | null;
};

export type CreateManualChargeInput = {
  amount: number;
  description: string;
  customer_id?: string | null;
  quote_id?: string | null;
  due_date?: string | null;
};

export type UpdateManualChargeInput = CreateManualChargeInput & {
  charge_id: string;
};

const EXPENSE_COLS =
  "id, company_id, owner_id, expense_kind, category, description, amount, expense_date, quote_id, notes, created_at";

const CHARGE_COLS =
  "id, company_id, owner_id, customer_id, quote_id, description, amount, status, due_date, paid_at, created_at, customer:customers(nome), quote:quotes(numero)";

function parseMoney(v: unknown): number {
  const n = typeof v === "string" ? Number(v) : Number(v ?? 0);
  return Number.isFinite(n) ? n : 0;
}

function parseSummaryPayload(raw: unknown): FinanceSummary {
  const o = (raw ?? {}) as Record<string, unknown>;
  const period = (o.period ?? {}) as Record<string, unknown>;
  return {
    faturamento: parseMoney(o.faturamento),
    caixa_vendas: parseMoney(o.caixa_vendas),
    caixa_cobrancas: parseMoney(o.caixa_cobrancas),
    despesas: parseMoney(o.despesas_total),
    lucro_estimado: parseMoney(o.lucro_estimado),
    period: {
      start: String(period.start ?? ""),
      end: String(period.end ?? ""),
    },
  };
}

function parseCashflowPayload(raw: unknown): FinanceCashflow {
  const o = (raw ?? {}) as Record<string, unknown>;
  const period = (o.period ?? {}) as Record<string, unknown>;
  const totals = (o.totals ?? {}) as Record<string, unknown>;
  const bucketsRaw = Array.isArray(o.buckets) ? o.buckets : [];

  return {
    granularity: String(o.granularity ?? "week"),
    period: {
      start: String(period.start ?? ""),
      end: String(period.end ?? ""),
    },
    totals: {
      caixa_entrada: parseMoney(totals.caixa_entrada),
      despesas_operacionais: parseMoney(totals.despesas_operacionais),
    },
    buckets: bucketsRaw.map((b) => {
      const row = (b ?? {}) as Record<string, unknown>;
      return {
        label: String(row.label ?? ""),
        bucket_start: String(row.bucket_start ?? ""),
        bucket_end: String(row.bucket_end ?? ""),
        caixa_entrada: parseMoney(row.caixa_entrada),
        despesas_operacionais: parseMoney(row.despesas_operacionais),
      };
    }),
  };
}

/** Mês calendário local → intervalo ISO [start, end) para a RPC. */
export function periodForMonth(year: number, monthIndex: number): FinancePeriod {
  const start = new Date(year, monthIndex, 1, 0, 0, 0, 0);
  const end = new Date(year, monthIndex + 1, 1, 0, 0, 0, 0);
  return { start: start.toISOString(), end: end.toISOString() };
}

export function currentMonthPeriod(): FinancePeriod {
  const now = new Date();
  return periodForMonth(now.getFullYear(), now.getMonth());
}

export function expenseCategoryLabel(
  kind: ExpenseKind,
  value: ExpenseCategoryAny,
): string {
  if (kind === "pessoal") {
    return PERSONAL_EXPENSE_CATEGORIES.find((c) => c.value === value)?.label ?? value;
  }
  return EXPENSE_CATEGORIES.find((c) => c.value === value)?.label ?? value;
}

export function financeErrorMessage(error: unknown): string {
  const e = error as { code?: string; message?: string } | null;
  const msg = (e?.message ?? "").trim();
  if (
    /sem permiss|Autenticacao|obrigatoria|positivo|descricao|orcamento|cliente|empresa|status|Intervalo/i.test(
      msg,
    )
  ) {
    return msg;
  }
  if (e?.code === "23503") return "Registro vinculado impede a operação.";
  if (e?.code === "42501" || e?.code === "PGRST301")
    return "Você não tem permissão para esta operação.";
  if (e?.code === "PGRST202")
    return "Função financeira indisponível no servidor. Atualize a página.";
  return "Não foi possível concluir a operação. Tente novamente.";
}

function invalidateFinance(qc: ReturnType<typeof useQueryClient>, companyId: string | null) {
  qc.invalidateQueries({ queryKey: ["finance-summary"] });
  qc.invalidateQueries({ queryKey: ["finance-cashflow"] });
  if (companyId) {
    qc.invalidateQueries({ queryKey: ["expenses", companyId] });
    qc.invalidateQueries({ queryKey: ["charges", companyId] });
  }
}

export function useFinanceSummary(
  companyId: string | null,
  period: FinancePeriod | null,
) {
  return useQuery({
    queryKey: ["finance-summary", companyId, period?.start, period?.end],
    enabled: !!companyId && !!period?.start && !!period?.end,
    queryFn: async (): Promise<FinanceSummary> => {
      if (!companyId || !period) throw new Error("Empresa ou período inválido.");
      const { data, error } = await supabase.rpc("get_finance_summary", {
        p_company_id: companyId,
        p_start: period.start,
        p_end: period.end,
      });
      if (error) throw error;
      return parseSummaryPayload(data);
    },
  });
}

export function useFinanceCashflow(
  companyId: string | null,
  period: FinancePeriod | null,
) {
  return useQuery({
    queryKey: ["finance-cashflow", companyId, period?.start, period?.end],
    enabled: !!companyId && !!period?.start && !!period?.end,
    queryFn: async (): Promise<FinanceCashflow> => {
      if (!companyId || !period) throw new Error("Empresa ou período inválido.");
      const { data, error } = await supabase.rpc("get_finance_cashflow", {
        p_company_id: companyId,
        p_start: period.start,
        p_end: period.end,
        p_granularity: "week",
      });
      if (error) throw error;
      return parseCashflowPayload(data);
    },
  });
}

export function useExpenses(kind?: ExpenseKind) {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  const query = useQuery({
    queryKey: ["expenses", companyId, kind ?? "all"],
    enabled: !!companyId,
    queryFn: async (): Promise<ExpenseRow[]> => {
      if (!companyId) return [];
      let q = supabase
        .from("expenses")
        .select(EXPENSE_COLS)
        .eq("company_id", companyId)
        .order("expense_date", { ascending: false });
      if (kind) {
        q = q.eq("expense_kind", kind);
      }
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as ExpenseRow[];
    },
  });

  return { ...query, companyId, hasActiveCompany: !!companyId };
}

/** Despesas operacionais — aba Despesas do negócio. */
export function useOperationalExpenses() {
  return useExpenses("operacional");
}

/** Retiradas pessoais — RLS restringe a owner/admin; UI esconde a aba para os demais. */
export function usePersonalExpenses() {
  return useExpenses("pessoal");
}

export function useCreateExpense(defaultKind: ExpenseKind = "operacional") {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (input: ExpenseInput) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Sua sessão expirou. Entre novamente.");
      const kind = input.expense_kind ?? defaultKind;
      const { error } = await supabase.from("expenses").insert({
        company_id: companyId,
        owner_id: u.user.id,
        expense_kind: kind,
        category: input.category,
        description: input.description.trim(),
        amount: input.amount,
        expense_date: input.expense_date,
        quote_id: input.quote_id ?? null,
        notes: input.notes?.trim() ? input.notes.trim() : null,
      });
      if (error) throw error;
    },
    onSuccess: () => invalidateFinance(qc, activeCompany?.companyId ?? null),
  });
}

export function useDeleteExpense() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (id: string) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      const { error } = await supabase
        .from("expenses")
        .delete()
        .eq("id", id)
        .eq("company_id", companyId);
      if (error) throw error;
    },
    onSuccess: () => invalidateFinance(qc, activeCompany?.companyId ?? null),
  });
}

/** Despesas operacionais/pessoais — UPDATE via PostgREST + RLS (Rev. 154). */
export function useUpdateExpense() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async ({ id, ...input }: ExpenseInput & { id: string }) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      const { error } = await supabase
        .from("expenses")
        .update({
          category: input.category,
          description: input.description.trim(),
          amount: input.amount,
          expense_date: input.expense_date,
          quote_id: input.quote_id ?? null,
          notes: input.notes?.trim() ? input.notes.trim() : null,
        })
        .eq("id", id)
        .eq("company_id", companyId);
      if (error) throw error;
    },
    onSuccess: () => invalidateFinance(qc, activeCompany?.companyId ?? null),
  });
}

export function useCharges() {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  const query = useQuery({
    queryKey: ["charges", companyId],
    enabled: !!companyId,
    queryFn: async (): Promise<ChargeRow[]> => {
      if (!companyId) return [];
      const { data, error } = await supabase
        .from("charges")
        .select(CHARGE_COLS)
        .eq("company_id", companyId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as ChargeRow[];
    },
  });

  return { ...query, companyId, hasActiveCompany: !!companyId };
}

export function useCreateManualCharge() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (input: CreateManualChargeInput) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      const { data, error } = await supabase.rpc("create_manual_charge", {
        p_company_id: companyId,
        p_amount: input.amount,
        p_description: input.description.trim(),
        p_customer_id: input.customer_id ?? undefined,
        p_quote_id: input.quote_id ?? undefined,
        p_due_date: input.due_date ?? undefined,
        p_payment_method: "manual",
      });
      if (error) throw error;
      return data as string;
    },
    onSuccess: () => invalidateFinance(qc, activeCompany?.companyId ?? null),
  });
}

export function useMarkChargePaid() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (chargeId: string) => {
      const { error } = await supabase.rpc("mark_charge_paid", {
        p_charge_id: chargeId,
        p_paid_at: new Date().toISOString(),
      });
      if (error) throw error;
    },
    onSuccess: () => invalidateFinance(qc, activeCompany?.companyId ?? null),
  });
}

/** Cobrança manual pendente/vencida — RPC update_manual_charge (Rev. 230). */
export function useUpdateManualCharge() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (input: UpdateManualChargeInput) => {
      const { error } = await supabase.rpc("update_manual_charge", {
        p_charge_id: input.charge_id,
        p_amount: input.amount,
        p_description: input.description.trim(),
        p_customer_id: input.customer_id ?? undefined,
        p_quote_id: input.quote_id ?? undefined,
        p_due_date: input.due_date ?? undefined,
      });
      if (error) throw error;
    },
    onSuccess: () => invalidateFinance(qc, activeCompany?.companyId ?? null),
  });
}

/** Orçamentos aprovados da empresa — vínculo opcional em despesa/cobrança. */
export function useApprovedQuoteOptions() {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  return useQuery({
    queryKey: ["finance-quote-options", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      if (!companyId) return [];
      const { data, error } = await supabase
        .from("quotes")
        .select("id, numero, total, customer:customers(nome)")
        .eq("company_id", companyId)
        .eq("status", "aprovado")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Array<{
        id: string;
        numero: number;
        total: number;
        customer: { nome: string } | null;
      }>;
    },
  });
}
