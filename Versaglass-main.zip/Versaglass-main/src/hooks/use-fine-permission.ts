import { useAuth, type Permissions } from "@/hooks/use-auth";
import { useCompany } from "@/contexts/company-context";
import { resolvesFinePermission } from "@/lib/fine-permissions";

/** Permissão fina efetiva (plataforma admin / gestor empresarial / checkbox). */
export function useHasFinePermission(key: keyof Permissions): boolean {
  const { isAdmin, permissions } = useAuth();
  const { companyRole } = useCompany();
  return resolvesFinePermission(isAdmin, companyRole, permissions, key);
}

export function useFinePermissions(): Record<keyof Permissions, boolean> {
  const { isAdmin, permissions } = useAuth();
  const { companyRole } = useCompany();
  return {
    manage_projetos: resolvesFinePermission(isAdmin, companyRole, permissions, "manage_projetos"),
    manage_estoque: resolvesFinePermission(isAdmin, companyRole, permissions, "manage_estoque"),
    manage_clientes: resolvesFinePermission(isAdmin, companyRole, permissions, "manage_clientes"),
    create_orcamentos: resolvesFinePermission(
      isAdmin,
      companyRole,
      permissions,
      "create_orcamentos",
    ),
    edit_orcamentos: resolvesFinePermission(isAdmin, companyRole, permissions, "edit_orcamentos"),
    delete_orcamentos: resolvesFinePermission(
      isAdmin,
      companyRole,
      permissions,
      "delete_orcamentos",
    ),
    use_plano_corte: resolvesFinePermission(isAdmin, companyRole, permissions, "use_plano_corte"),
  };
}
