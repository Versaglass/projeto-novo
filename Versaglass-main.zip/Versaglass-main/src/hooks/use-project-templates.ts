import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/contexts/company-context";
// `MAX_BYTES` local já é o limite da IMAGEM; o do desenho entra com apelido
// para os dois limites não se confundirem.
import {
  MAX_BYTES as MAX_BYTES_DESENHO,
  normalizeProjectData,
  tamanhoEmBytes,
  type ProjectData,
} from "@/types/project-data";
import type { Database, Json } from "@/integrations/supabase/types";
import { AREAS_PROJETO, type AreaProjeto } from "@/lib/project-area";
import {
  contagemNavegavelPorArea,
  ehSubtipoDaArea,
  type SubtipoProjeto,
} from "@/lib/project-subtypes";

type ProjectTemplatesInsert = Database["public"]["Tables"]["project_templates"]["Insert"];
type ProjectTemplatesUpdate = Database["public"]["Tables"]["project_templates"]["Update"];

// Biblioteca de Projetos Técnicos — tabela real `public.project_templates`.
//
// Desde a migration 20260724030000 os modelos pertencem à EMPRESA (company_id) e
// são compartilhados entre membros; `owner_id` é o CRIADOR. Este serviço escopa
// tudo à empresa ativa validada (`activeCompany`). A RLS é a fronteira final:
// leitura por membro; edição por criador ou owner/admin/manager; exclusão
// somente pelo criador (`owner_id = auth.uid()` — migration
// 20260909200000_project_templates_delete_owner_only).
// Não há vínculo com customers/quotes (a obra vive em `public.quotes`).

export type ProjectTemplateCategoria = Database["public"]["Enums"]["project_category"];
export type ProjectTemplateAcabamento = Database["public"]["Enums"]["project_acabamento"];
export type ProjectTemplateCor = Database["public"]["Enums"]["project_cor_refletivo"];

/** Categorias em que o CHECK `project_templates_acabamento_categoria` aceita acabamento. */
export const CATEGORIAS_COM_ACABAMENTO: readonly ProjectTemplateCategoria[] = [
  "vidro_comum",
  "espelho",
  "organico",
  "canelado",
] as const;

export function categoriaAceitaAcabamento(categoria: ProjectTemplateCategoria): boolean {
  return (CATEGORIAS_COM_ACABAMENTO as readonly string[]).includes(categoria);
}

export type ProjectTemplate = {
  id: string;
  owner_id: string;
  company_id: string | null;
  /**
   * ÁREA — classificação principal (`public.project_area`). Controla o
   * agrupamento, os filtros da biblioteca, o badge do card e a paleta do
   * editor. Independente de `categoria`.
   *
   * O tipo admite `null` apesar de a coluna ser NOT NULL: enquanto a migration
   * 20260727090000 não estiver aplicada em um ambiente, a tela pode receber um
   * modelo sem área, e é justamente esse caso que o editor trata perguntando em
   * vez de assumir. Tipar como obrigatório aqui esconderia o buraco atrás de um
   * `!` e a paleta errada apareceria sem aviso.
   */
  area: AreaProjeto | null;
  /**
   * SUBTIPO — o "Tipo de projeto" dentro da área (`src/lib/project-subtypes.ts`).
   * O par (area, subtipo) é validado pela constraint
   * `project_templates_area_subtipo`, então um subtipo aqui SEMPRE pertence à
   * `area` da mesma linha.
   *
   * Admite `null` pelo mesmo motivo de `area`: enquanto a migration
   * 20260728100000 não estiver aplicada em um ambiente, a tela pode receber um
   * modelo sem subtipo. O card omite a linha em vez de inventar um rótulo.
   */
  subtipo: SubtipoProjeto | null;
  categoria: ProjectTemplateCategoria;
  /**
   * Processo do vidro (`project_acabamento`). NULL = não informado.
   * Só faz sentido com categoria em vidro_comum/espelho/organico/canelado
   * (CHECK `project_templates_acabamento_categoria`).
   */
  acabamento: ProjectTemplateAcabamento | null;
  /**
   * Cor do refletivo (`project_cor_refletivo`). NULL permitido mesmo em
   * refletivo — o CHECK só impede cor preenchida fora de refletivo
   * (`cor IS NULL OR categoria = refletivo`).
   */
  cor: ProjectTemplateCor | null;
  nome: string;
  descricao: string | null;
  espessura: string | null;
  tipo: string | null;
  imagem_url: string | null;
  largura_padrao: number;
  altura_padrao: number;
  preco_m2: number;
  observacoes: string | null;
  ativo: boolean;
  created_at: string;
  updated_at: string;
  /**
   * Versão do desenho paramétrico, ou `null` quando o modelo não tem desenho.
   *
   * A listagem NÃO traz `project_data` inteiro: o card só precisa saber se
   * existe desenho, e cada linha pode chegar a 256 KB de geometria — arrastar
   * isso para a biblioteca inteira deixaria a tela pesada sem nenhum ganho.
   * A consulta pede só o subcampo (`project_data->versao`); a geometria
   * completa é buscada sob demanda por `useProjectTemplateDrawing`.
   */
  desenho_versao: number | null;
  /**
   * Geometria completa. Só vem em `useProjectTemplateById` (fluxo "Orçar") e em
   * `useProjectTemplateDrawing` (editor) — a LISTAGEM não carrega este campo.
   */
  project_data?: unknown;
};

// Campos editáveis pelo formulário (nunca id/owner_id/company_id/timestamps).
export type ProjectTemplateInput = {
  /** Obrigatória na criação. Valor do enum, nunca texto livre. */
  area: AreaProjeto;
  /**
   * Obrigatório na criação e SEMPRE de `subtiposDaArea(area)` — o tipo não
   * consegue amarrar as duas propriedades entre si, então quem monta o input
   * valida com `ehSubtipoDaArea`. O banco recusa o par inválido de qualquer
   * modo (`project_templates_area_subtipo`).
   */
  subtipo: SubtipoProjeto;
  categoria: ProjectTemplateCategoria;
  /**
   * Opcionais no input: omitir (= `undefined`) deixa a coluna NULL no insert.
   * O formulário da Biblioteca sempre envia `null` ou o enum; "Salvar como
   * modelo" em Orçamentos (Rev. 180: ainda 4 categorias) pode omitir.
   */
  acabamento?: ProjectTemplateAcabamento | null;
  cor?: ProjectTemplateCor | null;
  nome: string;
  descricao: string | null;
  espessura: string | null;
  tipo: string | null;
  largura_padrao: number;
  altura_padrao: number;
  preco_m2: number;
  observacoes: string | null;
  ativo: boolean;
  imagem_url: string | null;
  /**
   * Desenho paramétrico NA CRIAÇÃO — o caminho de "Salvar como modelo", que
   * copia o snapshot de um item do orçamento para um modelo novo.
   *
   * Três estados distintos, de propósito:
   *   `undefined` → não envie a coluna (o comportamento de todo o resto da
   *                 aplicação; o modelo nasce sem desenho e a coluna fica NULL);
   *   `null`      → modelo explicitamente sem desenho;
   *   ProjectData → o desenho é gravado junto com a linha, já normalizado
   *                 contra `area` (ver `useCreateProjectTemplate`).
   *
   * O formulário da Biblioteca não usa este campo: lá o desenho é feito depois,
   * no editor, por `useSaveProjectDrawing`.
   */
  project_data?: ProjectData | null;
};

const COLS =
  "id, owner_id, company_id, area, subtipo, categoria, acabamento, cor, nome, descricao, espessura, tipo, imagem_url, largura_padrao, altura_padrao, preco_m2, observacoes, ativo, created_at, updated_at, desenho_versao:project_data->versao";

const BUCKET = "project-images";
const MAX_BYTES = 5 * 1024 * 1024; // 5 MiB (igual ao bucket)
const ALLOWED_MIME = ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"];

export function projectTemplateErrorMessage(error: unknown): string {
  const e = error as { code?: string; message?: string } | null;
  if (e?.code === "42501" || e?.code === "PGRST301")
    return "Você não tem permissão para esta operação.";
  if (e?.code === "23505") return "Já existe um registro com esses dados.";
  // A constraint que amarra `project_data.area` a `area` tem uma causa concreta e
  // uma saída concreta — dizer só "não foi possível" deixaria o usuário sem
  // nenhuma pista do que fazer.
  if (e?.code === "23514" && e.message?.includes("project_data_area")) {
    return "A área escolhida não corresponde ao desenho já salvo neste modelo. Remova ou recrie o desenho antes de alterar a área.";
  }
  // Par (area, subtipo) fora da tabela — vem de escrita direta pela API ou de um
  // estado de formulário que ficou para trás depois de trocar a área. Dizer
  // "operação inválida" mandaria o usuário procurar o problema no lugar errado.
  if (e?.code === "23514" && e.message?.includes("area_subtipo")) {
    return "O tipo de projeto escolhido não pertence à área selecionada. Escolha novamente o tipo.";
  }
  if (e?.code === "23514" && e.message?.includes("acabamento_categoria")) {
    return "Acabamento só se aplica a vidro comum, espelho, orgânico ou canelado. Limpe o campo ou troque a categoria.";
  }
  if (e?.code === "23514" && e.message?.includes("cor_refletivo")) {
    return "Cor só se aplica à categoria Refletivo. Limpe o campo ou troque a categoria.";
  }
  if (e?.code === "23502" && e.message?.includes("subtipo")) return "Escolha o tipo de projeto.";
  if (e?.code === "23502" && e.message?.includes("area")) return "Escolha a área do projeto.";
  return "Não foi possível concluir a operação. Tente novamente.";
}

/** Termo de busca sanitizado — a mesma limpeza para a lista e para as contagens. */
function termoDeBusca(search: string): string {
  return search
    .trim()
    .replace(/[,()%*]/g, " ")
    .trim();
}

/** Página da Biblioteca. 12 cards cabem em 4×3 / 3×4 / 2×6. */
export const BIBLIOTECA_PAGE_SIZE = 12;

export type ProjectTemplatesPage = {
  items: ProjectTemplate[];
  total: number;
};

/**
 * Lista os modelos da empresa ativa, **uma página por vez**.
 *
 * `page` é 1-based. O recorte usa `.range()` do PostgREST (inclusivo nos dois
 * lados) e `count: "exact"` para montar "página N de M" sem baixar o JSON de
 * geometria — a listagem continua pedindo só `project_data->versao`.
 */
export function useProjectTemplates(
  search: string,
  area: string,
  subtipo = "todos",
  incluirInativos = false,
  page = 1,
  pageSize = BIBLIOTECA_PAGE_SIZE,
  enabled = true,
) {
  const { activeCompany, loading: companyLoading } = useCompany();
  const companyId = activeCompany?.companyId ?? null;
  const pageSafe = Math.max(1, page);
  const sizeSafe = Math.max(1, pageSize);

  const query = useQuery({
    queryKey: [
      "project-templates",
      companyId,
      search.trim(),
      area,
      subtipo,
      incluirInativos,
      pageSafe,
      sizeSafe,
    ],
    enabled: !!companyId && enabled,
    queryFn: async (): Promise<ProjectTemplatesPage> => {
      if (!companyId) return { items: [], total: 0 };
      const from = (pageSafe - 1) * sizeSafe;
      const to = from + sizeSafe - 1;
      let q = supabase
        .from("project_templates")
        .select(COLS, { count: "exact" })
        .eq("company_id", companyId)
        .order("area")
        .order("nome")
        .range(from, to);
      if (!incluirInativos) q = q.eq("ativo", true);
      // Só um dos quatro valores do enum chega ao `eq`. Um valor inventado na
      // URL ou no estado não vira filtro nenhum — e não vira erro do Postgres.
      if ((AREAS_PROJETO as readonly string[]).includes(area)) {
        q = q.eq("area", area as AreaProjeto);
        // Só DENTRO de uma área, e só se o subtipo for daquela área. Um valor
        // restante de outra área (ou inventado na URL) não vira filtro — e
        // não vira erro do Postgres.
        if (ehSubtipoDaArea(area as AreaProjeto, subtipo)) q = q.eq("subtipo", subtipo);
      }
      const term = termoDeBusca(search);
      // v1 do wizard: busca só por `nome` (Rev. 172/173). Sem coluna `codigo`.
      if (term) q = q.ilike("nome", `%${term}%`);
      const { data, error, count } = await q;
      if (error) throw error;
      return { items: (data ?? []) as ProjectTemplate[], total: count ?? 0 };
    },
  });

  return { ...query, companyId, hasActiveCompany: !!companyId, companyLoading };
}

/** Contagem por área + total, para os rótulos dos filtros. */
export type ContagemPorArea = Record<AreaProjeto, number> & { todos: number };

/**
 * Quantos modelos existem em cada área, para os números dos cards.
 *
 * Recorte base: empresa ativa, `ativo` conforme o papel, mesmo termo de busca.
 * Com `apenasNavegaveis` (padrão em `/app/projetos`), só entra o que passa em
 * `ehSubtipoDaArea` — a mesma regra dos cards de tipo — para o total da área
 * bater com a soma dos tipos navegáveis (e não incluir subtipos legados).
 */
export function useProjectTemplateAreaCounts(
  search: string,
  incluirInativos = false,
  opts?: { apenasNavegaveis?: boolean },
) {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;
  const apenasNavegaveis = opts?.apenasNavegaveis ?? false;

  return useQuery({
    queryKey: [
      "project-template-area-counts",
      companyId,
      search.trim(),
      incluirInativos,
      apenasNavegaveis ? "nav" : "raw",
    ],
    enabled: !!companyId,
    queryFn: async (): Promise<ContagemPorArea> => {
      const zerado = {
        todos: 0,
        vidracaria: 0,
        esquadrias: 0,
        serralheria: 0,
        marcenaria: 0,
        marmoraria: 0,
      } as ContagemPorArea;
      if (!companyId) return zerado;
      let q = supabase.from("project_templates").select("area,subtipo").eq("company_id", companyId);
      if (!incluirInativos) q = q.eq("ativo", true);
      const term = termoDeBusca(search);
      if (term) q = q.ilike("nome", `%${term}%`);
      const { data, error } = await q;
      if (error) throw error;
      const linhas = (data ?? []) as { area: string | null; subtipo: string | null }[];
      if (apenasNavegaveis) {
        return contagemNavegavelPorArea(linhas);
      }
      const contagem = { ...zerado, todos: linhas.length };
      for (const l of linhas) {
        if (l.area && (AREAS_PROJETO as readonly string[]).includes(l.area)) {
          contagem[l.area as AreaProjeto] += 1;
        }
      }
      return contagem;
    },
  });
}

/**
 * Busca UM modelo por id, para o fluxo "Orçar" (Projetos → Orçamentos).
 *
 * Filtra por `id` + `company_id` da empresa ativa + `ativo = true`. A RLS é a
 * fronteira final: um id de outra empresa simplesmente não retorna linha.
 * Inexistente, inativo e inacessível colapsam no MESMO resultado (`null`), de
 * propósito — a interface não pode diferenciar os casos e assim revelar que um
 * id existe em outra empresa.
 */
export function useProjectTemplateById(templateId: string | null | undefined) {
  const { activeCompany, loading: companyLoading } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  const query = useQuery({
    queryKey: ["project-template-by-id", companyId, templateId ?? null],
    enabled: !!companyId && !!templateId,
    // O modelo é um molde: não precisa refazer a busca a cada foco de janela.
    staleTime: 5 * 60 * 1000,
    retry: false,
    queryFn: async (): Promise<ProjectTemplate | null> => {
      if (!companyId || !templateId) return null;
      // `project_data` COMPLETO aqui, ao contrário da listagem: é desta consulta
      // que sai o snapshot copiado para o item do orçamento. A listagem continua
      // trazendo só `project_data->versao`, porque o card só precisa saber se há
      // desenho e a geometria pode chegar a 256 KB por linha.
      const { data, error } = await supabase
        .from("project_templates")
        .select(`${COLS}, project_data`)
        .eq("id", templateId)
        .eq("company_id", companyId)
        .eq("ativo", true)
        .maybeSingle();
      if (error) throw error;
      return (data ?? null) as ProjectTemplate | null;
    },
  });

  return { ...query, companyId, companyLoading };
}

// Envia a imagem ao caminho da EMPRESA (`<company_id>/<uuid>.<ext>`), validando
// MIME e tamanho. Retorna o PATH (guardado em imagem_url). A RLS de storage só
// deixa membros da empresa gravarem nessa pasta.
export async function uploadTemplateImage(companyId: string, file: File): Promise<string> {
  if (!ALLOWED_MIME.includes(file.type))
    throw new Error("Formato de imagem não permitido (use JPG, PNG, WEBP, GIF ou AVIF).");
  if (file.size > MAX_BYTES) throw new Error("Imagem acima de 5 MB.");
  const ext =
    (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
  const path = `${companyId}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage
    .from(BUCKET)
    .upload(path, file, { upsert: false, contentType: file.type });
  if (error) throw error;
  return path;
}

// Remove um objeto do bucket somente se ele for da empresa ativa (path começa com
// o companyId). Nunca apaga imagem legada (pasta de usuário) nem de outra empresa.
export async function deleteTemplateImageIfOwnedByCompany(
  companyId: string,
  imagem_url: string | null,
) {
  if (!imagem_url) return;
  const path = imagem_url.startsWith("http") ? null : imagem_url.replace(/^\/+/, "");
  if (!path || !path.startsWith(`${companyId}/`)) return; // legado/externo: não mexe
  await supabase.storage.from(BUCKET).remove([path]);
}

/**
 * Geometria completa de UM modelo, para o editor paramétrico.
 *
 * Separada da listagem de propósito: só esta consulta traz `project_data`
 * inteiro, e só quando o editor abre. Escopada por `id` + `company_id` da
 * empresa ativa; a RLS (`project_templates_select_company`) é a fronteira
 * final — id de outra empresa simplesmente não retorna linha.
 *
 * O JSON cru é devolvido SEM validar aqui: quem decide o que fazer com um
 * desenho corrompido é a tela, que precisa distinguir "não tem desenho" de
 * "tem desenho ilegível" para avisar em vez de apagar.
 */
export function useProjectTemplateDrawing(templateId: string | null) {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  return useQuery({
    queryKey: ["project-template-drawing", companyId, templateId],
    enabled: !!companyId && !!templateId,
    staleTime: 0,
    retry: false,
    queryFn: async (): Promise<{ project_data: unknown } | null> => {
      if (!companyId || !templateId) return null;
      const { data, error } = await supabase
        .from("project_templates")
        .select("id, project_data")
        .eq("id", templateId)
        .eq("company_id", companyId)
        .maybeSingle();
      if (error) throw error;
      return (data ?? null) as { project_data: unknown } | null;
    },
  });
}

/**
 * Grava o desenho paramétrico NO MODELO ATUAL.
 *
 * UPDATE, nunca INSERT: o editor deixa de criar um modelo novo a cada
 * salvamento. `company_id`/`owner_id` não são enviados (o trigger de
 * imutabilidade e a RLS cuidam do resto) e `observacoes` não é tocado — é
 * texto humano, não depósito de JSON.
 *
 * `largura_padrao`/`altura_padrao` acompanham o desenho porque a relação está
 * comprovada no código do editor: `initialState` monta o desenho a partir
 * dessas colunas multiplicando por 1000 (metros → milímetros), então o caminho
 * inverso é a mesma equação. A conversão é explícita, nunca implícita.
 */
export function useSaveProjectDrawing() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async ({
      id,
      dados,
      areaTemplate,
    }: {
      id: string;
      dados: ProjectData;
      areaTemplate: AreaProjeto;
    }) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");

      const normalizado = normalizeProjectData(dados);
      if (!normalizado) throw new Error("O desenho está em um formato inválido e não foi salvo.");

      // A ÁREA DO MODELO É A FONTE OFICIAL.
      //
      // O que o navegador manda em `dados.area` não é aceito como verdade: um
      // rascunho antigo, um JSON importado pelo botão "Exportar" ou uma
      // chamada direta à API podem trazer outra área, e gravá-la faria o
      // desenho dizer "marcenaria" enquanto o card diz "vidraçaria". Aqui a
      // divergência é NORMALIZADA (não rejeitada) — o desenho é do modelo, e o
      // modelo já sabe qual é a sua área. A constraint
      // `project_templates_project_data_area` faz a mesma checagem no banco,
      // para quem nunca passar por este código.
      const limpo: ProjectData =
        normalizado.area === areaTemplate ? normalizado : { ...normalizado, area: areaTemplate };

      if (tamanhoEmBytes(limpo) > MAX_BYTES_DESENHO) {
        throw new Error("O desenho ficou grande demais para ser salvo. Remova alguns componentes.");
      }

      const { data, error } = await supabase
        .from("project_templates")
        .update({
          project_data: limpo as unknown as Json,
          largura_padrao: limpo.largura / 1000,
          altura_padrao: limpo.altura / 1000,
        })
        .eq("id", id)
        .eq("company_id", companyId)
        .select("id");
      if (error) throw error;
      if (!data || data.length === 0) {
        throw new Error("Modelo não encontrado na empresa ativa ou sem permissão para salvar.");
      }
      return limpo;
    },
    onSuccess: (_d, vars) => {
      qc.invalidateQueries({ queryKey: ["project-templates"] });
      qc.invalidateQueries({ queryKey: ["project-template-drawing"] });
      qc.invalidateQueries({ queryKey: ["project-template-by-id"] });
      void vars;
    },
  });
}

export function useCreateProjectTemplate() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (input: ProjectTemplateInput) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Sua sessão expirou. Entre novamente.");

      // `project_data` sai do spread e volta condicionalmente: mandar a chave
      // com `undefined` não é o mesmo que não mandar a chave, e o caminho
      // normal (formulário da Biblioteca) não deve tocar na coluna.
      const { project_data, ...campos } = input;
      const linha: ProjectTemplatesInsert = {
        ...campos,
        owner_id: u.user.id, // criador (RLS exige = auth.uid()) — NUNCA do formulário
        company_id: companyId, // empresa ativa validada (RLS exige membership) — idem
      };

      if (project_data !== undefined) {
        if (project_data === null) {
          linha.project_data = null;
        } else {
          // A ÁREA DO MODELO É A FONTE OFICIAL — a mesma regra de
          // `useSaveProjectDrawing`. O desenho copiado vem de um item de
          // orçamento e pode carregar a área do modelo de ORIGEM; gravá-la faria
          // o desenho dizer "vidraçaria" enquanto o card novo diz "marcenaria",
          // e a constraint `project_templates_project_data_area` recusaria a
          // linha inteira. Aqui a divergência é NORMALIZADA, não rejeitada.
          const normalizado = normalizeProjectData(project_data);
          if (!normalizado)
            throw new Error("O desenho copiado está em um formato inválido e não foi salvo.");
          const limpo: ProjectData =
            normalizado.area === input.area ? normalizado : { ...normalizado, area: input.area };
          if (tamanhoEmBytes(limpo) > MAX_BYTES_DESENHO) {
            throw new Error("O desenho é grande demais para ser copiado para um modelo.");
          }
          linha.project_data = limpo as unknown as Json;
        }
      }

      const { error } = await supabase.from("project_templates").insert(linha);
      if (error) {
        // Rollback da imagem recém-enviada para não deixar objeto órfão.
        await deleteTemplateImageIfOwnedByCompany(companyId, input.imagem_url).catch(() => {});
        throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["project-templates"] });
      // As contagens dos filtros vivem em outra consulta: sem esta linha, criar
      // ou excluir um modelo mudaria a lista e deixaria o numero do card velho.
      qc.invalidateQueries({ queryKey: ["project-template-area-counts"] });
    },
  });
}

export function useUpdateProjectTemplate() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async ({
      id,
      input,
      previousImage,
      areaAnterior,
      temDesenho,
    }: {
      id: string;
      input: ProjectTemplateInput;
      previousImage: string | null;
      areaAnterior: AreaProjeto | null;
      /** O modelo já tem `project_data` gravado? */
      temDesenho: boolean;
    }) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");

      // TROCA DE ÁREA COM DESENHO EXISTENTE: recusada aqui, não "resolvida".
      //
      // Mudar a área muda a biblioteca de peças: o desenho de uma bancada de
      // granito não tem sentido na paleta de vidraçaria. As duas saídas
      // automáticas seriam apagar a geometria (perda silenciosa de trabalho) ou
      // deixá-la incompatível com a nova área (o card diz uma coisa, o editor
      // abre outra). Nenhuma das duas é aceitável, então quem decide é o
      // usuário: remova ou recrie o desenho e depois troque a área. A interface
      // já bloqueia o campo; esta checagem cobre quem chegar por outro caminho,
      // e o banco recusa de qualquer modo (constraint
      // `project_templates_project_data_area`).
      if (temDesenho && areaAnterior !== null && input.area !== areaAnterior) {
        throw new Error("Remova ou recrie o desenho antes de alterar a área deste modelo.");
      }

      // company_id/owner_id não são enviados — imutáveis pelo formulário. Filtro por
      // company_id garante alvo na empresa ativa; a RLS reforça criador/admin.
      //
      // `project_data` é DESCARTADO aqui: ele só existe no input para a criação
      // ("Salvar como modelo"). Quem edita a geometria de um modelo existente é
      // o editor paramétrico (`useSaveProjectDrawing`) — deixar esta rota
      // gravar desenho abriria um segundo caminho capaz de sobrescrever o
      // trabalho salvo sem passar por nenhuma das validações de lá.
      const { project_data: _ignorado, ...campos } = input;
      void _ignorado;
      const { data, error } = await supabase
        .from("project_templates")
        .update(campos as ProjectTemplatesUpdate)
        .eq("id", id)
        .eq("company_id", companyId)
        .select("id");
      if (error) throw error;
      if (!data || data.length === 0)
        throw new Error("Projeto não encontrado na empresa ativa ou sem permissão.");
      // Só depois de confirmar, remove a imagem antiga se foi substituída.
      if (previousImage && previousImage !== input.imagem_url) {
        await deleteTemplateImageIfOwnedByCompany(companyId, previousImage).catch(() => {});
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["project-templates"] });
      // As contagens dos filtros vivem em outra consulta: sem esta linha, criar
      // ou excluir um modelo mudaria a lista e deixaria o numero do card velho.
      qc.invalidateQueries({ queryKey: ["project-template-area-counts"] });
    },
  });
}

export function useDeleteProjectTemplate() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (template: Pick<ProjectTemplate, "id">) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      const { data: auth } = await supabase.auth.getUser();
      const uid = auth.user?.id;
      if (!uid) throw new Error("Sua sessão expirou. Entre novamente.");

      // HARD DELETE. Sem FK para quotes/estoque (snapshots independentes).
      // Defesa extra + RLS: só o autor (`owner_id = auth.uid()`). NÃO apagar
      // Storage: imagem_url pode ser compartilhada com inventory_items /
      // quote_items.
      const { data, error } = await supabase
        .from("project_templates")
        .delete()
        .eq("id", template.id)
        .eq("company_id", companyId)
        .eq("owner_id", uid)
        .select("id");
      if (error) throw error;
      if (!data || data.length === 0)
        throw new Error("Projeto não encontrado ou sem permissão para excluir.");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["project-templates"] });
      qc.invalidateQueries({ queryKey: ["project-template-area-counts"] });
      qc.invalidateQueries({ queryKey: ["project-templates-picker"] });
      qc.invalidateQueries({ queryKey: ["project-picker-unified"] });
      qc.invalidateQueries({ queryKey: ["project-template-by-id"] });
      qc.invalidateQueries({ queryKey: ["project-template-drawing"] });
    },
  });
}

/** Item leve para seletores (Lista de Projeto, modal de Orçamentos). */
export type ProjectTemplatePickerItem = Pick<
  ProjectTemplate,
  | "id"
  | "area"
  | "subtipo"
  | "categoria"
  | "nome"
  | "descricao"
  | "espessura"
  | "tipo"
  | "largura_padrao"
  | "altura_padrao"
  | "preco_m2"
  | "imagem_url"
  | "observacoes"
> & {
  project_data?: unknown;
};

/**
 * Todos os modelos ativos da empresa — mesma consulta do picker de
 * `app.orcamentos.novo.tsx`, escopada por `company_id`.
 */
export function useCompanyProjectTemplatePicker() {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  return useQuery({
    queryKey: ["project-templates-picker", companyId],
    enabled: !!companyId,
    queryFn: async (): Promise<ProjectTemplatePickerItem[]> => {
      if (!companyId) return [];
      const { data, error } = await supabase
        .from("project_templates")
        .select(
          "id,area,subtipo,categoria,tipo,nome,descricao,espessura,largura_padrao,altura_padrao,preco_m2,imagem_url,observacoes,project_data",
        )
        .eq("company_id", companyId)
        .eq("ativo", true)
        .order("categoria")
        .order("nome");
      if (error) throw error;
      return (data ?? []) as ProjectTemplatePickerItem[];
    },
  });
}
