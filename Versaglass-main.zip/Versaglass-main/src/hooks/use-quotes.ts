import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database, Json } from "@/integrations/supabase/types";
import type { QuoteItemTipoProjeto } from "@/lib/tipo-projeto-orcamento";
import { useCompany } from "@/contexts/company-context";

// Módulo de Orçamentos — tabelas reais `public.quotes` + `public.quote_items`.
//
// Persistência atômica: criar/editar um orçamento (cabeçalho + itens + total)
// passa pela RPC `save_quote_with_items` (SECURITY DEFINER), que valida identidade
// (auth.uid), membership da empresa, cliente-na-empresa e dono/admin na edição, e
// **recalcula os totais no banco** — o total da interface é só prévia. Leitura,
// exclusão e mudança de status usam o cliente autenticado (a RLS por tenant já
// isola), sempre escopados à empresa ativa validada (`activeCompany`).

export type QuoteStatus = "rascunho" | "enviado" | "aprovado" | "recusado";
export type QuoteStage = "orcamento" | "producao" | "instalacao" | "pago";

export const QUOTE_STATUSES: QuoteStatus[] = ["rascunho", "enviado", "aprovado", "recusado"];

export type QuoteListRow = {
  id: string;
  numero: number;
  status: QuoteStatus;
  etapa: QuoteStage;
  total: number;
  validade_dias: number;
  created_at: string;
  customer: { nome: string } | null;
};

export type QuoteItem = {
  id: string;
  quote_id: string;
  descricao: string;
  largura: number; // metros
  altura: number; // metros
  quantidade: number;
  m2: number;
  preco_unit: number;
  subtotal: number;
  ordem: number;
  drawing_data: unknown;
  drawing_notes: string | null;
  /**
   * SNAPSHOT do desenho paramétrico copiado do modelo técnico (ProjectDataV1).
   * NULL = item sem desenho paramétrico. Não confundir com `drawing_data`, que
   * é o desenho técnico de recortes/ferragens do próprio orçamento — um item
   * pode ter os dois.
   */
  project_data: unknown;
  /** Path da foto copiada do modelo/catálogo/estoque. NULL = sem foto (Rev. 220). */
  imagem_url?: string | null;
  /** Ambiente do item (texto opcional). NULL = não informado. */
  ambiente?: string | null;
  /** Enum comercial opcional (Rev. 145). */
  tipo_projeto?: QuoteItemTipoProjeto | null;
  /** Snapshot: projeto direto ou estoque originado de projeto. */
  originado_de_projeto?: boolean;
};

// Item enviado à RPC — largura/altura em METROS, preço por m².
//
// `drawing_data`/`drawing_notes` viajam junto desde a migration 20260727030000 e
// `project_data` desde a 20260727080000. Os três são OPCIONAIS e precisam ser
// REENVIADOS na edição: a RPC apaga e regrava os itens, então o que não for
// enviado volta ao estado "sem desenho". Omitir continua válido (item sem
// desenho); enviar `project_data: null` remove o snapshot de propósito.
export type QuoteItemInput = {
  descricao: string;
  largura: number;
  altura: number;
  quantidade: number;
  preco_unit: number;
  /** Enum opcional — omitido ou null grava NULL no banco (Rev. 145). */
  tipo_projeto?: QuoteItemTipoProjeto | null;
  drawing_data?: unknown;
  drawing_notes?: string | null;
  project_data?: unknown;
  /** Path da foto — reenviado na edição como os demais snapshots (Rev. 220). */
  imagem_url?: string | null;
  /** Ambiente do item — "" / omitido / null → NULL no banco. */
  ambiente?: string | null;
  /** Procedência visual — omitido / null → false na RPC. */
  originado_de_projeto?: boolean;
};

export type SaveQuoteInput = {
  quoteId?: string | null; // presente = edição
  customerId: string;
  status: QuoteStatus;
  observacoes: string | null;
  desconto: number;
  acrescimo: number;
  validadeDias: number;
  items: QuoteItemInput[];
};

export function quoteErrorMessage(error: unknown): string {
  const e = error as { code?: string; message?: string } | null;
  const msg = e?.message ?? "";
  // Mensagens de negócio da RPC são compreensíveis; repassa quando reconhecidas.
  if (
    /pertence a empresa|empresa invalida|sem permiss|descricao|quantidade|negativ|1 a 200 itens|Autenticacao/i.test(
      msg,
    )
  ) {
    return msg;
  }
  if (e?.code === "23503") return "Registro vinculado impede a operação.";
  if (e?.code === "42501" || e?.code === "PGRST301")
    return "Você não tem permissão para esta operação.";
  return "Não foi possível concluir a operação. Tente novamente.";
}

export function useQuotes() {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  const query = useQuery({
    queryKey: ["quotes", companyId],
    enabled: !!companyId,
    queryFn: async (): Promise<QuoteListRow[]> => {
      if (!companyId) return [];
      const { data, error } = await supabase
        .from("quotes")
        .select("id,numero,status,etapa,total,validade_dias,created_at,customer:customers(nome)")
        .eq("company_id", companyId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as QuoteListRow[];
    },
  });

  return { ...query, companyId, hasActiveCompany: !!companyId };
}

export function useQuote(id: string) {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  return useQuery({
    queryKey: ["quote", companyId, id],
    enabled: !!companyId && !!id,
    queryFn: async () => {
      if (!companyId) return null;
      const { data: quote, error } = await supabase
        .from("quotes")
        .select("*, customer:customers(*)")
        .eq("id", id)
        .eq("company_id", companyId)
        .maybeSingle();
      if (error) throw error;
      if (!quote) return null;
      const { data: items, error: ie } = await supabase
        .from("quote_items")
        .select("*")
        .eq("quote_id", id)
        .order("ordem");
      if (ie) throw ie;
      return { quote, items: (items ?? []) as unknown as QuoteItem[] };
    },
  });
}

// Clientes da empresa ativa para o seletor do formulário (id/nome/telefone).
export function useCompanyCustomerOptions() {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  return useQuery({
    queryKey: ["quote-customer-options", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      if (!companyId) return [];
      const { data, error } = await supabase
        .from("customers")
        .select("id,nome,telefone")
        .eq("company_id", companyId)
        .order("nome");
      if (error) throw error;
      return (data ?? []) as { id: string; nome: string; telefone: string | null }[];
    },
  });
}

export function useSaveQuote() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (input: SaveQuoteInput): Promise<string> => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      // A RPC valida identidade/empresa/cliente e recalcula o total. Nunca
      // enviamos owner_id nem total — o banco os define.
      //
      // A CHAMADA é tipada (nome da função e nomes dos parâmetros são conferidos
      // pelos tipos gerados). Só `p_items` precisa de conversão: ele carrega
      // `drawing_data`/`project_data`, que são `unknown` por natureza — o
      // formato deles é validado no banco e em TypeScript próprio, não pelo
      // tipo `Json` do PostgREST.
      const { data, error } = await supabase.rpc("save_quote_with_items", {
        p_company_id: companyId,
        p_customer_id: input.customerId,
        p_items: input.items as unknown as Json,
        p_quote_id: input.quoteId ?? undefined,
        p_status: input.status,
        p_observacoes: input.observacoes ?? undefined,
        p_desconto: input.desconto,
        p_acrescimo: input.acrescimo,
        p_validade_dias: input.validadeDias,
      });
      if (error) throw error;
      return data as string;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["quotes"] });
      qc.invalidateQueries({ queryKey: ["quote"] });
    },
  });
}

// Atualização de campo único do cabeçalho (status/etapa/instalação). A RLS de
// `quotes` (dono ou admin) autoriza; escopamos por empresa ativa por segurança.
function useQuoteFieldUpdate(field: "status" | "etapa" | "instalacao_em") {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async ({ id, value }: { id: string; value: string | null }) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      // Chave dinâmica (status/etapa/instalacao_em): cast estrutural para Update,
      // sem `any` (Revisão 122).
      const { data, error } = await supabase
        .from("quotes")
        .update({ [field]: value } as Database["public"]["Tables"]["quotes"]["Update"])
        .eq("id", id)
        .eq("company_id", companyId)
        .select("id");
      if (error) throw error;
      if (!data || data.length === 0) throw new Error("Orçamento não encontrado na empresa ativa.");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["quote"] });
      qc.invalidateQueries({ queryKey: ["quotes"] });
    },
  });
}

export const useSetQuoteStatus = () => useQuoteFieldUpdate("status");
export const useSetQuoteStage = () => useQuoteFieldUpdate("etapa");
export const useSetQuoteInstalacao = () => useQuoteFieldUpdate("instalacao_em");

export function useDeleteQuote() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (id: string) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      // quote_items tem ON DELETE CASCADE — os itens saem junto. Nenhuma outra
      // tabela referencia quotes, então a exclusão física é segura.
      const { error } = await supabase
        .from("quotes")
        .delete()
        .eq("id", id)
        .eq("company_id", companyId);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["quotes"] });
      qc.invalidateQueries({ queryKey: ["quote"] });
    },
  });
}
