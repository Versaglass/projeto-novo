import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { CompanyRole } from "@/contexts/company-context";

/**
 * Equipe da empresa ativa.
 *
 * A listagem NÃO é um select em `company_members` + `profiles`: `profiles`
 * só devolve a própria linha (`profiles_select_own`) e o e-mail nem existe
 * lá — mora em `auth.users`, que o navegador não consulta. Quem cruza os três
 * é a RPC `list_company_members`, que escopa tudo pela membership ativa de
 * `auth.uid()` e só revela e-mail a owner/admin.
 */
export type CompanyMemberRow = {
  user_id: string;
  nome: string | null;
  email: string | null;
  role: CompanyRole;
  status: "active" | "blocked" | "invited";
  created_at: string;
  convite_pendente: boolean | null;
};

export type ConviteResultado =
  | "invited"
  | "linked"
  | "already_member"
  | "pending_acceptance"
  | "pending_already";

export function useCompanyMembers(companyId: string | null) {
  return useQuery({
    queryKey: ["company-members", companyId],
    enabled: !!companyId,
    queryFn: async (): Promise<CompanyMemberRow[]> => {
      // `companyId!`: `enabled: !!companyId` garante que a consulta só roda com
      // empresa selecionada — o tipo gerado exige `string`, não `string | null`.
      const { data, error } = await supabase.rpc("list_company_members", {
        p_company_id: companyId!,
      });
      if (error) throw error;
      return (data ?? []) as CompanyMemberRow[];
    },
  });
}

/**
 * Convite de vendedor. Todo o trabalho sensível acontece na Edge Function
 * `invite-company-seller`: o navegador só envia empresa, nome e e-mail.
 * Papel (`seller`), status e permissões são fixados no servidor — não há como
 * pedir outro papel, e a senha do convidado nunca passa por aqui.
 */
export function useInviteSeller(companyId: string | null) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: { name: string; email: string }): Promise<ConviteResultado> => {
      if (!companyId) throw new Error("Nenhuma empresa ativa selecionada.");

      const { data, error } = await supabase.functions.invoke("invite-company-seller", {
        body: {
          companyId,
          name: input.name.trim(),
          email: input.email.trim().toLowerCase(),
        },
      });

      if (error) {
        // A função devolve `{ error: "<mensagem>" }` com status 4xx/5xx; o
        // supabase-js embrulha isso num FunctionsHttpError cujo corpo precisa
        // ser lido do `context` para a mensagem chegar ao usuário.
        const resposta = (error as { context?: Response })?.context;
        if (resposta && typeof resposta.json === "function") {
          try {
            const corpo = await resposta.json();
            if (corpo?.error) throw new Error(corpo.error as string);
          } catch (e) {
            if (e instanceof Error && e.message) throw e;
          }
        }
        throw new Error(error.message ?? "Não foi possível enviar o convite.");
      }

      return (data?.status ?? "invited") as ConviteResultado;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["company-members", companyId] });
    },
  });
}
