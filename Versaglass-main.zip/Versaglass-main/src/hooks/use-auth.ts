/**
 * Reexporta o estado de autenticação COMPARTILHADO (Revisão 45).
 *
 * A implementação mudou de hook independente para Context
 * (`src/contexts/auth-context.tsx`) — antes, cada um dos 22 componentes que
 * chamava `useAuth()` montava o próprio estado e refazia as consultas de
 * `user_roles`/`profiles`: 12 pares por carregamento de `/app` (Revisão 42).
 *
 * Este arquivo permanece como PONTO DE ENTRADA porque os 22 consumidores
 * importam daqui. A API é idêntica; nenhum deles precisou ser alterado.
 */
export {
  useAuth,
  AuthProvider,
  type Permissions,
  type AppRole,
  type AuthContextValue,
} from "@/contexts/auth-context";
