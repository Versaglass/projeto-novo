import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";
import { useCompany } from "@/contexts/company-context";

// Módulo de Venda direta — tabelas reais `public.sales` + `public.sale_items`
// (migration 20260804120000, já aplicada em produção na Revisão 84).
//
// A venda NASCE APENAS pela RPC `create_sale_with_items`. Isso não é preferência
// de arquitetura: `sales` e `sale_items` receberam SOMENTE policy de SELECT, e
// com negação por padrão um `insert` direto do navegador devolve 42501 (provado
// na Revisão 83). Ou seja — **não existe venda gravada sem baixa de estoque**,
// e este arquivo não tem, nem pode ter, um caminho alternativo de escrita.
//
// O que o banco decide, e a tela nunca envia: `owner_id` (vem de `auth.uid()`),
// `numero` (sequência), `m2`, `subtotal`, `total` e `quantidade_baixa` — todos
// recalculados na RPC. O total da tela é PRÉVIA.

/** Os seis valores do enum `public.sale_payment_method`. */
export type SalePaymentMethod = "pix" | "dinheiro" | "cartao" | "boleto" | "parcelado" | "outro";

/** Estado da venda (`public.sale_status`, migration 20260819120000). */
export type SaleStatus = "finalizada" | "cancelada";

export const SALE_STATUS_META: Record<
  SaleStatus,
  { label: string; tone: string }
> = {
  finalizada: { label: "Finalizada", tone: "bg-emerald-500/15 text-emerald-300" },
  cancelada: { label: "Cancelada", tone: "bg-red-500/15 text-red-300" },
};

export const SALE_PAYMENT_METHODS: ReadonlyArray<{ value: SalePaymentMethod; label: string }> = [
  { value: "pix", label: "Pix" },
  { value: "dinheiro", label: "Dinheiro" },
  { value: "cartao", label: "Cartão" },
  { value: "boleto", label: "Boleto" },
  { value: "parcelado", label: "Parcelado" },
  { value: "outro", label: "Outro" },
];

/** Os seis valores do enum `public.inventory_unit`, na ordem da migration. */
export type SaleUnit = "m" | "m2" | "un" | "kg" | "pc" | "cx";

/**
 * Um item no formato que a RPC espera.
 *
 * ⚠️ `largura` e `altura` vão em METROS — é a convenção da RPC, igual à de
 * `save_quote_with_items`. A tela digita em MILÍMETROS (1200 × 800), que é como
 * o balcão mede vidro, e converte na hora de enviar. Trocar as duas coisas de
 * lugar daria erro de 1000× no `m2` e na baixa de estoque.
 */
export type SaleItemInput = {
  inventory_item_id: string | null;
  descricao: string;
  unidade: SaleUnit;
  largura: number;
  altura: number;
  quantidade: number;
  preco_unit: number;
  desconto: number;
};

export type CreateSaleInput = {
  items: SaleItemInput[];
  /** Cliente cadastrado. Excludente com `clienteNome` — CHECK no banco. */
  customerId: string | null;
  /** Nome avulso, quando não há cliente cadastrado. */
  clienteNome: string | null;
  formaPagamento: SalePaymentMethod;
  observacoes: string | null;
};

/** A venda como o BANCO a confirmou — a única fonte para o documento. */
export type SaleDocument = {
  sale: {
    id: string;
    numero: number;
    created_at: string;
    company_id: string;
    customer_id: string | null;
    cliente_nome: string | null;
    forma_pagamento: SalePaymentMethod;
    subtotal: number;
    desconto: number;
    acrescimo: number;
    total: number;
    observacoes: string | null;
    status: SaleStatus;
    cancelada_em: string | null;
    cancelada_por: string | null;
    motivo_cancelamento: string | null;
  };
  items: Array<{
    descricao: string;
    unidade: SaleUnit;
    largura: number;
    altura: number;
    m2: number;
    quantidade: number;
    preco_unit: number;
    desconto: number;
    subtotal: number;
    quantidade_baixa: number;
  }>;
  customer: {
    nome: string;
    documento: string | null;
    telefone: string | null;
    email: string | null;
    endereco: string | null;
    cidade: string | null;
  } | null;
};

/**
 * Erro da RPC → frase legível.
 *
 * Os SQLSTATE abaixo são levantados PELA NOSSA função com `using errcode`, e as
 * mensagens foram escritas e exercitadas na Revisão 83 (59/59 asserções). Por
 * isso, para esses códigos, a mensagem do banco é repassada INTEGRALMENTE: ela
 * já diz o item, o disponível e o pedido — informação que uma frase genérica
 * apagaria ("Estoque insuficiente para "Vidro temperado 8mm": disponivel
 * 8.0800 m2, venda pede 60.0000.").
 *
 * ⚠️ Cosmético conhecido, registrado em vez de "consertado": o texto vem do
 * Postgres sem acento (`disponivel`, `nao`) e com o `numeric` cru (`8.0800`).
 * Reescrever no cliente exigiria fazer parsing da mensagem para remontá-la — e
 * um parse errado mostraria número errado ao operador, que é bem pior do que
 * uma palavra sem acento.
 *
 * Qualquer outro código cai no genérico, e o erro cru vai para o console: o
 * usuário nunca vê `PGRST` nem stack de Postgres na tela.
 */
export function saleErrorMessage(error: unknown): string {
  const e = error as { code?: string; message?: string } | null;
  const code = e?.code;
  const msg = (e?.message ?? "").trim();

  // Códigos que a própria `create_sale_with_items` levanta.
  const NOSSOS = ["23514", "22023", "23503", "42501", "28000"];
  if (code && NOSSOS.includes(code) && msg) return msg;

  // 42501 sem mensagem própria = RLS barrou (insert direto, empresa errada).
  if (code === "42501" || code === "PGRST301")
    return "Você não tem permissão para registrar venda nesta empresa.";
  if (code === "23505") return "Esta venda já foi registrada.";
  if (code === "22P02") return "Unidade ou forma de pagamento inválida.";
  if (code === "PGRST202")
    return "A função de venda não está disponível no servidor. Atualize a página e tente de novo.";

  return "Não foi possível registrar a venda. Tente novamente.";
}

/**
 * Erro da RPC `cancel_sale` → frase legível na tela.
 *
 * Mesma filosofia de `saleErrorMessage`: repassar mensagens que a própria RPC
 * escreveu (já exercitadas na Revisão 136), e traduzir os casos que o operador
 * precisa reconhecer sem ler SQLSTATE.
 */
export function cancelSaleErrorMessage(error: unknown): string {
  const e = error as { code?: string; message?: string } | null;
  const code = e?.code;
  const msg = (e?.message ?? "").trim();
  const lower = msg.toLowerCase();

  if (lower.includes("ja esta cancelada") || lower.includes("já está cancelada"))
    return "Esta venda já foi cancelada.";
  if (lower.includes("sem permissao") || lower.includes("sem permissão"))
    return "Você não tem permissão para cancelar vendas nesta empresa.";
  if (lower.includes("vinculo com o estoque") || lower.includes("vínculo com o estoque"))
    return "Não é possível cancelar: um ou mais itens perderam o vínculo com o estoque (catálogo excluído).";
  if (lower.includes("informe o motivo"))
    return "Informe o motivo do cancelamento.";

  const NOSSOS = ["23514", "22023", "23503", "42501", "28000"];
  if (code && NOSSOS.includes(code) && msg) return msg;

  if (code === "42501" || code === "PGRST301")
    return "Você não tem permissão para cancelar vendas nesta empresa.";
  if (code === "PGRST202")
    return "A função de cancelamento não está disponível no servidor. Atualize a página e tente de novo.";

  return "Não foi possível cancelar a venda. Tente novamente.";
}

/**
 * Lê de volta a venda RECÉM-CRIADA, direto do banco.
 *
 * Existe para o documento nunca sair do formulário: o PDF precisa mostrar o
 * `numero` da sequência, os totais recalculados e o `m2` que só o banco
 * conhece. Gerar a nota a partir do estado da tela imprimiria números que
 * ninguém conferiu — e, no limite, uma nota de venda que falhou.
 */
export async function fetchSaleDocument(
  saleId: string,
  /**
   * Empresa ativa. A RLS de `sales` já isola por `is_company_member`, então isto
   * é cinto E suspensório — o mesmo que `useQuote` faz nos Orçamentos: se o
   * usuário é membro de duas empresas, o filtro garante que a venda lida é da
   * empresa que está na tela, e não de outra em que ele também entra.
   */
  companyId?: string | null,
): Promise<SaleDocument> {
  let consulta = supabase
    .from("sales")
    .select(
      "id, numero, created_at, company_id, customer_id, cliente_nome, forma_pagamento, subtotal, desconto, acrescimo, total, observacoes, status, cancelada_em, cancelada_por, motivo_cancelamento",
    )
    .eq("id", saleId);
  if (companyId) consulta = consulta.eq("company_id", companyId);
  const { data: sale, error: saleErr } = await consulta.single();
  if (saleErr) throw saleErr;

  const { data: items, error: itemsErr } = await supabase
    .from("sale_items")
    .select(
      "descricao, unidade, largura, altura, m2, quantidade, preco_unit, desconto, subtotal, quantidade_baixa",
    )
    .eq("sale_id", saleId)
    .order("ordem");
  if (itemsErr) throw itemsErr;

  let customer: SaleDocument["customer"] = null;
  if (sale.customer_id) {
    const { data, error } = await supabase
      .from("customers")
      .select("nome, documento, telefone, email, endereco, cidade")
      .eq("id", sale.customer_id)
      .maybeSingle();
    // Cliente ilegível não derruba a nota: a venda já existe e o documento sai
    // com o que foi confirmado. O erro fica no console, não na cara do usuário.
    if (error) console.error("Não foi possível carregar o cliente da venda.", error);
    else if (data) customer = data as SaleDocument["customer"];
  }

  return {
    sale: sale as SaleDocument["sale"],
    items: (items ?? []) as SaleDocument["items"],
    customer,
  };
}

/**
 * Cria a venda e devolve o documento JÁ CONFIRMADO pelo banco.
 *
 * A ordem importa e é o item 2 do pedido da Revisão 87: primeiro a RPC, e só
 * depois — com o id na mão — a leitura que alimenta o PDF. Se a RPC falhar,
 * nada é lido e nenhum documento existe.
 */
export function useCreateSale() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (input: CreateSaleInput): Promise<SaleDocument> => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa para registrar a venda.");

      // Nunca enviamos owner_id, numero, m2, subtotal, total nem
      // quantidade_baixa — todos são decididos pelo banco.
      const { data, error } = await supabase.rpc("create_sale_with_items", {
        p_company_id: companyId,
        p_items: input.items as unknown as Json,
        p_customer_id: input.customerId ?? undefined,
        p_cliente_nome: input.clienteNome ?? undefined,
        p_forma_pagamento: input.formaPagamento,
        p_observacoes: input.observacoes ?? undefined,
      });
      if (error) throw error;

      return fetchSaleDocument(data as string, companyId);
    },
    onSuccess: () => {
      // A venda debitou estoque: a listagem e o seletor de itens precisam
      // recarregar, ou o operador vende de novo sobre um saldo velho.
      qc.invalidateQueries({ queryKey: ["inventory"] });
      qc.invalidateQueries({ queryKey: ["inventory-picker"] });
      qc.invalidateQueries({ queryKey: ["sales"] });
    },
  });
}

/** Uma linha da listagem — só o que a tabela mostra, sem `select *`. */
export type SaleListRow = {
  id: string;
  numero: number;
  created_at: string;
  total: number;
  forma_pagamento: SalePaymentMethod;
  status: SaleStatus;
  cliente_nome: string | null;
  customer: { nome: string } | null;
};

/**
 * Vendas da empresa ativa, da mais recente para a mais antiga.
 *
 * O `queryKey` inclui o `companyId`: trocar de empresa recarrega sozinho, em vez
 * de mostrar a lista da empresa anterior — mesmo desenho de `useQuotes`.
 *
 * 🔒 O isolamento REAL é da RLS (`sales_select_company`, migration
 * 20260804120000): mesmo que este filtro fosse removido, o banco não devolveria
 * venda de outra empresa. O `.eq` aqui é escopo de tela, não a proteção.
 */
export function useSales() {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  const query = useQuery({
    queryKey: ["sales", companyId],
    enabled: !!companyId,
    queryFn: async (): Promise<SaleListRow[]> => {
      if (!companyId) return [];
      const { data, error } = await supabase
        .from("sales")
        .select(
          "id, numero, created_at, total, forma_pagamento, status, cliente_nome, customer:customers(nome)",
        )
        .eq("company_id", companyId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as SaleListRow[];
    },
  });

  return { ...query, companyId, hasActiveCompany: !!companyId };
}

/** Só vendas finalizadas podem ser canceladas — espelha a RPC. */
export function canCancelSale(status: SaleStatus | undefined): boolean {
  return status === "finalizada";
}

/**
 * Cancela uma venda pela RPC `cancel_sale` e revalida listagem, detalhe e estoque.
 */
export function useCancelSale() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async ({
      saleId,
      motivo,
    }: {
      saleId: string;
      motivo: string;
    }): Promise<string> => {
      const { data, error } = await supabase.rpc("cancel_sale", {
        p_sale_id: saleId,
        p_motivo: motivo,
      });
      if (error) throw error;
      return data as string;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["sales"] });
      qc.invalidateQueries({ queryKey: ["sale"] });
      qc.invalidateQueries({ queryKey: ["inventory"] });
      qc.invalidateQueries({ queryKey: ["inventory-picker"] });
    },
  });
}

/**
 * Uma venda com itens e cliente — a mesma forma que alimenta o PDF.
 *
 * Reusa `fetchSaleDocument` de propósito: se a tela de detalhe montasse a venda
 * por conta própria, ela e a nota poderiam divergir com o tempo. Aqui os dois
 * leem exatamente as mesmas colunas, do mesmo jeito.
 */
export function useSaleDetail(id: string | undefined) {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  return useQuery({
    queryKey: ["sale", companyId, id],
    enabled: !!companyId && !!id,
    queryFn: async (): Promise<SaleDocument | null> => {
      if (!companyId || !id) return null;
      return fetchSaleDocument(id, companyId);
    },
    retry: false,
  });
}

/** Rótulo da forma de pagamento para a tela. */
export function pagamentoLabel(v: string): string {
  return SALE_PAYMENT_METHODS.find((p) => p.value === v)?.label ?? v;
}

/**
 * Nome de quem comprou, com o caso "avulsa" explícito.
 *
 * Venda sem cliente é caso NORMAL (a migration deixa `customer_id` nulo de
 * propósito), então a listagem não pode mostrar "—" e deixar o operador achando
 * que faltou preencher: ou tem cliente cadastrado, ou tem nome avulso, ou foi
 * uma venda de balcão sem identificação — e as três são ditas por extenso.
 */
export function compradorLabel(venda: {
  customer: { nome: string } | null;
  cliente_nome: string | null;
}): { texto: string; avulsa: boolean } {
  if (venda.customer?.nome) return { texto: venda.customer.nome, avulsa: false };
  if (venda.cliente_nome) return { texto: venda.cliente_nome, avulsa: true };
  return { texto: "Sem identificação", avulsa: true };
}
