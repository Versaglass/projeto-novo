/**
 * Listagem do Estoque efetivo (inventory + globais).
 * Leitura sem side effects — não materializa ao abrir/filtrar/buscar.
 */

import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/contexts/company-context";
import {
  ehInventoryUiArea,
  inventoryCategoryValuesForArea,
  inventoryCategoryValuesInUiAreas,
  useInventoryItems,
  type InventoryCategoria,
  type InventoryFilters,
  type InventoryManufacturerProductRef,
} from "@/hooks/use-inventory";
import {
  asInventoryCategoria,
  mergeEffectiveInventory,
  type EffectiveInventoryItem,
  type GlobalManufacturerProductRow,
} from "@/lib/effective-inventory";

const GLOBAL_COLS =
  "id, name, description, source_code, inventory_category, unit, primary_image_path, active, product_manufacturers!inner ( id, name, active )";

function effectiveInventoryCategoryFilter(
  categoria: string,
  area: string,
): InventoryCategoria[] | null {
  if (categoria && categoria !== "todas") {
    const c = asInventoryCategoria(categoria);
    return c ? [c] : [];
  }
  if (area && area !== "all") {
    if (!ehInventoryUiArea(area)) return inventoryCategoryValuesInUiAreas();
    return inventoryCategoryValuesForArea(area);
  }
  return inventoryCategoryValuesInUiAreas();
}

function normalizeGlobalRow(row: Record<string, unknown>): GlobalManufacturerProductRow | null {
  if (typeof row.id !== "string" || typeof row.name !== "string") return null;
  const mfgRaw = row.product_manufacturers;
  const mfgRow = Array.isArray(mfgRaw) ? mfgRaw[0] : mfgRaw;
  let product_manufacturers: InventoryManufacturerProductRef["product_manufacturers"] = null;
  if (mfgRow && typeof mfgRow === "object") {
    const m = mfgRow as Record<string, unknown>;
    if (typeof m.id === "string" && typeof m.name === "string") {
      product_manufacturers = { id: m.id, name: m.name, active: m.active === true };
    }
  }
  if (product_manufacturers && product_manufacturers.active !== true) return null;

  return {
    id: row.id,
    name: row.name,
    description: typeof row.description === "string" ? row.description : null,
    source_code: typeof row.source_code === "string" ? row.source_code : "",
    inventory_category: typeof row.inventory_category === "string" ? row.inventory_category : null,
    unit: typeof row.unit === "string" ? row.unit : null,
    primary_image_path: typeof row.primary_image_path === "string" ? row.primary_image_path : null,
    active: row.active === true,
    product_manufacturers,
  };
}

async function fetchGlobalProductsForFilters(
  filters: InventoryFilters,
): Promise<GlobalManufacturerProductRow[]> {
  const cats = effectiveInventoryCategoryFilter(filters.categoria, filters.area);
  if (!cats || cats.length === 0) return [];

  const term = filters.search
    .trim()
    .replace(/[,()%*]/g, " ")
    .trim();

  let q = supabase
    .from("manufacturer_products")
    .select(GLOBAL_COLS)
    .eq("active", true)
    .order("inventory_category")
    .order("name");

  if (cats.includes("outros")) {
    q = q.or(`inventory_category.in.(${cats.join(",")}),inventory_category.is.null`);
  } else {
    q = q.in("inventory_category", cats);
  }

  if (term) {
    q = q.or(`name.ilike.%${term}%,description.ilike.%${term}%,source_code.ilike.%${term}%`);
  }

  const { data, error } = await q;
  if (error) throw error;

  const out: GlobalManufacturerProductRow[] = [];
  for (const raw of data ?? []) {
    const mapped = normalizeGlobalRow(raw as Record<string, unknown>);
    if (mapped) out.push(mapped);
  }
  return out;
}

export function useEffectiveInventoryItems(filters: InventoryFilters) {
  const inventoryQuery = useInventoryItems(filters);
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  const term = filters.search
    .trim()
    .replace(/[,()%*]/g, " ")
    .trim();

  const globalsQuery = useQuery({
    queryKey: ["effective-inventory", "globals", companyId, term, filters.categoria, filters.area],
    enabled: !!companyId,
    queryFn: () => fetchGlobalProductsForFilters(filters),
  });

  const items: EffectiveInventoryItem[] =
    inventoryQuery.data && globalsQuery.data
      ? mergeEffectiveInventory(inventoryQuery.data, globalsQuery.data)
      : inventoryQuery.data && !globalsQuery.isLoading
        ? mergeEffectiveInventory(inventoryQuery.data, [])
        : [];

  const isLoading = inventoryQuery.isLoading || (globalsQuery.isLoading && !globalsQuery.data);
  const isError = inventoryQuery.isError || globalsQuery.isError;
  const error = inventoryQuery.error ?? globalsQuery.error;

  return {
    data: items,
    isLoading,
    isError,
    error,
    refetch: async () => {
      await Promise.all([inventoryQuery.refetch(), globalsQuery.refetch()]);
    },
    companyId: inventoryQuery.companyId,
    hasActiveCompany: inventoryQuery.hasActiveCompany,
    companyLoading: inventoryQuery.companyLoading,
  };
}
