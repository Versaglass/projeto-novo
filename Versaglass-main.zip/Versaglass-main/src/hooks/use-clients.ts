import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/contexts/company-context";

// Módulo de Clientes — tabela real `public.customers`.
//
// Isolamento multiempresa: a RLS por tenant (`customers_*_tenant`) já garante que
// só o dono (`owner_id = auth.uid()`) ou um membro/admin da empresa
// (`is_company_member/admin(company_id)`) enxergue/altere cada linha. Este serviço
// escopa TODAS as operações à **empresa ativa validada** (`activeCompany` do
// CompanyProvider, que valida o id contra as memberships) e nunca aceita
// `company_id` vindo do formulário. `owner_id`/`company_id` são derivados no
// cliente apenas para satisfazer a RLS; a autoridade final é a RLS no banco.

export type Client = {
  id: string;
  owner_id: string;
  company_id: string | null;
  nome: string;
  documento: string | null;
  telefone: string | null;
  email: string | null;
  endereco: string | null;
  cidade: string | null;
  observacoes: string | null;
  created_at: string;
  updated_at: string;
};

// Apenas os campos que o formulário pode escrever. Nunca inclui id, owner_id,
// company_id ou timestamps — esses são derivados/gerenciados fora do formulário.
export type ClientInput = {
  nome: string;
  documento: string | null;
  telefone: string | null;
  email: string | null;
  endereco: string | null;
  cidade: string | null;
  observacoes: string | null;
};

// Colunas explícitas (evita `select *` e vazamento de colunas futuras).
const COLS =
  "id, owner_id, company_id, nome, documento, telefone, email, endereco, cidade, observacoes, created_at, updated_at";

// PostgREST interpreta vírgula/parênteses no filtro `.or()`; troca-os por espaço
// para impedir injeção de filtro. A RLS já limita as linhas à empresa, então isto
// é apenas robustez do parâmetro de busca, não uma fronteira de segurança.
function sanitizeTerm(raw: string): string {
  return raw.replace(/[,()%*]/g, " ").trim();
}

// Traduz o erro do Supabase para mensagem compreensível, sem expor detalhe interno.
export function clientErrorMessage(error: unknown): string {
  const e = error as { code?: string; message?: string } | null;
  if (e?.code === "23503")
    return "Este cliente possui orçamentos vinculados e não pode ser excluído.";
  if (e?.code === "23505") return "Já existe um cliente com esses dados.";
  if (e?.code === "42501" || e?.code === "PGRST301")
    return "Você não tem permissão para esta operação.";
  return "Não foi possível concluir a operação. Tente novamente.";
}

export function useClients(search: string) {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  const query = useQuery({
    queryKey: ["clients", companyId, search.trim()],
    enabled: !!companyId,
    queryFn: async (): Promise<Client[]> => {
      if (!companyId) return [];
      let q = supabase
        .from("customers")
        .select(COLS)
        .eq("company_id", companyId)
        .order("nome", { ascending: true });
      const term = sanitizeTerm(search);
      if (term) q = q.or(`nome.ilike.%${term}%,documento.ilike.%${term}%,email.ilike.%${term}%`);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as Client[];
    },
  });

  return { ...query, companyId, hasActiveCompany: !!companyId };
}

export function useClient(id: string) {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  return useQuery({
    queryKey: ["client", companyId, id],
    enabled: !!companyId && !!id,
    queryFn: async (): Promise<Client | null> => {
      if (!companyId) return null;
      const { data, error } = await supabase
        .from("customers")
        .select(COLS)
        .eq("id", id)
        .eq("company_id", companyId)
        .maybeSingle();
      if (error) throw error;
      return (data as Client | null) ?? null;
    },
  });
}

export function useCreateClient() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (input: ClientInput) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa antes de cadastrar clientes.");
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Sua sessão expirou. Entre novamente.");
      // `owner_id` é exigido pela RLS (= auth.uid()); `company_id` vem da empresa
      // ativa validada — nunca do formulário.
      // Retorna a linha criada (Rev. 239): fluxos de orçamento precisam do `id`
      // para "criar e seguir" (obra / seleção no formulário).
      const { data, error } = await supabase
        .from("customers")
        .insert({
          ...input,
          owner_id: u.user.id,
          company_id: companyId,
        })
        .select(COLS)
        .single();
      if (error) throw error;
      return data as Client;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["clients"] });
      qc.invalidateQueries({ queryKey: ["quote-customer-options"] });
      qc.invalidateQueries({ queryKey: ["customers-orc"] });
    },
  });
}

export function useUpdateClient() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async ({ id, input }: { id: string; input: ClientInput }) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa antes de editar clientes.");
      // O payload traz só campos editáveis — `company_id`/`owner_id` não são
      // enviados e portanto não podem ser trocados pelo formulário. O filtro por
      // `company_id` garante que só um cliente da empresa ativa seja alvo.
      const { data, error } = await supabase
        .from("customers")
        .update(input)
        .eq("id", id)
        .eq("company_id", companyId)
        .select("id");
      if (error) throw error;
      if (!data || data.length === 0) {
        throw new Error("Cliente não encontrado na empresa ativa (pode ter sido removido).");
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["clients"] }),
  });
}

export function useDeleteClient() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (id: string) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa antes de excluir clientes.");
      // Exclusão física. `quotes.customer_id` referencia customers com ON DELETE
      // RESTRICT: um cliente com orçamentos NÃO pode ser excluído — o banco rejeita
      // (23503) e nada relacionado é apagado silenciosamente.
      const { error } = await supabase
        .from("customers")
        .delete()
        .eq("id", id)
        .eq("company_id", companyId);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["clients"] }),
  });
}

// Converte o formulário para o payload do banco: aparadas as pontas, string vazia
// vira `null` (o schema aceita null nos opcionais) e e-mail é normalizado.
// Documento já chega canônico do `CustomerDialog` (Revisão 126: CPF 11 dígitos
// ou CNPJ 14 caracteres, sem máscara). Telefone segue como digitado — máscara
// é apresentação, igual ao cadastro da empresa.
export function toClientInput(form: {
  nome: string;
  documento: string;
  telefone: string;
  email: string;
  endereco: string;
  cidade: string;
  observacoes: string;
}): ClientInput {
  const clean = (v: string) => {
    const t = v.trim();
    return t === "" ? null : t;
  };
  const email = form.email.trim().toLowerCase();
  return {
    nome: form.nome.trim(),
    documento: clean(form.documento),
    telefone: clean(form.telefone),
    email: email === "" ? null : email,
    endereco: clean(form.endereco),
    cidade: clean(form.cidade),
    observacoes: clean(form.observacoes),
  };
}
