import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type PendingCompanyInvitation = {
  id: string;
  company_id: string;
  company_name: string;
  proposed_role: string;
  invited_by_nome: string | null;
  created_at: string;
  expires_at: string;
};

export function useMyPendingCompanyInvitations(enabled: boolean) {
  return useQuery({
    queryKey: ["company-invitations", "mine", "pending"],
    enabled,
    queryFn: async (): Promise<PendingCompanyInvitation[]> => {
      const { data, error } = await supabase.rpc("list_my_pending_company_invitations");
      if (error) throw error;
      return (data ?? []) as PendingCompanyInvitation[];
    },
  });
}

export function useRespondCompanyInvitation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: { id: string; action: "accept" | "reject" }) => {
      if (input.action === "accept") {
        const { data, error } = await supabase.rpc("accept_company_invitation", {
          p_invitation_id: input.id,
        });
        if (error) throw error;
        return data as string;
      }
      const { data, error } = await supabase.rpc("reject_company_invitation", {
        p_invitation_id: input.id,
      });
      if (error) throw error;
      return data as string;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["company-invitations", "mine", "pending"] });
    },
  });
}
