/**
 * Persistência atômica de produto global → inventory_items (save)
 * e ensure de id para fluxos que só precisam de inventory_items.id.
 */

import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/contexts/company-context";
import { optionalText, type InventoryItemInput } from "@/hooks/use-inventory";
import { adoptManufacturerProductErrorMessage } from "@/lib/manufacturer-catalog/adopt";

export type SaveManufacturerProductInventoryInput = {
  manufacturerProductId: string;
  form: InventoryItemInput;
};

export type SaveManufacturerProductInventoryResult = {
  inventoryItemId: string;
  /** false = já existia (corrida); dados do vencedor NÃO foram sobrescritos. */
  created: boolean;
};

export type EnsureManufacturerProductInventoryInput = {
  manufacturerProductId: string;
  /** Se omitido, a RPC usa defaults do produto global quando disponíveis. */
  form?: Partial<InventoryItemInput> & {
    nome?: string;
    categoria?: InventoryItemInput["categoria"];
    unidade?: InventoryItemInput["unidade"];
  };
};

export function ensureManufacturerProductErrorMessage(error: unknown): string {
  const msg = adoptManufacturerProductErrorMessage(error);
  if (msg === "Este produto já foi adicionado ao estoque da empresa.") {
    return "Não foi possível sincronizar o item no estoque. Tente novamente.";
  }
  return msg;
}

export function saveManufacturerProductErrorMessage(error: unknown): string {
  return ensureManufacturerProductErrorMessage(error);
}

function invalidateInventoryQueries(qc: ReturnType<typeof useQueryClient>) {
  qc.invalidateQueries({ queryKey: ["inventory"] });
  qc.invalidateQueries({ queryKey: ["effective-inventory"] });
  qc.invalidateQueries({ queryKey: ["inventory-picker"] });
  qc.invalidateQueries({ queryKey: ["inventory-item"] });
  qc.invalidateQueries({ queryKey: ["inventory-adopted-mfg"] });
}

/** Materialização atômica com dados finais do formulário (sem UPDATE posterior). */
export function useSaveManufacturerProductInventory() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async ({
      manufacturerProductId,
      form,
    }: SaveManufacturerProductInventoryInput): Promise<SaveManufacturerProductInventoryResult> => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      if (!form.categoria) throw new Error("Selecione uma categoria.");
      if (!form.unidade) throw new Error("Selecione uma unidade.");

      const { data, error } = await supabase.rpc("save_manufacturer_product_inventory_item", {
        p_company_id: companyId,
        p_manufacturer_product_id: manufacturerProductId,
        p_nome: form.nome.trim(),
        p_categoria: form.categoria,
        p_unidade: form.unidade,
        p_quantidade: form.quantidade,
        p_estoque_minimo: form.estoque_minimo,
        p_custo_unit: form.custo_unit,
        p_preco_venda: form.preco_venda,
        p_descricao: optionalText(form.descricao, 255),
        p_sku: optionalText(form.sku, 64),
        p_ncm: optionalText(form.ncm, 20),
        p_observacoes: optionalText(form.observacoes, 1000),
        p_fornecedor: optionalText(form.fornecedor, 120),
        p_supplier_id: form.supplier_id,
        p_localizacao: optionalText(form.localizacao, 120),
        p_imagem_url: optionalText(form.imagem_url, 500),
        p_ativo: form.ativo,
      });
      if (error) throw error;

      const row = Array.isArray(data) ? data[0] : data;
      const id =
        row && typeof row === "object"
          ? ((row as { inventory_item_id?: unknown }).inventory_item_id ??
            (row as { inventoryItemId?: unknown }).inventoryItemId)
          : null;
      const created =
        row && typeof row === "object" ? (row as { created?: unknown }).created === true : false;

      if (typeof id !== "string" || !id) {
        throw new Error("Não foi possível salvar o item no estoque.");
      }
      return { inventoryItemId: id, created };
    },
    onSuccess: () => invalidateInventoryQueries(qc),
  });
}

/** Garante um inventory_items.id (sem sobrescrever se já existir). */
export function useEnsureManufacturerProductInventory() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async ({
      manufacturerProductId,
      form,
    }: EnsureManufacturerProductInventoryInput): Promise<string> => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");

      const { data, error } = await supabase.rpc("ensure_manufacturer_product_inventory_item", {
        p_company_id: companyId,
        p_manufacturer_product_id: manufacturerProductId,
        p_nome: form?.nome?.trim() || null,
        p_descricao: form?.descricao !== undefined ? optionalText(form.descricao, 255) : null,
        p_sku: form?.sku !== undefined ? optionalText(form.sku, 64) : null,
        p_categoria: form?.categoria ?? null,
        p_unidade: form?.unidade ?? null,
        p_quantidade: form?.quantidade ?? null,
        p_estoque_minimo: form?.estoque_minimo ?? null,
        p_custo_unit: form?.custo_unit ?? null,
        p_preco_venda: form?.preco_venda ?? null,
        p_ncm: form?.ncm !== undefined ? optionalText(form.ncm, 20) : null,
        p_observacoes:
          form?.observacoes !== undefined ? optionalText(form.observacoes, 1000) : null,
        p_fornecedor: form?.fornecedor !== undefined ? optionalText(form.fornecedor, 120) : null,
        p_supplier_id: form?.supplier_id ?? null,
        p_localizacao: form?.localizacao !== undefined ? optionalText(form.localizacao, 120) : null,
        p_imagem_url: form?.imagem_url !== undefined ? optionalText(form.imagem_url, 500) : null,
        p_ativo: form?.ativo ?? true,
      });
      if (error) throw error;
      if (typeof data !== "string" || !data) {
        throw new Error("Não foi possível materializar o item no estoque.");
      }
      return data;
    },
    onSuccess: () => invalidateInventoryQueries(qc),
  });
}
