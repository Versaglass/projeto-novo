/**
 * Adoção de produto do catálogo global → estoque da empresa (Fase 4B).
 *
 * manufacturer_product_id = origem/proveniência (snapshot), NÃO sincronização.
 */

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/contexts/company-context";
import { optionalText } from "@/hooks/use-inventory";
import type {
  InventoryItemDraft,
  InventoryItemForm,
} from "@/components/inventory/inventory-item-form";
import {
  adoptManufacturerProductErrorMessage,
  draftFromManufacturerProduct as draftCore,
} from "@/lib/manufacturer-catalog/adopt";

export {
  adoptManufacturerProductErrorMessage,
  canAdoptManufacturerProduct,
} from "@/lib/manufacturer-catalog/adopt";

export type AdoptManufacturerProductInput = {
  manufacturerProductId: string;
  form: InventoryItemForm;
};

/** Prefill comercial a partir do produto global (editável antes de salvar). */
export function draftFromManufacturerProduct(product: {
  name: string;
  description: string | null;
  source_code: string;
  inventory_category: string | null;
  unit: string | null;
}): InventoryItemDraft {
  return draftCore(product);
}

/**
 * IDs de manufacturer_products já adotados pela empresa ativa (página atual).
 * Uma query em lote — sem N+1.
 */
export function useAdoptedManufacturerProductIds(productIds: readonly string[]) {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;
  const sortedKey = [...productIds].filter(Boolean).sort().join(",");

  return useQuery({
    queryKey: ["inventory-adopted-mfg", companyId, sortedKey],
    enabled: !!companyId && productIds.length > 0,
    queryFn: async (): Promise<Map<string, string>> => {
      if (!companyId || productIds.length === 0) return new Map();
      const { data, error } = await supabase
        .from("inventory_items")
        .select("id, manufacturer_product_id")
        .eq("company_id", companyId)
        .in("manufacturer_product_id", [...productIds]);
      if (error) throw error;
      const map = new Map<string, string>();
      for (const row of data ?? []) {
        const mpid = row.manufacturer_product_id;
        if (typeof mpid === "string") map.set(mpid, row.id);
      }
      return map;
    },
  });
}

export function useAdoptManufacturerProduct() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async ({ manufacturerProductId, form }: AdoptManufacturerProductInput) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");

      const { data, error } = await supabase.rpc("adopt_manufacturer_product_to_inventory", {
        p_company_id: companyId,
        p_manufacturer_product_id: manufacturerProductId,
        p_nome: form.nome.trim(),
        p_descricao: optionalText(form.descricao, 255),
        p_sku: optionalText(form.sku, 64),
        p_categoria: form.categoria,
        p_unidade: form.unidade,
        p_quantidade: form.quantidade,
        p_estoque_minimo: form.estoque_minimo,
        p_custo_unit: form.custo_unit,
        p_preco_venda: form.preco_venda,
        p_ncm: optionalText(form.ncm, 20),
        p_observacoes: optionalText(form.observacoes, 1000),
      });
      if (error) throw error;
      return data as string;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["inventory"] });
      qc.invalidateQueries({ queryKey: ["inventory-picker"] });
      qc.invalidateQueries({ queryKey: ["inventory-adopted-mfg"] });
    },
  });
}
