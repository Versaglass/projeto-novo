import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/contexts/company-context";

export type SupplierArea =
  | "vidracaria"
  | "serralheria"
  | "esquadrias"
  | "marcenaria"
  | "marmoraria"
  | "geral";

export type SupplierStatus = "ativo" | "inativo" | "bloqueado";

export const SUPPLIER_AREAS: ReadonlyArray<{ value: SupplierArea; label: string }> = [
  { value: "vidracaria", label: "Vidraçaria" },
  { value: "serralheria", label: "Serralheria" },
  { value: "esquadrias", label: "Esquadrias" },
  { value: "marcenaria", label: "Marcenaria" },
  { value: "marmoraria", label: "Marmoraria" },
  { value: "geral", label: "Geral" },
];

export const SUPPLIER_STATUSES: ReadonlyArray<{ value: SupplierStatus; label: string }> = [
  { value: "ativo", label: "Ativo" },
  { value: "inativo", label: "Inativo" },
  { value: "bloqueado", label: "Bloqueado" },
];

export type Supplier = {
  id: string;
  owner_id: string;
  company_id: string;
  codigo: string | null;
  nome: string;
  area: SupplierArea;
  cnpj: string | null;
  telefone: string | null;
  whatsapp: string | null;
  vendedor_contato: string | null;
  prazo_entrega: string | null;
  produtos_fornecidos: string | null;
  endereco: string | null;
  cidade: string | null;
  observacoes: string | null;
  status: SupplierStatus;
  created_at: string;
  updated_at: string;
};

export type SupplierInput = {
  codigo: string | null;
  nome: string;
  area: SupplierArea;
  cnpj: string | null;
  telefone: string | null;
  whatsapp: string | null;
  vendedor_contato: string | null;
  prazo_entrega: string | null;
  produtos_fornecidos: string | null;
  endereco: string | null;
  cidade: string | null;
  observacoes: string | null;
  status: SupplierStatus;
};

const COLS =
  "id, owner_id, company_id, codigo, nome, area, cnpj, telefone, whatsapp, vendedor_contato, prazo_entrega, produtos_fornecidos, endereco, cidade, observacoes, status, created_at, updated_at";

function sanitizeTerm(raw: string): string {
  return raw.replace(/[,()%*]/g, " ").trim();
}

export function supplierAreaLabel(value: SupplierArea): string {
  return SUPPLIER_AREAS.find((a) => a.value === value)?.label ?? value;
}

export function supplierStatusLabel(value: SupplierStatus): string {
  return SUPPLIER_STATUSES.find((s) => s.value === value)?.label ?? value;
}

export function supplierErrorMessage(error: unknown): string {
  const e = error as { code?: string; message?: string } | null;
  if (e?.code === "23505") return "Já existe um fornecedor com esse código ou CNPJ nesta empresa.";
  if (e?.code === "42501" || e?.code === "PGRST301")
    return "Você não tem permissão para esta operação.";
  if (e?.code === "23514") return "CNPJ inválido (deve ter 14 caracteres canônicos).";
  return "Não foi possível concluir a operação. Tente novamente.";
}

export function useSuppliers(search: string, areaFilter: string) {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  const query = useQuery({
    queryKey: ["suppliers", companyId, search.trim(), areaFilter],
    enabled: !!companyId,
    queryFn: async (): Promise<Supplier[]> => {
      if (!companyId) return [];
      let q = supabase
        .from("suppliers")
        .select(COLS)
        .eq("company_id", companyId)
        .order("nome", { ascending: true });
      const term = sanitizeTerm(search);
      if (term) {
        q = q.or(
          `nome.ilike.%${term}%,codigo.ilike.%${term}%,cnpj.ilike.%${term}%,telefone.ilike.%${term}%,whatsapp.ilike.%${term}%,vendedor_contato.ilike.%${term}%`,
        );
      }
      if (areaFilter && areaFilter !== "Todas") {
        q = q.eq("area", areaFilter as SupplierArea);
      }
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as Supplier[];
    },
  });

  return { ...query, companyId, hasActiveCompany: !!companyId };
}

/** Lista enxuta para combobox (Estoque): só ativos, ordenados por nome. */
export function useActiveSupplierOptions() {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  return useQuery({
    queryKey: ["suppliers", "options", companyId],
    enabled: !!companyId,
    queryFn: async (): Promise<Array<{ id: string; nome: string }>> => {
      if (!companyId) return [];
      const { data, error } = await supabase
        .from("suppliers")
        .select("id, nome")
        .eq("company_id", companyId)
        .eq("status", "ativo")
        .order("nome", { ascending: true });
      if (error) throw error;
      return (data ?? []) as Array<{ id: string; nome: string }>;
    },
  });
}

export function useCreateSupplier() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (input: SupplierInput) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa antes de cadastrar fornecedores.");
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Sua sessão expirou. Entre novamente.");
      const { error } = await supabase.from("suppliers").insert({
        ...input,
        owner_id: u.user.id,
        company_id: companyId,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["suppliers"] });
    },
  });
}

export function useUpdateSupplier() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async ({ id, input }: { id: string; input: SupplierInput }) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa antes de editar fornecedores.");
      const { data, error } = await supabase
        .from("suppliers")
        .update(input)
        .eq("id", id)
        .eq("company_id", companyId)
        .select("id");
      if (error) throw error;
      if (!data || data.length === 0) {
        throw new Error("Fornecedor não encontrado na empresa ativa (pode ter sido removido).");
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["suppliers"] });
    },
  });
}

export function useDeleteSupplier() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (id: string) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa antes de excluir fornecedores.");
      const { error } = await supabase.from("suppliers").delete().eq("id", id).eq("company_id", companyId);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["suppliers"] });
    },
  });
}

export function toSupplierInput(form: {
  codigo: string;
  nome: string;
  area: SupplierArea;
  cnpj: string;
  telefone: string;
  whatsapp: string;
  vendedor_contato: string;
  prazo_entrega: string;
  produtos_fornecidos: string;
  endereco: string;
  cidade: string;
  observacoes: string;
  status: SupplierStatus;
}): SupplierInput {
  const clean = (v: string, max?: number) => {
    const t = (max ? v.trim().slice(0, max) : v.trim());
    return t === "" ? null : t;
  };
  return {
    codigo: clean(form.codigo, 64),
    nome: form.nome.trim(),
    area: form.area,
    cnpj: clean(form.cnpj),
    telefone: clean(form.telefone, 20),
    whatsapp: clean(form.whatsapp, 20),
    vendedor_contato: clean(form.vendedor_contato, 120),
    prazo_entrega: clean(form.prazo_entrega, 120),
    produtos_fornecidos: clean(form.produtos_fornecidos, 2000),
    endereco: clean(form.endereco, 255),
    cidade: clean(form.cidade, 120),
    observacoes: clean(form.observacoes, 1000),
    status: form.status,
  };
}
