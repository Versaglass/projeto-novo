import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import type { Database, Json } from "@/integrations/supabase/types";
import { AREAS_PROJETO, type AreaProjeto } from "@/lib/project-area";
import {
  contagemNavegavelPorArea,
  ehSubtipoDaArea,
  type SubtipoProjeto,
} from "@/lib/project-subtypes";
import type {
  FiltroAreaProjeto,
  FiltroSubtipoProjeto,
} from "@/components/projects/ProjectAreaSubtypeFilters";
import {
  categoriaAceitaAcabamento,
  uploadTemplateImage,
  type ProjectTemplateAcabamento,
  type ProjectTemplateCategoria,
  type ProjectTemplateCor,
} from "@/hooks/use-project-templates";
import { mensagemDoErro } from "@/lib/erro-mensagem";
import {
  MAX_BYTES as MAX_BYTES_DESENHO,
  normalizeProjectData,
  tamanhoEmBytes,
  type ProjectData,
} from "@/types/project-data";

type Row = Database["public"]["Tables"]["platform_project_catalog"]["Row"];
type Insert = Database["public"]["Tables"]["platform_project_catalog"]["Insert"];
type Update = Database["public"]["Tables"]["platform_project_catalog"]["Update"];

export type PlatformCatalogItem = Row;

export type PlatformCatalogInput = {
  nome: string;
  descricao: string | null;
  imagem_url: string | null;
  area: AreaProjeto;
  subtipo: SubtipoProjeto;
  categoria: ProjectTemplateCategoria;
  acabamento: ProjectTemplateAcabamento | null;
  cor: ProjectTemplateCor | null;
  espessura: string | null;
  largura_padrao: number;
  altura_padrao: number;
  preco_referencia_m2: number;
  observacoes: string | null;
  ativo: boolean;
  ordem: number;
};

const BUCKET = "platform-catalog";
const MAX_BYTES = 5 * 1024 * 1024;
const ALLOWED_MIME = ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"];

const COLS =
  "id,nome,descricao,imagem_url,area,subtipo,categoria,acabamento,cor,espessura,largura_padrao,altura_padrao,preco_referencia_m2,observacoes,ativo,ordem,project_data,created_by,updated_by,created_at,updated_at";

function normalizarInput(input: PlatformCatalogInput): PlatformCatalogInput {
  const acabamento =
    input.acabamento && categoriaAceitaAcabamento(input.categoria) ? input.acabamento : null;
  const cor = input.categoria === "refletivo" ? input.cor : null;
  return { ...input, acabamento, cor };
}

/** Upload no bucket global (só admin de plataforma pela RLS). Path: `catalog/<uuid>.<ext>`. */
export async function uploadPlatformCatalogImage(file: File): Promise<string> {
  if (!ALLOWED_MIME.includes(file.type)) {
    throw new Error("Formato de imagem não permitido (use JPG, PNG, WEBP, GIF ou AVIF).");
  }
  if (file.size > MAX_BYTES) throw new Error("Imagem acima de 5 MB.");
  const ext =
    (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
  const path = `catalog/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage
    .from(BUCKET)
    .upload(path, file, { upsert: false, contentType: file.type });
  if (error) throw error;
  return path;
}

export async function deletePlatformCatalogImage(imagem_url: string | null) {
  if (!imagem_url || imagem_url.startsWith("http")) return;
  const path = imagem_url.replace(/^\/+/, "");
  if (!path.startsWith("catalog/")) return;
  await supabase.storage.from(BUCKET).remove([path]);
}

/**
 * Duplica a foto do catálogo global para `project-images/<company_id>/…`
 * (seed do wizard "Novo projeto"). Sem foto → `null`.
 */
export async function duplicateCatalogImageToCompany(
  companyId: string,
  catalogImagePath: string | null,
): Promise<string | null> {
  if (!catalogImagePath || catalogImagePath.startsWith("http")) return null;
  const path = catalogImagePath.replace(/^\/+/, "");
  const { data, error } = await supabase.storage.from(BUCKET).download(path);
  if (error) throw error;
  if (!data) throw new Error("Não foi possível baixar a foto do catálogo.");
  const ext = (path.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
  const mime =
    data.type && ALLOWED_MIME.includes(data.type)
      ? data.type
      : ext === "png"
        ? "image/png"
        : ext === "webp"
          ? "image/webp"
          : "image/jpeg";
  const file = new File([data], `catalog-copy.${ext}`, { type: mime });
  return uploadTemplateImage(companyId, file);
}

export function platformCatalogErrorMessage(e: unknown): string {
  return mensagemDoErro(e) ?? "Falha no catálogo global.";
}

/** Lista para empresas (só ativos) ou admin (todos). */
export function usePlatformProjectCatalog(opts?: {
  incluirInativos?: boolean;
  search?: string;
  area?: AreaProjeto | "todos";
  subtipo?: string | "todos";
  /** Padrão true. Use false para não buscar (ex.: wizard ainda sem área/tipo). */
  enabled?: boolean;
}) {
  const incluirInativos = opts?.incluirInativos ?? false;
  const search = (opts?.search ?? "").trim();
  const area = opts?.area ?? "todos";
  const subtipo = opts?.subtipo ?? "todos";
  const enabled = opts?.enabled ?? true;

  return useQuery({
    queryKey: ["platform-project-catalog", incluirInativos, search, area, subtipo],
    enabled,
    queryFn: async (): Promise<PlatformCatalogItem[]> => {
      let q = supabase
        .from("platform_project_catalog")
        .select(COLS)
        .order("ordem", { ascending: true })
        .order("nome", { ascending: true });
      if (!incluirInativos) q = q.eq("ativo", true);
      if (search) q = q.ilike("nome", `%${search}%`);
      if (area !== "todos") {
        q = q.eq("area", area);
        if (ehSubtipoDaArea(area, subtipo)) q = q.eq("subtipo", subtipo);
      }
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as PlatformCatalogItem[];
    },
  });
}

export type ContagemCatalogoPorArea = Record<FiltroAreaProjeto, number>;

/**
 * Contagens por área (chips) e, se `area` ≠ todos, por subtipo (select).
 * Respeita busca por nome e `incluirInativos`. Com `apenasNavegaveis`, a
 * contagem por área usa a mesma taxonomia dos cards de tipo (`ehSubtipoDaArea`),
 * alinhada a `/app/projetos`. Sem a flag (Catálogo global admin), conta todas as
 * linhas da área — inclusive subtipos legados ainda listáveis na gestão.
 */
export function usePlatformCatalogAreaCounts(opts?: {
  search?: string;
  incluirInativos?: boolean;
  area?: FiltroAreaProjeto;
  apenasNavegaveis?: boolean;
}) {
  const search = (opts?.search ?? "").trim();
  const incluirInativos = opts?.incluirInativos ?? false;
  const areaFiltro = opts?.area ?? "todos";
  const apenasNavegaveis = opts?.apenasNavegaveis ?? false;

  return useQuery({
    queryKey: [
      "platform-project-catalog-area-counts",
      incluirInativos,
      search,
      areaFiltro,
      apenasNavegaveis ? "nav" : "raw",
    ],
    queryFn: async (): Promise<{
      areas: ContagemCatalogoPorArea;
      subtipos: Partial<Record<FiltroSubtipoProjeto, number>>;
    }> => {
      const zerado: ContagemCatalogoPorArea = {
        todos: 0,
        vidracaria: 0,
        esquadrias: 0,
        serralheria: 0,
        marcenaria: 0,
        marmoraria: 0,
      };
      let q = supabase.from("platform_project_catalog").select("area,subtipo");
      if (!incluirInativos) q = q.eq("ativo", true);
      if (search) q = q.ilike("nome", `%${search}%`);
      const { data, error } = await q;
      if (error) throw error;
      const linhas = (data ?? []) as { area: string | null; subtipo: string | null }[];
      const areas = apenasNavegaveis
        ? contagemNavegavelPorArea(linhas)
        : (() => {
            const c = { ...zerado, todos: linhas.length };
            for (const l of linhas) {
              if (l.area && (AREAS_PROJETO as readonly string[]).includes(l.area)) {
                c[l.area as AreaProjeto] += 1;
              }
            }
            return c;
          })();
      const subtipos: Partial<Record<FiltroSubtipoProjeto, number>> = {};
      if (areaFiltro !== "todos") {
        const daArea = linhas.filter((l) => l.area === areaFiltro);
        let navegaveis = 0;
        for (const l of daArea) {
          if (l.subtipo && ehSubtipoDaArea(areaFiltro, l.subtipo)) {
            const s = l.subtipo as SubtipoProjeto;
            subtipos[s] = (subtipos[s] ?? 0) + 1;
            navegaveis += 1;
          }
        }
        subtipos.todos = apenasNavegaveis ? navegaveis : daArea.length;
      }
      return { areas, subtipos };
    },
  });
}

export function usePlatformCatalogItem(id: string | null | undefined) {
  return useQuery({
    queryKey: ["platform-project-catalog-item", id],
    enabled: !!id,
    queryFn: async (): Promise<PlatformCatalogItem | null> => {
      if (!id) return null;
      const { data, error } = await supabase
        .from("platform_project_catalog")
        .select(COLS)
        .eq("id", id)
        .eq("ativo", true)
        .maybeSingle();
      if (error) throw error;
      return (data as PlatformCatalogItem | null) ?? null;
    },
  });
}

/**
 * Item do catálogo global no formato consumido por pickers de orçamento
 * (`templateToQuoteItem` / "Aplicar projeto"). Sem cópia para `project_templates`.
 */
export type PlatformCatalogPickerItem = {
  id: string;
  area: AreaProjeto;
  subtipo: string;
  categoria: ProjectTemplateCategoria;
  tipo: string | null;
  nome: string;
  descricao: string | null;
  espessura: string | null;
  largura_padrao: number;
  altura_padrao: number;
  /** Alias de `preco_referencia_m2` para o conversor do orçamento. */
  preco_m2: number;
  imagem_url: string | null;
  observacoes: string | null;
  /** Desenho paramétrico do catálogo (snapshot ao aplicar no orçamento). */
  project_data: Json | null;
};

export function catalogToPickerItem(item: PlatformCatalogItem): PlatformCatalogPickerItem {
  return {
    id: item.id,
    area: item.area as AreaProjeto,
    subtipo: item.subtipo,
    categoria: item.categoria,
    tipo: null,
    nome: item.nome,
    descricao: item.descricao,
    espessura: item.espessura,
    largura_padrao: Number(item.largura_padrao) || 0,
    altura_padrao: Number(item.altura_padrao) || 0,
    preco_m2: Number(item.preco_referencia_m2) || 0,
    imagem_url: item.imagem_url,
    observacoes: item.observacoes,
    project_data: item.project_data ?? null,
  };
}

/** Lista ativa do catálogo global — mesma fonte da página Projetos. */
export function usePlatformCatalogPicker() {
  return useQuery({
    queryKey: ["platform-project-catalog-picker"],
    queryFn: async (): Promise<PlatformCatalogPickerItem[]> => {
      const { data, error } = await supabase
        .from("platform_project_catalog")
        .select(COLS)
        .eq("ativo", true)
        .order("area")
        .order("subtipo")
        .order("nome");
      if (error) throw error;
      return ((data ?? []) as PlatformCatalogItem[]).map(catalogToPickerItem);
    },
  });
}

export function useCreatePlatformCatalogItem() {
  const qc = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (input: PlatformCatalogInput): Promise<PlatformCatalogItem> => {
      const n = normalizarInput(input);
      if (!ehSubtipoDaArea(n.area, n.subtipo)) {
        throw new Error("O tipo de projeto não pertence à área escolhida.");
      }
      const linha: Insert = {
        ...n,
        created_by: user?.id ?? null,
        updated_by: user?.id ?? null,
      };
      const { data, error } = await supabase
        .from("platform_project_catalog")
        .insert(linha)
        .select(COLS)
        .single();
      if (error) {
        await deletePlatformCatalogImage(n.imagem_url).catch(() => {});
        throw error;
      }
      return data as PlatformCatalogItem;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["platform-project-catalog"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-area-counts"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-picker"] });
    },
  });
}

export function useUpdatePlatformCatalogItem() {
  const qc = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async ({
      id,
      input,
      previousImage,
    }: {
      id: string;
      input: PlatformCatalogInput;
      previousImage: string | null;
    }): Promise<PlatformCatalogItem> => {
      const n = normalizarInput(input);
      if (!ehSubtipoDaArea(n.area, n.subtipo)) {
        throw new Error("O tipo de projeto não pertence à área escolhida.");
      }
      const patch: Update = {
        ...n,
        updated_by: user?.id ?? null,
      };
      const { data, error } = await supabase
        .from("platform_project_catalog")
        .update(patch)
        .eq("id", id)
        .select(COLS)
        .single();
      if (error) throw error;
      if (previousImage && previousImage !== n.imagem_url) {
        await deletePlatformCatalogImage(previousImage).catch(() => {});
      }
      return data as PlatformCatalogItem;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["platform-project-catalog"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-item"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-area-counts"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-picker"] });
    },
  });
}

/**
 * Grava o desenho paramétrico no item do catálogo global.
 * Mesmo envelope `ProjectDataV1` de `project_templates.project_data`.
 * Também alinha `largura_padrao`/`altura_padrao` (m) às dimensões do desenho (mm).
 */
export function useSavePlatformCatalogDrawing() {
  const qc = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async ({
      id,
      dados,
      areaTemplate,
    }: {
      id: string;
      dados: ProjectData;
      areaTemplate: AreaProjeto;
    }): Promise<ProjectData> => {
      const normalizado = normalizeProjectData(dados);
      if (!normalizado) throw new Error("O desenho está em um formato inválido e não foi salvo.");

      const limpo: ProjectData =
        normalizado.area === areaTemplate ? normalizado : { ...normalizado, area: areaTemplate };

      if (tamanhoEmBytes(limpo) > MAX_BYTES_DESENHO) {
        throw new Error("O desenho ficou grande demais para ser salvo. Remova alguns componentes.");
      }

      const { data, error } = await supabase
        .from("platform_project_catalog")
        .update({
          project_data: limpo as unknown as Json,
          largura_padrao: limpo.largura / 1000,
          altura_padrao: limpo.altura / 1000,
          updated_by: user?.id ?? null,
        })
        .eq("id", id)
        .select("id");
      if (error) throw error;
      if (!data || data.length === 0) {
        throw new Error("Item do catálogo não encontrado ou sem permissão para salvar.");
      }
      return limpo;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["platform-project-catalog"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-item"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-area-counts"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-picker"] });
    },
  });
}

/** Soft-delete: `ativo = false` (empresas deixam de ver). */
export function useDeactivatePlatformCatalogItem() {
  const qc = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("platform_project_catalog")
        .update({ ativo: false, updated_by: user?.id ?? null })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["platform-project-catalog"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-area-counts"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-picker"] });
    },
  });
}

export function useReactivatePlatformCatalogItem() {
  const qc = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("platform_project_catalog")
        .update({ ativo: true, updated_by: user?.id ?? null })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["platform-project-catalog"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-area-counts"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-picker"] });
    },
  });
}

/**
 * Hard-delete do item no catálogo global.
 * Não remove o arquivo do Storage: orçamentos podem manter o mesmo path em
 * `quote_items.imagem_url` (prefixo `platform-catalog/`).
 */
export function useDeletePlatformCatalogItem() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { data, error } = await supabase
        .from("platform_project_catalog")
        .delete()
        .eq("id", id)
        .select("id");
      if (error) throw error;
      if (!data || data.length === 0) {
        throw new Error("Projeto não encontrado ou já removido.");
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["platform-project-catalog"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-item"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-area-counts"] });
      qc.invalidateQueries({ queryKey: ["platform-project-catalog-picker"] });
    },
  });
}
