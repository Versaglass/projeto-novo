import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";
import {
  DEFAULT_PROJECT_AREA_VISIBILITY,
  parseProjectAreaVisibility,
  PROJECT_AREA_VISIBILITY_KEY,
  type ProjectAreaVisibility,
} from "@/lib/project-area-visibility";
import type { AreaOpcional } from "@/lib/project-area";

const QUERY_KEY = ["platform-settings", PROJECT_AREA_VISIBILITY_KEY] as const;

export function useProjectAreaVisibility() {
  return useQuery({
    queryKey: QUERY_KEY,
    queryFn: async (): Promise<ProjectAreaVisibility> => {
      const { data, error } = await supabase
        .from("platform_settings")
        .select("value")
        .eq("key", PROJECT_AREA_VISIBILITY_KEY)
        .maybeSingle();
      if (error) throw error;
      return parseProjectAreaVisibility(data?.value);
    },
    staleTime: 30_000,
  });
}

export function useUpdateProjectAreaVisibility() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (next: ProjectAreaVisibility) => {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      const { error } = await supabase.from("platform_settings").upsert(
        {
          key: PROJECT_AREA_VISIBILITY_KEY,
          value: next as unknown as Json,
          updated_by: user?.id ?? null,
        },
        { onConflict: "key" },
      );
      if (error) throw error;
      return next;
    },
    onSuccess: (next) => {
      qc.setQueryData(QUERY_KEY, next);
      void qc.invalidateQueries({ queryKey: QUERY_KEY });
    },
  });
}

export function toggleAreaVisibility(
  current: ProjectAreaVisibility,
  area: AreaOpcional,
  enabled: boolean,
): ProjectAreaVisibility {
  return { ...current, [area]: enabled };
}

export { DEFAULT_PROJECT_AREA_VISIBILITY };
