import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/contexts/company-context";
import { normalizeProjectData } from "@/types/project-data";
import type { QuoteStage } from "@/hooks/use-quotes";

export type ServiceOrderSegment =
  | "vidracaria"
  | "serralheria"
  | "esquadrias"
  | "marcenaria"
  | "marmoraria";

export type ServiceOrderStage =
  | "orcamento"
  | "medicao"
  | "producao"
  | "corte"
  | "instalacao"
  | "finalizado"
  | "pago";

export type ServiceOrderStatus = "ativo" | "atrasado" | "finalizado" | "cancelado";

export const SERVICE_ORDER_SEGMENTS: ReadonlyArray<{
  value: ServiceOrderSegment;
  label: string;
}> = [
  { value: "vidracaria", label: "Vidraçaria" },
  { value: "serralheria", label: "Serralheria" },
  { value: "esquadrias", label: "Esquadrias" },
  { value: "marcenaria", label: "Marcenaria" },
  { value: "marmoraria", label: "Marmoraria" },
];

export const SERVICE_ORDER_STAGES: ReadonlyArray<{
  value: ServiceOrderStage;
  label: string;
  tone: string;
}> = [
  { value: "orcamento", label: "Orçamento", tone: "bg-slate-500/15 text-slate-600 dark:text-slate-300" },
  { value: "medicao", label: "Medição", tone: "bg-sky-500/15 text-sky-300" },
  { value: "producao", label: "Produção", tone: "bg-amber-500/15 text-amber-300" },
  { value: "corte", label: "Corte", tone: "bg-orange-500/15 text-orange-300" },
  { value: "instalacao", label: "Instalação", tone: "bg-indigo-500/15 text-indigo-300" },
  { value: "finalizado", label: "Finalizado", tone: "bg-emerald-500/15 text-emerald-300" },
  { value: "pago", label: "Pago", tone: "bg-violet-500/15 text-violet-300" },
];

export const SERVICE_ORDER_STATUSES: ReadonlyArray<{
  value: ServiceOrderStatus;
  label: string;
  tone: string;
}> = [
  { value: "ativo", label: "Ativo", tone: "bg-emerald-500/15 text-emerald-300" },
  { value: "atrasado", label: "Atrasado", tone: "bg-red-500/15 text-red-300" },
  { value: "finalizado", label: "Finalizado", tone: "bg-muted text-muted-foreground" },
  { value: "cancelado", label: "Cancelado", tone: "bg-zinc-500/15 text-zinc-400" },
];

export type ServiceOrderRow = {
  id: string;
  numero: number;
  titulo: string;
  segmento: ServiceOrderSegment;
  etapa: ServiceOrderStage;
  status: ServiceOrderStatus;
  responsavel: string | null;
  data_medicao: string | null;
  data_instalacao: string | null;
  valor: number;
  custo: number;
  observacoes: string | null;
  customer_id: string | null;
  quote_id: string | null;
  created_at: string;
  updated_at: string;
  customer: { nome: string } | null;
};

export type ServiceOrderInput = {
  titulo: string;
  segmento: ServiceOrderSegment;
  etapa: ServiceOrderStage;
  status: ServiceOrderStatus;
  responsavel: string | null;
  data_medicao: string | null;
  data_instalacao: string | null;
  valor: number;
  custo: number;
  observacoes: string | null;
  customer_id: string | null;
  quote_id?: string | null;
};

export type QuoteForServiceOrder = {
  id: string;
  numero: number;
  total: number;
  observacoes: string | null;
  etapa: QuoteStage;
  instalacao_em: string | null;
  customer_id: string;
  customer: { nome: string } | null;
};

export type QuoteItemForServiceOrder = {
  project_data?: unknown;
  tipo_projeto?: string | null;
  descricao?: string;
};

/** Mapeia a etapa do orçamento para a etapa inicial da OS. */
export function quoteStageToOsStage(etapa: QuoteStage): ServiceOrderStage {
  switch (etapa) {
    case "producao":
      return "producao";
    case "instalacao":
      return "instalacao";
    case "pago":
      return "pago";
    default:
      return "orcamento";
  }
}

/** Deduz o segmento a partir do snapshot paramétrico dos itens. */
export function inferSegmentFromQuoteItems(
  items: QuoteItemForServiceOrder[],
): ServiceOrderSegment {
  for (const item of items) {
    const dados = normalizeProjectData(item.project_data);
    if (!dados?.area) continue;
    switch (dados.area) {
      case "vidracaria":
        return "vidracaria";
      case "serralheria":
        return "serralheria";
      case "marcenaria":
        return "marcenaria";
      case "marmoraria":
        return "marmoraria";
    }
  }
  return "vidracaria";
}

export function buildServiceOrderInputFromQuote(
  quote: QuoteForServiceOrder,
  items: QuoteItemForServiceOrder[],
): ServiceOrderInput {
  const cliente = quote.customer?.nome?.trim() || "Cliente";
  const resumoItens = items
    .slice(0, 3)
    .map((i) => i.descricao?.trim())
    .filter(Boolean)
    .join(", ");

  const observacoes = [
    quote.observacoes?.trim(),
    resumoItens ? `Itens: ${resumoItens}${items.length > 3 ? "…" : ""}` : null,
    `Origem: orçamento #${quote.numero}`,
  ]
    .filter(Boolean)
    .join("\n");

  return {
    titulo: `${cliente} — Orç. #${quote.numero}`,
    segmento: inferSegmentFromQuoteItems(items),
    etapa: quoteStageToOsStage(quote.etapa),
    status: "ativo",
    responsavel: null,
    data_medicao: null,
    data_instalacao: quote.instalacao_em,
    valor: Number(quote.total),
    custo: 0,
    observacoes: observacoes || null,
    customer_id: quote.customer_id,
    quote_id: quote.id,
  };
}

const SELECT_LIST =
  "id,numero,titulo,segmento,etapa,status,responsavel,data_medicao,data_instalacao,valor,custo,observacoes,customer_id,quote_id,created_at,updated_at,customer:customers(nome)";

export function segmentLabel(value: ServiceOrderSegment) {
  return SERVICE_ORDER_SEGMENTS.find((s) => s.value === value)?.label ?? value;
}

export function stageLabel(value: ServiceOrderStage) {
  return SERVICE_ORDER_STAGES.find((s) => s.value === value)?.label ?? value;
}

export function stageTone(value: ServiceOrderStage) {
  return SERVICE_ORDER_STAGES.find((s) => s.value === value)?.tone ?? "bg-muted text-muted-foreground";
}

export function statusLabel(value: ServiceOrderStatus) {
  return SERVICE_ORDER_STATUSES.find((s) => s.value === value)?.label ?? value;
}

export function statusTone(value: ServiceOrderStatus) {
  return SERVICE_ORDER_STATUSES.find((s) => s.value === value)?.tone ?? "bg-muted text-muted-foreground";
}

export function formatOsNumero(numero: number) {
  return `OS-${String(numero).padStart(3, "0")}`;
}

export function serviceOrderErrorMessage(error: unknown): string {
  const e = error as { code?: string; message?: string } | null;
  const msg = e?.message ?? "";
  if (/titulo|empresa|permiss|Autenticacao/i.test(msg)) return msg;
  if (e?.code === "23503") return "Cliente ou orçamento vinculado não pertence à empresa.";
  if (e?.code === "23505") return "Já existe uma ordem de serviço para este orçamento.";
  if (e?.code === "42501" || e?.code === "PGRST301")
    return "Você não tem permissão para esta operação.";
  if (e?.code === "23514") return "Valor ou custo inválido.";
  return msg || "Não foi possível concluir a operação.";
}

function normalizeRow(row: ServiceOrderRow): ServiceOrderRow {
  return {
    ...row,
    valor: Number(row.valor),
    custo: Number(row.custo),
    customer: Array.isArray(row.customer) ? row.customer[0] ?? null : row.customer,
  };
}

export function useServiceOrders() {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  const query = useQuery({
    queryKey: ["service-orders", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("service_orders")
        .select(SELECT_LIST)
        .eq("company_id", companyId!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []).map((row) => normalizeRow(row as ServiceOrderRow));
    },
  });

  return {
    ...query,
    hasActiveCompany: !!companyId,
    companyId,
  };
}

export function useCreateServiceOrder() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (input: ServiceOrderInput) => {
      const companyId = activeCompany?.companyId;
      const { data: auth } = await supabase.auth.getUser();
      const uid = auth.user?.id;
      if (!companyId || !uid) throw new Error("Selecione uma empresa ativa.");

      const { data, error } = await supabase
        .from("service_orders")
        .insert({
          owner_id: uid,
          company_id: companyId,
          titulo: input.titulo.trim(),
          segmento: input.segmento,
          etapa: input.etapa,
          status: input.status,
          responsavel: input.responsavel?.trim() || null,
          data_medicao: input.data_medicao || null,
          data_instalacao: input.data_instalacao || null,
          valor: input.valor,
          custo: input.custo,
          observacoes: input.observacoes?.trim() || null,
          customer_id: input.customer_id || null,
          quote_id: input.quote_id ?? null,
        })
        .select("id")
        .single();
      if (error) throw error;
      return data.id as string;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["service-orders"] });
      qc.invalidateQueries({ queryKey: ["service-order-by-quote"] });
    },
  });
}

export function useServiceOrderByQuoteId(quoteId: string | null) {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  return useQuery({
    queryKey: ["service-order-by-quote", companyId, quoteId],
    enabled: !!companyId && !!quoteId,
    queryFn: async (): Promise<ServiceOrderRow | null> => {
      const { data, error } = await supabase
        .from("service_orders")
        .select(SELECT_LIST)
        .eq("company_id", companyId!)
        .eq("quote_id", quoteId!)
        .maybeSingle();
      if (error) throw error;
      return data ? normalizeRow(data as ServiceOrderRow) : null;
    },
  });
}

export function useCreateServiceOrderFromQuote() {
  const qc = useQueryClient();
  const create = useCreateServiceOrder();

  return useMutation({
    mutationFn: async ({
      quote,
      items,
    }: {
      quote: QuoteForServiceOrder;
      items: QuoteItemForServiceOrder[];
    }) => {
      const input = buildServiceOrderInputFromQuote(quote, items);
      return create.mutateAsync(input);
    },
    onSuccess: (_id, vars) => {
      qc.invalidateQueries({ queryKey: ["service-orders"] });
      qc.invalidateQueries({ queryKey: ["service-order-by-quote"] });
    },
  });
}

export function useUpdateServiceOrder() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async ({ id, input }: { id: string; input: ServiceOrderInput }) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");

      const { data, error } = await supabase
        .from("service_orders")
        .update({
          titulo: input.titulo.trim(),
          segmento: input.segmento,
          etapa: input.etapa,
          status: input.status,
          responsavel: input.responsavel?.trim() || null,
          data_medicao: input.data_medicao || null,
          data_instalacao: input.data_instalacao || null,
          valor: input.valor,
          custo: input.custo,
          observacoes: input.observacoes?.trim() || null,
          customer_id: input.customer_id || null,
          quote_id: input.quote_id ?? null,
        })
        .eq("id", id)
        .eq("company_id", companyId)
        .select("id");
      if (error) throw error;
      if (!data?.length) {
        throw new Error("Ordem de serviço não encontrada na empresa ativa ou sem permissão.");
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["service-orders"] });
      qc.invalidateQueries({ queryKey: ["service-order-by-quote"] });
    },
  });
}

export function useDeleteServiceOrder() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (id: string) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");

      const { data, error } = await supabase
        .from("service_orders")
        .delete()
        .eq("id", id)
        .eq("company_id", companyId)
        .select("id");
      if (error) throw error;
      if (!data?.length) {
        throw new Error("Ordem de serviço não encontrada ou sem permissão para excluir.");
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["service-orders"] });
      qc.invalidateQueries({ queryKey: ["service-order-by-quote"] });
    },
  });
}
