import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/contexts/company-context";
import { snapshotImagemUrlFromInventory } from "@/lib/quote-item-image";

// Estoque — tabela real `public.inventory_items`.
//
// Desde a migration 20260727010000 o catálogo pertence à EMPRESA (company_id
// NOT NULL e imutável) e é compartilhado entre os membros; `owner_id` é o
// CRIADOR. Este serviço escopa tudo à empresa ativa validada (`activeCompany`).
// A RLS é a fronteira final: leitura por membro, edição/exclusão por criador ou
// owner/admin/manager.
//
// O que este módulo NÃO faz, porque o schema não suporta:
//   · não há `inventory_movements` nem equivalente — `quantidade` é o SALDO
//     ATUAL absoluto, alterado por UPDATE. Não existe histórico de entrada/saída.
//   · não há fornecedor como entidade (`fornecedor` é texto livre), nem compras,
//     nem contas a pagar, nem custo médio, nem margem.
//   · `quote_items` NÃO tem FK para `inventory_items`: o orçamento leva apenas um
//     SNAPSHOT de descrição, preço e (quando houver) path da foto em `imagem_url`.
//     Editar o estoque nunca altera orçamento salvo.
//
// types.ts já espelha o enum completo e company_id NOT NULL (Revisão 122).

export type InventoryCategoria =
  | "aluminio"
  | "vidro"
  | "ferragem"
  | "acessorio"
  | "perfil"
  | "led"
  | "cola"
  | "outros"
  | "aco_metalon"
  | "chapa_aco"
  | "solda"
  | "mdf"
  | "ferragem_moveis"
  | "fita_borda"
  | "marmore"
  | "quartzo"
  | "porcelanato";

export type InventoryUnidade = "un" | "m" | "m2" | "kg" | "pc" | "cx";

export type InventoryArea =
  | "vidracaria"
  | "esquadrias"
  | "serralheria"
  | "marcenaria"
  | "marmoraria"
  | "geral";

/**
 * Áreas expostas nos filtros/UI do Estoque por enquanto.
 *
 * Habilitadas: Vidraçaria, Esquadrias e Geral.
 * Ocultas: Serralheria, Marcenaria, Marmoraria.
 *
 * Categorias podem pertencer a VÁRIAS áreas (`areas[]`) — ex.: aluminio /
 * perfil em Vidraçaria e Esquadrias.
 */
export const INVENTORY_UI_AREAS = ["vidracaria", "esquadrias", "geral"] as const;
export type InventoryUiArea = (typeof INVENTORY_UI_AREAS)[number];

export type InventoryCategoryDef = {
  value: InventoryCategoria;
  label: string;
  /** Uma ou mais áreas de filtro em que a categoria aparece. */
  areas: readonly InventoryArea[];
  color: string;
};

export function ehInventoryUiArea(valor: unknown): valor is InventoryUiArea {
  return typeof valor === "string" && (INVENTORY_UI_AREAS as readonly string[]).includes(valor);
}

export function categoriaPertenceAArea(
  def: Pick<InventoryCategoryDef, "areas">,
  area: string,
): boolean {
  return def.areas.includes(area as InventoryArea);
}

/** Categorias com pelo menos uma área habilitada na UI (deduplicadas). */
export function inventoryCategoriesInUiAreas(): InventoryCategoryDef[] {
  return INVENTORY_CATEGORIES.filter((c) => c.areas.some((a) => ehInventoryUiArea(a)));
}

export function inventoryCategoryValuesInUiAreas(): InventoryCategoria[] {
  return inventoryCategoriesInUiAreas().map((c) => c.value);
}

/** Categorias que entram no filtro de uma área específica. */
export function inventoryCategoryValuesForArea(area: string): InventoryCategoria[] {
  return INVENTORY_CATEGORIES.filter((c) => categoriaPertenceAArea(c, area)).map((c) => c.value);
}

// Espelha EXATAMENTE o enum `public.inventory_category` (8 originais da baseline
// + 9 adicionados em 20260727000000). `areas` é agrupamento de interface, não
// existe no banco — um item entra em vários filtros se a categoria for
// compartilhada.
export const INVENTORY_CATEGORIES: ReadonlyArray<InventoryCategoryDef> = [
  {
    value: "aluminio",
    label: "Alumínio",
    areas: ["vidracaria", "esquadrias"],
    color: "bg-slate-500/15 text-slate-600 dark:text-slate-300",
  },
  { value: "vidro", label: "Vidros", areas: ["vidracaria"], color: "bg-sky-500/15 text-sky-300" },
  {
    value: "ferragem",
    label: "Ferragens",
    areas: ["vidracaria", "esquadrias"],
    color: "bg-zinc-500/15 text-zinc-300",
  },
  {
    value: "acessorio",
    label: "Acessórios",
    areas: ["vidracaria", "esquadrias"],
    color: "bg-gold/15 text-gold",
  },
  {
    value: "perfil",
    label: "Perfis",
    areas: ["vidracaria", "esquadrias"],
    color: "bg-indigo-500/15 text-indigo-300",
  },
  { value: "led", label: "LED", areas: ["vidracaria"], color: "bg-amber-500/15 text-amber-300" },
  {
    value: "aco_metalon",
    label: "Aço/Metalon",
    areas: ["serralheria"],
    color: "bg-orange-500/15 text-orange-300",
  },
  {
    value: "chapa_aco",
    label: "Chapas de aço",
    areas: ["serralheria"],
    color: "bg-red-500/15 text-red-300",
  },
  {
    value: "solda",
    label: "Solda/Insumos",
    areas: ["serralheria"],
    color: "bg-yellow-500/15 text-yellow-300",
  },
  {
    value: "mdf",
    label: "MDF/Chapas",
    areas: ["marcenaria"],
    color: "bg-amber-700/20 text-amber-200",
  },
  {
    value: "ferragem_moveis",
    label: "Ferragens móveis",
    areas: ["marcenaria"],
    color: "bg-lime-500/15 text-lime-300",
  },
  {
    value: "fita_borda",
    label: "Fita de borda",
    areas: ["marcenaria"],
    color: "bg-teal-500/15 text-teal-300",
  },
  {
    value: "marmore",
    label: "Mármores/Granitos",
    areas: ["marmoraria"],
    color: "bg-purple-500/15 text-purple-300",
  },
  {
    value: "quartzo",
    label: "Quartzos",
    areas: ["marmoraria"],
    color: "bg-fuchsia-500/15 text-fuchsia-300",
  },
  {
    value: "porcelanato",
    label: "Porcelanatos",
    areas: ["marmoraria"],
    color: "bg-pink-500/15 text-pink-300",
  },
  {
    value: "cola",
    label: "Colas/Silicones",
    areas: ["geral"],
    color: "bg-emerald-500/15 text-emerald-300",
  },
  { value: "outros", label: "Outros", areas: ["geral"], color: "bg-muted text-muted-foreground" },
];

// Espelha o enum `public.inventory_unit`.
export const INVENTORY_UNITS: ReadonlyArray<InventoryUnidade> = ["un", "m", "m2", "kg", "pc", "cx"];

export function categoriaMeta(value: string) {
  return INVENTORY_CATEGORIES.find((c) => c.value === value);
}

/** Join opcional do catálogo global (fallback de imagem / proveniência). Sem sync. */
export type InventoryManufacturerProductRef = {
  id: string;
  name: string;
  source_code: string;
  primary_image_path: string | null;
  active: boolean;
  product_manufacturers: { id: string; name: string; active: boolean } | null;
};

export type InventoryItem = {
  id: string;
  owner_id: string;
  company_id: string;
  categoria: InventoryCategoria;
  nome: string;
  descricao: string | null;
  unidade: InventoryUnidade;
  quantidade: number;
  estoque_minimo: number;
  custo_unit: number;
  preco_venda: number;
  fornecedor: string | null;
  supplier_id: string | null;
  localizacao: string | null;
  imagem_url: string | null;
  observacoes: string | null;
  sku: string | null;
  ncm: string | null;
  ativo: boolean;
  /** true = criado via Projeto → Adicionar ao estoque. */
  originado_de_projeto: boolean;
  /**
   * Origem no catálogo global (snapshot na adoção). Não sincroniza automaticamente
   * com manufacturer_products após a criação.
   */
  manufacturer_product_id: string | null;
  /** Presente quando a query faz join (listagem/detalhe). */
  manufacturer_product?: InventoryManufacturerProductRef | null;
  created_at: string;
  updated_at: string;
};

// Campos editáveis pelo formulário — nunca id/owner_id/company_id/timestamps.
export type InventoryItemInput = {
  categoria: InventoryCategoria;
  nome: string;
  descricao: string | null;
  unidade: InventoryUnidade;
  quantidade: number;
  estoque_minimo: number;
  custo_unit: number;
  preco_venda: number;
  fornecedor: string | null;
  supplier_id: string | null;
  localizacao: string | null;
  observacoes: string | null;
  imagem_url: string | null;
  sku: string | null;
  ncm: string | null;
  ativo: boolean;
  /** Opcional no insert; omitido → default false no banco. true só via Projeto → Estoque. */
  originado_de_projeto?: boolean;
};

// Colunas explícitas — sem `select *`. `location` (duplicata de `localizacao`,
// P-04) e cest/gtin/segment ficam de fora: não têm uso na interface.
// Join manufacturer_products: fallback de imagem + proveniência (sem N+1).
const COLS =
  "id, owner_id, company_id, categoria, nome, descricao, unidade, quantidade, estoque_minimo, custo_unit, preco_venda, fornecedor, supplier_id, localizacao, imagem_url, observacoes, sku, ncm, ativo, originado_de_projeto, manufacturer_product_id, created_at, updated_at, manufacturer_products ( id, name, source_code, primary_image_path, active, product_manufacturers ( id, name, active ) )";

function normalizeManufacturerJoin(raw: unknown): InventoryManufacturerProductRef | null {
  if (!raw) return null;
  const row = Array.isArray(raw) ? raw[0] : raw;
  if (!row || typeof row !== "object") return null;
  const r = row as Record<string, unknown>;
  if (typeof r.id !== "string" || typeof r.name !== "string") return null;
  const mfgRaw = r.product_manufacturers;
  const mfgRow = Array.isArray(mfgRaw) ? mfgRaw[0] : mfgRaw;
  let product_manufacturers: InventoryManufacturerProductRef["product_manufacturers"] = null;
  if (mfgRow && typeof mfgRow === "object") {
    const m = mfgRow as Record<string, unknown>;
    if (typeof m.id === "string" && typeof m.name === "string") {
      product_manufacturers = { id: m.id, name: m.name, active: m.active === true };
    }
  }
  return {
    id: r.id,
    name: r.name,
    source_code: typeof r.source_code === "string" ? r.source_code : "",
    primary_image_path: typeof r.primary_image_path === "string" ? r.primary_image_path : null,
    active: r.active === true,
    product_manufacturers,
  };
}

function mapInventoryRow(row: Record<string, unknown>): InventoryItem {
  const { manufacturer_products, ...rest } = row;
  return {
    ...(rest as Omit<InventoryItem, "manufacturer_product" | "manufacturer_product_id">),
    manufacturer_product_id:
      typeof rest.manufacturer_product_id === "string" ? rest.manufacturer_product_id : null,
    manufacturer_product: normalizeManufacturerJoin(manufacturer_products),
  };
}

const BUCKET = "project-images";
const MAX_BYTES = 5 * 1024 * 1024; // 5 MiB (igual ao limite do bucket)
const ALLOWED_MIME = ["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"];

export function inventoryErrorMessage(error: unknown): string {
  const e = error as { code?: string; message?: string } | null;
  if (e?.code === "42501" || e?.code === "PGRST301")
    return "Você não tem permissão para esta operação.";
  if (e?.code === "23514") return "Valor inválido: quantidade e preços não podem ser negativos.";
  if (e?.code === "23503")
    return "Este item está vinculado a outro registro e não pode ser removido.";
  if (e?.code === "23505") {
    const msg = e.message ?? "";
    if (msg.includes("JA_ADOTADO") || msg.includes("manufacturer_product")) {
      return "Este produto já foi adicionado ao estoque da empresa.";
    }
    return "Já existe um item com esses dados.";
  }
  if (e?.code === "P0002" || (e?.message ?? "").includes("PRODUTO_INDISPONIVEL")) {
    return "Este produto não está mais disponível no catálogo.";
  }
  if (e?.code === "22P02") return "Categoria ou unidade inválida.";
  if (e?.message) return e.message;
  return "Não foi possível concluir a operação. Tente novamente.";
}

// Normaliza texto opcional: apara, corta no limite e converte vazio em NULL.
export function optionalText(value: string | null | undefined, max: number): string | null {
  const v = (value ?? "").trim().slice(0, max);
  return v === "" ? null : v;
}

// REMOVIDA: `nonNegativeNumber(value, decimals)`.
//
// Ela devolvia `0` para toda entrada que não entendia — e era o último degrau
// do defeito da Revisão 31: o `<input type="number">` engolia a vírgula de
// "89,90", o campo chegava aqui vazio e o item era gravado com preço zero sem
// nenhum aviso. Um conversor que nunca falha não deixa a validação falhar.
//
// O lugar dessa conversão agora é `src/lib/numero-campo.ts`
// (`validaNumeroCampo` / `validaCamposNumericos`), que RECUSA a entrada
// inválida com mensagem em vez de assumir zero, e faz o arredondamento por
// casa decimal via `arredonda` — `numeric` do Postgres é exato e continua sem
// receber lixo de ponto flutuante.

export type InventoryFilters = {
  search: string;
  categoria: string; // "todas" | InventoryCategoria
  area: string; // "all" | InventoryArea
  incluirInativos: boolean;
};

export function useInventoryItems(filters: InventoryFilters) {
  const { activeCompany, loading: companyLoading } = useCompany();
  const companyId = activeCompany?.companyId ?? null;
  const term = filters.search
    .trim()
    .replace(/[,()%*]/g, " ")
    .trim();

  const query = useQuery({
    queryKey: [
      "inventory",
      companyId,
      term,
      filters.categoria,
      filters.area,
      filters.incluirInativos,
    ],
    enabled: !!companyId,
    queryFn: async (): Promise<InventoryItem[]> => {
      if (!companyId) return [];
      let q = supabase
        .from("inventory_items")
        .select(COLS)
        .eq("company_id", companyId)
        .order("categoria")
        .order("nome");
      if (!filters.incluirInativos) q = q.eq("ativo", true);
      if (filters.categoria && filters.categoria !== "todas")
        q = q.eq("categoria", filters.categoria as InventoryCategoria);
      if (filters.area && filters.area !== "all") {
        // Área fora da UI atual (URL/estado legado): trata como "Todas" habilitadas.
        if (!ehInventoryUiArea(filters.area)) {
          const cats = inventoryCategoryValuesInUiAreas();
          if (cats.length === 0) return [];
          q = q.in("categoria", cats);
        } else {
          const cats = inventoryCategoryValuesForArea(filters.area);
          if (cats.length === 0) return [];
          q = q.in("categoria", cats);
        }
      } else {
        // "Todas" = somente áreas habilitadas (não traz serralheria/marcenaria/…).
        const cats = inventoryCategoryValuesInUiAreas();
        if (cats.length === 0) return [];
        q = q.in("categoria", cats);
      }
      if (term) {
        q = q.or(`nome.ilike.%${term}%,descricao.ilike.%${term}%,fornecedor.ilike.%${term}%`);
      }
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []).map((row) => mapInventoryRow(row as Record<string, unknown>));
    },
  });

  return { ...query, companyId, hasActiveCompany: !!companyId, companyLoading };
}

// Detalhe por id, sempre escopado à empresa ativa (a RLS reforça).
export function useInventoryItem(id: string | undefined) {
  const { activeCompany, loading: companyLoading } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  const query = useQuery({
    queryKey: ["inventory-item", companyId, id],
    enabled: !!companyId && !!id,
    queryFn: async (): Promise<InventoryItem | null> => {
      if (!companyId || !id) return null;
      const { data, error } = await supabase
        .from("inventory_items")
        .select(COLS)
        .eq("id", id)
        .eq("company_id", companyId)
        .maybeSingle();
      if (error) throw error;
      if (!data) return null;
      return mapInventoryRow(data as Record<string, unknown>);
    },
  });

  return { ...query, companyId, hasActiveCompany: !!companyId, companyLoading };
}

// Envia a imagem para o prefixo da EMPRESA (`<company_id>/estoque/<uuid>.<ext>`),
// validando MIME e tamanho antes. Retorna o PATH (é o que fica em imagem_url —
// URL assinada nunca é persistida). As policies empresariais do bucket chaveiam
// o 1º segmento do path, então esta subpasta já é autorizada.
export async function uploadInventoryImage(companyId: string, file: File): Promise<string> {
  if (!ALLOWED_MIME.includes(file.type)) {
    throw new Error("Formato de imagem não permitido (use JPG, PNG, WEBP, GIF ou AVIF).");
  }
  if (file.size > MAX_BYTES) throw new Error("Imagem acima de 5 MB.");
  const ext =
    (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
  const path = `${companyId}/estoque/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage
    .from(BUCKET)
    .upload(path, file, { upsert: false, contentType: file.type });
  if (error) throw error;
  return path;
}

// Remove um objeto do bucket somente se ele for da empresa ativa. Nunca apaga
// caminho legado por usuário (`<user_id>/estoque/...`) nem de outra empresa.
export async function deleteInventoryImageIfOwnedByCompany(
  companyId: string,
  imagem_url: string | null,
) {
  if (!imagem_url) return;
  const path = imagem_url.startsWith("http") ? null : imagem_url.replace(/^\/+/, "");
  if (!path || !path.startsWith(`${companyId}/`)) return; // legado/externo: não mexe
  await supabase.storage.from(BUCKET).remove([path]);
}

export function useCreateInventoryItem() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (input: InventoryItemInput) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Sua sessão expirou. Entre novamente.");
      const { error } = await supabase.from("inventory_items").insert({
        ...input,
        owner_id: u.user.id, // criador (RLS exige = auth.uid())
        company_id: companyId, // empresa ativa validada (RLS exige membership)
      });
      if (error) {
        // Rollback só de upload próprio do Estoque (`…/estoque/…`).
        // Paths de Biblioteca (`{companyId}/{uuid}`) podem ser compartilhados
        // quando o item nasce a partir de um projeto — não apagar.
        const path = (input.imagem_url ?? "").replace(/^\/+/, "");
        if (path.includes("/estoque/")) {
          await deleteInventoryImageIfOwnedByCompany(companyId, input.imagem_url).catch(() => {});
        }
        throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["inventory"] });
      qc.invalidateQueries({ queryKey: ["effective-inventory"] });
      // Venda Direta / Orçamentos leem o picker — precisa atualizar junto.
      qc.invalidateQueries({ queryKey: ["inventory-picker"] });
    },
  });
}

export function useUpdateInventoryItem() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async ({
      id,
      input,
      previousImage,
    }: {
      id: string;
      input: InventoryItemInput;
      previousImage: string | null;
    }) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      // company_id/owner_id não são enviados — imutáveis (trigger no banco).
      const { data, error } = await supabase
        .from("inventory_items")
        .update(input)
        .eq("id", id)
        .eq("company_id", companyId)
        .select("id");
      if (error) throw error;
      if (!data || data.length === 0) {
        throw new Error("Item não encontrado na empresa ativa ou sem permissão.");
      }
      // Só depois de confirmar, remove a imagem antiga se foi substituída.
      if (previousImage && previousImage !== input.imagem_url) {
        await deleteInventoryImageIfOwnedByCompany(companyId, previousImage).catch(() => {});
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["inventory"] });
      qc.invalidateQueries({ queryKey: ["effective-inventory"] });
      qc.invalidateQueries({ queryKey: ["inventory-item"] });
      qc.invalidateQueries({ queryKey: ["inventory-picker"] });
    },
  });
}

// Desativação/reativação — ação padrão no lugar de apagar o cadastro.
// Item inativo some da listagem (salvo filtro) e do seletor de Orçamentos.
export function useSetInventoryItemActive() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async ({ id, ativo }: { id: string; ativo: boolean }) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      const { data, error } = await supabase
        .from("inventory_items")
        .update({ ativo })
        .eq("id", id)
        .eq("company_id", companyId)
        .select("id");
      if (error) throw error;
      if (!data || data.length === 0) {
        throw new Error("Item não encontrado na empresa ativa ou sem permissão.");
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["inventory"] });
      qc.invalidateQueries({ queryKey: ["effective-inventory"] });
      qc.invalidateQueries({ queryKey: ["inventory-item"] });
    },
  });
}

// Exclusão FÍSICA — ação secundária e explícita. Nenhuma FK referencia
// inventory_items (quote_items não guarda inventory_item_id), então nada é
// apagado em cascata e nenhum orçamento existente muda. A imagem só é removida
// depois que o registro sai, e apenas se estiver no prefixo da empresa.
export function useDeleteInventoryItem() {
  const qc = useQueryClient();
  const { activeCompany } = useCompany();

  return useMutation({
    mutationFn: async (item: Pick<InventoryItem, "id" | "imagem_url">) => {
      const companyId = activeCompany?.companyId;
      if (!companyId) throw new Error("Selecione uma empresa ativa.");
      const { data, error } = await supabase
        .from("inventory_items")
        .delete()
        .eq("id", item.id)
        .eq("company_id", companyId)
        .select("id");
      if (error) throw error;
      if (!data || data.length === 0) {
        throw new Error("Item não encontrado ou sem permissão para excluir.");
      }
      await deleteInventoryImageIfOwnedByCompany(companyId, item.imagem_url).catch(() => {});
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["inventory"] });
      qc.invalidateQueries({ queryKey: ["effective-inventory"] });
      qc.invalidateQueries({ queryKey: ["inventory-item"] });
      qc.invalidateQueries({ queryKey: ["inventory-picker"] });
    },
  });
}

// ---------------------------------------------------------------------------
// Integração OPCIONAL com Orçamentos.
//
// Só itens ATIVOS da empresa ativa. O orçamento nunca depende do Estoque: se
// esta lista vier vazia, o item manual continua sendo o caminho normal.
// ---------------------------------------------------------------------------
export type StockPickerItem = Pick<
  InventoryItem,
  | "id"
  | "nome"
  | "descricao"
  | "categoria"
  | "unidade"
  | "preco_venda"
  | "quantidade"
  | "imagem_url"
  | "originado_de_projeto"
>;

export function useCompanyStockOptions() {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;

  return useQuery({
    queryKey: ["inventory-picker", companyId],
    enabled: !!companyId,
    queryFn: async (): Promise<StockPickerItem[]> => {
      if (!companyId) return [];
      const { data, error } = await supabase
        .from("inventory_items")
        .select(
          "id, nome, descricao, categoria, unidade, preco_venda, quantidade, imagem_url, originado_de_projeto",
        )
        .eq("company_id", companyId)
        .eq("ativo", true)
        .order("nome");
      if (error) throw error;
      return (data ?? []) as StockPickerItem[];
    },
  });
}

// Traduz um item de estoque para os campos de UM item de orçamento.
//
// A regra de cálculo dos Orçamentos (RPC `save_quote_with_items`, migration
// 20260724020000) é: COM largura e altura → preço por m²; SEM dimensões →
// preço por unidade (quantidade × preco_unit). O `unidade` do estoque decide
// qual dos dois o preenchimento propõe:
//   · unidade "m2"  → item dimensionado; dimensões ficam com o usuário (não
//                     inventamos medida) e preco_venda entra como preço por m².
//   · demais        → item por unidade; dimensões vão a ZERO para que a RPC
//                     calcule quantidade × preço.
// Tudo continua editável no formulário do orçamento, e o que é salvo em
// quote_items é um SNAPSHOT — alterar o estoque depois não mexe no orçamento.
export function stockItemToQuoteItem(item: StockPickerItem): {
  descricao: string;
  largura: number;
  altura: number;
  preco_unit: number;
  porM2: boolean;
  /** Path no bucket `project-images` — snapshot para `quote_items.imagem_url`. */
  imagem_url: string | null;
  /** Snapshot da procedência (PDF: imagem grande se true). */
  originado_de_projeto: boolean;
} {
  return {
    descricao: item.nome,
    // Dimensão NUNCA é inventada: zera e deixa o usuário informar quando for por
    // m². Enquanto ficar em zero, a RPC cobra por unidade — o comportamento que
    // já existia para item manual.
    largura: 0,
    altura: 0,
    preco_unit: Number(item.preco_venda) || 0,
    porM2: item.unidade === "m2",
    imagem_url: snapshotImagemUrlFromInventory(item.imagem_url),
    originado_de_projeto: item.originado_de_projeto === true,
  };
}
