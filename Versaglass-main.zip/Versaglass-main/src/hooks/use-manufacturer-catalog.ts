/**
 * Catálogo de Fabricantes (Fase 4A) — leitura via RLS.
 * Sem service role, sem mutações em manufacturer_* / inventory_items.
 */

import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import {
  catalogListRange,
  catalogSortColumn,
  MANUFACTURER_CATALOG_PAGE_SIZE,
  type ManufacturerCatalogSearch,
} from "@/lib/manufacturer-catalog/search";
import {
  buildProductSearchOrFilter,
  sanitizeCatalogSearchTerm,
} from "@/lib/manufacturer-catalog/attributes";

type MfgRow = Database["public"]["Tables"]["product_manufacturers"]["Row"];
type ProdRow = Database["public"]["Tables"]["manufacturer_products"]["Row"];
type InventoryCategory = NonNullable<ProdRow["inventory_category"]>;

export type ManufacturerCatalogListItem = {
  id: string;
  name: string;
  source_code: string;
  product_line: string | null;
  inventory_category: ProdRow["inventory_category"];
  suggested_category: string | null;
  primary_image_path: string | null;
  unit: ProdRow["unit"];
  manufacturer: { id: string; name: string };
};

export type ManufacturerCatalogDetail = ManufacturerCatalogListItem & {
  base_code: string | null;
  description: string | null;
  product_type: string | null;
  attributes: unknown;
  observations: unknown;
  technical_image_paths: string[];
  source_catalog_name: string | null;
  source_catalog_date: string | null;
  source_page: number | null;
  source_excerpt: string | null;
};

export type ManufacturerOption = { id: string; name: string };

type JoinedMfg = { id: string; name: string; active: boolean };

type ListRow = {
  id: string;
  name: string;
  source_code: string;
  product_line: string | null;
  inventory_category: ProdRow["inventory_category"];
  suggested_category: string | null;
  primary_image_path: string | null;
  unit: ProdRow["unit"];
  manufacturer_id: string;
  product_manufacturers: JoinedMfg | JoinedMfg[] | null;
};

type DetailRow = ListRow & {
  base_code: string | null;
  description: string | null;
  product_type: string | null;
  technical_image_paths: unknown;
  attributes: unknown;
  observations: unknown;
  source_catalog_name: string | null;
  source_catalog_date: string | null;
  source_page: number | null;
  source_excerpt: string | null;
};

const LIST_COLS =
  "id, name, source_code, product_line, inventory_category, suggested_category, primary_image_path, unit, manufacturer_id, product_manufacturers!inner ( id, name, active )";

const DETAIL_COLS =
  "id, name, source_code, base_code, description, product_type, product_line, inventory_category, suggested_category, unit, primary_image_path, technical_image_paths, attributes, observations, source_catalog_name, source_catalog_date, source_page, source_excerpt, manufacturer_id, product_manufacturers!inner ( id, name, active )";

const FETCH_PAGE = 500;

function asJoinedMfg(raw: unknown): JoinedMfg | null {
  if (!raw) return null;
  const row = Array.isArray(raw) ? raw[0] : raw;
  if (!row || typeof row !== "object") return null;
  const r = row as Record<string, unknown>;
  if (typeof r.id !== "string" || typeof r.name !== "string") return null;
  return { id: r.id, name: r.name, active: r.active === true };
}

function asStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((v): v is string => typeof v === "string" && v.length > 0);
}

function isInventoryCategory(value: string): value is InventoryCategory {
  return (
    [
      "aluminio",
      "vidro",
      "ferragem",
      "acessorio",
      "perfil",
      "led",
      "cola",
      "outros",
      "aco_metalon",
      "chapa_aco",
      "solda",
      "mdf",
      "ferragem_moveis",
      "fita_borda",
      "marmore",
      "quartzo",
      "porcelanato",
    ] as string[]
  ).includes(value);
}

async function fetchAllActiveManufacturers(): Promise<ManufacturerOption[]> {
  const all: ManufacturerOption[] = [];
  let from = 0;
  for (;;) {
    const { data, error } = await supabase
      .from("product_manufacturers")
      .select("id, name")
      .eq("active", true)
      .order("name", { ascending: true })
      .range(from, from + FETCH_PAGE - 1);
    if (error) throw error;
    const batch = (data ?? []) as Pick<MfgRow, "id" | "name">[];
    if (batch.length === 0) break;
    for (const m of batch) all.push({ id: m.id, name: m.name });
    if (batch.length < FETCH_PAGE) break;
    from += FETCH_PAGE;
  }
  return all;
}

async function findActiveManufacturerIdsByName(term: string): Promise<string[]> {
  const sanitized = sanitizeCatalogSearchTerm(term);
  if (!sanitized) return [];
  const ids: string[] = [];
  let from = 0;
  for (;;) {
    const { data, error } = await supabase
      .from("product_manufacturers")
      .select("id")
      .eq("active", true)
      .ilike("name", `%${sanitized}%`)
      .range(from, from + FETCH_PAGE - 1);
    if (error) throw error;
    const batch = data ?? [];
    if (batch.length === 0) break;
    for (const row of batch) ids.push(row.id as string);
    if (batch.length < FETCH_PAGE) break;
    from += FETCH_PAGE;
  }
  return ids;
}

export function manufacturerCatalogErrorMessage(error: unknown): string {
  const e = error as { code?: string; message?: string } | null;
  if (e?.code === "42501" || e?.code === "PGRST301") {
    return "Você não tem permissão para consultar o catálogo.";
  }
  return "Não foi possível carregar o catálogo. Tente novamente.";
}

export function useManufacturerOptions() {
  return useQuery({
    queryKey: ["manufacturer-catalog", "manufacturers"],
    queryFn: fetchAllActiveManufacturers,
    staleTime: 60_000,
  });
}

export function useManufacturerProductLines(manufacturerId?: string) {
  return useQuery({
    queryKey: ["manufacturer-catalog", "lines", manufacturerId ?? "all"],
    queryFn: async (): Promise<string[]> => {
      const { data, error } = await supabase.rpc("list_manufacturer_product_lines", {
        p_manufacturer_id: manufacturerId ?? null,
      });
      if (error) throw error;
      const lines: string[] = [];
      for (const row of (data ?? []) as { product_line: string }[]) {
        const line = typeof row?.product_line === "string" ? row.product_line.trim() : "";
        if (line) lines.push(line);
      }
      return lines;
    },
    staleTime: 60_000,
  });
}

export function useManufacturerCatalogProducts(search: ManufacturerCatalogSearch) {
  const page = search.page ?? 1;
  const ordem = search.ordem ?? "nome_asc";

  return useQuery({
    queryKey: ["manufacturer-catalog", "list", search],
    queryFn: async (): Promise<{ items: ManufacturerCatalogListItem[]; total: number }> => {
      const { from, to } = catalogListRange(page);
      const sort = catalogSortColumn(ordem);

      let q = supabase
        .from("manufacturer_products")
        .select(LIST_COLS, { count: "exact" })
        .eq("active", true)
        .eq("product_manufacturers.active", true);

      if (search.fabricante) q = q.eq("manufacturer_id", search.fabricante);
      if (search.categoria && isInventoryCategory(search.categoria)) {
        q = q.eq("inventory_category", search.categoria);
      }
      if (search.linha) q = q.eq("product_line", search.linha);

      if (search.q) {
        const mfgIds = await findActiveManufacturerIdsByName(search.q);
        const orFilter = buildProductSearchOrFilter(search.q, mfgIds);
        if (orFilter) q = q.or(orFilter);
      }

      q = q.order(sort.column, { ascending: sort.ascending }).range(from, to);

      const { data, error, count } = await q;
      if (error) throw error;

      const items: ManufacturerCatalogListItem[] = [];
      for (const raw of (data ?? []) as unknown as ListRow[]) {
        const mfg = asJoinedMfg(raw.product_manufacturers);
        if (!mfg || !mfg.active) continue;
        items.push({
          id: raw.id,
          name: raw.name,
          source_code: raw.source_code,
          product_line: raw.product_line ?? null,
          inventory_category: raw.inventory_category,
          suggested_category: raw.suggested_category ?? null,
          primary_image_path: raw.primary_image_path ?? null,
          unit: raw.unit,
          manufacturer: { id: mfg.id, name: mfg.name },
        });
      }

      return { items, total: count ?? items.length };
    },
  });
}

export function useManufacturerCatalogProduct(productId: string | undefined) {
  return useQuery({
    queryKey: ["manufacturer-catalog", "detail", productId],
    enabled: !!productId,
    queryFn: async (): Promise<ManufacturerCatalogDetail | null> => {
      if (!productId) return null;
      const { data, error } = await supabase
        .from("manufacturer_products")
        .select(DETAIL_COLS)
        .eq("id", productId)
        .eq("active", true)
        .eq("product_manufacturers.active", true)
        .maybeSingle();
      if (error) throw error;
      if (!data) return null;
      const row = data as unknown as DetailRow;
      const mfg = asJoinedMfg(row.product_manufacturers);
      if (!mfg || !mfg.active) return null;

      return {
        id: row.id,
        name: row.name,
        source_code: row.source_code,
        base_code: row.base_code ?? null,
        description: row.description ?? null,
        product_type: row.product_type ?? null,
        product_line: row.product_line ?? null,
        inventory_category: row.inventory_category,
        suggested_category: row.suggested_category ?? null,
        unit: row.unit,
        primary_image_path: row.primary_image_path ?? null,
        technical_image_paths: asStringArray(row.technical_image_paths),
        attributes: row.attributes,
        observations: row.observations,
        source_catalog_name: row.source_catalog_name ?? null,
        source_catalog_date: row.source_catalog_date ?? null,
        source_page: row.source_page ?? null,
        source_excerpt: row.source_excerpt ?? null,
        manufacturer: { id: mfg.id, name: mfg.name },
      };
    },
  });
}

export { MANUFACTURER_CATALOG_PAGE_SIZE };
