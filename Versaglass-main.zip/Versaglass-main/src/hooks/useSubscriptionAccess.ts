// =====================================================================
// ⚠️ BLOCO FORA DE USO — "biblioteca bloqueada por assinatura"
//
// Esta tela faz parte de um sistema de assinatura B2C (catálogo de modelos
// premium) que NASCEU NO PRIMEIRO COMMIT do projeto (`a0c7291`, "estado
// inicial recebido") e NUNCA FOI CONECTADO. Está documentado em
// `PLANOS_BIBLIOTECA_ASSINATURA.md`, na raiz do repositório.
//
// Por que "nunca conectado", em fatos (levantamento na Revisão 112):
//
//   • a migration que o documento cita — `20260703030000_subscription_locked_
//     library.sql`, "com tabelas, seeds, funções e RLS" — NÃO EXISTE em
//     `supabase/migrations/`;
//   • as tabelas sobreviveram na baseline (`project_categories`,
//     `project_models`, `plan_model_limits`, `plans`), mas NENHUMA delas tem
//     um único leitor no código, e não há seed em migration alguma;
//   • `user_subscriptions` tem UMA referência em toda a árvore: o `select` de
//     `getUserPlan`. NADA insere. Logo `getUserPlan` devolve sempre "free";
//   • `/planos` e `/upgrade-premium` não têm um `onClick` sequer — não há
//     caminho de upgrade;
//   • `/editor/$modelId` redireciona quando `plan === "free"`, ou seja, para
//     100% dos usuários. A tela do editor é INALCANÇÁVEL hoje;
//   • o bloco é um CIRCUITO FECHADO: `/catalogo`, `/editor/$modelId`,
//     `/planos`, `/upgrade-premium`, `/projeto/$projectId`, `/pdf/$projectId`
//     e as duas telas `/admin/*` só apontam umas para as outras. Nenhuma rota
//     do aplicativo autenticado aponta para dentro dele — nem o menu.
//
// 📌 MANTIDO NO CÓDIGO POR DECISÃO DO RESPONSÁVEL, SEM USO ATIVO.
//    NÃO expandir, NÃO depurar e NÃO usar como referência de padrão até
//    haver decisão de produto. O editor de desenho que funciona é outro:
//    `components/ParametricProjectEditor.tsx` (Projetos › Editar desenho) e
//    `components/engineering/UniversalEngineeringEditor.tsx` (Editor 2D/3D).
// =====================================================================

import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { accessByPlan, getUserPlan } from "@/modules/subscriptions/accessControl";

export function useSubscriptionAccess() {
  return useQuery({
    queryKey: ["subscription-access"],
    queryFn: async () => {
      const { data } = await supabase.auth.getUser();
      const plan = await getUserPlan(data.user?.id ?? null);
      return accessByPlan(plan);
    },
    staleTime: 60_000,
  });
}
