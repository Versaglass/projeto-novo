export type PlanSlug = "free" | "pro" | "premium";

export type ProjectCategory = {
  id: string;
  name: string;
  slug: string;
  description: string;
};

export type ProjectModel = {
  id: string;
  categorySlug: string;
  title: string;
  slug: string;
  description: string;
  image2dUrl: string;
  image3dUrl: string;
  isPremium: boolean;
  freePreview: boolean;
};

export const PLAN_PRICES = {
  pro: 149.9,
  premium: 299.9,
};

export const PROJECT_CATEGORIES: ProjectCategory[] = [
  {
    id: "portoes",
    name: "Portões",
    slug: "portoes",
    description: "Portões de correr, basculante, social e garagem.",
  },
  {
    id: "telhados",
    name: "Telhados",
    slug: "telhados",
    description: "Estruturas para telhados metálicos e cobertura.",
  },
  {
    id: "pergolados",
    name: "Pergolados",
    slug: "pergolados",
    description: "Pergolados metálicos, madeira e vidro.",
  },
  {
    id: "coberturas",
    name: "Coberturas",
    slug: "coberturas",
    description: "Coberturas residenciais, comerciais e industriais.",
  },
  {
    id: "portas-metalicas",
    name: "Portas metálicas",
    slug: "portas-metalicas",
    description: "Portas sociais, pivotantes, correr e segurança.",
  },
  {
    id: "escadas",
    name: "Escadas",
    slug: "escadas",
    description: "Escadas metálicas, caracol, reta e mista.",
  },
  {
    id: "mezaninos",
    name: "Mezaninos",
    slug: "mezaninos",
    description: "Mezaninos comerciais e industriais.",
  },
  {
    id: "galpoes",
    name: "Galpões",
    slug: "galpoes",
    description: "Galpões metálicos, tesouras, pilares e terças.",
  },
  {
    id: "energia-solar",
    name: "Energia solar",
    slug: "energia-solar",
    description: "Estruturas para painéis solares.",
  },
  {
    id: "estruturas-industriais",
    name: "Estruturas industriais",
    slug: "estruturas-industriais",
    description: "Estruturas especiais e industriais.",
  },
];

const img = (name: string) => `/projetos/${name}`;

export const PROJECT_MODELS: ProjectModel[] = [
  {
    id: "portao-basculante-01",
    categorySlug: "portoes",
    title: "Portão basculante residencial",
    slug: "portao-basculante-residencial",
    description: "Modelo editável com quadro, travessas, folha e contrapeso.",
    image2dUrl: img("aco-portao-basculante-2d.svg"),
    image3dUrl: img("aco-portao-basculante-3d.svg"),
    isPremium: false,
    freePreview: true,
  },
  {
    id: "portao-correr-01",
    categorySlug: "portoes",
    title: "Portão de correr com trilho",
    slug: "portao-correr-trilho",
    description: "Portão com roldanas, trilho e quadro metálico.",
    image2dUrl: img("aco-portao-correr-2d.svg"),
    image3dUrl: img("aco-portao-basculante-3d.svg"),
    isPremium: false,
    freePreview: true,
  },
  {
    id: "portao-social-01",
    categorySlug: "portoes",
    title: "Portão social tubular",
    slug: "portao-social-tubular",
    description: "Modelo social com fechadura e barras verticais.",
    image2dUrl: img("aco-grade-janela-2d.svg"),
    image3dUrl: img("aco-aparador-industrial-3d.svg"),
    isPremium: false,
    freePreview: false,
  },
  {
    id: "portao-lambril-01",
    categorySlug: "portoes",
    title: "Portão lambril fechado",
    slug: "portao-lambril-fechado",
    description: "Portão fechado com módulos e reforços internos.",
    image2dUrl: img("aco-portao-basculante-2d.svg"),
    image3dUrl: img("aco-portao-basculante-3d.svg"),
    isPremium: true,
    freePreview: false,
  },
  {
    id: "portao-industrial-01",
    categorySlug: "portoes",
    title: "Portão industrial reforçado",
    slug: "portao-industrial-reforcado",
    description: "Estrutura reforçada para vãos maiores.",
    image2dUrl: img("aco-portao-correr-2d.svg"),
    image3dUrl: img("aco-galpao-tesoura-3d.svg"),
    isPremium: true,
    freePreview: false,
  },
  {
    id: "portao-pivotante-01",
    categorySlug: "portoes",
    title: "Portão pivotante metálico",
    slug: "portao-pivotante-metalico",
    description: "Folha pivotante com dobradiça reforçada.",
    image2dUrl: img("aco-portao-basculante-2d.svg"),
    image3dUrl: img("aco-portao-basculante-3d.svg"),
    isPremium: true,
    freePreview: false,
  },

  ...Array.from({ length: 12 }, (_, i) => ({
    id: `telhado-${i + 1}`,
    categorySlug: "telhados",
    title: `Telhado metálico modelo ${i + 1}`,
    slug: `telhado-metalico-${i + 1}`,
    description: "Estrutura com tesouras, terças e inclinação editável.",
    image2dUrl: img("aco-galpao-tesoura-2d.svg"),
    image3dUrl: img("aco-galpao-tesoura-3d.svg"),
    isPremium: i >= 10,
    freePreview: false,
  })),
  ...Array.from({ length: 6 }, (_, i) => ({
    id: `pergolado-${i + 1}`,
    categorySlug: "pergolados",
    title: `Pergolado modelo ${i + 1}`,
    slug: `pergolado-${i + 1}`,
    description: "Pergolado editável com pilares, vigas e cobertura.",
    image2dUrl: img("aco-mesa-industrial-2d.svg"),
    image3dUrl: img("aco-aparador-industrial-3d.svg"),
    isPremium: i >= 5,
    freePreview: false,
  })),
  ...Array.from({ length: 7 }, (_, i) => ({
    id: `cobertura-${i + 1}`,
    categorySlug: "coberturas",
    title: `Cobertura modelo ${i + 1}`,
    slug: `cobertura-${i + 1}`,
    description: "Cobertura com estrutura e lista de materiais automática.",
    image2dUrl: img("aco-galpao-tesoura-2d.svg"),
    image3dUrl: img("aco-galpao-tesoura-3d.svg"),
    isPremium: i >= 5,
    freePreview: false,
  })),
  ...Array.from({ length: 6 }, (_, i) => ({
    id: `porta-metalica-${i + 1}`,
    categorySlug: "portas-metalicas",
    title: `Porta metálica modelo ${i + 1}`,
    slug: `porta-metalica-${i + 1}`,
    description: "Porta editável com folha, batente e ferragens.",
    image2dUrl: img("aco-grade-janela-2d.svg"),
    image3dUrl: img("aco-portao-basculante-3d.svg"),
    isPremium: i >= 5,
    freePreview: false,
  })),
  ...Array.from({ length: 5 }, (_, i) => ({
    id: `escada-${i + 1}`,
    categorySlug: "escadas",
    title: `Escada metálica modelo ${i + 1}`,
    slug: `escada-metalica-${i + 1}`,
    description: "Escada com degraus, longarinas e guarda-corpo.",
    image2dUrl: img("marmoraria-escada-2d.svg"),
    image3dUrl: img("marmoraria-bancada-pia-3d.svg"),
    isPremium: i >= 3,
    freePreview: false,
  })),
  ...Array.from({ length: 4 }, (_, i) => ({
    id: `mezanino-${i + 1}`,
    categorySlug: "mezaninos",
    title: `Mezanino modelo ${i + 1}`,
    slug: `mezanino-${i + 1}`,
    description: "Mezanino com pilares, vigas, piso e escada.",
    image2dUrl: img("aco-galpao-tesoura-2d.svg"),
    image3dUrl: img("aco-galpao-tesoura-3d.svg"),
    isPremium: i >= 2,
    freePreview: false,
  })),
  ...Array.from({ length: 8 }, (_, i) => ({
    id: `galpao-${i + 1}`,
    categorySlug: "galpoes",
    title: `Galpão premium ${i + 1}`,
    slug: `galpao-premium-${i + 1}`,
    description: "Biblioteca premium de galpões e estruturas industriais.",
    image2dUrl: img("aco-galpao-tesoura-2d.svg"),
    image3dUrl: img("aco-galpao-tesoura-3d.svg"),
    isPremium: true,
    freePreview: false,
  })),
  ...Array.from({ length: 5 }, (_, i) => ({
    id: `solar-${i + 1}`,
    categorySlug: "energia-solar",
    title: `Estrutura solar ${i + 1}`,
    slug: `estrutura-solar-${i + 1}`,
    description: "Estrutura premium para painéis solares.",
    image2dUrl: img("aco-galpao-tesoura-2d.svg"),
    image3dUrl: img("aco-galpao-tesoura-3d.svg"),
    isPremium: true,
    freePreview: false,
  })),
  ...Array.from({ length: 5 }, (_, i) => ({
    id: `industrial-${i + 1}`,
    categorySlug: "estruturas-industriais",
    title: `Estrutura industrial ${i + 1}`,
    slug: `estrutura-industrial-${i + 1}`,
    description: "Modelo premium para estrutura pesada.",
    image2dUrl: img("aco-galpao-tesoura-2d.svg"),
    image3dUrl: img("aco-galpao-tesoura-3d.svg"),
    isPremium: true,
    freePreview: false,
  })),
];

export const PRO_LIMITS: Record<string, number> = {
  portoes: 5,
  telhados: 10,
  pergolados: 5,
  coberturas: 5,
  "portas-metalicas": 5,
  escadas: 3,
  mezaninos: 2,
};

export function canAccessModel(
  userPlan: PlanSlug,
  categorySlug: string,
  modelIndex: number,
  model?: Pick<ProjectModel, "freePreview">,
) {
  if (userPlan === "premium") return true;
  if (userPlan === "pro") {
    const limit = PRO_LIMITS[categorySlug] ?? 0;
    return modelIndex < limit;
  }
  return !!model?.freePreview;
}

export function lockedTarget(userPlan: PlanSlug) {
  return userPlan === "pro" ? "/upgrade-premium" : "/planos";
}
