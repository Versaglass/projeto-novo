import { QueryClient } from "@tanstack/react-query";
import { createRouter } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";

export const getRouter = () => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        // Evita refetch a cada vez que a aba/iframe ganha foco
        // (a prévia do Lovable dispara focus repetidamente).
        refetchOnWindowFocus: false,
        refetchOnReconnect: false,
        // Cache inteligente: evita chamadas repetidas e melhora a navegação entre páginas.
        staleTime: 5 * 60_000,
        gcTime: 30 * 60_000,
        retry: 1,
      },
    },
  });

  const router = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    // Carregamento sob demanda com preload reaproveitável por 30s.
    defaultPreload: "intent",
    defaultPreloadStaleTime: 30_000,
  });

  return router;
};
