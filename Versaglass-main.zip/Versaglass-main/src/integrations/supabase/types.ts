﻿export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      ai_dialog_action_previews: {
        Row: {
          created_at: string
          id: string
          intent: Json
          message_id: string | null
          preview: Json
          risk: string
          session_id: string
          snapshot: Json | null
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          intent?: Json
          message_id?: string | null
          preview?: Json
          risk?: string
          session_id: string
          snapshot?: Json | null
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          intent?: Json
          message_id?: string | null
          preview?: Json
          risk?: string
          session_id?: string
          snapshot?: Json | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_dialog_action_previews_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "ai_dialog_messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ai_dialog_action_previews_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "ai_dialog_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_dialog_executions: {
        Row: {
          created_at: string
          error: string | null
          executed_by: string
          id: string
          preview_id: string
          result: Json
          rollback_available: boolean
          success: boolean
        }
        Insert: {
          created_at?: string
          error?: string | null
          executed_by: string
          id?: string
          preview_id: string
          result?: Json
          rollback_available?: boolean
          success?: boolean
        }
        Update: {
          created_at?: string
          error?: string | null
          executed_by?: string
          id?: string
          preview_id?: string
          result?: Json
          rollback_available?: boolean
          success?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "ai_dialog_executions_preview_id_fkey"
            columns: ["preview_id"]
            isOneToOne: false
            referencedRelation: "ai_dialog_action_previews"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_dialog_messages: {
        Row: {
          audio_url: string | null
          content: string
          created_at: string
          id: string
          metadata: Json
          role: string
          session_id: string
          tokens: number | null
        }
        Insert: {
          audio_url?: string | null
          content: string
          created_at?: string
          id?: string
          metadata?: Json
          role: string
          session_id: string
          tokens?: number | null
        }
        Update: {
          audio_url?: string | null
          content?: string
          created_at?: string
          id?: string
          metadata?: Json
          role?: string
          session_id?: string
          tokens?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "ai_dialog_messages_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "ai_dialog_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_dialog_sessions: {
        Row: {
          created_at: string
          id: string
          mode: string
          status: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          mode?: string
          status?: string
          title?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          mode?: string
          status?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      ai_dialog_suggestions: {
        Row: {
          applied: boolean
          created_at: string
          description: string | null
          id: string
          message_id: string | null
          risk: string
          session_id: string
          title: string
        }
        Insert: {
          applied?: boolean
          created_at?: string
          description?: string | null
          id?: string
          message_id?: string | null
          risk?: string
          session_id: string
          title: string
        }
        Update: {
          applied?: boolean
          created_at?: string
          description?: string | null
          id?: string
          message_id?: string | null
          risk?: string
          session_id?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_dialog_suggestions_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "ai_dialog_messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ai_dialog_suggestions_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "ai_dialog_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_generated_code: {
        Row: {
          company_id: string | null
          copied_count: number
          created_at: string
          description: string | null
          downloaded_count: number
          files: Json
          id: string
          prompt: string
          sql_migrations: Json
          status: string
          title: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          company_id?: string | null
          copied_count?: number
          created_at?: string
          description?: string | null
          downloaded_count?: number
          files?: Json
          id?: string
          prompt: string
          sql_migrations?: Json
          status?: string
          title?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          company_id?: string | null
          copied_count?: number
          created_at?: string
          description?: string | null
          downloaded_count?: number
          files?: Json
          id?: string
          prompt?: string
          sql_migrations?: Json
          status?: string
          title?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      ai_system_settings: {
        Row: {
          category: string
          company_id: string | null
          created_at: string
          created_by: string | null
          id: string
          setting_key: string
          setting_value: Json
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          category?: string
          company_id?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          setting_key: string
          setting_value?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          category?: string
          company_id?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          setting_key?: string
          setting_value?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      platform_settings: {
        Row: {
          key: string
          value: Json
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          key: string
          value?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          key?: string
          value?: Json
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      asaas_webhook_events: {
        Row: {
          company_subscription_id: string | null
          event_id: string
          event_type: string
          processed_at: string | null
          processing_error: string | null
          received_at: string
          resource_id: string | null
        }
        Insert: {
          company_subscription_id?: string | null
          event_id: string
          event_type: string
          processed_at?: string | null
          processing_error?: string | null
          received_at?: string
          resource_id?: string | null
        }
        Update: {
          company_subscription_id?: string | null
          event_id?: string
          event_type?: string
          processed_at?: string | null
          processing_error?: string | null
          received_at?: string
          resource_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "asaas_webhook_events_company_subscription_id_fkey"
            columns: ["company_subscription_id"]
            isOneToOne: false
            referencedRelation: "company_subscriptions"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_logs: {
        Row: {
          action: string
          actor_email: string | null
          actor_id: string | null
          created_at: string
          entity: string | null
          entity_id: string | null
          id: string
          ip: string | null
          metadata: Json
        }
        Insert: {
          action: string
          actor_email?: string | null
          actor_id?: string | null
          created_at?: string
          entity?: string | null
          entity_id?: string | null
          id?: string
          ip?: string | null
          metadata?: Json
        }
        Update: {
          action?: string
          actor_email?: string | null
          actor_id?: string | null
          created_at?: string
          entity?: string | null
          entity_id?: string | null
          id?: string
          ip?: string | null
          metadata?: Json
        }
        Relationships: []
      }
      auth_events: {
        Row: {
          created_at: string
          email: string | null
          id: string
          ip: string | null
          kind: Database["public"]["Enums"]["auth_event_kind"]
          metadata: Json | null
          read_at: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          email?: string | null
          id?: string
          ip?: string | null
          kind: Database["public"]["Enums"]["auth_event_kind"]
          metadata?: Json | null
          read_at?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          ip?: string | null
          kind?: Database["public"]["Enums"]["auth_event_kind"]
          metadata?: Json | null
          read_at?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      billing_notifications: {
        Row: {
          created_at: string
          dias_atraso: number | null
          id: string
          kind: Database["public"]["Enums"]["notif_kind"]
          mensagem: string
          read_at: string | null
          status: Database["public"]["Enums"]["notif_status"]
          subscription_id: string | null
          titulo: string
          user_id: string
          valor: number | null
          vencimento: string | null
        }
        Insert: {
          created_at?: string
          dias_atraso?: number | null
          id?: string
          kind?: Database["public"]["Enums"]["notif_kind"]
          mensagem: string
          read_at?: string | null
          status?: Database["public"]["Enums"]["notif_status"]
          subscription_id?: string | null
          titulo: string
          user_id: string
          valor?: number | null
          vencimento?: string | null
        }
        Update: {
          created_at?: string
          dias_atraso?: number | null
          id?: string
          kind?: Database["public"]["Enums"]["notif_kind"]
          mensagem?: string
          read_at?: string | null
          status?: Database["public"]["Enums"]["notif_status"]
          subscription_id?: string | null
          titulo?: string
          user_id?: string
          valor?: number | null
          vencimento?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "billing_notifications_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscriptions"
            referencedColumns: ["id"]
          },
        ]
      }
      catalog_import_items: {
        Row: {
          review_decision: string
          reviewed_at: string | null
          reviewed_by: string | null
          published_product_id: string | null
          inventory_category: Database["public"]["Enums"]["inventory_category"] | null
          ai_review_required: boolean
          ai_warnings: Json
          attributes: Json
          base_code: string | null
          created_at: string
          description: string | null
          duplicate_product_id: string | null
          id: string
          import_job_id: string
          name: string | null
          normalized_source_code: string | null
          observations: Json
          position: number
          primary_image_staging_path: string | null
          product_line: string | null
          product_type: string | null
          raw_manifest_item: Json
          source_code: string | null
          source_excerpt: string | null
          source_page: number | null
          suggested_category: string | null
          suggested_inventory_category: Database["public"]["Enums"]["inventory_category"] | null
          technical_image_staging_paths: Json
          unit: Database["public"]["Enums"]["inventory_unit"] | null
          updated_at: string
          validation_errors: Json
          validation_status: string
          validation_warnings: Json
        }
        Insert: {
          review_decision?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          published_product_id?: string | null
          inventory_category?: Database["public"]["Enums"]["inventory_category"] | null
          ai_review_required?: boolean
          ai_warnings?: Json
          attributes?: Json
          base_code?: string | null
          created_at?: string
          description?: string | null
          duplicate_product_id?: string | null
          id?: string
          import_job_id: string
          name?: string | null
          normalized_source_code?: string | null
          observations?: Json
          position: number
          primary_image_staging_path?: string | null
          product_line?: string | null
          product_type?: string | null
          raw_manifest_item?: Json
          source_code?: string | null
          source_excerpt?: string | null
          source_page?: number | null
          suggested_category?: string | null
          suggested_inventory_category?: Database["public"]["Enums"]["inventory_category"] | null
          technical_image_staging_paths?: Json
          unit?: Database["public"]["Enums"]["inventory_unit"] | null
          updated_at?: string
          validation_errors?: Json
          validation_status: string
          validation_warnings?: Json
        }
        Update: {
          review_decision?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          published_product_id?: string | null
          inventory_category?: Database["public"]["Enums"]["inventory_category"] | null
          ai_review_required?: boolean
          ai_warnings?: Json
          attributes?: Json
          base_code?: string | null
          created_at?: string
          description?: string | null
          duplicate_product_id?: string | null
          id?: string
          import_job_id?: string
          name?: string | null
          normalized_source_code?: string | null
          observations?: Json
          position?: number
          primary_image_staging_path?: string | null
          product_line?: string | null
          product_type?: string | null
          raw_manifest_item?: Json
          source_code?: string | null
          source_excerpt?: string | null
          source_page?: number | null
          suggested_category?: string | null
          suggested_inventory_category?: Database["public"]["Enums"]["inventory_category"] | null
          technical_image_staging_paths?: Json
          unit?: Database["public"]["Enums"]["inventory_unit"] | null
          updated_at?: string
          validation_errors?: Json
          validation_status?: string
          validation_warnings?: Json
        }
        Relationships: [
          {
            foreignKeyName: "catalog_import_items_import_job_id_fkey"
            columns: ["import_job_id"]
            isOneToOne: false
            referencedRelation: "catalog_import_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "catalog_import_items_duplicate_product_id_fkey"
            columns: ["duplicate_product_id"]
            isOneToOne: false
            referencedRelation: "manufacturer_products"
            referencedColumns: ["id"]
          },
        ]
      }
      catalog_import_jobs: {
        Row: {
          approved_items: number
          rejected_items: number
          published_items: number
          duplicates_at_publish: number
          resolved_manufacturer_id: string | null
          resolved_manufacturer_name: string | null
          completed_at: string | null
          completed_by: string | null
          actual_size_bytes: number | null
          catalog_date: string | null
          catalog_name: string | null
          created_at: string
          created_by: string
          declared_size_bytes: number
          duplicate_items: number
          error_code: string | null
          error_message: string | null
          existing_manufacturer_id: string | null
          id: string
          invalid_items: number
          manufacturer_name: string | null
          normalized_manufacturer_name: string | null
          original_filename: string
          processed_at: string | null
          review_items: number
          schema_version: string | null
          source_filename: string | null
          status: string
          storage_bucket: string
          storage_path: string
          total_items: number
          updated_at: string
          valid_items: number
          warnings: Json
        }
        Insert: {
          actual_size_bytes?: number | null
          approved_items?: number
          rejected_items?: number
          published_items?: number
          duplicates_at_publish?: number
          resolved_manufacturer_id?: string | null
          resolved_manufacturer_name?: string | null
          completed_at?: string | null
          completed_by?: string | null
          catalog_date?: string | null
          catalog_name?: string | null
          created_at?: string
          created_by: string
          declared_size_bytes: number
          duplicate_items?: number
          error_code?: string | null
          error_message?: string | null
          existing_manufacturer_id?: string | null
          id?: string
          invalid_items?: number
          manufacturer_name?: string | null
          normalized_manufacturer_name?: string | null
          original_filename: string
          processed_at?: string | null
          review_items?: number
          schema_version?: string | null
          source_filename?: string | null
          status?: string
          storage_bucket?: string
          storage_path: string
          total_items?: number
          updated_at?: string
          valid_items?: number
          warnings?: Json
        }
        Update: {
          actual_size_bytes?: number | null
          approved_items?: number
          rejected_items?: number
          published_items?: number
          duplicates_at_publish?: number
          resolved_manufacturer_id?: string | null
          resolved_manufacturer_name?: string | null
          completed_at?: string | null
          completed_by?: string | null
          catalog_date?: string | null
          catalog_name?: string | null
          created_at?: string
          created_by?: string
          declared_size_bytes?: number
          duplicate_items?: number
          error_code?: string | null
          error_message?: string | null
          existing_manufacturer_id?: string | null
          id?: string
          invalid_items?: number
          manufacturer_name?: string | null
          normalized_manufacturer_name?: string | null
          original_filename?: string
          processed_at?: string | null
          review_items?: number
          schema_version?: string | null
          source_filename?: string | null
          status?: string
          storage_bucket?: string
          storage_path?: string
          total_items?: number
          updated_at?: string
          valid_items?: number
          warnings?: Json
        }
        Relationships: [
          {
            foreignKeyName: "catalog_import_jobs_existing_manufacturer_id_fkey"
            columns: ["existing_manufacturer_id"]
            isOneToOne: false
            referencedRelation: "product_manufacturers"
            referencedColumns: ["id"]
          },
        ]
      }
      charges: {
        Row: {
          amount: number
          boleto_url: string | null
          company_id: string
          created_at: string
          customer_id: string | null
          description: string | null
          due_date: string | null
          id: string
          net_amount: number | null
          order_service_id: string | null
          owner_id: string
          paid_at: string | null
          payment_link: string | null
          payment_method: string
          pix_copy_paste: string | null
          pix_qrcode: string | null
          platform_fee: number
          provider_charge_id: string | null
          quote_id: string | null
          sale_id: string | null
          status: string
          updated_at: string
        }
        Insert: {
          amount?: number
          boleto_url?: string | null
          company_id: string
          created_at?: string
          customer_id?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          net_amount?: number | null
          order_service_id?: string | null
          owner_id: string
          paid_at?: string | null
          payment_link?: string | null
          payment_method: string
          pix_copy_paste?: string | null
          pix_qrcode?: string | null
          platform_fee?: number
          provider_charge_id?: string | null
          quote_id?: string | null
          sale_id?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          boleto_url?: string | null
          company_id?: string
          created_at?: string
          customer_id?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          net_amount?: number | null
          order_service_id?: string | null
          owner_id?: string
          paid_at?: string | null
          payment_link?: string | null
          payment_method?: string
          pix_copy_paste?: string | null
          pix_qrcode?: string | null
          platform_fee?: number
          provider_charge_id?: string | null
          quote_id?: string | null
          sale_id?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "charges_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "charges_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "charges_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "charges_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "charges_quote_id_fkey"
            columns: ["quote_id"]
            isOneToOne: false
            referencedRelation: "quotes"
            referencedColumns: ["id"]
          },
        ]
      }
      company_members: {
        Row: {
          company_id: string | null
          created_at: string
          id: string
          permissions: Json
          role: string
          status: string
          user_id: string | null
        }
        Insert: {
          company_id?: string | null
          created_at?: string
          id?: string
          permissions?: Json
          role?: string
          status?: string
          user_id?: string | null
        }
        Update: {
          company_id?: string | null
          created_at?: string
          id?: string
          permissions?: Json
          role?: string
          status?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "company_members_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "company_members_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "company_members_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
        ]
      }
      company_invitations: {
        Row: {
          id: string
          company_id: string
          invited_user_id: string
          invited_email: string
          invited_by: string
          proposed_role: string
          status: Database["public"]["Enums"]["company_invitation_status"]
          created_at: string
          expires_at: string
          responded_at: string | null
        }
        Insert: {
          id?: string
          company_id: string
          invited_user_id: string
          invited_email: string
          invited_by: string
          proposed_role?: string
          status?: Database["public"]["Enums"]["company_invitation_status"]
          created_at?: string
          expires_at: string
          responded_at?: string | null
        }
        Update: {
          id?: string
          company_id?: string
          invited_user_id?: string
          invited_email?: string
          invited_by?: string
          proposed_role?: string
          status?: Database["public"]["Enums"]["company_invitation_status"]
          created_at?: string
          expires_at?: string
          responded_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "company_invitations_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      company_module_access: {
        Row: {
          company_id: string | null
          created_at: string
          enabled: boolean
          id: string
          locked_reason: string | null
          module_id: string | null
          plan_id: string | null
          user_id: string | null
        }
        Insert: {
          company_id?: string | null
          created_at?: string
          enabled?: boolean
          id?: string
          locked_reason?: string | null
          module_id?: string | null
          plan_id?: string | null
          user_id?: string | null
        }
        Update: {
          company_id?: string | null
          created_at?: string
          enabled?: boolean
          id?: string
          locked_reason?: string | null
          module_id?: string | null
          plan_id?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "company_module_access_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "company_module_access_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "company_module_access_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "company_module_access_module_id_fkey"
            columns: ["module_id"]
            isOneToOne: false
            referencedRelation: "platform_modules"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "company_module_access_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "platform_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      company_profiles: {
        Row: {
          address: string | null
          city: string | null
          cnpj: string | null
          company_name: string
          created_at: string
          email: string | null
          id: string
          logo_url: string | null
          phone: string | null
          segment: string | null
          state: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          address?: string | null
          city?: string | null
          cnpj?: string | null
          company_name: string
          created_at?: string
          email?: string | null
          id?: string
          logo_url?: string | null
          phone?: string | null
          segment?: string | null
          state?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          address?: string | null
          city?: string | null
          cnpj?: string | null
          company_name?: string
          created_at?: string
          email?: string | null
          id?: string
          logo_url?: string | null
          phone?: string | null
          segment?: string | null
          state?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      company_subscriptions: {
        Row: {
          asaas_checkout_id: string | null
          asaas_customer_id: string | null
          asaas_subscription_id: string | null
          billing_type: string | null
          canceled_at: string | null
          checkout_expires_at: string | null
          checkout_status: string | null
          company_id: string
          created_at: string
          created_by: string | null
          id: string
          last_payment_at: string | null
          next_due_date: string | null
          plan_slug: string
          status: string
          updated_at: string
        }
        Insert: {
          asaas_checkout_id?: string | null
          asaas_customer_id?: string | null
          asaas_subscription_id?: string | null
          billing_type?: string | null
          canceled_at?: string | null
          checkout_expires_at?: string | null
          checkout_status?: string | null
          company_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          last_payment_at?: string | null
          next_due_date?: string | null
          plan_slug: string
          status?: string
          updated_at?: string
        }
        Update: {
          asaas_checkout_id?: string | null
          asaas_customer_id?: string | null
          asaas_subscription_id?: string | null
          billing_type?: string | null
          canceled_at?: string | null
          checkout_expires_at?: string | null
          checkout_status?: string | null
          company_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          last_payment_at?: string | null
          next_due_date?: string | null
          plan_slug?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_subscriptions_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: true
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "company_subscriptions_plan_slug_fkey"
            columns: ["plan_slug"]
            isOneToOne: false
            referencedRelation: "saas_plans"
            referencedColumns: ["slug"]
          },
        ]
      }
      customers: {
        Row: {
          cidade: string | null
          company_id: string | null
          created_at: string
          documento: string | null
          email: string | null
          endereco: string | null
          id: string
          nome: string
          observacoes: string | null
          owner_id: string
          telefone: string | null
          updated_at: string
        }
        Insert: {
          cidade?: string | null
          company_id?: string | null
          created_at?: string
          documento?: string | null
          email?: string | null
          endereco?: string | null
          id?: string
          nome: string
          observacoes?: string | null
          owner_id: string
          telefone?: string | null
          updated_at?: string
        }
        Update: {
          cidade?: string | null
          company_id?: string | null
          created_at?: string
          documento?: string | null
          email?: string | null
          endereco?: string | null
          id?: string
          nome?: string
          observacoes?: string | null
          owner_id?: string
          telefone?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "customers_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "customers_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "customers_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
        ]
      }
      expenses: {
        Row: {
          amount: number
          category: string
          company_id: string
          created_at: string
          description: string
          expense_date: string
          expense_kind: Database["public"]["Enums"]["expense_kind"]
          id: string
          notes: string | null
          owner_id: string
          quote_id: string | null
          updated_at: string
        }
        Insert: {
          amount: number
          category: string
          company_id: string
          created_at?: string
          description: string
          expense_date: string
          expense_kind?: Database["public"]["Enums"]["expense_kind"]
          id?: string
          notes?: string | null
          owner_id: string
          quote_id?: string | null
          updated_at?: string
        }
        Update: {
          amount?: number
          category?: string
          company_id?: string
          created_at?: string
          description?: string
          expense_date?: string
          expense_kind?: Database["public"]["Enums"]["expense_kind"]
          id?: string
          notes?: string | null
          owner_id?: string
          quote_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "expenses_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expenses_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "expenses_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "expenses_quote_id_fkey"
            columns: ["quote_id"]
            isOneToOne: false
            referencedRelation: "quotes"
            referencedColumns: ["id"]
          },
        ]
      }
      fiscal_invoices: {
        Row: {
          access_key: string | null
          canceled_at: string | null
          company_id: string
          created_at: string
          customer_id: string | null
          error_message: string | null
          id: string
          invoice_number: string | null
          invoice_type: string
          issued_at: string | null
          order_service_id: string | null
          pdf_url: string | null
          protocol: string | null
          sale_id: string | null
          status: string
          total_amount: number
          updated_at: string
          xml_url: string | null
        }
        Insert: {
          access_key?: string | null
          canceled_at?: string | null
          company_id: string
          created_at?: string
          customer_id?: string | null
          error_message?: string | null
          id?: string
          invoice_number?: string | null
          invoice_type: string
          issued_at?: string | null
          order_service_id?: string | null
          pdf_url?: string | null
          protocol?: string | null
          sale_id?: string | null
          status?: string
          total_amount?: number
          updated_at?: string
          xml_url?: string | null
        }
        Update: {
          access_key?: string | null
          canceled_at?: string | null
          company_id?: string
          created_at?: string
          customer_id?: string | null
          error_message?: string | null
          id?: string
          invoice_number?: string | null
          invoice_type?: string
          issued_at?: string | null
          order_service_id?: string | null
          pdf_url?: string | null
          protocol?: string | null
          sale_id?: string | null
          status?: string
          total_amount?: number
          updated_at?: string
          xml_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fiscal_invoices_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fiscal_invoices_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "fiscal_invoices_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "fiscal_invoices_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      fiscal_settings: {
        Row: {
          certificate_url: string | null
          city: string | null
          cnpj: string
          company_id: string
          created_at: string
          environment: string
          id: string
          legal_name: string
          municipal_registration: string | null
          provider: string
          state: string | null
          state_registration: string | null
          tax_regime: string | null
          trade_name: string | null
          updated_at: string
        }
        Insert: {
          certificate_url?: string | null
          city?: string | null
          cnpj: string
          company_id: string
          created_at?: string
          environment?: string
          id?: string
          legal_name: string
          municipal_registration?: string | null
          provider?: string
          state?: string | null
          state_registration?: string | null
          tax_regime?: string | null
          trade_name?: string | null
          updated_at?: string
        }
        Update: {
          certificate_url?: string | null
          city?: string | null
          cnpj?: string
          company_id?: string
          created_at?: string
          environment?: string
          id?: string
          legal_name?: string
          municipal_registration?: string | null
          provider?: string
          state?: string | null
          state_registration?: string | null
          tax_regime?: string | null
          trade_name?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fiscal_settings_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: true
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fiscal_settings_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: true
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "fiscal_settings_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: true
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
        ]
      }
      inventory_items: {
        Row: {
          ativo: boolean
          categoria: Database["public"]["Enums"]["inventory_category"]
          cest: string | null
          company_id: string
          created_at: string
          custo_unit: number
          descricao: string | null
          estoque_minimo: number
          fornecedor: string | null
          gtin: string | null
          id: string
          imagem_url: string | null
          localizacao: string | null
          location: string | null
          ncm: string | null
          nome: string
          observacoes: string | null
          originado_de_projeto: boolean
          owner_id: string
          preco_venda: number
          quantidade: number
          segment: string | null
          sku: string | null
          supplier_id: string | null
          unidade: Database["public"]["Enums"]["inventory_unit"]
          updated_at: string
          manufacturer_product_id: string | null
        }
        Insert: {
          ativo?: boolean
          categoria: Database["public"]["Enums"]["inventory_category"]
          cest?: string | null
          company_id: string
          created_at?: string
          custo_unit?: number
          descricao?: string | null
          estoque_minimo?: number
          fornecedor?: string | null
          gtin?: string | null
          id?: string
          imagem_url?: string | null
          localizacao?: string | null
          location?: string | null
          ncm?: string | null
          nome: string
          observacoes?: string | null
          originado_de_projeto?: boolean
          owner_id: string
          preco_venda?: number
          quantidade?: number
          segment?: string | null
          sku?: string | null
          supplier_id?: string | null
          unidade?: Database["public"]["Enums"]["inventory_unit"]
          updated_at?: string
          manufacturer_product_id?: string | null
        }
        Update: {
          ativo?: boolean
          categoria?: Database["public"]["Enums"]["inventory_category"]
          cest?: string | null
          company_id?: string
          created_at?: string
          custo_unit?: number
          descricao?: string | null
          estoque_minimo?: number
          fornecedor?: string | null
          gtin?: string | null
          id?: string
          imagem_url?: string | null
          localizacao?: string | null
          location?: string | null
          ncm?: string | null
          nome?: string
          observacoes?: string | null
          originado_de_projeto?: boolean
          owner_id?: string
          preco_venda?: number
          quantidade?: number
          segment?: string | null
          sku?: string | null
          supplier_id?: string | null
          unidade?: Database["public"]["Enums"]["inventory_unit"]
          updated_at?: string
          manufacturer_product_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "inventory_items_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inventory_items_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "inventory_items_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "inventory_items_manufacturer_product_id_fkey"
            columns: ["manufacturer_product_id"]
            isOneToOne: false
            referencedRelation: "manufacturer_products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inventory_items_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
        ]
      }
      password_reset_tokens: {
        Row: {
          channel: string
          created_at: string
          email: string | null
          expires_at: string
          flow: string
          id: string
          ip_address: string | null
          phone: string | null
          token_hash: string | null
          used_at: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          channel: string
          created_at?: string
          email?: string | null
          expires_at?: string
          flow?: string
          id?: string
          ip_address?: string | null
          phone?: string | null
          token_hash?: string | null
          used_at?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          channel?: string
          created_at?: string
          email?: string | null
          expires_at?: string
          flow?: string
          id?: string
          ip_address?: string | null
          phone?: string | null
          token_hash?: string | null
          used_at?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      manufacturer_products: {
        Row: {
          active: boolean
          attributes: Json
          base_code: string | null
          created_at: string
          description: string | null
          id: string
          inventory_category: Database["public"]["Enums"]["inventory_category"] | null
          manufacturer_id: string
          name: string
          normalized_source_code: string
          observations: Json
          primary_image_path: string | null
          product_line: string | null
          product_type: string | null
          source_catalog_date: string | null
          source_catalog_name: string | null
          source_code: string
          source_excerpt: string | null
          source_page: number | null
          suggested_category: string | null
          technical_image_paths: Json
          unit: Database["public"]["Enums"]["inventory_unit"] | null
          updated_at: string
        }
        Insert: {
          active?: boolean
          attributes?: Json
          base_code?: string | null
          created_at?: string
          description?: string | null
          id?: string
          inventory_category?: Database["public"]["Enums"]["inventory_category"] | null
          manufacturer_id: string
          name: string
          normalized_source_code: string
          observations?: Json
          primary_image_path?: string | null
          product_line?: string | null
          product_type?: string | null
          source_catalog_date?: string | null
          source_catalog_name?: string | null
          source_code: string
          source_excerpt?: string | null
          source_page?: number | null
          suggested_category?: string | null
          technical_image_paths?: Json
          unit?: Database["public"]["Enums"]["inventory_unit"] | null
          updated_at?: string
        }
        Update: {
          active?: boolean
          attributes?: Json
          base_code?: string | null
          created_at?: string
          description?: string | null
          id?: string
          inventory_category?: Database["public"]["Enums"]["inventory_category"] | null
          manufacturer_id?: string
          name?: string
          normalized_source_code?: string
          observations?: Json
          primary_image_path?: string | null
          product_line?: string | null
          product_type?: string | null
          source_catalog_date?: string | null
          source_catalog_name?: string | null
          source_code?: string
          source_excerpt?: string | null
          source_page?: number | null
          suggested_category?: string | null
          technical_image_paths?: Json
          unit?: Database["public"]["Enums"]["inventory_unit"] | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "manufacturer_products_manufacturer_id_fkey"
            columns: ["manufacturer_id"]
            isOneToOne: false
            referencedRelation: "product_manufacturers"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_accounts: {
        Row: {
          account_number: string | null
          account_type: string | null
          agency: string | null
          bank_name: string | null
          cnpj: string | null
          company_id: string
          company_name: string | null
          created_at: string
          financial_email: string | null
          financial_phone: string | null
          id: string
          marketplace_account_id: string | null
          pix_key: string | null
          platform_fee_type: string
          platform_fee_value: number
          provider: string
          status: string
          updated_at: string
        }
        Insert: {
          account_number?: string | null
          account_type?: string | null
          agency?: string | null
          bank_name?: string | null
          cnpj?: string | null
          company_id: string
          company_name?: string | null
          created_at?: string
          financial_email?: string | null
          financial_phone?: string | null
          id?: string
          marketplace_account_id?: string | null
          pix_key?: string | null
          platform_fee_type?: string
          platform_fee_value?: number
          provider?: string
          status?: string
          updated_at?: string
        }
        Update: {
          account_number?: string | null
          account_type?: string | null
          agency?: string | null
          bank_name?: string | null
          cnpj?: string | null
          company_id?: string
          company_name?: string | null
          created_at?: string
          financial_email?: string | null
          financial_phone?: string | null
          id?: string
          marketplace_account_id?: string | null
          pix_key?: string | null
          platform_fee_type?: string
          platform_fee_value?: number
          provider?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payment_accounts_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: true
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payment_accounts_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: true
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "payment_accounts_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: true
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
        ]
      }
      payment_splits: {
        Row: {
          charge_id: string
          company_amount: number
          company_id: string
          created_at: string
          gross_amount: number
          id: string
          platform_amount: number
          provider_split_id: string | null
          status: string
        }
        Insert: {
          charge_id: string
          company_amount?: number
          company_id: string
          created_at?: string
          gross_amount?: number
          id?: string
          platform_amount?: number
          provider_split_id?: string | null
          status?: string
        }
        Update: {
          charge_id?: string
          company_amount?: number
          company_id?: string
          created_at?: string
          gross_amount?: number
          id?: string
          platform_amount?: number
          provider_split_id?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "payment_splits_charge_id_fkey"
            columns: ["charge_id"]
            isOneToOne: false
            referencedRelation: "charges"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payment_splits_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payment_splits_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "payment_splits_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
        ]
      }
      plan_model_limits: {
        Row: {
          allow_all: boolean | null
          category_slug: string
          created_at: string | null
          id: string
          model_limit: number | null
          plan_slug: string
        }
        Insert: {
          allow_all?: boolean | null
          category_slug: string
          created_at?: string | null
          id?: string
          model_limit?: number | null
          plan_slug: string
        }
        Update: {
          allow_all?: boolean | null
          category_slug?: string
          created_at?: string | null
          id?: string
          model_limit?: number | null
          plan_slug?: string
        }
        Relationships: []
      }
      plan_module_access: {
        Row: {
          enabled: boolean
          module_id: string
          plan_id: string
        }
        Insert: {
          enabled?: boolean
          module_id: string
          plan_id: string
        }
        Update: {
          enabled?: boolean
          module_id?: string
          plan_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "plan_module_access_module_id_fkey"
            columns: ["module_id"]
            isOneToOne: false
            referencedRelation: "platform_modules"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "plan_module_access_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "platform_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      plans: {
        Row: {
          active: boolean | null
          billing_cycle: string | null
          created_at: string | null
          id: string
          name: string
          price: number
          slug: string
        }
        Insert: {
          active?: boolean | null
          billing_cycle?: string | null
          created_at?: string | null
          id?: string
          name: string
          price: number
          slug: string
        }
        Update: {
          active?: boolean | null
          billing_cycle?: string | null
          created_at?: string | null
          id?: string
          name?: string
          price?: number
          slug?: string
        }
        Relationships: []
      }
      platform_modules: {
        Row: {
          ativo: boolean
          created_at: string
          descricao: string | null
          id: string
          nome: string
          rota: string | null
          segmento: string
        }
        Insert: {
          ativo?: boolean
          created_at?: string
          descricao?: string | null
          id: string
          nome: string
          rota?: string | null
          segmento: string
        }
        Update: {
          ativo?: boolean
          created_at?: string
          descricao?: string | null
          id?: string
          nome?: string
          rota?: string | null
          segmento?: string
        }
        Relationships: []
      }
      platform_plans: {
        Row: {
          ativo: boolean
          created_at: string
          descricao: string | null
          id: string
          nome: string
          segmento: string
        }
        Insert: {
          ativo?: boolean
          created_at?: string
          descricao?: string | null
          id: string
          nome: string
          segmento: string
        }
        Update: {
          ativo?: boolean
          created_at?: string
          descricao?: string | null
          id?: string
          nome?: string
          segmento?: string
        }
        Relationships: []
      }
      platform_project_catalog: {
        Row: {
          acabamento: Database["public"]["Enums"]["project_acabamento"] | null
          altura_padrao: number
          area: Database["public"]["Enums"]["project_area"]
          ativo: boolean
          categoria: Database["public"]["Enums"]["project_category"]
          cor: Database["public"]["Enums"]["project_cor_refletivo"] | null
          created_at: string
          created_by: string | null
          descricao: string | null
          espessura: string | null
          id: string
          imagem_url: string | null
          largura_padrao: number
          nome: string
          observacoes: string | null
          ordem: number
          preco_referencia_m2: number
          project_data: Json | null
          subtipo: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          acabamento?: Database["public"]["Enums"]["project_acabamento"] | null
          altura_padrao?: number
          area: Database["public"]["Enums"]["project_area"]
          ativo?: boolean
          categoria: Database["public"]["Enums"]["project_category"]
          cor?: Database["public"]["Enums"]["project_cor_refletivo"] | null
          created_at?: string
          created_by?: string | null
          descricao?: string | null
          espessura?: string | null
          id?: string
          imagem_url?: string | null
          largura_padrao?: number
          nome: string
          observacoes?: string | null
          ordem?: number
          preco_referencia_m2?: number
          project_data?: Json | null
          subtipo: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          acabamento?: Database["public"]["Enums"]["project_acabamento"] | null
          altura_padrao?: number
          area?: Database["public"]["Enums"]["project_area"]
          ativo?: boolean
          categoria?: Database["public"]["Enums"]["project_category"]
          cor?: Database["public"]["Enums"]["project_cor_refletivo"] | null
          created_at?: string
          created_by?: string | null
          descricao?: string | null
          espessura?: string | null
          id?: string
          imagem_url?: string | null
          largura_padrao?: number
          nome?: string
          observacoes?: string | null
          ordem?: number
          preco_referencia_m2?: number
          project_data?: Json | null
          subtipo?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      product_manufacturers: {
        Row: {
          active: boolean
          created_at: string
          id: string
          name: string
          normalized_name: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          id?: string
          name: string
          normalized_name: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          id?: string
          name?: string
          normalized_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          ativo: boolean
          created_at: string
          empresa: string | null
          id: string
          nome: string | null
          permissions: Json
          segment: string
          telefone: string | null
          updated_at: string
        }
        Insert: {
          ativo?: boolean
          created_at?: string
          empresa?: string | null
          id: string
          nome?: string | null
          permissions?: Json
          segment?: string
          telefone?: string | null
          updated_at?: string
        }
        Update: {
          ativo?: boolean
          created_at?: string
          empresa?: string | null
          id?: string
          nome?: string | null
          permissions?: Json
          segment?: string
          telefone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      project_categories: {
        Row: {
          active: boolean | null
          created_at: string | null
          id: string
          name: string
          slug: string
        }
        Insert: {
          active?: boolean | null
          created_at?: string | null
          id?: string
          name: string
          slug: string
        }
        Update: {
          active?: boolean | null
          created_at?: string | null
          id?: string
          name?: string
          slug?: string
        }
        Relationships: []
      }
      project_models: {
        Row: {
          active: boolean | null
          category_id: string | null
          created_at: string | null
          description: string | null
          file_url: string | null
          free_preview: boolean | null
          id: string
          image_2d_url: string | null
          image_3d_url: string | null
          is_premium: boolean | null
          slug: string
          title: string
        }
        Insert: {
          active?: boolean | null
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          file_url?: string | null
          free_preview?: boolean | null
          id?: string
          image_2d_url?: string | null
          image_3d_url?: string | null
          is_premium?: boolean | null
          slug: string
          title: string
        }
        Update: {
          active?: boolean | null
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          file_url?: string | null
          free_preview?: boolean | null
          id?: string
          image_2d_url?: string | null
          image_3d_url?: string | null
          is_premium?: boolean | null
          slug?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_models_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "project_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      project_templates: {
        Row: {
          acabamento: Database["public"]["Enums"]["project_acabamento"] | null
          altura_padrao: number
          area: Database["public"]["Enums"]["project_area"]
          ativo: boolean
          categoria: Database["public"]["Enums"]["project_category"]
          company_id: string
          cor: Database["public"]["Enums"]["project_cor_refletivo"] | null
          created_at: string
          descricao: string | null
          espessura: string | null
          id: string
          imagem_url: string | null
          largura_padrao: number
          nome: string
          observacoes: string | null
          owner_id: string
          preco_m2: number
          project_data: Json | null
          subtipo: string
          tipo: string | null
          updated_at: string
        }
        Insert: {
          acabamento?: Database["public"]["Enums"]["project_acabamento"] | null
          altura_padrao?: number
          area: Database["public"]["Enums"]["project_area"]
          ativo?: boolean
          categoria: Database["public"]["Enums"]["project_category"]
          company_id: string
          cor?: Database["public"]["Enums"]["project_cor_refletivo"] | null
          created_at?: string
          descricao?: string | null
          espessura?: string | null
          id?: string
          imagem_url?: string | null
          largura_padrao?: number
          nome: string
          observacoes?: string | null
          owner_id: string
          preco_m2?: number
          project_data?: Json | null
          subtipo: string
          tipo?: string | null
          updated_at?: string
        }
        Update: {
          acabamento?: Database["public"]["Enums"]["project_acabamento"] | null
          altura_padrao?: number
          area?: Database["public"]["Enums"]["project_area"]
          ativo?: boolean
          categoria?: Database["public"]["Enums"]["project_category"]
          company_id?: string
          cor?: Database["public"]["Enums"]["project_cor_refletivo"] | null
          created_at?: string
          descricao?: string | null
          espessura?: string | null
          id?: string
          imagem_url?: string | null
          largura_padrao?: number
          nome?: string
          observacoes?: string | null
          owner_id?: string
          preco_m2?: number
          project_data?: Json | null
          subtipo?: string
          tipo?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_templates_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "project_templates_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "project_templates_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
        ]
      }
      quote_items: {
        Row: {
          altura: number
          ambiente: string | null
          company_id: string | null
          created_at: string
          descricao: string
          drawing_data: Json
          drawing_notes: string | null
          id: string
          imagem_url: string | null
          largura: number
          m2: number
          ordem: number
          originado_de_projeto: boolean
          preco_unit: number
          project_data: Json | null
          quantidade: number
          quote_id: string
          subtotal: number
          tipo_projeto:
            | Database["public"]["Enums"]["quote_item_tipo_projeto"]
            | null
          updated_at: string
        }
        Insert: {
          altura?: number
          ambiente?: string | null
          company_id?: string | null
          created_at?: string
          descricao: string
          drawing_data?: Json
          drawing_notes?: string | null
          id?: string
          imagem_url?: string | null
          largura?: number
          m2?: number
          ordem?: number
          originado_de_projeto?: boolean
          preco_unit?: number
          project_data?: Json | null
          quantidade?: number
          quote_id: string
          subtotal?: number
          tipo_projeto?:
            | Database["public"]["Enums"]["quote_item_tipo_projeto"]
            | null
          updated_at?: string
        }
        Update: {
          altura?: number
          ambiente?: string | null
          company_id?: string | null
          created_at?: string
          descricao?: string
          drawing_data?: Json
          drawing_notes?: string | null
          id?: string
          imagem_url?: string | null
          largura?: number
          m2?: number
          ordem?: number
          originado_de_projeto?: boolean
          preco_unit?: number
          project_data?: Json | null
          quantidade?: number
          quote_id?: string
          subtotal?: number
          tipo_projeto?:
            | Database["public"]["Enums"]["quote_item_tipo_projeto"]
            | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "quote_items_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quote_items_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "quote_items_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "quote_items_quote_id_fkey"
            columns: ["quote_id"]
            isOneToOne: false
            referencedRelation: "quotes"
            referencedColumns: ["id"]
          },
        ]
      }
      quotes: {
        Row: {
          acrescimo: number
          company_id: string | null
          created_at: string
          customer_id: string
          desconto: number
          etapa: Database["public"]["Enums"]["quote_stage"]
          id: string
          instalacao_em: string | null
          numero: number
          observacoes: string | null
          owner_id: string
          status: Database["public"]["Enums"]["quote_status"]
          total: number
          updated_at: string
          validade_dias: number
        }
        Insert: {
          acrescimo?: number
          company_id?: string | null
          created_at?: string
          customer_id: string
          desconto?: number
          etapa?: Database["public"]["Enums"]["quote_stage"]
          id?: string
          instalacao_em?: string | null
          numero?: number
          observacoes?: string | null
          owner_id: string
          status?: Database["public"]["Enums"]["quote_status"]
          total?: number
          updated_at?: string
          validade_dias?: number
        }
        Update: {
          acrescimo?: number
          company_id?: string | null
          created_at?: string
          customer_id?: string
          desconto?: number
          etapa?: Database["public"]["Enums"]["quote_stage"]
          id?: string
          instalacao_em?: string | null
          numero?: number
          observacoes?: string | null
          owner_id?: string
          status?: Database["public"]["Enums"]["quote_status"]
          total?: number
          updated_at?: string
          validade_dias?: number
        }
        Relationships: [
          {
            foreignKeyName: "quotes_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quotes_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "quotes_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "quotes_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      recurring_charges: {
        Row: {
          amount: number
          company_id: string
          created_at: string
          customer_id: string | null
          end_date: string | null
          frequency: string
          id: string
          next_charge_date: string
          payment_method: string
          start_date: string
          status: string
          updated_at: string
        }
        Insert: {
          amount?: number
          company_id: string
          created_at?: string
          customer_id?: string | null
          end_date?: string | null
          frequency: string
          id?: string
          next_charge_date: string
          payment_method: string
          start_date: string
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          company_id?: string
          created_at?: string
          customer_id?: string | null
          end_date?: string | null
          frequency?: string
          id?: string
          next_charge_date?: string
          payment_method?: string
          start_date?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "recurring_charges_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "recurring_charges_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "recurring_charges_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "recurring_charges_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      saas_plans: {
        Row: {
          active: boolean
          created_at: string
          cycle: string
          name: string
          price_monthly: number
          slug: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          cycle: string
          name: string
          price_monthly: number
          slug: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          cycle?: string
          name?: string
          price_monthly?: number
          slug?: string
          updated_at?: string
        }
        Relationships: []
      }
      sale_items: {
        Row: {
          altura: number
          company_id: string
          created_at: string
          desconto: number
          descricao: string
          id: string
          inventory_item_id: string | null
          largura: number
          m2: number
          ordem: number
          preco_unit: number
          quantidade: number
          quantidade_baixa: number
          sale_id: string
          subtotal: number
          unidade: Database["public"]["Enums"]["inventory_unit"]
          updated_at: string
        }
        Insert: {
          altura?: number
          company_id: string
          created_at?: string
          desconto?: number
          descricao: string
          id?: string
          inventory_item_id?: string | null
          largura?: number
          m2?: number
          ordem?: number
          preco_unit?: number
          quantidade: number
          quantidade_baixa?: number
          sale_id: string
          subtotal?: number
          unidade?: Database["public"]["Enums"]["inventory_unit"]
          updated_at?: string
        }
        Update: {
          altura?: number
          company_id?: string
          created_at?: string
          desconto?: number
          descricao?: string
          id?: string
          inventory_item_id?: string | null
          largura?: number
          m2?: number
          ordem?: number
          preco_unit?: number
          quantidade?: number
          quantidade_baixa?: number
          sale_id?: string
          subtotal?: number
          unidade?: Database["public"]["Enums"]["inventory_unit"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sale_items_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sale_items_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "sale_items_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "sale_items_inventory_item_id_fkey"
            columns: ["inventory_item_id"]
            isOneToOne: false
            referencedRelation: "inventory_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sale_items_sale_id_fkey"
            columns: ["sale_id"]
            isOneToOne: false
            referencedRelation: "sales"
            referencedColumns: ["id"]
          },
        ]
      }
      sales: {
        Row: {
          acrescimo: number
          cancelada_em: string | null
          cancelada_por: string | null
          cliente_nome: string | null
          company_id: string
          created_at: string
          customer_id: string | null
          desconto: number
          forma_pagamento: Database["public"]["Enums"]["sale_payment_method"]
          id: string
          motivo_cancelamento: string | null
          numero: number
          observacoes: string | null
          owner_id: string
          status: Database["public"]["Enums"]["sale_status"]
          subtotal: number
          total: number
          updated_at: string
        }
        Insert: {
          acrescimo?: number
          cancelada_em?: string | null
          cancelada_por?: string | null
          cliente_nome?: string | null
          company_id: string
          created_at?: string
          customer_id?: string | null
          desconto?: number
          forma_pagamento?: Database["public"]["Enums"]["sale_payment_method"]
          id?: string
          motivo_cancelamento?: string | null
          numero?: number
          observacoes?: string | null
          owner_id: string
          status?: Database["public"]["Enums"]["sale_status"]
          subtotal?: number
          total?: number
          updated_at?: string
        }
        Update: {
          acrescimo?: number
          cancelada_em?: string | null
          cancelada_por?: string | null
          cliente_nome?: string | null
          company_id?: string
          created_at?: string
          customer_id?: string | null
          desconto?: number
          forma_pagamento?: Database["public"]["Enums"]["sale_payment_method"]
          id?: string
          motivo_cancelamento?: string | null
          numero?: number
          observacoes?: string | null
          owner_id?: string
          status?: Database["public"]["Enums"]["sale_status"]
          subtotal?: number
          total?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sales_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sales_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "sales_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "sales_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      security_events: {
        Row: {
          action: string
          company_id: string | null
          created_at: string
          email: string | null
          flow: string
          id: string
          ip_address: string | null
          metadata: Json
          phone: string | null
          success: boolean
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          company_id?: string | null
          created_at?: string
          email?: string | null
          flow: string
          id?: string
          ip_address?: string | null
          metadata?: Json
          phone?: string | null
          success?: boolean
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          company_id?: string | null
          created_at?: string
          email?: string | null
          flow?: string
          id?: string
          ip_address?: string | null
          metadata?: Json
          phone?: string | null
          success?: boolean
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      security_lockouts: {
        Row: {
          created_at: string
          email: string | null
          id: string
          locked_until: string
          phone: string | null
          reason: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          email?: string | null
          id?: string
          locked_until: string
          phone?: string | null
          reason: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          locked_until?: string
          phone?: string | null
          reason?: string
          user_id?: string | null
        }
        Relationships: []
      }
      server_logs: {
        Row: {
          action: string
          created_at: string
          duration_ms: number | null
          id: string
          level: Database["public"]["Enums"]["server_log_level"]
          message: string | null
          metadata: Json
          status: number | null
          user_email: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          duration_ms?: number | null
          id?: string
          level?: Database["public"]["Enums"]["server_log_level"]
          message?: string | null
          metadata?: Json
          status?: number | null
          user_email?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          duration_ms?: number | null
          id?: string
          level?: Database["public"]["Enums"]["server_log_level"]
          message?: string | null
          metadata?: Json
          status?: number | null
          user_email?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      service_orders: {
        Row: {
          company_id: string
          created_at: string
          custo: number
          customer_id: string | null
          data_instalacao: string | null
          data_medicao: string | null
          etapa: Database["public"]["Enums"]["service_order_stage"]
          id: string
          numero: number
          observacoes: string | null
          owner_id: string
          quote_id: string | null
          responsavel: string | null
          segmento: Database["public"]["Enums"]["service_order_segment"]
          status: Database["public"]["Enums"]["service_order_status"]
          titulo: string
          updated_at: string
          valor: number
        }
        Insert: {
          company_id: string
          created_at?: string
          custo?: number
          customer_id?: string | null
          data_instalacao?: string | null
          data_medicao?: string | null
          etapa?: Database["public"]["Enums"]["service_order_stage"]
          id?: string
          numero?: number
          observacoes?: string | null
          owner_id: string
          quote_id?: string | null
          responsavel?: string | null
          segmento?: Database["public"]["Enums"]["service_order_segment"]
          status?: Database["public"]["Enums"]["service_order_status"]
          titulo: string
          updated_at?: string
          valor?: number
        }
        Update: {
          company_id?: string
          created_at?: string
          custo?: number
          customer_id?: string | null
          data_instalacao?: string | null
          data_medicao?: string | null
          etapa?: Database["public"]["Enums"]["service_order_stage"]
          id?: string
          numero?: number
          observacoes?: string | null
          owner_id?: string
          quote_id?: string | null
          responsavel?: string | null
          segmento?: Database["public"]["Enums"]["service_order_segment"]
          status?: Database["public"]["Enums"]["service_order_status"]
          titulo?: string
          updated_at?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "service_orders_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_orders_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_orders_quote_id_fkey"
            columns: ["quote_id"]
            isOneToOne: false
            referencedRelation: "quotes"
            referencedColumns: ["id"]
          },
        ]
      }
      suppliers: {
        Row: {
          area: Database["public"]["Enums"]["supplier_area"]
          cidade: string | null
          cnpj: string | null
          codigo: string | null
          company_id: string
          created_at: string
          endereco: string | null
          id: string
          nome: string
          observacoes: string | null
          owner_id: string
          prazo_entrega: string | null
          produtos_fornecidos: string | null
          status: Database["public"]["Enums"]["supplier_status"]
          telefone: string | null
          updated_at: string
          vendedor_contato: string | null
          whatsapp: string | null
        }
        Insert: {
          area?: Database["public"]["Enums"]["supplier_area"]
          cidade?: string | null
          cnpj?: string | null
          codigo?: string | null
          company_id: string
          created_at?: string
          endereco?: string | null
          id?: string
          nome: string
          observacoes?: string | null
          owner_id: string
          prazo_entrega?: string | null
          produtos_fornecidos?: string | null
          status?: Database["public"]["Enums"]["supplier_status"]
          telefone?: string | null
          updated_at?: string
          vendedor_contato?: string | null
          whatsapp?: string | null
        }
        Update: {
          area?: Database["public"]["Enums"]["supplier_area"]
          cidade?: string | null
          cnpj?: string | null
          codigo?: string | null
          company_id?: string
          created_at?: string
          endereco?: string | null
          id?: string
          nome?: string
          observacoes?: string | null
          owner_id?: string
          prazo_entrega?: string | null
          produtos_fornecidos?: string | null
          status?: Database["public"]["Enums"]["supplier_status"]
          telefone?: string | null
          updated_at?: string
          vendedor_contato?: string | null
          whatsapp?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "suppliers_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      subscriptions: {
        Row: {
          created_at: string
          dia_vencimento: number
          id: string
          observacoes: string | null
          plano: string
          proximo_vencimento: string
          status: Database["public"]["Enums"]["sub_status"]
          ultimo_pagamento: string | null
          updated_at: string
          user_id: string
          valor: number
        }
        Insert: {
          created_at?: string
          dia_vencimento?: number
          id?: string
          observacoes?: string | null
          plano?: string
          proximo_vencimento?: string
          status?: Database["public"]["Enums"]["sub_status"]
          ultimo_pagamento?: string | null
          updated_at?: string
          user_id: string
          valor?: number
        }
        Update: {
          created_at?: string
          dia_vencimento?: number
          id?: string
          observacoes?: string | null
          plano?: string
          proximo_vencimento?: string
          status?: Database["public"]["Enums"]["sub_status"]
          ultimo_pagamento?: string | null
          updated_at?: string
          user_id?: string
          valor?: number
        }
        Relationships: []
      }
      two_factor_codes: {
        Row: {
          attempts: number
          channel: string
          code_hash: string | null
          company_id: string | null
          created_at: string
          destination: string
          expires_at: string
          id: string
          max_attempts: number
          purpose: string
          user_id: string | null
          verified_at: string | null
        }
        Insert: {
          attempts?: number
          channel: string
          code_hash?: string | null
          company_id?: string | null
          created_at?: string
          destination: string
          expires_at?: string
          id?: string
          max_attempts?: number
          purpose: string
          user_id?: string | null
          verified_at?: string | null
        }
        Update: {
          attempts?: number
          channel?: string
          code_hash?: string | null
          company_id?: string | null
          created_at?: string
          destination?: string
          expires_at?: string
          id?: string
          max_attempts?: number
          purpose?: string
          user_id?: string | null
          verified_at?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_subscriptions: {
        Row: {
          company_id: string | null
          created_at: string | null
          expires_at: string | null
          id: string
          plan_slug: string
          started_at: string | null
          status: string | null
          user_id: string
        }
        Insert: {
          company_id?: string | null
          created_at?: string | null
          expires_at?: string | null
          id?: string
          plan_slug: string
          started_at?: string | null
          status?: string | null
          user_id: string
        }
        Update: {
          company_id?: string | null
          created_at?: string | null
          expires_at?: string | null
          id?: string
          plan_slug?: string
          started_at?: string | null
          status?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_subscriptions_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "company_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_subscriptions_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_fiscal_summary"
            referencedColumns: ["company_id"]
          },
          {
            foreignKeyName: "user_subscriptions_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "platform_payment_summary"
            referencedColumns: ["company_id"]
          },
        ]
      }
    }
    Views: {
      platform_fiscal_summary: {
        Row: {
          authorized_amount: number | null
          authorized_invoices: number | null
          company_id: string | null
          company_name: string | null
          environment: string | null
          processing_invoices: number | null
          provider: string | null
          rejected_invoices: number | null
        }
        Relationships: []
      }
      platform_payment_summary: {
        Row: {
          account_status: string | null
          avg_ticket: number | null
          company_id: string | null
          company_name: string | null
          failed_charges: number | null
          gross_amount: number | null
          paid_charges: number | null
          platform_fees: number | null
          provider: string | null
          total_charges: number | null
        }
        Relationships: []
      }
    }
    Functions: {
      add_company_seller: {
        Args: { p_company_id: string; p_requester: string; p_user_id: string }
        Returns: string
      }
      accept_company_invitation: {
        Args: { p_invitation_id: string }
        Returns: string
      }
      adopt_manufacturer_product_to_inventory: {
        Args: {
          p_company_id: string
          p_manufacturer_product_id: string
          p_nome: string
          p_descricao?: string | null
          p_sku?: string | null
          p_categoria: Database["public"]["Enums"]["inventory_category"]
          p_unidade: Database["public"]["Enums"]["inventory_unit"]
          p_quantidade: number
          p_estoque_minimo: number
          p_custo_unit: number
          p_preco_venda: number
          p_ncm?: string | null
          p_observacoes?: string | null
        }
        Returns: string
      }
      save_manufacturer_product_inventory_item: {
        Args: {
          p_company_id: string
          p_manufacturer_product_id: string
          p_nome: string
          p_categoria: Database["public"]["Enums"]["inventory_category"]
          p_unidade: Database["public"]["Enums"]["inventory_unit"]
          p_quantidade: number
          p_estoque_minimo: number
          p_custo_unit: number
          p_preco_venda: number
          p_descricao?: string | null
          p_sku?: string | null
          p_ncm?: string | null
          p_observacoes?: string | null
          p_fornecedor?: string | null
          p_supplier_id?: string | null
          p_localizacao?: string | null
          p_imagem_url?: string | null
          p_ativo?: boolean
        }
        Returns: {
          inventory_item_id: string
          created: boolean
        }[]
      }
      ensure_manufacturer_product_inventory_item: {
        Args: {
          p_company_id: string
          p_manufacturer_product_id: string
          p_nome?: string | null
          p_descricao?: string | null
          p_sku?: string | null
          p_categoria?: Database["public"]["Enums"]["inventory_category"] | null
          p_unidade?: Database["public"]["Enums"]["inventory_unit"] | null
          p_quantidade?: number | null
          p_estoque_minimo?: number | null
          p_custo_unit?: number | null
          p_preco_venda?: number | null
          p_ncm?: string | null
          p_observacoes?: string | null
          p_fornecedor?: string | null
          p_supplier_id?: string | null
          p_localizacao?: string | null
          p_imagem_url?: string | null
          p_ativo?: boolean | null
        }
        Returns: string
      }
      auth_user_id_by_email: { Args: { p_email: string }; Returns: string }
      can_access_model: {
        Args: {
          _category_slug: string
          _free_preview?: boolean
          _model_index: number
          _user_plan: string
        }
        Returns: boolean
      }
      can_manage_company_estoque: {
        Args: { _company_id: string; _user_id?: string }
        Returns: boolean
      }
      cancel_sale: {
        Args: { p_motivo: string; p_sale_id: string }
        Returns: string
      }
      company_fiscal_dashboard: {
        Args: { _company_id: string }
        Returns: {
          authorized_amount: number
          authorized_count: number
          processing_count: number
          rejected_count: number
        }[]
      }
      company_payment_dashboard: {
        Args: { _company_id: string }
        Returns: {
          expected_receivable: number
          platform_fees: number
          total_boleto: number
          total_card: number
          total_overdue: number
          total_pending: number
          total_pix: number
          total_received: number
        }[]
      }
      create_company_with_owner: {
        Args: {
          p_city?: string
          p_cnpj?: string
          p_company_name: string
          p_email?: string
          p_phone?: string
          p_segment?: string
          p_state?: string
        }
        Returns: Json
      }
      create_manual_charge: {
        Args: {
          p_amount: number
          p_company_id: string
          p_customer_id?: string
          p_description: string
          p_due_date?: string
          p_payment_method?: string
          p_quote_id?: string
        }
        Returns: string
      }
      create_sale_with_items: {
        Args: {
          p_acrescimo?: number
          p_cliente_nome?: string
          p_company_id: string
          p_customer_id?: string
          p_desconto?: number
          p_forma_pagamento?: Database["public"]["Enums"]["sale_payment_method"]
          p_items: Json
          p_observacoes?: string
        }
        Returns: string
      }
      generate_billing_notifications: { Args: never; Returns: number }
      get_finance_cashflow: {
        Args: {
          p_company_id: string
          p_end: string
          p_granularity?: string
          p_start: string
        }
        Returns: Json
      }
      get_finance_summary: {
        Args: { p_company_id: string; p_end: string; p_start: string }
        Returns: Json
      }
      get_user_plan: { Args: { _user_id: string }; Returns: string }
      has_permission: {
        Args: { _perm: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      publish_catalog_import_batch: {
        Args: {
          p_job_id: string
          p_manufacturer_id: string | null
          p_new_manufacturer_name: string | null
          p_new_manufacturer_normalized_name: string | null
          p_products: Json
        }
        Returns: Json
      }
      list_manufacturer_product_lines: {
        Args: { p_manufacturer_id?: string | null }
        Returns: { product_line: string }[]
      }
      is_company_admin: {
        Args: { _company_id: string; _user_id?: string }
        Returns: boolean
      }
      is_company_member: {
        Args: { _company_id: string; _user_id?: string }
        Returns: boolean
      }
      is_company_owner: {
        Args: { _company_id: string; _user_id?: string }
        Returns: boolean
      }
      is_company_owner_or_admin: {
        Args: { _company_id: string; _user_id?: string }
        Returns: boolean
      }
      is_platform_admin: { Args: { _user_id?: string }; Returns: boolean }
      list_company_members: {
        Args: { p_company_id: string }
        Returns: {
          convite_pendente: boolean
          created_at: string
          email: string
          nome: string
          role: string
          status: string
          user_id: string
        }[]
      }
      list_my_pending_company_invitations: {
        Args: Record<PropertyKey, never>
        Returns: {
          company_id: string
          company_name: string
          created_at: string
          expires_at: string
          id: string
          invited_by_nome: string
          proposed_role: string
        }[]
      }
      reject_company_invitation: {
        Args: { p_invitation_id: string }
        Returns: string
      }
      mark_charge_paid: {
        Args: { p_charge_id: string; p_paid_at?: string }
        Returns: undefined
      }
      update_manual_charge: {
        Args: {
          p_charge_id: string
          p_amount: number
          p_description: string
          p_customer_id?: string
          p_due_date?: string
          p_quote_id?: string
        }
        Returns: undefined
      }
      project_image_can_manage: { Args: { _seg: string }; Returns: boolean }
      project_image_is_member: { Args: { _seg: string }; Returns: boolean }
      save_quote_with_items: {
        Args: {
          p_acrescimo?: number
          p_company_id: string
          p_customer_id: string
          p_desconto?: number
          p_items: Json
          p_observacoes?: string
          p_quote_id?: string
          p_status?: Database["public"]["Enums"]["quote_status"]
          p_validade_dias?: number
        }
        Returns: string
      }
      subscription_state: {
        Args: {
          _proximo: string
          _status: Database["public"]["Enums"]["sub_status"]
        }
        Returns: string
      }
    }
    Enums: {
      app_role: "admin" | "vendedor" | "instalador"
      company_invitation_status:
        | "pending"
        | "accepted"
        | "rejected"
        | "expired"
        | "cancelled"
      auth_event_kind:
        | "signup"
        | "login_success"
        | "login_error"
        | "payment"
        | "subscription_created"
      expense_kind: "operacional" | "pessoal"
      inventory_category:
        | "aluminio"
        | "vidro"
        | "ferragem"
        | "acessorio"
        | "perfil"
        | "led"
        | "cola"
        | "outros"
        | "aco_metalon"
        | "chapa_aco"
        | "solda"
        | "mdf"
        | "ferragem_moveis"
        | "fita_borda"
        | "marmore"
        | "quartzo"
        | "porcelanato"
      inventory_unit: "m" | "m2" | "un" | "kg" | "pc" | "cx"
      notif_kind: "lembrete" | "atraso" | "aviso"
      notif_status: "pendente" | "enviada" | "lida"
      project_acabamento: "cortado" | "lapidado" | "bisote" | "com_moldura"
      project_area: "vidracaria" | "esquadrias" | "serralheria" | "marcenaria" | "marmoraria"
      project_category:
        | "vidro_comum"
        | "temperado"
        | "espelho"
        | "esquadria"
        | "refletivo"
        | "organico"
        | "canelado"
      project_cor_refletivo:
        | "prata"
        | "neutro"
        | "champanhe"
        | "cinza"
        | "verde"
        | "azul"
      quote_item_tipo_projeto:
        | "janela"
        | "porta"
        | "fixo"
        | "box"
        | "fechamento_pia"
        | "espelho"
        | "bascula_maxiar_pivotante"
        | "guarda_corpo"
        | "reposicao"
        | "sacadas"
        | "articulados"
        | "muro"
        | "vitrine"
        | "janela_esquadrias"
        | "porta_esquadrias"
        | "maxim_ar_esquadrias"
        | "fixos_esquadrias"
        | "portao_esquadrias"
        | "fachada_esquadrias"
        | "porta_pivotante_esquadrias"
        | "diversos_esquadrias"
        | "basculantes_esquadrias"
        | "janela_pivotante_esquadrias"
        | "camarao_esquadrias"
        | "janela_abrir_esquadrias"
        | "gradil_esquadrias"
      quote_stage: "orcamento" | "producao" | "instalacao" | "pago"
      quote_status: "rascunho" | "enviado" | "aprovado" | "recusado"
      sale_payment_method:
        | "pix"
        | "dinheiro"
        | "cartao"
        | "boleto"
        | "parcelado"
        | "outro"
      sale_status: "finalizada" | "cancelada"
      server_log_level: "info" | "warn" | "error"
      service_order_segment:
        | "vidracaria"
        | "serralheria"
        | "esquadrias"
        | "marcenaria"
        | "marmoraria"
      service_order_stage:
        | "orcamento"
        | "medicao"
        | "producao"
        | "corte"
        | "instalacao"
        | "finalizado"
        | "pago"
      service_order_status: "ativo" | "atrasado" | "finalizado" | "cancelado"
      supplier_area:
        | "vidracaria"
        | "serralheria"
        | "esquadrias"
        | "marcenaria"
        | "marmoraria"
        | "geral"
      supplier_status: "ativo" | "inativo" | "bloqueado"
      sub_status: "ativo" | "suspenso" | "cancelado"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "vendedor", "instalador"],
      company_invitation_status: [
        "pending",
        "accepted",
        "rejected",
        "expired",
        "cancelled",
      ],
      auth_event_kind: [
        "signup",
        "login_success",
        "login_error",
        "payment",
        "subscription_created",
      ],
      expense_kind: ["operacional", "pessoal"],
      inventory_category: [
        "aluminio",
        "vidro",
        "ferragem",
        "acessorio",
        "perfil",
        "led",
        "cola",
        "outros",
        "aco_metalon",
        "chapa_aco",
        "solda",
        "mdf",
        "ferragem_moveis",
        "fita_borda",
        "marmore",
        "quartzo",
        "porcelanato",
      ],
      inventory_unit: ["m", "m2", "un", "kg", "pc", "cx"],
      notif_kind: ["lembrete", "atraso", "aviso"],
      notif_status: ["pendente", "enviada", "lida"],
      project_acabamento: ["cortado", "lapidado", "bisote", "com_moldura"],
      project_area: ["vidracaria", "esquadrias", "serralheria", "marcenaria", "marmoraria"],
      project_category: [
        "vidro_comum",
        "temperado",
        "espelho",
        "esquadria",
        "refletivo",
        "organico",
        "canelado",
      ],
      project_cor_refletivo: [
        "prata",
        "neutro",
        "champanhe",
        "cinza",
        "verde",
        "azul",
      ],
      quote_item_tipo_projeto: [
        "janela",
        "porta",
        "fixo",
        "box",
        "fechamento_pia",
        "espelho",
        "bascula_maxiar_pivotante",
        "guarda_corpo",
        "reposicao",
        "sacadas",
        "articulados",
        "muro",
        "vitrine",
        "janela_esquadrias",
        "porta_esquadrias",
        "maxim_ar_esquadrias",
        "fixos_esquadrias",
        "portao_esquadrias",
        "fachada_esquadrias",
        "porta_pivotante_esquadrias",
        "diversos_esquadrias",
        "basculantes_esquadrias",
        "janela_pivotante_esquadrias",
        "camarao_esquadrias",
        "janela_abrir_esquadrias",
        "gradil_esquadrias",
      ],
      quote_stage: ["orcamento", "producao", "instalacao", "pago"],
      quote_status: ["rascunho", "enviado", "aprovado", "recusado"],
      sale_payment_method: [
        "pix",
        "dinheiro",
        "cartao",
        "boleto",
        "parcelado",
        "outro",
      ],
      sale_status: ["finalizada", "cancelada"],
      server_log_level: ["info", "warn", "error"],
      service_order_segment: [
        "vidracaria",
        "serralheria",
        "esquadrias",
        "marcenaria",
        "marmoraria",
      ],
      service_order_stage: [
        "orcamento",
        "medicao",
        "producao",
        "corte",
        "instalacao",
        "finalizado",
        "pago",
      ],
      service_order_status: ["ativo", "atrasado", "finalizado", "cancelado"],
      supplier_area: [
        "vidracaria",
        "serralheria",
        "esquadrias",
        "marcenaria",
        "marmoraria",
        "geral",
      ],
      supplier_status: ["ativo", "inativo", "bloqueado"],
      sub_status: ["ativo", "suspenso", "cancelado"],
    },
  },
} as const

