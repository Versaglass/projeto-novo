import { Link, Outlet, useLocation, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState, type Dispatch, type SetStateAction } from "react";
import {
  LayoutDashboard,
  Users,
  FileText,
  LogOut,
  Layers,
  Sparkles,
  Package,
  Scissors,
  Shield,
  CreditCard,
  Receipt,
  Bell,
  Activity,
  FolderOpen,
  ChevronDown,
  Truck,
  Box,
  UserCog,
  Square,
  Wrench,
  Settings,
  Calculator,
  DollarSign,
  Library,
  Lock,
  DraftingCompass,
  Menu,
  type LucideIcon,
} from "lucide-react";
import { NotificationsBell } from "@/components/NotificationsBell";
import { CompanyInvitationBanner } from "@/components/CompanyInvitationBanner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";
import type { Permissions } from "@/hooks/use-auth";
import { getPlanFromStorage, hasModuleAccess, MODULES, type ModuleKey } from "@/lib/module-access";
import { consumeHiddenRouteToast } from "@/lib/hidden-route-guard";
import { consumeAccountInactiveToast, shouldShowAccountInactiveToast } from "@/lib/account-active";
import { finePermissionForNavTo, resolvesFinePermission } from "@/lib/fine-permissions";
import { invalidateAuthzSnapshot } from "@/lib/authz-snapshot";
import { invalidateAuthSessionSnapshot } from "@/lib/auth-session-snapshot";
import { ThemeToggle } from "@/components/theme-toggle";
import { useCompany } from "@/contexts/company-context";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

type NavItem = {
  to: string;
  label: string;
  icon: LucideIcon;
  exact?: boolean;
  perm?: keyof Permissions;
  adminOnly?: boolean;
  moduleKey?: ModuleKey;
  locked?: boolean;
  /** Só aparece para quem tem empresa ativa, em qualquer papel. Ver `podeVer`. */
  requiresCompany?: boolean;
};

const NAV: NavItem[] = [
  { to: "/app", label: "Dashboard", icon: LayoutDashboard, exact: true },
  // Projetos é a BIBLIOTECA de modelos técnicos da empresa: qualquer membro
  // precisa enxergá-la para poder orçar. Antes o item exigia a permissão
  // `manage_projetos`, que nasce `false` em `profiles.permissions` — por isso o
  // vendedor nunca via a aba. Permissão de GERIR (criar/editar/excluir) é
  // decidida dentro da página pelo papel EMPRESARIAL (`companyRole`), e a RLS
  // continua sendo a proteção final; esconder item de menu nunca foi segurança.
  { to: "/app/projetos", label: "Projetos", icon: Layers, perm: "manage_projetos" },
  { to: "/app/editor-engenharia", label: "Editor 2D", icon: DraftingCompass },
  { to: "/app/estoque", label: "Estoque", icon: Package, perm: "manage_estoque" },
  // Catálogo de Fabricantes: removido do menu do usuário. Produtos globais
  // publicados pelo Super Admin aparecem automaticamente em Estoque.
  // Rotas /app/catalogo-fabricantes* restritas a platform admin (legado).
  { to: "/app/plano-corte", label: "Plano de corte", icon: Scissors, perm: "use_plano_corte" },
  // Revisão 89: era `/app/calculadora`. A rota antiga continua respondendo, por
  // redirect, para não quebrar favorito nem link salvo.
  { to: "/app/venda-direta", label: "Venda direta", icon: Calculator },
  // Histórico das vendas registradas (Revisão 88). Fica logo abaixo de "Venda
  // direta" porque é o par dela: uma registra, a outra consulta. `requiresCompany`
  // porque a lista É por empresa — sem empresa ativa não há o que mostrar.
  { to: "/app/vendas", label: "Vendas", icon: Receipt, requiresCompany: true },
  // Lista de orçamentos não exige `create_orcamentos` (criar/editar/excluir são
  // ações finas na página e em /novo).
  { to: "/app/orcamentos", label: "Orçamentos", icon: FileText },
  // Ordens de Serviço e Agenda: removidos do menu (contas normais + Super Admin).
  // Rotas permanecem com `hiddenRouteBeforeLoad` — mesmo espírito da Rev. 227.
  // Central de Obras e Instalador: já ocultos (mock/localStorage).
  // Compras: página removida da experiência operacional (rota e menu).
  { to: "/app/financeiro", label: "Financeiro", icon: DollarSign },
  { to: "/app/minha-assinatura", label: "Minha assinatura", icon: CreditCard },
];

/**
 * Ferramentas ativas no menu Administração (Super Admin).
 * Rotas legadas podem existir no código sem item aqui; `requireAdmin` permanece.
 */
const ADMINISTRACAO: NavItem[] = [
  { to: "/app/admin/usuarios", label: "Usuários", icon: Shield, adminOnly: true },
  { to: "/app/admin/catalogo-global", label: "Catálogo Global", icon: Library, adminOnly: true },
  {
    to: "/app/admin/importar-catalogo",
    label: "Importar catálogo com IA",
    icon: Sparkles,
    adminOnly: true,
  },
  { to: "/app/admin/configuracoes", label: "Configurações", icon: Settings, adminOnly: true },
  { to: "/app/admin/assinaturas", label: "Assinaturas", icon: Receipt, adminOnly: true },
  { to: "/app/admin/notificacoes", label: "Notificações", icon: Bell, adminOnly: true },
  { to: "/app/admin/logs", label: "Registros do servidor", icon: Activity, adminOnly: true },
];

// ⚠️ Esta lista NÃO é um índice de páginas — é o MAPA DE MÓDULOS do plano.
// Cada entrada é um módulo comercial (`moduleKey`), e o `to` aponta para a
// página que atende aquele módulo. Por isso é normal vários itens levarem ao
// mesmo lugar: vários apontam para `/app/projetos` ou `/app/ferragens`.
// O que os diferencia é o cadeado — `hasModuleAccess` marca `locked` quando o
// plano não inclui o módulo.
const MATERIAIS: NavItem[] = [
  { to: "/app/vidros", label: "Vidros", icon: Square, moduleKey: "vidros" },
  { to: "/app/aluminios", label: "Alumínios", icon: Library, moduleKey: "aluminios" },
  {
    to: "/app/ferragens",
    label: "Ferragens para vidro",
    icon: Wrench,
    moduleKey: "ferragens_vidro",
  },
  { to: "/app/projetos", label: "Serralheria", icon: Layers, moduleKey: "serralheria" },
  // Aço e Metalon: entrada de menu removida da experiência operacional.
  // Estoque geral (/app/estoque) e dados de categoria aco_metalon permanecem.
  { to: "/app/projetos", label: "MDF e chapas", icon: Box, moduleKey: "mdf" },
  { to: "/app/ferragens", label: "Ferragens móveis", icon: Wrench, moduleKey: "ferragens_moveis" },
  { to: "/app/projetos", label: "Mármores e Granitos", icon: Square, moduleKey: "marmores" },
  { to: "/app/projetos", label: "Quartzos", icon: Square, moduleKey: "quartzos" },
  { to: "/app/projetos", label: "Porcelanatos", icon: Square, moduleKey: "porcelanatos" },
];

/**
 * Ocultação TEMPORÁRIA no submenu Materiais — as entradas acima permanecem
 * no mapa de módulos para reativação futura. Não bloqueia rotas nem remove
 * páginas/dados. Remova o `moduleKey` desta lista para voltar a exibir.
 */
const MATERIAIS_OCULTOS = new Set([
  "serralheria",
  "mdf",
  "marmores",
  "quartzos",
  "porcelanatos",
  "ferragens_moveis",
]);

// Rótulo do papel EMPRESARIAL exibido no rodapé da barra lateral.
const COMPANY_ROLE_LABEL: Record<string, string> = {
  owner: "Proprietário",
  admin: "Administrador",
  manager: "Gerente",
  operator: "Operador",
  installer: "Instalador",
  seller: "Vendedor",
};

const CADASTROS: NavItem[] = [
  { to: "/app/clientes", label: "Clientes", icon: Users, perm: "manage_clientes" },
  { to: "/app/fornecedores", label: "Fornecedores", icon: Truck },
  // Produtos: página de cadastro local removida. Estoque / catálogo / venda
  // direta continuam usando seus próprios fluxos de produto.
  { to: "/app/funcionarios", label: "Funcionários", icon: UserCog },
];

type SidebarNavProps = {
  pathname: string;
  visibleNav: NavItem[];
  visibleMateriais: NavItem[];
  visibleCadastros: NavItem[];
  visibleAdmin: NavItem[];
  materiaisOpen: boolean;
  setMateriaisOpen: Dispatch<SetStateAction<boolean>>;
  cadastrosOpen: boolean;
  setCadastrosOpen: Dispatch<SetStateAction<boolean>>;
  adminOpen: boolean;
  setAdminOpen: Dispatch<SetStateAction<boolean>>;
  materiaisActive: boolean;
  cadastrosActive: boolean;
  adminActive: boolean;
  /** Fecha o drawer mobile após escolher uma rota (não ao expandir grupo). */
  onNavigate?: () => void;
};

/** Mesma árvore de itens para sidebar desktop e drawer mobile. */
function SidebarNav({
  pathname,
  visibleNav,
  visibleMateriais,
  visibleCadastros,
  visibleAdmin,
  materiaisOpen,
  setMateriaisOpen,
  cadastrosOpen,
  setCadastrosOpen,
  adminOpen,
  setAdminOpen,
  materiaisActive,
  cadastrosActive,
  adminActive,
  onNavigate,
}: SidebarNavProps) {
  return (
    <nav className="flex-1 overflow-y-auto px-3 mt-2 pb-4">
      {visibleNav.map((item) => {
        const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
        const Icon = item.icon;
        return (
          <Link
            key={item.to}
            to={item.to}
            onClick={onNavigate}
            className={`mb-1 flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${
              active
                ? "bg-gold text-gold-foreground font-semibold shadow-glow"
                : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            }`}
          >
            <Icon className="h-4 w-4" />
            {item.label}
          </Link>
        );
      })}

      {visibleMateriais.length > 0 && (
        <div className="mt-1">
          <button
            type="button"
            onClick={() => setMateriaisOpen((o) => !o)}
            aria-expanded={materiaisOpen}
            className={`mb-1 flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${
              materiaisActive
                ? "bg-sidebar-accent text-sidebar-accent-foreground font-semibold"
                : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            }`}
          >
            <Library className="h-4 w-4" />
            <span className="flex-1 text-left">Materiais</span>
            <ChevronDown
              className={`h-4 w-4 transition-transform ${materiaisOpen ? "rotate-180" : ""}`}
            />
          </button>
          {materiaisOpen && (
            <ul className="mb-1 ml-2 space-y-0.5 border-l border-sidebar-border pl-2">
              {visibleMateriais.map((item) => {
                const active = pathname.startsWith(item.to);
                const Icon = item.icon;
                const moduleLabel = item.moduleKey ? MODULES[item.moduleKey].upgradePlan : "";
                return (
                  <li key={`${item.to}-${item.label}`}>
                    <Link
                      to={item.locked ? "/app/minha-assinatura" : item.to}
                      title={item.locked ? `Bloqueado: ${moduleLabel}` : item.label}
                      onClick={onNavigate}
                      className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition ${
                        active
                          ? "bg-gold text-gold-foreground font-semibold shadow-glow"
                          : item.locked
                            ? "text-sidebar-foreground/35 hover:bg-sidebar-accent/60"
                            : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                      }`}
                    >
                      <Icon className="h-3.5 w-3.5" />
                      <span className="flex-1">{item.label}</span>
                      {item.locked && <Lock className="h-3 w-3" />}
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      )}

      {visibleCadastros.length > 0 && (
        <div className="mt-1">
          <button
            type="button"
            onClick={() => setCadastrosOpen((o) => !o)}
            aria-expanded={cadastrosOpen}
            className={`mb-1 flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${
              cadastrosActive
                ? "bg-sidebar-accent text-sidebar-accent-foreground font-semibold"
                : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            }`}
          >
            <FolderOpen className="h-4 w-4" />
            <span className="flex-1 text-left">Cadastros</span>
            <ChevronDown
              className={`h-4 w-4 transition-transform ${cadastrosOpen ? "rotate-180" : ""}`}
            />
          </button>
          {cadastrosOpen && (
            <ul className="mb-1 ml-2 space-y-0.5 border-l border-sidebar-border pl-2">
              {visibleCadastros.map((item) => {
                const active = pathname.startsWith(item.to);
                const Icon = item.icon;
                return (
                  <li key={item.to}>
                    <Link
                      to={item.to}
                      onClick={onNavigate}
                      className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition ${
                        active
                          ? "bg-gold text-gold-foreground font-semibold shadow-glow"
                          : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                      }`}
                    >
                      <Icon className="h-3.5 w-3.5" />
                      {item.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      )}

      {visibleAdmin.length > 0 && (
        <div className="mt-1">
          <button
            type="button"
            onClick={() => setAdminOpen((o) => !o)}
            aria-expanded={adminOpen}
            className={`mb-1 flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${
              adminActive
                ? "bg-sidebar-accent text-sidebar-accent-foreground font-semibold"
                : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            }`}
          >
            <Shield className="h-4 w-4" />
            <span className="flex-1 text-left">Administração</span>
            <ChevronDown
              className={`h-4 w-4 transition-transform ${adminOpen ? "rotate-180" : ""}`}
            />
          </button>
          {adminOpen && (
            <ul className="mb-1 ml-2 space-y-0.5 border-l border-sidebar-border pl-2">
              {visibleAdmin.map((item) => {
                const active = pathname.startsWith(item.to);
                const Icon = item.icon;
                return (
                  <li key={item.to}>
                    <Link
                      to={item.to}
                      onClick={onNavigate}
                      className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition ${
                        active
                          ? "bg-gold text-gold-foreground font-semibold shadow-glow"
                          : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                      }`}
                    >
                      <Icon className="h-3.5 w-3.5" />
                      {item.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      )}
    </nav>
  );
}

type SidebarFooterProps = {
  pathname: string;
  email?: string | null;
  companyName?: string | null;
  companyRole: string | null;
  role: string | null;
  onLogout: () => void;
  onNavigate?: () => void;
};

function SidebarFooter({
  pathname,
  email,
  companyName,
  companyRole,
  role,
  onLogout,
  onNavigate,
}: SidebarFooterProps) {
  return (
    <div className="border-t border-sidebar-border p-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
      <div className="mb-3">
        <ThemeToggle variant="sidebar" />
      </div>
      <div className="mb-1 truncate text-xs text-sidebar-foreground/60">{email}</div>
      {companyName && (
        <div className="mb-1 truncate text-[11px] font-semibold text-sidebar-foreground/80">
          {companyName}
        </div>
      )}
      {/* Dois crachás distintos DE PROPÓSITO: o papel EMPRESARIAL
          (company_members.role — quem manda nesta empresa) e o papel de
          PLATAFORMA (app_role). Confundi-los é o que fazia o proprietário
          de uma empresa aparecer apenas como "vendedor". */}
      <div className="mb-3 flex flex-wrap gap-1">
        {companyRole && (
          <span className="inline-flex rounded-full bg-gold/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-gold">
            {COMPANY_ROLE_LABEL[companyRole] ?? companyRole}
          </span>
        )}
        {role && (
          <span className="inline-flex rounded-full bg-sidebar-accent px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-sidebar-foreground/70">
            {role}
          </span>
        )}
      </div>
      <Link
        to="/app/conta"
        onClick={onNavigate}
        className={`mb-1 flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm transition ${
          pathname === "/app/conta"
            ? "bg-gold text-gold-foreground font-semibold shadow-glow"
            : "text-sidebar-foreground/80 hover:bg-sidebar-accent"
        }`}
      >
        <Settings className="h-4 w-4" /> Configurações
      </Link>
      <button
        type="button"
        onClick={onLogout}
        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-sidebar-foreground/80 hover:bg-sidebar-accent"
      >
        <LogOut className="h-4 w-4" /> Sair
      </button>
    </div>
  );
}

function SidebarBrand() {
  return (
    <div className="flex items-center gap-2.5 px-6 py-6">
      <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-gold shadow-glow">
        <Sparkles className="h-5 w-5 text-gold-foreground" />
      </div>
      <div>
        <div className="font-display text-lg font-bold leading-none tracking-tight">VersaGlass</div>
        <div className="text-[10px] uppercase tracking-[0.18em] text-sidebar-foreground/50 mt-1">
          Gestão versátil
        </div>
      </div>
    </div>
  );
}

export function AppShell() {
  const { user, isAdmin, permissions, role, loading: authLoading } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const { hasCompany, loading: companyLoading, activeCompany, companyRole } = useCompany();

  // Gate de onboarding (UX; a RLS continua sendo a proteção final dos dados).
  // Regra EXPLÍCITA: o admin de PLATAFORMA não é forçado ao onboarding — ele
  // administra a plataforma e pode não ter empresa. Usuário comum sem empresa é
  // levado ao onboarding e mantido lá até criar/entrar em uma empresa.
  // Espera AMBOS os carregamentos (papel de plataforma e memberships) antes de
  // agir — senão `isAdmin` ainda seria `false` e um admin cairia no onboarding.
  //
  // `redirectingRef` evita disparar o mesmo redirect várias vezes enquanto a
  // navegação está pendente: `useNavigate` devolve uma função nova a cada render,
  // então o efeito reexecuta a cada render; sem esta trava, um usuário sem empresa
  // chamaria `navigate` repetidamente até a rota mudar, gerando reprocessamento em
  // excesso. Só navegamos quando a rota de DESTINO difere da atual, e destravamos
  // assim que o destino é alcançado.
  const redirectingRef = useRef(false);
  const [loggingOut, setLoggingOut] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Toast após redirect de rota oculta (Revisão 227) — beforeLoad não monta React.
  useEffect(() => {
    const hidden = consumeHiddenRouteToast();
    if (hidden) toast.info(hidden);
    const inactive = consumeAccountInactiveToast();
    if (inactive && shouldShowAccountInactiveToast()) toast.error(inactive);
  }, [location.pathname]);

  useEffect(() => {
    // Durante o logout (ou já sem usuário) o gate NÃO pode agir: sem sessão,
    // `hasCompany` é false e o gate tentaria mandar para /app/onboarding, brigando
    // com o redirect do logout e criando loop /auth ↔ /app/onboarding. Quem cuida
    // do usuário deslogado é o `beforeLoad` de _authenticated (→ /auth).
    if (loggingOut || !user) {
      redirectingRef.current = false;
      return;
    }
    if (companyLoading || authLoading) return;
    if (isAdmin) {
      redirectingRef.current = false;
      return;
    }
    const onOnboarding = location.pathname === "/app/onboarding";
    // Só há um destino quando a rota atual está ERRADA para o estado do usuário:
    // sem empresa e fora do onboarding → onboarding; com empresa e no onboarding →
    // /app. Nos demais casos já estamos onde deveríamos e não navegamos (nunca
    // redirecionamos para a própria rota atual).
    let target: string | null = null;
    if (!hasCompany && !onOnboarding) target = "/app/onboarding";
    else if (hasCompany && onOnboarding) target = "/app";
    if (!target) {
      redirectingRef.current = false;
      return;
    }
    if (redirectingRef.current) return;
    redirectingRef.current = true;
    navigate({ to: target });
  }, [
    companyLoading,
    authLoading,
    hasCompany,
    isAdmin,
    user,
    loggingOut,
    location.pathname,
    navigate,
  ]);

  /**
   * Visibilidade de item guardado por permissão fina.
   *
   * Regra: gestores empresariais (owner/admin/manager) ignoram permissões
   * finas; operator/installer/seller respeitam `profiles.permissions`.
   * Super Admin de plataforma bypassa finas e vê a pasta Administração.
   * Ver `resolvesFinePermission` em `fine-permissions.ts`.
   */
  const podeVer = (item: NavItem) => {
    if (item.adminOnly) return isAdmin;
    if (item.requiresCompany) return !!activeCompany;
    if (!item.perm) return true;
    return resolvesFinePermission(isAdmin, companyRole, permissions, item.perm);
  };

  const visibleNav = NAV.filter(podeVer);
  const visibleCadastros = CADASTROS.filter(podeVer);
  // Pasta exclusiva do Super Admin de plataforma — depois das funções normais.
  const visibleAdmin = isAdmin ? ADMINISTRACAO.filter(podeVer) : [];

  const currentPlan = getPlanFromStorage();
  // Itens cujo destino exige permissão fina também respeitam o mesmo helper.
  // MATERIAIS_OCULTOS permanece oculto para TODAS as contas (não reativar).
  const visibleMateriais = MATERIAIS.filter((item) => {
    if (item.moduleKey && MATERIAIS_OCULTOS.has(item.moduleKey)) return false;
    const need = finePermissionForNavTo(item.to);
    if (!need) return true;
    return resolvesFinePermission(isAdmin, companyRole, permissions, need);
  }).map((item) => ({
    ...item,
    locked: item.moduleKey ? !hasModuleAccess(currentPlan, item.moduleKey) : false,
  }));

  const cadastrosActive = visibleCadastros.some((i) => location.pathname.startsWith(i.to));
  const materiaisActive = visibleMateriais.some((i) => location.pathname.startsWith(i.to));
  const adminActive = visibleAdmin.some((i) => location.pathname.startsWith(i.to));
  const [cadastrosOpen, setCadastrosOpen] = useState(cadastrosActive);
  const [materiaisOpen, setMateriaisOpen] = useState(materiaisActive);
  const [adminOpen, setAdminOpen] = useState(adminActive);

  const closeMobileMenu = () => setMobileMenuOpen(false);

  const logout = async () => {
    if (loggingOut) return; // impede cliques duplicados
    setLoggingOut(true); // trava o gate de onboarding enquanto encerramos a sessão
    setMobileMenuOpen(false);
    try {
      invalidateAuthSessionSnapshot();
      invalidateAuthzSnapshot();
      const { error } = await supabase.auth.signOut({ scope: "local" });
      if (error) {
        toast.error("Não foi possível encerrar a sessão: " + error.message);
        return; // mantém o usuário logado; o finally libera para nova tentativa
      }
      // Limpa apenas as preferências locais de empresa ativa (nada permanente).
      // A chave passou a ser por usuário (`vmm_active_company_id:<uid>`), então
      // varremos o prefixo — inclusive a chave antiga sem sufixo, de sessões
      // anteriores à mudança.
      if (typeof localStorage !== "undefined") {
        for (const k of Object.keys(localStorage)) {
          if (k === "vmm_active_company_id" || k.startsWith("vmm_active_company_id:")) {
            localStorage.removeItem(k);
          }
        }
      }
      toast.success("Sessão encerrada");
      // `replace` evita que o /app fique no histórico (voltar não reabre a sessão).
      // Destino é "/" — a entrada pública passou a renderizar a autenticação ali
      // mesmo, sem o salto "/" → "/auth". O gate de onboarding continua ignorando
      // o estado sem usuário (`if (loggingOut || !user) return`), então não há
      // disputa de navegação nem loop.
      navigate({ to: "/", replace: true });
    } finally {
      setLoggingOut(false);
    }
  };

  const navProps: SidebarNavProps = {
    pathname: location.pathname,
    visibleNav,
    visibleMateriais,
    visibleCadastros,
    visibleAdmin,
    materiaisOpen,
    setMateriaisOpen,
    cadastrosOpen,
    setCadastrosOpen,
    adminOpen,
    setAdminOpen,
    materiaisActive,
    cadastrosActive,
    adminActive,
  };

  const footerProps: Omit<SidebarFooterProps, "onNavigate"> = {
    pathname: location.pathname,
    email: user?.email,
    companyName: activeCompany?.companyName ?? null,
    companyRole,
    role,
    onLogout: logout,
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop — sidebar fixa (inalterada visualmente) */}
      <aside className="fixed left-0 top-0 hidden h-screen w-64 flex-col bg-sidebar text-sidebar-foreground md:flex border-r border-sidebar-border">
        <SidebarBrand />
        <SidebarNav {...navProps} />
        <SidebarFooter {...footerProps} />
      </aside>

      {/* Mobile — header compacto + drawer (mesma árvore de navegação) */}
      <header className="sticky top-0 z-10 flex items-center justify-between border-b border-sidebar-border bg-sidebar px-3 py-3 text-sidebar-foreground pt-[max(0.75rem,env(safe-area-inset-top))] md:hidden">
        <div className="flex min-w-0 items-center gap-2">
          <button
            type="button"
            aria-label="Abrir menu"
            aria-expanded={mobileMenuOpen}
            aria-controls="app-mobile-sidebar"
            onClick={() => setMobileMenuOpen(true)}
            className="rounded-lg p-2 hover:bg-sidebar-accent"
          >
            <Menu className="h-5 w-5" />
          </button>
          <Link to="/app" className="flex min-w-0 items-center gap-2">
            <div className="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-gradient-gold">
              <Sparkles className="h-4 w-4 text-gold-foreground" />
            </div>
            <span className="font-display font-bold truncate">VersaGlass</span>
          </Link>
        </div>
        <div className="flex shrink-0 items-center gap-1">
          <ThemeToggle
            variant="icon"
            className="scale-90 [&_button]:h-9 [&_button]:w-9 [&_svg]:h-4 [&_svg]:w-4"
          />
          {isAdmin && <NotificationsBell />}
          <Link
            to="/app/conta"
            className="rounded-lg p-2 hover:bg-sidebar-accent"
            aria-label="Configurações"
          >
            <Settings className="h-4 w-4" />
          </Link>
          <button
            type="button"
            onClick={logout}
            className="rounded-lg p-2 hover:bg-sidebar-accent"
            aria-label="Sair"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </header>

      <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
        <SheetContent
          id="app-mobile-sidebar"
          side="left"
          className="flex w-[min(82vw,300px)] max-w-[300px] flex-col gap-0 border-sidebar-border bg-sidebar p-0 text-sidebar-foreground [&>button]:text-sidebar-foreground [&>button]:right-3 [&>button]:top-[max(0.75rem,env(safe-area-inset-top))]"
        >
          <SheetHeader className="sr-only">
            <SheetTitle>Menu de navegação</SheetTitle>
            <SheetDescription>Navegação principal do VersaGlass</SheetDescription>
          </SheetHeader>
          <div className="pt-[env(safe-area-inset-top)]">
            <SidebarBrand />
          </div>
          <SidebarNav {...navProps} onNavigate={closeMobileMenu} />
          <SidebarFooter {...footerProps} onNavigate={closeMobileMenu} />
        </SheetContent>
      </Sheet>

      <main className="md:pl-64">
        <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-10">
          <CompanyInvitationBanner />
          <Outlet />
        </div>
      </main>
    </div>
  );
}
