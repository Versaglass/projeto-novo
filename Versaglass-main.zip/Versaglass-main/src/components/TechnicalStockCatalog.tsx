import { useMemo, useState } from "react";
import { Download, Filter, PackagePlus, Search, ShoppingCart } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { aluminumProfiles } from "@/data/aluminumCatalog";
import { AluminumDrawing } from "@/components/AluminumCatalog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";

type CatalogKind = "aluminios" | "vidros" | "ferragens" | "acessorios";

type TechnicalItem = {
  id: string;
  kind: CatalogKind;
  codigo: string;
  nome: string;
  categoria: string;
  descricao: string;
  unidade: string;
  medida?: string;
  ncm?: string;
  estoque: number;
  custo: number;
  venda: number;
};

const glassItems: TechnicalItem[] = [
  {
    id: "vd-temp-6",
    kind: "vidros",
    codigo: "VD-TEMP-06",
    nome: "Vidro temperado 6 mm",
    categoria: "Temperado",
    descricao: "Incolor, bronze, fumê ou verde. Uso em box, janelas e divisórias.",
    unidade: "m²",
    medida: "6 mm",
    ncm: "7007.19.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "vd-temp-8",
    kind: "vidros",
    codigo: "VD-TEMP-08",
    nome: "Vidro temperado 8 mm",
    categoria: "Temperado",
    descricao: "Indicado para portas, guarda-corpo interno, divisórias e fachadas leves.",
    unidade: "m²",
    medida: "8 mm",
    ncm: "7007.19.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "vd-temp-10",
    kind: "vidros",
    codigo: "VD-TEMP-10",
    nome: "Vidro temperado 10 mm",
    categoria: "Temperado",
    descricao: "Indicado para portas, fachadas, guarda-corpos e projetos premium.",
    unidade: "m²",
    medida: "10 mm",
    ncm: "7007.19.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "vd-lam-8",
    kind: "vidros",
    codigo: "VD-LAM-08",
    nome: "Vidro laminado 4+4",
    categoria: "Laminado",
    descricao: "Duas chapas com PVB. Uso em cobertura, guarda-corpo e segurança.",
    unidade: "m²",
    medida: "8 mm",
    ncm: "7007.29.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "vd-lam-10",
    kind: "vidros",
    codigo: "VD-LAM-10",
    nome: "Vidro laminado 5+5",
    categoria: "Laminado",
    descricao: "Vidro de segurança para guarda-corpo, cobertura e fachadas.",
    unidade: "m²",
    medida: "10 mm",
    ncm: "7007.29.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "vd-esp-4",
    kind: "vidros",
    codigo: "ESP-04",
    nome: "Espelho prata 4 mm",
    categoria: "Espelhos",
    descricao: "Espelho comum para banheiro, sala, loja e móveis planejados.",
    unidade: "m²",
    medida: "4 mm",
    ncm: "7009.91.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "vd-esp-6",
    kind: "vidros",
    codigo: "ESP-06",
    nome: "Espelho prata 6 mm",
    categoria: "Espelhos",
    descricao: "Espelho premium para grandes formatos e projetos decorativos.",
    unidade: "m²",
    medida: "6 mm",
    ncm: "7009.91.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "vd-jat",
    kind: "vidros",
    codigo: "VD-JAT",
    nome: "Vidro jateado",
    categoria: "Decorativo",
    descricao: "Privacidade e acabamento decorativo para portas, divisórias e boxes.",
    unidade: "m²",
    medida: "sob medida",
    ncm: "7007.19.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
];

const hardwareItems: TechnicalItem[] = [
  {
    id: "fg-dob-101",
    kind: "ferragens",
    codigo: "DOB-101",
    nome: "Dobradiça vidro/vidro",
    categoria: "Dobradiças",
    descricao: "Dobradiça para porta de vidro temperado.",
    unidade: "un",
    medida: "10 mm",
    ncm: "8302.41.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "fg-dob-102",
    kind: "ferragens",
    codigo: "DOB-102",
    nome: "Dobradiça parede/vidro",
    categoria: "Dobradiças",
    descricao: "Dobradiça para fixação da folha de vidro na parede.",
    unidade: "un",
    medida: "8/10 mm",
    ncm: "8302.41.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "fg-pux-h",
    kind: "ferragens",
    codigo: "PUX-H-400",
    nome: "Puxador H 400 mm",
    categoria: "Puxadores",
    descricao: "Puxador tubular inox/alumínio para portas de vidro.",
    unidade: "par",
    medida: "400 mm",
    ncm: "8302.41.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "fg-pux-h-600",
    kind: "ferragens",
    codigo: "PUX-H-600",
    nome: "Puxador H 600 mm",
    categoria: "Puxadores",
    descricao: "Puxador premium para porta de vidro temperado.",
    unidade: "par",
    medida: "600 mm",
    ncm: "8302.41.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "fg-rold-box",
    kind: "ferragens",
    codigo: "ROLD-BOX",
    nome: "Roldana para box",
    categoria: "Roldanas",
    descricao: "Roldana superior/inferior para box de correr.",
    unidade: "un",
    medida: "padrão",
    ncm: "8302.41.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "fg-fech-1520",
    kind: "ferragens",
    codigo: "FECH-1520",
    nome: "Fechadura para vidro",
    categoria: "Fechaduras",
    descricao: "Fechadura central para porta de vidro temperado.",
    unidade: "un",
    medida: "10 mm",
    ncm: "8301.40.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "fg-mola-piso",
    kind: "ferragens",
    codigo: "MOLA-PISO",
    nome: "Mola hidráulica de piso",
    categoria: "Molas",
    descricao: "Mola para portas de vidro com controle de fechamento.",
    unidade: "un",
    medida: "padrão",
    ncm: "8302.60.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
];

const accessoryItems: TechnicalItem[] = [
  {
    id: "ac-sil-neutro",
    kind: "acessorios",
    codigo: "SIL-NEUTRO",
    nome: "Silicone neutro",
    categoria: "Silicones",
    descricao: "Vedação e acabamento em vidro, alumínio, pedra e esquadrias.",
    unidade: "un",
    medida: "280 g",
    ncm: "3214.10.10",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "ac-fita-vhb",
    kind: "acessorios",
    codigo: "FITA-VHB",
    nome: "Fita dupla face estrutural",
    categoria: "Fitas",
    descricao: "Fixação de perfis, espelhos e acessórios.",
    unidade: "rolo",
    medida: "19 mm",
    ncm: "3919.10.10",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "ac-guarnicao",
    kind: "acessorios",
    codigo: "GUARN-BOX",
    nome: "Guarnição para box",
    categoria: "Guarnições",
    descricao: "Vedação lateral e inferior para boxes de vidro.",
    unidade: "m",
    medida: "6/8 mm",
    ncm: "3916.20.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "ac-escova",
    kind: "acessorios",
    codigo: "ESC-5X7",
    nome: "Escova de vedação",
    categoria: "Escovas",
    descricao: "Escova para portas, janelas e fechamento de sacada.",
    unidade: "m",
    medida: "5x7 mm",
    ncm: "9603.50.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
  {
    id: "ac-parafuso",
    kind: "acessorios",
    codigo: "PAR-INX",
    nome: "Parafuso inox",
    categoria: "Fixadores",
    descricao: "Parafuso para instalação de ferragens e acessórios.",
    unidade: "cx",
    medida: "diversos",
    ncm: "7318.15.00",
    estoque: 0,
    custo: 0,
    venda: 0,
  },
];

const aluminumItems: TechnicalItem[] = aluminumProfiles.map((p) => ({
  id: p.id,
  kind: "aluminios",
  codigo: p.codigo,
  nome: p.nome,
  categoria: p.categoria,
  descricao: `${p.codigo} • Peça ${p.medidaM} m • Peso ${p.pesoKgM.toFixed(3)} kg/m`,
  unidade: "barra",
  medida: [p.aMm && `A ${p.aMm} mm`, p.bMm && `B ${p.bMm} mm`, p.cMm && `C ${p.cMm} mm`]
    .filter(Boolean)
    .join(" • "),
  ncm: p.ncm,
  estoque: 0,
  custo: 0,
  venda: 0,
}));

const allItems = [...aluminumItems, ...glassItems, ...hardwareItems, ...accessoryItems];

const labels: Record<CatalogKind, string> = {
  aluminios: "Alumínios",
  vidros: "Vidros",
  ferragens: "Ferragens",
  acessorios: "Acessórios",
};

export function TechnicalStockCatalog() {
  const [query, setQuery] = useState("");
  const [active, setActive] = useState<CatalogKind>("aluminios");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return allItems.filter(
      (item) =>
        item.kind === active &&
        (!q ||
          [item.codigo, item.nome, item.categoria, item.descricao, item.medida]
            .join(" ")
            .toLowerCase()
            .includes(q)),
    );
  }, [active, query]);

  const downloadPdf = (kind: CatalogKind) => {
    const rows = allItems.filter((item) => item.kind === kind);
    const doc = new jsPDF({ orientation: "landscape" });
    doc.setFontSize(16);
    doc.text(`Catálogo técnico - ${labels[kind]}`, 14, 16);
    doc.setFontSize(10);
    doc.text(
      "Estoque inicial zerado. Cada empresa adiciona suas próprias quantidades, custos e preços.",
      14,
      23,
    );
    autoTable(doc, {
      startY: 30,
      head: [["Código", "Nome", "Categoria", "Medida", "Unidade", "Estoque", "NCM", "Descrição"]],
      body: rows.map((i) => [
        i.codigo,
        i.nome,
        i.categoria,
        i.medida || "—",
        i.unidade,
        "0",
        i.ncm || "—",
        i.descricao,
      ]),
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [15, 23, 42] },
      columnStyles: { 7: { cellWidth: 70 } },
    });
    doc.save(`catalogo-${kind}-estoque-zerado.pdf`);
    toast.success(`PDF de ${labels[kind]} baixado`);
  };

  const downloadAllPdf = () => {
    const doc = new jsPDF({ orientation: "landscape" });
    doc.setFontSize(16);
    doc.text("Biblioteca técnica de estoque", 14, 16);
    doc.setFontSize(10);
    doc.text(
      "Alumínios, vidros, ferragens e acessórios pré-cadastrados com estoque inicial zerado.",
      14,
      23,
    );
    let startY = 31;
    (Object.keys(labels) as CatalogKind[]).forEach((kind, index) => {
      if (index > 0) doc.addPage("landscape");
      if (index > 0) startY = 20;
      doc.setFontSize(13);
      doc.text(labels[kind], 14, startY - 6);
      const rows = allItems.filter((item) => item.kind === kind);
      autoTable(doc, {
        startY,
        head: [["Código", "Nome", "Categoria", "Medida", "Unidade", "Estoque", "NCM"]],
        body: rows.map((i) => [
          i.codigo,
          i.nome,
          i.categoria,
          i.medida || "—",
          i.unidade,
          "0",
          i.ncm || "—",
        ]),
        styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [15, 23, 42] },
      });
    });
    doc.save("biblioteca-tecnica-estoque-zerado.pdf");
    toast.success("PDF completo baixado");
  };

  return (
    <Card className="mb-6 border-gold/20 bg-gradient-to-br from-card to-gold/5">
      <CardHeader className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <div>
          <Badge className="mb-2" variant="secondary">
            Catálogo base do estoque
          </Badge>
          <CardTitle>Biblioteca técnica pré-cadastrada</CardTitle>
          <p className="mt-1 max-w-3xl text-sm text-muted-foreground">
            Materiais aparecem para consulta, compra e orçamento com estoque inicial zerado. O
            cliente assinante informa apenas as quantidades, custos e preços da própria empresa.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={() => downloadPdf(active)} className="gap-2">
            <Download className="h-4 w-4" /> Baixar PDF da aba
          </Button>
          <Button onClick={downloadAllPdf} className="gap-2">
            <Download className="h-4 w-4" /> Baixar PDF completo
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs
          value={active}
          onValueChange={(v) => setActive(v as CatalogKind)}
          className="space-y-4"
        >
          <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <TabsList className="flex flex-wrap h-auto justify-start">
              {(Object.keys(labels) as CatalogKind[]).map((kind) => (
                <TabsTrigger key={kind} value={kind}>
                  {labels[kind]}{" "}
                  <span className="ml-1 rounded bg-background/70 px-1.5 text-[10px]">
                    {allItems.filter((i) => i.kind === kind).length}
                  </span>
                </TabsTrigger>
              ))}
            </TabsList>
            <div className="relative w-full md:w-80">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Buscar no catálogo"
                className="pl-9"
              />
            </div>
          </div>

          {(Object.keys(labels) as CatalogKind[]).map((kind) => (
            <TabsContent key={kind} value={kind} className="mt-0">
              <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                {filtered.map((item) => (
                  <div key={item.id} className="rounded-2xl border bg-background/60 p-3">
                    <div className="mb-3 flex items-start justify-between gap-2">
                      <div>
                        <div className="font-bold">{item.codigo}</div>
                        <div className="text-sm font-medium">{item.nome}</div>
                      </div>
                      <Badge variant="outline">Estoque 0</Badge>
                    </div>
                    {item.kind === "aluminios" && (
                      <AluminumDrawing
                        profile={aluminumProfiles.find((p) => p.id === item.id)!}
                        className="mb-3 h-20 w-full rounded-lg bg-card"
                      />
                    )}
                    {item.kind !== "aluminios" && (
                      <GenericDrawing kind={item.kind} label={item.codigo} />
                    )}
                    <div className="mt-3 grid gap-1 text-xs text-muted-foreground">
                      <div>
                        <b className="text-foreground">Categoria:</b> {item.categoria}
                      </div>
                      <div>
                        <b className="text-foreground">Medida:</b> {item.medida || "—"}
                      </div>
                      <div>
                        <b className="text-foreground">Unidade:</b> {item.unidade}
                      </div>
                      <div>
                        <b className="text-foreground">NCM:</b> {item.ncm || "—"}
                      </div>
                      <div>{item.descricao}</div>
                    </div>
                    <div className="mt-3 flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 gap-1"
                        onClick={() =>
                          toast.info(
                            "Use 'Novo item' para cadastrar quantidade, custo e preço da sua empresa.",
                          )
                        }
                      >
                        <PackagePlus className="h-3.5 w-3.5" /> Adicionar ao estoque
                      </Button>
                      <Button
                        size="sm"
                        variant="secondary"
                        className="gap-1"
                        onClick={() =>
                          toast.info(
                            "Pedido de compra preparado para futura integração com fornecedores.",
                          )
                        }
                      >
                        <ShoppingCart className="h-3.5 w-3.5" /> Comprar
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
}

function GenericDrawing({ kind, label }: { kind: CatalogKind; label: string }) {
  return (
    <svg
      viewBox="0 0 220 90"
      className="h-20 w-full rounded-lg bg-card"
      role="img"
      aria-label={label}
    >
      <rect x="1" y="1" width="218" height="88" fill="#fff" stroke="#e5e7eb" />
      {kind === "vidros" && (
        <>
          <rect
            x="42"
            y="20"
            width="136"
            height="50"
            rx="3"
            fill="#dff6ff"
            stroke="#0284c7"
            strokeWidth="4"
          />
          <path d="M55 64 L160 26" stroke="#7dd3fc" strokeWidth="3" />
        </>
      )}
      {kind === "ferragens" && (
        <>
          <circle cx="78" cy="45" r="20" fill="#111827" />
          <rect x="105" y="25" width="60" height="40" rx="8" fill="#374151" />
          <circle cx="122" cy="45" r="6" fill="#fff" />
        </>
      )}
      {kind === "acessorios" && (
        <>
          <rect x="56" y="28" width="108" height="34" rx="17" fill="#111827" />
          <rect x="72" y="36" width="76" height="18" rx="9" fill="#64748b" />
        </>
      )}
      <text x="14" y="20" fontSize="12" fontWeight="700" fill="#2563eb">
        {label}
      </text>
    </svg>
  );
}
