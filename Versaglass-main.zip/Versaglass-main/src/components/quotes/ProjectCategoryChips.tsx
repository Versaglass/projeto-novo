import type { ProjectTemplateCategoria } from "@/hooks/use-project-templates";
import { PROJECT_CATEGORIES, type FiltroCategoriaProjeto } from "@/lib/project-category";
import { cn } from "@/lib/utils";

type Props = {
  modelos: { categoria: ProjectTemplateCategoria }[];
  selected: FiltroCategoriaProjeto;
  onSelect: (categoria: FiltroCategoriaProjeto) => void;
};

export function ProjectCategoryChips({ modelos, selected, onSelect }: Props) {
  const contagem = (cat: ProjectTemplateCategoria) =>
    modelos.filter((m) => m.categoria === cat).length;

  return (
    <div className="flex flex-wrap gap-2">
      <button
        type="button"
        onClick={() => onSelect("all")}
        aria-pressed={selected === "all"}
        className={cn(
          "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition",
          selected === "all"
            ? "border-primary bg-primary text-primary-foreground shadow-sm"
            : "border-input bg-background hover:border-primary/40 hover:bg-accent",
        )}
      >
        Todos
        <span className="opacity-70">({modelos.length})</span>
      </button>
      {PROJECT_CATEGORIES.map((cat) => {
        const n = contagem(cat.value);
        const ativo = selected === cat.value;
        return (
          <button
            key={cat.value}
            type="button"
            disabled={n === 0}
            onClick={() => onSelect(cat.value)}
            aria-pressed={ativo}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition disabled:cursor-not-allowed disabled:opacity-40",
              ativo
                ? "border-primary bg-primary text-primary-foreground shadow-sm"
                : "border-input bg-background hover:border-primary/40 hover:bg-accent",
            )}
          >
            {cat.label}
            <span className="opacity-70">({n})</span>
          </button>
        );
      })}
    </div>
  );
}
