import { Loader2, Search } from "lucide-react";
import { ListaRolavel } from "@/components/ui/lista-rolavel";
import { brl } from "@/lib/format";
import { categoriaMeta, type StockPickerItem } from "@/hooks/use-inventory";

type Props = {
  items: StockPickerItem[];
  totalItems: number;
  busca: string;
  onBuscaChange: (value: string) => void;
  onPick: (item: StockPickerItem) => void;
  loading?: boolean;
};

/** Grade de itens do estoque — padrão da Venda Direta (Rev. 104–105), sem alterar aquele arquivo. */
export function StockItemPickerGrid({
  items,
  totalItems,
  busca,
  onBuscaChange,
  onPick,
  loading,
}: Props) {
  return (
    <div className="rounded-2xl border bg-card p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="font-display text-sm font-bold">Itens do estoque</div>
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <input
            value={busca}
            onChange={(e) => onBuscaChange(e.target.value)}
            placeholder="Buscar por nome ou categoria"
            className="w-64 rounded-lg border bg-background py-2 pl-8 pr-3 text-sm outline-none focus:ring-2 ring-ring"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex items-center gap-2 py-6 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Carregando o estoque…
        </div>
      ) : items.length === 0 ? (
        <p className="py-6 text-sm text-muted-foreground">
          {totalItems === 0
            ? "Nenhum item ativo no estoque desta empresa."
            : "Nenhum item corresponde ao filtro."}
        </p>
      ) : (
        <ListaRolavel
          className="grid max-h-[26rem] gap-2 md:grid-cols-2 lg:grid-cols-3"
          contagem={
            busca.trim()
              ? `${items.length} de ${totalItems} ${totalItems === 1 ? "item" : "itens"}`
              : `${items.length} ${items.length === 1 ? "item" : "itens"}`
          }
        >
          {items.map((item) => {
            const saldo = Number(item.quantidade) || 0;
            const semSaldo = saldo <= 0;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onPick(item)}
                disabled={semSaldo}
                title={
                  semSaldo
                    ? "Sem saldo em estoque."
                    : "Adicionar ao orçamento"
                }
                className="flex items-center justify-between gap-3 rounded-xl border bg-background p-3 text-left hover:border-gold/50 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <div className="min-w-0">
                  <div className="truncate text-sm font-semibold">{item.nome}</div>
                  <div className="text-xs text-muted-foreground">
                    {categoriaMeta(item.categoria)?.label ?? item.categoria} ·{" "}
                    {brl(Number(item.preco_venda) || 0)}/
                    {item.unidade === "m2" ? "m²" : item.unidade}
                  </div>
                </div>
                <span
                  className={`shrink-0 rounded-full px-2 py-1 text-xs font-semibold ${
                    semSaldo
                      ? "bg-destructive/10 text-destructive"
                      : "bg-emerald-500/10 text-emerald-600"
                  }`}
                >
                  {saldo} {item.unidade === "m2" ? "m²" : item.unidade}
                </span>
              </button>
            );
          })}
        </ListaRolavel>
      )}
    </div>
  );
}
