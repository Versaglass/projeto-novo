import {
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent,
} from "react";
import { Search } from "lucide-react";
import { foldBusca } from "@/lib/fold-busca";
import { cn } from "@/lib/utils";

export type CustomerSearchOption = {
  id: string;
  nome: string;
  telefone?: string | null;
};

type CustomerSearchFieldProps = {
  customers: CustomerSearchOption[];
  /** Id selecionado (modo controlado em novo.tsx). Vazio = nenhum. */
  value?: string;
  onSelect: (customerId: string) => void;
  placeholder?: string;
  emptyText?: string;
  disabled?: boolean;
  isLoading?: boolean;
  className?: string;
  /** Se true, limpa o texto após selecionar (fluxo Adicionar → navega). */
  clearOnSelect?: boolean;
};

/**
 * Busca de cliente sem Radix/cmdk (Rev. 237).
 * `<input>` + lista `absolute` — só React state + Tailwind.
 */
export function CustomerSearchField({
  customers,
  value = "",
  onSelect,
  placeholder = "Buscar cliente por nome...",
  emptyText = "Nenhum cliente encontrado.",
  disabled,
  isLoading,
  className,
  clearOnSelect = false,
}: CustomerSearchFieldProps) {
  const listId = useId();
  const rootRef = useRef<HTMLDivElement>(null);
  const selected = useMemo(
    () => customers.find((c) => c.id === value) ?? null,
    [customers, value],
  );

  const [query, setQuery] = useState(selected?.nome ?? "");
  const [open, setOpen] = useState(false);
  const [highlight, setHighlight] = useState(0);

  // Sincroniza rótulo quando value muda por fora (ex.: após cadastrar cliente).
  useEffect(() => {
    if (selected) setQuery(selected.nome);
    else if (!clearOnSelect && !value) setQuery("");
  }, [selected, value, clearOnSelect]);

  const filtered = useMemo(() => {
    const t = query.trim();
    if (!t) return customers.slice(0, 50);
    const folded = foldBusca(t);
    return customers.filter((c) => foldBusca(c.nome).includes(folded)).slice(0, 50);
  }, [customers, query]);

  useEffect(() => {
    setHighlight(0);
  }, [query, open]);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (!rootRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  const pick = (id: string, nome: string) => {
    onSelect(id);
    if (clearOnSelect) {
      setQuery("");
    } else {
      setQuery(nome);
    }
    setOpen(false);
  };

  const onKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (!open && (e.key === "ArrowDown" || e.key === "Enter")) {
      setOpen(true);
      return;
    }
    if (!open) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setHighlight((h) => Math.min(h + 1, Math.max(0, filtered.length - 1)));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setHighlight((h) => Math.max(h - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const item = filtered[highlight];
      if (item) pick(item.id, item.nome);
    } else if (e.key === "Escape") {
      setOpen(false);
    }
  };

  return (
    <div ref={rootRef} className={cn("relative w-full", className)}>
      <div className="flex items-center gap-2 rounded-lg border border-input bg-background px-3 py-2 focus-within:ring-2 focus-within:ring-ring">
        <Search className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
        <input
          type="text"
          role="combobox"
          aria-expanded={open}
          aria-controls={listId}
          aria-autocomplete="list"
          disabled={disabled || isLoading}
          value={query}
          placeholder={isLoading ? "Carregando..." : placeholder}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          onKeyDown={onKeyDown}
          className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground disabled:opacity-50"
          autoComplete="off"
        />
      </div>

      {open && !disabled && !isLoading && (
        <div
          id={listId}
          role="listbox"
          className="absolute left-0 right-0 z-50 mt-1 max-h-64 overflow-y-auto rounded-lg border border-border bg-popover text-popover-foreground shadow-md"
        >
          {filtered.length === 0 ? (
            <p className="px-3 py-4 text-center text-sm text-muted-foreground">{emptyText}</p>
          ) : (
            filtered.map((c, i) => (
              <button
                key={c.id}
                type="button"
                role="option"
                aria-selected={c.id === value || i === highlight}
                onMouseEnter={() => setHighlight(i)}
                onClick={() => pick(c.id, c.nome)}
                className={cn(
                  "flex w-full flex-col items-start gap-0.5 px-3 py-2 text-left text-sm transition",
                  i === highlight || c.id === value
                    ? "bg-accent text-accent-foreground"
                    : "hover:bg-accent/60",
                )}
              >
                <span className="font-medium">{c.nome}</span>
                {c.telefone ? (
                  <span className="text-xs text-muted-foreground">{c.telefone}</span>
                ) : null}
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}
