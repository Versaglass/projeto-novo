import {
  INVENTORY_CATEGORIES,
  type InventoryCategoria,
  type StockPickerItem,
} from "@/hooks/use-inventory";
import { cn } from "@/lib/utils";

export type FiltroCategoriaEstoque = InventoryCategoria | "all";

type Props = {
  estoque: StockPickerItem[];
  selected: FiltroCategoriaEstoque;
  onSelect: (categoria: FiltroCategoriaEstoque) => void;
};

export function StockCategoryChips({ estoque, selected, onSelect }: Props) {
  const contagem = (cat: InventoryCategoria) =>
    estoque.filter((i) => i.categoria === cat).length;

  return (
    <div className="flex flex-wrap gap-2">
      <button
        type="button"
        onClick={() => onSelect("all")}
        aria-pressed={selected === "all"}
        className={cn(
          "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition",
          selected === "all"
            ? "border-primary bg-primary text-primary-foreground shadow-sm"
            : "border-input bg-background hover:border-primary/40 hover:bg-accent",
        )}
      >
        Todos
        <span className="opacity-70">({estoque.length})</span>
      </button>
      {INVENTORY_CATEGORIES.map((cat) => {
        const n = contagem(cat.value);
        const ativo = selected === cat.value;
        return (
          <button
            key={cat.value}
            type="button"
            disabled={n === 0}
            onClick={() => onSelect(cat.value)}
            aria-pressed={ativo}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition disabled:cursor-not-allowed disabled:opacity-40",
              ativo
                ? "border-primary bg-primary text-primary-foreground shadow-sm"
                : cn("border-input bg-background hover:border-primary/40 hover:bg-accent", cat.color),
            )}
          >
            {cat.label}
            <span className="opacity-70">({n})</span>
          </button>
        );
      })}
    </div>
  );
}
