import { ImageIcon, Loader2, Search } from "lucide-react";
import { ListaRolavel } from "@/components/ui/lista-rolavel";
import { StorageImage } from "@/components/StorageImage";
import { brl, num } from "@/lib/format";
import { categoriaProjetoLabel } from "@/lib/project-category";
import { ROTULO_AREA, type AreaProjeto } from "@/lib/project-area";
import { rotuloSubtipo } from "@/lib/project-subtypes";

/** Campos mínimos para a grade (Biblioteca legada ou catálogo global). */
export type ProjectPickerGridItem = {
  id: string;
  area?: AreaProjeto | string | null;
  subtipo?: string | null;
  categoria: string;
  nome: string;
  descricao?: string | null;
  largura_padrao: number;
  altura_padrao: number;
  preco_m2: number;
  imagem_url?: string | null;
};

type Props = {
  items: ProjectPickerGridItem[];
  totalItems: number;
  busca: string;
  onBuscaChange: (value: string) => void;
  onPick: (item: ProjectPickerGridItem) => void;
  loading?: boolean;
  disabled?: boolean;
  pickTitle?: string;
  imageBucket?: "project-images" | "platform-catalog";
};

/** Grade de modelos — foto ou placeholder (Rev. 201). */
export function ProjectTemplatePickerGrid({
  items,
  totalItems,
  busca,
  onBuscaChange,
  onPick,
  loading,
  disabled,
  pickTitle = "Abrir no formulário de orçamento",
  imageBucket = "project-images",
}: Props) {
  return (
    <div className="rounded-2xl border bg-card p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="font-display text-sm font-bold">Projetos</div>
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <input
            value={busca}
            onChange={(e) => onBuscaChange(e.target.value)}
            placeholder="Buscar por nome"
            className="w-64 rounded-lg border bg-background py-2 pl-8 pr-3 text-sm outline-none focus:ring-2 ring-ring"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex items-center gap-2 py-6 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Carregando modelos…
        </div>
      ) : items.length === 0 ? (
        <p className="py-6 text-sm text-muted-foreground">
          {totalItems === 0
            ? "Nenhum projeto ativo no catálogo da plataforma."
            : "Nenhum modelo corresponde ao filtro."}
        </p>
      ) : (
        <ListaRolavel
          className="grid max-h-[32rem] gap-3 md:grid-cols-2 lg:grid-cols-3"
          contagem={
            busca.trim()
              ? `${items.length} de ${totalItems} ${totalItems === 1 ? "modelo" : "modelos"}`
              : `${items.length} ${items.length === 1 ? "modelo" : "modelos"}`
          }
        >
          {items.map((item) => {
            const larguraM = Number(item.largura_padrao) || 0;
            const alturaM = Number(item.altura_padrao) || 0;
            const m2 = larguraM * alturaM;
            const subtipoLabel = rotuloSubtipo(item.subtipo);
            return (
              <button
                key={item.id}
                type="button"
                disabled={disabled}
                onClick={() => onPick(item)}
                title={pickTitle}
                className="overflow-hidden rounded-xl border bg-background text-left transition hover:border-gold/50 hover:shadow-md disabled:cursor-not-allowed disabled:opacity-50"
              >
                <div className="relative aspect-[4/3] bg-muted/40">
                  {item.imagem_url ? (
                    <StorageImage
                      bucket={imageBucket}
                      src={item.imagem_url}
                      alt={item.nome}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                      <ImageIcon className="h-8 w-8 opacity-40" />
                    </div>
                  )}
                  {item.area && item.area in ROTULO_AREA && (
                    <span className="absolute left-2 top-2 rounded-full bg-background/90 px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wider">
                      {ROTULO_AREA[item.area as AreaProjeto]}
                    </span>
                  )}
                </div>
                <div className="space-y-1 p-3">
                  <div className="truncate text-sm font-semibold">{item.nome}</div>
                  <div className="text-xs text-muted-foreground">
                    {categoriaProjetoLabel(item.categoria)}
                    {subtipoLabel ? ` · ${subtipoLabel}` : ""}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {num(larguraM, 2)} × {num(alturaM, 2)} m · {brl(Number(item.preco_m2) || 0)}/m²
                    {m2 > 0 && (
                      <>
                        {" "}
                        ·{" "}
                        <span className="font-medium text-foreground">
                          {brl(m2 * Number(item.preco_m2))}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </ListaRolavel>
      )}
    </div>
  );
}
