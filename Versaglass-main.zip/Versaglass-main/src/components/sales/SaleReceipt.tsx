import { brl } from "@/lib/format";
import type { SaleDocument } from "@/hooks/use-sales";
import {
  formatSaleReceiptDateTime,
  saleReceiptCustomerDoc,
  saleReceiptCustomerName,
  saleReceiptItemQtyLine,
  saleReceiptPaymentLabel,
  type SaleReceiptCompany,
} from "@/lib/sale-receipt";

type SaleReceiptProps = {
  document: SaleDocument;
  company: SaleReceiptCompany | null;
};

/**
 * Corpo do comprovante térmico (80 mm) — NÃO É DOCUMENTO FISCAL.
 * Reutilizável por Venda Direta e Vendas; só renderiza dados já persistidos.
 */
export function SaleReceipt({ document, company }: SaleReceiptProps) {
  const { sale, items } = document;
  const cancelada = sale.status === "cancelada";
  const cliente = saleReceiptCustomerName(document);
  const clienteDoc = saleReceiptCustomerDoc(document);
  const dataHora = formatSaleReceiptDateTime(sale.created_at);
  const pagamento = saleReceiptPaymentLabel(document);
  const desconto = Number(sale.desconto) || 0;
  const acrescimo = Number(sale.acrescimo) || 0;
  const subtotal = Number(sale.subtotal) || 0;
  const total = Number(sale.total) || 0;
  const observacoes = (sale.observacoes ?? "").trim();

  return (
    <article className="sale-receipt-paper text-black">
      <header className="sale-receipt-block text-center">
        {company?.company_name && (
          <div className="sale-receipt-company-name">{company.company_name}</div>
        )}
        {company?.cnpjFormatted && (
          <div className="sale-receipt-muted">CNPJ: {company.cnpjFormatted}</div>
        )}
        {company?.phoneFormatted && (
          <div className="sale-receipt-muted">{company.phoneFormatted}</div>
        )}
        {company?.email && <div className="sale-receipt-muted">{company.email}</div>}
        {company?.addressLine && <div className="sale-receipt-muted">{company.addressLine}</div>}
        {company?.cityState && <div className="sale-receipt-muted">{company.cityState}</div>}
      </header>

      <div className="sale-receipt-rule" aria-hidden />

      <div className="sale-receipt-block text-center">
        <div className="sale-receipt-title">COMPROVANTE DE VENDA</div>
        <div className="sale-receipt-nonfiscal">NÃO É DOCUMENTO FISCAL</div>
        {cancelada && <div className="sale-receipt-cancelled">VENDA CANCELADA</div>}
      </div>

      <div className="sale-receipt-rule" aria-hidden />

      <div className="sale-receipt-block sale-receipt-meta">
        <div>Venda: #{sale.numero}</div>
        {dataHora && <div>Data: {dataHora}</div>}
        <div>Cliente: {cliente}</div>
        {clienteDoc && (
          <div>
            {clienteDoc.label}: {clienteDoc.value}
          </div>
        )}
        <div>Pagamento: {pagamento}</div>
      </div>

      <div className="sale-receipt-rule" aria-hidden />

      <div className="sale-receipt-block">
        {items.map((item, idx) => (
          <div key={idx} className="sale-receipt-item">
            <div className="sale-receipt-item-name">{item.descricao}</div>
            <div className="sale-receipt-item-qty">{saleReceiptItemQtyLine(item)}</div>
            <div className="sale-receipt-item-sub">{brl(Number(item.subtotal) || 0)}</div>
          </div>
        ))}
      </div>

      <div className="sale-receipt-rule" aria-hidden />

      <div className="sale-receipt-block sale-receipt-totals">
        <div className="sale-receipt-row">
          <span>Subtotal</span>
          <span>{brl(subtotal)}</span>
        </div>
        {desconto > 0 && (
          <div className="sale-receipt-row">
            <span>Desconto</span>
            <span>- {brl(desconto)}</span>
          </div>
        )}
        {acrescimo > 0 && (
          <div className="sale-receipt-row">
            <span>Acréscimo</span>
            <span>{brl(acrescimo)}</span>
          </div>
        )}
        <div className="sale-receipt-row sale-receipt-total">
          <span>TOTAL</span>
          <span>{brl(total)}</span>
        </div>
      </div>

      {observacoes && (
        <>
          <div className="sale-receipt-rule" aria-hidden />
          <div className="sale-receipt-block">
            <div className="sale-receipt-obs-label">Observações</div>
            <div className="sale-receipt-obs">{observacoes}</div>
          </div>
        </>
      )}

      <div className="sale-receipt-rule" aria-hidden />

      <footer className="sale-receipt-block text-center">
        <div>Obrigado pela preferência.</div>
        <div className="sale-receipt-footer-note">Comprovante gerado pelo VersaGlass</div>
        <div className="sale-receipt-footer-note">NÃO É DOCUMENTO FISCAL</div>
      </footer>
    </article>
  );
}
