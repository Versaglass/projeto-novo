import { AlertTriangle } from "lucide-react";

/**
 * Faixa de aviso do bloco "biblioteca bloqueada por assinatura" (Revisao 113).
 *
 * PURAMENTE VISUAL. Nao le dado, nao consulta plano, nao decide navegacao e nao
 * toca em logica nenhuma — e so um <div> com texto. Existe para o caso de
 * alguem chegar a uma das quatro telas do bloco digitando a URL, e descobrir
 * ali mesmo que aquilo nao esta em uso, em vez de tentar assinar um plano que
 * nao existe.
 *
 * Por que uma faixa e nao um redirect: redirecionar seria decidir o destino do
 * bloco, e a decisao do responsavel foi MANTER as telas. O aviso informa sem
 * remover nada.
 *
 * O comentario de cabecalho de cada rota do bloco explica o contexto inteiro.
 */
export function AvisoBlocoForaDeUso() {
  return (
    <div
      role="status"
      className="mx-auto mb-6 flex max-w-4xl items-start gap-3 rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-sm text-amber-200"
    >
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
      <p>
        <b>Tela fora de uso.</b> Esta é a interface de um sistema de assinatura de biblioteca de
        modelos que <b>nunca foi conectado</b> — não há como contratar plano, e o editor que ela
        oferece nunca foi construído. Ela continua no ar por decisão de produto, sem uso ativo. O
        editor de desenho que <b>funciona</b> está em <b>Projetos › Editar desenho</b> e em{" "}
        <b>Editor 2D</b>, no menu do aplicativo.
      </p>
    </div>
  );
}
