import { Lock, Crown, CheckCircle2 } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { MODULES, type ModuleKey } from "@/lib/module-access";

export function ModuleLockedCard({ moduleKey }: { moduleKey: ModuleKey }) {
  const module = MODULES[moduleKey];
  return (
    <div className="rounded-2xl border bg-card p-8 text-center shadow-sm">
      <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-gold/15 text-gold">
        <Lock className="h-7 w-7" />
      </div>
      <h1 className="mt-5 font-display text-2xl font-bold">{module.label} bloqueado</h1>
      <p className="mx-auto mt-2 max-w-xl text-sm text-muted-foreground">
        Este módulo faz parte do <strong>{module.upgradePlan}</strong>. O cliente consegue
        visualizar que existe, mas só libera após assinar ou fazer upgrade.
      </p>
      <div className="mx-auto mt-5 grid max-w-xl gap-2 text-left text-sm md:grid-cols-2">
        <div className="rounded-xl border bg-muted/20 p-3">
          <CheckCircle2 className="mb-1 h-4 w-4 text-gold" /> Catálogo técnico liberado
        </div>
        <div className="rounded-xl border bg-muted/20 p-3">
          <CheckCircle2 className="mb-1 h-4 w-4 text-gold" /> Orçamento integrado
        </div>
        <div className="rounded-xl border bg-muted/20 p-3">
          <CheckCircle2 className="mb-1 h-4 w-4 text-gold" /> Estoque e compras
        </div>
        <div className="rounded-xl border bg-muted/20 p-3">
          <CheckCircle2 className="mb-1 h-4 w-4 text-gold" /> Projetos editáveis
        </div>
      </div>
      <Link
        to="/app/minha-assinatura"
        className="mt-6 inline-flex items-center gap-2 rounded-lg bg-gradient-gold px-5 py-2.5 text-sm font-semibold text-gold-foreground shadow-glow hover:opacity-95"
      >
        <Crown className="h-4 w-4" /> Fazer upgrade
      </Link>
    </div>
  );
}
