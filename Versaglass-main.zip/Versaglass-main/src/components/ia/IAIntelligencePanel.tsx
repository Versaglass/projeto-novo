import { useMemo, useRef, useState } from "react";
import {
  Bot,
  LockKeyhole,
  Mic,
  MicOff,
  Send,
  ShieldCheck,
  X,
  RotateCcw,
  History,
  AlertTriangle,
  ScanSearch,
  Brain,
  Lightbulb,
  CheckCircle2,
  Volume2,
  VolumeX,
  KeyRound,
  MessageCircle,
  Sparkles,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/use-auth";
import {
  IA_GUIDED_WORKFLOW,
  buildGuidedWorkflowPlan,
  buildIAActionPlan,
  buildPlanFromScanFinding,
  confirmAdminPassword,
  executeIAAction,
  runIAIntelligenceScan,
  saveIACommand,
  saveIAKnowledge,
  type IAActionPlan,
  type IAScanFinding,
  type IAScanPeriod,
} from "@/lib/ia-intelligence";
import { iaAdvise, type IAAdviseResult } from "@/lib/ia-intelligence-chat.functions";
import {
  AI_ADMIN_DISABLED_MESSAGE,
  AI_ADMIN_EXECUTION_ENABLED,
} from "@/modules/ai-intelligence/config";
import { supabase } from "@/integrations/supabase/client";
import { campoTextoDoErro, mensagemDoErro } from "@/lib/erro-mensagem";

type ChatTurn = {
  role: "user" | "assistant";
  content: string;
  suggestions?: string[];
  refinedCommand?: string;
};

export function IAIntelligencePanel() {
  const { isAdmin, user, role } = useAuth();
  // Modo seguro (P-26): a execução/persistência administrativa depende de tabelas
  // ausentes no schema. Desligada por flag central. Só orientação (iaAdvise) e
  // prévia (cálculo no cliente) permanecem. Ver src/modules/ai-intelligence/config.ts.
  const executionDisabled = !AI_ADMIN_EXECUTION_ENABLED;
  const [open, setOpen] = useState(false);
  const [command, setCommand] = useState("");
  const [password, setPassword] = useState("");
  const [requirePassword, setRequirePassword] = useState(
    () => localStorage.getItem("ia-intelligence-require-password") === "true",
  );
  const [voiceEnabled, setVoiceEnabled] = useState(
    () => localStorage.getItem("ia-intelligence-voice") !== "false",
  );
  const [plan, setPlan] = useState<IAActionPlan | null>(null);
  const [running, setRunning] = useState(false);
  const [history, setHistory] = useState<
    {
      id: string;
      action_type: string;
      action_summary: string;
      status?: string | null;
      created_at: string;
    }[]
  >([]);
  const [knowledge, setKnowledge] = useState("");
  const [scanPeriod, setScanPeriod] = useState<IAScanPeriod>(15);
  const [scanRunning, setScanRunning] = useState(false);
  const [scanFindings, setScanFindings] = useState<IAScanFinding[]>([]);
  const [guidedModule, setGuidedModule] = useState<string | null>(null);
  const [agentName, setAgentName] = useState("");
  const [agentObjective, setAgentObjective] = useState("");
  const [listening, setListening] = useState(false);
  const [conversation, setConversation] = useState<ChatTurn[]>([]);
  const [advising, setAdvising] = useState(false);
  const [lastAdvice, setLastAdvice] = useState<IAAdviseResult | null>(null);
  const [voiceMode, setVoiceMode] = useState<
    "idle" | "listening-command" | "speaking" | "listening-confirm" | "executing"
  >("idle");
  const [micPermission, setMicPermission] = useState<"granted" | "denied" | "prompt">("prompt");
  const recognitionRef = useRef<any>(null);
  const commandRef = useRef("");
  commandRef.current = command;

  function speak(text: string) {
    if (!voiceEnabled || typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.replace(/[*_#`]/g, ""));
    utterance.lang = "pt-BR";
    utterance.rate = 0.96;
    utterance.pitch = 1;
    window.speechSynthesis.speak(utterance);
  }

  function speakAsync(text: string): Promise<void> {
    return new Promise((resolve) => {
      if (typeof window === "undefined" || !("speechSynthesis" in window)) return resolve();
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text.replace(/[*_#`]/g, ""));
      utterance.lang = "pt-BR";
      utterance.rate = 0.96;
      utterance.pitch = 1;
      utterance.onend = () => resolve();
      utterance.onerror = () => resolve();
      // Fallback: se voz estiver desativada, apenas resolve imediatamente
      if (!voiceEnabled) return resolve();
      window.speechSynthesis.speak(utterance);
    });
  }

  async function checkMicPermission(): Promise<"granted" | "denied" | "prompt"> {
    try {
      if (navigator.permissions && (navigator.permissions as any).query) {
        const result = await (navigator.permissions as any).query({ name: "microphone" });
        return result.state;
      }
    } catch {
      // Intencionalmente vazio. `permissions.query({ name: "microphone" })` não
      // é suportado em todo navegador e lança quando não é. O `return "prompt"`
      // logo abaixo já é a resposta correta para "não sei o estado", e quem
      // chama trata os três valores — não há nada a registrar aqui.
    }
    return "prompt";
  }

  async function ensureMicPermission(): Promise<boolean> {
    const status = await checkMicPermission();
    setMicPermission(status);
    if (status === "granted") return true;
    try {
      if (navigator?.mediaDevices?.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((t) => t.stop());
        setMicPermission("granted");
        return true;
      }
      return false;
    } catch (err: unknown) {
      setMicPermission("denied");
      return false;
    }
  }

  function listenOnce(maxMs = 15000, silenceMs = 1800): Promise<string> {
    return new Promise((resolve, reject) => {
      const SR: any =
        typeof window !== "undefined" &&
        ((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
      if (!SR) return reject(new Error("Reconhecimento de voz não suportado. Use Chrome ou Edge."));
      const rec = new SR();
      rec.lang = "pt-BR";
      rec.continuous = true;
      rec.interimResults = true;
      let finalText = "";
      let silenceTimer: any = null;
      const maxTimer = setTimeout(() => {
        try {
          rec.stop();
        } catch {
          // Intencionalmente vazio: `SpeechRecognition.stop()` lança InvalidStateError
          // se o reconhecimento já parou sozinho. Parar o que já parou é o
          // resultado desejado; não há falha a tratar.
        }
      }, maxMs);
      const resetSilence = () => {
        if (silenceTimer) clearTimeout(silenceTimer);
        silenceTimer = setTimeout(() => {
          try {
            rec.stop();
          } catch {
            // Intencionalmente vazio: `SpeechRecognition.stop()` lança InvalidStateError
            // se o reconhecimento já parou sozinho. Parar o que já parou é o
            // resultado desejado; não há falha a tratar.
          }
        }, silenceMs);
      };
      rec.onresult = (e: any) => {
        for (let i = e.resultIndex; i < e.results.length; i++) {
          const chunk = e.results[i][0].transcript;
          if (e.results[i].isFinal) finalText += chunk + " ";
        }
        resetSilence();
      };
      rec.onerror = (e: any) => {
        clearTimeout(maxTimer);
        if (silenceTimer) clearTimeout(silenceTimer);
        setListening(false);
        if (e?.error === "no-speech") return resolve("");
        reject(new Error(e?.error || "erro no reconhecimento"));
      };
      rec.onend = () => {
        clearTimeout(maxTimer);
        if (silenceTimer) clearTimeout(silenceTimer);
        setListening(false);
        resolve(finalText.trim());
      };
      recognitionRef.current = rec;
      try {
        rec.start();
        setListening(true);
        resetSilence();
      } catch (err: unknown) {
        reject(err);
      }
    });
  }

  function detectAffirmative(text: string): "yes" | "no" | "unknown" {
    const t = text
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");
    if (/(cancel|nao|negativ|para tudo|abort|desist|esquec)/.test(t)) return "no";
    if (/(sim|confirm|ok|pode|executa|manda|autoriz|prossig|vai|isso|correto|certo|beleza)/.test(t))
      return "yes";
    return "unknown";
  }

  async function startVoiceConversation() {
    if (executionDisabled) return; // modo seguro (P-26): a conversa por voz auto-executa
    if (voiceMode !== "idle") return;
    if (!voiceEnabled) {
      toast.info("Ative a voz da IA para usar a conversa por voz.");
      return;
    }
    const ok = await ensureMicPermission();
    if (!ok) return;
    try {
      setVoiceMode("speaking");
      await speakAsync("Estou ouvindo. Diga qual comando você quer executar.");
      setVoiceMode("listening-command");
      toast.info("Fale seu comando agora…");
      const spoken = await listenOnce(20000, 2000);
      if (!spoken) {
        await speakAsync("Não ouvi nada. Vamos tentar de novo quando quiser.");
        setVoiceMode("idle");
        return;
      }
      setCommand(spoken);
      const nextPlan = buildIAActionPlan(spoken);
      setPlan(nextPlan);
      setConversation((c) => [...c, { role: "user", content: spoken }]);
      const riskWord =
        { baixo: "baixo", medio: "médio", alto: "alto", critico: "crítico" }[nextPlan.risk] ||
        nextPlan.risk;
      const planSpeech = `Entendi. O comando será executado da seguinte forma: ${nextPlan.title}. ${nextPlan.summary} O risco é ${riskWord}. Você confirma a execução? Responda sim ou não.`;
      setConversation((c) => [...c, { role: "assistant", content: planSpeech }]);
      setVoiceMode("speaking");
      await speakAsync(planSpeech);
      setVoiceMode("listening-confirm");
      toast.info("Diga 'sim' para executar ou 'não' para cancelar.");
      const reply = await listenOnce(10000, 1500);
      const decision = detectAffirmative(reply);
      setConversation((c) => [...c, { role: "user", content: reply || "(sem resposta)" }]);
      if (decision === "yes") {
        setVoiceMode("speaking");
        await speakAsync("Confirmado. Executando agora.");
        setVoiceMode("executing");
        await sendAndExecute();
      } else if (decision === "no") {
        setVoiceMode("speaking");
        await speakAsync("Comando cancelado. Nada foi executado.");
        setPlan(null);
        setCommand("");
        toast.info("Comando cancelado por voz.");
      } else {
        setVoiceMode("speaking");
        await speakAsync(
          "Não entendi sua resposta. Vou aguardar. Clique em enviar e executar se quiser confirmar, ou fale de novo.",
        );
      }
    } catch (err: unknown) {
      toast.error("Erro na conversa por voz: " + (mensagemDoErro(err) || "desconhecido"));
      await speakAsync("Tive um problema na conversa por voz.");
    } finally {
      setVoiceMode("idle");
    }
  }

  function stopListening() {
    try {
      recognitionRef.current?.stop();
    } catch {
      // Intencionalmente vazio: mesmo caso do `rec.stop()` — lança se já parou.
      // O `setListening(false)` abaixo roda de qualquer forma, então o estado da
      // interface fica correto nos dois caminhos.
    }
    setListening(false);
  }

  async function toggleListening() {
    if (listening) {
      stopListening();
      return;
    }
    const SR: any =
      typeof window !== "undefined" &&
      ((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
    if (!SR) {
      toast.error("Reconhecimento de voz não suportado neste navegador. Use Chrome ou Edge.");
      return;
    }
    // Solicita permissão explícita ao microfone antes de iniciar o reconhecimento
    try {
      if (navigator?.mediaDevices?.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((t) => t.stop());
      }
    } catch (err: unknown) {
      // `getUserMedia` rejeita com DOMException, e é o `.name` dela que separa
      // permissão negada de microfone ausente. Leitura estrutural porque
      // DOMException não é garantidamente instância de `Error`.
      const nome = campoTextoDoErro(err, "name");
      if (nome === "NotAllowedError" || nome === "SecurityError") {
        toast.error(
          "Permissão do microfone negada. Habilite o microfone nas configurações do navegador (ícone de cadeado na barra de endereço).",
        );
      } else if (nome === "NotFoundError") {
        toast.error("Nenhum microfone encontrado neste dispositivo.");
      } else {
        toast.error(
          "Não foi possível acessar o microfone: " +
            (mensagemDoErro(err) || nome || "erro desconhecido"),
        );
      }
      return;
    }

    const rec = new SR();
    rec.lang = "pt-BR";
    rec.continuous = true;
    rec.interimResults = true;
    let finalBuffer = "";
    const baseCommand = commandRef.current ? commandRef.current + " " : "";

    rec.onresult = (event: any) => {
      let interim = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const chunk = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalBuffer += chunk + " ";
        else interim += chunk;
      }
      const combined = (baseCommand + finalBuffer + interim).replace(/\s+/g, " ").trim();
      setCommand(combined);
    };
    rec.onerror = (e: any) => {
      setListening(false);
      if (e?.error === "not-allowed")
        toast.error("Permita o acesso ao microfone para usar o comando por voz.");
      else if (e?.error !== "aborted" && e?.error !== "no-speech")
        toast.error("Erro no reconhecimento de voz: " + (e?.error || ""));
    };
    rec.onend = () => setListening(false);

    recognitionRef.current = rec;
    try {
      rec.start();
      setListening(true);
      speak("Pode falar. Depois clique em Enviar.");
      toast.info("Ouvindo… fale o comando e clique em Enviar.");
    } catch {
      setListening(false);
    }
  }

  function toggleVoice() {
    const next = !voiceEnabled;
    setVoiceEnabled(next);
    localStorage.setItem("ia-intelligence-voice", String(next));
    if (!next && typeof window !== "undefined" && "speechSynthesis" in window)
      window.speechSynthesis.cancel();
    if (next) setTimeout(() => speak("Resposta por áudio ativada na IA Intelligence."), 50);
  }

  function togglePasswordMode() {
    const next = !requirePassword;
    setRequirePassword(next);
    localStorage.setItem("ia-intelligence-require-password", String(next));
    toast.success(
      next
        ? "Senha ADM ativada para ações da IA Intelligence."
        : "Senha ADM removida temporariamente da IA Intelligence.",
    );
    speak(
      next
        ? "Senha administrativa ativada para ações da IA Intelligence."
        : "Senha administrativa removida temporariamente da IA Intelligence.",
    );
  }

  const canShow = isAdmin && user?.email;
  const riskClass = useMemo(() => {
    if (!plan) return "bg-slate-500/10 text-slate-300 border-slate-500/20";
    return {
      baixo: "bg-green-500/10 text-green-300 border-green-500/20",
      medio: "bg-yellow-500/10 text-yellow-300 border-yellow-500/20",
      alto: "bg-orange-500/10 text-orange-300 border-orange-500/20",
      critico: "bg-red-500/10 text-red-300 border-red-500/20",
    }[plan.risk];
  }, [plan]);

  if (!canShow) return null;

  async function preparePlan() {
    if (!command.trim()) return toast.error("Digite ou dite um comando para a IA Intelligence.");
    const nextPlan = buildIAActionPlan(command);
    setPlan(nextPlan);
    speak(`Prévia criada: ${nextPlan.title}. ${nextPlan.summary}`);
  }

  async function converseWithIA(overrideCommand?: string) {
    const text = (overrideCommand ?? command).trim();
    if (!text) return toast.error("Digite ou dite um comando para conversar com a IA.");
    if (listening) stopListening();
    const userTurn: ChatTurn = { role: "user", content: text };
    setConversation((c) => [...c, userTurn]);
    setAdvising(true);
    try {
      const history = conversation.slice(-6).map((t) => ({ role: t.role, content: t.content }));
      const advice = await iaAdvise({
        data: { command: text, history, context: `Usuário: ${user?.email}. Papel: ${role}.` },
      });
      setLastAdvice(advice);
      setConversation((c) => [
        ...c,
        {
          role: "assistant",
          content: advice.reply,
          suggestions: advice.suggestions,
          refinedCommand: advice.refinedCommand,
        },
      ]);
      const spokenSuggestions = advice.suggestions.length
        ? ` Algumas sugestões: ${advice.suggestions.slice(0, 3).join(". ")}.`
        : "";
      speak(`${advice.reply}${spokenSuggestions} Se estiver bom, clique em enviar e executar.`);
      if (advice.refinedCommand && advice.refinedCommand !== text)
        setCommand(advice.refinedCommand);
      toast.success("A IA respondeu com sugestões.");
    } catch (e: unknown) {
      const msg = mensagemDoErro(e) || "Não foi possível conversar com a IA.";
      setConversation((c) => [...c, { role: "assistant", content: msg }]);
      toast.error(msg);
      speak("Não consegui responder agora.");
    } finally {
      setAdvising(false);
    }
  }

  async function sendAndExecute() {
    if (executionDisabled) return; // modo seguro (P-26): não toca o Supabase
    if (!command.trim()) return toast.error("Digite ou dite um comando primeiro.");
    if (!user?.email || !user?.id) return;
    if (listening) stopListening();
    if (requirePassword && !password) {
      const nextPlan = buildIAActionPlan(command);
      setPlan(nextPlan);
      toast.info("Senha ADM obrigatória. Preencha para confirmar a execução.");
      speak("Prévia criada. Digite a senha administrativa para confirmar.");
      return;
    }
    const nextPlan = buildIAActionPlan(command);
    setPlan(nextPlan);
    setRunning(true);
    try {
      if (requirePassword) await confirmAdminPassword(user.email, password);
      const commandId = await saveIACommand(user.id, command, nextPlan);
      await supabase.from("ai_intelligence_approvals" as any).insert({
        command_id: commandId,
        user_id: user.id,
        approved: true,
        approved_at: new Date().toISOString(),
      });
      await executeIAAction(nextPlan, user.id, commandId);
      toast.success("Comando executado pela IA Intelligence.");
      speak(`Comando executado. ${nextPlan.title}.`);
      setCommand("");
      setPassword("");
      setPlan(null);
      loadHistory();
    } catch (e: unknown) {
      toast.error(mensagemDoErro(e) || "Não foi possível executar o comando.");
      speak("Não foi possível executar o comando.");
    } finally {
      setRunning(false);
    }
  }

  async function loadHistory() {
    if (executionDisabled) return; // modo seguro (P-26): ai_intelligence_logs ausente
    const { data } = await supabase
      .from("ai_intelligence_logs" as any)
      .select("id, action_type, action_summary, status, created_at")
      .order("created_at", { ascending: false })
      .limit(10);
    setHistory(
      ((data as
        | {
            id: string;
            action_type: string;
            action_summary: string;
            status?: string | null;
            created_at: string;
          }[]
        | null) || []),
    );
  }

  async function saveLearning() {
    if (executionDisabled) return; // modo seguro (P-26): ai_intelligence_knowledge ausente
    if (!user?.id) return;
    if (!knowledge.trim()) return toast.error("Digite a informação que a IA deve aprender.");
    try {
      await saveIAKnowledge(user.id, knowledge);
      toast.success("Conhecimento salvo para a IA Intelligence.");
      speak("Conhecimento salvo para a IA Intelligence.");
      setKnowledge("");
    } catch (e: unknown) {
      toast.error(mensagemDoErro(e) || "Não foi possível salvar o conhecimento.");
    }
  }

  async function startScan() {
    if (executionDisabled) return; // modo seguro (P-26): tabelas de varredura ausentes
    if (!user?.id) return;
    setScanRunning(true);
    try {
      const result = await runIAIntelligenceScan(user.id, scanPeriod);
      setScanFindings(result.findings);
      toast.success(result.summary);
      speak(
        `${result.summary} ${result.findings.length ? "Encontrei pontos que precisam de atenção." : "Nenhum problema crítico encontrado."}`,
      );
    } catch (e: unknown) {
      toast.error(mensagemDoErro(e) || "Não foi possível executar a varredura.");
    } finally {
      setScanRunning(false);
    }
  }

  function prepareFindingResolution(finding: IAScanFinding) {
    if (executionDisabled) return; // modo seguro (P-26)
    setPlan(buildPlanFromScanFinding(finding));
    setCommand(finding.suggestedCommand);
    toast.info(
      requirePassword
        ? "Prévia criada. Digite a senha ADM para autorizar a correção."
        : "Prévia criada. Confirme para executar sem senha temporariamente.",
    );
    speak(`Prévia criada para resolver: ${finding.title}.`);
  }

  function startGuidedWorkflow(moduleId: string, childId?: string) {
    if (executionDisabled) return; // modo seguro (P-26)
    const workflowPlan = buildGuidedWorkflowPlan(moduleId, childId);
    setPlan(workflowPlan);
    setCommand(
      `Alteração assistida: ${workflowPlan.payload.moduleLabel || moduleId}${workflowPlan.payload.childLabel ? ` > ${workflowPlan.payload.childLabel}` : ""}`,
    );
    toast.info(
      requirePassword
        ? "Fluxo assistido preparado. Revise e confirme com senha ADM."
        : "Fluxo assistido preparado. Revise e confirme sem senha temporariamente.",
    );
    speak(`Fluxo assistido preparado: ${workflowPlan.title}.`);
  }

  function prepareAgentCreation() {
    if (executionDisabled) return; // modo seguro (P-26)
    if (!agentName.trim()) return toast.error("Informe o nome da nova IA.");
    const cmd = `Criar IA nome: ${agentName}; objetivo: ${agentObjective || "Agente especializado criado pelo ADM"}`;
    setCommand(cmd);
    setPlan(buildIAActionPlan(cmd));
  }

  async function confirmAndExecute() {
    if (executionDisabled) return; // modo seguro (P-26)
    if (!plan || !user?.email || !user?.id) return;
    if (requirePassword && !password) return toast.error("Digite a senha do ADM para confirmar.");
    setRunning(true);
    try {
      if (requirePassword) await confirmAdminPassword(user.email, password);
      const commandId = await saveIACommand(user.id, command, plan);
      await supabase.from("ai_intelligence_approvals" as any).insert({
        command_id: commandId,
        user_id: user.id,
        approved: true,
        approved_at: new Date().toISOString(),
      });
      await executeIAAction(plan, user.id, commandId);
      toast.success("Ação executada pela IA Intelligence e registrada no histórico.");
      speak("Ação executada pela IA Intelligence e registrada no histórico.");
      setCommand("");
      setPassword("");
      setPlan(null);
      loadHistory();
    } catch (e: unknown) {
      toast.error(mensagemDoErro(e) || "Não foi possível executar a ação.");
    } finally {
      setRunning(false);
    }
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-5 right-5 z-50 flex items-center gap-2 rounded-full bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-500 px-5 py-3 text-white shadow-2xl shadow-blue-900/30 hover:scale-[1.02] transition"
      >
        <Bot className="h-5 w-5" /> IA Intelligence
      </button>
      {open && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm">
          <aside className="absolute right-0 top-0 h-full w-full max-w-2xl overflow-y-auto border-l border-white/10 bg-[#07111f] text-white shadow-2xl">
            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-white/10 bg-[#07111f]/95 px-6 py-5 backdrop-blur">
              <div>
                <h2 className="flex items-center gap-2 text-2xl font-bold">
                  <ShieldCheck className="text-cyan-400" /> IA Intelligence
                </h2>
                <p className="text-sm text-slate-400">
                  ADM operacional com voz, prévia e confirmação. Senha pode ser ativada depois.
                </p>
              </div>
              <button onClick={() => setOpen(false)} className="rounded-xl p-2 hover:bg-white/10">
                <X />
              </button>
            </div>

            <div className="space-y-5 p-6">
              <div className="rounded-2xl border border-cyan-500/20 bg-cyan-500/10 p-4 text-sm text-cyan-100">
                <b>Regra ativa:</b> a IA só executa após comando e prévia da ação. A senha ADM está
                temporariamente opcional e pode ser ativada pelo botão abaixo. Usuários comuns não
                visualizam este painel.
              </div>

              {executionDisabled && (
                <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm text-amber-100">
                  <b>{AI_ADMIN_DISABLED_MESSAGE}</b>
                  <p className="mt-1 text-amber-100/80">
                    Você ainda pode conversar com a IA para receber orientação e visualizar a prévia
                    de uma ação — mas nenhuma alteração é aplicada.
                  </p>
                </div>
              )}

              {micPermission === "denied" && (
                <div className="rounded-2xl border border-red-500/30 bg-red-500/10 p-5 text-red-100">
                  <div className="flex items-start gap-3">
                    <div className="mt-1 rounded-full bg-red-500/20 p-2">
                      <MicOff className="h-5 w-5 text-red-300" />
                    </div>
                    <div className="flex-1">
                      <h4 className="mb-1 font-bold text-red-200">Microfone bloqueado</h4>
                      <p className="mb-3 text-sm text-red-100/80">
                        O acesso ao microfone foi negado. Para usar os comandos de voz e a conversa
                        com a IA, você precisa permitir o microfone.
                      </p>
                      <ol className="mb-3 list-decimal space-y-1 pl-5 text-sm text-red-100/80">
                        <li>
                          Clique no ícone de <b>cadeado</b> (🔒) na barra de endereço do navegador.
                        </li>
                        <li>
                          Encontre a opção <b>Microfone</b> e mude para <b>Permitir</b>.
                        </li>
                        <li>Recarregue a página (F5).</li>
                      </ol>
                      <button
                        onClick={async () => {
                          const ok = await ensureMicPermission();
                          if (ok)
                            toast.success(
                              "Microfone liberado! Agora você pode usar a conversa por voz.",
                            );
                          else
                            toast.error("Permissão ainda negada. Verifique as instruções acima.");
                        }}
                        className="inline-flex items-center gap-2 rounded-xl bg-red-600 px-4 py-2 font-semibold text-white hover:bg-red-700"
                      >
                        <Mic className="h-4 w-4" /> Tentar liberar microfone
                      </button>
                    </div>
                  </div>
                </div>
              )}

              <div className="grid gap-3 md:grid-cols-2">
                <button
                  onClick={toggleVoice}
                  className={`flex items-center justify-between rounded-2xl border p-4 text-left ${voiceEnabled ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-100" : "border-white/10 bg-white/[0.03] text-slate-300"}`}
                >
                  <span>
                    <b className="block">Resposta por áudio</b>
                    <small>
                      {voiceEnabled
                        ? "Ativada — a IA fala os principais retornos."
                        : "Desativada — clique para ligar a voz."}
                    </small>
                  </span>
                  {voiceEnabled ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
                </button>

                <button
                  onClick={togglePasswordMode}
                  className={`flex items-center justify-between rounded-2xl border p-4 text-left ${requirePassword ? "border-yellow-500/30 bg-yellow-500/10 text-yellow-100" : "border-blue-500/30 bg-blue-500/10 text-blue-100"}`}
                >
                  <span>
                    <b className="block">Senha da IA</b>
                    <small>
                      {requirePassword
                        ? "Ativada — senha ADM exigida em toda ação."
                        : "Aberta por enquanto — clique para adicionar senha."}
                    </small>
                  </span>
                  <KeyRound className="h-5 w-5" />
                </button>
              </div>

              <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-4">
                <h3 className="mb-2 flex items-center gap-2 text-lg font-bold text-emerald-100">
                  <Brain className="h-5 w-5" /> Aprendizado da IA
                </h3>
                <p className="mb-3 text-sm text-emerald-100/80">
                  Registre regras, preferências, processos internos e padrões da empresa. A IA salva
                  esse conhecimento para usar nas próximas análises e sugestões.
                </p>
                <textarea
                  value={knowledge}
                  onChange={(e) => setKnowledge(e.target.value)}
                  rows={3}
                  className="w-full rounded-xl border border-white/10 bg-[#0b1628] p-3 text-sm outline-none focus:border-emerald-500"
                  placeholder="Ex.: Sempre considerar 10% de perda em vidro temperado; priorizar fornecedor X em alumínios brancos; não vender abaixo de 35% de margem..."
                />
                <button
                  onClick={saveLearning}
                  disabled={executionDisabled}
                  title={executionDisabled ? AI_ADMIN_DISABLED_MESSAGE : undefined}
                  className="mt-3 inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 font-semibold hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <CheckCircle2 className="h-4 w-4" /> Salvar conhecimento
                </button>
              </div>

              <div className="rounded-2xl border border-blue-500/20 bg-blue-500/10 p-4">
                <h3 className="mb-2 flex items-center gap-2 text-lg font-bold text-blue-100">
                  <Lightbulb className="h-5 w-5" /> Modo assistido
                </h3>
                <p className="mb-3 text-sm text-blue-100/80">
                  Quando você disser “gostaria de fazer uma alteração”, a IA também pode abrir este
                  menu por módulos. Clique em uma área para preparar o fluxo sem texto longo.
                </p>
                <div className="grid gap-2 md:grid-cols-2">
                  {IA_GUIDED_WORKFLOW.map((item) => (
                    <button
                      key={item.id}
                      disabled={executionDisabled}
                      title={executionDisabled ? AI_ADMIN_DISABLED_MESSAGE : undefined}
                      onClick={() =>
                        item.children
                          ? setGuidedModule(guidedModule === item.id ? null : item.id)
                          : startGuidedWorkflow(item.id)
                      }
                      className="rounded-xl border border-white/10 bg-[#0b1628] p-3 text-left hover:border-blue-400 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <b className="text-white">{item.label}</b>
                      <p className="mt-1 text-xs text-slate-400">{item.description}</p>
                    </button>
                  ))}
                </div>
                {guidedModule && (
                  <div className="mt-3 rounded-xl border border-white/10 bg-black/20 p-3">
                    <p className="mb-2 text-sm font-semibold text-blue-100">Escolha a subárea:</p>
                    <div className="grid gap-2 md:grid-cols-2">
                      {IA_GUIDED_WORKFLOW.find((item) => item.id === guidedModule)?.children?.map(
                        (child) => (
                          <button
                            key={child.id}
                            disabled={executionDisabled}
                            onClick={() => startGuidedWorkflow(guidedModule, child.id)}
                            className="rounded-lg bg-white/10 p-3 text-left text-sm hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-50"
                          >
                            <b>{child.label}</b>
                            <p className="text-xs text-slate-400">{child.description}</p>
                          </button>
                        ),
                      )}
                    </div>
                  </div>
                )}
              </div>

              <div className="rounded-2xl border border-orange-500/20 bg-orange-500/10 p-4">
                <h3 className="mb-2 flex items-center gap-2 text-lg font-bold text-orange-100">
                  <Bot className="h-5 w-5" /> Gerenciar outras IAs
                </h3>
                <p className="mb-3 text-sm text-orange-100/80">
                  A IA Intelligence pode criar, ativar, desativar e ajustar outras IAs, sempre com
                  prévia. A senha ADM pode ser ativada novamente quando o sistema estiver
                  finalizado.
                </p>
                <div className="grid gap-3 md:grid-cols-2">
                  <input
                    value={agentName}
                    onChange={(e) => setAgentName(e.target.value)}
                    className="rounded-xl border border-white/10 bg-[#0b1628] px-3 py-2 text-sm outline-none focus:border-orange-500"
                    placeholder="Nome da IA. Ex.: IA Atendimento"
                  />
                  <input
                    value={agentObjective}
                    onChange={(e) => setAgentObjective(e.target.value)}
                    className="rounded-xl border border-white/10 bg-[#0b1628] px-3 py-2 text-sm outline-none focus:border-orange-500"
                    placeholder="Objetivo. Ex.: responder clientes no WhatsApp"
                  />
                </div>
                <button
                  onClick={prepareAgentCreation}
                  disabled={executionDisabled}
                  title={executionDisabled ? AI_ADMIN_DISABLED_MESSAGE : undefined}
                  className="mt-3 inline-flex items-center gap-2 rounded-xl bg-orange-600 px-4 py-2 font-semibold hover:bg-orange-700 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <Bot className="h-4 w-4" /> Preparar criação de IA
                </button>
              </div>

              <div className="rounded-2xl border border-fuchsia-500/20 bg-fuchsia-500/10 p-4 text-sm text-fuchsia-100">
                <h3 className="mb-2 flex items-center gap-2 text-lg font-bold">
                  <Brain className="h-5 w-5" /> Imagens e projetos realistas
                </h3>
                <p>
                  Comandos como “trocar imagem do projeto X por imagem realista” ou “criar projeto
                  com imagem realista” agora geram um plano de alteração de mídia, backup da versão
                  anterior e registro em histórico. A execução usa prévia obrigatória; a senha ADM
                  pode ser ativada novamente pelo botão da IA.
                </p>
              </div>

              <div className="rounded-2xl border border-purple-500/20 bg-purple-500/10 p-4">
                <h3 className="mb-2 flex items-center gap-2 text-lg font-bold text-purple-100">
                  <ScanSearch className="h-5 w-5" /> Varredura inteligente
                </h3>
                <p className="mb-3 text-sm text-purple-100/80">
                  Escolha um período para a IA procurar problemas, causas prováveis e soluções em
                  estoque, financeiro, fiscal e logs do sistema.
                </p>
                <div className="flex flex-col gap-3 md:flex-row">
                  <select
                    value={scanPeriod}
                    onChange={(e) => setScanPeriod(Number(e.target.value) as IAScanPeriod)}
                    className="rounded-xl border border-white/10 bg-[#0b1628] px-3 py-2 text-sm outline-none focus:border-purple-500"
                  >
                    <option value={15}>Últimos 15 dias</option>
                    <option value={30}>Últimos 30 dias</option>
                    <option value={60}>Últimos 60 dias</option>
                    <option value={90}>Últimos 3 meses</option>
                    <option value={180}>Últimos 6 meses</option>
                  </select>
                  <button
                    disabled={scanRunning || executionDisabled}
                    title={executionDisabled ? AI_ADMIN_DISABLED_MESSAGE : undefined}
                    onClick={startScan}
                    className="inline-flex items-center justify-center gap-2 rounded-xl bg-purple-600 px-4 py-2 font-semibold hover:bg-purple-700 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <ScanSearch className="h-4 w-4" />{" "}
                    {scanRunning ? "Fazendo varredura..." : "Fazer varredura"}
                  </button>
                </div>

                {scanFindings.length > 0 && (
                  <div className="mt-4 space-y-3">
                    {scanFindings.map((finding) => (
                      <div
                        key={finding.id}
                        className="rounded-xl border border-white/10 bg-black/25 p-4 text-sm"
                      >
                        <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                          <b className="text-white">{finding.title}</b>
                          <span className="rounded-full bg-white/10 px-3 py-1 text-xs uppercase text-slate-200">
                            {finding.area} • {finding.severity}
                          </span>
                        </div>
                        <p>
                          <b>Problema:</b> {finding.problem}
                        </p>
                        <p className="mt-1">
                          <b>Causa provável:</b> {finding.cause}
                        </p>
                        <p className="mt-1">
                          <b>Solução:</b> {finding.solution}
                        </p>
                        <div className="mt-3 flex flex-wrap gap-2">
                          <button
                            onClick={() => prepareFindingResolution(finding)}
                            disabled={executionDisabled}
                            className="inline-flex items-center gap-2 rounded-lg bg-green-600 px-3 py-2 font-semibold hover:bg-green-700 disabled:cursor-not-allowed disabled:opacity-50"
                          >
                            <Lightbulb className="h-4 w-4" /> Autorizar solução
                          </button>
                          <pre className="max-h-28 flex-1 overflow-auto rounded-lg bg-black/30 p-2 text-xs text-slate-300">
                            {JSON.stringify(finding.evidence, null, 2)}
                          </pre>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                <div className="mb-2 flex items-center justify-between gap-2">
                  <label className="block text-sm font-semibold text-slate-200">
                    Comando do ADM
                  </label>
                  <button
                    type="button"
                    onClick={toggleListening}
                    className={`inline-flex items-center gap-2 rounded-xl px-3 py-1.5 text-xs font-semibold transition ${listening ? "animate-pulse bg-red-600 text-white shadow-lg shadow-red-900/40" : "bg-white/10 text-slate-100 hover:bg-white/20"}`}
                    title="Falar comando (diga 'enviar' ao final)"
                  >
                    {listening ? (
                      <>
                        <MicOff className="h-4 w-4" /> Ouvindo… toque para parar
                      </>
                    ) : (
                      <>
                        <Mic className="h-4 w-4" /> Falar comando
                      </>
                    )}
                  </button>
                </div>
                <textarea
                  value={command}
                  onChange={(e) => setCommand(e.target.value)}
                  rows={5}
                  className="w-full rounded-xl border border-white/10 bg-[#0b1628] p-3 text-sm outline-none focus:border-cyan-500"
                  placeholder={
                    "Ex.: Adicionar produto nome: Espelho Orgânico 160x70, preço: 799, categoria: Espelhos, estoque: 0\nDica: clique em “Falar comando”, dite o pedido e depois clique em “Enviar” — a IA executa a alteração."
                  }
                />
                <div className="mt-3 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={startVoiceConversation}
                    disabled={voiceMode !== "idle" || executionDisabled}
                    className={`inline-flex items-center gap-2 rounded-xl px-5 py-2.5 font-bold text-white shadow-lg transition disabled:cursor-not-allowed disabled:opacity-70 ${
                      voiceMode === "listening-command" || voiceMode === "listening-confirm"
                        ? "animate-pulse bg-red-600 shadow-red-900/40"
                        : voiceMode === "speaking"
                          ? "bg-purple-600 shadow-purple-900/40"
                          : voiceMode === "executing"
                            ? "bg-emerald-600 shadow-emerald-900/40"
                            : "bg-fuchsia-600 hover:bg-fuchsia-700 shadow-fuchsia-900/40"
                    }`}
                    title={
                      executionDisabled
                        ? AI_ADMIN_DISABLED_MESSAGE
                        : "A IA ouve seu comando, explica o que fará e pede confirmação por voz"
                    }
                  >
                    {voiceMode === "listening-command" && (
                      <>
                        <Mic className="h-4 w-4" /> Ouvindo comando…
                      </>
                    )}
                    {voiceMode === "listening-confirm" && (
                      <>
                        <Mic className="h-4 w-4" /> Aguardando sim/não…
                      </>
                    )}
                    {voiceMode === "speaking" && (
                      <>
                        <Volume2 className="h-4 w-4" /> IA falando…
                      </>
                    )}
                    {voiceMode === "executing" && (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" /> Executando…
                      </>
                    )}
                    {voiceMode === "idle" && (
                      <>
                        <MessageCircle className="h-4 w-4" /> Conversa por voz
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => converseWithIA()}
                    disabled={advising}
                    className="inline-flex items-center gap-2 rounded-xl bg-cyan-600 px-5 py-2.5 font-bold text-white shadow-lg shadow-cyan-900/30 hover:bg-cyan-700 disabled:opacity-50"
                  >
                    {advising ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <MessageCircle className="h-4 w-4" />
                    )}
                    {advising ? "IA pensando…" : "Conversar com a IA"}
                  </button>
                  <button
                    type="button"
                    onClick={sendAndExecute}
                    disabled={running || executionDisabled}
                    title={executionDisabled ? AI_ADMIN_DISABLED_MESSAGE : undefined}
                    className="inline-flex items-center gap-2 rounded-xl bg-green-600 px-5 py-2.5 font-bold text-white shadow-lg shadow-green-900/30 hover:bg-green-700 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <Send className="h-4 w-4" /> {running ? "Executando…" : "Enviar e executar"}
                  </button>
                  <button
                    type="button"
                    onClick={toggleListening}
                    className={`inline-flex items-center gap-2 rounded-xl px-4 py-2 font-semibold transition ${listening ? "animate-pulse bg-red-600 text-white" : "bg-indigo-600 text-white hover:bg-indigo-700"}`}
                  >
                    {listening ? (
                      <>
                        <MicOff className="h-4 w-4" /> Parar de ouvir
                      </>
                    ) : (
                      <>
                        <Mic className="h-4 w-4" /> Falar comando
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={preparePlan}
                    className="inline-flex items-center gap-2 rounded-xl bg-white/10 px-4 py-2 font-semibold text-slate-100 hover:bg-white/20"
                  >
                    Só visualizar prévia
                  </button>
                </div>

                {conversation.length > 0 && (
                  <div className="mt-4 space-y-2 rounded-xl border border-white/10 bg-black/25 p-3">
                    <div className="mb-1 flex items-center justify-between">
                      <span className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-cyan-300">
                        <Sparkles className="h-3.5 w-3.5" /> Diálogo com a IA
                      </span>
                      <button
                        onClick={() => {
                          setConversation([]);
                          setLastAdvice(null);
                        }}
                        className="text-xs text-slate-400 hover:text-white"
                      >
                        Limpar
                      </button>
                    </div>
                    <div className="max-h-72 space-y-2 overflow-auto pr-1">
                      {conversation.map((turn, i) => (
                        <div
                          key={i}
                          className={`rounded-lg p-3 text-sm ${turn.role === "user" ? "bg-blue-500/10 text-blue-100" : "bg-cyan-500/10 text-cyan-100"}`}
                        >
                          <b className="mr-2 text-xs uppercase opacity-70">
                            {turn.role === "user" ? "Você" : "IA"}
                          </b>
                          <span className="whitespace-pre-wrap">{turn.content}</span>
                          {turn.suggestions && turn.suggestions.length > 0 && (
                            <ul className="mt-2 list-disc space-y-1 pl-5 text-xs text-cyan-50/90">
                              {turn.suggestions.map((s, j) => (
                                <li key={j}>{s}</li>
                              ))}
                            </ul>
                          )}
                          {turn.refinedCommand && turn.refinedCommand !== turn.content && (
                            <button
                              onClick={() => {
                                setCommand(turn.refinedCommand!);
                                toast.success("Comando refinado carregado.");
                              }}
                              className="mt-2 inline-flex items-center gap-1 rounded-md bg-white/10 px-2 py-1 text-xs hover:bg-white/20"
                            >
                              <CheckCircle2 className="h-3 w-3" /> Usar versão refinada
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                    {lastAdvice && (
                      <div className="mt-2 flex flex-wrap gap-2 border-t border-white/10 pt-2">
                        <button
                          onClick={sendAndExecute}
                          disabled={running || executionDisabled}
                          title={executionDisabled ? AI_ADMIN_DISABLED_MESSAGE : undefined}
                          className="inline-flex items-center gap-2 rounded-lg bg-green-600 px-3 py-1.5 text-xs font-semibold hover:bg-green-700 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          <Send className="h-3 w-3" /> Executar com as sugestões
                        </button>
                        <button
                          onClick={() =>
                            converseWithIA("Refine ainda mais e detalhe passo a passo.")
                          }
                          disabled={advising}
                          className="inline-flex items-center gap-2 rounded-lg bg-white/10 px-3 py-1.5 text-xs hover:bg-white/20 disabled:opacity-50"
                        >
                          Pedir mais detalhes
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {plan && (
                <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                  <div className="mb-3 flex items-center justify-between gap-3">
                    <h3 className="text-lg font-bold">Prévia obrigatória</h3>
                    <span
                      className={`rounded-full border px-3 py-1 text-xs uppercase ${riskClass}`}
                    >
                      Risco {plan.risk}
                    </span>
                  </div>
                  <p className="font-semibold text-cyan-200">{plan.title}</p>
                  <p className="mt-2 text-sm text-slate-300">{plan.summary}</p>
                  {!executionDisabled && (
                    <div className="mt-4 grid gap-3 rounded-xl bg-black/25 p-3 text-xs text-slate-300 md:grid-cols-2">
                      <div>
                        <b>Tabela:</b> {plan.targetTable || "sistema"}
                      </div>
                      <div>
                        <b>Operação:</b> {plan.operation || "registrar"}
                      </div>
                      <pre className="md:col-span-2 max-h-52 overflow-auto rounded-lg bg-black/30 p-3">
                        {JSON.stringify(plan.payload, null, 2)}
                      </pre>
                    </div>
                  )}

                  <div
                    className={`mt-4 rounded-xl border p-3 text-sm ${executionDisabled ? "border-amber-500/20 bg-amber-500/10 text-amber-100" : requirePassword ? "border-yellow-500/20 bg-yellow-500/10 text-yellow-100" : "border-blue-500/20 bg-blue-500/10 text-blue-100"}`}
                  >
                    <AlertTriangle className="mr-2 inline h-4 w-4" />{" "}
                    {executionDisabled
                      ? `${AI_ADMIN_DISABLED_MESSAGE} Esta é apenas uma prévia — nada será aplicado.`
                      : requirePassword
                        ? "Para executar, digite a senha do ADM. Esta confirmação está ativa."
                        : "Senha ADM removida temporariamente. Revise a prévia e confirme a ação. Você pode ativar a senha pelo botão ‘Senha da IA’."}
                  </div>

                  {requirePassword && (
                    <label className="mt-4 block text-sm font-semibold text-slate-200">
                      Senha ADM
                    </label>
                  )}
                  <div className="mt-2 flex gap-2">
                    {requirePassword && (
                      <input
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        type="password"
                        className="flex-1 rounded-xl border border-white/10 bg-[#0b1628] px-3 py-2 outline-none focus:border-cyan-500"
                        placeholder="Digite sua senha"
                      />
                    )}
                    <button
                      disabled={running || executionDisabled}
                      title={executionDisabled ? AI_ADMIN_DISABLED_MESSAGE : undefined}
                      onClick={confirmAndExecute}
                      className="inline-flex items-center gap-2 rounded-xl bg-green-600 px-4 py-2 font-semibold hover:bg-green-700 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <LockKeyhole className="h-4 w-4" />{" "}
                      {running
                        ? "Executando..."
                        : requirePassword
                          ? "Confirmar com senha"
                          : "Confirmar sem senha"}
                    </button>
                  </div>
                </div>
              )}

              <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="flex items-center gap-2 text-lg font-bold">
                    <History className="h-5 w-5" /> Histórico
                  </h3>
                  <button
                    onClick={loadHistory}
                    disabled={executionDisabled}
                    title={executionDisabled ? AI_ADMIN_DISABLED_MESSAGE : undefined}
                    className="rounded-lg bg-white/10 px-3 py-1 text-sm hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    Atualizar
                  </button>
                </div>
                {history.length === 0 ? (
                  <p className="text-sm text-slate-400">Nenhuma ação carregada.</p>
                ) : (
                  <div className="space-y-2">
                    {history.map((h) => (
                      <div key={h.id} className="rounded-xl bg-black/20 p-3 text-sm">
                        <div className="flex items-center justify-between gap-3">
                          <b>{h.action_type}</b>
                          <span className="text-xs text-slate-400">
                            {new Date(h.created_at).toLocaleString("pt-BR")}
                          </span>
                        </div>
                        <p className="mt-1 text-slate-300">{h.action_summary}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {!executionDisabled && (
                <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-sm text-slate-300">
                  <h3 className="mb-2 flex items-center gap-2 font-bold text-white">
                    <RotateCcw className="h-4 w-4" /> Restauração
                  </h3>
                  Snapshots são salvos antes da execução. A restauração pode ser feita pelo
                  histórico técnico e pelas tabelas <b>ai_intelligence_snapshots</b> e{" "}
                  <b>ai_intelligence_rollbacks</b>.
                </div>
              )}
            </div>
          </aside>
        </div>
      )}
    </>
  );
}
