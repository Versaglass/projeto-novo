import { useState } from "react";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cancelSaleErrorMessage, useCancelSale } from "@/hooks/use-sales";

type CancelSaleDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  saleId: string;
  saleNumero: number;
  onSuccess?: () => void;
};

/**
 * Confirmação destrutiva com motivo obrigatório — espelha o contrato da RPC
 * `cancel_sale(p_sale_id, p_motivo)`.
 */
export function CancelSaleDialog({
  open,
  onOpenChange,
  saleId,
  saleNumero,
  onSuccess,
}: CancelSaleDialogProps) {
  const cancelSale = useCancelSale();
  const [motivo, setMotivo] = useState("");

  const fechar = () => {
    if (cancelSale.isPending) return;
    onOpenChange(false);
    setMotivo("");
  };

  const confirmar = async () => {
    const texto = motivo.trim();
    if (!texto) {
      toast.error("Informe o motivo do cancelamento.");
      return;
    }
    try {
      await cancelSale.mutateAsync({ saleId, motivo: texto });
      toast.success(`Venda nº ${saleNumero} cancelada. O estoque foi estornado.`);
      setMotivo("");
      onOpenChange(false);
      onSuccess?.();
    } catch (e) {
      console.error("[vendas] falha ao cancelar venda", e);
      toast.error(cancelSaleErrorMessage(e));
    }
  };

  return (
    <AlertDialog
      open={open}
      onOpenChange={(next) => {
        if (!next) fechar();
        else onOpenChange(true);
      }}
    >
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Cancelar venda #{saleNumero}?</AlertDialogTitle>
          <AlertDialogDescription>
            O estoque será creditado automaticamente com as quantidades baixadas no momento da
            venda. Esta ação não pode ser desfeita pela interface.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <div className="py-2">
          <label htmlFor="motivo-cancelamento" className="mb-1.5 block text-sm font-medium">
            Motivo do cancelamento <span className="text-destructive">*</span>
          </label>
          <textarea
            id="motivo-cancelamento"
            rows={3}
            value={motivo}
            onChange={(e) => setMotivo(e.target.value)}
            placeholder="Ex.: cliente desistiu, erro de lançamento..."
            className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none ring-offset-background focus-visible:ring-2 focus-visible:ring-ring"
            disabled={cancelSale.isPending}
          />
        </div>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={cancelSale.isPending} onClick={fechar}>
            Voltar
          </AlertDialogCancel>
          <button
            type="button"
            disabled={cancelSale.isPending || !motivo.trim()}
            onClick={() => void confirmar()}
            className="inline-flex items-center justify-center gap-2 rounded-md bg-destructive px-4 py-2 text-sm font-semibold text-destructive-foreground hover:bg-destructive/90 disabled:opacity-50"
          >
            {cancelSale.isPending ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> Cancelando...
              </>
            ) : (
              "Confirmar cancelamento"
            )}
          </button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
