import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

// Cache to avoid re-signing the same path repeatedly across renders
const cache = new Map<string, { url: string; exp: number }>();

type StorageBucket = "project-images" | "platform-catalog" | "manufacturer-catalog";

function extractPath(value: string, bucket: StorageBucket): string | null {
  if (!value) return null;
  if (!value.startsWith("http")) return value.replace(/^\/+/, "");
  const esc = bucket.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const pub = value.match(new RegExp(`/object/public/${esc}/(.+)$`));
  if (pub) return decodeURIComponent(pub[1]);
  const sig = value.match(new RegExp(`/object/sign/${esc}/([^?]+)`));
  if (sig) return decodeURIComponent(sig[1]);
  return null;
}

function useSignedImage(value: string | null | undefined, bucket: StorageBucket) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let cancelled = false;
    if (!value) {
      setUrl(null);
      return;
    }
    const path = extractPath(value, bucket);
    if (!path) {
      setUrl(value);
      return;
    }
    const cacheKey = `${bucket}:${path}`;
    const now = Date.now();
    const hit = cache.get(cacheKey);
    if (hit && hit.exp > now + 60_000) {
      setUrl(hit.url);
      return;
    }
    supabase.storage
      .from(bucket)
      .createSignedUrl(path, 60 * 60 * 24 * 7)
      .then(({ data }) => {
        if (cancelled) return;
        if (data?.signedUrl) {
          cache.set(cacheKey, { url: data.signedUrl, exp: now + 1000 * 60 * 60 * 24 * 6 });
          setUrl(data.signedUrl);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [value, bucket]);
  return url;
}

export function StorageImage({
  src,
  alt,
  className,
  /** Default: Biblioteca / Estoque. Use `platform-catalog` no catálogo global de projetos; `manufacturer-catalog` no catálogo de fabricantes. */
  bucket = "project-images",
}: {
  src?: string | null;
  alt?: string;
  className?: string;
  bucket?: StorageBucket;
}) {
  const url = useSignedImage(src, bucket);
  if (!url) {
    return null;
  }
  return (
    <img
      src={url}
      alt={alt}
      className={className}
      loading="lazy"
      decoding="async"
      referrerPolicy="no-referrer"
      onError={(e) => {
        e.currentTarget.style.display = "none";
      }}
    />
  );
}
