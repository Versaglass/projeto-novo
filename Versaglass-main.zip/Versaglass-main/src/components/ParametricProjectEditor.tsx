import { useEffect, useMemo, useRef, useState } from "react";
import {
  Box,
  Copy,
  Download,
  Grid3X3,
  Hammer,
  Layers,
  Lock,
  MousePointer2,
  Move,
  Package,
  Plus,
  RotateCw,
  Save,
  Scissors,
  Trash2,
  X,
  ZoomIn,
  ZoomOut,
  type LucideIcon,
} from "lucide-react";
import { toast } from "sonner";
import { brl } from "@/lib/format";
import { numeroParaTexto, textoParaNumero } from "@/lib/numero-campo";
import { useCompany } from "@/contexts/company-context";
import { useAuth } from "@/hooks/use-auth";
import { ROTULO_AREA, type AreaProjeto } from "@/lib/project-area";
import { normalizeProjectData, VERSAO_ATUAL, type ProjectData } from "@/types/project-data";

/**
 * Persistência injetável: o editor não escolhe a tabela.
 * Catálogo global → `platform_project_catalog.project_data`;
 * legado templates → `project_templates.project_data` (se ainda houver caller).
 */
export type PersistProjectDrawing = (args: {
  id: string;
  dados: ProjectData;
  areaTemplate: AreaProjeto;
}) => Promise<ProjectData>;

export type ProjectLike = {
  id: string;
  nome: string;
  /**
   * Área do MODELO (`platform_project_catalog.area` / `project_templates.area`),
   * não uma escolha do editor.
   * Sem `"todos"`: não existe desenho sem área, e o valor pseudo-área abria uma
   * paleta vazia. Sem `"serralheria_aco"`: o identificador agora é o do enum.
   */
  area: AreaProjeto;
  /** Só rótulo, para o cabeçalho. NUNCA é usada para deduzir área ou paleta. */
  categoria: string;
  descricao?: string;
  espessura?: string | null;
  largura_padrao: number;
  altura_padrao: number;
  preco_m2: number;
};

type PieceType =
  | "vidro"
  | "perfil"
  | "ferragem"
  | "recorte"
  | "furo"
  | "mdf"
  | "pedra"
  | "aco"
  | "texto";
type Piece = {
  id: string;
  tipo: PieceType;
  nome: string;
  x: number;
  y: number;
  largura: number;
  altura: number;
  qtd: number;
  material: string;
  cor: string;
  locked?: boolean;
  obs?: string;
};

type Mode = "2d" | "3d" | "explodido" | "plano";

/**
 * Ferramenta ativa da barra flutuante (Revisao 109).
 *
 * A barra ja tinha um botao "Selecionar" e um "Mover", os dois SEM `onClick` e
 * com o MESMO icone — dois botoes identicos, nenhum com funcao (Revisao 108).
 * Agora sao os dois estados de um alternador: "selecionar" e o repouso (clicar
 * escolhe a peca, que era o unico comportamento existente) e "mover" arma o
 * arrasto. "Corte" continua sem funcao e por isso NAO entrou aqui.
 */
type Tool = "selecionar" | "mover";

/**
 * Medida mínima de uma peça, em milímetros (Revisao 110).
 *
 * O `NumberEdit` do painel da direita não tem mínimo — digitar `0` grava `0`, e
 * o desenho só disfarça com `Math.max(10, …)` na hora de pintar. Não havia
 * validação para reaproveitar, então este piso é decisão declarada: 10 mm fica
 * abaixo da menor peça de catálogo (a lateral de MDF tem 18 mm) e vale cerca de
 * dois pixels de arrasto na escala desta tela. Vale só para a ALÇA; o campo
 * numérico continua exatamente como estava.
 */
const MIN_MM = 10;

/** As 4 alças de canto, na mesma ordem em que já eram desenhadas. */
const ALCAS: { ax: 0 | 1; ay: 0 | 1; cursor: string }[] = [
  { ax: 0, ay: 0, cursor: "nwse-resize" },
  { ax: 1, ay: 0, cursor: "nesw-resize" },
  { ax: 0, ay: 1, cursor: "nesw-resize" },
  { ax: 1, ay: 1, cursor: "nwse-resize" },
];

type ParamState = {
  nome: string;
  largura: number;
  altura: number;
  profundidade: number;
  material: string;
  acabamento: string;
  pecas: Piece[];
  versao: number;
};

// Uma entrada por valor de `public.project_area` — o `Record` obriga o
// compilador a cobrar a paleta nova quando uma área for acrescentada ao enum.
const PALETTE: Record<AreaProjeto, { label: string; items: Omit<Piece, "id">[] }> = {
  vidracaria: {
    label: "Vidraçaria",
    items: [
      {
        tipo: "vidro",
        nome: "Vidro",
        x: 80,
        y: 80,
        largura: 1100,
        altura: 2200,
        qtd: 1,
        material: "Vidro temperado 10mm",
        cor: "#cfe6e3",
      },
      {
        tipo: "perfil",
        nome: "Perfil U",
        x: 80,
        y: 80,
        largura: 40,
        altura: 2200,
        qtd: 1,
        material: "Alumínio",
        cor: "#1f2937",
      },
      {
        tipo: "ferragem",
        nome: "Dobradiça",
        x: 600,
        y: 260,
        largura: 55,
        altura: 110,
        qtd: 2,
        material: "Inox",
        cor: "#374151",
      },
      {
        tipo: "ferragem",
        nome: "Puxador",
        x: 640,
        y: 650,
        largura: 40,
        altura: 360,
        qtd: 1,
        material: "Inox",
        cor: "#334155",
      },
      {
        tipo: "recorte",
        nome: "Recorte",
        x: 180,
        y: 180,
        largura: 180,
        altura: 120,
        qtd: 1,
        material: "Recorte no vidro",
        cor: "#f97316",
      },
      {
        tipo: "furo",
        nome: "Furo",
        x: 260,
        y: 280,
        largura: 60,
        altura: 60,
        qtd: 1,
        material: "Furo",
        cor: "#16a34a",
      },
    ],
  },
  serralheria: {
    label: "Serralheria de aço",
    items: [
      {
        tipo: "aco",
        nome: "Metalon",
        x: 80,
        y: 80,
        largura: 1200,
        altura: 80,
        qtd: 1,
        material: "Metalon 30x30",
        cor: "#475569",
      },
      {
        tipo: "aco",
        nome: "Montante",
        x: 80,
        y: 80,
        largura: 80,
        altura: 1800,
        qtd: 1,
        material: "Tubo aço",
        cor: "#475569",
      },
      {
        tipo: "ferragem",
        nome: "Dobradiça reforçada",
        x: 70,
        y: 380,
        largura: 80,
        altura: 150,
        qtd: 2,
        material: "Aço",
        cor: "#111827",
      },
    ],
  },
  marcenaria: {
    label: "Marcenaria",
    items: [
      {
        tipo: "mdf",
        nome: "Lateral MDF",
        x: 80,
        y: 80,
        largura: 18,
        altura: 700,
        qtd: 2,
        material: "MDF 18mm",
        cor: "#b7791f",
      },
      {
        tipo: "mdf",
        nome: "Porta MDF",
        x: 120,
        y: 110,
        largura: 420,
        altura: 650,
        qtd: 2,
        material: "MDF 18mm",
        cor: "#d6a55d",
      },
      {
        tipo: "mdf",
        nome: "Prateleira",
        x: 120,
        y: 390,
        largura: 760,
        altura: 18,
        qtd: 2,
        material: "MDF 18mm",
        cor: "#c0843d",
      },
      {
        tipo: "mdf",
        nome: "Gaveta",
        x: 120,
        y: 560,
        largura: 360,
        altura: 140,
        qtd: 2,
        material: "MDF 15mm",
        cor: "#a16207",
      },
      {
        tipo: "ferragem",
        nome: "Puxador",
        x: 500,
        y: 380,
        largura: 24,
        altura: 180,
        qtd: 2,
        material: "Alumínio/Inox",
        cor: "#475569",
      },
      {
        tipo: "ferragem",
        nome: "Dobradiça caneco",
        x: 470,
        y: 220,
        largura: 60,
        altura: 60,
        qtd: 4,
        material: "Aço niquelado",
        cor: "#475569",
      },
    ],
  },
  marmoraria: {
    label: "Marmoraria",
    items: [
      {
        tipo: "pedra",
        nome: "Bancada",
        x: 80,
        y: 80,
        largura: 1600,
        altura: 600,
        qtd: 1,
        material: "Granito 20mm",
        cor: "#a8a29e",
      },
      {
        tipo: "pedra",
        nome: "Frontão",
        x: 80,
        y: 30,
        largura: 1600,
        altura: 120,
        qtd: 1,
        material: "Granito 20mm",
        cor: "#78716c",
      },
      {
        tipo: "pedra",
        nome: "Saia",
        x: 80,
        y: 680,
        largura: 1600,
        altura: 120,
        qtd: 1,
        material: "Granito 20mm",
        cor: "#78716c",
      },
      {
        tipo: "recorte",
        nome: "Recorte cuba",
        x: 520,
        y: 210,
        largura: 420,
        altura: 260,
        qtd: 1,
        material: "Recorte",
        cor: "#0ea5e9",
      },
      {
        tipo: "recorte",
        nome: "Recorte cooktop",
        x: 980,
        y: 220,
        largura: 520,
        altura: 320,
        qtd: 1,
        material: "Recorte",
        cor: "#f97316",
      },
      {
        tipo: "furo",
        nome: "Furo torneira",
        x: 470,
        y: 155,
        largura: 48,
        altura: 48,
        qtd: 1,
        material: "Furo",
        cor: "#16a34a",
      },
    ],
  },
  esquadrias: {
    label: "Esquadrias",
    items: [
      {
        tipo: "perfil",
        nome: "Montante alumínio",
        x: 80,
        y: 80,
        largura: 60,
        altura: 1800,
        qtd: 2,
        material: "Alumínio linha 25",
        cor: "#94a3b8",
      },
      {
        tipo: "perfil",
        nome: "Travessa",
        x: 80,
        y: 80,
        largura: 1200,
        altura: 60,
        qtd: 2,
        material: "Alumínio linha 25",
        cor: "#94a3b8",
      },
      {
        tipo: "vidro",
        nome: "Vidro da esquadria",
        x: 160,
        y: 160,
        largura: 1040,
        altura: 1600,
        qtd: 1,
        material: "Vidro temperado 8mm",
        cor: "#cfe6e3",
      },
      {
        tipo: "ferragem",
        nome: "Fechadura",
        x: 1080,
        y: 900,
        largura: 80,
        altura: 160,
        qtd: 1,
        material: "Inox",
        cor: "#334155",
      },
    ],
  },
};

function initialState(project: ProjectLike): ParamState {
  const width = Math.max(900, Math.round((project.largura_padrao || 4.4) * 1000));
  const height = Math.max(700, Math.round((project.altura_padrao || 2.2) * 1000));
  const uid = () => crypto.randomUUID();
  // A ÁREA decide, e só ela. Antes bastava a categoria conter "vidro" ou "box"
  // para o estado inicial virar um box de vidraçaria — um armário de marcenaria
  // com categoria "Esquadria / outros" e tipo "Box" nascia com quatro folhas de
  // vidro e perfil de alumínio. Casar substring em texto livre acerta por acaso.
  if (project.area === "vidracaria") {
    const panel = Math.round(width / 4);
    return {
      nome: project.nome,
      largura: width,
      altura: height,
      profundidade: 80,
      material: project.espessura || "Vidro temperado 10mm",
      acabamento: "Polido",
      versao: 1,
      pecas: [1, 2, 3, 4]
        .map((n) => ({
          id: uid(),
          tipo: "vidro" as PieceType,
          nome: `Vidro ${n}`,
          x: (n - 1) * panel,
          y: 0,
          largura: panel,
          altura: height,
          qtd: 1,
          material: project.espessura || "Vidro temperado 10mm",
          cor: "#cfe6e3",
        }))
        .concat([
          {
            id: uid(),
            tipo: "perfil",
            nome: "Perfil U Superior",
            x: 0,
            y: -45,
            largura: width,
            altura: 35,
            qtd: 1,
            material: "Alumínio",
            cor: "#111827",
          },
          {
            id: uid(),
            tipo: "perfil",
            nome: "Perfil U Inferior",
            x: 0,
            y: height + 10,
            largura: width,
            altura: 35,
            qtd: 1,
            material: "Alumínio",
            cor: "#111827",
          },
          {
            id: uid(),
            tipo: "ferragem",
            nome: "Puxador 1038A",
            x: panel * 2 - 55,
            y: height * 0.38,
            largura: 40,
            altura: 420,
            qtd: 2,
            material: "Inox",
            cor: "#334155",
          },
          {
            id: uid(),
            tipo: "furo",
            nome: "Furo 1125",
            x: panel + 15,
            y: 95,
            largura: 42,
            altura: 42,
            qtd: 4,
            material: "Furo",
            cor: "#16a34a",
          },
        ]),
    };
  }

  if (project.area === "marcenaria") {
    const depth = Math.max(350, Math.round(width * 0.18));
    const baseY = 40;
    const moduleW = Math.round(width / 3);
    const drawerH = Math.round(height * 0.18);
    return {
      nome: project.nome,
      largura: width,
      altura: height,
      profundidade: depth,
      material: project.espessura || "MDF 18mm",
      acabamento: "Fita de borda PVC",
      versao: 1,
      pecas: [
        {
          id: uid(),
          tipo: "mdf",
          nome: "Caixa externa MDF",
          x: 0,
          y: baseY,
          largura: width,
          altura: height,
          qtd: 1,
          material: "MDF 18mm",
          cor: "#b7791f",
          obs: "carcaca",
        },
        {
          id: uid(),
          tipo: "mdf",
          nome: "Lateral esquerda",
          x: 0,
          y: baseY,
          largura: 36,
          altura: height,
          qtd: 1,
          material: "MDF 18mm",
          cor: "#8a5a22",
        },
        {
          id: uid(),
          tipo: "mdf",
          nome: "Lateral direita",
          x: width - 36,
          y: baseY,
          largura: 36,
          altura: height,
          qtd: 1,
          material: "MDF 18mm",
          cor: "#8a5a22",
        },
        {
          id: uid(),
          tipo: "mdf",
          nome: "Prateleira superior",
          x: 0,
          y: baseY,
          largura: width,
          altura: 28,
          qtd: 1,
          material: "MDF 18mm",
          cor: "#c0843d",
        },
        {
          id: uid(),
          tipo: "mdf",
          nome: "Prateleira central",
          x: 36,
          y: baseY + Math.round(height * 0.46),
          largura: width - 72,
          altura: 24,
          qtd: 1,
          material: "MDF 18mm",
          cor: "#c0843d",
        },
        {
          id: uid(),
          tipo: "mdf",
          nome: "Divisória vertical",
          x: moduleW,
          y: baseY + 28,
          largura: 24,
          altura: height - 56,
          qtd: 2,
          material: "MDF 18mm",
          cor: "#a16207",
        },
        {
          id: uid(),
          tipo: "mdf",
          nome: "Porta esquerda",
          x: 48,
          y: baseY + 55,
          largura: moduleW - 70,
          altura: Math.round(height * 0.42),
          qtd: 1,
          material: "MDF 18mm",
          cor: "#d6a55d",
          obs: "porta",
        },
        {
          id: uid(),
          tipo: "mdf",
          nome: "Porta direita",
          x: width - moduleW + 34,
          y: baseY + 55,
          largura: moduleW - 70,
          altura: Math.round(height * 0.42),
          qtd: 1,
          material: "MDF 18mm",
          cor: "#d6a55d",
          obs: "porta",
        },
        {
          id: uid(),
          tipo: "mdf",
          nome: "Gaveta 01",
          x: moduleW + 45,
          y: baseY + Math.round(height * 0.58),
          largura: moduleW - 90,
          altura: drawerH,
          qtd: 1,
          material: "MDF 15mm",
          cor: "#9a641e",
          obs: "gaveta",
        },
        {
          id: uid(),
          tipo: "mdf",
          nome: "Gaveta 02",
          x: moduleW + 45,
          y: baseY + Math.round(height * 0.58) + drawerH + 18,
          largura: moduleW - 90,
          altura: drawerH,
          qtd: 1,
          material: "MDF 15mm",
          cor: "#9a641e",
          obs: "gaveta",
        },
        {
          id: uid(),
          tipo: "ferragem",
          nome: "Puxador porta",
          x: 48 + moduleW - 96,
          y: baseY + Math.round(height * 0.24),
          largura: 24,
          altura: 150,
          qtd: 2,
          material: "Alumínio/Inox",
          cor: "#334155",
        },
        {
          id: uid(),
          tipo: "ferragem",
          nome: "Puxador gaveta",
          x: moduleW + Math.round(moduleW * 0.43),
          y: baseY + Math.round(height * 0.65),
          largura: 180,
          altura: 22,
          qtd: 2,
          material: "Alumínio",
          cor: "#334155",
        },
      ],
    };
  }

  if (project.area === "marmoraria") {
    const depth = Math.max(500, Math.round(height));
    return {
      nome: project.nome,
      largura: width,
      altura: depth,
      profundidade: 40,
      material: project.espessura || "Granito São Gabriel 20mm",
      acabamento: "Meia esquadria / boleado",
      versao: 1,
      pecas: [
        {
          id: uid(),
          tipo: "pedra",
          nome: "Bancada principal",
          x: 0,
          y: 90,
          largura: width,
          altura: depth,
          qtd: 1,
          material: "Granito 20mm",
          cor: "#a8a29e",
          obs: "bancada",
        },
        {
          id: uid(),
          tipo: "pedra",
          nome: "Frontão",
          x: 0,
          y: 35,
          largura: width,
          altura: 90,
          qtd: 1,
          material: "Granito 20mm",
          cor: "#78716c",
          obs: "frontao",
        },
        {
          id: uid(),
          tipo: "pedra",
          nome: "Saia frontal",
          x: 0,
          y: 90 + depth + 18,
          largura: width,
          altura: 120,
          qtd: 1,
          material: "Granito 20mm",
          cor: "#78716c",
          obs: "saia",
        },
        {
          id: uid(),
          tipo: "recorte",
          nome: "Recorte da cuba",
          x: Math.round(width * 0.18),
          y: 90 + Math.round(depth * 0.28),
          largura: Math.round(width * 0.22),
          altura: Math.round(depth * 0.38),
          qtd: 1,
          material: "Cuba inox/porcelana",
          cor: "#0ea5e9",
        },
        {
          id: uid(),
          tipo: "recorte",
          nome: "Recorte cooktop",
          x: Math.round(width * 0.58),
          y: 90 + Math.round(depth * 0.28),
          largura: Math.round(width * 0.28),
          altura: Math.round(depth * 0.42),
          qtd: 1,
          material: "Cooktop",
          cor: "#f97316",
        },
        {
          id: uid(),
          tipo: "furo",
          nome: "Furo torneira",
          x: Math.round(width * 0.15),
          y: 90 + Math.round(depth * 0.16),
          largura: 52,
          altura: 52,
          qtd: 1,
          material: "Furo 35mm",
          cor: "#16a34a",
        },
      ],
    };
  }

  const sample = PALETTE[project.area]?.items?.[0] || PALETTE.vidracaria.items[0];
  return {
    nome: project.nome,
    largura: width,
    altura: height,
    profundidade: 450,
    material: project.espessura || sample.material,
    acabamento: "Padrão",
    versao: 1,
    pecas: [
      {
        ...sample,
        id: uid(),
        largura: Math.min(width, sample.largura),
        altura: Math.min(height, sample.altura),
      },
    ],
  };
}

/**
 * `project_data` (banco) → `ParamState` (editor).
 *
 * `versao` do estado é o CONTADOR DE EDIÇÕES do editor, não a versão do
 * formato: por isso vem de `revisao`, e não do `versao` persistido (que vale
 * sempre 1 e identifica o schema).
 */
function paramStateDeProjectData(dados: ProjectData): ParamState {
  return {
    nome: dados.nome,
    largura: dados.largura,
    altura: dados.altura,
    profundidade: dados.profundidade,
    material: dados.material,
    acabamento: dados.acabamento,
    versao: dados.revisao,
    pecas: dados.pecas.map((p) => ({ ...p, tipo: p.tipo as PieceType })),
  };
}

/** `ParamState` (editor) → `project_data` (banco). Caminho inverso do acima. */
function projectDataDeParamState(state: ParamState, area: AreaProjeto): ProjectData {
  return {
    versao: VERSAO_ATUAL,
    area,
    nome: state.nome,
    largura: state.largura,
    altura: state.altura,
    profundidade: state.profundidade,
    material: state.material,
    acabamento: state.acabamento,
    revisao: state.versao,
    pecas: state.pecas.map((p) => ({
      id: p.id,
      tipo: p.tipo,
      nome: p.nome,
      x: p.x,
      y: p.y,
      largura: p.largura,
      altura: p.altura,
      qtd: p.qtd,
      material: p.material,
      cor: p.cor,
      ...(p.locked !== undefined ? { locked: p.locked } : {}),
      ...(p.obs !== undefined ? { obs: p.obs } : {}),
    })),
  };
}

export function ParametricProjectEditor({
  project,
  dadosIniciais,
  onClose,
  onPersist,
  draftNamespace = "default",
}: {
  project: ProjectLike;
  /** Desenho já validado vindo do banco, ou `null` para começar do zero. */
  dadosIniciais: ProjectData | null;
  onClose: () => void;
  /** Grava `project_data` na fonte escolhida pelo caller (catálogo, etc.). */
  onPersist: PersistProjectDrawing;
  /** Isola rascunhos localStorage entre contextos (ex.: `platform-catalog`). */
  draftNamespace?: string;
}) {
  const { activeCompany } = useCompany();
  const { user } = useAuth();

  // ÚNICA fonte da área dentro do editor: a do modelo.
  //
  // Havia uma prop `area` separada de `project.area`, o que permitia abrir o
  // editor com a paleta de uma área e gravar `project_data.area` de outra. Com
  // um só valor não existe divergência a conciliar — e é o mesmo valor que o
  // salvamento reimpõe e que o banco confere.
  const area = project.area;

  // RASCUNHO local — nunca um salvamento definitivo.
  //
  // A chave inclui usuário, empresa/namespace e modelo: a anterior era só o id
  // do modelo, então dois usuários no mesmo navegador liam o rascunho um do
  // outro. O rascunho só é OFERECIDO (com botão de descartar), jamais aplicado
  // sozinho: um `project_data` salvo depois dele continua sendo o que abre.
  const storageKey = `vmm_rascunho_desenho:${draftNamespace}:${user?.id ?? "anon"}:${activeCompany?.companyId ?? "sem-empresa"}:${project.id}`;

  const [state, setState] = useState<ParamState>(() =>
    dadosIniciais ? paramStateDeProjectData(dadosIniciais) : initialState(project),
  );
  const [rascunho, setRascunho] = useState<ParamState | null>(null);

  // A leitura acontece UMA vez, antes de qualquer gravação de rascunho. Sem o
  // guarda, o rascunho que o próprio editor acabou de gravar seria lido de
  // volta e anunciado como "recuperável" — o aviso aparecia sozinho na abertura
  // de um modelo que nem desenho tinha.
  const leituraFeitaRef = useRef(false);
  useEffect(() => {
    if (typeof window === "undefined" || leituraFeitaRef.current) return;
    leituraFeitaRef.current = true;
    const bruto = localStorage.getItem(storageKey);
    if (!bruto) return;
    try {
      const candidato = normalizeProjectData(JSON.parse(bruto));
      if (!candidato) {
        localStorage.removeItem(storageKey);
        return;
      }
      // Rascunho igual ao que já está aberto não é rascunho — é o mesmo desenho.
      const atual = JSON.stringify(projectDataDeParamState(state, area));
      if (JSON.stringify(candidato) === atual) {
        localStorage.removeItem(storageKey);
        return;
      }
      // Rascunho mais ANTIGO que o desenho salvo é descartado sem perguntar:
      // já foi superado pelo que está no banco.
      if (dadosIniciais && candidato.revisao <= dadosIniciais.revisao) {
        localStorage.removeItem(storageKey);
        return;
      }
      setRascunho(paramStateDeProjectData(candidato));
    } catch {
      localStorage.removeItem(storageKey);
    }
    // `state`/`area` entram só como leitura da abertura; o guarda impede reexecução.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storageKey, dadosIniciais]);

  // Instantâneo do que já está no banco: começa no desenho carregado e é
  // atualizado a cada salvamento. Rascunho igual a ele não é trabalho pendente,
  // é cópia do que já está salvo — e por isso não é gravado.
  const ultimoSalvoRef = useRef<string | null>(
    dadosIniciais ? JSON.stringify(dadosIniciais) : null,
  );

  // Rascunho gravado a cada mudança — para não perder trabalho se a aba fechar.
  // O primeiro render é pulado: nada foi editado ainda, e gravar ali criaria um
  // "rascunho" idêntico ao estado recém-carregado.
  const primeiroRenderRef = useRef(true);
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (primeiroRenderRef.current) {
      primeiroRenderRef.current = false;
      return;
    }
    const serializado = JSON.stringify(projectDataDeParamState(state, area));
    if (serializado === ultimoSalvoRef.current) {
      // Nada divergindo do banco: o rascunho perdeu a razão de existir.
      localStorage.removeItem(storageKey);
      return;
    }
    try {
      localStorage.setItem(storageKey, serializado);
    } catch {
      // Cota cheia não pode impedir a edição; o salvamento real é no banco.
    }
  }, [state, area, storageKey]);

  const [mode, setMode] = useState<Mode>("2d");
  const [tool, setTool] = useState<Tool>("selecionar");
  const [selectedId, setSelectedId] = useState(state.pecas[0]?.id || "");
  const [zoom, setZoom] = useState(1);
  const [saving, setSaving] = useState(false);
  const selected = state.pecas.find((p) => p.id === selectedId) || state.pecas[0];
  const scale = Math.min(980 / Math.max(state.largura, 1), 430 / Math.max(state.altura, 1)) * zoom;
  const offsetX = 80;
  const offsetY = 80;

  const metrics = useMemo(() => {
    const area = state.pecas
      .filter((p) => ["vidro", "mdf", "pedra", "aco"].includes(p.tipo))
      .reduce((s, p) => s + (p.largura * p.altura * p.qtd) / 1_000_000, 0);
    const linear = state.pecas
      .filter((p) => ["perfil", "aco"].includes(p.tipo))
      .reduce((s, p) => s + ((p.largura + p.altura) * p.qtd) / 1000, 0);
    const ferragens = state.pecas
      .filter((p) => ["ferragem", "furo", "recorte"].includes(p.tipo))
      .reduce((s, p) => s + p.qtd, 0);
    const materiais = area * (project.preco_m2 || 650) + linear * 55 + ferragens * 38;
    return { area, linear, ferragens, materiais, total: materiais * 1.32 + 650 };
  }, [state.pecas, project.preco_m2]);

  const set = (patch: Partial<ParamState>) =>
    setState((s) => ({ ...s, ...patch, versao: s.versao + 1 }));
  const updatePiece = (id: string, patch: Partial<Piece>) =>
    setState((s) => ({
      ...s,
      versao: s.versao + 1,
      pecas: s.pecas.map((p) => (p.id === id ? { ...p, ...patch } : p)),
    }));
  /**
   * Escrita CRUA na peça, SEM mexer em `versao`. Existe para o arrasto: um
   * gesto dispara dezenas de `pointermove`, e `versao` não é contador de
   * quadros — é a `revisao` que vai para o banco e que o painel exibe. O
   * arrasto conta UMA revisão, ao soltar (`encerrarArrasto`).
   */
  const moverPeca = (id: string, patch: Partial<Piece>) =>
    setState((s) => ({
      ...s,
      pecas: s.pecas.map((p) => (p.id === id ? { ...p, ...patch } : p)),
    }));
  const encerrarArrasto = () => setState((s) => ({ ...s, versao: s.versao + 1 }));
  const addPiece = (piece: Omit<Piece, "id">) => {
    const p = {
      ...piece,
      id: crypto.randomUUID(),
      x: Math.max(0, piece.x + state.pecas.length * 12),
      y: Math.max(0, piece.y + state.pecas.length * 10),
    };
    setState((s) => ({ ...s, versao: s.versao + 1, pecas: [...s.pecas, p] }));
    setSelectedId(p.id);
  };
  const duplicate = () =>
    selected &&
    addPiece({
      ...selected,
      nome: `${selected.nome} cópia`,
      x: selected.x + 60,
      y: selected.y + 60,
    });
  const remove = () => {
    if (!selected || selected.locked) return;
    setState((s) => ({
      ...s,
      versao: s.versao + 1,
      pecas: s.pecas.filter((p) => p.id !== selected.id),
    }));
    setSelectedId(state.pecas.find((p) => p.id !== selected.id)?.id || "");
  };
  /**
   * "Salvar desenho" — persiste via `onPersist` (caller escolhe a tabela).
   *
   * Substitui as duas ações antigas: o "Salvar" que só escrevia no localStorage
   * (a geometria sumia em outro navegador) e o "Salvar como novo", que criava
   * um modelo a cada clique e enfiava o JSON em `observacoes`.
   */
  const salvarDesenho = () => {
    if (saving) return;
    setSaving(true);
    void onPersist({
      id: project.id,
      dados: projectDataDeParamState(state, area),
      areaTemplate: area,
    })
      .then((salvo) => {
        // Rascunho cumpriu o papel: o banco agora é a fonte oficial. Registrar
        // o instantâneo evita que o efeito de rascunho o regrave em seguida.
        ultimoSalvoRef.current = JSON.stringify(salvo);
        if (typeof window !== "undefined") localStorage.removeItem(storageKey);
        setRascunho(null);
        toast.success("Desenho salvo");
      })
      .catch((e: unknown) =>
        toast.error(e instanceof Error ? e.message : "Não foi possível salvar o desenho."),
      )
      .finally(() => setSaving(false));
  };

  const aplicarRascunho = () => {
    if (!rascunho) return;
    setState(rascunho);
    setSelectedId(rascunho.pecas[0]?.id ?? "");
    setRascunho(null);
  };
  const descartarRascunho = () => {
    if (typeof window !== "undefined") localStorage.removeItem(storageKey);
    setRascunho(null);
  };
  // ARRASTO (Revisao 109). O `<svg>` tem `width="100%"` e `viewBox` fixo, então
  // pixel de tela não vale unidade de desenho: a conversão vem do próprio
  // navegador (`getScreenCTM`), e do viewBox para milímetros divide-se por
  // `scale` — que aqui já inclui o zoom, então arrastar acerta em qualquer zoom.
  const svgRef = useRef<SVGSVGElement | null>(null);
  const arrasto = useRef<{
    id: string;
    x0: number;
    y0: number;
    pX: number;
    pY: number;
    moveu: boolean;
  } | null>(null);

  const pontoNoDesenho = (e: React.PointerEvent) => {
    const ctm = svgRef.current?.getScreenCTM();
    if (!ctm) return null;
    return new DOMPoint(e.clientX, e.clientY).matrixTransform(ctm.inverse());
  };

  const aoPressionarPeca = (peca: Piece) => (e: React.PointerEvent) => {
    if (tool !== "mover" || peca.locked) return;
    const ponto = pontoNoDesenho(e);
    if (!ponto) return;
    setSelectedId(peca.id);
    arrasto.current = {
      id: peca.id,
      x0: ponto.x,
      y0: ponto.y,
      pX: peca.x,
      pY: peca.y,
      moveu: false,
    };
    // Sem `setPointerCapture` o gesto morre quando o ponteiro sai de cima da
    // peça — que é o que acontece em qualquer arrasto um pouco mais rápido.
    (e.currentTarget as Element).setPointerCapture(e.pointerId);
    e.preventDefault();
  };

  const aoArrastarPeca = (e: React.PointerEvent) => {
    const a = arrasto.current;
    if (!a) return;
    const ponto = pontoNoDesenho(e);
    if (!ponto) return;
    const nx = Math.round(a.pX + (ponto.x - a.x0) / scale);
    const ny = Math.round(a.pY + (ponto.y - a.y0) / scale);
    if (nx === a.pX && ny === a.pY && !a.moveu) return;
    a.moveu = true;
    moverPeca(a.id, { x: nx, y: ny });
  };

  const aoSoltarPeca = (e: React.PointerEvent) => {
    const a = arrasto.current;
    arrasto.current = null;
    const alvo = e.currentTarget as Element;
    if (alvo.hasPointerCapture?.(e.pointerId)) alvo.releasePointerCapture(e.pointerId);
    if (a?.moveu) encerrarArrasto();
  };

  // REDIMENSIONAR (Revisao 110). Mesmo mecanismo do arrasto de mover — a
  // conversão sai de `getScreenCTM` e o delta em unidades do viewBox vira
  // milímetro dividindo por `scale`, que já traz o zoom dentro. O que muda é a
  // regra: o delta vai para a MEDIDA, e a borda oposta à alça fica parada.
  const redim = useRef<{
    id: string;
    ax: number;
    ay: number;
    vx0: number;
    vy0: number;
    x0: number;
    y0: number;
    w0: number;
    h0: number;
    mudou: boolean;
  } | null>(null);

  const aoPegarAlca = (peca: Piece, ax: number, ay: number) => (e: React.PointerEvent) => {
    if (peca.locked) return;
    // A alça vive dentro do `<g>` da peça, que tem o arrasto de mover: sem parar
    // a propagação, pegar um canto arrastaria a peça em vez de esticá-la.
    e.stopPropagation();
    const ponto = pontoNoDesenho(e);
    if (!ponto) return;
    setSelectedId(peca.id);
    redim.current = {
      id: peca.id,
      ax,
      ay,
      vx0: ponto.x,
      vy0: ponto.y,
      x0: peca.x,
      y0: peca.y,
      w0: peca.largura,
      h0: peca.altura,
      mudou: false,
    };
    (e.currentTarget as Element).setPointerCapture(e.pointerId);
    e.preventDefault();
  };

  const aoArrastarAlca = (e: React.PointerEvent) => {
    const r = redim.current;
    if (!r) return;
    e.stopPropagation();
    const ponto = pontoNoDesenho(e);
    if (!ponto) return;
    const dx = Math.round((ponto.x - r.vx0) / scale);
    const dy = Math.round((ponto.y - r.vy0) / scale);
    if (!r.mudou && dx === 0 && dy === 0) return;
    // Sempre a partir do instante em que a alça foi pega, nunca do estado
    // corrente — senão a borda "parada" andaria junto.
    const patch: Partial<Piece> = {};
    if (r.ax === 0) {
      const direita = r.x0 + r.w0;
      const nx = Math.min(r.x0 + dx, direita - MIN_MM);
      patch.x = nx;
      patch.largura = direita - nx;
    } else if (r.ax === 1) {
      patch.largura = Math.max(MIN_MM, r.w0 + dx);
    }
    if (r.ay === 0) {
      const baixo = r.y0 + r.h0;
      const ny = Math.min(r.y0 + dy, baixo - MIN_MM);
      patch.y = ny;
      patch.altura = baixo - ny;
    } else if (r.ay === 1) {
      patch.altura = Math.max(MIN_MM, r.h0 + dy);
    }
    r.mudou = true;
    moverPeca(r.id, patch);
  };

  const aoSoltarAlca = (e: React.PointerEvent) => {
    const r = redim.current;
    redim.current = null;
    e.stopPropagation();
    const alvo = e.currentTarget as Element;
    if (alvo.hasPointerCapture?.(e.pointerId)) alvo.releasePointerCapture(e.pointerId);
    if (r?.mudou) encerrarArrasto();
  };

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${state.nome.replace(/\s+/g, "-").toLowerCase()}-editavel.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  // Sem fallback para vidraçaria: `PALETTE` é um `Record` completo sobre as
  // quatro áreas, então não existe área sem paleta. O fallback antigo existia
  // por causa de `"todos"`, que não é área e não existe mais.
  const palette = PALETTE[area].items;
  const is3d = mode === "3d" || mode === "explodido";

  return (
    <div className="fixed inset-0 z-50 bg-[#07111f] text-white" onClick={onClose}>
      <div className="flex h-full flex-col" onClick={(e) => e.stopPropagation()}>
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-[#081321] px-4 py-3">
          {/* Deixa explícito QUAL modelo está sendo editado — o editor grava na
              linha real do banco, então a identificação não pode ser vaga. */}
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="rounded-lg border border-white/10 px-3 py-2 text-sm hover:bg-white/10"
            >
              Voltar
            </button>
            <div>
              <div className="text-sm text-white/60">
                Catálogo › Editar desenho · {ROTULO_AREA[area]}
              </div>
              <h2 className="font-display text-lg font-bold">{project.nome}</h2>
            </div>
          </div>
          {/* "Salvar como novo" foi RETIRADO: criava um modelo a cada clique e
              gravava JSON em `observacoes`. Duplicar modelo será uma ação
              explícita da biblioteca, em etapa própria. "Duplicar"/"Excluir"
              abaixo agem sobre a PEÇA selecionada, não sobre o modelo. */}
          <div className="flex flex-wrap gap-2">
            <Action
              onClick={salvarDesenho}
              icon={Save}
              label={saving ? "Salvando..." : "Salvar desenho"}
              green
            />
            <Action onClick={duplicate} icon={Copy} label="Duplicar peça" />
            <Action onClick={remove} icon={Trash2} label="Excluir peça" red />
            <Action onClick={exportJson} icon={Download} label="Exportar" />
          </div>
        </header>

        {rascunho && (
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-amber-400/30 bg-amber-400/10 px-4 py-2 text-sm text-amber-100">
            <span>
              Há um <b>rascunho local</b> deste desenho, mais recente que o salvo e ainda não
              gravado no modelo.
            </span>
            <span className="flex gap-2">
              <button
                onClick={aplicarRascunho}
                className="rounded-lg border border-amber-300/40 px-3 py-1.5 text-xs font-semibold hover:bg-amber-400/20"
              >
                Recuperar rascunho
              </button>
              <button
                onClick={descartarRascunho}
                className="rounded-lg border border-white/15 px-3 py-1.5 text-xs hover:bg-white/10"
              >
                Descartar
              </button>
            </span>
          </div>
        )}

        <main className="grid min-h-0 flex-1 grid-cols-[280px_minmax(520px,1fr)_320px] gap-3 p-3 max-xl:grid-cols-[240px_minmax(420px,1fr)] max-lg:grid-cols-1 max-lg:overflow-auto">
          <aside className="space-y-3 overflow-y-auto rounded-xl border border-white/10 bg-[#0b1727] p-3">
            <div className="text-xs font-bold uppercase tracking-wider text-cyan-300">
              Componentes
            </div>
            <div className="grid grid-cols-2 gap-2">
              {palette.map((p) => (
                <button
                  key={`${p.tipo}-${p.nome}`}
                  onClick={() => addPiece(p)}
                  className="rounded-lg border border-white/10 bg-white/5 p-3 text-left text-xs hover:border-cyan-400/60 hover:bg-cyan-400/10"
                >
                  <Package className="mb-2 h-4 w-4 text-cyan-300" />
                  {p.nome}
                </button>
              ))}
            </div>
            <div className="rounded-xl border border-white/10 bg-black/20 p-3">
              <div className="mb-2 flex items-center gap-2 text-sm font-semibold">
                <Layers className="h-4 w-4 text-emerald-300" /> Camadas
              </div>
              <div className="space-y-1">
                {state.pecas.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setSelectedId(p.id)}
                    className={`flex w-full items-center justify-between rounded-md px-2 py-1.5 text-xs ${selected?.id === p.id ? "bg-emerald-500/25 text-emerald-100" : "hover:bg-white/10"}`}
                  >
                    <span>{p.nome}</span>
                    <span className="text-white/40">{p.tipo}</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="rounded-xl border border-white/10 bg-black/20 p-3 text-xs text-white/70">
              <b className="text-white">Visão durante a alteração:</b> selecione uma peça, edite
              medidas no painel direito e veja o desenho, cotas, materiais e total atualizarem na
              hora.
            </div>
          </aside>

          <section className="min-w-0 space-y-3 overflow-y-auto">
            <div className="rounded-xl border border-white/10 bg-[#0b1727] p-2">
              <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                <div className="flex gap-1">
                  {(["2d", "3d", "explodido", "plano"] as Mode[]).map((m) => (
                    <button
                      key={m}
                      onClick={() => setMode(m)}
                      className={`rounded-lg px-3 py-2 text-xs font-semibold uppercase ${mode === m ? "bg-blue-600 text-white" : "bg-white/5 text-white/70 hover:bg-white/10"}`}
                    >
                      {m === "plano" ? "Plano de corte" : m === "3d" ? "Perspectiva" : m}
                    </button>
                  ))}
                </div>
                <div className="flex items-center gap-1">
                  <IconBtn onClick={() => setZoom((z) => Math.max(0.6, z - 0.1))} icon={ZoomOut} />
                  <span className="rounded bg-white/5 px-3 py-2 text-xs">
                    {Math.round(zoom * 100)}%
                  </span>
                  <IconBtn onClick={() => setZoom((z) => Math.min(1.6, z + 0.1))} icon={ZoomIn} />
                  <IconBtn
                    onClick={() => set({ pecas: initialState(project).pecas })}
                    icon={RotateCw}
                  />
                </div>
              </div>
              <div className="relative overflow-auto rounded-lg bg-[#f8fafc] p-4 text-slate-950">
                <svg
                  ref={svgRef}
                  width="100%"
                  height="520"
                  viewBox="0 0 1120 520"
                  className="min-w-[760px] rounded bg-white shadow-inner"
                  style={{
                    backgroundImage:
                      "linear-gradient(#eef2f7 1px, transparent 1px), linear-gradient(90deg,#eef2f7 1px, transparent 1px)",
                    backgroundSize: "24px 24px",
                  }}
                >
                  <defs>
                    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
                      <feDropShadow dx="0" dy="8" stdDeviation="6" floodOpacity="0.22" />
                    </filter>
                    <pattern id="wood-grain" width="80" height="36" patternUnits="userSpaceOnUse">
                      <rect width="80" height="36" fill="#c98a3a" />
                      <path
                        d="M0 9 C18 4 32 16 52 10 S72 6 80 13 M0 24 C22 18 38 30 62 24 S76 20 80 26"
                        fill="none"
                        stroke="#7c4a15"
                        strokeWidth="2"
                        opacity=".45"
                      />
                      <circle cx="22" cy="18" r="5" fill="none" stroke="#7c4a15" opacity=".35" />
                    </pattern>
                    <pattern
                      id="stone-speckle"
                      width="70"
                      height="70"
                      patternUnits="userSpaceOnUse"
                    >
                      <rect width="70" height="70" fill="#a8a29e" />
                      <circle cx="12" cy="14" r="2" fill="#57534e" opacity=".5" />
                      <circle cx="44" cy="20" r="1.6" fill="#f5f5f4" opacity=".7" />
                      <circle cx="30" cy="48" r="2.3" fill="#44403c" opacity=".45" />
                      <path
                        d="M4 58 C22 42 38 72 66 50"
                        stroke="#e7e5e4"
                        strokeWidth="2"
                        opacity=".35"
                        fill="none"
                      />
                    </pattern>
                  </defs>
                  <Dimension
                    x1={offsetX}
                    y1={35}
                    x2={offsetX + state.largura * scale}
                    y2={35}
                    label={`${state.largura}`}
                  />
                  <Dimension
                    x1={35}
                    y1={offsetY}
                    x2={35}
                    y2={offsetY + state.altura * scale}
                    label={`${state.altura}`}
                    vertical
                  />
                  {state.pecas.map((p, idx) => (
                    <PieceSvg
                      key={p.id}
                      p={p}
                      idx={idx}
                      selected={selected?.id === p.id}
                      scale={scale}
                      ox={offsetX}
                      oy={offsetY}
                      mode={mode}
                      tool={tool}
                      onSelect={() => setSelectedId(p.id)}
                      onPointerDown={aoPressionarPeca(p)}
                      onPointerMove={aoArrastarPeca}
                      onPointerUp={aoSoltarPeca}
                    />
                  ))}
                  {/* Os números dos vidros são desenhados FORA do `<g>` da peça,
                      por cima de tudo. Sem `pointer-events: none` eles engolem o
                      ponteiro justamente no CENTRO de cada vidro — que é onde se
                      clica para selecionar e onde se pega para arrastar. Era um
                      defeito silencioso desde sempre: clicar no meio de um vidro
                      não selecionava. Rótulo não é alvo de clique. */}
                  {state.pecas
                    .filter((p) => p.tipo === "vidro")
                    .map((p, idx) => (
                      <text
                        key={`num-${p.id}`}
                        x={offsetX + (p.x + p.largura / 2) * scale}
                        y={offsetY + (p.y + p.altura / 2) * scale}
                        textAnchor="middle"
                        fontSize="22"
                        fontWeight="700"
                        pointerEvents="none"
                      >
                        {idx + 1}
                      </text>
                    ))}
                  {/* CAMADA DAS ALÇAS (Revisao 110) — depois de todas as peças,
                      e não dentro do `<g>` de uma delas.
                      Motivo medido: dentro do grupo, qualquer peça desenhada
                      adiante pinta por cima. No editor do menu, com o Vidro 2
                      selecionado, as três alças da borda direita caíam embaixo
                      do Vidro 3 e não pegavam — `elementFromPoint` devolvia o
                      vizinho. Aqui as quatro ficam por cima de tudo.
                      Furo e recorte continuam SEM alça, como sempre estiveram:
                      o desenho deles nunca teve canto para pegar, e inventar um
                      agora seria mudança visual que ninguém pediu. */}
                  {(() => {
                    const idx = state.pecas.findIndex((p) => p.id === selected?.id);
                    const pc = state.pecas[idx];
                    if (!pc || pc.tipo === "furo" || pc.tipo === "recorte") return null;
                    const x = offsetX + pc.x * scale + (mode === "explodido" ? idx * 14 : 0);
                    const y = offsetY + pc.y * scale + (mode === "explodido" ? idx * 8 : 0);
                    const w = Math.max(10, pc.largura * scale);
                    const h = Math.max(10, pc.altura * scale);
                    return ALCAS.map(({ ax, ay, cursor }) => {
                      const cx = x + w * ax;
                      const cy = y + h * ay;
                      return (
                        <g key={`alca-${ax}-${ay}`}>
                          {/* Alvo invisível, maior que a alça: a alça pintada tem
                              10 unidades de viewBox, cerca de 8 px na tela —
                              pequeno demais para pegar com o mouse. O azul sai do
                              caminho do ponteiro para os dois não disputarem o
                              mesmo clique. */}
                          <rect
                            x={cx - 10}
                            y={cy - 10}
                            width="20"
                            height="20"
                            fill="none"
                            pointerEvents="all"
                            style={{ cursor, touchAction: "none" }}
                            onPointerDown={aoPegarAlca(pc, ax, ay)}
                            onPointerMove={aoArrastarAlca}
                            onPointerUp={aoSoltarAlca}
                            onPointerCancel={aoSoltarAlca}
                          />
                          <rect
                            x={cx - 5}
                            y={cy - 5}
                            width="10"
                            height="10"
                            fill="#2563eb"
                            pointerEvents="none"
                          />
                        </g>
                      );
                    });
                  })()}
                </svg>
                {/* Revisao 109 — "Selecionar" e "Mover" viraram os dois estados
                    de um alternador, e ganharam icones DIFERENTES: os dois
                    usavam `Move`, o que fazia dois botoes identicos lado a lado.
                    O destaque do ativo usa `bg-blue-600 text-white`, o mesmo das
                    abas de modo logo acima — nenhuma cor nova. */}
                <div className="absolute bottom-6 left-8 flex flex-wrap gap-1 rounded-lg bg-[#0b1727] p-2 text-xs text-white shadow-lg">
                  <Tool
                    label="Selecionar"
                    icon={MousePointer2}
                    ativo={tool === "selecionar"}
                    title="Clicar escolhe a peça"
                    onClick={() => setTool("selecionar")}
                  />
                  <Tool
                    label="Mover"
                    icon={Move}
                    ativo={tool === "mover"}
                    title={
                      tool === "mover"
                        ? "Modo mover ativo — arraste uma peça no desenho para reposicioná-la"
                        : "Ativar o modo mover"
                    }
                    onClick={() => setTool((t) => (t === "mover" ? "selecionar" : "mover"))}
                  />
                  <Tool label="Copiar" icon={Copy} onClick={duplicate} />
                  <Tool label="Corte" icon={Scissors} />
                  <Tool label="Excluir" icon={Trash2} onClick={remove} />
                </div>
              </div>
            </div>

            <div className="grid gap-3 xl:grid-cols-4 md:grid-cols-2">
              <Panel title="Perspectiva">
                <Mini3D pieces={state.pecas} is3d={is3d} />
              </Panel>
              <Panel title="Plano de corte">
                <CutPlan pieces={state.pecas} />
              </Panel>
              <Panel title="Lista de materiais">
                <Materials pieces={state.pecas} />
              </Panel>
              <Panel title="Resumo">
                <Summary metrics={metrics} />
              </Panel>
            </div>
          </section>

          <aside className="space-y-3 overflow-y-auto rounded-xl border border-white/10 bg-[#0b1727] p-4 max-xl:col-span-2 max-lg:col-span-1">
            <div className="flex items-center justify-between">
              <div className="text-xs font-bold uppercase tracking-wider text-cyan-300">
                Propriedades
              </div>
              <Box className="h-4 w-4 text-white/50" />
            </div>
            <div className="rounded-xl border border-white/10 bg-black/20 p-3">
              <div className="mb-2 text-sm font-semibold">Medidas gerais do projeto</div>
              <div className="grid grid-cols-2 gap-2">
                <NumberEdit
                  label="Largura total"
                  value={state.largura}
                  onChange={(v) => set({ largura: v })}
                />
                <NumberEdit
                  label={project.area === "marmoraria" ? "Profundidade/avanço" : "Altura total"}
                  value={state.altura}
                  onChange={(v) => set({ altura: v })}
                />
              </div>
              <div className="mt-2">
                <NumberEdit
                  label="Profundidade"
                  value={state.profundidade}
                  onChange={(v) => set({ profundidade: v })}
                />
              </div>
              <div className="mt-2">
                <TextEdit
                  label="Acabamento geral"
                  value={state.acabamento}
                  onChange={(v) => set({ acabamento: v })}
                />
              </div>
            </div>
            {selected ? (
              <div className="space-y-3">
                <TextEdit
                  label="Nome"
                  value={selected.nome}
                  onChange={(v) => updatePiece(selected.id, { nome: v })}
                />
                <NumberEdit
                  label="Largura"
                  value={selected.largura}
                  onChange={(v) => updatePiece(selected.id, { largura: v })}
                />
                <NumberEdit
                  label="Altura"
                  value={selected.altura}
                  onChange={(v) => updatePiece(selected.id, { altura: v })}
                />
                <NumberEdit
                  label="X"
                  value={selected.x}
                  onChange={(v) => updatePiece(selected.id, { x: v })}
                />
                <NumberEdit
                  label="Y"
                  value={selected.y}
                  onChange={(v) => updatePiece(selected.id, { y: v })}
                />
                <NumberEdit
                  label="Qtd"
                  value={selected.qtd}
                  onChange={(v) => updatePiece(selected.id, { qtd: v })}
                />
                <TextEdit
                  label="Material"
                  value={selected.material}
                  onChange={(v) => updatePiece(selected.id, { material: v })}
                />
                <TextEdit
                  label="Cor HEX"
                  value={selected.cor}
                  onChange={(v) => updatePiece(selected.id, { cor: v })}
                />
                {/* O botão "Aplicar alterações" saiu aqui (Revisao 113).
                    Ele só disparava um toast dizendo que as alterações eram em
                    tempo real — o que já eram. Conferido linha a linha na
                    Revisao 112: não validava, não normalizava, não gravava
                    rascunho, não incrementava `versao` e não era `submit` (não
                    existe <form> neste arquivo). O único efeito era tirar o foco
                    do campo, que qualquer clique fora já faz.
                    Não entra substituto: o painel esquerdo já avisa que o
                    desenho atualiza na hora, e quem grava é "Salvar desenho",
                    no cabeçalho. */}
              </div>
            ) : (
              <p className="text-sm text-white/60">Selecione uma peça para editar.</p>
            )}
            {/* Revisao 116 — o bloco deixou de fingir histórico.
                Antes: `[0,1,2,3].map` com 4 linhas "Alteração no projeto" e
                "Versão {versao−n}" (Rev. 108/115). Não havia snapshot nenhum.
                Agora: só a revisão atual (`state.versao` = `project_data.revisao`
                ao gravar) e um aviso claro de que versões anteriores não existem. */}
            <div className="rounded-xl border border-white/10 bg-black/20 p-3">
              <div className="mb-1 text-sm font-semibold">Revisão do desenho</div>
              <p className="text-xs">
                <b>Revisão atual: {state.versao}</b>
              </p>
              <p className="mt-1 text-xs text-white/50">
                Histórico de versões anteriores ainda não está disponível.
              </p>
            </div>
          </aside>
        </main>
      </div>
    </div>
  );
}

function PieceSvg({
  p,
  idx,
  selected,
  scale,
  ox,
  oy,
  mode,
  tool,
  onSelect,
  onPointerDown,
  onPointerMove,
  onPointerUp,
}: {
  p: Piece;
  idx: number;
  selected: boolean;
  scale: number;
  ox: number;
  oy: number;
  mode: Mode;
  tool: Tool;
  onSelect: () => void;
  onPointerDown: (e: React.PointerEvent) => void;
  onPointerMove: (e: React.PointerEvent) => void;
  onPointerUp: (e: React.PointerEvent) => void;
}) {
  const x = ox + p.x * scale + (mode === "explodido" ? idx * 14 : 0);
  const y = oy + p.y * scale + (mode === "explodido" ? idx * 8 : 0);
  const w = Math.max(10, p.largura * scale);
  const h = Math.max(10, p.altura * scale);
  const depth =
    mode === "3d" || mode === "explodido" ? Math.max(10, Math.min(42, 22 + idx * 2)) : 0;
  // Os TRÊS ramos de desenho (furo, recorte e o resto) recebem o mesmo conjunto
  // de handlers: um furo é tão arrastável quanto um vidro.
  const arrastavel = tool === "mover" && !p.locked;
  const gesto = {
    onClick: onSelect,
    onPointerDown,
    onPointerMove,
    onPointerUp,
    onPointerCancel: onPointerUp,
    className: arrastavel ? "cursor-move" : "cursor-pointer",
    style: arrastavel ? { touchAction: "none" as const } : undefined,
  };
  if (p.tipo === "furo")
    return (
      <g {...gesto}>
        <circle
          cx={x + w / 2}
          cy={y + h / 2}
          r={Math.max(4, w / 2)}
          fill="#f8fafc"
          stroke="#16a34a"
          strokeWidth="3"
        />
        <line
          x1={x + w / 2 - 9}
          y1={y + h / 2}
          x2={x + w / 2 + 9}
          y2={y + h / 2}
          stroke="#16a34a"
        />
        <line
          x1={x + w / 2}
          y1={y + h / 2 - 9}
          x2={x + w / 2}
          y2={y + h / 2 + 9}
          stroke="#16a34a"
        />
        <text x={x + w + 4} y={y + h / 2} fontSize="10" fill="#166534">
          {p.nome}
        </text>
      </g>
    );
  if (p.tipo === "recorte")
    return (
      <g {...gesto}>
        <rect
          x={x}
          y={y}
          width={w}
          height={h}
          rx="12"
          fill="rgba(255,255,255,.72)"
          stroke={p.cor}
          strokeWidth="3"
          strokeDasharray="8 5"
        />
        <text x={x + 4} y={y - 5} fontSize="10" fill={p.cor}>
          {p.nome}
        </text>
        <text
          x={x + w / 2}
          y={y + h / 2}
          textAnchor="middle"
          fontSize="11"
          fontWeight="700"
          fill={p.cor}
        >
          {Math.round(p.largura)} x {Math.round(p.altura)}
        </text>
      </g>
    );
  const fill =
    p.tipo === "mdf" ? "url(#wood-grain)" : p.tipo === "pedra" ? "url(#stone-speckle)" : p.cor;
  const opacity = p.tipo === "vidro" ? 0.68 : 0.96;
  const stroke = selected
    ? "#2563eb"
    : p.tipo === "pedra"
      ? "#57534e"
      : p.tipo === "mdf"
        ? "#7c4a15"
        : "#111827";
  return (
    <g {...gesto} filter={["vidro", "mdf", "pedra"].includes(p.tipo) ? "url(#shadow)" : undefined}>
      {depth > 0 && (
        <polygon
          points={`${x + w},${y} ${x + w + depth},${y - depth} ${x + w + depth},${y + h - depth} ${x + w},${y + h}`}
          fill={p.tipo === "pedra" ? "#78716c" : p.tipo === "mdf" ? "#8a5a22" : "#64748b"}
          opacity=".55"
          stroke="#0f172a"
          strokeWidth="1"
        />
      )}
      {depth > 0 && (
        <polygon
          points={`${x},${y} ${x + depth},${y - depth} ${x + w + depth},${y - depth} ${x + w},${y}`}
          fill={p.tipo === "pedra" ? "#d6d3d1" : p.tipo === "mdf" ? "#d6a55d" : "#94a3b8"}
          opacity=".6"
          stroke="#0f172a"
          strokeWidth="1"
        />
      )}
      <rect
        x={x}
        y={y}
        width={w}
        height={h}
        rx={p.tipo === "vidro" ? 1 : 5}
        fill={fill}
        opacity={opacity}
        stroke={stroke}
        strokeWidth={selected ? 3 : 1.4}
      />
      {p.tipo === "mdf" && p.obs === "gaveta" && (
        <line
          x1={x + 8}
          y1={y + h / 2}
          x2={x + w - 8}
          y2={y + h / 2}
          stroke="#7c4a15"
          strokeWidth="2"
          opacity=".45"
        />
      )}
      {p.tipo === "mdf" && p.obs === "porta" && (
        <rect
          x={x + 10}
          y={y + 10}
          width={Math.max(4, w - 20)}
          height={Math.max(4, h - 20)}
          rx="4"
          fill="none"
          stroke="#7c4a15"
          strokeWidth="2"
          opacity=".35"
        />
      )}
      {/* As 4 alças de canto saíram daqui na Revisao 110 e viraram uma camada
          própria no fim do SVG — ver o comentário lá. Dentro deste `<g>` elas
          ficavam embaixo de qualquer peça desenhada adiante. */}
      <text
        x={x + w / 2}
        y={y + h / 2}
        textAnchor="middle"
        fontSize="13"
        fontWeight="700"
        fill={
          p.tipo === "vidro"
            ? "#0f172a"
            : p.tipo === "mdf"
              ? "#422006"
              : p.tipo === "pedra"
                ? "#1c1917"
                : "#0f172a"
        }
      >
        {p.tipo !== "vidro" ? p.nome : ""}
      </text>
      <text x={x + w / 2} y={y + h + 18} textAnchor="middle" fontSize="11" fill="#0f172a">
        {Math.round(p.largura)} x {Math.round(p.altura)}
      </text>
    </g>
  );
}
function Dimension({
  x1,
  y1,
  x2,
  y2,
  label,
  vertical,
}: {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  label: string;
  vertical?: boolean;
}) {
  return (
    <g stroke="#111827" fill="#111827">
      <line x1={x1} y1={y1} x2={x2} y2={y2} strokeWidth="1.5" />
      <line x1={x1} y1={y1 - 7} x2={x1} y2={y1 + 7} />
      <line x1={x2} y1={y2 - 7} x2={x2} y2={y2 + 7} />
      <text
        x={(x1 + x2) / 2}
        y={(y1 + y2) / 2 - 8}
        textAnchor="middle"
        fontSize="13"
        fontWeight="700"
        transform={vertical ? `rotate(-90 ${(x1 + x2) / 2} ${(y1 + y2) / 2})` : undefined}
      >
        {label}
      </text>
    </g>
  );
}
function Action({
  icon: Icon,
  label,
  onClick,
  green,
  blue,
  red,
}: {
  icon: LucideIcon;
  label: string;
  onClick?: () => void;
  green?: boolean;
  blue?: boolean;
  red?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold ${green ? "bg-emerald-600 hover:bg-emerald-500" : blue ? "bg-blue-600 hover:bg-blue-500" : red ? "bg-red-600 hover:bg-red-500" : "border border-white/10 bg-white/5 hover:bg-white/10"}`}
    >
      <Icon className="h-4 w-4" />
      {label}
    </button>
  );
}
function IconBtn({ icon: Icon, onClick }: { icon: LucideIcon; onClick: () => void }) {
  return (
    <button onClick={onClick} className="rounded bg-white/5 p-2 hover:bg-white/10">
      <Icon className="h-4 w-4" />
    </button>
  );
}
function Tool({
  icon: Icon,
  label,
  onClick,
  ativo,
  title,
}: {
  icon: LucideIcon;
  label: string;
  onClick?: () => void;
  /** Só as ferramentas que são MODO usam isto. As de ação passam `undefined`. */
  ativo?: boolean;
  title?: string;
}) {
  return (
    <button
      onClick={onClick}
      title={title}
      aria-pressed={ativo}
      className={`inline-flex items-center gap-1 rounded px-2 py-1 ${ativo ? "bg-blue-600 font-bold text-white" : "hover:bg-white/10"}`}
    >
      <Icon className="h-3.5 w-3.5" />
      {label}
    </button>
  );
}
function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white p-3 text-slate-950">
      <div className="mb-2 text-xs font-bold uppercase">{title}</div>
      {children}
    </div>
  );
}
function Mini3D({ pieces, is3d }: { pieces: Piece[]; is3d: boolean }) {
  // Revisao 119 — isto NÃO é Three.js / WebGL.
  // É SVG com skewY e polígonos de falsa profundidade (o `is3d` só liga o efeito).
  // Existe um Studio3D real (`src/components/projects/Studio3D.tsx` + Product3D /
  // ProjectViewer, ~1.8k linhas, three + R3F/drei) que NENHUMA rota importa hoje.
  // Ligar ou remover esse bloco é decisão de produto futura (Revisão 118).
  return (
    <svg viewBox="0 0 260 160" className="h-36 w-full rounded bg-slate-100">
      <defs>
        <pattern id="miniWood" width="18" height="10" patternUnits="userSpaceOnUse">
          <rect width="18" height="10" fill="#c0843d" />
          <path d="M0 6 C6 2 11 9 18 4" stroke="#7c4a15" fill="none" opacity=".5" />
        </pattern>
        <pattern id="miniStone" width="16" height="16" patternUnits="userSpaceOnUse">
          <rect width="16" height="16" fill="#a8a29e" />
          <circle cx="4" cy="5" r="1.2" fill="#44403c" opacity=".5" />
          <circle cx="11" cy="12" r="1" fill="#fff" opacity=".6" />
        </pattern>
      </defs>
      <g transform={is3d ? "skewY(-8) translate(16 26)" : "translate(12 20)"}>
        {pieces
          .filter((p) => ["vidro", "mdf", "pedra", "aco"].includes(p.tipo))
          .slice(0, 6)
          .map((p, i) => {
            const fill =
              p.tipo === "mdf" ? "url(#miniWood)" : p.tipo === "pedra" ? "url(#miniStone)" : p.cor;
            return (
              <g key={p.id}>
                <rect
                  x={10 + i * 36}
                  y={32 + i * 3}
                  width="34"
                  height="82"
                  fill={fill}
                  opacity=".75"
                  stroke="#0f172a"
                />
                {is3d && (
                  <polygon
                    points={`${44 + i * 36},${32 + i * 3} ${55 + i * 36},${22 + i * 3} ${55 + i * 36},${104 + i * 3} ${44 + i * 36},${114 + i * 3}`}
                    fill="#64748b"
                    opacity=".35"
                  />
                )}
              </g>
            );
          })}
      </g>
    </svg>
  );
}
function CutPlan({ pieces }: { pieces: Piece[] }) {
  return (
    <svg viewBox="0 0 260 160" className="h-36 w-full rounded bg-slate-100">
      {pieces
        .filter((p) => ["vidro", "mdf", "pedra", "aco"].includes(p.tipo))
        .slice(0, 4)
        .map((p, i) => (
          <g key={p.id}>
            <rect
              x={12 + i * 60}
              y="30"
              width="48"
              height="92"
              fill={p.tipo === "mdf" ? "#d6a55d" : p.tipo === "pedra" ? "#a8a29e" : p.cor}
              opacity=".7"
              stroke="#334155"
            />
            <text x={36 + i * 60} y="62" textAnchor="middle" fontSize="10" fontWeight="700">
              {p.tipo === "mdf" ? "MDF" : p.tipo === "pedra" ? "PEDRA" : i + 1}
            </text>
            <text x={36 + i * 60} y="138" textAnchor="middle" fontSize="9">
              {Math.round(p.largura)}x{Math.round(p.altura)}
            </text>
          </g>
        ))}
    </svg>
  );
}
function Materials({ pieces }: { pieces: Piece[] }) {
  return (
    <div className="max-h-36 overflow-auto text-xs">
      <table className="w-full">
        <tbody>
          {pieces.slice(0, 9).map((p) => (
            <tr key={p.id} className="border-b">
              <td className="py-1">
                <b>{p.nome}</b>
                <br />
                <span className="text-slate-500">{p.material}</span>
              </td>
              <td className="text-right">{p.qtd}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
function Summary({
  metrics,
}: {
  metrics: { area: number; linear: number; ferragens: number; materiais: number; total: number };
}) {
  return (
    <div className="space-y-1 text-sm">
      <Row label="Área" value={`${metrics.area.toFixed(2)} m²`} />
      <Row label="Metro linear" value={`${metrics.linear.toFixed(2)} m`} />
      <Row label="Materiais" value={brl(metrics.materiais)} />
      <div className="mt-3 border-t pt-2 text-xl font-bold text-emerald-600">
        {brl(metrics.total)}
      </div>
    </div>
  );
}
function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-2">
      <span className="text-slate-500">{label}</span>
      <b>{value}</b>
    </div>
  );
}
function TextEdit({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-white/60">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none focus:border-cyan-400"
      />
    </label>
  );
}
/**
 * Revisao 32 — era `type="number"` com `Number(...) || 0`, o par que zerava a
 * medida quando o usuario digitava com virgula. Agora e texto com rascunho: a
 * conversao aceita "," e ".", e o que nao e numero deixa o valor anterior
 * intacto e sinaliza na borda, em vez de virar 0 sem aviso.
 */
function NumberEdit({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  const [draft, setDraft] = useState<string | null>(null);
  const texto = draft ?? numeroParaTexto(value);
  const invalido = draft !== null && draft.trim() !== "" && Number.isNaN(textoParaNumero(draft));
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-white/60">{label}</span>
      <input
        inputMode="decimal"
        value={texto}
        title={
          invalido
            ? "Valor inválido — use apenas números, com vírgula ou ponto na casa decimal."
            : undefined
        }
        onChange={(e) => {
          setDraft(e.target.value);
          const n = textoParaNumero(e.target.value);
          if (!Number.isNaN(n)) onChange(n);
        }}
        onBlur={() => setDraft(null)}
        className={`w-full rounded-lg border bg-white/5 px-3 py-2 text-sm outline-none focus:border-cyan-400 ${invalido ? "border-red-500 text-red-300" : "border-white/10"}`}
      />
    </label>
  );
}
