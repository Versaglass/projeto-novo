import { MessageCircle } from "lucide-react";

/**
 * Passo a passo de "mandar o orçamento pelo WhatsApp" (Revisao 114).
 *
 * POR QUE ISTO EXISTE, e por que NÃO é um defeito a corrigir: o link
 * `wa.me` abre a conversa com TEXTO e nada mais — ele não anexa arquivo.
 * Anexar sozinho exigiria a API oficial de negócios do WhatsApp, que é paga
 * e está fora de escopo. Confirmado com o responsável: o comportamento fica
 * como está; o que muda é a CLAREZA da instrução.
 *
 * POR QUE UM COMPONENTE, e não duas frases soltas: a orientação vive no
 * detalhe do orçamento (e já morou na aba Adicionar — Revisões 57, 59, 114).
 * A Revisao 167 **removeu** o banner da seleção de cliente: ali ainda não
 * existe orçamento/PDF. A ESTRUTURA abaixo continua a mesma; o único trecho
 * que muda entre contextos é o passo 1:
 *
 *   • no DETALHE o cartão "Orçamento" está ali na mesma tela;
 *   • o contexto "listagem" ficou no componente por compatibilidade, mas a
 *     aba Adicionar não o renderiza mais (Rev. 167).
 *
 * ⚠️ O rótulo citado é "Orçamento", NÃO "PDF": a Revisão 78 renomeou aquele
 * cartão, e os dois textos antigos continuaram mandando o vendedor clicar num
 * "botão PDF" que não existe mais.
 */
export function InstrucaoWhatsAppPdf({ contexto }: { contexto: "detalhe" | "listagem" }) {
  const passo1 =
    contexto === "detalhe" ? (
      <>
        <b>Baixe o PDF</b> no cartão <b>Orçamento</b> aqui em cima.
      </>
    ) : (
      <>
        <b>Abra o orçamento</b> e baixe o PDF no cartão <b>Orçamento</b>.
      </>
    );

  return (
    <div className="mb-3 rounded-xl border border-emerald-600/25 bg-emerald-600/5 p-3">
      <div className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold text-foreground">
        <MessageCircle className="h-3.5 w-3.5 text-emerald-600" />
        Para enviar o orçamento pelo WhatsApp, são 3 passos
      </div>
      <ol className="ml-4 list-decimal space-y-0.5 text-xs text-muted-foreground marker:font-semibold marker:text-foreground">
        <li>{passo1}</li>
        <li>
          <b>Abra o WhatsApp</b> no botão verde — ele vem <b>só com a mensagem de texto</b>.
        </li>
        <li>
          <b>Anexe na conversa</b> o arquivo que você acabou de baixar e envie.
        </li>
      </ol>
      <p className="mt-1.5 text-[11px] text-muted-foreground/80">
        O PDF não vai junto automaticamente: o link do WhatsApp só carrega texto.
      </p>
    </div>
  );
}
