import { useMemo, useState } from "react";
import { Download, Filter, Search, FileDown, PackagePlus, Plus, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { aluminumCategories, aluminumProfiles, type AluminumProfile } from "@/data/aluminumCatalog";
import { toast } from "sonner";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { useCompany } from "@/contexts/company-context";
import { useAuth } from "@/hooks/use-auth";
import { canManageCompanyEstoque } from "@/lib/inventory-auth";
import {
  useCreateInventoryItem,
  inventoryErrorMessage,
  uploadInventoryImage,
} from "@/hooks/use-inventory";
import { InventoryItemDialog } from "@/components/inventory/InventoryItemDialog";
import {
  inventoryFormToInput,
  type InventoryItemDraft,
  type InventoryItemForm,
} from "@/components/inventory/inventory-item-form";

const STROKE = "#0f172a";
const FILL = "#111827";
const LABEL = "#2563eb";
const PATH_ATTR = `stroke="${STROKE}" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" fill="none"`;

function escXml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

/** SVG completo do desenho técnico — mesma aparência de `AluminumDrawing`. */
export function aluminumProfileSvgMarkup(profile: AluminumProfile): string {
  const medidas = [
    profile.aMm ? `A ${profile.aMm}mm` : "",
    profile.bMm ? `B ${profile.bMm}mm` : "",
    profile.cMm ? `C ${profile.cMm}mm` : "",
  ]
    .filter(Boolean)
    .join(" • ");

  let shape = "";
  switch (profile.desenho) {
    case "barra":
      shape = `<rect x="42" y="62" width="136" height="18" fill="${FILL}" rx="2" />`;
      break;
    case "cantoneira":
      shape = `<path d="M70 28 V98 H154" ${PATH_ATTR} />`;
      break;
    case "cantoneira_desigual":
      shape = `<path d="M80 30 V104 H166" ${PATH_ATTR} />`;
      break;
    case "tubo_redondo":
      shape = `<circle cx="110" cy="70" r="40" stroke="${STROKE}" stroke-width="10" fill="none" /><circle cx="110" cy="70" r="24" fill="#fff" />`;
      break;
    case "tubo_retangular":
      shape = `<rect x="42" y="46" width="136" height="52" stroke="${STROKE}" stroke-width="10" fill="none" /><rect x="60" y="61" width="100" height="22" fill="#fff" />`;
      break;
    case "tubo_quadrado":
      shape = `<rect x="70" y="30" width="80" height="80" stroke="${STROKE}" stroke-width="10" fill="none" /><rect x="88" y="48" width="44" height="44" fill="#fff" />`;
      break;
    case "u":
      shape = `<path d="M72 30 V102 H148 V30" ${PATH_ATTR} />`;
      break;
    case "u_desigual":
      shape = `<path d="M76 24 V104 H158 V42" ${PATH_ATTR} />`;
      break;
    case "t":
      shape = `<path d="M52 42 H168" ${PATH_ATTR} /><path d="M110 42 V106" ${PATH_ATTR} />`;
      break;
    case "vergalhao":
      shape = `<circle cx="110" cy="70" r="38" fill="${FILL}" />`;
      break;
    case "perfil_complexo":
      shape = `<path d="M54 42 H156 L166 55 H112 v12 h44 v12 h-44 v18 H68 V72 H54 Z" fill="${FILL}" />`;
      break;
  }

  return [
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 220 140" width="880" height="560">`,
    `<rect x="1" y="1" width="218" height="138" fill="#ffffff" stroke="#e5e7eb" />`,
    shape,
    `<text x="14" y="20" font-size="12" font-weight="700" fill="${LABEL}" font-family="system-ui,sans-serif">${escXml(profile.codigo)}</text>`,
    `<text x="14" y="124" font-size="10" fill="#475569" font-family="system-ui,sans-serif">${escXml(medidas)}</text>`,
    `</svg>`,
  ].join("");
}

function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Não foi possível carregar o desenho técnico."));
    img.src = url;
  });
}

/** Converte o desenho do perfil em PNG para gravar no estoque. */
export async function aluminumProfileToPngFile(profile: AluminumProfile): Promise<File> {
  const svg = aluminumProfileSvgMarkup(profile);
  const blob = new Blob([svg], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  try {
    const img = await loadImage(url);
    const canvas = document.createElement("canvas");
    canvas.width = 880;
    canvas.height = 560;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Não foi possível gerar a imagem do perfil.");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    const png = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob(
        (b) => (b ? resolve(b) : reject(new Error("Não foi possível gerar a imagem do perfil."))),
        "image/png",
      );
    });
    const nome = `${profile.codigo.toLowerCase().replace(/[^a-z0-9-]+/g, "-")}.png`;
    return new File([png], nome, { type: "image/png" });
  } finally {
    URL.revokeObjectURL(url);
  }
}

export function AluminumDrawing({
  profile,
  className = "",
}: {
  profile: AluminumProfile;
  className?: string;
}) {
  const stroke = STROKE;
  const fill = FILL;
  const label = LABEL;
  const common = {
    stroke,
    strokeWidth: 6,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    fill: "none",
  };
  return (
    <svg
      viewBox="0 0 220 140"
      className={className || "h-28 w-full rounded-lg bg-card"}
      role="img"
      aria-label={`Desenho técnico ${profile.codigo}`}
    >
      <rect x="1" y="1" width="218" height="138" fill="#ffffff" stroke="#e5e7eb" />
      {profile.desenho === "barra" && (
        <rect x="42" y="62" width="136" height="18" fill={fill} rx="2" />
      )}
      {profile.desenho === "cantoneira" && <path d="M70 28 V98 H154" {...common} />}
      {profile.desenho === "cantoneira_desigual" && <path d="M80 30 V104 H166" {...common} />}
      {profile.desenho === "tubo_redondo" && (
        <>
          <circle cx="110" cy="70" r="40" stroke={stroke} strokeWidth="10" fill="none" />
          <circle cx="110" cy="70" r="24" fill="#fff" />
        </>
      )}
      {profile.desenho === "tubo_retangular" && (
        <>
          <rect
            x="42"
            y="46"
            width="136"
            height="52"
            stroke={stroke}
            strokeWidth="10"
            fill="none"
          />
          <rect x="60" y="61" width="100" height="22" fill="#fff" />
        </>
      )}
      {profile.desenho === "tubo_quadrado" && (
        <>
          <rect x="70" y="30" width="80" height="80" stroke={stroke} strokeWidth="10" fill="none" />
          <rect x="88" y="48" width="44" height="44" fill="#fff" />
        </>
      )}
      {profile.desenho === "u" && <path d="M72 30 V102 H148 V30" {...common} />}
      {profile.desenho === "u_desigual" && <path d="M76 24 V104 H158 V42" {...common} />}
      {profile.desenho === "t" && (
        <>
          <path d="M52 42 H168" {...common} />
          <path d="M110 42 V106" {...common} />
        </>
      )}
      {profile.desenho === "vergalhao" && <circle cx="110" cy="70" r="38" fill={fill} />}
      {profile.desenho === "perfil_complexo" && (
        <path d="M54 42 H156 L166 55 H112 v12 h44 v12 h-44 v18 H68 V72 H54 Z" fill={fill} />
      )}
      <text x="14" y="20" fontSize="12" fontWeight="700" fill={label}>
        {profile.codigo}
      </text>
      <text x="14" y="124" fontSize="10" fill="#475569">
        {profile.aMm ? `A ${profile.aMm}mm` : ""}
        {profile.bMm ? ` • B ${profile.bMm}mm` : ""}
        {profile.cMm ? ` • C ${profile.cMm}mm` : ""}
      </text>
    </svg>
  );
}

const catalogProfiles = aluminumProfiles.map((p) => ({ ...p, estoque: 0, estoqueMinimo: 0 }));

function draftFromProfile(p: AluminumProfile): InventoryItemDraft {
  const medidas = [p.aMm && `A ${p.aMm}mm`, p.bMm && `B ${p.bMm}mm`, p.cMm && `C ${p.cMm}mm`]
    .filter(Boolean)
    .join(" • ");
  const descricao = [
    p.categoria,
    `${p.medidaM} m`,
    `${p.pesoKgM.toFixed(3).replace(".", ",")} kg/m`,
    medidas,
    p.polegadas,
  ]
    .filter(Boolean)
    .join(" · ")
    .slice(0, 255);
  return {
    nome: `${p.codigo} — ${p.nome}`.slice(0, 120).toUpperCase(),
    categoria: "aluminio",
    unidade: "m",
    descricao,
    sku: p.sku,
    ncm: p.ncm,
  };
}

export function AluminumCatalog() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Todas");
  const [draft, setDraft] = useState<InventoryItemDraft | null>(null);
  const [gerandoFoto, setGerandoFoto] = useState<string | null>(null);
  const { activeCompany, companyRole } = useCompany();
  const { permissions } = useAuth();
  const create = useCreateInventoryItem();
  const canWriteStock = canManageCompanyEstoque({
    hasActiveCompany: Boolean(activeCompany?.companyId),
    companyRole,
    permissions,
  });

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return catalogProfiles.filter((p) => {
      const matchesCat = category === "Todas" || p.categoria === category;
      const matchesQ =
        !q ||
        [p.codigo, p.sku, p.nome, p.categoria, p.polegadas].join(" ").toLowerCase().includes(q);
      return matchesCat && matchesQ;
    });
  }, [query, category]);

  const exportPdf = () => {
    const doc = new jsPDF({ orientation: "landscape" });
    doc.setFontSize(16);
    doc.text("Catálogo técnico de alumínios", 14, 16);
    doc.setFontSize(10);
    doc.text(
      "Desenhos técnicos sem marca. Estoque inicial zerado para cada empresa informar suas próprias quantidades.",
      14,
      23,
    );
    autoTable(doc, {
      startY: 30,
      head: [
        [
          "SKU",
          "Código",
          "Nome",
          "Categoria",
          "Peça",
          "Peso kg/m",
          "Medidas",
          "Polegadas",
          "Estoque",
          "NCM",
        ],
      ],
      body: catalogProfiles.map((p) => [
        p.sku,
        p.codigo,
        p.nome,
        p.categoria,
        `${p.medidaM} m`,
        p.pesoKgM.toFixed(3),
        [p.aMm && `A ${p.aMm}mm`, p.bMm && `B ${p.bMm}mm`, p.cMm && `C ${p.cMm}mm`]
          .filter(Boolean)
          .join(" • "),
        p.polegadas || "—",
        "0",
        p.ncm,
      ]),
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [15, 23, 42] },
      columnStyles: { 2: { cellWidth: 58 } },
    });
    doc.save("catalogo-aluminios-sem-marca.pdf");
    toast.success("PDF do catálogo de alumínios baixado");
  };

  const exportCsv = () => {
    const headers = [
      "sku",
      "codigo",
      "nome",
      "categoria",
      "medidaM",
      "pesoKgM",
      "aMm",
      "bMm",
      "cMm",
      "polegadas",
      "ncm",
      "gtin",
      "estoque",
      "estoqueMinimo",
      "precoCusto",
      "precoVenda",
    ];
    const rows = [
      headers.join(";"),
      ...catalogProfiles.map((p) =>
        headers
          .map((h) => `"${String((p as Record<string, unknown>)[h] ?? "").replaceAll('"', '""')}"`)
          .join(";"),
      ),
    ];
    const blob = new Blob([rows.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "catalogo-aluminios-sem-marca.csv";
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Catálogo de alumínios exportado");
  };

  const abrirCadastro = (seed: InventoryItemDraft) => {
    if (!activeCompany) {
      toast.error("Selecione uma empresa ativa para cadastrar no estoque.");
      return;
    }
    if (!canWriteStock) {
      toast.error("Você não tem permissão para gerenciar o estoque.");
      return;
    }
    setDraft(seed);
  };

  const cadastrarPerfil = async (p: AluminumProfile) => {
    if (!activeCompany) {
      toast.error("Selecione uma empresa ativa para cadastrar no estoque.");
      return;
    }
    if (!canWriteStock) {
      toast.error("Você não tem permissão para gerenciar o estoque.");
      return;
    }
    if (gerandoFoto) return;
    setGerandoFoto(p.id);
    try {
      const file = await aluminumProfileToPngFile(p);
      const path = await uploadInventoryImage(activeCompany.companyId, file);
      abrirCadastro({ ...draftFromProfile(p), imagem_url: path });
    } catch (e) {
      console.error("[aluminios] falha ao gerar/enviar foto do perfil", e);
      toast.error(e instanceof Error ? e.message : inventoryErrorMessage(e));
    } finally {
      setGerandoFoto(null);
    }
  };

  const cadastrarNovo = () =>
    abrirCadastro({
      categoria: "aluminio",
      unidade: "m",
      nome: "",
      descricao: "",
    });

  const onCadastrarEstoque = (form: InventoryItemForm) => {
    create.mutate(inventoryFormToInput(form), {
      onSuccess: () => {
        toast.success("Alumínio cadastrado no estoque");
        setDraft(null);
      },
      onError: (e) => toast.error(e instanceof Error ? e.message : inventoryErrorMessage(e)),
    });
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <Badge variant="secondary" className="mb-3">
            Produtos / Alumínios
          </Badge>
          <h2 className="font-display text-2xl font-bold">Catálogo técnico de alumínios</h2>
          <p className="mt-1 max-w-3xl text-sm text-muted-foreground">
            Use um perfil do catálogo ou cadastre um alumínio próprio. O item vai para o estoque da
            empresa, pronto para orçamento. Quantidade inicial fica zerada até você informar.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            onClick={cadastrarNovo}
            disabled={!activeCompany || !canWriteStock}
            className="gap-2"
          >
            <Plus className="h-4 w-4" /> Novo alumínio
          </Button>
          <Button variant="outline" onClick={exportPdf} className="gap-2">
            <FileDown className="h-4 w-4" /> Baixar PDF
          </Button>
          <Button variant="outline" onClick={exportCsv} className="gap-2">
            <Download className="h-4 w-4" /> Exportar CSV
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="grid gap-3 p-4 md:grid-cols-[1fr_280px]">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              className="pl-9"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar por código, nome, SKU ou medida"
            />
          </div>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger>
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Todas">Todas categorias</SelectItem>
              {aluminumCategories.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Tabs defaultValue="cards" className="space-y-4">
        <TabsList>
          <TabsTrigger value="cards">Cards com imagem</TabsTrigger>
          <TabsTrigger value="tabela">Tabela técnica</TabsTrigger>
        </TabsList>
        <TabsContent value="cards" className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((p) => (
            <Card key={p.id} className="overflow-hidden">
              <div className="bg-muted/40 p-3">
                <AluminumDrawing profile={p} />
              </div>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <CardTitle className="text-lg">{p.codigo}</CardTitle>
                    <p className="mt-1 text-sm font-medium">{p.nome}</p>
                  </div>
                  <Badge>{p.categoria}</Badge>
                </div>
              </CardHeader>
              <CardContent className="grid gap-2 text-sm">
                <Line label="SKU" value={p.sku} />
                <Line label="Peça" value={`${p.medidaM} m`} />
                <Line label="Peso" value={`${p.pesoKgM.toFixed(3).replace(".", ",")} kg/m`} />
                <Line
                  label="Medidas"
                  value={[p.aMm && `A ${p.aMm}mm`, p.bMm && `B ${p.bMm}mm`, p.cMm && `C ${p.cMm}mm`]
                    .filter(Boolean)
                    .join(" • ")}
                />
                <Line label="Polegadas" value={p.polegadas || "—"} />
                <Line label="NCM" value={p.ncm} />
                <Button
                  type="button"
                  className="mt-2 w-full gap-2"
                  disabled={!canWriteStock || gerandoFoto === p.id}
                  onClick={() => cadastrarPerfil(p)}
                >
                  {gerandoFoto === p.id ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <PackagePlus className="h-4 w-4" />
                  )}
                  {gerandoFoto === p.id ? "Preparando foto…" : "Usar este perfil"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
        <TabsContent value="tabela">
          <Card>
            <CardContent className="overflow-x-auto p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Imagem</TableHead>
                    <TableHead>Código</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Nome</TableHead>
                    <TableHead>Peça</TableHead>
                    <TableHead>Peso</TableHead>
                    <TableHead>A</TableHead>
                    <TableHead>B</TableHead>
                    <TableHead>C</TableHead>
                    <TableHead>NCM</TableHead>
                    <TableHead className="text-right">Ação</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell className="w-36">
                        <AluminumDrawing profile={p} className="h-16 w-32 rounded bg-card" />
                      </TableCell>
                      <TableCell className="font-bold">{p.codigo}</TableCell>
                      <TableCell>{p.categoria}</TableCell>
                      <TableCell>{p.nome}</TableCell>
                      <TableCell>{p.medidaM} m</TableCell>
                      <TableCell>{p.pesoKgM.toFixed(3)} kg/m</TableCell>
                      <TableCell>{p.aMm ?? "—"}</TableCell>
                      <TableCell>{p.bMm ?? "—"}</TableCell>
                      <TableCell>{p.cMm ?? "—"}</TableCell>
                      <TableCell>{p.ncm}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          className="gap-1"
                          disabled={!canWriteStock || gerandoFoto === p.id}
                          onClick={() => cadastrarPerfil(p)}
                        >
                          {gerandoFoto === p.id ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          ) : (
                            <PackagePlus className="h-3.5 w-3.5" />
                          )}
                          Usar
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {draft && (
        <InventoryItemDialog
          key={`${draft.sku ?? "novo"}-${draft.nome ?? "aluminio"}-${draft.imagem_url ?? "sem-foto"}`}
          initial={null}
          draft={draft}
          onClose={() => setDraft(null)}
          onSubmit={onCadastrarEstoque}
          loading={create.isPending}
        />
      )}
    </div>
  );
}

function Line({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-3 border-b pb-1">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}
