import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import {
  ChevronRight,
  Cloud,
  Eye,
  EyeOff,
  LayoutDashboard,
  LockKeyhole,
  Mail,
  PanelsTopLeft,
  ShieldCheck,
  Sparkles,
  Users,
  type LucideIcon,
} from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { logEvent } from "@/lib/log-event";
import { mensagemDeErroDeAuth } from "@/lib/auth-error-message";
import {
  ACCOUNT_INACTIVE_TOAST,
  consumeAccountInactiveToast,
  fetchAccountActiveStatus,
  shouldShowAccountInactiveToast,
} from "@/lib/account-active";
import { markAuthSessionValidated } from "@/lib/auth-session-snapshot";
import { ttIdentify, ttTrack } from "@/lib/tiktok";

import segmentVidracaria from "@/assets/segment-vidracaria.jpg";
import segmentEsquadrias from "@/assets/segment-esquadrias.jpg";
import { getStoredSegment } from "@/lib/segmentAccess";

// Tela pública de autenticação — extraída de `src/routes/auth.tsx` SEM nenhuma
// alteração visual, para poder ser renderizada por duas rotas:
//   · "/"     → entrada principal do sistema (usuário sem sessão);
//   · "/auth" → alias de compatibilidade, mantido porque o callback do OAuth
//               aponta para `origin + "/auth"` e o `onAuthStateChange` abaixo lê
//               `access_token`/`code=` do hash. Um redirect de "/auth" para "/"
//               descartaria esse fragmento e quebraria o retorno do provedor.
// Ambas as rotas usam ESTE componente — não existe segunda implementação.

const showcase = [
  { label: "Vidraçaria", image: segmentVidracaria, text: "Vidros, espelhos, fachadas e box." },
  {
    label: "Esquadrias",
    image: segmentEsquadrias,
    text: "Portas, janelas, fachadas e estruturas.",
  },
];

const schema = z.object({
  email: z.string().trim().email("E-mail inválido").max(255),
  password: z.string().min(6, "Mínimo 6 caracteres").max(72),
  nome: z.string().trim().max(120).optional(),
  empresa: z.string().trim().max(120).optional(),
});

// O provider Google não está configurado no projeto Supabase, então o botão
// fica oculto: exibi-lo só levaria o usuário a uma tentativa fadada a falhar.
// O fluxo OAuth abaixo é preservado para reativação — volte esta flag para
// `true` assim que o provider estiver habilitado no Dashboard.
const GOOGLE_OAUTH_ENABLED = false;

// Destino pós-login. `_authenticated` manda quem tenta entrar sem sessão para a
// autenticação com `?redirect=<rota pedida>`; aqui esse valor é honrado, mas só
// se for um caminho INTERNO da área autenticada. Qualquer outra coisa (URL
// absoluta, `//host`, rota pública) cai no padrão `/app` — um `redirect` vindo
// da barra de endereço não pode virar redirecionamento aberto.
function safeRedirectTarget(raw: unknown): string {
  if (typeof raw !== "string") return "/app";
  const valor = raw.trim();
  if (!valor.startsWith("/") || valor.startsWith("//")) return "/app";
  return valor === "/app" || valor.startsWith("/app/") || valor.startsWith("/app?")
    ? valor
    : "/app";
}

export function AuthPage() {
  const navigate = useNavigate();
  // Lido do router (funciona em "/" e em "/auth", que não declaram search schema).
  const destino = useRouterState({
    select: (s) => safeRedirectTarget((s.location.search as Record<string, unknown>)?.redirect),
  });
  const [mode, setMode] = useState<"login" | "signup" | "forgot">("login");
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ email: "", password: "", nome: "", empresa: "" });

  // Toast enfileirado pelo guard / auth-context após signOut por conta inativa.
  useEffect(() => {
    const msg = consumeAccountInactiveToast();
    if (msg && shouldShowAccountInactiveToast()) toast.error(msg);
  }, []);

  useEffect(() => {
    let cancelled = false;
    let loggedOAuth = false;

    const goIfActive = async (userId: string) => {
      const status = await fetchAccountActiveStatus(userId);
      if (cancelled) return;
      if (status === "inactive") {
        await supabase.auth.signOut({ scope: "local" });
        if (shouldShowAccountInactiveToast()) toast.error(ACCOUNT_INACTIVE_TOAST);
        return;
      }
      // `unknown`: não bloqueia na tela de login; `/_authenticated` revalida.
      navigate({ to: destino as never, replace: true });
    };

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, s) => {
      if (event === "SIGNED_IN" && s?.user && !loggedOAuth) {
        const h =
          typeof window !== "undefined" ? window.location.hash + window.location.search : "";
        if (h.includes("access_token") || h.includes("code=")) {
          loggedOAuth = true;
          logEvent("login_success", {
            email: s.user.email ?? undefined,
            user_id: s.user.id,
            metadata: {
              method: s.user.app_metadata?.provider ?? "unknown",
              selectedSegment: getStoredSegment(),
            },
          });
        }
      }
      if (s?.user) void goIfActive(s.user.id);
    });
    supabase.auth.getSession().then(({ data }) => {
      if (data.session?.user) void goIfActive(data.session.user.id);
    });
    return () => {
      cancelled = true;
      subscription.unsubscribe();
    };
  }, [navigate, destino]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (mode === "forgot") {
      if (!form.email) {
        toast.error("Informe seu e-mail");
        return;
      }
      setLoading(true);
      try {
        const { error } = await supabase.auth.resetPasswordForEmail(form.email, {
          redirectTo: window.location.origin + "/reset-password",
        });
        if (error) throw error;
        toast.success("Enviamos um link de redefinição para seu e-mail.");
        setMode("login");
      } catch (err: unknown) {
        // Nunca o texto cru do provedor: um "user not found" aqui diria quem
        // tem conta. O sucesso acima também é genérico, pelo mesmo motivo.
        toast.error(
          mensagemDeErroDeAuth(
            "recuperacao-senha",
            err,
            "Não foi possível enviar o e-mail de recuperação. Tente novamente em instantes.",
          ),
        );
      } finally {
        setLoading(false);
      }
      return;
    }

    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Dados inválidos");
      return;
    }

    setLoading(true);
    const selectedSegment = getStoredSegment();
    try {
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email: form.email,
          password: form.password,
          options: {
            emailRedirectTo: window.location.origin + "/app",
            data: { nome: form.nome, empresa: form.empresa, preferred_segment: selectedSegment },
          },
        });
        if (error) throw error;
        await logEvent("signup", {
          email: form.email,
          user_id: data.user?.id,
          metadata: { nome: form.nome, empresa: form.empresa, preferred_segment: selectedSegment },
        });
        await ttIdentify({ email: form.email, userId: data.user?.id });
        ttTrack("CompleteRegistration", {
          contents: [
            { content_id: "signup", content_type: "product", content_name: "Cadastro VersaGlass" },
          ],
          value: 0,
          currency: "BRL",
        });
        toast.success("Cadastro criado! Verifique seu e-mail para confirmar.");
        setMode("login");
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: form.email,
          password: form.password,
        });
        if (error) {
          await logEvent("login_error", {
            email: form.email,
            metadata: { reason: error.message, method: "password", selectedSegment },
          });
          if (error.message?.toLowerCase().includes("invalid login")) {
            // Mensagem deliberadamente neutra: não confirma nem nega a existência
            // da conta, e não cita provedor de OAuth (ver P-24).
            toast.error(
              "Não foi possível entrar. Verifique seu e-mail e senha ou use a opção de recuperação de senha.",
              { duration: 8000 },
            );
            return;
          }
          throw error;
        }

        const uid = data.user?.id;
        if (uid) {
          const status = await fetchAccountActiveStatus(uid);
          if (status === "inactive") {
            await supabase.auth.signOut({ scope: "local" });
            if (shouldShowAccountInactiveToast()) toast.error(ACCOUNT_INACTIVE_TOAST);
            return;
          }
        }

        // Login com senha já validou no Auth server — evita getUser() logo ao entrar em /app.
        markAuthSessionValidated(data.session, data.user ?? null);

        await logEvent("login_success", {
          email: form.email,
          user_id: data.user?.id,
          metadata: { method: "password", selectedSegment },
        });
        try {
          await supabase.auth.updateUser({ data: { preferred_segment: selectedSegment } });
        } catch {
          // A escolha do segmento também fica salva no navegador; não travar o login se o update falhar.
        }
        toast.success("Bem-vindo!");
        navigate({ to: destino as never, replace: true });
      }
    } catch (err: unknown) {
      // Fecha o buraco do Defeito 1 (Revisão 21): este `catch` recebe TUDO que
      // não é "invalid login" — cadastro, limite de envio, queda de rede — e
      // imprimia a mensagem do provedor literalmente na tela.
      toast.error(
        mensagemDeErroDeAuth(
          mode === "signup" ? "cadastro" : "login",
          err,
          mode === "signup"
            ? "Não foi possível concluir o cadastro. Tente novamente em instantes."
            : "Não foi possível entrar. Tente novamente em instantes.",
        ),
      );
    } finally {
      setLoading(false);
    }
  };

  const google = async () => {
    setLoading(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin + "/auth",
      extraParams: { prompt: "select_account consent" },
    });
    if (result.error) {
      // O fluxo está desligado por flag (P-24), mas o vazamento seria o mesmo
      // se fosse reativado — e a mensagem continua sem citar o provedor.
      toast.error(
        mensagemDeErroDeAuth(
          "oauth",
          result.error,
          "Não foi possível entrar. Tente novamente em instantes.",
        ),
      );
      setLoading(false);
      return;
    }
    if (result.redirected) return;
    navigate({ to: destino as never, replace: true });
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#050b14] text-white">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_16%_10%,rgba(37,99,235,0.30),transparent_34rem),radial-gradient(circle_at_70%_30%,rgba(124,58,237,0.22),transparent_30rem),radial-gradient(circle_at_82%_88%,rgba(20,184,166,0.12),transparent_36rem)]" />
      <div className="absolute inset-0 opacity-[0.08] [background-image:linear-gradient(to_right,#fff_1px,transparent_1px),linear-gradient(to_bottom,#fff_1px,transparent_1px)] [background-size:44px_44px]" />

      <div className="relative mx-auto grid min-h-screen w-full max-w-[1720px] grid-cols-1 gap-8 p-4 lg:grid-cols-[1.08fr_0.92fr] lg:p-8 xl:p-11">
        <section className="flex min-h-[calc(100vh-5.5rem)] flex-col justify-between py-2">
          <div>
            <Link to="/" className="inline-flex items-center gap-3">
              <div className="relative grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-500 shadow-[0_0_55px_rgba(59,130,246,0.35)]">
                <ShieldCheck className="h-8 w-8 text-white" />
                <span className="absolute -bottom-1 -right-1 h-4 w-4 rounded-full border-2 border-[#050b14] bg-emerald-400" />
              </div>
              <div>
                <div className="text-2xl font-black tracking-tight">
                  <span>VERSA</span>
                  <span className="text-blue-400">GLASS</span>
                </div>
                <div className="mt-0.5 text-[11px] uppercase tracking-[0.42em] text-slate-400">
                  Enterprise
                </div>
              </div>
            </Link>

            <div className="mt-9 max-w-4xl lg:mt-12">
              <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.06] px-4 py-2 text-sm text-slate-200 backdrop-blur-xl">
                <Sparkles className="h-4 w-4 text-yellow-300" />
                Gestão para Vidraçarias e Esquadrias
              </div>

              <h1 className="mt-6 max-w-5xl text-5xl font-black leading-[1.02] tracking-tight sm:text-6xl xl:text-7xl">
                Uma plataforma.{" "}
                <span className="bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400 bg-clip-text text-transparent">
                  Gestão completa.
                </span>
              </h1>

              <p className="mt-6 max-w-3xl text-lg leading-8 text-slate-300 xl:text-xl">
                Sistema completo para vidraçarias e empresas de esquadrias.
                <br className="hidden sm:block" />
                Gerencie projetos, orçamentos, estoque, vendas e financeiro em um só lugar.
              </p>

              <div className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-2">
                {showcase.map((item) => (
                  <RealisticSegmentCard key={item.label} {...item} />
                ))}
              </div>

              <div className="mt-7 grid grid-cols-2 gap-3 md:grid-cols-4">
                <ProofCard
                  icon={Users}
                  value="Multiusuário"
                  label="dados isolados por empresa"
                  tone="text-cyan-300"
                />
                <ProofCard
                  icon={ShieldCheck}
                  value="Seguro"
                  label="permissões por plano"
                  tone="text-emerald-300"
                />
                <ProofCard
                  icon={Cloud}
                  value="Online"
                  label="acesso de qualquer lugar"
                  tone="text-blue-300"
                />
                <ProofCard
                  icon={LayoutDashboard}
                  value="Gestão completa"
                  label="projetos, estoque e financeiro"
                  tone="text-teal-300"
                />
              </div>
            </div>
          </div>

          <div className="mt-10 hidden text-xs uppercase tracking-[0.42em] text-slate-500 lg:block">
            Vidraçaria • Esquadrias • Projetos • Estoque • Orçamentos • Vendas • Financeiro
          </div>
        </section>

        <section className="flex items-center justify-center lg:justify-end">
          <div className="w-full max-w-2xl rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 shadow-[0_35px_100px_rgba(0,0,0,0.45)] backdrop-blur-2xl sm:p-8 xl:p-10">
            <div className="mb-7 text-center">
              <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full border border-blue-400/40 bg-blue-500/10">
                <Users className="h-8 w-8 text-blue-300" />
              </div>
              <h2 className="text-3xl font-black tracking-tight text-white sm:text-4xl">
                {mode === "login"
                  ? "Bem-vindo!"
                  : mode === "signup"
                    ? "Criar conta"
                    : "Recuperar senha"}
              </h2>
              <p className="mt-2 text-base text-slate-300">
                {mode === "login"
                  ? "Entre na sua conta para acessar o sistema."
                  : mode === "signup"
                    ? "Crie sua conta e comece a usar o VersaGlass."
                    : "Use recuperação segura por código no e-mail ou celular."}
              </p>
            </div>

            <form onSubmit={submit} className="space-y-5">
              {mode === "signup" && (
                <>
                  <Field
                    label="Seu nome"
                    value={form.nome}
                    onChange={(v) => setForm({ ...form, nome: v })}
                  />
                  <Field
                    label="Nome da empresa"
                    value={form.empresa}
                    onChange={(v) => setForm({ ...form, empresa: v })}
                  />
                </>
              )}

              <Field
                icon={Mail}
                label="E-mail"
                type="email"
                value={form.email}
                onChange={(v) => setForm({ ...form, email: v })}
                required
                placeholder="seu@email.com"
              />

              {mode !== "forgot" && (
                <PasswordField
                  icon={LockKeyhole}
                  label="Senha"
                  value={form.password}
                  onChange={(v) => setForm({ ...form, password: v })}
                />
              )}

              {mode === "login" && (
                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center gap-2 text-slate-300">
                    <input
                      type="checkbox"
                      className="h-4 w-4 rounded border-white/20 bg-white/10 accent-blue-500"
                      defaultChecked
                    />
                    Lembrar-me
                  </label>
                  <Link
                    to="/forgot-password-2fa"
                    className="font-semibold text-blue-400 hover:text-blue-300"
                  >
                    Esqueceu sua senha?
                  </Link>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="flex h-16 w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-blue-500 to-purple-500 text-lg font-black text-white shadow-[0_20px_60px_rgba(59,130,246,0.35)] transition hover:scale-[1.01] hover:from-blue-400 hover:to-purple-400 disabled:opacity-50"
              >
                {loading
                  ? "Aguarde..."
                  : mode === "login"
                    ? "Entrar"
                    : mode === "signup"
                      ? "Criar conta"
                      : "Enviar link"}
                {!loading && mode !== "forgot" ? <ChevronRight className="h-5 w-5" /> : null}
              </button>
            </form>

            {mode !== "forgot" && GOOGLE_OAUTH_ENABLED && (
              <>
                <div className="my-7 flex items-center gap-4 text-sm text-slate-500">
                  <div className="h-px flex-1 bg-white/10" /> ou continue com{" "}
                  <div className="h-px flex-1 bg-white/10" />
                </div>
                <button
                  onClick={google}
                  disabled={loading}
                  className="flex w-full items-center justify-center gap-3 rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-4 text-base font-semibold text-white transition hover:bg-white/10 disabled:opacity-50"
                >
                  <GoogleIcon />
                  Continuar com Google
                </button>
              </>
            )}

            <button
              onClick={() => setMode(mode === "login" ? "signup" : "login")}
              className="mt-7 w-full text-center text-base text-slate-300 hover:text-white"
            >
              {mode === "login" ? "Ainda não tem uma conta? Criar conta" : "← Já tem conta? Entrar"}
            </button>

            {/* Havia aqui um link "Primeiro acesso? Criar primeira senha com
                código", para /first-password. Removido na Revisão 74.
                A rota NÃO foi apagada — só deixou de ter link.

                Por quê: aquele fluxo pede um CÓDIGO, mas depende do OTP do
                Supabase, e em produção o canal de celular está desligado
                (`phone: false`) e o template de e-mail manda LINK, não dígitos.
                Zero uso registrado. Além disso ele era redundante: chama
                exatamente as mesmas funções de `lib/access-security` que o
                "Esqueceu sua senha?" acima (/forgot-password-2fa) — a única
                diferença era o rótulo gravado em `security_events`.

                Mantido no código por reversibilidade: se o template do projeto
                passar a usar `{{ .Token }}`, basta devolver o link. */}
          </div>
        </section>
      </div>
    </div>
  );
}

function RealisticSegmentCard({
  label,
  image,
  text,
}: {
  label: string;
  image: string;
  text: string;
}) {
  return (
    <div className="group relative min-h-[260px] overflow-hidden rounded-3xl border border-white/10 bg-slate-900 shadow-2xl">
      <img
        src={image}
        alt={label}
        className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-105"
        loading="eager"
        decoding="async"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/45 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 p-5">
        <div className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-white/15 backdrop-blur-md">
          <PanelsTopLeft className="h-6 w-6 text-white" />
        </div>
        <h3 className="text-xl font-black text-white">{label}</h3>
        <p className="mt-2 text-sm leading-6 text-slate-200">{text}</p>
      </div>
    </div>
  );
}

function ProofCard({
  icon: Icon,
  value,
  label,
  tone,
}: {
  icon: LucideIcon;
  value: string;
  label: string;
  tone: string;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.05] p-4 backdrop-blur-xl">
      <Icon className={`h-7 w-7 ${tone}`} />
      <div className="mt-3 text-lg font-black text-white">{value}</div>
      <div className="text-sm text-slate-400">{label}</div>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg className="h-5 w-5" viewBox="0 0 24 24">
      <path
        fill="#4285F4"
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
      />
      <path
        fill="#34A853"
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
      />
      <path
        fill="#FBBC05"
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
      />
      <path
        fill="#EA4335"
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
      />
    </svg>
  );
}

function Field({
  icon: Icon,
  label,
  type = "text",
  value,
  onChange,
  required,
  placeholder,
}: {
  icon?: LucideIcon;
  label: string;
  type?: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
  placeholder?: string;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-semibold text-slate-300">{label}</span>
      <div className="relative">
        {Icon ? (
          <Icon className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-500" />
        ) : null}
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          required={required}
          placeholder={placeholder}
          className={`h-14 w-full rounded-2xl border border-white/10 bg-white/[0.055] ${Icon ? "pl-12" : "pl-4"} pr-4 text-base text-white outline-none transition placeholder:text-slate-500 focus:border-blue-400/60 focus:bg-white/[0.075] focus:ring-4 focus:ring-blue-500/10`}
        />
      </div>
    </label>
  );
}

function PasswordField({
  icon: Icon,
  label,
  value,
  onChange,
}: {
  icon?: LucideIcon;
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  const [show, setShow] = useState(false);
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-semibold text-slate-300">{label}</span>
      <div className="relative">
        {Icon ? (
          <Icon className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-500" />
        ) : null}
        <input
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          required
          minLength={6}
          className={`h-14 w-full rounded-2xl border border-white/10 bg-white/[0.055] ${Icon ? "pl-12" : "pl-4"} pr-14 text-base text-white outline-none transition placeholder:text-slate-500 focus:border-blue-400/60 focus:bg-white/[0.075] focus:ring-4 focus:ring-blue-500/10`}
        />
        <button
          type="button"
          onClick={() => setShow((s) => !s)}
          aria-label={show ? "Ocultar senha" : "Mostrar senha"}
          className="absolute right-3 top-1/2 -translate-y-1/2 rounded-xl p-2 text-slate-400 transition hover:bg-white/10 hover:text-white"
        >
          {show ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
        </button>
      </div>
    </label>
  );
}
