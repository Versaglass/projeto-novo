import { useMemo } from "react";

type Props = {
  /** Largura real em metros */
  widthM: number;
  /** Altura real em metros */
  heightM: number;
  /** Profundidade do box (m) - default 0.9m */
  depthM?: number;
  /** Espessura do perfil de alumínio (mm) - default 25 */
  profileMm?: number;
  /** Espessura do vidro (mm) - default 8 */
  glassMm?: number;
  className?: string;
  /** Exibir cotas sobre a renderização */
  showDims?: boolean;
};

/**
 * Renderização isométrica 3D (SVG puro) de um box de correr de 2 folhas.
 * Gerada dinamicamente a partir das medidas cadastradas — sem imagens,
 * sem WebGL, sem dependências externas. Reage automaticamente a qualquer
 * mudança de largura/altura/profundidade.
 */
export default function IsoSlidingBox3D({
  widthM,
  heightM,
  depthM = 0.15,
  profileMm = 25,
  glassMm = 8,
  className,
  showDims = true,
}: Props) {
  const W = Math.max(0.4, widthM);
  const H = Math.max(0.4, heightM);
  const D = Math.max(0.05, depthM);
  const P = profileMm / 1000; // m
  const G = glassMm / 1000; // m

  // Projeção isométrica (30°) — 1 metro = SCALE px
  const SCALE = 260;
  const ANG = Math.PI / 6; // 30°
  const cos = Math.cos(ANG);
  const sin = Math.sin(ANG);

  // Projeta ponto 3D (x direita, y cima, z profundidade) → 2D
  const proj = (x: number, y: number, z: number) => ({
    x: (x - z) * cos * SCALE,
    y: (-y + (x + z) * sin) * SCALE,
  });

  // Bounding box para viewBox
  const { viewBox, offset } = useMemo(() => {
    const corners = [
      [0, 0, 0],
      [W, 0, 0],
      [0, H, 0],
      [W, H, 0],
      [0, 0, D],
      [W, 0, D],
      [0, H, D],
      [W, H, D],
    ] as const;
    const pts = corners.map(([x, y, z]) => proj(x, y, z));
    const minX = Math.min(...pts.map((p) => p.x));
    const maxX = Math.max(...pts.map((p) => p.x));
    const minY = Math.min(...pts.map((p) => p.y));
    const maxY = Math.max(...pts.map((p) => p.y));
    const pad = 80;
    const w = maxX - minX + pad * 2;
    const h = maxY - minY + pad * 2;
    return {
      viewBox: `0 0 ${w} ${h}`,
      offset: { x: -minX + pad, y: -minY + pad },
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [W, H, D]);

  const p = (x: number, y: number, z: number) => {
    const pt = proj(x, y, z);
    return `${pt.x + offset.x},${pt.y + offset.y}`;
  };

  // Face helper: retorna string "points" para <polygon>
  const face = (pts: Array<[number, number, number]>) =>
    pts.map(([x, y, z]) => p(x, y, z)).join(" ");

  // ==== Componentes do box ====
  // Perfis: base, topo, laterais (extrudados, D de profundidade)
  const halfW = W / 2;

  // Cota label helper
  const cota = (
    from: [number, number, number],
    to: [number, number, number],
    label: string,
    side: "top" | "right",
  ) => {
    const a = proj(from[0], from[1], from[2]);
    const b = proj(to[0], to[1], to[2]);
    const ax = a.x + offset.x;
    const ay = a.y + offset.y;
    const bx = b.x + offset.x;
    const by = b.y + offset.y;
    const off = side === "top" ? -28 : 34;
    const dx = side === "top" ? 0 : off;
    const dy = side === "top" ? off : 0;
    const mx = (ax + bx) / 2 + dx;
    const my = (ay + by) / 2 + dy;
    return (
      <g>
        <line
          x1={ax + dx}
          y1={ay + dy}
          x2={bx + dx}
          y2={by + dy}
          stroke="#94a3b8"
          strokeWidth={1}
        />
        <line
          x1={ax}
          y1={ay}
          x2={ax + dx}
          y2={ay + dy}
          stroke="#94a3b8"
          strokeWidth={1}
          strokeDasharray="3 3"
        />
        <line
          x1={bx}
          y1={by}
          x2={bx + dx}
          y2={by + dy}
          stroke="#94a3b8"
          strokeWidth={1}
          strokeDasharray="3 3"
        />
        <text
          x={mx}
          y={my}
          fill="#e2e8f0"
          fontSize={14}
          fontWeight={600}
          textAnchor="middle"
          dominantBaseline="middle"
          style={{ paintOrder: "stroke", stroke: "#0b1220", strokeWidth: 4 }}
        >
          {label}
        </text>
      </g>
    );
  };

  return (
    <div
      className={className}
      style={{
        position: "relative",
        width: "100%",
        height: "100%",
        background: "#0b1220",
        borderRadius: 8,
        overflow: "hidden",
      }}
    >
      <svg
        viewBox={viewBox}
        preserveAspectRatio="xMidYMid meet"
        style={{ width: "100%", height: "100%", display: "block" }}
      >
        <defs>
          {/* Alumínio escovado */}
          <linearGradient id="alu-front" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#d1d5db" />
            <stop offset="50%" stopColor="#9ca3af" />
            <stop offset="100%" stopColor="#6b7280" />
          </linearGradient>
          <linearGradient id="alu-top" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#e5e7eb" />
            <stop offset="100%" stopColor="#9ca3af" />
          </linearGradient>
          <linearGradient id="alu-side" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#6b7280" />
            <stop offset="100%" stopColor="#4b5563" />
          </linearGradient>

          {/* Vidro translúcido com reflexo */}
          <linearGradient id="glass-front" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#93c5fd" stopOpacity="0.28" />
            <stop offset="45%" stopColor="#bfdbfe" stopOpacity="0.18" />
            <stop offset="55%" stopColor="#e0f2fe" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#7dd3fc" stopOpacity="0.22" />
          </linearGradient>
          <linearGradient id="glass-side" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.55" />
            <stop offset="100%" stopColor="#0ea5e9" stopOpacity="0.7" />
          </linearGradient>
        </defs>

        {/* Sombra de contato (elipse projetada no chão) */}
        <ellipse
          cx={proj(W / 2, 0, D / 2).x + offset.x}
          cy={proj(W / 2, 0, D / 2).y + offset.y + 8}
          rx={SCALE * (W * 0.55)}
          ry={SCALE * (D * 0.6)}
          fill="#000"
          opacity={0.35}
        />

        {/* ===== Perfil INFERIOR (trilho) ===== */}
        {/* topo */}
        <polygon
          points={face([
            [0, P, 0],
            [W, P, 0],
            [W, P, D],
            [0, P, D],
          ])}
          fill="url(#alu-top)"
          stroke="#374151"
          strokeWidth={0.8}
        />
        {/* frente */}
        <polygon
          points={face([
            [0, 0, D],
            [W, 0, D],
            [W, P, D],
            [0, P, D],
          ])}
          fill="url(#alu-front)"
          stroke="#374151"
          strokeWidth={0.8}
        />
        {/* lateral direita */}
        <polygon
          points={face([
            [W, 0, 0],
            [W, P, 0],
            [W, P, D],
            [W, 0, D],
          ])}
          fill="url(#alu-side)"
          stroke="#374151"
          strokeWidth={0.8}
        />

        {/* ===== Perfil SUPERIOR (trilho) ===== */}
        <polygon
          points={face([
            [0, H, 0],
            [W, H, 0],
            [W, H, D],
            [0, H, D],
          ])}
          fill="url(#alu-top)"
          stroke="#374151"
          strokeWidth={0.8}
        />
        <polygon
          points={face([
            [0, H - P, D],
            [W, H - P, D],
            [W, H, D],
            [0, H, D],
          ])}
          fill="url(#alu-front)"
          stroke="#374151"
          strokeWidth={0.8}
        />
        <polygon
          points={face([
            [W, H - P, 0],
            [W, H, 0],
            [W, H, D],
            [W, H - P, D],
          ])}
          fill="url(#alu-side)"
          stroke="#374151"
          strokeWidth={0.8}
        />

        {/* ===== Vidro FOLHA 1 (esquerda, plano frontal em z = D*0.35) ===== */}
        {(() => {
          const z1 = D * 0.35;
          const x0 = P;
          const x1 = halfW + P * 0.5;
          const y0 = P;
          const y1 = H - P;
          return (
            <g>
              {/* face frontal */}
              <polygon
                points={face([
                  [x0, y0, z1],
                  [x1, y0, z1],
                  [x1, y1, z1],
                  [x0, y1, z1],
                ])}
                fill="url(#glass-front)"
                stroke="#93c5fd"
                strokeOpacity={0.6}
                strokeWidth={0.8}
              />
              {/* espessura lateral direita */}
              <polygon
                points={face([
                  [x1, y0, z1],
                  [x1, y0, z1 + G],
                  [x1, y1, z1 + G],
                  [x1, y1, z1],
                ])}
                fill="url(#glass-side)"
              />
              {/* topo espessura */}
              <polygon
                points={face([
                  [x0, y1, z1],
                  [x1, y1, z1],
                  [x1, y1, z1 + G],
                  [x0, y1, z1 + G],
                ])}
                fill="url(#glass-side)"
                opacity={0.7}
              />
              {/* reflexo diagonal */}
              <line
                x1={proj(x0 + (x1 - x0) * 0.2, y1 - (y1 - y0) * 0.05, z1).x + offset.x}
                y1={proj(x0 + (x1 - x0) * 0.2, y1 - (y1 - y0) * 0.05, z1).y + offset.y}
                x2={proj(x0 + (x1 - x0) * 0.55, y0 + (y1 - y0) * 0.15, z1).x + offset.x}
                y2={proj(x0 + (x1 - x0) * 0.55, y0 + (y1 - y0) * 0.15, z1).y + offset.y}
                stroke="#f0f9ff"
                strokeOpacity={0.55}
                strokeWidth={2}
              />
              {/* Puxador vertical folha 1 */}
              <line
                x1={proj(x1 - 0.02, y0 + (y1 - y0) * 0.35, z1).x + offset.x}
                y1={proj(x1 - 0.02, y0 + (y1 - y0) * 0.35, z1).y + offset.y}
                x2={proj(x1 - 0.02, y0 + (y1 - y0) * 0.65, z1).x + offset.x}
                y2={proj(x1 - 0.02, y0 + (y1 - y0) * 0.65, z1).y + offset.y}
                stroke="#e5e7eb"
                strokeWidth={3}
                strokeLinecap="round"
              />
            </g>
          );
        })()}

        {/* ===== Vidro FOLHA 2 (direita, plano frontal em z = D*0.65) ===== */}
        {(() => {
          const z2 = D * 0.65;
          const x0 = halfW - P * 0.5;
          const x1 = W - P;
          const y0 = P;
          const y1 = H - P;
          return (
            <g>
              <polygon
                points={face([
                  [x0, y0, z2],
                  [x1, y0, z2],
                  [x1, y1, z2],
                  [x0, y1, z2],
                ])}
                fill="url(#glass-front)"
                stroke="#93c5fd"
                strokeOpacity={0.6}
                strokeWidth={0.8}
              />
              <polygon
                points={face([
                  [x1, y0, z2],
                  [x1, y0, z2 + G],
                  [x1, y1, z2 + G],
                  [x1, y1, z2],
                ])}
                fill="url(#glass-side)"
              />
              <polygon
                points={face([
                  [x0, y1, z2],
                  [x1, y1, z2],
                  [x1, y1, z2 + G],
                  [x0, y1, z2 + G],
                ])}
                fill="url(#glass-side)"
                opacity={0.7}
              />
              <line
                x1={proj(x0 + (x1 - x0) * 0.25, y1 - (y1 - y0) * 0.05, z2).x + offset.x}
                y1={proj(x0 + (x1 - x0) * 0.25, y1 - (y1 - y0) * 0.05, z2).y + offset.y}
                x2={proj(x0 + (x1 - x0) * 0.6, y0 + (y1 - y0) * 0.15, z2).x + offset.x}
                y2={proj(x0 + (x1 - x0) * 0.6, y0 + (y1 - y0) * 0.15, z2).y + offset.y}
                stroke="#f0f9ff"
                strokeOpacity={0.55}
                strokeWidth={2}
              />
              <line
                x1={proj(x0 + 0.02, y0 + (y1 - y0) * 0.35, z2).x + offset.x}
                y1={proj(x0 + 0.02, y0 + (y1 - y0) * 0.35, z2).y + offset.y}
                x2={proj(x0 + 0.02, y0 + (y1 - y0) * 0.65, z2).x + offset.x}
                y2={proj(x0 + 0.02, y0 + (y1 - y0) * 0.65, z2).y + offset.y}
                stroke="#e5e7eb"
                strokeWidth={3}
                strokeLinecap="round"
              />
            </g>
          );
        })()}

        {/* ===== Perfis LATERAIS ===== */}
        {/* esquerda */}
        <polygon
          points={face([
            [0, 0, 0],
            [P, 0, 0],
            [P, H, 0],
            [0, H, 0],
          ])}
          fill="url(#alu-side)"
        />
        <polygon
          points={face([
            [0, 0, D],
            [P, 0, D],
            [P, H, D],
            [0, H, D],
          ])}
          fill="url(#alu-front)"
        />
        <polygon
          points={face([
            [P, 0, 0],
            [P, 0, D],
            [P, H, D],
            [P, H, 0],
          ])}
          fill="url(#alu-top)"
          opacity={0.85}
        />
        {/* direita */}
        <polygon
          points={face([
            [W - P, 0, 0],
            [W, 0, 0],
            [W, H, 0],
            [W - P, H, 0],
          ])}
          fill="url(#alu-side)"
        />
        <polygon
          points={face([
            [W - P, 0, D],
            [W, 0, D],
            [W, H, D],
            [W - P, H, D],
          ])}
          fill="url(#alu-front)"
        />
        <polygon
          points={face([
            [W, 0, 0],
            [W, 0, D],
            [W, H, D],
            [W, H, 0],
          ])}
          fill="url(#alu-top)"
          opacity={0.85}
        />

        {/* ===== Cotas ===== */}
        {showDims && (
          <>
            {cota([0, 0, D], [W, 0, D], `${W.toFixed(2).replace(".", ",")} m`, "right")}
            {cota([W, 0, D], [W, H, D], `${H.toFixed(2).replace(".", ",")} m`, "top")}
          </>
        )}
      </svg>
    </div>
  );
}
