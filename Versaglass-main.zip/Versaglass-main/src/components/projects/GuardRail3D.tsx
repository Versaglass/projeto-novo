import { Suspense, useEffect, useMemo, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { ContactShadows, OrbitControls, MeshReflectorMaterial } from "@react-three/drei";
import * as THREE from "three";

type Props = {
  /** Largura total em metros */
  widthM: number;
  /** Altura em metros (do piso ao topo do vidro) */
  heightM: number;
  /** Quantidade de módulos (painéis de vidro). Se omitido, é derivado da largura. */
  modules?: number;
  /** Espessura do vidro em mm (default 10) */
  glassMm?: number;
  /** Largura do perfil base em mm (default 60) */
  baseMm?: number;
  className?: string;
  showDims?: boolean;
  interactive?: boolean;
};

/**
 * Renderização WebGL fotorrealista de guarda-corpo em vidro temperado
 * com base de alumínio anodizado escovado. Geometria gerada dinamicamente
 * a partir das medidas (largura, altura, quantidade de módulos).
 */
export default function GuardRail3D({
  widthM,
  heightM,
  modules,
  glassMm = 10,
  baseMm = 60,
  className,
  showDims = true,
  interactive = true,
}: Props) {
  const W = Math.max(0.6, widthM);
  const H = Math.max(0.4, heightM);
  const N = Math.max(1, modules ?? Math.max(2, Math.round(W / 1.2)));
  const G = glassMm / 1000;
  const B = baseMm / 1000;

  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const camPos = useMemo<[number, number, number]>(() => {
    // ~35° isométrica
    const dist = Math.max(W, H) * 1.6 + 1.8;
    return [dist * 0.85, H * 0.75 + 0.6, dist * 0.85];
  }, [W, H]);

  return (
    <div
      className={className}
      style={{ position: "relative", width: "100%", height: "100%", background: "#e5e7eb" }}
    >
      {mounted && (
        <Canvas
          shadows
          dpr={[1, 2]}
          camera={{ position: camPos, fov: 32 }}
          gl={{
            antialias: true,
            toneMapping: THREE.ACESFilmicToneMapping,
            toneMappingExposure: 1.15,
          }}
        >
          {/* Fundo estúdio cinza médio para dar contraste ao vidro */}
          <color attach="background" args={["#b8c1cc"]} />

          {/* Iluminação de estúdio (sem HDR externo) */}
          <hemisphereLight args={["#ffffff", "#8a95a5", 0.7]} />
          <ambientLight intensity={0.25} />
          {/* Key light superior */}
          <directionalLight
            position={[4, 6, 3]}
            intensity={1.3}
            color="#ffffff"
            castShadow
            shadow-mapSize-width={2048}
            shadow-mapSize-height={2048}
            shadow-camera-left={-6}
            shadow-camera-right={6}
            shadow-camera-top={6}
            shadow-camera-bottom={-6}
            shadow-bias={-0.0002}
          />
          {/* Fill lateral */}
          <directionalLight position={[-5, 3, 2]} intensity={0.55} color="#dbeafe" />
          {/* Rim light traseiro */}
          <directionalLight position={[0, 4, -5]} intensity={0.7} color="#ffffff" />

          <Suspense fallback={null}>
            <Studio />
            <GuardRail W={W} H={H} N={N} G={G} B={B} />
            <ContactShadows
              position={[0, 0.002, 0]}
              opacity={0.5}
              blur={2.4}
              far={6}
              resolution={1024}
              color="#000"
            />
          </Suspense>

          {interactive && (
            <OrbitControls
              enablePan
              enableZoom
              enableRotate
              minDistance={1.5}
              maxDistance={12}
              minPolarAngle={Math.PI / 6}
              maxPolarAngle={Math.PI / 2 - 0.05}
              target={[0, H * 0.45, 0]}
            />
          )}
        </Canvas>
      )}

      {showDims && (
        <div
          style={{
            position: "absolute",
            top: 12,
            left: 12,
            display: "flex",
            gap: 8,
            pointerEvents: "none",
          }}
        >
          <span style={pill}>L {W.toFixed(2).replace(".", ",")} m</span>
          <span style={pill}>A {H.toFixed(2).replace(".", ",")} m</span>
          <span style={pill}>
            {N} {N === 1 ? "módulo" : "módulos"}
          </span>
        </div>
      )}
    </div>
  );
}

const pill: React.CSSProperties = {
  background: "rgba(17,24,39,0.85)",
  color: "#f9fafb",
  fontSize: 11,
  fontWeight: 600,
  padding: "4px 10px",
  borderRadius: 999,
  letterSpacing: 0.3,
  backdropFilter: "blur(6px)",
};

/* -------------------- Cena / Estúdio -------------------- */

function Studio() {
  return (
    <group>
      {/* Piso reflexivo (chão de estúdio claro) */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[40, 40]} />
        <MeshReflectorMaterial
          blur={[400, 100]}
          resolution={1024}
          mixBlur={1}
          mixStrength={25}
          roughness={0.85}
          depthScale={0.6}
          minDepthThreshold={0.4}
          maxDepthThreshold={1.2}
          color="#9aa4b0"
          metalness={0.15}
          mirror={0.3}
        />
      </mesh>
      {/* Fundo curvo (cyclorama) simulado por plano vertical distante */}
      <mesh position={[0, 6, -8]} receiveShadow>
        <planeGeometry args={[40, 20]} />
        <meshStandardMaterial color="#c9d1db" roughness={1} />
      </mesh>
    </group>
  );
}

/* -------------------- Guarda-corpo -------------------- */

function GuardRail({ W, H, N, G, B }: { W: number; H: number; N: number; G: number; B: number }) {
  // Materiais PBR
  const aluminum = useMemo(
    () =>
      new THREE.MeshPhysicalMaterial({
        color: "#c9ced6",
        metalness: 1.0,
        roughness: 0.32,
        clearcoat: 0.6,
        clearcoatRoughness: 0.25,
        envMapIntensity: 1.1,
      }),
    [],
  );

  const glass = useMemo(
    () =>
      new THREE.MeshPhysicalMaterial({
        color: "#eaf6ff",
        metalness: 0,
        roughness: 0.02,
        transmission: 0.97,
        thickness: G * 20,
        ior: 1.52,
        transparent: true,
        opacity: 1,
        attenuationColor: new THREE.Color("#bfe3ff"),
        attenuationDistance: 4,
        envMapIntensity: 1.2,
        clearcoat: 1,
        clearcoatRoughness: 0.02,
        side: THREE.DoubleSide,
      }),
    [G],
  );

  const glassEdge = useMemo(
    () =>
      new THREE.MeshPhysicalMaterial({
        color: "#7dd3fc",
        metalness: 0.1,
        roughness: 0.2,
        transmission: 0.5,
        transparent: true,
        opacity: 0.65,
      }),
    [],
  );

  // Dimensões dos módulos
  const gap = 0.006; // fresta entre painéis
  const moduleW = (W - gap * (N - 1)) / N;
  const glassH = H - B; // altura do vidro (base ocupa B)

  // Posiciona o guarda-corpo centralizado no eixo X e alinhado a Z=0
  const startX = -W / 2;

  return (
    <group position={[0, 0, 0]}>
      {/* Perfil de base contínuo em alumínio */}
      <mesh position={[0, B / 2, 0]} castShadow receiveShadow material={aluminum}>
        <boxGeometry args={[W + 0.02, B, 0.12]} />
      </mesh>
      {/* Sapata / rodapé decorativo (linha mais escura no meio) */}
      <mesh position={[0, B * 0.35, 0.061]} material={aluminum}>
        <boxGeometry args={[W + 0.021, 0.006, 0.001]} />
      </mesh>
      {/* Perfil de topo (corrimão fino opcional) */}
      <mesh position={[0, B + glassH + 0.012, 0]} castShadow receiveShadow material={aluminum}>
        <boxGeometry args={[W + 0.02, 0.024, 0.05]} />
      </mesh>

      {Array.from({ length: N }).map((_, i) => {
        const x = startX + moduleW / 2 + i * (moduleW + gap);
        return (
          <group key={i} position={[x, 0, 0]}>
            {/* Vidro temperado */}
            <mesh position={[0, B + glassH / 2, 0]} castShadow receiveShadow material={glass}>
              <boxGeometry args={[moduleW - 0.01, glassH - 0.01, G]} />
            </mesh>
            {/* Bordas lapidadas com leve tom azulado */}
            <mesh position={[0, B + glassH / 2, G / 2 + 0.0005]} material={glassEdge}>
              <boxGeometry args={[moduleW - 0.008, glassH - 0.008, 0.0006]} />
            </mesh>
            <mesh position={[0, B + glassH / 2, -G / 2 - 0.0005]} material={glassEdge}>
              <boxGeometry args={[moduleW - 0.008, glassH - 0.008, 0.0006]} />
            </mesh>
            {/* Fixadores / spider (2 pontos por painel na base) */}
            <mesh position={[-(moduleW / 2) * 0.55, B + 0.06, 0]} castShadow material={aluminum}>
              <cylinderGeometry args={[0.02, 0.02, 0.05, 24]} />
            </mesh>
            <mesh position={[(moduleW / 2) * 0.55, B + 0.06, 0]} castShadow material={aluminum}>
              <cylinderGeometry args={[0.02, 0.02, 0.05, 24]} />
            </mesh>
          </group>
        );
      })}

      {/* Postes / torres nas extremidades e entre módulos (se >2) */}
      {Array.from({ length: N + 1 }).map((_, i) => {
        const x = startX + i * (moduleW + gap) - (i > 0 && i < N ? gap / 2 : 0);
        return (
          <mesh
            key={`post-${i}`}
            position={[x, B + glassH / 2, 0]}
            castShadow
            receiveShadow
            material={aluminum}
          >
            <boxGeometry args={[0.03, glassH, 0.06]} />
          </mesh>
        );
      })}
    </group>
  );
}
