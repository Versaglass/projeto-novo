import { useMemo } from "react";
import * as THREE from "three";

/**
 * Materiais PBR compartilhados pelas cenas 3D.
 *
 * Vive em arquivo próprio (Revisão 53) porque é um HOOK, não um componente:
 * misturado ao `Studio3D.tsx` ele derrubava o Fast Refresh do arquivo inteiro
 * (react-refresh/only-export-components). Custo da separação: um import.
 */
export function useMaterials() {
  return useMemo(() => {
    const aluminum = new THREE.MeshPhysicalMaterial({
      color: "#c9ced6",
      metalness: 1.0,
      roughness: 0.32,
      clearcoat: 0.6,
      clearcoatRoughness: 0.25,
      envMapIntensity: 1.1,
    });
    const steelDark = new THREE.MeshPhysicalMaterial({
      color: "#2a2f36",
      metalness: 0.95,
      roughness: 0.45,
      clearcoat: 0.3,
      envMapIntensity: 0.9,
    });
    const glass = new THREE.MeshPhysicalMaterial({
      color: "#eaf6ff",
      metalness: 0,
      roughness: 0.02,
      transmission: 0.97,
      thickness: 0.2,
      ior: 1.52,
      transparent: true,
      opacity: 1,
      attenuationColor: new THREE.Color("#bfe3ff"),
      attenuationDistance: 4,
      envMapIntensity: 1.2,
      clearcoat: 1,
      clearcoatRoughness: 0.02,
      side: THREE.DoubleSide,
    });
    const glassEdge = new THREE.MeshPhysicalMaterial({
      color: "#7dd3fc",
      metalness: 0.1,
      roughness: 0.2,
      transmission: 0.5,
      transparent: true,
      opacity: 0.65,
    });
    const mirror = new THREE.MeshPhysicalMaterial({
      color: "#e2e8f0",
      metalness: 1,
      roughness: 0.03,
      envMapIntensity: 1.4,
    });
    const wood = new THREE.MeshPhysicalMaterial({
      color: "#8b6a4a",
      metalness: 0.05,
      roughness: 0.55,
      clearcoat: 0.4,
      clearcoatRoughness: 0.35,
    });
    const woodDark = new THREE.MeshPhysicalMaterial({
      color: "#3f2f22",
      metalness: 0.05,
      roughness: 0.5,
      clearcoat: 0.3,
    });
    const woodLight = new THREE.MeshPhysicalMaterial({
      color: "#d8c3a0",
      metalness: 0.05,
      roughness: 0.6,
      clearcoat: 0.25,
    });
    const stone = new THREE.MeshPhysicalMaterial({
      color: "#d6d3ce",
      metalness: 0.02,
      roughness: 0.35,
      clearcoat: 0.7,
      clearcoatRoughness: 0.15,
    });
    const stoneDark = new THREE.MeshPhysicalMaterial({
      color: "#3b3a38",
      metalness: 0.05,
      roughness: 0.3,
      clearcoat: 0.8,
      clearcoatRoughness: 0.1,
    });
    return {
      aluminum,
      steelDark,
      glass,
      glassEdge,
      mirror,
      wood,
      woodDark,
      woodLight,
      stone,
      stoneDark,
    };
  }, []);
}
