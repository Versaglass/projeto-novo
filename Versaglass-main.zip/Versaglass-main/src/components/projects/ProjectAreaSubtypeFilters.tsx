import {
  AREAS_OPERACIONAIS,
  AREAS_PROJETO,
  ROTULO_AREA,
  type AreaProjeto,
} from "@/lib/project-area";
import {
  ehSubtipoDaArea,
  ROTULO_SUBTIPO,
  subtiposDaArea,
  type SubtipoProjeto,
} from "@/lib/project-subtypes";
import { cn } from "@/lib/utils";

/** Filtro de área na listagem — "todos" = sem filtro de área. */
export type FiltroAreaProjeto = "todos" | AreaProjeto;

/** Filtro de subtipo — "todos" = todos os tipos da área escolhida. */
export type FiltroSubtipoProjeto = "todos" | SubtipoProjeto;

/** Superfície operacional: Todos + Vidraçaria + Esquadrias. */
export const FILTROS_AREA: ReadonlyArray<{ id: FiltroAreaProjeto; label: string }> = [
  { id: "todos", label: "Todos" },
  ...AREAS_OPERACIONAIS.map((a) => ({ id: a as FiltroAreaProjeto, label: ROTULO_AREA[a] })),
];

/** Admin / catálogo global — todas as áreas do enum histórico. */
export const FILTROS_AREA_TODAS: ReadonlyArray<{ id: FiltroAreaProjeto; label: string }> = [
  { id: "todos", label: "Todos" },
  ...AREAS_PROJETO.map((a) => ({ id: a as FiltroAreaProjeto, label: ROTULO_AREA[a] })),
];

type Props = {
  area: FiltroAreaProjeto;
  subtipo: FiltroSubtipoProjeto;
  onAreaChange: (area: FiltroAreaProjeto) => void;
  onSubtipoChange: (subtipo: FiltroSubtipoProjeto) => void;
  /** Contagens opcionais por chip (Biblioteca / Catálogo global). */
  contagens?: Partial<Record<FiltroAreaProjeto, number>>;
  /**
   * Contagens opcionais por tipo na área atual (select).
   * Chave `"todos"` = total na área; demais = subtipos.
   */
  contagensSubtipo?: Partial<Record<FiltroSubtipoProjeto, number>>;
  /**
   * Áreas nos chips. Padrão = superfície operacional (Vidraçaria + Esquadrias).
   * Passe `FILTROS_AREA_TODAS` (sem o "todos" — use a prop) via `filtrosArea`
   * para admin.
   */
  filtrosArea?: ReadonlyArray<{ id: FiltroAreaProjeto; label: string }>;
  disabled?: boolean;
  className?: string;
};

/**
 * Chips de área + select de tipo/subtipo — mesmo padrão da Biblioteca
 * (`/app/projetos`, pós-Rev. 177). Ao trocar a área, o chamador deve zerar
 * o subtipo para "todos" (este componente não guarda estado próprio).
 */
export function ProjectAreaSubtypeFilters({
  area,
  subtipo,
  onAreaChange,
  onSubtipoChange,
  contagens,
  contagensSubtipo,
  filtrosArea = FILTROS_AREA,
  disabled,
  className,
}: Props) {
  return (
    <div className={cn("flex flex-wrap items-center gap-2", className)}>
      {filtrosArea.map((f) => {
        const n = contagens?.[f.id];
        return (
          <button
            key={f.id}
            type="button"
            disabled={disabled}
            onClick={() => onAreaChange(f.id)}
            aria-pressed={area === f.id}
            className={cn(
              "rounded-lg px-3 py-2 text-xs font-semibold disabled:cursor-not-allowed disabled:opacity-50",
              area === f.id
                ? "bg-gold text-gold-foreground"
                : "border border-border text-muted-foreground hover:text-foreground",
            )}
          >
            {f.label}
            {n !== undefined && <span className="ml-1.5 opacity-70">{n}</span>}
          </button>
        );
      })}
      <select
        value={subtipo}
        onChange={(e) => {
          onSubtipoChange(
            area !== "todos" && ehSubtipoDaArea(area, e.target.value) ? e.target.value : "todos",
          );
        }}
        disabled={disabled || area === "todos"}
        title={
          area === "todos" ? "Escolha uma área para filtrar por tipo de projeto" : "Tipo de projeto"
        }
        className="rounded-lg border border-border bg-background px-3 py-2 text-xs font-semibold outline-none focus:ring-2 ring-ring disabled:cursor-not-allowed disabled:opacity-50"
      >
        <option value="todos">
          {area === "todos"
            ? "Tipo de projeto (escolha a área)"
            : contagensSubtipo?.todos !== undefined
              ? `Todos os tipos ${contagensSubtipo.todos}`
              : "Todos os tipos"}
        </option>
        {area !== "todos" &&
          subtiposDaArea(area).map((s) => {
            const n = contagensSubtipo?.[s];
            return (
              <option key={s} value={s}>
                {ROTULO_SUBTIPO[s]}
                {n !== undefined ? ` ${n}` : ""}
              </option>
            );
          })}
      </select>
    </div>
  );
}
