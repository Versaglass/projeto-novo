export type ProductKind =
  | "glass-box"
  | "glass-door"
  | "guard-rail"
  | "mirror"
  | "metal-gate"
  | "metal-grid"
  | "metal-hangar"
  | "metal-table"
  | "wood-cabinet"
  | "wood-panel"
  | "wood-closet"
  | "wood-vanity"
  | "stone-counter"
  | "stone-stair"
  | "stone-sink"
  | "stone-niche";

export function pickProductKind(input: {
  segment?: string;
  area?: string;
  id?: string;
}): ProductKind {
  const s = input.segment ?? "";
  const id = input.id ?? "";
  if (id.includes("guarda-corpo")) return "guard-rail";
  if (id.includes("box")) return "glass-box";
  if (id.includes("porta") && input.area === "vidracaria") return "glass-door";
  if (s === "guarda_corpo") return "guard-rail";
  if (s === "box") return "glass-box";
  if (s === "porta" || s === "porta_vidro" || s === "portas_vidro") return "glass-door";
  if (s === "espelho" || s === "espelhos") return "mirror";
  if (s === "janela" || s === "janela_vidro") return "glass-door";
  if (s === "portao") return "metal-gate";
  if (s === "grades" || s === "janela") return "metal-grid";
  if (s === "galpao") return "metal-hangar";
  if (s === "moveis_industriais") return "metal-table";
  if (s === "cozinha") return "wood-cabinet";
  if (s === "painel") return "wood-panel";
  if (s === "closet") return "wood-closet";
  if (s === "banheiro") return "wood-vanity";
  if (s === "bancadas") return "stone-counter";
  if (s === "escadas") return "stone-stair";
  if (s === "cubas") return "stone-sink";
  if (s === "nichos") return "stone-niche";
  if (input.area === "vidracaria") return "glass-door";
  // `serralheria` é o identificador atual (enum `public.project_area`);
  // `serralheria_aco` é o antigo e continua aceito porque esta função também
  // recebe `area` de desenhos exportados e de rascunhos locais.
  if (input.area === "serralheria" || input.area === "serralheria_aco") return "metal-grid";
  if (input.area === "marcenaria") return "wood-cabinet";
  if (input.area === "marmoraria") return "stone-counter";
  return "glass-door";
}
