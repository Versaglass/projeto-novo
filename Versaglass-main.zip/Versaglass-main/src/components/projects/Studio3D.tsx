import { Suspense, useEffect, useMemo, useState, type ReactNode } from "react";
import { Canvas } from "@react-three/fiber";
import { ContactShadows, OrbitControls, MeshReflectorMaterial } from "@react-three/drei";
import * as THREE from "three";

type Props = {
  widthM: number;
  heightM: number;
  depthM?: number;
  className?: string;
  interactive?: boolean;
  showDims?: boolean;
  extraPill?: string;
  /** Ambient background tone. */
  bg?: string;
  floor?: string;
  wall?: string;
  /** Vertical offset for camera target (fraction of H). */
  targetY?: number;
  children: ReactNode;
};

/**
 * Ambiente de estúdio fotorrealista compartilhado por todos os produtos.
 * Iluminação, câmera isométrica ~35° e materiais PBR uniformes garantem
 * que todas as visualizações tenham a mesma qualidade e ângulo.
 */
export default function Studio3D({
  widthM,
  heightM,
  depthM = 0.6,
  className,
  interactive = true,
  showDims = true,
  extraPill,
  bg = "#b8c1cc",
  floor = "#9aa4b0",
  wall = "#c9d1db",
  targetY = 0.45,
  children,
}: Props) {
  const W = Math.max(0.4, widthM);
  const H = Math.max(0.3, heightM);
  const D = Math.max(0.1, depthM);

  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const camPos = useMemo<[number, number, number]>(() => {
    const dist = Math.max(W, H, D) * 1.6 + 1.8;
    return [dist * 0.85, H * 0.75 + 0.6, dist * 0.85];
  }, [W, H, D]);

  return (
    <div
      className={className}
      style={{ position: "relative", width: "100%", height: "100%", background: bg }}
    >
      {mounted && (
        <Canvas
          shadows
          dpr={[1, 2]}
          camera={{ position: camPos, fov: 32 }}
          gl={{
            antialias: true,
            toneMapping: THREE.ACESFilmicToneMapping,
            toneMappingExposure: 1.15,
          }}
        >
          <color attach="background" args={[bg]} />
          <hemisphereLight args={["#ffffff", "#8a95a5", 0.7]} />
          <ambientLight intensity={0.25} />
          <directionalLight
            position={[4, 6, 3]}
            intensity={1.3}
            color="#ffffff"
            castShadow
            shadow-mapSize-width={2048}
            shadow-mapSize-height={2048}
            shadow-camera-left={-8}
            shadow-camera-right={8}
            shadow-camera-top={8}
            shadow-camera-bottom={-8}
            shadow-bias={-0.0002}
          />
          <directionalLight position={[-5, 3, 2]} intensity={0.55} color="#dbeafe" />
          <directionalLight position={[0, 4, -5]} intensity={0.7} color="#ffffff" />

          <Suspense fallback={null}>
            <Studio floor={floor} wall={wall} />
            {children}
            <ContactShadows
              position={[0, 0.002, 0]}
              opacity={0.5}
              blur={2.4}
              far={8}
              resolution={1024}
              color="#000"
            />
          </Suspense>

          {interactive && (
            <OrbitControls
              enablePan
              enableZoom
              enableRotate
              minDistance={1.2}
              maxDistance={16}
              minPolarAngle={Math.PI / 6}
              maxPolarAngle={Math.PI / 2 - 0.05}
              target={[0, H * targetY, 0]}
            />
          )}
        </Canvas>
      )}

      {showDims && (
        <div
          style={{
            position: "absolute",
            top: 12,
            left: 12,
            display: "flex",
            gap: 8,
            pointerEvents: "none",
            flexWrap: "wrap",
          }}
        >
          <span style={pill}>L {W.toFixed(2).replace(".", ",")} m</span>
          <span style={pill}>A {H.toFixed(2).replace(".", ",")} m</span>
          {extraPill && <span style={pill}>{extraPill}</span>}
        </div>
      )}
    </div>
  );
}

const pill: React.CSSProperties = {
  background: "rgba(17,24,39,0.85)",
  color: "#f9fafb",
  fontSize: 11,
  fontWeight: 600,
  padding: "4px 10px",
  borderRadius: 999,
  letterSpacing: 0.3,
  backdropFilter: "blur(6px)",
};

function Studio({ floor, wall }: { floor: string; wall: string }) {
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[40, 40]} />
        <MeshReflectorMaterial
          blur={[400, 100]}
          resolution={1024}
          mixBlur={1}
          mixStrength={25}
          roughness={0.85}
          depthScale={0.6}
          minDepthThreshold={0.4}
          maxDepthThreshold={1.2}
          color={floor}
          metalness={0.15}
          mirror={0.3}
        />
      </mesh>
      <mesh position={[0, 6, -8]} receiveShadow>
        <planeGeometry args={[40, 20]} />
        <meshStandardMaterial color={wall} roughness={1} />
      </mesh>
    </group>
  );
}
