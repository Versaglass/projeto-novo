import { Component, Suspense, lazy, type ReactNode } from "react";
import type { ProductKind } from "./product-kinds";

const Product3D = lazy(() => import("./Product3D"));

type Props = {
  kind: ProductKind;
  widthM: number;
  heightM: number;
  fallbackImage: string;
  alt?: string;
  className?: string;
};

class Boundary extends Component<
  { children: ReactNode; fallback: ReactNode },
  { hasError: boolean }
> {
  state = { hasError: false };
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch(err: unknown) {
    // eslint-disable-next-line no-console
    console.error("[ProjectViewer] 3D render failed, falling back to 2D:", err);
  }
  render() {
    if (this.state.hasError) return this.props.fallback;
    return this.props.children;
  }
}

/**
 * Renderiza a visualização 3D do projeto. Se o WebGL/Three falhar
 * (import, runtime ou contexto WebGL indisponível), cai automaticamente
 * para a imagem 2D existente do projeto. Nunca exibe área em branco.
 */
export function ProjectViewer({ kind, widthM, heightM, fallbackImage, alt, className }: Props) {
  const img = (
    <img
      src={fallbackImage}
      alt={alt ?? "Visualização do projeto"}
      loading="lazy"
      decoding="async"
      className={`h-full w-full object-cover ${className ?? ""}`}
    />
  );

  // Detect WebGL support once (SSR-safe).
  const canWebGL =
    typeof window !== "undefined" &&
    (() => {
      try {
        const c = document.createElement("canvas");
        return !!(c.getContext("webgl2") || c.getContext("webgl"));
      } catch {
        return false;
      }
    })();

  if (!canWebGL) return img;

  return (
    <Boundary fallback={img}>
      <Suspense fallback={img}>
        <Product3D kind={kind} widthM={widthM} heightM={heightM} className={className} />
      </Suspense>
    </Boundary>
  );
}

export default ProjectViewer;
