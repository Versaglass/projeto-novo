import Studio3D from "./Studio3D";
import { useMaterials } from "./use-materials";
import type { ProductKind } from "./product-kinds";

type Props = {
  kind: ProductKind;
  widthM: number;
  heightM: number;
  depthM?: number;
  modules?: number;
  className?: string;
  interactive?: boolean;
  showDims?: boolean;
};

const KIND_ENV: Record<ProductKind, { bg: string; floor: string; wall: string; target: number }> = {
  "glass-box": { bg: "#c5d0dc", floor: "#a7b0bc", wall: "#d4dbe4", target: 0.5 },
  "glass-door": { bg: "#c5d0dc", floor: "#a7b0bc", wall: "#d4dbe4", target: 0.5 },
  "guard-rail": { bg: "#b8c1cc", floor: "#9aa4b0", wall: "#c9d1db", target: 0.45 },
  mirror: { bg: "#c9c2b8", floor: "#a89f92", wall: "#d8d1c6", target: 0.5 },
  "metal-gate": { bg: "#b0b6bd", floor: "#8a8f96", wall: "#c2c8ce", target: 0.5 },
  "metal-grid": { bg: "#b0b6bd", floor: "#8a8f96", wall: "#c2c8ce", target: 0.5 },
  "metal-hangar": { bg: "#aab2ba", floor: "#7c8188", wall: "#b8c0c8", target: 0.4 },
  "metal-table": { bg: "#c0bcb5", floor: "#9a968f", wall: "#d0ccc5", target: 0.5 },
  "wood-cabinet": { bg: "#d1c8b8", floor: "#a89e8c", wall: "#dcd4c4", target: 0.5 },
  "wood-panel": { bg: "#c8bfae", floor: "#a09786", wall: "#d4cbba", target: 0.5 },
  "wood-closet": { bg: "#d1c8b8", floor: "#a89e8c", wall: "#dcd4c4", target: 0.5 },
  "wood-vanity": { bg: "#c9d0d1", floor: "#9ea6a8", wall: "#d5dcde", target: 0.4 },
  "stone-counter": { bg: "#cfcdc8", floor: "#a3a19c", wall: "#dcdad5", target: 0.4 },
  "stone-stair": { bg: "#c8c6c0", floor: "#9c9a94", wall: "#d5d3cd", target: 0.4 },
  "stone-sink": { bg: "#cfcdc8", floor: "#a3a19c", wall: "#dcdad5", target: 0.4 },
  "stone-niche": { bg: "#c9d0d1", floor: "#9ea6a8", wall: "#d5dcde", target: 0.5 },
};

/**
 * Renderizador fotorrealista único para todo o catálogo.
 * Reaproveita estúdio, iluminação e materiais PBR — muda apenas a
 * geometria conforme o tipo de produto. Preserva sempre as medidas.
 */
export default function Product3D({
  kind,
  widthM,
  heightM,
  depthM,
  modules,
  className,
  interactive = true,
  showDims = true,
}: Props) {
  const env = KIND_ENV[kind];
  return (
    <Studio3D
      widthM={widthM}
      heightM={heightM}
      depthM={depthM ?? defaultDepth(kind)}
      className={className}
      interactive={interactive}
      showDims={showDims}
      bg={env.bg}
      floor={env.floor}
      wall={env.wall}
      targetY={env.target}
      extraPill={extraPillFor(kind, widthM, modules)}
    >
      <Geometry
        kind={kind}
        W={Math.max(0.4, widthM)}
        H={Math.max(0.3, heightM)}
        D={Math.max(0.05, depthM ?? defaultDepth(kind))}
        modules={modules}
      />
    </Studio3D>
  );
}

function defaultDepth(kind: ProductKind): number {
  switch (kind) {
    case "glass-box":
      return 0.85;
    case "glass-door":
      return 0.05;
    case "guard-rail":
      return 0.06;
    case "mirror":
      return 0.03;
    case "metal-gate":
      return 0.08;
    case "metal-grid":
      return 0.06;
    case "metal-hangar":
      return 4;
    case "metal-table":
      return 0.7;
    case "wood-cabinet":
      return 0.35;
    case "wood-panel":
      return 0.06;
    case "wood-closet":
      return 0.6;
    case "wood-vanity":
      return 0.5;
    case "stone-counter":
      return 0.6;
    case "stone-stair":
      return 0.3;
    case "stone-sink":
      return 0.55;
    case "stone-niche":
      return 0.15;
  }
}

function extraPillFor(kind: ProductKind, w: number, modules?: number): string | undefined {
  if (kind === "guard-rail") {
    const n = modules ?? Math.max(2, Math.round(w / 1.2));
    return `${n} ${n === 1 ? "módulo" : "módulos"}`;
  }
  if (kind === "glass-box") return "2 folhas";
  return undefined;
}

/* ==================== GEOMETRIAS ==================== */

function Geometry({
  kind,
  W,
  H,
  D,
  modules,
}: {
  kind: ProductKind;
  W: number;
  H: number;
  D: number;
  modules?: number;
}) {
  switch (kind) {
    case "glass-box":
      return <GlassBox W={W} H={H} D={D} />;
    case "glass-door":
      return <GlassDoor W={W} H={H} />;
    case "guard-rail":
      return <GuardRail W={W} H={H} N={modules ?? Math.max(2, Math.round(W / 1.2))} />;
    case "mirror":
      return <MirrorPanel W={W} H={H} />;
    case "metal-gate":
      return <MetalGate W={W} H={H} />;
    case "metal-grid":
      return <MetalGrid W={W} H={H} />;
    case "metal-hangar":
      return <MetalHangar W={W} H={H} D={D} />;
    case "metal-table":
      return <MetalTable W={W} H={H} D={D} />;
    case "wood-cabinet":
      return <WoodCabinet W={W} H={H} D={D} />;
    case "wood-panel":
      return <WoodPanel W={W} H={H} />;
    case "wood-closet":
      return <WoodCloset W={W} H={H} D={D} />;
    case "wood-vanity":
      return <WoodVanity W={W} H={H} D={D} />;
    case "stone-counter":
      return <StoneCounter W={W} H={H} D={D} />;
    case "stone-stair":
      return <StoneStair W={W} H={H} D={D} />;
    case "stone-sink":
      return <StoneSink W={W} H={H} D={D} />;
    case "stone-niche":
      return <StoneNiche W={W} H={H} D={D} />;
  }
}

/* ---------- Vidraçaria ---------- */

function GuardRail({ W, H, N }: { W: number; H: number; N: number }) {
  const m = useMaterials();
  const G = 0.01,
    B = 0.06;
  const gap = 0.006;
  const moduleW = (W - gap * (N - 1)) / N;
  const glassH = H - B;
  const startX = -W / 2;
  return (
    <group>
      <mesh position={[0, B / 2, 0]} castShadow receiveShadow material={m.aluminum}>
        <boxGeometry args={[W + 0.02, B, 0.12]} />
      </mesh>
      <mesh position={[0, B + glassH + 0.012, 0]} castShadow receiveShadow material={m.aluminum}>
        <boxGeometry args={[W + 0.02, 0.024, 0.05]} />
      </mesh>
      {Array.from({ length: N }).map((_, i) => {
        const x = startX + moduleW / 2 + i * (moduleW + gap);
        return (
          <group key={i} position={[x, 0, 0]}>
            <mesh position={[0, B + glassH / 2, 0]} castShadow receiveShadow material={m.glass}>
              <boxGeometry args={[moduleW - 0.01, glassH - 0.01, G]} />
            </mesh>
            <mesh position={[0, B + glassH / 2, G / 2 + 0.0005]} material={m.glassEdge}>
              <boxGeometry args={[moduleW - 0.008, glassH - 0.008, 0.0006]} />
            </mesh>
          </group>
        );
      })}
      {Array.from({ length: N + 1 }).map((_, i) => {
        const x = startX + i * (moduleW + gap);
        return (
          <mesh key={`p-${i}`} position={[x, B + glassH / 2, 0]} castShadow material={m.aluminum}>
            <boxGeometry args={[0.03, glassH, 0.06]} />
          </mesh>
        );
      })}
    </group>
  );
}

function GlassBox({ W, H, D }: { W: number; H: number; D: number }) {
  const m = useMaterials();
  const G = 0.008;
  const trackH = 0.04;
  const glassH = H - trackH * 2;
  const leafW = W / 2;
  return (
    <group>
      {/* Trilhos superior e inferior */}
      <mesh position={[0, trackH / 2, 0]} castShadow receiveShadow material={m.aluminum}>
        <boxGeometry args={[W, trackH, D + 0.04]} />
      </mesh>
      <mesh position={[0, H - trackH / 2, 0]} castShadow receiveShadow material={m.aluminum}>
        <boxGeometry args={[W, trackH, D + 0.04]} />
      </mesh>
      {/* Perfis laterais */}
      <mesh position={[-W / 2, H / 2, 0]} material={m.aluminum}>
        <boxGeometry args={[0.03, H, D + 0.02]} />
      </mesh>
      <mesh position={[W / 2, H / 2, 0]} material={m.aluminum}>
        <boxGeometry args={[0.03, H, D + 0.02]} />
      </mesh>
      {/* Folha traseira */}
      <mesh
        position={[-leafW / 2 + 0.01, trackH + glassH / 2, -D / 4]}
        castShadow
        material={m.glass}
      >
        <boxGeometry args={[leafW - 0.02, glassH, G]} />
      </mesh>
      {/* Folha frontal (deslocada) */}
      <mesh position={[leafW / 2 - 0.01, trackH + glassH / 2, D / 4]} castShadow material={m.glass}>
        <boxGeometry args={[leafW - 0.02, glassH, G]} />
      </mesh>
      {/* Puxadores */}
      <mesh position={[leafW / 2 - 0.12, trackH + glassH / 2, D / 4 + G]} material={m.aluminum}>
        <boxGeometry args={[0.02, 0.18, 0.02]} />
      </mesh>
      <mesh position={[-leafW / 2 + 0.12, trackH + glassH / 2, -D / 4 - G]} material={m.aluminum}>
        <boxGeometry args={[0.02, 0.18, 0.02]} />
      </mesh>
    </group>
  );
}

function GlassDoor({ W, H }: { W: number; H: number }) {
  const m = useMaterials();
  return (
    <group>
      {/* Marco superior/lateral */}
      <mesh position={[0, H + 0.02, 0]} material={m.aluminum}>
        <boxGeometry args={[W + 0.08, 0.04, 0.08]} />
      </mesh>
      <mesh position={[-W / 2 - 0.02, H / 2, 0]} material={m.aluminum}>
        <boxGeometry args={[0.04, H, 0.08]} />
      </mesh>
      <mesh position={[W / 2 + 0.02, H / 2, 0]} material={m.aluminum}>
        <boxGeometry args={[0.04, H, 0.08]} />
      </mesh>
      {/* Folha de vidro pivotante */}
      <mesh position={[0, H / 2, 0]} castShadow material={m.glass}>
        <boxGeometry args={[W - 0.02, H - 0.02, 0.01]} />
      </mesh>
      {/* Puxador vertical */}
      <mesh position={[W / 2 - 0.1, H / 2, 0.03]} material={m.aluminum}>
        <boxGeometry args={[0.025, H * 0.4, 0.025]} />
      </mesh>
      {/* Mola de piso */}
      <mesh position={[0, 0.01, 0]} material={m.aluminum}>
        <boxGeometry args={[0.15, 0.02, 0.1]} />
      </mesh>
    </group>
  );
}

function MirrorPanel({ W, H }: { W: number; H: number }) {
  const m = useMaterials();
  return (
    <group>
      {/* Moldura */}
      <mesh position={[0, H / 2, -0.005]} material={m.aluminum}>
        <boxGeometry args={[W + 0.04, H + 0.04, 0.02]} />
      </mesh>
      {/* Espelho */}
      <mesh position={[0, H / 2, 0.008]} material={m.mirror}>
        <boxGeometry args={[W, H, 0.01]} />
      </mesh>
      {/* LED backlight */}
      <mesh position={[0, H / 2, -0.02]}>
        <planeGeometry args={[W + 0.12, H + 0.12]} />
        <meshStandardMaterial emissive="#fff8e0" emissiveIntensity={0.6} color="#fff8e0" />
      </mesh>
    </group>
  );
}

/* ---------- Serralheria ---------- */

function MetalGate({ W, H }: { W: number; H: number }) {
  const m = useMaterials();
  const bars = Math.max(6, Math.round(W * 6));
  const barGap = W / bars;
  return (
    <group>
      {/* Quadro */}
      <mesh position={[0, H / 2, 0]} material={m.steelDark}>
        <boxGeometry args={[W, 0.06, 0.06]} />
      </mesh>
      <mesh position={[0, H - 0.03, 0]} material={m.steelDark}>
        <boxGeometry args={[W, 0.06, 0.06]} />
      </mesh>
      <mesh position={[0, 0.03, 0]} material={m.steelDark}>
        <boxGeometry args={[W, 0.06, 0.06]} />
      </mesh>
      <mesh position={[-W / 2, H / 2, 0]} material={m.steelDark}>
        <boxGeometry args={[0.06, H, 0.06]} />
      </mesh>
      <mesh position={[W / 2, H / 2, 0]} material={m.steelDark}>
        <boxGeometry args={[0.06, H, 0.06]} />
      </mesh>
      {/* Barras verticais */}
      {Array.from({ length: bars - 1 }).map((_, i) => (
        <mesh key={i} position={[-W / 2 + (i + 1) * barGap, H / 2, 0]} material={m.steelDark}>
          <boxGeometry args={[0.02, H - 0.1, 0.02]} />
        </mesh>
      ))}
      {/* Diagonais */}
      <mesh position={[0, H / 2, 0]} rotation={[0, 0, Math.atan2(H, W)]} material={m.steelDark}>
        <boxGeometry args={[Math.sqrt(W * W + H * H) - 0.1, 0.03, 0.03]} />
      </mesh>
    </group>
  );
}

function MetalGrid({ W, H }: { W: number; H: number }) {
  const m = useMaterials();
  const bars = Math.max(5, Math.round(W * 5));
  return (
    <group>
      {/* Marco */}
      {[0.02, H - 0.02].map((y, i) => (
        <mesh key={`h${i}`} position={[0, y, 0]} material={m.steelDark}>
          <boxGeometry args={[W, 0.04, 0.04]} />
        </mesh>
      ))}
      {[-W / 2, W / 2].map((x, i) => (
        <mesh key={`v${i}`} position={[x, H / 2, 0]} material={m.steelDark}>
          <boxGeometry args={[0.04, H, 0.04]} />
        </mesh>
      ))}
      {Array.from({ length: bars - 1 }).map((_, i) => (
        <mesh key={i} position={[-W / 2 + ((i + 1) * W) / bars, H / 2, 0]} material={m.steelDark}>
          <boxGeometry args={[0.02, H - 0.08, 0.02]} />
        </mesh>
      ))}
    </group>
  );
}

function MetalHangar({ W, H, D }: { W: number; H: number; D: number }) {
  const m = useMaterials();
  return (
    <group>
      {/* Pilares */}
      {[
        [-W / 2, -D / 2],
        [W / 2, -D / 2],
        [-W / 2, D / 2],
        [W / 2, D / 2],
      ].map(([x, z], i) => (
        <mesh key={i} position={[x, H / 2, z]} material={m.steelDark} castShadow>
          <boxGeometry args={[0.15, H, 0.15]} />
        </mesh>
      ))}
      {/* Tesouras (triangulos) */}
      {[-D / 2, D / 2].map((z, i) => (
        <group key={i} position={[0, H, z]}>
          <mesh
            rotation={[0, 0, Math.atan2(H * 0.4, W / 2)]}
            position={[-W / 4, H * 0.2, 0]}
            material={m.steelDark}
          >
            <boxGeometry args={[Math.sqrt((W / 2) ** 2 + (H * 0.4) ** 2), 0.08, 0.08]} />
          </mesh>
          <mesh
            rotation={[0, 0, -Math.atan2(H * 0.4, W / 2)]}
            position={[W / 4, H * 0.2, 0]}
            material={m.steelDark}
          >
            <boxGeometry args={[Math.sqrt((W / 2) ** 2 + (H * 0.4) ** 2), 0.08, 0.08]} />
          </mesh>
          <mesh position={[0, 0, 0]} material={m.steelDark}>
            <boxGeometry args={[W, 0.08, 0.08]} />
          </mesh>
        </group>
      ))}
      {/* Cobertura (2 planos) */}
      <mesh
        position={[-W / 4, H + H * 0.2, 0]}
        rotation={[0, 0, Math.atan2(H * 0.4, W / 2)]}
        castShadow
        material={m.aluminum}
      >
        <boxGeometry args={[Math.sqrt((W / 2) ** 2 + (H * 0.4) ** 2), 0.02, D + 0.2]} />
      </mesh>
      <mesh
        position={[W / 4, H + H * 0.2, 0]}
        rotation={[0, 0, -Math.atan2(H * 0.4, W / 2)]}
        castShadow
        material={m.aluminum}
      >
        <boxGeometry args={[Math.sqrt((W / 2) ** 2 + (H * 0.4) ** 2), 0.02, D + 0.2]} />
      </mesh>
    </group>
  );
}

function MetalTable({ W, H, D }: { W: number; H: number; D: number }) {
  const m = useMaterials();
  const legH = H - 0.04;
  return (
    <group>
      {/* Tampo */}
      <mesh position={[0, H - 0.02, 0]} castShadow material={m.woodDark}>
        <boxGeometry args={[W, 0.04, D]} />
      </mesh>
      {/* 4 pernas metalon */}
      {[
        [-W / 2 + 0.05, -D / 2 + 0.05],
        [W / 2 - 0.05, -D / 2 + 0.05],
        [-W / 2 + 0.05, D / 2 - 0.05],
        [W / 2 - 0.05, D / 2 - 0.05],
      ].map(([x, z], i) => (
        <mesh key={i} position={[x, legH / 2, z]} castShadow material={m.steelDark}>
          <boxGeometry args={[0.04, legH, 0.04]} />
        </mesh>
      ))}
      {/* Travessas */}
      <mesh position={[0, 0.1, -D / 2 + 0.05]} material={m.steelDark}>
        <boxGeometry args={[W - 0.1, 0.04, 0.04]} />
      </mesh>
      <mesh position={[0, 0.1, D / 2 - 0.05]} material={m.steelDark}>
        <boxGeometry args={[W - 0.1, 0.04, 0.04]} />
      </mesh>
    </group>
  );
}

/* ---------- Marcenaria ---------- */

function WoodCabinet({ W, H, D }: { W: number; H: number; D: number }) {
  const m = useMaterials();
  const doors = Math.max(2, Math.round(W / 0.5));
  const doorW = W / doors;
  return (
    <group>
      {/* Caixa */}
      <mesh position={[0, H / 2, -D / 2 + 0.01]} castShadow material={m.wood}>
        <boxGeometry args={[W, H, 0.02]} />
      </mesh>
      <mesh position={[0, H, 0]} material={m.wood}>
        <boxGeometry args={[W, 0.02, D]} />
      </mesh>
      <mesh position={[0, 0, 0]} material={m.wood}>
        <boxGeometry args={[W, 0.02, D]} />
      </mesh>
      <mesh position={[-W / 2, H / 2, 0]} material={m.wood}>
        <boxGeometry args={[0.02, H, D]} />
      </mesh>
      <mesh position={[W / 2, H / 2, 0]} material={m.wood}>
        <boxGeometry args={[0.02, H, D]} />
      </mesh>
      {/* Portas */}
      {Array.from({ length: doors }).map((_, i) => {
        const x = -W / 2 + doorW * (i + 0.5);
        return (
          <group key={i}>
            <mesh position={[x, H / 2, D / 2 - 0.005]} castShadow material={m.woodLight}>
              <boxGeometry args={[doorW - 0.01, H - 0.02, 0.02]} />
            </mesh>
            <mesh position={[x + doorW / 2 - 0.05, H / 2, D / 2 + 0.015]} material={m.aluminum}>
              <boxGeometry args={[0.015, 0.12, 0.015]} />
            </mesh>
          </group>
        );
      })}
    </group>
  );
}

function WoodPanel({ W, H }: { W: number; H: number }) {
  const m = useMaterials();
  const ribs = Math.max(12, Math.round(W * 12));
  const ribW = W / ribs;
  return (
    <group>
      <mesh position={[0, H / 2, -0.02]} castShadow material={m.woodDark}>
        <boxGeometry args={[W, H, 0.03]} />
      </mesh>
      {Array.from({ length: ribs }).map((_, i) => {
        const x = -W / 2 + ribW * (i + 0.5);
        return (
          <mesh key={i} position={[x, H / 2, 0.005]} material={m.wood}>
            <boxGeometry args={[ribW * 0.7, H - 0.05, 0.03]} />
          </mesh>
        );
      })}
      {/* TV mock */}
      <mesh position={[0, H * 0.55, 0.025]}>
        <boxGeometry args={[W * 0.5, H * 0.32, 0.02]} />
        <meshStandardMaterial color="#0a0a0a" roughness={0.3} />
      </mesh>
    </group>
  );
}

function WoodCloset({ W, H, D }: { W: number; H: number; D: number }) {
  const m = useMaterials();
  const cols = Math.max(3, Math.round(W / 0.7));
  const colW = W / cols;
  return (
    <group>
      {/* Caixa */}
      <mesh position={[0, H / 2, -D / 2 + 0.01]} castShadow material={m.wood}>
        <boxGeometry args={[W, H, 0.02]} />
      </mesh>
      {/* Divisórias verticais */}
      {Array.from({ length: cols + 1 }).map((_, i) => (
        <mesh key={i} position={[-W / 2 + colW * i, H / 2, 0]} material={m.wood}>
          <boxGeometry args={[0.02, H, D]} />
        </mesh>
      ))}
      {/* Gavetas inferiores + cabideiros */}
      {Array.from({ length: cols }).map((_, i) => {
        const x = -W / 2 + colW * (i + 0.5);
        return (
          <group key={i}>
            {/* 2 gavetas */}
            <mesh position={[x, H * 0.15, D / 2 - 0.01]} castShadow material={m.woodLight}>
              <boxGeometry args={[colW - 0.03, H * 0.12, 0.02]} />
            </mesh>
            <mesh position={[x, H * 0.28, D / 2 - 0.01]} castShadow material={m.woodLight}>
              <boxGeometry args={[colW - 0.03, H * 0.12, 0.02]} />
            </mesh>
            {/* Cabideiro */}
            <mesh position={[x, H * 0.75, 0]} rotation={[0, 0, Math.PI / 2]} material={m.aluminum}>
              <cylinderGeometry args={[0.01, 0.01, colW - 0.05, 16]} />
            </mesh>
          </group>
        );
      })}
    </group>
  );
}

function WoodVanity({ W, H, D }: { W: number; H: number; D: number }) {
  const m = useMaterials();
  return (
    <group>
      {/* Corpo */}
      <mesh position={[0, H / 2, 0]} castShadow material={m.wood}>
        <boxGeometry args={[W, H, D]} />
      </mesh>
      {/* Portas */}
      <mesh position={[-W / 4, H / 2, D / 2 + 0.005]} castShadow material={m.woodLight}>
        <boxGeometry args={[W / 2 - 0.02, H - 0.04, 0.02]} />
      </mesh>
      <mesh position={[W / 4, H / 2, D / 2 + 0.005]} castShadow material={m.woodLight}>
        <boxGeometry args={[W / 2 - 0.02, H - 0.04, 0.02]} />
      </mesh>
      {/* Cuba de apoio */}
      <mesh position={[0, H + 0.05, 0]} castShadow material={m.stone}>
        <cylinderGeometry args={[Math.min(W, D) * 0.3, Math.min(W, D) * 0.28, 0.12, 32]} />
      </mesh>
      {/* Torneira */}
      <mesh position={[0, H + 0.2, -D / 2 + 0.05]} material={m.aluminum}>
        <cylinderGeometry args={[0.015, 0.015, 0.3, 16]} />
      </mesh>
    </group>
  );
}

/* ---------- Marmoraria ---------- */

function StoneCounter({ W, H, D }: { W: number; H: number; D: number }) {
  const m = useMaterials();
  const topThick = 0.04;
  return (
    <group>
      {/* Base marcenaria */}
      <mesh position={[0, H / 2 - topThick / 2, 0]} castShadow material={m.woodLight}>
        <boxGeometry args={[W, H - topThick, D]} />
      </mesh>
      {/* Tampo pedra */}
      <mesh position={[0, H - topThick / 2, 0]} castShadow material={m.stone}>
        <boxGeometry args={[W + 0.04, topThick, D + 0.04]} />
      </mesh>
      {/* Cuba embutida */}
      <mesh position={[W * 0.15, H, 0]} material={m.stoneDark}>
        <boxGeometry args={[W * 0.35, 0.005, D * 0.55]} />
      </mesh>
      {/* Torneira */}
      <mesh position={[W * 0.15, H + 0.18, -D * 0.3]} material={m.aluminum}>
        <cylinderGeometry args={[0.015, 0.015, 0.35, 16]} />
      </mesh>
    </group>
  );
}

function StoneStair({ W, H, D }: { W: number; H: number; D: number }) {
  const m = useMaterials();
  const steps = Math.max(4, Math.round(H / 0.18));
  const stepH = H / steps;
  const stepD = D;
  return (
    <group>
      {Array.from({ length: steps }).map((_, i) => (
        <group key={i}>
          {/* Piso (horizontal) */}
          <mesh
            position={[0, stepH * (i + 1) - 0.015, -D * i]}
            castShadow
            receiveShadow
            material={m.stone}
          >
            <boxGeometry args={[W, 0.03, stepD + 0.02]} />
          </mesh>
          {/* Espelho (vertical) */}
          <mesh
            position={[0, stepH * (i + 0.5), -D * i + stepD / 2]}
            castShadow
            material={m.stoneDark}
          >
            <boxGeometry args={[W, stepH, 0.02]} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function StoneSink({ W, H, D }: { W: number; H: number; D: number }) {
  const m = useMaterials();
  return (
    <group>
      {/* Corpo esculpido */}
      <mesh position={[0, H / 2, 0]} castShadow material={m.stone}>
        <boxGeometry args={[W, H, D]} />
      </mesh>
      {/* Interior escavado */}
      <mesh position={[0, H - 0.04, 0]} material={m.stoneDark}>
        <boxGeometry args={[W - 0.1, 0.08, D - 0.1]} />
      </mesh>
      {/* Saia */}
      <mesh position={[0, H * 0.05, D / 2 + 0.005]} material={m.stone}>
        <boxGeometry args={[W, H * 0.1, 0.02]} />
      </mesh>
      {/* Torneira parede */}
      <mesh position={[0, H + 0.25, -D / 2]} material={m.aluminum}>
        <cylinderGeometry args={[0.015, 0.015, 0.4, 16]} />
      </mesh>
    </group>
  );
}

function StoneNiche({ W, H, D }: { W: number; H: number; D: number }) {
  const m = useMaterials();
  return (
    <group>
      {/* Parede de fundo */}
      <mesh position={[0, H / 2, -D / 2]} receiveShadow material={m.stone}>
        <boxGeometry args={[W + 0.4, H + 0.4, 0.02]} />
      </mesh>
      {/* Nicho embutido (fundo) */}
      <mesh position={[0, H / 2, -D / 2 + 0.011]} material={m.stoneDark}>
        <boxGeometry args={[W, H, 0.01]} />
      </mesh>
      {/* Prateleiras */}
      <mesh position={[0, H * 0.35, -D / 2 + D / 2]} castShadow material={m.stone}>
        <boxGeometry args={[W - 0.01, 0.02, D - 0.02]} />
      </mesh>
      <mesh position={[0, H * 0.7, -D / 2 + D / 2]} castShadow material={m.stone}>
        <boxGeometry args={[W - 0.01, 0.02, D - 0.02]} />
      </mesh>
      {/* Bordas */}
      {[
        [-W / 2, 0],
        [W / 2, 0],
      ].map(([x], i) => (
        <mesh key={i} position={[x, H / 2, 0]} material={m.stone}>
          <boxGeometry args={[0.02, H, D]} />
        </mesh>
      ))}
      <mesh position={[0, H, 0]} material={m.stone}>
        <boxGeometry args={[W, 0.02, D]} />
      </mesh>
      <mesh position={[0, 0, 0]} material={m.stone}>
        <boxGeometry args={[W, 0.02, D]} />
      </mesh>
    </group>
  );
}
