import { useMemo, useState, type ChangeEvent, type FormEvent, type ReactNode } from "react";
import { Package, Plus, X } from "lucide-react";
import { toast } from "sonner";
import { StorageImage } from "@/components/StorageImage";
import {
  inventoryItemFormSchema,
  type InventoryItemDraft,
  type InventoryItemForm,
} from "@/components/inventory/inventory-item-form";
import { useCompany } from "@/contexts/company-context";
import { numeroParaTexto, validaCamposNumericos } from "@/lib/numero-campo";
import {
  deleteInventoryImageIfOwnedByCompany,
  inventoryErrorMessage,
  INVENTORY_CATEGORIES,
  INVENTORY_UNITS,
  inventoryCategoriesInUiAreas,
  uploadInventoryImage,
  type InventoryCategoria,
  type InventoryItem,
  type InventoryUnidade,
} from "@/hooks/use-inventory";
import { useActiveSupplierOptions } from "@/hooks/use-suppliers";

export function InventoryItemDialog({
  initial,
  draft,
  onClose,
  onSubmit,
  loading,
  dialogTitle,
  contextBanner,
  lockedCategoria,
}: {
  initial: InventoryItem | null;
  draft?: InventoryItemDraft | null;
  onClose: () => void;
  onSubmit: (v: InventoryItemForm) => void;
  loading: boolean;
  /** Título customizado (ex.: adoção do catálogo). */
  dialogTitle?: string;
  /** Contexto de proveniência acima do formulário (somente UI). */
  contextBanner?: ReactNode;
  /** Quando definido, a categoria fica fixa (visões especializadas). */
  lockedCategoria?: InventoryCategoria;
}) {
  const { activeCompany } = useCompany();
  const companyId = activeCompany?.companyId ?? null;
  /** Criação (`initial` null) vs edição de item persistido — campos históricos só na edição. */
  const isEdit = initial != null;
  const { data: supplierOptions = [] } = useActiveSupplierOptions();
  const seed = initial ?? draft ?? null;
  /** Catálogo global sem categoria/unidade: exige escolha explícita (sem fallback). */
  const needsCategoryChoice = Boolean(!isEdit && draft && !draft.categoria && !lockedCategoria);
  const needsUnitChoice = Boolean(!isEdit && draft && !draft.unidade);

  const [form, setForm] = useState<
    Omit<
      InventoryItemForm,
      "quantidade" | "estoque_minimo" | "custo_unit" | "preco_venda" | "categoria" | "unidade"
    > & {
      categoria: InventoryCategoria | "";
      unidade: InventoryUnidade | "";
    }
  >({
    nome: seed?.nome ?? "",
    categoria: lockedCategoria ?? seed?.categoria ?? (needsCategoryChoice ? "" : "aluminio"),
    unidade: seed?.unidade ?? (needsUnitChoice ? "" : "un"),
    descricao: seed?.descricao ?? "",
    sku: initial?.sku ?? draft?.sku ?? "",
    ncm: initial?.ncm ?? draft?.ncm ?? "",
    fornecedor: seed?.fornecedor ?? "",
    supplier_id: initial?.supplier_id ?? "",
    localizacao: initial?.localizacao ?? "",
    observacoes: initial?.observacoes ?? "",
    imagem_url: initial?.imagem_url ?? draft?.imagem_url ?? "",
    ativo: initial?.ativo ?? true,
  });
  const [num, setNum] = useState({
    quantidade: numeroParaTexto(initial?.quantidade ?? (draft ? 0 : undefined)),
    estoque_minimo: numeroParaTexto(initial?.estoque_minimo ?? (draft ? 0 : undefined)),
    custo_unit: numeroParaTexto(initial?.custo_unit ?? (draft ? 0 : undefined)),
    preco_venda: numeroParaTexto(initial?.preco_venda ?? (draft ? 0 : undefined)),
  });
  const [uploading, setUploading] = useState(false);
  // Foto pré-enviada pelo catálogo (ou upload manual) — cancelar remove do bucket.
  const [pendingImage, setPendingImage] = useState<string | null>(() =>
    !initial && draft?.imagem_url ? draft.imagem_url : null,
  );

  /** Categorias das áreas habilitadas; na edição, preserva categoria legada se houver. */
  const categoriasSelect = useMemo(() => {
    if (lockedCategoria) {
      const locked = INVENTORY_CATEGORIES.find((c) => c.value === lockedCategoria);
      return locked ? [locked] : inventoryCategoriesInUiAreas();
    }
    const enabled = inventoryCategoriesInUiAreas();
    const atual = form.categoria;
    if (atual && !enabled.some((c) => c.value === atual)) {
      const legado = INVENTORY_CATEGORIES.find((c) => c.value === atual);
      if (legado) return [...enabled, legado];
    }
    return enabled;
  }, [form.categoria, lockedCategoria]);

  const numChange = (field: keyof typeof num) => (e: ChangeEvent<HTMLInputElement>) =>
    setNum((prev) => ({ ...prev, [field]: e.target.value }));

  const uploadImage = async (file: File) => {
    if (!companyId) {
      toast.error("Selecione uma empresa ativa.");
      return;
    }
    setUploading(true);
    try {
      const path = await uploadInventoryImage(companyId, file);
      if (pendingImage)
        await deleteInventoryImageIfOwnedByCompany(companyId, pendingImage).catch(() => {});
      setPendingImage(path);
      setForm((prev) => ({ ...prev, imagem_url: path }));
      toast.success("Imagem enviada");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : inventoryErrorMessage(e));
    } finally {
      setUploading(false);
    }
  };

  const cancel = async () => {
    if (pendingImage && companyId) {
      await deleteInventoryImageIfOwnedByCompany(companyId, pendingImage).catch(() => {});
    }
    onClose();
  };

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (loading) return;
    if (!form.categoria && !lockedCategoria) {
      toast.error("Selecione uma categoria.");
      return;
    }
    if (!form.unidade) {
      toast.error("Selecione uma unidade.");
      return;
    }
    const categoriaFinal = lockedCategoria ?? form.categoria;
    if (!categoriaFinal) {
      toast.error("Selecione uma categoria.");
      return;
    }
    const numeros = validaCamposNumericos([
      {
        chave: "quantidade",
        texto: num.quantidade,
        regra: { label: "a quantidade", min: 0, casas: 3 },
      },
      {
        chave: "estoque_minimo",
        texto: num.estoque_minimo,
        regra: { label: "o estoque mínimo", min: 0, casas: 3 },
      },
      {
        chave: "custo_unit",
        texto: num.custo_unit,
        regra: { label: "o custo unitário", min: 0, casas: 2 },
      },
      {
        chave: "preco_venda",
        texto: num.preco_venda,
        regra: { label: "o preço de venda", min: 0, casas: 2 },
      },
    ]);
    if (!numeros.ok) {
      toast.error(numeros.erro);
      return;
    }
    const parsed = inventoryItemFormSchema.safeParse({
      ...form,
      categoria: categoriaFinal,
      ...numeros.valores,
    });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    // Criação: não coletar fornecedor/localização — payload normaliza para null.
    onSubmit(
      isEdit ? parsed.data : { ...parsed.data, fornecedor: "", supplier_id: "", localizacao: "" },
    );
  };

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={cancel}>
      <div
        className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-card p-6 shadow-elegant"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-xl font-bold">
            {dialogTitle ?? (initial ? "Editar item" : "Novo item")}
          </h2>
          <button onClick={cancel} type="button">
            <X className="h-5 w-5" />
          </button>
        </div>
        {contextBanner ? <div className="mb-4">{contextBanner}</div> : null}
        <form onSubmit={submit} className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <Field col={4} label="Nome *">
            <input
              value={form.nome}
              onChange={(e) => setForm({ ...form, nome: e.target.value.toUpperCase() })}
              className={inp}
            />
          </Field>
          <Field col={2} label="Categoria *">
            <select
              value={form.categoria}
              onChange={(e) =>
                setForm({ ...form, categoria: e.target.value as InventoryCategoria | "" })
              }
              className={inp}
              required
              disabled={Boolean(lockedCategoria)}
              aria-readonly={Boolean(lockedCategoria)}
            >
              {(needsCategoryChoice || form.categoria === "") && (
                <option value="" disabled>
                  Selecione a categoria
                </option>
              )}
              {categoriasSelect.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.label}
                </option>
              ))}
            </select>
          </Field>
          <Field col={2} label="Unidade *">
            <select
              value={form.unidade}
              onChange={(e) =>
                setForm({ ...form, unidade: e.target.value as InventoryUnidade | "" })
              }
              className={inp}
              required
            >
              {(needsUnitChoice || form.unidade === "") && (
                <option value="" disabled>
                  Selecione a unidade
                </option>
              )}
              {INVENTORY_UNITS.map((u) => (
                <option key={u} value={u}>
                  {u}
                </option>
              ))}
            </select>
          </Field>
          <Field col={4} label="Descrição (opcional)">
            <input
              value={form.descricao ?? ""}
              onChange={(e) => setForm({ ...form, descricao: e.target.value })}
              className={inp}
            />
          </Field>
          <Field col={2} label="SKU (opcional)">
            <input
              value={form.sku ?? ""}
              onChange={(e) => setForm({ ...form, sku: e.target.value })}
              className={inp}
            />
          </Field>
          <Field col={2} label="NCM (opcional)">
            <input
              value={form.ncm ?? ""}
              onChange={(e) => setForm({ ...form, ncm: e.target.value })}
              className={inp}
            />
          </Field>
          <Field col={2} label="Quantidade">
            <input
              inputMode="decimal"
              value={num.quantidade}
              onChange={numChange("quantidade")}
              placeholder="0,000"
              className={inp}
            />
          </Field>
          <Field col={2} label="Estoque mínimo">
            <input
              inputMode="decimal"
              value={num.estoque_minimo}
              onChange={numChange("estoque_minimo")}
              placeholder="0,000"
              className={inp}
            />
          </Field>
          <Field col={2} label="Custo unit. (R$)">
            <input
              inputMode="decimal"
              value={num.custo_unit}
              onChange={numChange("custo_unit")}
              placeholder="0,00"
              className={inp}
            />
          </Field>
          <Field col={2} label="Preço de venda (R$)">
            <input
              inputMode="decimal"
              value={num.preco_venda}
              onChange={numChange("preco_venda")}
              placeholder="89,90"
              className={inp}
            />
          </Field>
          {isEdit && (
            <>
              <Field col={2} label="Fornecedor cadastrado (opcional)">
                <select
                  value={form.supplier_id ?? ""}
                  onChange={(e) => {
                    const id = e.target.value;
                    const nome = supplierOptions.find((s) => s.id === id)?.nome ?? "";
                    setForm({
                      ...form,
                      supplier_id: id,
                      fornecedor: id ? nome : form.fornecedor,
                    });
                  }}
                  className={inp}
                >
                  <option value="">— Nenhum / digitar abaixo —</option>
                  {supplierOptions.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.nome}
                    </option>
                  ))}
                </select>
              </Field>
              <Field col={2} label="Fornecedor texto livre (opcional)">
                <input
                  value={form.fornecedor ?? ""}
                  onChange={(e) =>
                    setForm({ ...form, fornecedor: e.target.value, supplier_id: "" })
                  }
                  placeholder="Ou digite manualmente"
                  className={inp}
                />
              </Field>
              <Field col={4} label="Localização (opcional)">
                <input
                  value={form.localizacao ?? ""}
                  onChange={(e) => setForm({ ...form, localizacao: e.target.value })}
                  className={inp}
                />
              </Field>
            </>
          )}
          <Field col={4} label="Observações (opcional)">
            <textarea
              value={form.observacoes ?? ""}
              onChange={(e) => setForm({ ...form, observacoes: e.target.value })}
              rows={2}
              className={inp}
            />
          </Field>

          <label className="col-span-4 flex cursor-pointer items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.ativo}
              onChange={(e) => setForm({ ...form, ativo: e.target.checked })}
              className="h-4 w-4 accent-current"
            />
            Item ativo (aparece na listagem e no seletor de Orçamentos e da Venda direta)
          </label>

          <div className="col-span-4">
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              Foto do item (opcional)
            </label>
            <div className="flex items-center gap-3">
              {form.imagem_url ? (
                <StorageImage
                  src={form.imagem_url}
                  alt="Prévia"
                  className="h-16 w-16 rounded-lg border border-border object-cover"
                />
              ) : (
                <div className="grid h-16 w-16 place-items-center rounded-lg border border-dashed border-border bg-muted text-muted-foreground">
                  <Package className="h-6 w-6" />
                </div>
              )}
              <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-input bg-background px-3 py-2 text-sm hover:bg-accent">
                <Plus className="h-4 w-4" />
                {uploading ? "Enviando..." : form.imagem_url ? "Trocar foto" : "Adicionar foto"}
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp,image/gif,image/avif"
                  className="hidden"
                  disabled={uploading || !companyId}
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) uploadImage(file);
                    e.target.value = "";
                  }}
                />
              </label>
              {form.imagem_url && (
                <button
                  type="button"
                  onClick={async () => {
                    if (pendingImage && companyId && form.imagem_url === pendingImage) {
                      await deleteInventoryImageIfOwnedByCompany(companyId, pendingImage).catch(
                        () => {},
                      );
                      setPendingImage(null);
                    }
                    setForm({ ...form, imagem_url: "" });
                  }}
                  className="text-xs text-destructive hover:underline"
                >
                  Remover
                </button>
              )}
            </div>
          </div>

          <div className="col-span-4 mt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={cancel}
              className="rounded-lg border border-input px-4 py-2 text-sm"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading || uploading}
              className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50"
            >
              {loading ? "Salvando..." : initial ? "Salvar" : "Cadastrar"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

const inp =
  "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring";

function Field({
  label,
  children,
  col = 1,
}: {
  label: string;
  children: React.ReactNode;
  col?: 1 | 2 | 3 | 4;
}) {
  const span = { 1: "col-span-1", 2: "col-span-2", 3: "col-span-3", 4: "col-span-4" }[col];
  return (
    <label className={`${span} block`}>
      <span className="mb-1 block text-xs font-medium text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}
