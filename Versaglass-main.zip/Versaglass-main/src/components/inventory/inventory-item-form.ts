/**
 * Tipos e helpers do formulário de inventory item — separados do Dialog
 * para evitar warning react-refresh/only-export-components.
 */

import { z } from "zod";
import {
  INVENTORY_CATEGORIES,
  INVENTORY_UNITS,
  optionalText,
  type InventoryCategoria,
  type InventoryItemInput,
  type InventoryUnidade,
} from "@/hooks/use-inventory";

const CATEGORIA_VALUES = INVENTORY_CATEGORIES.map((c) => c.value) as [
  InventoryCategoria,
  ...InventoryCategoria[],
];

export const inventoryItemFormSchema = z.object({
  nome: z.string().trim().min(1, "Nome obrigatório").max(120),
  categoria: z.enum(CATEGORIA_VALUES),
  unidade: z.enum(INVENTORY_UNITS as unknown as [InventoryUnidade, ...InventoryUnidade[]]),
  descricao: z.string().trim().max(255).optional().or(z.literal("")),
  sku: z.string().trim().max(64).optional().or(z.literal("")),
  ncm: z.string().trim().max(20).optional().or(z.literal("")),
  quantidade: z.number().min(0, "Quantidade não pode ser negativa").finite(),
  estoque_minimo: z.number().min(0, "Estoque mínimo não pode ser negativo").finite(),
  custo_unit: z.number().min(0, "Custo não pode ser negativo").finite(),
  preco_venda: z.number().min(0, "Preço de venda não pode ser negativo").finite(),
  fornecedor: z.string().trim().max(120).optional().or(z.literal("")),
  supplier_id: z.string().trim().optional().or(z.literal("")),
  localizacao: z.string().trim().max(120).optional().or(z.literal("")),
  observacoes: z.string().trim().max(1000).optional().or(z.literal("")),
  imagem_url: z.string().trim().max(500).optional().or(z.literal("")),
  ativo: z.boolean(),
});

export type InventoryItemForm = z.infer<typeof inventoryItemFormSchema>;

/** Prefill de criação (catálogo técnico). Não é um item persistido. */
export type InventoryItemDraft = {
  nome?: string;
  categoria?: InventoryCategoria;
  unidade?: InventoryUnidade;
  descricao?: string;
  sku?: string;
  ncm?: string;
  fornecedor?: string;
  /** Path já enviado ao Storage (ex.: foto gerada do desenho técnico). */
  imagem_url?: string;
};

export function inventoryFormToInput(form: InventoryItemForm): InventoryItemInput {
  return {
    nome: form.nome.trim(),
    categoria: form.categoria,
    unidade: form.unidade,
    descricao: optionalText(form.descricao, 255),
    sku: optionalText(form.sku, 64),
    ncm: optionalText(form.ncm, 20),
    quantidade: form.quantidade,
    estoque_minimo: form.estoque_minimo,
    custo_unit: form.custo_unit,
    preco_venda: form.preco_venda,
    fornecedor: optionalText(form.fornecedor, 120),
    supplier_id: form.supplier_id?.trim() ? form.supplier_id.trim() : null,
    localizacao: optionalText(form.localizacao, 120),
    observacoes: optionalText(form.observacoes, 1000),
    imagem_url: optionalText(form.imagem_url, 500),
    ativo: form.ativo,
  };
}
