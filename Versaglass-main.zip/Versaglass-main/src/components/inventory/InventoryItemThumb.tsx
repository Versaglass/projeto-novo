import { Package } from "lucide-react";
import { StorageImage } from "@/components/StorageImage";
import type { InventoryItem } from "@/hooks/use-inventory";

/**
 * Hierarquia de imagem do estoque (Fase 4B):
 * 1. imagem_url própria (project-images)
 * 2. primary_image_path do manufacturer_product (manufacturer-catalog)
 * 3. placeholder
 *
 * Nunca persistir path do catálogo global em imagem_url.
 */
export function InventoryItemThumb({
  item,
  className = "h-10 w-10 rounded-lg border border-border object-cover",
  placeholderClassName = "grid h-10 w-10 place-items-center rounded-lg border border-dashed border-border bg-muted text-muted-foreground",
}: {
  item: Pick<InventoryItem, "nome" | "imagem_url" | "manufacturer_product">;
  className?: string;
  placeholderClassName?: string;
}) {
  if (item.imagem_url) {
    return <StorageImage src={item.imagem_url} alt={item.nome} className={className} />;
  }

  const globalPath = item.manufacturer_product?.primary_image_path;
  const globalActive = item.manufacturer_product?.active !== false;
  if (globalPath && globalActive) {
    return (
      <StorageImage
        src={globalPath}
        alt={item.nome}
        bucket="manufacturer-catalog"
        className={className}
      />
    );
  }

  return (
    <div className={placeholderClassName}>
      <Package className="h-4 w-4" aria-hidden />
    </div>
  );
}
