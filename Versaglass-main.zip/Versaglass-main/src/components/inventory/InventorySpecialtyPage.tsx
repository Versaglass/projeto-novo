/**
 * Visão especializada do Estoque filtrada por uma categoria fixa
 * (ex.: Vidros → `vidro`, Ferragens para vidro → `ferragem`).
 *
 * Fonte: mesmos `inventory_items` (+ overlay global efetivo) do Estoque.
 * Sem tabela/storage paralelo.
 */

import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { AlertTriangle, Pencil, Plus, Search, ShoppingCart, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { brl } from "@/lib/format";
import { InventoryItemThumb } from "@/components/inventory/InventoryItemThumb";
import { InventoryItemDialog } from "@/components/inventory/InventoryItemDialog";
import {
  inventoryFormToInput,
  type InventoryItemDraft,
  type InventoryItemForm,
} from "@/components/inventory/inventory-item-form";
import { useCompany } from "@/contexts/company-context";
import { useAuth } from "@/hooks/use-auth";
import { canManageCompanyEstoque } from "@/lib/inventory-auth";
import {
  useCreateInventoryItem,
  useUpdateInventoryItem,
  useDeleteInventoryItem,
  inventoryErrorMessage,
  categoriaMeta,
  type InventoryCategoria,
  type InventoryItem,
  type InventoryUnidade,
} from "@/hooks/use-inventory";
import { useEffectiveInventoryItems } from "@/hooks/use-effective-inventory";
import {
  saveManufacturerProductErrorMessage,
  useSaveManufacturerProductInventory,
} from "@/hooks/use-ensure-manufacturer-inventory";
import {
  canDeleteEffectiveItem,
  effectiveItemToThumb,
  type EffectiveInventoryItem,
} from "@/lib/effective-inventory";
import { draftFromManufacturerProduct } from "@/lib/manufacturer-catalog/adopt";

export type InventorySpecialtyPageProps = {
  title: string;
  description: string;
  /** Categoria enum real de `inventory_items` (ex.: vidro, ferragem). */
  lockedCategoria: InventoryCategoria;
  /** Unidade sugerida na criação (usuário ainda pode alterar). */
  defaultUnidade: InventoryUnidade;
  createLabel: string;
  emptyTitle: string;
  emptyCta: string;
  dialogCreateTitle: string;
};

export function InventorySpecialtyPage({
  title,
  description,
  lockedCategoria,
  defaultUnidade,
  createLabel,
  emptyTitle,
  emptyCta,
  dialogCreateTitle,
}: InventorySpecialtyPageProps) {
  const { companyRole } = useCompany();
  const { permissions } = useAuth();

  const [search, setSearch] = useState("");
  const [somenteBaixo, setSomenteBaixo] = useState(false);
  const [incluirInativos, setIncluirInativos] = useState(false);
  const [editing, setEditing] = useState<EffectiveInventoryItem | null>(null);
  const [creating, setCreating] = useState(false);
  const [confirmDel, setConfirmDel] = useState<EffectiveInventoryItem | null>(null);

  const {
    data: rawItens = [],
    isLoading,
    isError,
    refetch,
    hasActiveCompany,
    companyLoading,
  } = useEffectiveInventoryItems({
    search,
    categoria: lockedCategoria,
    area: "all",
    incluirInativos,
  });

  const itens = useMemo(() => {
    if (!somenteBaixo) return rawItens;
    return rawItens.filter(
      (i) =>
        i.ativo && Number(i.estoque_minimo) > 0 && Number(i.quantidade) <= Number(i.estoque_minimo),
    );
  }, [rawItens, somenteBaixo]);

  const create = useCreateInventoryItem();
  const update = useUpdateInventoryItem();
  const del = useDeleteInventoryItem();
  const saveGlobal = useSaveManufacturerProductInventory();

  const canWriteStock = canManageCompanyEstoque({
    hasActiveCompany,
    companyRole,
    permissions,
  });

  const createDraft: InventoryItemDraft = useMemo(
    () => ({
      categoria: lockedCategoria,
      unidade: defaultUnidade,
    }),
    [lockedCategoria, defaultUnidade],
  );

  const editingDraft: InventoryItemDraft | null = useMemo(() => {
    if (!editing || editing.source !== "global") return null;
    return draftFromManufacturerProduct({
      name: editing.nome,
      description: editing.descricao,
      source_code: editing.sku ?? "",
      inventory_category: editing.categoria ?? lockedCategoria,
      unit: editing.unidade,
    });
  }, [editing, lockedCategoria]);

  const onSubmit = (form: InventoryItemForm) => {
    const input = inventoryFormToInput({ ...form, categoria: lockedCategoria });

    if (editing) {
      if (editing.source === "global" && editing.manufacturerProductId) {
        saveGlobal.mutate(
          { manufacturerProductId: editing.manufacturerProductId, form: input },
          {
            onSuccess: ({ created }) => {
              toast.success(
                created
                  ? "Item atualizado"
                  : "Este produto já estava no estoque. Lista atualizada.",
              );
              setEditing(null);
            },
            onError: (e) =>
              toast.error(e instanceof Error ? e.message : saveManufacturerProductErrorMessage(e)),
          },
        );
        return;
      }

      if (!editing.inventoryItemId) {
        toast.error("Item inválido para edição.");
        return;
      }

      update.mutate(
        {
          id: editing.inventoryItemId,
          input,
          previousImage: editing.imagem_url,
        },
        {
          onSuccess: () => {
            toast.success("Item atualizado");
            setEditing(null);
          },
          onError: (e) => toast.error(e instanceof Error ? e.message : inventoryErrorMessage(e)),
        },
      );
      return;
    }

    create.mutate(input, {
      onSuccess: () => {
        toast.success("Item cadastrado");
        setCreating(false);
      },
      onError: (e) => toast.error(e instanceof Error ? e.message : inventoryErrorMessage(e)),
    });
  };

  const onDelete = () => {
    if (!confirmDel || !canDeleteEffectiveItem(confirmDel) || !confirmDel.inventoryItemId) return;
    del.mutate(
      { id: confirmDel.inventoryItemId, imagem_url: confirmDel.imagem_url },
      {
        onSuccess: () => {
          toast.success("Item excluído");
          setConfirmDel(null);
        },
        onError: (e) => toast.error(e instanceof Error ? e.message : inventoryErrorMessage(e)),
      },
    );
  };

  const catLabel = categoriaMeta(lockedCategoria)?.label ?? lockedCategoria;

  if (companyLoading) {
    return <p className="text-sm text-muted-foreground">Carregando empresa…</p>;
  }

  if (!hasActiveCompany) {
    return (
      <div className="rounded-2xl border border-dashed p-8 text-center text-sm text-muted-foreground">
        Selecione uma empresa ativa para gerenciar {title.toLowerCase()}.
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">{title}</h1>
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{description}</p>
        </div>
        {canWriteStock ? (
          <button
            type="button"
            onClick={() => {
              setEditing(null);
              setCreating(true);
            }}
            className="inline-flex h-11 items-center gap-2 rounded-2xl bg-primary px-4 text-sm font-semibold text-primary-foreground shadow-sm hover:opacity-90"
          >
            <Plus className="h-4 w-4" /> {createLabel}
          </button>
        ) : null}
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <label className="relative min-w-[220px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por nome, descrição…"
            className="h-11 w-full rounded-xl border bg-background pl-9 pr-3 text-sm"
          />
        </label>
        <label className="inline-flex items-center gap-2 text-sm text-muted-foreground">
          <input
            type="checkbox"
            checked={somenteBaixo}
            onChange={(e) => setSomenteBaixo(e.target.checked)}
            className="rounded border"
          />
          Estoque baixo
        </label>
        <label className="inline-flex items-center gap-2 text-sm text-muted-foreground">
          <input
            type="checkbox"
            checked={incluirInativos}
            onChange={(e) => setIncluirInativos(e.target.checked)}
            className="rounded border"
          />
          Incluir inativos
        </label>
        <Link to="/app/estoque" className="text-sm text-primary underline-offset-2 hover:underline">
          Ver estoque geral
        </Link>
      </div>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">Carregando…</p>
      ) : isError ? (
        <div className="rounded-2xl border border-rose-500/30 bg-rose-500/10 px-4 py-6 text-sm">
          Não foi possível carregar os itens.{" "}
          <button type="button" className="underline" onClick={() => void refetch()}>
            Tentar novamente
          </button>
        </div>
      ) : itens.length === 0 ? (
        <div className="rounded-2xl border border-dashed px-4 py-14 text-center">
          <p className="text-sm font-medium">{emptyTitle}</p>
          {canWriteStock ? (
            <button
              type="button"
              onClick={() => setCreating(true)}
              className="mt-3 inline-flex h-10 items-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground"
            >
              <Plus className="h-4 w-4" /> {emptyCta}
            </button>
          ) : null}
        </div>
      ) : (
        <div className="overflow-x-auto rounded-2xl border bg-card shadow-sm">
          <table className="min-w-full text-left text-sm">
            <thead className="border-b bg-muted/40 text-xs uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="px-3 py-3 font-medium">Item</th>
                <th className="px-3 py-3 font-medium">Categoria</th>
                <th className="px-3 py-3 font-medium">Qtd</th>
                <th className="px-3 py-3 font-medium">Custo</th>
                <th className="px-3 py-3 font-medium">Venda</th>
                <th className="px-3 py-3 font-medium">Ações</th>
              </tr>
            </thead>
            <tbody>
              {itens.map((i) => {
                const cmeta = i.categoria ? categoriaMeta(i.categoria) : undefined;
                const low =
                  Number(i.estoque_minimo) > 0 && Number(i.quantidade) <= Number(i.estoque_minimo);
                const canDelete = canWriteStock && canDeleteEffectiveItem(i);
                const canSell =
                  i.source === "inventory" &&
                  !!i.inventoryItemId &&
                  i.ativo &&
                  Number(i.quantidade) > 0;
                return (
                  <tr
                    key={i.rowKey}
                    className={`border-t transition hover:bg-muted/20 ${i.ativo ? "" : "opacity-60"}`}
                  >
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-3">
                        <InventoryItemThumb item={effectiveItemToThumb(i)} />
                        <div className="min-w-0">
                          <p className="truncate font-medium">{i.nome}</p>
                          {i.descricao ? (
                            <p className="truncate text-xs text-muted-foreground">{i.descricao}</p>
                          ) : null}
                          {i.sku ? (
                            <p className="font-mono text-[11px] text-muted-foreground">{i.sku}</p>
                          ) : null}
                          {low ? (
                            <span className="mt-0.5 inline-flex items-center gap-1 text-[11px] text-amber-600">
                              <AlertTriangle className="h-3 w-3" /> Abaixo do mínimo
                            </span>
                          ) : null}
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <span
                        className={`inline-flex rounded-md px-1.5 py-0.5 text-xs ${cmeta?.color ?? "bg-muted"}`}
                      >
                        {cmeta?.label ?? catLabel}
                      </span>
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      {Number(i.quantidade)} {i.unidade ?? ""}
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      {brl(Number(i.custo_unit) || 0)}
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      {brl(Number(i.preco_venda) || 0)}
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-0.5">
                        {canWriteStock ? (
                          <button
                            type="button"
                            onClick={() => setEditing(i)}
                            title="Editar"
                            className="rounded p-1.5 text-muted-foreground hover:bg-muted"
                          >
                            <Pencil className="h-3.5 w-3.5" />
                          </button>
                        ) : null}
                        {canSell ? (
                          <Link
                            to="/app/venda-direta"
                            search={{ itemId: i.inventoryItemId! }}
                            title={`Vender "${i.nome}"`}
                            className="rounded p-1.5 text-emerald-600 hover:bg-emerald-500/10"
                          >
                            <ShoppingCart className="h-3.5 w-3.5" />
                          </Link>
                        ) : null}
                        {canDelete ? (
                          <button
                            type="button"
                            onClick={() => setConfirmDel(i)}
                            title="Excluir"
                            className="rounded p-1.5 text-destructive hover:bg-destructive/10"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {(creating || editing) && (
        <InventoryItemDialog
          initial={(editing?.inventoryItem as InventoryItem | null) ?? null}
          draft={editing?.source === "global" ? editingDraft : creating ? createDraft : null}
          lockedCategoria={lockedCategoria}
          dialogTitle={
            editing
              ? editing.source === "global"
                ? "Editar produto global"
                : undefined
              : dialogCreateTitle
          }
          onClose={() => {
            setCreating(false);
            setEditing(null);
          }}
          onSubmit={onSubmit}
          loading={create.isPending || update.isPending || saveGlobal.isPending}
        />
      )}

      {confirmDel ? (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4"
          onClick={() => setConfirmDel(null)}
        >
          <div
            className="w-full max-w-md rounded-2xl bg-card p-6 shadow-elegant"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="font-display text-lg font-bold">Excluir item?</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Excluir definitivamente <strong>{confirmDel.nome}</strong>? A imagem associada também
              será removida.
            </p>
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmDel(null)}
                className="h-10 rounded-xl border px-4 text-sm"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={onDelete}
                disabled={del.isPending}
                className="h-10 rounded-xl bg-destructive px-4 text-sm font-semibold text-destructive-foreground"
              >
                {del.isPending ? "Excluindo…" : "Excluir"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
