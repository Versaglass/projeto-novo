import { useMemo } from "react";
import {
  calcularLayout,
  estiloDaPeca,
  medidasDivergem,
  preenchimentoDaPeca,
  resumoDoDesenho,
  rotuloDaPeca,
} from "@/lib/project-data-rendering";
import type { ProjectData } from "@/types/project-data";

// =====================================================================
// Visualização SOMENTE LEITURA do desenho paramétrico.
//
// Usada no formulário do orçamento e na tela de detalhe. Não edita, não salva,
// não conhece Supabase e não altera o objeto recebido — só desenha.
//
// SVG, e não canvas: a mesma geometria de `project-data-rendering.ts` alimenta
// este componente e o PDF, o resultado é nítido em qualquer zoom ou densidade
// de tela, e o texto continua sendo texto (selecionável e acessível).
//
// NENHUMA string do desenho é interpretada como HTML: nome, material e
// acabamento entram como filhos de <text>, que o React escapa. Não há
// `dangerouslySetInnerHTML` em lugar algum.
// =====================================================================

type Props = {
  data: ProjectData;
  /** Espaço disponível, em px. O desenho preserva proporção dentro dele. */
  larguraMax?: number;
  alturaMax?: number;
  mostrarRotulos?: boolean;
  /** Compacto: sem cotas e sem legenda — para miniatura em lista. */
  compacto?: boolean;
  /** Medidas comerciais do item, em mm, só para sinalizar divergência. */
  larguraItemMm?: number;
  alturaItemMm?: number;
};

const MARGEM = 26;

export function ProjectDataPreview({
  data,
  larguraMax = 760,
  alturaMax = 420,
  mostrarRotulos = true,
  compacto = false,
  larguraItemMm,
  alturaItemMm,
}: Props) {
  // Geometria derivada memorizada: recalcular a cada render de um formulário
  // que muda a cada tecla digitada seria desperdício puro.
  const layout = useMemo(
    () => calcularLayout(data, { larguraMax, alturaMax, margem: MARGEM }),
    [data, larguraMax, alturaMax],
  );

  const divergencia = useMemo(
    () =>
      larguraItemMm !== undefined && alturaItemMm !== undefined
        ? medidasDivergem(data, larguraItemMm, alturaItemMm)
        : false,
    [data, larguraItemMm, alturaItemMm],
  );

  if (!data.pecas.length) {
    return (
      <div className="rounded-lg border border-dashed border-border bg-muted/30 p-6 text-center text-xs text-muted-foreground">
        Este desenho não possui componentes.
      </div>
    );
  }

  const largura = Math.max(1, layout.largura);
  const altura = Math.max(1, layout.altura);
  const descricao = `Desenho paramétrico: ${resumoDoDesenho(data)}`;

  return (
    <div className="space-y-2">
      <svg
        viewBox={`0 0 ${largura} ${altura}`}
        // `w-full` + `height:auto` mantêm a proporção e deixam o desenho
        // acompanhar a largura disponível no celular sem cortar nada.
        className="h-auto w-full rounded-lg border border-border bg-card"
        role="img"
        aria-label={descricao}
        preserveAspectRatio="xMidYMid meet"
      >
        <title>{descricao}</title>

        {/* Retângulo do projeto: referência visual do contorno principal. As
            peças podem — legitimamente — ultrapassá-lo. */}
        <rect
          x={layout.projeto.x}
          y={layout.projeto.y}
          width={Math.max(0, layout.projeto.largura)}
          height={Math.max(0, layout.projeto.altura)}
          fill="none"
          stroke="#cbd5e1"
          strokeWidth={1}
          strokeDasharray="4 4"
        />

        {layout.pecas.map((pos, i) => (
          <PecaSvg key={pos.peca.id || i} pos={pos} mostrarRotulos={mostrarRotulos && !compacto} />
        ))}

        {!compacto && (
          <Cotas
            x={layout.projeto.x}
            y={layout.projeto.y}
            largura={layout.projeto.largura}
            altura={layout.projeto.altura}
            larguraMm={data.largura}
            alturaMm={data.altura}
          />
        )}
      </svg>

      {!compacto && (
        <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-muted-foreground">
          <span>{resumoDoDesenho(data)}</span>
          {divergencia && (
            <span className="text-amber-600 dark:text-amber-400">
              As medidas comerciais diferem das medidas do desenho paramétrico.
            </span>
          )}
        </div>
      )}
    </div>
  );
}

function PecaSvg({
  pos,
  mostrarRotulos,
}: {
  pos: ReturnType<typeof calcularLayout>["pecas"][number];
  mostrarRotulos: boolean;
}) {
  const { peca } = pos;
  const estilo = estiloDaPeca(peca.tipo);
  const preenchimento = preenchimentoDaPeca(peca);
  // Peça minúscula na escala ainda precisa ser vista: piso de 2 px.
  const w = Math.max(2, pos.largura);
  const h = Math.max(2, pos.altura);
  const rotulo = mostrarRotulos ? rotuloDaPeca(peca, w, h, 6.2) : null;

  // TEXTO é conteúdo, não peça: desenha-se a palavra, não um retângulo mudo.
  if (estilo.forma === "texto") {
    return (
      <text
        x={pos.x}
        y={pos.cy}
        fontSize={Math.max(9, Math.min(16, h))}
        fill={estilo.contorno}
        dominantBaseline="middle"
      >
        {(peca.nome ?? "").slice(0, 120)}
      </text>
    );
  }

  // FURO: círculo com cruz de centro — nunca um bloco sólido.
  if (estilo.forma === "circulo") {
    const r = Math.max(2, Math.min(w, h) / 2);
    return (
      <g>
        <circle
          cx={pos.cx}
          cy={pos.cy}
          r={r}
          fill={estilo.preenchimento}
          stroke={estilo.contorno}
          strokeWidth={1.4}
        />
        <line
          x1={pos.cx - r}
          y1={pos.cy}
          x2={pos.cx + r}
          y2={pos.cy}
          stroke={estilo.contorno}
          strokeWidth={0.8}
        />
        <line
          x1={pos.cx}
          y1={pos.cy - r}
          x2={pos.cx}
          y2={pos.cy + r}
          stroke={estilo.contorno}
          strokeWidth={0.8}
        />
      </g>
    );
  }

  // RECORTE: área VAZADA, tracejada e quase transparente — não é material.
  const vazado = estilo.forma === "vazado";

  return (
    <g>
      <rect
        x={pos.x}
        y={pos.y}
        width={w}
        height={h}
        fill={preenchimento}
        fillOpacity={estilo.opacidade}
        stroke={estilo.contorno}
        strokeWidth={vazado ? 1.6 : 1}
        strokeDasharray={estilo.tracejado ? estilo.tracejado.join(" ") : undefined}
        rx={vazado ? 3 : 1}
      />
      {/* Sigla no canto: distingue o tipo sem depender de cor, o que mantém o
          desenho legível impresso em preto e branco. */}
      {w > 16 && h > 12 && (
        <text x={pos.x + 3} y={pos.y + 10} fontSize={8} fill={estilo.contorno} opacity={0.75}>
          {estilo.sigla}
        </text>
      )}
      {rotulo && (
        <text
          x={pos.cx}
          y={pos.cy}
          textAnchor="middle"
          dominantBaseline="middle"
          fontSize={9}
          fill="#0f172a"
        >
          {rotulo}
        </text>
      )}
    </g>
  );
}

function Cotas({
  x,
  y,
  largura,
  altura,
  larguraMm,
  alturaMm,
}: {
  x: number;
  y: number;
  largura: number;
  altura: number;
  larguraMm: number;
  alturaMm: number;
}) {
  if (largura <= 0 || altura <= 0) return null;
  return (
    <g stroke="#475569" fill="#475569" fontSize={9}>
      <line x1={x} y1={y - 9} x2={x + largura} y2={y - 9} strokeWidth={0.8} />
      <text x={x + largura / 2} y={y - 13} textAnchor="middle" stroke="none">
        {Math.round(larguraMm)} mm
      </text>
      <line x1={x - 9} y1={y} x2={x - 9} y2={y + altura} strokeWidth={0.8} />
      <text
        x={x - 13}
        y={y + altura / 2}
        textAnchor="middle"
        stroke="none"
        transform={`rotate(-90 ${x - 13} ${y + altura / 2})`}
      >
        {Math.round(alturaMm)} mm
      </text>
    </g>
  );
}
