import { useMemo, useRef, useState } from "react";
import {
  Box,
  Download,
  FileText,
  Gem,
  Hammer,
  Layers,
  Move,
  Package,
  Plus,
  RotateCw,
  Ruler,
  Save,
  Scissors,
  Trash2,
  WandSparkles,
  type LucideIcon,
} from "lucide-react";
import {
  START_PROJECTS,
  calculateProject,
  cloneProject,
  elementCost,
  generateCutPieces,
  type EngineeringElement,
  type EngineeringProject,
  type Segment,
} from "@/lib/engineering/engine";
import { brl } from "@/lib/format";
import { textoParaNumero } from "@/lib/numero-campo";

type ViewMode = "2d" | "3d" | "corte" | "materiais";

/**
 * Ferramenta ativa da barra inferior (Revisao 109).
 *
 * Ate aqui a barra NAO tinha estado nenhum: "Copiar", "Girar" e "Excluir" sao
 * acoes de um disparo, e "Mover"/"Cotas" eram `<button>` sem `onClick` — nada
 * na tela ficava "selecionado". Como "Mover" e um MODO (arma o arrasto e fica
 * armado), ele precisa de estado proprio; "selecionar" e o repouso, que era o
 * unico comportamento que existia antes.
 *
 * "Cotas" continua sem funcao e por isso NAO entrou aqui — vira ferramenta no
 * dia em que tiver o que ligar. Ver Revisao 108, §15.
 */
type Tool = "selecionar" | "mover";

const SEGMENTS: { id: Segment; label: string; icon: LucideIcon; tone: string }[] = [
  { id: "vidracaria", label: "Vidraçaria", icon: Layers, tone: "from-blue-600 to-cyan-500" },
  { id: "marcenaria", label: "Marcenaria", icon: Box, tone: "from-amber-600 to-orange-500" },
  { id: "marmoraria", label: "Marmoraria", icon: Gem, tone: "from-stone-600 to-zinc-400" },
  { id: "serralheria", label: "Serralheria", icon: Hammer, tone: "from-slate-600 to-zinc-500" },
];

const COMPONENTS: Record<
  Segment,
  {
    label: string;
    kind: EngineeringElement["kind"];
    material: string;
    color: string;
    unitCost: number;
  }[]
> = {
  vidracaria: [
    {
      label: "Vidro",
      kind: "glass",
      material: "Vidro temperado incolor 10mm",
      color: "#cdebe8",
      unitCost: 210,
    },
    {
      label: "Perfil U",
      kind: "profile",
      material: "Alumínio perfil U",
      color: "#151923",
      unitCost: 38,
    },
    {
      label: "Puxador",
      kind: "hardware",
      material: "Puxador inox",
      color: "#1b1f28",
      unitCost: 85,
    },
    {
      label: "Dobradiça",
      kind: "hardware",
      material: "Dobradiça vidro",
      color: "#1b1f28",
      unitCost: 120,
    },
    { label: "Furo", kind: "cutout", material: "Furo no vidro", color: "#063b3a", unitCost: 18 },
    {
      label: "Recorte",
      kind: "cutout",
      material: "Recorte no vidro",
      color: "#071518",
      unitCost: 75,
    },
  ],
  marcenaria: [
    { label: "Módulo MDF", kind: "wood", material: "MDF 18mm", color: "#8a5a34", unitCost: 145 },
    { label: "Porta", kind: "wood", material: "Porta MDF", color: "#9b673c", unitCost: 145 },
    { label: "Gaveta", kind: "wood", material: "Gaveta MDF", color: "#724423", unitCost: 125 },
    {
      label: "Puxador",
      kind: "hardware",
      material: "Puxador móvel",
      color: "#1b1f28",
      unitCost: 24,
    },
    {
      label: "Dobradiça",
      kind: "hardware",
      material: "Dobradiça caneco",
      color: "#2f3742",
      unitCost: 12,
    },
  ],
  marmoraria: [
    {
      label: "Bancada",
      kind: "stone",
      material: "Granito / Quartzo",
      color: "#ddd8ce",
      unitCost: 680,
    },
    { label: "Frontão", kind: "stone", material: "Frontão", color: "#d0ccc3", unitCost: 120 },
    { label: "Saia", kind: "stone", material: "Saia", color: "#c8c3b8", unitCost: 145 },
    { label: "Cuba", kind: "cutout", material: "Recorte de cuba", color: "#2c3742", unitCost: 110 },
    {
      label: "Cooktop",
      kind: "cutout",
      material: "Recorte cooktop",
      color: "#171717",
      unitCost: 130,
    },
  ],
  serralheria: [
    { label: "Pilar", kind: "steel", material: "Metalon 100x100", color: "#40464f", unitCost: 95 },
    { label: "Viga", kind: "steel", material: "Metalon 100x100", color: "#565e69", unitCost: 95 },
    {
      label: "Treliça",
      kind: "steel",
      material: "Treliça metálica",
      color: "#6a7280",
      unitCost: 78,
    },
    { label: "Chapa", kind: "steel", material: "Chapa metálica", color: "#7d8795", unitCost: 65 },
    {
      label: "Dobradiça",
      kind: "hardware",
      material: "Dobradiça reforçada",
      color: "#1b1f28",
      unitCost: 45,
    },
  ],
};

const canvasW = 900;
// Revisao 120 — altura do viewBox (antes 440). Com `width="100%"` o SVG
// mantém a proporção viewBox na tela; subir H aumenta a altura renderizada
// e o espaço útil em mm no eixo Y (o `scale` usa canvasH - 110). Não fixa px
// de CSS: em telas estreitas a coluna central encolhe e o SVG acompanha.
const canvasH = 600;

/**
 * Medida mínima de uma peça, em milímetros (Revisao 110).
 *
 * O painel numérico da direita NÃO tem mínimo — digitar `0` grava `0`, e o
 * desenho só disfarça com `Math.max(2, …)` na hora de pintar. Como não havia
 * validação para reaproveitar, este piso é decisão declarada: 10 mm fica bem
 * abaixo da menor peça de catálogo (a lateral de MDF do editor paramétrico tem
 * 18 mm) e, na escala de tela deste editor, vale cerca de um pixel de arrasto.
 * O piso vale só para a ALÇA; o campo numérico continua como estava.
 */
const MIN_MM = 10;

/**
 * As 8 alças, na MESMA ordem em que já eram desenhadas — nada mudou de lugar.
 * `ax`/`ay` dizem que fração da peça a alça ocupa, e é isso que decide o que o
 * arrasto altera: `0` arrasta a borda inicial (mexe em posição E medida, porque
 * a borda oposta fica parada), `1` arrasta a borda final (mexe só na medida) e
 * `0.5` é o meio de uma aresta, que não mexe naquele eixo.
 */
const ALCAS: { ax: 0 | 0.5 | 1; ay: 0 | 0.5 | 1; cursor: string }[] = [
  { ax: 0, ay: 0, cursor: "nwse-resize" },
  { ax: 0.5, ay: 0, cursor: "ns-resize" },
  { ax: 1, ay: 0, cursor: "nesw-resize" },
  { ax: 0, ay: 0.5, cursor: "ew-resize" },
  { ax: 1, ay: 0.5, cursor: "ew-resize" },
  { ax: 0, ay: 1, cursor: "nesw-resize" },
  { ax: 0.5, ay: 1, cursor: "ns-resize" },
  { ax: 1, ay: 1, cursor: "nwse-resize" },
];

function toInputValue(value: number | undefined) {
  if (!value) return "";
  return String(Math.round(value));
}

/**
 * Revisao 32 — passou a usar `textoParaNumero`, o mesmo conversor do resto do
 * projeto. O input daqui ja era `inputMode="decimal"` (a virgula chegava), mas
 * a regra de formato era propria; agora "1.234,56" e as demais formas valem
 * igual em toda tela. O `fallback` continua sendo o valor ANTERIOR do campo —
 * entrada ilegivel nao troca a medida por zero.
 */
function parseNumber(value: string, fallback: number) {
  if (value.trim() === "") return 0;
  const n = textoParaNumero(value);
  return Number.isNaN(n) ? fallback : n;
}

export function UniversalEngineeringEditor() {
  const [segment, setSegment] = useState<Segment>("vidracaria");
  const [project, setProject] = useState<EngineeringProject>(() =>
    cloneProject(START_PROJECTS.vidracaria),
  );
  const [selectedId, setSelectedId] = useState(project.elements[0]?.id ?? "");
  const [mode, setMode] = useState<ViewMode>("2d");
  const [tool, setTool] = useState<Tool>("selecionar");
  const [history, setHistory] = useState<string[]>(["Projeto criado"]);

  const selected = project.elements.find((e) => e.id === selectedId) ?? project.elements[0];
  const metrics = useMemo(() => calculateProject(project), [project]);
  const cuts = useMemo(() => generateCutPieces(project), [project]);
  const scale = Math.min(
    (canvasW - 110) / project.width,
    (canvasH - 110) / Math.max(project.height, 1),
  );
  const ox = 70;
  const oy = 70;

  const switchSegment = (id: Segment) => {
    const next = cloneProject(START_PROJECTS[id]);
    setSegment(id);
    setProject(next);
    setSelectedId(next.elements[0]?.id ?? "");
    setMode("2d");
    setHistory([`Modelo ${next.title} carregado`]);
  };

  const updateProject = (patch: Partial<EngineeringProject>) => {
    setProject((p) => ({ ...p, ...patch }));
    setHistory((h) => [`Projeto atualizado`, ...h].slice(0, 8));
  };

  /**
   * Escrita CRUA na peça, sem histórico. Existe para o arrasto: um gesto
   * dispara dezenas de `pointermove`, e passar cada um pelo `updateElement`
   * encheria as 8 linhas do histórico com "Vidro 2 alterado" e apagaria tudo
   * o que veio antes. O arrasto registra UMA linha, ao soltar.
   */
  const setElement = (id: string, patch: Partial<EngineeringElement>) =>
    setProject((p) => ({
      ...p,
      elements: p.elements.map((el) => (el.id === id ? { ...el, ...patch } : el)),
    }));

  const updateElement = (id: string, patch: Partial<EngineeringElement>) => {
    setElement(id, patch);
    setHistory((h) => [`${selected?.label ?? "Peça"} alterado`, ...h].slice(0, 8));
  };

  const registrarMovimento = (label: string) =>
    setHistory((h) => [`${label} movido`, ...h].slice(0, 8));

  const registrarRedimensionamento = (label: string) =>
    setHistory((h) => [`${label} redimensionado`, ...h].slice(0, 8));

  const addComponent = (template: (typeof COMPONENTS)[Segment][number]) => {
    const id = `${template.kind}-${Date.now()}`;
    const element: EngineeringElement = {
      id,
      kind: template.kind,
      label: template.label,
      x: Math.round(project.width * 0.12),
      y: Math.round(project.height * 0.12),
      width: template.kind === "hardware" ? 120 : Math.round(project.width * 0.22),
      height:
        template.kind === "profile" || template.kind === "steel"
          ? 80
          : Math.round(project.height * 0.25),
      depth: segment === "marcenaria" ? 350 : segment === "marmoraria" ? 30 : 10,
      thickness: segment === "marcenaria" ? 18 : segment === "marmoraria" ? 30 : 10,
      material: template.material,
      unitCost: template.unitCost,
      quantity: 1,
      color: template.color,
    };
    setProject((p) => ({ ...p, elements: [...p.elements, element] }));
    setSelectedId(id);
    setHistory((h) => [`${template.label} adicionado`, ...h].slice(0, 8));
  };

  const duplicateSelected = () => {
    if (!selected) return;
    const copy = {
      ...selected,
      id: `${selected.id}-copy-${Date.now()}`,
      label: `${selected.label} cópia`,
      x: selected.x + 80,
      y: selected.y + 80,
    };
    setProject((p) => ({ ...p, elements: [...p.elements, copy] }));
    setSelectedId(copy.id);
  };

  const deleteSelected = () => {
    if (!selected || selected.locked) return;
    setProject((p) => ({ ...p, elements: p.elements.filter((el) => el.id !== selected.id) }));
    setSelectedId(project.elements.find((el) => el.id !== selected.id)?.id ?? "");
  };

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(project, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${project.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    // Revisao 124 — o card da Rev. 120 usava `calc(100dvh - 6rem)` DENTRO do
    // `md:py-10` (5rem) do AppShell. A conta quase fechava (sobra 1rem), mas
    // qualquer folga (subpixel, barra, cabeçalho interno alto) empurrava o
    // rodapé do card para fora da janela: a página rolava e a barra
    // Mover/Cotas/… sumia. Aqui o wrapper CANCELA o padding vertical do shell
    // (`-my-10`) e preenche `100dvh` de verdade; o card interno é `h-full`.
    // Abaixo de xl o layout empilha e continua rolando (viewport estreita).
    <div className="xl:-my-10 xl:h-dvh xl:max-h-dvh xl:overflow-hidden">
      <div className="flex h-full min-h-0 flex-col overflow-hidden rounded-3xl border border-white/10 bg-slate-950 text-white shadow-2xl xl:rounded-none xl:border-x-0 xl:border-b-0">
        <div className="flex shrink-0 flex-col gap-2 border-b border-white/10 bg-slate-950/95 px-4 py-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="min-w-0">
            <p className="text-[10px] uppercase tracking-[0.25em] text-cyan-300">
              Motor gráfico universal
            </p>
            <h1 className="truncate text-xl font-bold lg:text-2xl">
              Editor 2D Vetorial + Prévia em perspectiva + Plano de Corte
            </h1>
            <p className="hidden text-sm text-slate-400 sm:block">
              Altere medidas, materiais e componentes e veja o projeto atualizar em tempo real.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {/* Revisao 113 — o botão parou de dizer que salvou.
                Ele nunca salvou: a Revisao 108 mediu ZERO requisições não-GET,
                `localStorage` inalterado e o F5 devolvendo o valor de fábrica.
                O que ele faz de verdade é marcar uma versão na lista de
                histórico DESTA sessão — então é isso que ele passa a dizer, no
                rótulo e na linha que escreve.
                A persistência de verdade NÃO foi implementada e é decisão de
                produto (Revisao 112, PARTE 2): esta tela não é aberta a partir
                de modelo nenhum, então não há linha a que prender o desenho.
                Enquanto isso, quem precisa levar o trabalho embora usa o
                "Exportar JSON" ao lado — que funciona. */}
            <button
              onClick={() =>
                setHistory((h) => ["Alterações mantidas nesta sessão", ...h].slice(0, 8))
              }
              title="Marca uma versão no histórico desta sessão. O desenho ainda NÃO é gravado no servidor — ao recarregar a página ele volta ao modelo de fábrica. Para guardar, use “Exportar JSON”."
              className="engine-btn bg-slate-700 hover:bg-slate-600"
            >
              <Save size={16} />
              Marcar versão
            </button>
            <button
              onClick={duplicateSelected}
              className="engine-btn bg-slate-800 hover:bg-slate-700"
            >
              <Plus size={16} />
              Duplicar peça
            </button>
            <button onClick={exportJson} className="engine-btn bg-blue-600 hover:bg-blue-500">
              <Download size={16} />
              Exportar JSON
            </button>
            <button className="engine-btn bg-purple-600 hover:bg-purple-500">
              <FileText size={16} />
              Gerar PDF
            </button>
          </div>
        </div>

        {/* Revisao 124 — laterais um pouco mais estreitas (220|1fr|260) vs
            240|1fr|280 da Rev. 120: o centro recupera ~40px sem apertar
            Propriedades (campos continuam w-full). */}
        <div className="grid min-h-0 flex-1 gap-0 overflow-hidden xl:grid-cols-[220px_minmax(0,1fr)_260px]">
          <aside className="min-h-0 overflow-y-auto border-r border-white/10 bg-slate-900/65 p-3">
            <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
              Segmento
            </p>
            <div className="grid grid-cols-2 gap-2 xl:grid-cols-1">
              {SEGMENTS.map((s) => {
                const Icon = s.icon;
                const active = segment === s.id;
                return (
                  <button
                    key={s.id}
                    onClick={() => switchSegment(s.id)}
                    className={`flex items-center gap-2 rounded-2xl border p-3 text-left transition ${active ? "border-cyan-400 bg-cyan-400/10" : "border-white/10 bg-white/5 hover:bg-white/10"}`}
                  >
                    <span
                      className={`grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br ${s.tone}`}
                    >
                      <Icon size={18} />
                    </span>
                    <span className="font-semibold">{s.label}</span>
                  </button>
                );
              })}
            </div>

            <p className="mb-3 mt-6 text-xs font-semibold uppercase tracking-wider text-slate-400">
              Componentes técnicos
            </p>
            <div className="grid grid-cols-2 gap-2">
              {COMPONENTS[segment].map((c) => (
                <button
                  key={`${segment}-${c.label}`}
                  onClick={() => addComponent(c)}
                  className="rounded-2xl border border-white/10 bg-slate-800/70 p-3 text-sm hover:border-cyan-400 hover:bg-cyan-400/10"
                >
                  <Package className="mx-auto mb-2 h-5 w-5 text-cyan-300" />
                  {c.label}
                </button>
              ))}
            </div>

            <p className="mb-3 mt-6 text-xs font-semibold uppercase tracking-wider text-slate-400">
              Camadas
            </p>
            <div className="max-h-64 space-y-1 overflow-auto pr-1">
              {project.elements.map((el) => (
                <button
                  key={el.id}
                  onClick={() => setSelectedId(el.id)}
                  className={`w-full rounded-xl px-3 py-2 text-left text-sm ${selectedId === el.id ? "bg-emerald-600 text-white" : "bg-white/5 text-slate-300 hover:bg-white/10"}`}
                >
                  <span className="block font-semibold">{el.label}</span>
                  <span className="text-xs opacity-70">
                    {Math.round(el.width)} x {Math.round(el.height)} mm
                  </span>
                </button>
              ))}
            </div>
          </aside>

          <main className="flex min-h-0 min-w-0 flex-col overflow-hidden bg-slate-950 p-3">
            <div className="mb-2 flex shrink-0 flex-wrap items-center justify-between gap-2">
              <div className="flex rounded-2xl border border-white/10 bg-slate-900 p-1">
                {[
                  ["2d", "Editor 2D"],
                  ["3d", "Perspectiva"],
                  ["corte", "Plano de corte"],
                  ["materiais", "Lista de materiais"],
                ].map(([id, label]) => (
                  <button
                    key={id}
                    onClick={() => setMode(id as ViewMode)}
                    className={`rounded-xl px-3 py-2 text-sm ${mode === id ? "bg-blue-600 text-white" : "text-slate-300 hover:bg-white/10"}`}
                  >
                    {label}
                  </button>
                ))}
              </div>
              <div className="flex gap-2 text-sm text-slate-300">
                <span className="rounded-xl bg-white/5 px-3 py-2">
                  Área: {metrics.totalArea.toFixed(2)} m²
                </span>
                <span className="rounded-xl bg-white/5 px-3 py-2">
                  Linear: {metrics.totalLinear.toFixed(2)} m
                </span>
                <span className="rounded-xl bg-emerald-500/15 px-3 py-2 text-emerald-300">
                  Total: {brl(metrics.total)}
                </span>
              </div>
            </div>

            <div className="flex min-h-0 flex-1 flex-col rounded-3xl border border-white/10 bg-white p-2 text-slate-950 sm:p-3">
              {mode === "2d" && (
                <SvgCanvas
                  project={project}
                  selectedId={selectedId}
                  setSelectedId={setSelectedId}
                  setElement={setElement}
                  onMoveEnd={registrarMovimento}
                  onResizeEnd={registrarRedimensionamento}
                  tool={tool}
                  scale={scale}
                  ox={ox}
                  oy={oy}
                />
              )}
              {mode === "3d" && <ThreeLikePreview project={project} />}
              {mode === "corte" && <CutPlan project={project} cuts={cuts} />}
              {mode === "materiais" && <MaterialList project={project} />}
            </div>

            <div className="mt-2 flex shrink-0 flex-wrap gap-2 rounded-2xl border border-white/10 bg-slate-900 p-2">
              {/* Revisao 109 — "Mover" e alternador, nao acao: clicar arma o
                  modo, clicar de novo volta para "selecionar". O destaque do
                  estado ativo usa `engine-tool-ativa`, que puxa o MESMO token de
                  tema das abas de visualizacao logo acima — nenhuma cor nova. */}
              <button
                onClick={() => setTool((t) => (t === "mover" ? "selecionar" : "mover"))}
                aria-pressed={tool === "mover"}
                title={
                  tool === "mover"
                    ? "Modo mover ativo — arraste uma peça no desenho para reposicioná-la"
                    : "Ativar o modo mover"
                }
                className={`engine-tool ${tool === "mover" ? "engine-tool-ativa" : ""}`}
              >
                <Move size={15} />
                Mover
              </button>
              <button className="engine-tool">
                <Ruler size={15} />
                Cotas
              </button>
              <button onClick={duplicateSelected} className="engine-tool">
                <Plus size={15} />
                Copiar
              </button>
              <button
                onClick={() =>
                  selected &&
                  updateElement(selected.id, { width: selected.height, height: selected.width })
                }
                className="engine-tool"
              >
                <RotateCw size={15} />
                Girar
              </button>
              <button onClick={deleteSelected} className="engine-tool text-red-300">
                <Trash2 size={15} />
                Excluir
              </button>
            </div>
          </main>

          <aside className="min-h-0 overflow-y-auto border-l border-white/10 bg-slate-900/65 p-3">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Propriedades
            </p>
            {selected ? (
              <div className="mt-4 space-y-3">
                <PropertyInput
                  label="Nome"
                  value={selected.label}
                  onChange={(v) => updateElement(selected.id, { label: v })}
                />
                <PropertyNumber
                  label="Largura"
                  value={selected.width}
                  suffix="mm"
                  onChange={(v) => updateElement(selected.id, { width: v })}
                />
                <PropertyNumber
                  label="Altura"
                  value={selected.height}
                  suffix="mm"
                  onChange={(v) => updateElement(selected.id, { height: v })}
                />
                <PropertyNumber
                  label="Posição X"
                  value={selected.x}
                  suffix="mm"
                  onChange={(v) => updateElement(selected.id, { x: v })}
                />
                <PropertyNumber
                  label="Posição Y"
                  value={selected.y}
                  suffix="mm"
                  onChange={(v) => updateElement(selected.id, { y: v })}
                />
                <PropertyNumber
                  label="Espessura"
                  value={selected.thickness}
                  suffix="mm"
                  onChange={(v) => updateElement(selected.id, { thickness: v })}
                />
                <PropertyNumber
                  label="Qtd"
                  value={selected.quantity}
                  onChange={(v) => updateElement(selected.id, { quantity: v })}
                />
                <PropertyNumber
                  label="Custo unitário"
                  value={selected.unitCost}
                  prefix="R$"
                  onChange={(v) => updateElement(selected.id, { unitCost: v })}
                />
                <PropertyInput
                  label="Material"
                  value={selected.material}
                  onChange={(v) => updateElement(selected.id, { material: v })}
                />
                <div className="rounded-2xl bg-slate-950 p-3">
                  <p className="text-xs text-slate-400">Custo calculado da peça</p>
                  <p className="text-xl font-bold text-emerald-300">{brl(elementCost(selected))}</p>
                </div>
              </div>
            ) : (
              <p className="mt-4 text-sm text-slate-400">Selecione uma peça.</p>
            )}

            <div className="mt-6 rounded-2xl border border-white/10 bg-slate-950 p-4">
              <p className="text-sm font-bold">Resumo automático</p>
              <SummaryLine label="Materiais" value={brl(metrics.materialCost)} />
              <SummaryLine label="Mão de obra" value={brl(project.laborCost)} />
              <SummaryLine label="Margem" value={brl(metrics.margin)} />
              <div className="mt-3 border-t border-white/10 pt-3 text-xl font-bold text-emerald-300">
                {brl(metrics.total)}
              </div>
            </div>

            <div className="mt-6 rounded-2xl border border-white/10 bg-slate-950 p-4">
              <p className="text-sm font-bold">Histórico em tempo real</p>
              <div className="mt-3 space-y-2">
                {history.map((h, i) => (
                  <div
                    key={`${h}-${i}`}
                    className="rounded-xl bg-white/5 px-3 py-2 text-xs text-slate-300"
                  >
                    v{history.length - i} • {h}
                  </div>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </div>

      <style>{`
        .engine-btn{display:inline-flex;align-items:center;gap:.45rem;border-radius:0.9rem;padding:.65rem .9rem;font-weight:700;font-size:.875rem;transition:.2s}
        .engine-tool{display:inline-flex;align-items:center;gap:.35rem;border-radius:.75rem;background:rgba(255,255,255,.06);padding:.55rem .75rem;font-size:.82rem;color:#cbd5e1}
        .engine-tool:hover{background:rgba(255,255,255,.12)}
        /* O azul do ativo vem do TEMA (--color-blue-600), o mesmo token que as
           abas de visualizacao usam via \`bg-blue-600\`. Medido: neste projeto
           (Tailwind v4) ele vale rgb(21,93,252) — NAO o #2563eb do contorno da
           peca selecionada. Sao dois azuis distintos e o fallback fica com o
           segundo so para o caso de o token sumir. */
        .engine-tool-ativa,.engine-tool-ativa:hover{background:#2563eb;background:var(--color-blue-600,#2563eb);color:#fff;font-weight:700}
      `}</style>
    </div>
  );
}

function SvgCanvas({
  project,
  selectedId,
  setSelectedId,
  setElement,
  onMoveEnd,
  onResizeEnd,
  tool,
  scale,
  ox,
  oy,
}: {
  project: EngineeringProject;
  selectedId: string;
  setSelectedId: (id: string) => void;
  setElement: (id: string, patch: Partial<EngineeringElement>) => void;
  onMoveEnd?: (label: string) => void;
  onResizeEnd?: (label: string) => void;
  tool: Tool;
  scale: number;
  ox: number;
  oy: number;
}) {
  const w = canvasW;
  const h = canvasH;
  const px = (n: number) => ox + n * scale;
  const py = (n: number) => oy + n * scale;

  // ARRASTO (Revisao 109). O `<svg>` tem `width="100%"` e `viewBox` fixo, entao
  // um pixel da tela NAO vale uma unidade do desenho — a conversao precisa vir
  // do proprio navegador (`getScreenCTM`), nao de uma regra de tres nossa. Do
  // sistema do viewBox para milimetros, divide-se por `scale`.
  const svgRef = useRef<SVGSVGElement | null>(null);
  const arrasto = useRef<{
    id: string;
    label: string;
    x0: number;
    y0: number;
    elX: number;
    elY: number;
    moveu: boolean;
  } | null>(null);

  const pontoNoDesenho = (e: React.PointerEvent) => {
    const ctm = svgRef.current?.getScreenCTM();
    if (!ctm) return null;
    return new DOMPoint(e.clientX, e.clientY).matrixTransform(ctm.inverse());
  };

  const aoPressionar = (el: EngineeringElement) => (e: React.PointerEvent) => {
    if (tool !== "mover" || el.locked) return;
    const p = pontoNoDesenho(e);
    if (!p) return;
    setSelectedId(el.id);
    arrasto.current = {
      id: el.id,
      label: el.label,
      x0: p.x,
      y0: p.y,
      elX: el.x,
      elY: el.y,
      moveu: false,
    };
    // Sem `setPointerCapture` o gesto morre assim que o ponteiro sai de cima da
    // peca — que e exatamente o que acontece ao arrastar rapido.
    (e.currentTarget as Element).setPointerCapture(e.pointerId);
    e.preventDefault();
  };

  const aoMover = (e: React.PointerEvent) => {
    const a = arrasto.current;
    if (!a) return;
    const p = pontoNoDesenho(e);
    if (!p) return;
    const nx = Math.round(a.elX + (p.x - a.x0) / scale);
    const ny = Math.round(a.elY + (p.y - a.y0) / scale);
    if (nx === a.elX && ny === a.elY && !a.moveu) return;
    a.moveu = true;
    setElement(a.id, { x: nx, y: ny });
  };

  const aoSoltar = (e: React.PointerEvent) => {
    const a = arrasto.current;
    arrasto.current = null;
    const alvo = e.currentTarget as Element;
    if (alvo.hasPointerCapture?.(e.pointerId)) alvo.releasePointerCapture(e.pointerId);
    // Uma linha de historico por GESTO, e so se a peca realmente saiu do lugar.
    if (a?.moveu) onMoveEnd?.(a.label);
  };

  // REDIMENSIONAR (Revisao 110). Mesmo mecanismo do arrasto de mover: a
  // conversao de coordenada sai de `getScreenCTM` e o delta em unidades do
  // viewBox vira milimetro dividindo por `scale`. O que muda e a REGRA: aqui o
  // delta nao vai para a posicao, vai para a medida — e a borda oposta a alça
  // fica parada, que e o que faz o redimensionamento parecer natural.
  const redim = useRef<{
    id: string;
    label: string;
    ax: number;
    ay: number;
    vx0: number;
    vy0: number;
    x0: number;
    y0: number;
    w0: number;
    h0: number;
    mudou: boolean;
  } | null>(null);

  const aoPegarAlca =
    (el: EngineeringElement, ax: number, ay: number) => (e: React.PointerEvent) => {
      if (el.locked) return;
      // A alça vive DENTRO do `<g>` da peça, que tem o arrasto de mover. Sem
      // parar a propagacao, pegar um canto moveria a peça em vez de esticá-la.
      e.stopPropagation();
      const p = pontoNoDesenho(e);
      if (!p) return;
      setSelectedId(el.id);
      redim.current = {
        id: el.id,
        label: el.label,
        ax,
        ay,
        vx0: p.x,
        vy0: p.y,
        x0: el.x,
        y0: el.y,
        w0: el.width,
        h0: el.height,
        mudou: false,
      };
      (e.currentTarget as Element).setPointerCapture(e.pointerId);
      e.preventDefault();
    };

  const aoArrastarAlca = (e: React.PointerEvent) => {
    const r = redim.current;
    if (!r) return;
    e.stopPropagation();
    const p = pontoNoDesenho(e);
    if (!p) return;
    const dx = Math.round((p.x - r.vx0) / scale);
    const dy = Math.round((p.y - r.vy0) / scale);
    if (!r.mudou && dx === 0 && dy === 0) return;
    // Tudo e calculado a partir do INSTANTE EM QUE A ALÇA FOI PEGA, nunca do
    // estado corrente: com o valor corrente a borda "parada" andaria junto e a
    // peça escaparia do ponteiro.
    const patch: Partial<EngineeringElement> = {};
    if (r.ax === 0) {
      const direita = r.x0 + r.w0;
      const nx = Math.min(r.x0 + dx, direita - MIN_MM);
      patch.x = nx;
      patch.width = direita - nx;
    } else if (r.ax === 1) {
      patch.width = Math.max(MIN_MM, r.w0 + dx);
    }
    if (r.ay === 0) {
      const baixo = r.y0 + r.h0;
      const ny = Math.min(r.y0 + dy, baixo - MIN_MM);
      patch.y = ny;
      patch.height = baixo - ny;
    } else if (r.ay === 1) {
      patch.height = Math.max(MIN_MM, r.h0 + dy);
    }
    r.mudou = true;
    setElement(r.id, patch);
  };

  const aoSoltarAlca = (e: React.PointerEvent) => {
    const r = redim.current;
    redim.current = null;
    e.stopPropagation();
    const alvo = e.currentTarget as Element;
    if (alvo.hasPointerCapture?.(e.pointerId)) alvo.releasePointerCapture(e.pointerId);
    if (r?.mudou) onResizeEnd?.(r.label);
  };

  // Revisao 120/124 — o pai (`flex-1` no card branco) define a altura útil.
  // `height="100%"` + `meet` preenche sem distorcer; getScreenCTM continua
  // refletindo o mapeamento tela↔viewBox (Revisões 109-110). Intocado na 124
  // (só o layout ao redor mudou). Sem min-height fixo no SVG.

  return (
    <svg
      ref={svgRef}
      width="100%"
      height="100%"
      viewBox={`0 0 ${w} ${h}`}
      preserveAspectRatio="xMidYMid meet"
      className="block h-full min-h-0 w-full flex-1 rounded-2xl bg-[linear-gradient(#eef2f7_1px,transparent_1px),linear-gradient(90deg,#eef2f7_1px,transparent_1px)] [background-size:24px_24px]"
    >
      <defs>
        <filter id="softShadow" x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="0" dy="8" stdDeviation="8" floodOpacity="0.2" />
        </filter>
        <linearGradient id="glassGrad" x1="0" x2="1">
          <stop offset="0" stopColor="#d9f4f0" stopOpacity="0.86" />
          <stop offset="1" stopColor="#b7dad8" stopOpacity="0.75" />
        </linearGradient>
        <linearGradient id="stoneGrad" x1="0" x2="1">
          <stop offset="0" stopColor="#f0eee8" />
          <stop offset="1" stopColor="#bdb7ad" />
        </linearGradient>
        <linearGradient id="woodGrad" x1="0" x2="1">
          <stop offset="0" stopColor="#a66c3a" />
          <stop offset="1" stopColor="#633817" />
        </linearGradient>
      </defs>

      <Dimension
        x1={px(0)}
        y1={py(-260)}
        x2={px(project.width)}
        y2={py(-260)}
        label={`${project.width}`}
      />
      <Dimension
        x1={px(-300)}
        y1={py(0)}
        x2={px(-300)}
        y2={py(project.height)}
        label={`${project.height}`}
        vertical
      />

      {project.elements.map((el: EngineeringElement, index: number) => {
        const selected = el.id === selectedId;
        const x = px(el.x);
        const y = py(el.y);
        const ew = Math.max(2, el.width * scale);
        const eh = Math.max(2, el.height * scale);
        const fill =
          el.kind === "glass"
            ? "url(#glassGrad)"
            : el.kind === "wood"
              ? "url(#woodGrad)"
              : el.kind === "stone"
                ? "url(#stoneGrad)"
                : (el.color ?? "#334155");
        return (
          <g
            key={el.id}
            onClick={() => setSelectedId(el.id)}
            onPointerDown={aoPressionar(el)}
            onPointerMove={aoMover}
            onPointerUp={aoSoltar}
            onPointerCancel={aoSoltar}
            style={{
              cursor: tool === "mover" && !el.locked ? "move" : "pointer",
              touchAction: tool === "mover" ? "none" : undefined,
            }}
          >
            {el.kind === "cutout" ? (
              <rect
                x={x}
                y={y}
                width={ew}
                height={eh}
                rx={10}
                fill={el.color ?? "#111827"}
                opacity="0.9"
                stroke="#0f172a"
                strokeDasharray="7 5"
              />
            ) : (
              <rect
                x={x}
                y={y}
                width={ew}
                height={eh}
                rx={el.kind === "hardware" ? 6 : 0}
                fill={fill}
                stroke={selected ? "#2563eb" : "#0f172a"}
                strokeWidth={selected ? 3 : 1.2}
                filter="url(#softShadow)"
                opacity={el.kind === "glass" ? 0.82 : 1}
              />
            )}
            {el.kind === "glass" && (
              <text
                x={x + ew / 2}
                y={y + eh / 2}
                textAnchor="middle"
                dominantBaseline="middle"
                fontSize="26"
                fontWeight="700"
              >
                {index + 1}
              </text>
            )}
            {el.kind === "hardware" && (
              <circle
                cx={x + ew / 2}
                cy={y + eh / 2}
                r={Math.min(12, ew / 2)}
                fill="#0f172a"
                stroke="#94a3b8"
              />
            )}
            <text x={x + ew / 2} y={y + eh + 18} textAnchor="middle" fontSize="11" fontWeight="700">
              {Math.round(el.width)} x {Math.round(el.height)}
            </text>
          </g>
        );
      })}

      {/* As alças vêm DEPOIS de todas as peças, e não dentro do `<g>` de uma
          delas (Revisao 110).
          Motivo medido, não estético: dentro do grupo, qualquer peça desenhada
          adiante pinta por cima. Com o Vidro 2 selecionado, as três alças da
          borda direita caíam embaixo do Vidro 3 — `elementFromPoint` devolvia o
          retângulo do vizinho — e simplesmente não pegavam. Cinco funcionavam,
          três não, e a diferença era só a ordem de pintura. Numa camada própria
          no fim do SVG, as oito ficam por cima de tudo. */}
      {(() => {
        const sel = project.elements.find((el: EngineeringElement) => el.id === selectedId);
        if (!sel) return null;
        return (
          <SelectionHandles
            x={px(sel.x)}
            y={py(sel.y)}
            w={Math.max(2, sel.width * scale)}
            h={Math.max(2, sel.height * scale)}
            el={sel}
            onPegar={aoPegarAlca}
            onArrastar={aoArrastarAlca}
            onSoltar={aoSoltarAlca}
          />
        );
      })()}
    </svg>
  );
}

function Dimension({
  x1,
  y1,
  x2,
  y2,
  label,
  vertical = false,
}: {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  label: string | number;
  vertical?: boolean;
}) {
  const midX = (x1 + x2) / 2;
  const midY = (y1 + y2) / 2;
  return (
    <g stroke="#111827" fill="#111827" fontSize="13" fontWeight="700">
      <line x1={x1} y1={y1} x2={x2} y2={y2} strokeWidth="1.5" />
      <line x1={x1} y1={y1 - 8} x2={x1} y2={y1 + 8} strokeWidth="1.5" />
      <line x1={x2} y1={y2 - 8} x2={x2} y2={y2 + 8} strokeWidth="1.5" />
      <text
        x={midX}
        y={midY - (vertical ? 0 : 8)}
        textAnchor="middle"
        transform={vertical ? `rotate(-90 ${midX} ${midY})` : undefined}
      >
        {label}
      </text>
    </g>
  );
}

function SelectionHandles({
  x,
  y,
  w,
  h,
  el,
  onPegar,
  onArrastar,
  onSoltar,
}: {
  x: number;
  y: number;
  w: number;
  h: number;
  el: EngineeringElement;
  onPegar: (el: EngineeringElement, ax: number, ay: number) => (e: React.PointerEvent) => void;
  onArrastar: (e: React.PointerEvent) => void;
  onSoltar: (e: React.PointerEvent) => void;
}) {
  return (
    <g>
      {ALCAS.map(({ ax, ay, cursor }) => {
        const cx = x + w * ax;
        const cy = y + h * ay;
        return (
          <g key={`${ax}-${ay}`}>
            {/* Alvo invisível, maior que a alça. A alça desenhada tem 8 unidades
                de viewBox, que na tela dão cerca de 5 px — pequeno demais para
                pegar com o mouse. Este retângulo de 18 leva os handlers e o
                cursor; o azul continua com o tamanho de sempre e sai do caminho
                do ponteiro, senão os dois disputariam o mesmo clique. */}
            <rect
              x={cx - 9}
              y={cy - 9}
              width="18"
              height="18"
              fill="none"
              pointerEvents="all"
              style={{ cursor, touchAction: "none" }}
              onPointerDown={onPegar(el, ax, ay)}
              onPointerMove={onArrastar}
              onPointerUp={onSoltar}
              onPointerCancel={onSoltar}
            />
            <rect
              x={cx - 4}
              y={cy - 4}
              width="8"
              height="8"
              fill="#2563eb"
              stroke="white"
              pointerEvents="none"
            />
          </g>
        );
      })}
    </g>
  );
}

function ThreeLikePreview({ project }: { project: EngineeringProject }) {
  // Revisao 119 — isto NÃO é Three.js / WebGL.
  // É CSS com perspective + rotateX/translateZ (falsa profundidade).
  // Existe um Studio3D real (`src/components/projects/Studio3D.tsx` + Product3D /
  // ProjectViewer, ~1.8k linhas, three + R3F/drei) que NENHUMA rota importa hoje.
  // Ligar ou remover esse bloco é decisão de produto futura (Revisão 118).
  const maxWidth = 760;
  const scale = Math.min(maxWidth / project.width, 0.18);
  return (
    <div className="min-h-0 flex-1 overflow-hidden rounded-2xl bg-gradient-to-br from-slate-100 to-slate-300 p-8 text-slate-950">
      <div
        className="relative mx-auto h-[min(48vh,420px)] max-w-[850px]"
        style={{ perspective: 900 }}
      >
        <div className="absolute bottom-2 left-16 right-16 h-28 rotate-x-60 rounded-[40%] bg-slate-400/25 blur-xl" />
        <div
          className="absolute left-10 top-16"
          style={{ transform: "rotateX(58deg) rotateZ(-9deg)", transformStyle: "preserve-3d" }}
        >
          {project.elements
            .filter((e) => ["glass", "wood", "stone", "steel", "profile"].includes(e.kind))
            .map((el, i) => {
              const w = Math.max(30, el.width * scale);
              const h = Math.max(18, el.height * scale);
              return (
                <div
                  key={el.id}
                  className="absolute border border-slate-900/40 shadow-xl"
                  style={{
                    left: el.x * scale,
                    top: el.y * scale,
                    width: w,
                    height: h,
                    background: el.kind === "glass" ? "rgba(183,218,216,.55)" : el.color,
                    transform: `translateZ(${i * 8}px)`,
                  }}
                >
                  <span className="absolute left-1 top-1 text-[10px] font-bold">{el.label}</span>
                </div>
              );
            })}
        </div>
      </div>
      <p className="text-center text-sm text-slate-600">
        Prévia em perspectiva (CSS) — não é WebGL nem Three.js.
      </p>
    </div>
  );
}

function CutPlan({
  project,
  cuts,
}: {
  project: EngineeringProject;
  cuts: ReturnType<typeof generateCutPieces>;
}) {
  return (
    <div className="min-h-0 flex-1 overflow-auto p-4 text-slate-950">
      <div className="mb-4 flex items-center gap-2 font-bold">
        <Scissors size={20} /> Plano de corte com medidas de peça e sobra
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {cuts.map((c) => (
          <div key={c.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-3">
            <div className="mb-2 flex justify-between text-sm font-bold">
              <span>{c.label}</span>
              <span>{c.material}</span>
            </div>
            <svg viewBox="0 0 360 170" className="w-full rounded-xl bg-white">
              <rect x="20" y="20" width="320" height="130" fill="#e2e8f0" stroke="#94a3b8" />
              <rect x="55" y="42" width="250" height="86" fill="#b7dad8" stroke="#0f172a" />
              <text x="180" y="90" textAnchor="middle" fontSize="16" fontWeight="700">
                {c.width} x {c.height}
              </text>
              <text x="180" y="38" textAnchor="middle" fontSize="12">
                sobra largura: {c.sobraLargura} mm cada lado
              </text>
              <text x="180" y="145" textAnchor="middle" fontSize="12">
                sobra altura: {c.sobraAltura} mm
              </text>
            </svg>
          </div>
        ))}
      </div>
    </div>
  );
}

function MaterialList({ project }: { project: EngineeringProject }) {
  return (
    <div className="min-h-0 flex-1 overflow-auto p-4 text-slate-950">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="bg-slate-100 text-left">
            <th className="p-3">Item</th>
            <th className="p-3">Descrição</th>
            <th className="p-3">Qtd</th>
            <th className="p-3">Medida</th>
            <th className="p-3">Custo</th>
          </tr>
        </thead>
        <tbody>
          {project.elements.map((el, i) => (
            <tr key={el.id} className="border-b border-slate-200">
              <td className="p-3">{i + 1}</td>
              <td className="p-3">
                <b>{el.label}</b>
                <br />
                <span className="text-slate-500">{el.material}</span>
              </td>
              <td className="p-3">{el.quantity}</td>
              <td className="p-3">
                {el.width} x {el.height} mm
              </td>
              <td className="p-3">{brl(elementCost(el))}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function PropertyInput({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-slate-400">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-sm text-white outline-none focus:border-cyan-400"
      />
    </label>
  );
}

function PropertyNumber({
  label,
  value,
  onChange,
  suffix,
  prefix,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  suffix?: string;
  prefix?: string;
}) {
  const [draft, setDraft] = useState<string | null>(null);
  const shown = draft ?? toInputValue(value);
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-slate-400">{label}</span>
      <div className="flex items-center rounded-xl border border-white/10 bg-slate-950 focus-within:border-cyan-400">
        {prefix && <span className="pl-3 text-xs text-slate-500">{prefix}</span>}
        <input
          inputMode="decimal"
          value={shown}
          placeholder="Digite o valor"
          onFocus={() => {
            if (value === 0) setDraft("");
          }}
          onChange={(e) => {
            setDraft(e.target.value);
            onChange(parseNumber(e.target.value, value));
          }}
          onBlur={() => setDraft(null)}
          className="w-full bg-transparent px-3 py-2 text-sm text-white outline-none placeholder:text-slate-600"
        />
        {suffix && <span className="pr-3 text-xs text-slate-500">{suffix}</span>}
      </div>
    </label>
  );
}

function SummaryLine({ label, value }: { label: string; value: string }) {
  return (
    <div className="mt-2 flex justify-between text-sm text-slate-300">
      <span>{label}</span>
      <b>{value}</b>
    </div>
  );
}
