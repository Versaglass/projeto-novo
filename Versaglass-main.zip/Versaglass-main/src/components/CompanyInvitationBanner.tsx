import { toast } from "sonner";
import { Building2, Check, X } from "lucide-react";
import {
  useMyPendingCompanyInvitations,
  useRespondCompanyInvitation,
} from "@/hooks/use-company-invitations";
import { useCompany } from "@/contexts/company-context";
import { useAuth } from "@/hooks/use-auth";
import { mensagemDoErro } from "@/lib/erro-mensagem";

const ROLE_LABEL: Record<string, string> = {
  seller: "Vendedor",
  operator: "Operador",
  installer: "Instalador",
  manager: "Gerente",
  admin: "Administrador",
  owner: "Proprietário",
};

/**
 * Banner pós-login (AppShell): convites pendentes de empresas às quais o
 * usuário ainda não é membro ativo (Rev. 247/248).
 */
export function CompanyInvitationBanner() {
  const { user } = useAuth();
  const { refresh } = useCompany();
  const { data: invites = [], isLoading } = useMyPendingCompanyInvitations(!!user);
  const respond = useRespondCompanyInvitation();

  if (!user || isLoading || invites.length === 0) return null;

  const onRespond = async (id: string, action: "accept" | "reject") => {
    if (respond.isPending) return;
    try {
      const result = await respond.mutateAsync({ id, action });
      if (action === "accept") {
        if (result === "accepted" || result === "already_member") {
          toast.success(
            result === "already_member"
              ? "Você já fazia parte desta empresa."
              : "Convite aceito. A empresa está disponível no seletor.",
          );
          await refresh();
        } else if (result === "expired") {
          toast.error("Este convite expirou.");
        } else {
          toast.info(`Convite: ${result}`);
        }
      } else {
        if (result === "rejected") toast.success("Convite recusado.");
        else if (result === "expired") toast.error("Este convite expirou.");
        else toast.info(`Convite: ${result}`);
      }
    } catch (e: unknown) {
      toast.error(mensagemDoErro(e) ?? "Não foi possível responder ao convite.");
    }
  };

  return (
    <div className="mb-4 space-y-2">
      {invites.map((inv) => (
        <div
          key={inv.id}
          className="flex flex-col gap-3 rounded-2xl border border-gold/40 bg-gold/10 px-4 py-3 sm:flex-row sm:items-center sm:justify-between"
          role="status"
        >
          <div className="flex min-w-0 items-start gap-3">
            <Building2 className="mt-0.5 h-5 w-5 shrink-0 text-gold" />
            <div className="min-w-0">
              <p className="text-sm font-semibold">
                Convite para <span className="text-foreground">{inv.company_name}</span>
              </p>
              <p className="text-xs text-muted-foreground">
                Papel: {ROLE_LABEL[inv.proposed_role] ?? inv.proposed_role}
                {inv.invited_by_nome ? ` · por ${inv.invited_by_nome}` : ""}
                {" · "}
                válido até {new Date(inv.expires_at).toLocaleDateString("pt-BR")}
              </p>
            </div>
          </div>
          <div className="flex shrink-0 flex-wrap gap-2">
            <button
              type="button"
              disabled={respond.isPending}
              onClick={() => onRespond(inv.id, "reject")}
              className="inline-flex items-center gap-1.5 rounded-lg border border-input bg-background px-3 py-1.5 text-xs font-medium hover:bg-accent disabled:opacity-50"
            >
              <X className="h-3.5 w-3.5" /> Recusar
            </button>
            <button
              type="button"
              disabled={respond.isPending}
              onClick={() => onRespond(inv.id, "accept")}
              className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-gold px-3 py-1.5 text-xs font-semibold text-gold-foreground shadow-glow disabled:opacity-50"
            >
              <Check className="h-3.5 w-3.5" /> Aceitar
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
