import { Check, FileText, Hammer, Wrench, Wallet, type LucideIcon } from "lucide-react";

export type Stage = "orcamento" | "producao" | "instalacao" | "pago";

const STAGES: { key: Stage; label: string; icon: LucideIcon }[] = [
  { key: "orcamento", label: "Orçamento", icon: FileText },
  { key: "producao", label: "Produção", icon: Hammer },
  { key: "instalacao", label: "Instalação", icon: Wrench },
  { key: "pago", label: "Pago", icon: Wallet },
];

export function PipelineStatus({
  current,
  compact = false,
}: {
  current: Stage;
  compact?: boolean;
}) {
  const idx = STAGES.findIndex((s) => s.key === current);
  return (
    <div className="flex items-center gap-1">
      {STAGES.map((s, i) => {
        const done = i < idx;
        const active = i === idx;
        const Icon = s.icon;
        return (
          <div key={s.key} className="flex items-center gap-1">
            <div
              className={`grid place-items-center rounded-full transition ${
                compact ? "h-6 w-6" : "h-8 w-8"
              } ${
                done
                  ? "bg-[oklch(0.62_0.15_150)] text-white"
                  : active
                    ? "bg-gradient-gold text-gold-foreground shadow-glow"
                    : "bg-muted text-muted-foreground"
              }`}
              title={s.label}
            >
              {done ? (
                <Check className={compact ? "h-3 w-3" : "h-4 w-4"} />
              ) : (
                <Icon className={compact ? "h-3 w-3" : "h-4 w-4"} />
              )}
            </div>
            {!compact && (
              <span
                className={`hidden text-xs font-medium md:inline ${active ? "text-foreground" : "text-muted-foreground"}`}
              >
                {s.label}
              </span>
            )}
            {i < STAGES.length - 1 && (
              <div
                className={`h-px ${compact ? "w-3" : "w-6 md:w-10"} ${done ? "bg-[oklch(0.62_0.15_150)]" : "bg-border"}`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}

// REMOVIDA na Revisão 53: `STAGE_LABEL`.
//
// Era exportada e NÃO tinha um único consumidor — nem em outro arquivo, nem
// dentro deste. Os rótulos que a tela usa vêm do array `STAGES` acima, que já
// carrega `label` em cada item. Mantê-la só para tirar o `export` deixaria uma
// constante morta no arquivo; o que ela custava era derrubar o Fast Refresh do
// módulo inteiro (react-refresh/only-export-components).
