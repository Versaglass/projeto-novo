import { useLayoutEffect, useRef, useState } from "react";
import { aplicarTecla } from "@/lib/mascara-campo";

/**
 * Input com máscara em tempo real — e com o cursor no lugar certo.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * O QUE ESTE COMPONENTE RESOLVE (e o que ele NÃO faz)
 * ────────────────────────────────────────────────────────────────────────────
 * A conta de qual texto e qual posição de cursor resultam de cada tecla está em
 * `aplicarTecla` (`src/lib/mascara-campo.ts`), pura e testada sem navegador.
 * O que sobra aqui é o problema que só existe no React:
 *
 * **Escrever em `input.value` joga o cursor para o fim.** Num input controlado,
 * mascarar no `onChange` faz o React reescrever `value` no commit — que vem
 * DEPOIS do handler e desfaria qualquer `setSelectionRange` feito nele. Por
 * isso a posição é guardada num ref e aplicada em `useLayoutEffect`, que roda
 * depois do commit e antes de o navegador pintar: o cursor nunca é visto no
 * lugar errado.
 *
 * ⚠️ **O contador de render não é enfeite.** Quando a máscara RECUSA a tecla
 * (uma letra na posição do dígito verificador, um 15º caractere), o valor sai
 * igual ao anterior, o `setState` do pai não muda nada, **o React não
 * re-renderiza e o efeito não roda** — e o cursor fica onde o navegador o
 * deixou, no fim da linha. Um estado local trocado a cada tecla garante o
 * render, e o efeito ainda corrige o texto na tela, que o React não reescreveu.
 *
 * **Não valida.** Nunca recusa um valor pela metade — `12.AB` é um estado
 * legítimo de digitação. Quem recusa continua sendo `validarCnpj` /
 * `validarTelefoneBrCom`, no `onBlur` e no envio, como a Revisão 92 deixou.
 *
 * **Não muda o que vai ao banco.** O mascarado é o que o campo mostra; a forma
 * canônica continua saindo de `validarCnpj().cnpj` na hora de gravar.
 */
type Props = Omit<React.InputHTMLAttributes<HTMLInputElement>, "value" | "onChange" | "type"> & {
  /** Valor já mascarado — o componente não remascara o que recebe. */
  value: string;
  /** Recebe o valor JÁ MASCARADO, pronto para ir ao estado. */
  onChange: (valor: string) => void;
  /** A máscara, pura: texto entra, texto sai (`src/lib/mascara-campo.ts`). */
  mascara: (bruto: string) => string;
};

export function CampoMascarado({ value, onChange, mascara, ...resto }: Props) {
  /**
   * 🔴 O elemento vem do EVENTO, não de `ref={…}` no JSX. Não é preferência de
   * estilo: **o plugin de desenvolvimento deste projeto
   * (`@lovable.dev/vite-tanstack-config`) injeta um `ref` próprio em cada
   * elemento JSX** — é o mesmo plugin que carimba `data-tsd-source="arquivo:
   * linha"` no HTML. Ele SUBSTITUI o `ref` declarado aqui, então `ref.current`
   * ficava `null` para sempre e o cursor nunca era corrigido.
   *
   * O sintoma era cruel: a máscara funcionava, o texto saía certo, e só o
   * cursor pulava para o fim — exatamente o defeito que este componente existe
   * para evitar, e só em `npm run dev` (no build de produção o plugin não
   * entra). Medido em Chrome real; o `ref` de callback nunca era chamado.
   *
   * `e.currentTarget` no `onChange` é imune a isso e é sempre o elemento certo:
   * `cursorDesejado` só é preenchido nesse mesmo handler.
   */
  const ref = useRef<HTMLInputElement | null>(null);
  const cursorDesejado = useRef<number | null>(null);
  const [, forcarRender] = useState(0);

  useLayoutEffect(() => {
    const el = ref.current;
    const pos = cursorDesejado.current;
    cursorDesejado.current = null;
    if (!el || pos === null) return;
    // O texto na tela pode ter divergido quando a máscara recusou a tecla: o
    // navegador já inseriu o caractere e o React não teve o que reescrever.
    if (el.value !== value) el.value = value;
    // Sem checar `document.activeElement`: `cursorDesejado` só é preenchido
    // dentro do `onChange`, que só dispara por digitação no próprio campo.
    // (A checagem ainda tornaria isto intestável em Chrome headless, onde
    // `focus()` é no-op — a armadilha de instrumento da Revisão 92 §6.)
    el.setSelectionRange(pos, pos);
  });

  function aoDigitar(e: React.ChangeEvent<HTMLInputElement>) {
    const el = e.currentTarget;
    ref.current = el;
    const r = aplicarTecla({
      bruto: el.value,
      cursor: el.selectionStart ?? el.value.length,
      anterior: value,
      tipo: (e.nativeEvent as InputEvent).inputType,
      mascara,
    });
    cursorDesejado.current = r.cursor;
    onChange(r.valor);
    forcarRender((n) => n + 1);
  }

  return <input value={value} onChange={aoDigitar} {...resto} />;
}
