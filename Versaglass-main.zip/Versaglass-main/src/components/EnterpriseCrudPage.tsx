import { useMemo, useState } from "react";
import { Search, Plus, Download, Upload, Edit, Copy, Trash2, Lock, Filter } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import { useCompany } from "@/contexts/company-context";
import { validaNumeroCampo } from "@/lib/numero-campo";
import { toast } from "sonner";

/**
 * Papéis EMPRESARIAIS que gerem o conteúdo — mesma lista que `app.estoque.tsx`,
 * `app.estoque.$id.tsx`, `app.projetos.tsx` e `app.orcamentos.novo.tsx` já usam,
 * e a mesma das policies (`cm.role in ('owner','admin','manager')`).
 */
const MANAGER_ROLES = ["owner", "admin", "manager"];

export type CrudItem = Record<string, string | number | boolean | undefined> & {
  id: string;
  status?: string;
  categoria?: string;
  nome?: string;
  codigo?: string;
  sku?: string;
};

export type FieldConfig = {
  key: string;
  label: string;
  type?: "text" | "number" | "textarea" | "select" | "currency";
  options?: string[];
  required?: boolean;
};

type Props = {
  title: string;
  subtitle: string;
  badge: string;
  storageKey: string;
  initialData: CrudItem[];
  fields: FieldConfig[];
  categoryField?: string;
  highlight?: string[];
};

/** Campo que o usuário digita como número — `number` ou `currency`. */
const isNumerico = (field: FieldConfig) => field.type === "number" || field.type === "currency";

const formatValue = (value: unknown, type?: string) => {
  if (value === undefined || value === null || value === "") return "—";
  if (type === "currency")
    return Number(value).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  if (typeof value === "boolean") return value ? "Sim" : "Não";
  return String(value);
};

function getStoredData(storageKey: string, initialData: CrudItem[]) {
  if (typeof window === "undefined") return initialData;
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return initialData;
    return JSON.parse(raw) as CrudItem[];
  } catch {
    return initialData;
  }
}

export function EnterpriseCrudPage({
  title,
  subtitle,
  badge,
  storageKey,
  initialData,
  fields,
  categoryField = "categoria",
  highlight = [],
}: Props) {
  const { isAdmin } = useAuth();
  const { companyRole } = useCompany();
  const [items, setItems] = useState<CrudItem[]>(() => getStoredData(storageKey, initialData));
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Todas");
  const [editing, setEditing] = useState<CrudItem | null>(null);

  // CORRIGIDO: era `isAdmin || role === "manager"`, com `role` vindo do
  // `useAuth()` — papel de PLATAFORMA, cujo enum é `admin | vendedor |
  // instalador`. "manager" pertence ao papel EMPRESARIAL (`company_members`),
  // outro sistema. A comparação era sempre falsa e o ramo estava morto: só o
  // admin de plataforma editava. O `@ts-nocheck` no topo do arquivo escondia
  // o erro (TS2367) que teria apontado isso.
  //
  // A correção é ADITIVA: quem editava antes (isAdmin) continua editando.
  //
  // A EXCLUSÃO usa este mesmo `canEdit` desde a Revisão 52. Antes era
  // `disabled={!isAdmin}`, herdado do scaffold inicial junto com a linha
  // quebrada acima. Não era cautela com ação destrutiva — era o MESMO erro de
  // eixo: `isAdmin` é o admin de PLATAFORMA, então nem o dono da empresa
  // conseguia apagar um fornecedor da própria empresa, enquanto um funcionário
  // da VersaGlass conseguia.
  //
  // O projeto não tem nenhum nível de exclusão mais restrito que o de edição:
  // `is_company_admin` (= owner/admin/manager, a mesma lista) libera DELETE em
  // `inventory_items`, `project_templates`, `charges` e `fiscal_invoices`, e na
  // interface `app.projetos.tsx` e `app.estoque.tsx` usam o mesmo gate para
  // editar e excluir. O outro nível que existe, `ADMIN_ROLES` (owner/admin) em
  // `company-context.tsx`, é para gerir PESSOAS (`app.funcionarios.tsx`), não
  // para apagar conteúdo.
  const canEdit = isAdmin || MANAGER_ROLES.includes(companyRole ?? "");
  const categories = useMemo(
    () => ["Todas", ...Array.from(new Set(items.map((i) => String(i[categoryField] || "Geral"))))],
    [items, categoryField],
  );
  const fieldMap = useMemo(() => Object.fromEntries(fields.map((f) => [f.key, f])), [fields]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter((item) => {
      const matchesCategory =
        category === "Todas" || String(item[categoryField] || "Geral") === category;
      const matchesQuery = !q || Object.values(item).join(" ").toLowerCase().includes(q);
      return matchesCategory && matchesQuery;
    });
  }, [items, query, category, categoryField]);

  const persist = (next: CrudItem[]) => {
    setItems(next);
    if (typeof window !== "undefined") localStorage.setItem(storageKey, JSON.stringify(next));
  };

  const createBlank = () => {
    const blank: CrudItem = { id: crypto.randomUUID(), status: "Ativo" };
    fields.forEach((field) => {
      if (field.key !== "id" && blank[field.key] === undefined) blank[field.key] = "";
    });
    setEditing(blank);
  };

  const save = () => {
    if (!editing) return;
    // Revisão 32 — os campos `number`/`currency` são digitados como TEXTO e só
    // viram número aqui. Entrada que não é número em formato nenhum RECUSA o
    // salvamento com mensagem; antes ela virava `0` (ou `NaN` exibido como
    // "R$ NaN") sem que nada na tela dissesse o que houve.
    const numerico: CrudItem = { ...editing };
    for (const field of fields) {
      if (field.type !== "number" && field.type !== "currency") continue;
      const r = validaNumeroCampo(editing[field.key], {
        label: field.label.toLowerCase(),
        // Sem `min`: um CRUD genérico tem campo que aceita negativo (saldo,
        // ajuste, variação). A recusa aqui é de entrada ILEGÍVEL, não de sinal.
        min: -Infinity,
        casas: field.type === "currency" ? 2 : undefined,
      });
      if (!r.ok) return toast.error(r.erro);
      numerico[field.key] = editing[field.key] === "" ? "" : r.valor;
    }
    const exists = items.some((i) => i.id === numerico.id);
    const next = exists
      ? items.map((i) => (i.id === numerico.id ? numerico : i))
      : [numerico, ...items];
    persist(next);
    setEditing(null);
    toast.success("Cadastro salvo com sucesso");
  };

  const duplicate = (item: CrudItem) => {
    if (!canEdit) return toast.error("Sem permissão para duplicar");
    persist([
      {
        ...item,
        id: crypto.randomUUID(),
        codigo: item.codigo ? `${item.codigo}-COPIA` : undefined,
        sku: item.sku ? `${item.sku}-COPIA` : undefined,
      },
      ...items,
    ]);
    toast.success("Registro duplicado");
  };

  const remove = (item: CrudItem) => {
    if (!canEdit) return toast.error("Sem permissão para excluir");
    persist(items.filter((i) => i.id !== item.id));
    toast.success("Registro removido com auditoria local");
  };

  const exportCsv = () => {
    const headers = fields.map((f) => f.key);
    const rows = [
      headers.join(";"),
      ...items.map((item) =>
        headers.map((h) => `"${String(item[h] ?? "").replaceAll('"', '""')}"`).join(";"),
      ),
    ];
    const blob = new Blob([rows.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${storageKey}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const primaryFields = highlight.length ? highlight : fields.slice(0, 6).map((f) => f.key);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <Badge variant="secondary" className="mb-3">
            {badge}
          </Badge>
          <h1 className="font-display text-3xl font-bold">{title}</h1>
          <p className="mt-2 max-w-3xl text-sm text-muted-foreground">{subtitle}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={exportCsv} className="gap-2">
            <Download className="h-4 w-4" /> Exportar CSV
          </Button>
          <Button
            variant="outline"
            className="gap-2"
            onClick={() => toast.info("Importação CSV/XLSX pronta para ligar ao Supabase Storage.")}
          >
            <Upload className="h-4 w-4" /> Importar
          </Button>
          <Button onClick={createBlank} disabled={!canEdit} className="gap-2">
            <Plus className="h-4 w-4" /> Novo
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="grid gap-3 p-4 md:grid-cols-[1fr_260px]">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar por código, nome, CPF/CNPJ, telefone, SKU ou descrição"
              className="pl-9"
            />
          </div>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger>
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {categories.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {editing && (
        <Card className="border-gold/50">
          <CardHeader>
            <CardTitle>
              {items.some((i) => i.id === editing.id) ? "Editar cadastro" : "Novo cadastro"}
            </CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {fields.map((field) => (
              <label
                key={field.key}
                className={field.type === "textarea" ? "md:col-span-2 xl:col-span-3" : ""}
              >
                <span className="mb-1 block text-xs font-medium text-muted-foreground">
                  {field.label}
                </span>
                {field.type === "textarea" ? (
                  <Textarea
                    value={String(editing[field.key] ?? "")}
                    onChange={(e) => setEditing({ ...editing, [field.key]: e.target.value })}
                  />
                ) : field.type === "select" ? (
                  <Select
                    value={String(editing[field.key] ?? "")}
                    onValueChange={(value) => setEditing({ ...editing, [field.key]: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {field.options?.map((o) => (
                        <SelectItem key={o} value={o}>
                          {o}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  // Campo numérico é `type="text"` + `inputMode="decimal"`, NUNCA
                  // `type="number"`: este último descarta a vírgula de "89,90"
                  // antes do handler e entrega `""`. Guardamos o texto e a
                  // conversão acontece uma vez só, em `save()`.
                  <Input
                    type="text"
                    inputMode={isNumerico(field) ? "decimal" : undefined}
                    value={String(editing[field.key] ?? "")}
                    placeholder={isNumerico(field) ? "Ex.: 89,90" : undefined}
                    onChange={(e) => setEditing({ ...editing, [field.key]: e.target.value })}
                  />
                )}
              </label>
            ))}
            <div className="flex gap-2 md:col-span-2 xl:col-span-3">
              <Button onClick={save}>Salvar</Button>
              <Button variant="outline" onClick={() => setEditing(null)}>
                Cancelar
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="cards" className="space-y-4">
        <TabsList>
          <TabsTrigger value="cards">Cards</TabsTrigger>
          <TabsTrigger value="table">Tabela</TabsTrigger>
        </TabsList>
        <TabsContent value="cards" className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((item) => (
            <Card key={item.id}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <CardTitle className="text-lg">
                      {item.nome || item.codigo || item.sku || item.id}
                    </CardTitle>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {item.categoria || item[categoryField] || "Geral"}
                    </p>
                  </div>
                  <Badge variant={item.status === "Ativo" ? "default" : "secondary"}>
                    {item.status || "Ativo"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid gap-2 text-sm">
                  {primaryFields.map((key) => (
                    <div key={key} className="flex justify-between gap-3 border-b pb-1">
                      <span className="text-muted-foreground">{fieldMap[key]?.label || key}</span>
                      <span className="text-right font-medium">
                        {formatValue(item[key], fieldMap[key]?.type)}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="flex flex-wrap gap-2 pt-2">
                  <Button
                    size="sm"
                    variant="secondary"
                    disabled={!canEdit}
                    onClick={() => setEditing(item)}
                    className="gap-1"
                  >
                    <Edit className="h-3.5 w-3.5" /> Editar
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={!canEdit}
                    onClick={() => duplicate(item)}
                    className="gap-1"
                  >
                    <Copy className="h-3.5 w-3.5" /> Duplicar
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    disabled={!canEdit}
                    onClick={() => remove(item)}
                    className="gap-1"
                  >
                    {canEdit ? (
                      <Trash2 className="h-3.5 w-3.5" />
                    ) : (
                      <Lock className="h-3.5 w-3.5" />
                    )}{" "}
                    Excluir
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
        <TabsContent value="table">
          <Card>
            <CardContent className="overflow-x-auto p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    {fields.slice(0, 8).map((f) => (
                      <TableHead key={f.key}>{f.label}</TableHead>
                    ))}
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((item) => (
                    <TableRow key={item.id}>
                      {fields.slice(0, 8).map((f) => (
                        <TableCell key={f.key}>{formatValue(item[f.key], f.type)}</TableCell>
                      ))}
                      <TableCell>
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={!canEdit}
                          onClick={() => setEditing(item)}
                        >
                          Editar
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
