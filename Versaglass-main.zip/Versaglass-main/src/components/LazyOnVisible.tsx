import { Suspense, useEffect, useRef, useState, type ReactNode } from "react";

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  rootMargin?: string;
  /** Unmount children when they leave the viewport (frees WebGL contexts, etc.) */
  unmountOnHidden?: boolean;
  className?: string;
}

/**
 * Renders `children` only when scrolled into view.
 * Optionally unmounts them again when they leave, so heavy resources
 * (3D scenes, video, canvas) are released.
 */
export function LazyOnVisible({
  children,
  fallback = null,
  rootMargin = "200px",
  unmountOnHidden = false,
  className,
}: Props) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(false);
  const [hasBeenVisible, setHasBeenVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setVisible(true);
      setHasBeenVisible(true);
      return;
    }
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          setHasBeenVisible(true);
        } else if (unmountOnHidden) {
          setVisible(false);
        }
      },
      { rootMargin },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [rootMargin, unmountOnHidden]);

  const shouldRender = unmountOnHidden ? visible : hasBeenVisible;

  return (
    <div ref={ref} className={className}>
      {shouldRender ? <Suspense fallback={fallback}>{children}</Suspense> : fallback}
    </div>
  );
}

export default LazyOnVisible;
