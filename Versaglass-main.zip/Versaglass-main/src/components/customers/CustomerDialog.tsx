import { useRef, useState } from "react";
import { X } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import type { Client } from "@/hooks/use-clients";
import { CampoMascarado } from "@/components/CampoMascarado";
import { mascararCpfCnpj, mascararTelefoneBr, mascararSalvo } from "@/lib/mascara-campo";
import { validarDocumentoCliente } from "@/lib/documento-cliente";
import { validarTelefoneBr } from "@/lib/whatsapp";

/**
 * E-mail do cliente — mesmo padrão do cadastro da empresa (Revisão 92), com
 * frase deste formulário. `trim` + minúsculas antes de gravar.
 */
const emailClienteSchema = z
  .string()
  .trim()
  .toLowerCase()
  .email("O e-mail do cliente não é válido. Use o formato nome@dominio.com.br.")
  .max(255, "O e-mail do cliente passa de 255 caracteres.");

const customerSchema = z.object({
  nome: z.string().trim().min(1, "Nome obrigatório").max(120),
  endereco: z.string().trim().max(255).optional().or(z.literal("")),
  cidade: z.string().trim().max(120).optional().or(z.literal("")),
  observacoes: z.string().trim().max(1000).optional().or(z.literal("")),
});

/** Valores do formulário (sempre strings; o serviço converte vazio→null). */
export type CustomerFormValues = {
  nome: string;
  documento: string;
  telefone: string;
  email: string;
  endereco: string;
  cidade: string;
  observacoes: string;
};

/**
 * Formulário completo de cliente (CPF/CNPJ, telefone, e-mail, endereço,
 * observações) — Revisões 91–95 / 125–127. Extraído de `/app/clientes` na
 * Rev. 239 para unificar o cadastro em Orçamentos.
 */
export function CustomerDialog({
  title,
  submitLabel,
  initial,
  onClose,
  onSubmit,
  loading,
}: {
  title: string;
  submitLabel: string;
  initial?: Client;
  onClose: () => void;
  onSubmit: (v: CustomerFormValues) => void;
  loading: boolean;
}) {
  const [form, setForm] = useState<CustomerFormValues>({
    nome: initial?.nome ?? "",
    // `mascararSalvo`: só mascara o que o banco já tem se a máscara representar
    // o valor inteiro — evita mutilar lixo legado no primeiro "Salvar".
    documento: mascararSalvo(initial?.documento, mascararCpfCnpj),
    telefone: mascararSalvo(initial?.telefone, mascararTelefoneBr),
    email: initial?.email ?? "",
    endereco: initial?.endereco ?? "",
    cidade: initial?.cidade ?? "",
    observacoes: initial?.observacoes ?? "",
  });
  const [erroDocumento, setErroDocumento] = useState<string | null>(null);
  const [erroTelefone, setErroTelefone] = useState<string | null>(null);
  const [erroEmail, setErroEmail] = useState<string | null>(null);

  const fieldOrder = [
    "nome",
    "documento",
    "telefone",
    "email",
    "endereco",
    "cidade",
    "observacoes",
  ] as const;
  const formRef = useRef<HTMLFormElement>(null);

  /**
   * Travas (Revisão 126) — espelham `/app/conta` (Rev. 92/95).
   *
   * Documento, telefone e e-mail continuam OPCIONAIS. Preenchidos, precisam
   * estar certos. Documento desce canônico (sem máscara); telefone como
   * digitado (máscara é apresentação, igual à empresa).
   */
  const validarFormulario = ():
    | { ok: true; values: CustomerFormValues }
    | { ok: false; erro: string } => {
    const parsed = customerSchema.safeParse(form);
    if (!parsed.success) return { ok: false, erro: parsed.error.issues[0].message };

    const doc = validarDocumentoCliente(form.documento);
    if (!doc.ok) return { ok: false, erro: doc.erro };

    let telefone = "";
    if (form.telefone.trim()) {
      const tel = validarTelefoneBr(form.telefone);
      if (!tel.ok) return { ok: false, erro: tel.erro };
      telefone = form.telefone.trim().slice(0, 20);
    }

    let email = "";
    if (form.email.trim()) {
      const em = emailClienteSchema.safeParse(form.email);
      if (!em.success) return { ok: false, erro: em.error.issues[0].message };
      email = em.data;
    }

    return {
      ok: true,
      values: {
        nome: form.nome.trim(),
        documento: doc.documento,
        telefone,
        email,
        endereco: form.endereco,
        cidade: form.cidade,
        observacoes: form.observacoes,
      },
    };
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    const v = validarFormulario();
    if (!v.ok) {
      toast.error(v.erro);
      return;
    }
    if (v.values.documento) {
      const doc = validarDocumentoCliente(v.values.documento);
      if (doc.ok && doc.formatado) {
        setForm((f) => ({
          ...f,
          documento: doc.formatado,
          email: v.values.email,
        }));
      }
    } else {
      setForm((f) => ({ ...f, email: v.values.email }));
    }
    setErroDocumento(null);
    setErroTelefone(null);
    setErroEmail(null);
    onSubmit(v.values);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, name: string) => {
    if (e.key !== "Enter") return;
    e.preventDefault();
    const idx = fieldOrder.indexOf(name as (typeof fieldOrder)[number]);
    if (idx === -1) return;
    if (idx < fieldOrder.length - 1) {
      const next = fieldOrder[idx + 1];
      const el = formRef.current?.querySelector<HTMLElement>(`[name="${next}"]`);
      el?.focus();
    } else {
      formRef.current?.requestSubmit();
    }
  };

  const inputCls =
    "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring";

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div
        className="w-full max-w-lg rounded-2xl bg-card p-6 shadow-elegant"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-xl font-bold">{title}</h2>
          <button type="button" onClick={onClose} aria-label="Fechar">
            <X className="h-5 w-5" />
          </button>
        </div>
        <form ref={formRef} onSubmit={submit} className="grid grid-cols-2 gap-3">
          <FieldInput
            col={2}
            name="nome"
            label="Nome *"
            value={form.nome}
            onChange={(v) => setForm({ ...form, nome: v })}
            onKeyDown={handleKeyDown}
            autoFocus
          />
          <label className="block">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">CPF/CNPJ</span>
            <CampoMascarado
              name="documento"
              value={form.documento}
              mascara={mascararCpfCnpj}
              inputMode="text"
              placeholder="000.000.000-00 ou 00.000.000/0000-00"
              onChange={(v) => setForm({ ...form, documento: v })}
              onKeyDown={(e) => handleKeyDown(e, "documento")}
              onBlur={() => {
                const r = validarDocumentoCliente(form.documento);
                if (r.ok && r.documento) setForm((f) => ({ ...f, documento: r.formatado }));
                setErroDocumento(r.ok ? null : r.erro);
              }}
              className={inputCls}
            />
            {erroDocumento && <p className="mt-1 text-xs text-destructive">{erroDocumento}</p>}
          </label>
          <label className="block">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">Telefone</span>
            <CampoMascarado
              name="telefone"
              value={form.telefone}
              mascara={mascararTelefoneBr}
              inputMode="tel"
              placeholder="(00) 00000-0000"
              onChange={(v) => setForm({ ...form, telefone: v })}
              onKeyDown={(e) => handleKeyDown(e, "telefone")}
              onBlur={() => {
                if (!form.telefone.trim()) return setErroTelefone(null);
                const r = validarTelefoneBr(form.telefone);
                setErroTelefone(r.ok ? null : r.erro);
              }}
              className={inputCls}
            />
            {erroTelefone && <p className="mt-1 text-xs text-destructive">{erroTelefone}</p>}
          </label>
          <label className="col-span-2 block">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">E-mail</span>
            <input
              name="email"
              type="email"
              value={form.email}
              placeholder="nome@dominio.com.br"
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              onKeyDown={(e) => handleKeyDown(e, "email")}
              onBlur={() => {
                if (!form.email.trim()) return setErroEmail(null);
                const r = emailClienteSchema.safeParse(form.email);
                setErroEmail(r.success ? null : r.error.issues[0].message);
              }}
              className={inputCls}
            />
            {erroEmail && <p className="mt-1 text-xs text-destructive">{erroEmail}</p>}
          </label>
          <FieldInput
            col={2}
            name="endereco"
            label="Endereço"
            value={form.endereco}
            onChange={(v) => setForm({ ...form, endereco: v })}
            onKeyDown={handleKeyDown}
          />
          <FieldInput
            col={2}
            name="cidade"
            label="Cidade"
            value={form.cidade}
            onChange={(v) => setForm({ ...form, cidade: v })}
            onKeyDown={handleKeyDown}
          />
          <label className="col-span-2 block">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">
              Observações
            </span>
            <textarea
              name="observacoes"
              value={form.observacoes}
              onChange={(e) => setForm({ ...form, observacoes: e.target.value })}
              rows={3}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            />
          </label>
          <div className="col-span-2 mt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-input px-4 py-2 text-sm"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={loading}
              className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50"
            >
              {loading ? "Salvando..." : submitLabel}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function FieldInput({
  label,
  value,
  onChange,
  type = "text",
  col = 1,
  name,
  onKeyDown,
  autoFocus,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  col?: 1 | 2;
  name?: string;
  onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>, name: string) => void;
  autoFocus?: boolean;
}) {
  return (
    <label className={col === 2 ? "col-span-2 block" : "block"}>
      <span className="mb-1 block text-xs font-medium text-muted-foreground">{label}</span>
      <input
        name={name}
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={onKeyDown && name ? (e) => onKeyDown(e, name) : undefined}
        autoFocus={autoFocus}
        className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
      />
    </label>
  );
}
