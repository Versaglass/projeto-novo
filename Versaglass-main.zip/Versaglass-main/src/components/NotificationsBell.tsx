import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Bell } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export function NotificationsBell() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let mounted = true;
    async function load() {
      const { count: c } = await supabase
        .from("auth_events")
        .select("*", { count: "exact", head: true })
        .is("read_at", null);
      if (mounted) setCount(c ?? 0);
    }
    load();
    const ch = supabase
      .channel("auth_events_bell")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "auth_events" }, () => {
        setCount((c) => c + 1);
      })
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "auth_events" }, () => {
        load();
      })
      .on("postgres_changes", { event: "DELETE", schema: "public", table: "auth_events" }, () => {
        load();
      })
      .subscribe();
    return () => {
      mounted = false;
      supabase.removeChannel(ch);
    };
  }, []);

  return (
    <Link
      to="/app/admin/notificacoes"
      className="relative inline-flex h-9 w-9 items-center justify-center rounded-lg hover:bg-accent"
      aria-label="Notificações"
    >
      <Bell className="h-5 w-5" />
      {count > 0 && (
        <span className="absolute -top-1 -right-1 inline-flex min-w-[18px] h-[18px] items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">
          {count > 99 ? "99+" : count}
        </span>
      )}
    </Link>
  );
}
