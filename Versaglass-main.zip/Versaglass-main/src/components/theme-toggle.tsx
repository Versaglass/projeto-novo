import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

type ThemeToggleProps = {
  /** Estilo compacto para barra lateral / mobile. */
  variant?: "icon" | "sidebar";
  className?: string;
};

export function ThemeToggle({ variant = "icon", className }: ThemeToggleProps) {
  const { theme, setTheme, resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  if (!mounted) {
    return (
      <div
        className={cn(
          variant === "sidebar" ? "h-10 w-full" : "h-11 w-11",
          className,
        )}
        aria-hidden
      />
    );
  }

  const isDark = (resolvedTheme ?? theme) !== "light";

  const setLight = () => setTheme("light");
  const setDark = () => setTheme("dark");

  if (variant === "sidebar") {
    return (
      <div className={cn("flex gap-1 rounded-lg bg-sidebar-accent/50 p-1", className)}>
        <button
          type="button"
          onClick={setLight}
          className={cn(
            "flex flex-1 items-center justify-center gap-2 rounded-md px-2 py-2 text-xs font-medium transition",
            !isDark
              ? "bg-gold text-gold-foreground shadow-glow"
              : "text-sidebar-foreground/70 hover:text-sidebar-foreground",
          )}
          aria-label="Modo claro"
          aria-pressed={!isDark}
        >
          <Sun className="h-3.5 w-3.5" />
          Claro
        </button>
        <button
          type="button"
          onClick={setDark}
          className={cn(
            "flex flex-1 items-center justify-center gap-2 rounded-md px-2 py-2 text-xs font-medium transition",
            isDark
              ? "bg-gold text-gold-foreground shadow-glow"
              : "text-sidebar-foreground/70 hover:text-sidebar-foreground",
          )}
          aria-label="Modo escuro"
          aria-pressed={isDark}
        >
          <Moon className="h-3.5 w-3.5" />
          Escuro
        </button>
      </div>
    );
  }

  return (
    <div className={cn("flex gap-2", className)}>
      <button
        type="button"
        onClick={setLight}
        className={cn(
          "grid h-11 w-11 place-items-center rounded-2xl border transition",
          !isDark
            ? "border-gold/40 bg-gold/15 text-gold"
            : "border-white/10 bg-white/[0.06] text-slate-200 hover:bg-white/10",
        )}
        aria-label="Modo claro"
        aria-pressed={!isDark}
      >
        <Sun className="h-5 w-5" />
      </button>
      <button
        type="button"
        onClick={setDark}
        className={cn(
          "grid h-11 w-11 place-items-center rounded-2xl border transition",
          isDark
            ? "border-gold/40 bg-gold/15 text-gold"
            : "border-white/10 bg-white/[0.06] text-slate-200 hover:bg-white/10",
        )}
        aria-label="Modo escuro"
        aria-pressed={isDark}
      >
        <Moon className="h-5 w-5" />
      </button>
    </div>
  );
}
