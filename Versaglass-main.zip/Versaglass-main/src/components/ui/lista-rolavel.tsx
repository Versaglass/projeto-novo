import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Lista com altura limitada que DIZ que rola.
 *
 * Nasceu do defeito diagnosticado na Revisão 104: o seletor "Buscar no estoque"
 * mantinha os itens num contêiner de 320 px com `overflow-y-auto` e nenhuma
 * pista de que havia mais coisa abaixo. Com 24 itens ativos — estoque pequeno
 * para uma vidraçaria real — metade ficava fora da área visível, e um item no
 * meio do alfabeto ("LED AMARELO", 51 em estoque) simplesmente não era
 * encontrado. Quem abria a lista, percorria o que via e concluía, com razão pelo
 * que a tela mostrava, que o item "não aparece".
 *
 * A barra de rolagem sozinha NÃO resolve: no macOS e no Windows 11 ela fica
 * oculta até o usuário rolar — ou seja, aparece só para quem já descobriu que
 * dá para rolar. Por isso as pistas aqui são três, e nenhuma depende de hover:
 *
 *   1. `contagem` fixa no topo — quantos itens existem, e quantos o filtro
 *      deixou passar. É a única que continua verdadeira quando a lista NÃO rola;
 *   2. um fade no rodapé, visível apenas enquanto sobra conteúdo abaixo. Some
 *      ao chegar no fim, então serve de indicador de progresso;
 *   3. o rótulo "role para ver mais", que diz em palavras o que o fade sugere —
 *      gradiente é convenção visual, e convenção não é óbvia para todo mundo.
 *
 * O fade é `pointer-events-none` e fica FORA do contêiner rolável: não cobre
 * clique de item nem entra na conta do `scrollHeight`.
 */
export function ListaRolavel({
  children,
  className,
  contagem,
  vazio,
}: {
  children: React.ReactNode;
  /** Classes do contêiner rolável — incluindo a altura máxima e o grid/space-y. */
  className?: string;
  /** Texto do topo, ex. "24 itens" ou "3 de 24 itens". */
  contagem?: React.ReactNode;
  /** Quando true, some com as pistas de rolagem: não há o que rolar. */
  vazio?: boolean;
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [temMais, setTemMais] = useState(false);

  // Recalcula a cada rolagem E a cada mudança de tamanho do conteúdo. O
  // ResizeObserver é o que mantém a pista correta quando a busca filtra a lista
  // (de 24 para 3 itens, por exemplo) sem que nenhum evento de scroll dispare.
  const medir = useCallback(() => {
    const el = ref.current;
    if (!el) return;
    // 2 px de folga: zoom do navegador e arredondamento de layout deixam sobras
    // de fração de pixel que fariam o fade piscar no fim da lista.
    setTemMais(el.scrollHeight - el.clientHeight - el.scrollTop > 2);
  }, []);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    medir();
    const ro = new ResizeObserver(medir);
    ro.observe(el);
    for (const filho of Array.from(el.children)) ro.observe(filho);
    return () => ro.disconnect();
  }, [medir, children]);

  return (
    <div>
      {contagem && !vazio && (
        <div className="mb-2 text-xs font-medium text-muted-foreground">{contagem}</div>
      )}
      <div className="relative">
        <div ref={ref} onScroll={medir} className={cn("overflow-y-auto", className)}>
          {children}
        </div>
        {temMais && (
          <>
            <div className="pointer-events-none absolute inset-x-0 bottom-0 h-12 rounded-b-xl bg-gradient-to-t from-card to-transparent" />
            <div className="pointer-events-none absolute inset-x-0 bottom-1 flex justify-center">
              <span className="flex items-center gap-1 rounded-full bg-card/90 px-2 py-0.5 text-[11px] font-semibold text-muted-foreground shadow-sm">
                <ChevronDown className="h-3 w-3" /> role para ver mais
              </span>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
