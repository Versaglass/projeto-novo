import { useMemo, useState } from "react";
import { Plus, Trash2, X, Save, Scissors, Wrench, DoorOpen, CircleDot } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";
import { numeroParaTexto, textoParaNumero } from "@/lib/numero-campo";
import { mensagemDoErro } from "@/lib/erro-mensagem";
import type { QuoteItemTipoProjeto } from "@/lib/tipo-projeto-orcamento";

type Cutout = {
  id: string;
  tipo: "retangular" | "redondo" | "meia-lua" | "rasgo";
  x: number;
  y: number;
  largura: number;
  altura: number;
  diametro?: number;
  observacao?: string;
};

type Hardware = {
  id: string;
  tipo: string;
  nome: string;
  x: number;
  y: number;
  quantidade: number;
  observacao?: string;
};

export type DrawingData = {
  versao: number;
  tipoProjeto: string;
  larguraMm: number;
  alturaMm: number;
  observacoesTecnicas: string;
  recortes: Cutout[];
  ferragens: Hardware[];
};

/** Campos do item de orçamento que o desenho lê — espelho mínimo, sem any. */
export type DrawingSourceItem = {
  id: string;
  descricao?: string | null;
  largura?: number | null;
  altura?: number | null;
  tipo_projeto?: QuoteItemTipoProjeto | null;
  drawing_notes?: string | null;
  drawing_data?: unknown;
};

const FERRAGENS = [
  "Dobradiça superior",
  "Dobradiça inferior",
  "Puxador H",
  "Puxador cava",
  "Fechadura",
  "Contra-fechadura",
  "Mola hidráulica",
  "Roldana",
  "Trilho superior",
  "Trilho inferior",
  "Suporte tucano",
  "Prolongador",
  "Botão francês",
  "Presilha",
  "Kit box",
];

const RECORTES: Cutout["tipo"][] = ["retangular", "redondo", "meia-lua", "rasgo"];

function defaultDrawing(item: DrawingSourceItem): DrawingData {
  return {
    versao: 1,
    tipoProjeto: item.descricao || "Projeto",
    larguraMm: Math.round(Number(item.largura || 0) * 1000) || 800,
    alturaMm: Math.round(Number(item.altura || 0) * 1000) || 2100,
    observacoesTecnicas: item.drawing_notes || "",
    recortes: [],
    ferragens: [],
  };
}

function normalizeDrawing(item: DrawingSourceItem): DrawingData {
  const raw = item.drawing_data;
  if (raw && typeof raw === "object" && !Array.isArray(raw)) {
    const obj = raw as Partial<DrawingData> & Record<string, unknown>;
    return {
      ...defaultDrawing(item),
      ...obj,
      recortes: Array.isArray(obj.recortes) ? (obj.recortes as Cutout[]) : [],
      ferragens: Array.isArray(obj.ferragens) ? (obj.ferragens as Hardware[]) : [],
    };
  }
  return defaultDrawing(item);
}

function px(v: number, max: number, size: number) {
  if (!max) return 0;
  return Math.max(0, Math.min(size, (v / max) * size));
}

export function ProjectDrawingPreview({
  item,
  compact = false,
}: {
  item: DrawingSourceItem;
  compact?: boolean;
}) {
  const drawing = normalizeDrawing(item);
  const w = Number(drawing.larguraMm) || 800;
  const h = Number(drawing.alturaMm) || 2100;
  const viewW = 360;
  const viewH = 260;
  const scale = Math.min((viewW - 40) / w, (viewH - 40) / h);
  const panelW = w * scale;
  const panelH = h * scale;
  const ox = (viewW - panelW) / 2;
  const oy = (viewH - panelH) / 2;

  return (
    <div className="rounded-xl border border-border bg-background p-3">
      {!compact && (
        <div className="mb-2 flex items-center justify-between gap-2 text-xs text-muted-foreground">
          <span>{drawing.tipoProjeto}</span>
          <span>
            {drawing.larguraMm} × {drawing.alturaMm} mm
          </span>
        </div>
      )}
      <svg viewBox={`0 0 ${viewW} ${viewH}`} className="h-auto w-full rounded-lg bg-muted/40">
        <rect
          x={ox}
          y={oy}
          width={panelW}
          height={panelH}
          rx="4"
          fill="rgba(120,180,255,.16)"
          stroke="currentColor"
          strokeWidth="2"
          className="text-gold"
        />
        <line
          x1={ox}
          y1={oy + 22}
          x2={ox + panelW}
          y2={oy + 22}
          stroke="currentColor"
          strokeDasharray="5 5"
          opacity=".25"
        />
        {drawing.recortes.map((r) => {
          const x = ox + px(r.x, w, panelW);
          const y = oy + px(r.y, h, panelH);
          if (r.tipo === "redondo") {
            const radius = Math.max(5, px((r.diametro || r.largura || 60) / 2, w, panelW));
            return (
              <circle
                key={r.id}
                cx={x}
                cy={y}
                r={radius}
                fill="rgba(0,0,0,.35)"
                stroke="currentColor"
                strokeWidth="1.5"
                className="text-destructive"
              />
            );
          }
          return (
            <rect
              key={r.id}
              x={x}
              y={y}
              width={Math.max(8, px(r.largura, w, panelW))}
              height={Math.max(8, px(r.altura, h, panelH))}
              rx="3"
              fill="rgba(0,0,0,.35)"
              stroke="currentColor"
              strokeWidth="1.5"
              className="text-destructive"
            />
          );
        })}
        {drawing.ferragens.map((f) => {
          const x = ox + px(f.x, w, panelW);
          const y = oy + px(f.y, h, panelH);
          return (
            <g key={f.id}>
              <circle cx={x} cy={y} r="8" fill="rgba(245,190,80,.95)" stroke="rgba(0,0,0,.45)" />
              <text x={x} y={y + 3} textAnchor="middle" fontSize="9" fill="#111">
                F
              </text>
            </g>
          );
        })}
        <text
          x={ox + panelW / 2}
          y={oy + panelH + 16}
          textAnchor="middle"
          fontSize="10"
          fill="currentColor"
          opacity=".65"
        >
          Largura {drawing.larguraMm} mm
        </text>
        <text
          x={Math.max(10, ox - 10)}
          y={oy + panelH / 2}
          textAnchor="middle"
          fontSize="10"
          fill="currentColor"
          opacity=".65"
          transform={`rotate(-90 ${Math.max(10, ox - 10)} ${oy + panelH / 2})`}
        >
          Altura {drawing.alturaMm} mm
        </text>
      </svg>
      {(drawing.recortes.length > 0 || drawing.ferragens.length > 0) && !compact && (
        <div className="mt-3 grid gap-2 text-xs text-muted-foreground sm:grid-cols-2">
          <div>
            <strong className="text-foreground">Recortes:</strong> {drawing.recortes.length}
          </div>
          <div>
            <strong className="text-foreground">Ferragens:</strong> {drawing.ferragens.length}
          </div>
        </div>
      )}
    </div>
  );
}

export function ProjectDrawingEditor({
  item,
  onClose,
  onSaved,
}: {
  item: DrawingSourceItem;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [drawing, setDrawing] = useState<DrawingData>(() => normalizeDrawing(item));
  const [saving, setSaving] = useState(false);
  const totalAlteracoes = useMemo(
    () => drawing.recortes.length + drawing.ferragens.length,
    [drawing],
  );

  const set = (patch: Partial<DrawingData>) => setDrawing((d) => ({ ...d, ...patch }));
  const addCutout = () =>
    setDrawing((d) => ({
      ...d,
      recortes: [
        ...d.recortes,
        {
          id: crypto.randomUUID(),
          tipo: "retangular",
          x: 100,
          y: 100,
          largura: 120,
          altura: 80,
          diametro: 60,
        },
      ],
    }));
  const addHardware = () =>
    setDrawing((d) => ({
      ...d,
      ferragens: [
        ...d.ferragens,
        {
          id: crypto.randomUUID(),
          tipo: "ferragem",
          nome: "Puxador H",
          x: 120,
          y: 1000,
          quantidade: 1,
        },
      ],
    }));

  const updateCutout = (id: string, patch: Partial<Cutout>) =>
    setDrawing((d) => ({
      ...d,
      recortes: d.recortes.map((r) => (r.id === id ? { ...r, ...patch } : r)),
    }));
  const updateHardware = (id: string, patch: Partial<Hardware>) =>
    setDrawing((d) => ({
      ...d,
      ferragens: d.ferragens.map((f) => (f.id === id ? { ...f, ...patch } : f)),
    }));

  const save = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from("quote_items")
        .update({
          drawing_data: drawing as unknown as Json,
          drawing_notes: drawing.observacoesTecnicas || null,
          updated_at: new Date().toISOString(),
        })
        .eq("id", item.id);
      if (error) throw error;
      toast.success("Desenho técnico atualizado");
      onSaved();
      onClose();
    } catch (e: unknown) {
      toast.error(mensagemDoErro(e) || "Erro ao salvar desenho");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
      onClick={onClose}
    >
      <div
        className="grid max-h-[92vh] w-full max-w-6xl overflow-hidden rounded-2xl border border-border bg-card shadow-elegant lg:grid-cols-[1fr_420px]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="overflow-y-auto p-5">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <h2 className="font-display text-2xl font-bold">Editar desenho do projeto</h2>
              <p className="text-sm text-muted-foreground">
                Adicione recortes, furos, rasgos, puxadores, dobradiças, trilhos e outras ferragens
                depois do orçamento criado.
              </p>
            </div>
            <button onClick={onClose} className="rounded-md p-2 hover:bg-accent">
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="grid gap-3 md:grid-cols-3">
            <label className="block md:col-span-3">
              <span className="mb-1 block text-xs font-medium text-muted-foreground">
                Nome do projeto
              </span>
              <input
                value={drawing.tipoProjeto}
                onChange={(e) => set({ tipoProjeto: e.target.value })}
                className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
              />
            </label>
            <NumberInput
              label="Largura final (mm)"
              value={drawing.larguraMm}
              onChange={(v) => set({ larguraMm: v })}
            />
            <NumberInput
              label="Altura final (mm)"
              value={drawing.alturaMm}
              onChange={(v) => set({ alturaMm: v })}
            />
            <div className="rounded-lg border border-border bg-background p-3 text-sm">
              <div className="text-xs text-muted-foreground">Alterações</div>
              <div className="mt-1 font-display text-2xl font-bold text-gold">
                {totalAlteracoes}
              </div>
            </div>
          </div>

          <div className="mt-5 grid gap-4 lg:grid-cols-2">
            <section className="rounded-xl border border-border bg-background p-4">
              <div className="mb-3 flex items-center justify-between gap-2">
                <h3 className="inline-flex items-center gap-2 font-display font-semibold">
                  <Scissors className="h-4 w-4 text-destructive" /> Recortes e furos
                </h3>
                <button
                  onClick={addCutout}
                  className="inline-flex items-center gap-1 rounded-md border border-input px-2.5 py-1.5 text-xs hover:bg-accent"
                >
                  <Plus className="h-3.5 w-3.5" /> Adicionar
                </button>
              </div>
              <div className="space-y-3">
                {drawing.recortes.length === 0 ? (
                  <Empty text="Nenhum recorte adicionado." />
                ) : (
                  drawing.recortes.map((r, idx) => (
                    <div key={r.id} className="rounded-lg border border-border bg-card p-3">
                      <div className="mb-2 flex items-center justify-between">
                        <span className="text-xs font-semibold text-muted-foreground">
                          Recorte {idx + 1}
                        </span>
                        <button
                          onClick={() =>
                            setDrawing((d) => ({
                              ...d,
                              recortes: d.recortes.filter((x) => x.id !== r.id),
                            }))
                          }
                          className="text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <label className="block col-span-2">
                          <span className="mb-1 block text-[10px] uppercase text-muted-foreground">
                            Tipo
                          </span>
                          <select
                            value={r.tipo}
                            onChange={(e) =>
                              updateCutout(r.id, { tipo: e.target.value as Cutout["tipo"] })
                            }
                            className="w-full rounded-md border border-input bg-background px-2 py-1.5 text-xs"
                          >
                            {RECORTES.map((tipo) => (
                              <option key={tipo} value={tipo}>
                                {tipo}
                              </option>
                            ))}
                          </select>
                        </label>
                        <SmallNumber
                          label="X mm"
                          value={r.x}
                          onChange={(v) => updateCutout(r.id, { x: v })}
                        />
                        <SmallNumber
                          label="Y mm"
                          value={r.y}
                          onChange={(v) => updateCutout(r.id, { y: v })}
                        />
                        <SmallNumber
                          label="Largura mm"
                          value={r.largura}
                          onChange={(v) => updateCutout(r.id, { largura: v })}
                        />
                        <SmallNumber
                          label="Altura/diâmetro mm"
                          value={r.tipo === "redondo" ? r.diametro || r.largura : r.altura}
                          onChange={(v) =>
                            updateCutout(
                              r.id,
                              r.tipo === "redondo"
                                ? { diametro: v, largura: v, altura: v }
                                : { altura: v },
                            )
                          }
                        />
                      </div>
                    </div>
                  ))
                )}
              </div>
            </section>

            <section className="rounded-xl border border-border bg-background p-4">
              <div className="mb-3 flex items-center justify-between gap-2">
                <h3 className="inline-flex items-center gap-2 font-display font-semibold">
                  <Wrench className="h-4 w-4 text-gold" /> Ferragens
                </h3>
                <button
                  onClick={addHardware}
                  className="inline-flex items-center gap-1 rounded-md border border-input px-2.5 py-1.5 text-xs hover:bg-accent"
                >
                  <Plus className="h-3.5 w-3.5" /> Adicionar
                </button>
              </div>
              <div className="space-y-3">
                {drawing.ferragens.length === 0 ? (
                  <Empty text="Nenhuma ferragem adicionada." />
                ) : (
                  drawing.ferragens.map((f, idx) => (
                    <div key={f.id} className="rounded-lg border border-border bg-card p-3">
                      <div className="mb-2 flex items-center justify-between">
                        <span className="text-xs font-semibold text-muted-foreground">
                          Ferragem {idx + 1}
                        </span>
                        <button
                          onClick={() =>
                            setDrawing((d) => ({
                              ...d,
                              ferragens: d.ferragens.filter((x) => x.id !== f.id),
                            }))
                          }
                          className="text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <label className="block col-span-2">
                          <span className="mb-1 block text-[10px] uppercase text-muted-foreground">
                            Nome
                          </span>
                          <select
                            value={f.nome}
                            onChange={(e) => updateHardware(f.id, { nome: e.target.value })}
                            className="w-full rounded-md border border-input bg-background px-2 py-1.5 text-xs"
                          >
                            {FERRAGENS.map((nome) => (
                              <option key={nome} value={nome}>
                                {nome}
                              </option>
                            ))}
                          </select>
                        </label>
                        <SmallNumber
                          label="X mm"
                          value={f.x}
                          onChange={(v) => updateHardware(f.id, { x: v })}
                        />
                        <SmallNumber
                          label="Y mm"
                          value={f.y}
                          onChange={(v) => updateHardware(f.id, { y: v })}
                        />
                        <SmallNumber
                          label="Qtd"
                          value={f.quantidade}
                          onChange={(v) => updateHardware(f.id, { quantidade: v })}
                        />
                      </div>
                    </div>
                  ))
                )}
              </div>
            </section>
          </div>

          <label className="mt-5 block">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">
              Observações técnicas
            </span>
            <textarea
              value={drawing.observacoesTecnicas}
              onChange={(e) => set({ observacoesTecnicas: e.target.value })}
              rows={3}
              placeholder="Ex.: recorte para fechadura a 1050 mm do piso, puxador centralizado, lapidar bordas..."
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring"
            />
          </label>
        </div>

        <aside className="border-t border-border bg-background/70 p-5 lg:border-l lg:border-t-0">
          <div className="mb-3 flex items-center gap-2 font-display text-lg font-semibold">
            <DoorOpen className="h-5 w-5 text-gold" /> Prévia técnica
          </div>
          <ProjectDrawingPreview
            item={{ ...item, drawing_data: drawing, drawing_notes: drawing.observacoesTecnicas }}
          />
          <div className="mt-4 rounded-xl border border-border bg-card p-3 text-xs text-muted-foreground">
            <div className="mb-1 inline-flex items-center gap-1 font-semibold text-foreground">
              <CircleDot className="h-3.5 w-3.5" /> Legenda
            </div>
            <p>
              Áreas escuras representam recortes/furos. Pontos amarelos representam ferragens
              posicionadas no projeto.
            </p>
          </div>
          <div className="mt-5 flex gap-2">
            <button
              onClick={onClose}
              className="flex-1 rounded-lg border border-border px-4 py-2 text-sm hover:bg-accent"
            >
              Cancelar
            </button>
            <button
              onClick={save}
              disabled={saving}
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-lg bg-gradient-gold px-4 py-2 text-sm font-semibold text-gold-foreground disabled:opacity-50"
            >
              <Save className="h-4 w-4" /> {saving ? "Salvando..." : "Salvar desenho"}
            </button>
          </div>
        </aside>
      </div>
    </div>
  );
}

/**
 * Campos numericos do editor de desenho (Revisao 32).
 *
 * Eram `type="number"` com `parseFloat(...) || 0`: a virgula era descartada
 * pelo navegador e o `|| 0` zerava a medida no meio da digitacao. Agora o
 * rascunho e TEXTO enquanto o campo tem foco, a conversao aceita virgula e
 * ponto, e entrada ilegivel NAO altera o valor — a borda fica vermelha e o
 * campo se explica, em vez de a peca virar 0 mm calada.
 */
function useNumeroDesenhado(value: number, onChange: (v: number) => void) {
  const [draft, setDraft] = useState<string | null>(null);
  const texto = draft ?? numeroParaTexto(value);
  const invalido = draft !== null && draft.trim() !== "" && Number.isNaN(textoParaNumero(draft));
  const handle = (v: string) => {
    setDraft(v);
    const n = textoParaNumero(v);
    if (!Number.isNaN(n)) onChange(n);
  };
  return { texto, invalido, handle, blur: () => setDraft(null) };
}

const TITULO_INVALIDO =
  "Valor inválido — use apenas números, com vírgula ou ponto na casa decimal (ex.: 1200 ou 89,90).";

function NumberInput({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  const n = useNumeroDesenhado(value, onChange);
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-medium text-muted-foreground">{label}</span>
      <input
        inputMode="decimal"
        value={n.texto}
        onChange={(e) => n.handle(e.target.value)}
        onBlur={n.blur}
        title={n.invalido ? TITULO_INVALIDO : undefined}
        className={`w-full rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:ring-2 ring-ring ${n.invalido ? "border-destructive text-destructive" : "border-input"}`}
      />
      {n.invalido && (
        <span className="mt-1 block text-[10px] text-destructive">{TITULO_INVALIDO}</span>
      )}
    </label>
  );
}

function SmallNumber({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  const n = useNumeroDesenhado(value, onChange);
  return (
    <label className="block">
      <span className="mb-1 block text-[10px] uppercase text-muted-foreground">{label}</span>
      <input
        inputMode="decimal"
        value={n.texto}
        onChange={(e) => n.handle(e.target.value)}
        onBlur={n.blur}
        title={n.invalido ? TITULO_INVALIDO : undefined}
        className={`w-full rounded-md border bg-background px-2 py-1.5 text-xs ${n.invalido ? "border-destructive text-destructive" : "border-input"}`}
      />
    </label>
  );
}

function Empty({ text }: { text: string }) {
  return (
    <div className="rounded-lg border border-dashed border-border p-6 text-center text-xs text-muted-foreground">
      {text}
    </div>
  );
}
