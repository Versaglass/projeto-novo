// =====================================================================
// ⚠️ BLOCO FORA DE USO — "biblioteca bloqueada por assinatura"
//
// Esta tela faz parte de um sistema de assinatura B2C (catálogo de modelos
// premium) que NASCEU NO PRIMEIRO COMMIT do projeto (`a0c7291`, "estado
// inicial recebido") e NUNCA FOI CONECTADO. Está documentado em
// `PLANOS_BIBLIOTECA_ASSINATURA.md`, na raiz do repositório.
//
// Por que "nunca conectado", em fatos (levantamento na Revisão 112):
//
//   • a migration que o documento cita — `20260703030000_subscription_locked_
//     library.sql`, "com tabelas, seeds, funções e RLS" — NÃO EXISTE em
//     `supabase/migrations/`;
//   • as tabelas sobreviveram na baseline (`project_categories`,
//     `project_models`, `plan_model_limits`, `plans`), mas NENHUMA delas tem
//     um único leitor no código, e não há seed em migration alguma;
//   • `user_subscriptions` tem UMA referência em toda a árvore: o `select` de
//     `getUserPlan`. NADA insere. Logo `getUserPlan` devolve sempre "free";
//   • `/planos` e `/upgrade-premium` não têm um `onClick` sequer — não há
//     caminho de upgrade;
//   • `/editor/$modelId` redireciona quando `plan === "free"`, ou seja, para
//     100% dos usuários. A tela do editor é INALCANÇÁVEL hoje;
//   • o bloco é um CIRCUITO FECHADO: `/catalogo`, `/editor/$modelId`,
//     `/planos`, `/upgrade-premium`, `/projeto/$projectId`, `/pdf/$projectId`
//     e as duas telas `/admin/*` só apontam umas para as outras. Nenhuma rota
//     do aplicativo autenticado aponta para dentro dele — nem o menu.
//
// 📌 MANTIDO NO CÓDIGO POR DECISÃO DO RESPONSÁVEL, SEM USO ATIVO.
//    NÃO expandir, NÃO depurar e NÃO usar como referência de padrão até
//    haver decisão de produto. O editor de desenho que funciona é outro:
//    `components/ParametricProjectEditor.tsx` (Projetos › Editar desenho) e
//    `components/engineering/UniversalEngineeringEditor.tsx` (Editor 2D/3D).
// =====================================================================

import { supabase } from "@/integrations/supabase/client";
import { canAccessModel, type PlanSlug } from "@/data/projectLibrary";

export type SubscriptionAccess = {
  plan: PlanSlug;
  isSubscriber: boolean;
  canEdit: boolean;
  canGeneratePdf: boolean;
  canDownloadImage: boolean;
  canSaveProject: boolean;
  canCutList: boolean;
  canMaterialList: boolean;
  canExportDxf: boolean;
  canExportDwg: boolean;
  canExportSvg: boolean;
  canUseAi: boolean;
  canRenderHd: boolean;
};

export const FREE_ACCESS: SubscriptionAccess = {
  plan: "free",
  isSubscriber: false,
  canEdit: false,
  canGeneratePdf: false,
  canDownloadImage: false,
  canSaveProject: false,
  canCutList: false,
  canMaterialList: false,
  canExportDxf: false,
  canExportDwg: false,
  canExportSvg: false,
  canUseAi: false,
  canRenderHd: false,
};

export function accessByPlan(plan: PlanSlug): SubscriptionAccess {
  if (plan === "premium") {
    return {
      plan,
      isSubscriber: true,
      canEdit: true,
      canGeneratePdf: true,
      canDownloadImage: true,
      canSaveProject: true,
      canCutList: true,
      canMaterialList: true,
      canExportDxf: true,
      canExportDwg: true,
      canExportSvg: true,
      canUseAi: true,
      canRenderHd: true,
    };
  }
  if (plan === "pro") {
    return {
      plan,
      isSubscriber: true,
      canEdit: true,
      canGeneratePdf: true,
      canDownloadImage: true,
      canSaveProject: true,
      canCutList: true,
      canMaterialList: true,
      canExportDxf: false,
      canExportDwg: false,
      canExportSvg: false,
      canUseAi: false,
      canRenderHd: false,
    };
  }
  return FREE_ACCESS;
}

export async function getUserPlan(userId?: string | null): Promise<PlanSlug> {
  if (!userId) return "free";
  const { data, error } = await supabase
    .from("user_subscriptions")
    .select("plan_slug,status,expires_at")
    .eq("user_id", userId)
    .eq("status", "active")
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error || !data) return "free";
  if (data.expires_at && new Date(data.expires_at).getTime() < Date.now()) return "free";
  return data.plan_slug === "premium" ? "premium" : data.plan_slug === "pro" ? "pro" : "free";
}

export function modelAccessForPlan(
  plan: PlanSlug,
  categorySlug: string,
  modelIndex: number,
  freePreview?: boolean,
) {
  const allowed = canAccessModel(plan, categorySlug, modelIndex, { freePreview: !!freePreview });
  return {
    allowed,
    reason: allowed
      ? null
      : plan === "pro"
        ? "Disponível no Plano Premium"
        : "Assine para desbloquear",
  };
}
