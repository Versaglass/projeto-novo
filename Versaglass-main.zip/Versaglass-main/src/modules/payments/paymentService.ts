import type { Charge, CreateChargeInput, PaymentAccount, RecurringCharge } from "./types";
import type { PaymentProvider } from "./paymentProvider";
import { calculatePlatformFee, createSplitDraft } from "./splitService";

export function buildChargeDraft(input: CreateChargeInput): Charge {
  const platform_fee = calculatePlatformFee(
    input.amount,
    input.platform_fee_type,
    input.platform_fee_value,
  );
  return {
    id: crypto.randomUUID(),
    company_id: input.company_id,
    customer_id: input.customer_id,
    customer_name: input.customer_name,
    sale_id: input.sale_id,
    order_service_id: input.order_service_id,
    payment_method: input.payment_method,
    status: "pending",
    description: input.description,
    amount: input.amount,
    platform_fee,
    net_amount: Number((input.amount - platform_fee).toFixed(2)),
    due_date: input.due_date,
    paid_at: undefined,
    payment_link: input.payment_link,
    boleto_url: input.boleto_url,
    pix_qrcode: input.pix_qrcode,
    pix_copy_paste: input.pix_copy_paste,
    provider_charge_id: input.provider_charge_id,
    created_at: new Date().toISOString(),
  };
}

export async function createChargeWithProvider(
  input: CreateChargeInput,
  account: PaymentAccount,
  provider: PaymentProvider,
) {
  const draft = buildChargeDraft(input);
  const providerResult = await provider.createCharge(input, account);
  const charge: Charge = { ...draft, ...providerResult };
  const split = createSplitDraft(charge.id, charge.company_id, charge.amount, charge.platform_fee);
  return { charge, split };
}

export function markChargePaid(charge: Charge, paidAt = new Date().toISOString()): Charge {
  return { ...charge, status: "paid", paid_at: paidAt };
}

export function createRecurringDraft(
  input: Omit<RecurringCharge, "id" | "status" | "created_at">,
): RecurringCharge {
  return {
    ...input,
    id: crypto.randomUUID(),
    status: "active",
    created_at: new Date().toISOString(),
  };
}

export function getPaymentShareExample(amount = 1000, platformFee = 20) {
  return {
    gross_amount: amount,
    platform_amount: platformFee,
    company_amount: amount - platformFee,
  };
}
