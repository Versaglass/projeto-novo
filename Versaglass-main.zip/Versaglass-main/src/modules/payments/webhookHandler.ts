import type { Charge } from "./types";
import type { PaymentProvider } from "./paymentProvider";
import { markChargePaid } from "./paymentService";

export async function handlePaymentWebhook(
  payload: unknown,
  provider: PaymentProvider,
  charges: Charge[],
  headers?: Record<string, string>,
) {
  const event = await provider.parseWebhook(payload, headers);
  return charges.map((charge) => {
    if (charge.provider_charge_id !== event.provider_charge_id) return charge;
    if (event.status === "paid") return markChargePaid(charge, event.paid_at);
    return { ...charge, status: event.status };
  });
}
