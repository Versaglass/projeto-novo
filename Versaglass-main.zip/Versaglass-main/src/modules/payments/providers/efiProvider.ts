import type { PaymentProvider } from "../paymentProvider";

type EfiWebhook = {
  txid?: string;
  id?: string;
  status?: string;
};

export const efiProvider: PaymentProvider = {
  name: "efi",
  async createMarketplaceAccount(account) {
    return {
      marketplace_account_id: account.marketplace_account_id || `efi_${account.company_id}`,
      status: "pending",
    };
  },
  async createCharge(input) {
    return {
      provider_charge_id: `efi_charge_${crypto.randomUUID()}`,
      payment_link: input.payment_link || `https://pagamento.exemplo/efi/${crypto.randomUUID()}`,
      status: "pending",
    };
  },
  async cancelCharge() {},
  async refundCharge() {},
  async parseWebhook(payload) {
    const data = (payload ?? {}) as EfiWebhook;
    return {
      provider: "efi",
      provider_charge_id: String(data.txid || data.id || ""),
      status: data.status === "CONCLUIDA" ? "paid" : "pending",
      raw: payload,
    };
  },
  async createSplit(_chargeId, split) {
    return { provider_split_id: `efi_split_${split.id}`, status: "processing" };
  },
};
