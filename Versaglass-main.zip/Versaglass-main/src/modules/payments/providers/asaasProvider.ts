import type { PaymentProvider } from "../paymentProvider";

type AsaasWebhook = {
  id?: string;
  event?: string;
  payment?: { id?: string; paymentDate?: string };
};

export const asaasProvider: PaymentProvider = {
  name: "asaas",
  async createMarketplaceAccount(account) {
    return {
      marketplace_account_id: account.marketplace_account_id || `asaas_${account.company_id}`,
      status: "active",
    };
  },
  async createCharge(input) {
    return {
      provider_charge_id: `asaas_charge_${crypto.randomUUID()}`,
      payment_link: input.payment_link || `https://pagamento.exemplo/asaas/${crypto.randomUUID()}`,
      boleto_url:
        input.payment_method === "boleto"
          ? `https://boleto.exemplo/${crypto.randomUUID()}.pdf`
          : undefined,
      pix_qrcode: input.payment_method === "pix" ? "data:image/png;base64,QR_CODE_PIX" : undefined,
      pix_copy_paste:
        input.payment_method === "pix" ? "00020101021226860014br.gov.bcb.pix" : undefined,
      status: "pending",
    };
  },
  async cancelCharge() {},
  async refundCharge() {},
  async parseWebhook(payload) {
    const data = (payload ?? {}) as AsaasWebhook;
    return {
      provider: "asaas",
      provider_charge_id: data.payment?.id || data.id || "",
      status: data.event === "PAYMENT_RECEIVED" ? "paid" : "pending",
      paid_at: data.payment?.paymentDate,
      raw: payload,
    };
  },
  async createSplit(_chargeId, split) {
    return { provider_split_id: `asaas_split_${split.id}`, status: "done" };
  },
};
