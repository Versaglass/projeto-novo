import type { PaymentProvider } from "../paymentProvider";

type PagarmeWebhook = {
  id?: string;
  data?: { id?: string; status?: string };
};

export const pagarmeProvider: PaymentProvider = {
  name: "pagarme",
  async createMarketplaceAccount(account) {
    return {
      marketplace_account_id: account.marketplace_account_id || `pagarme_${account.company_id}`,
      status: "pending",
    };
  },
  async createCharge(input) {
    return {
      provider_charge_id: `pagarme_charge_${crypto.randomUUID()}`,
      payment_link:
        input.payment_link || `https://pagamento.exemplo/pagarme/${crypto.randomUUID()}`,
      status: "pending",
    };
  },
  async cancelCharge() {},
  async refundCharge() {},
  async parseWebhook(payload) {
    const data = (payload ?? {}) as PagarmeWebhook;
    return {
      provider: "pagarme",
      provider_charge_id: String(data.data?.id || data.id || ""),
      status: data.data?.status === "paid" ? "paid" : "pending",
      raw: payload,
    };
  },
  async createSplit(_chargeId, split) {
    return { provider_split_id: `pagarme_split_${split.id}`, status: "processing" };
  },
};
