import type { RecurringCharge, RecurringFrequency } from "./types";

const daysByFrequency: Record<RecurringFrequency, number> = {
  weekly: 7,
  biweekly: 15,
  monthly: 30,
  quarterly: 90,
  yearly: 365,
};

export function calculateNextChargeDate(currentDate: string, frequency: RecurringFrequency) {
  const date = new Date(`${currentDate}T12:00:00`);
  date.setDate(date.getDate() + daysByFrequency[frequency]);
  return date.toISOString().slice(0, 10);
}

export function advanceRecurringCharge(recurring: RecurringCharge): RecurringCharge {
  const next = calculateNextChargeDate(recurring.next_charge_date, recurring.frequency);
  const finished = recurring.end_date ? next > recurring.end_date : false;
  return { ...recurring, next_charge_date: next, status: finished ? "finished" : recurring.status };
}
