import type {
  CreateChargeInput,
  PaymentAccount,
  PaymentSplit,
  ProviderChargeResponse,
  ChargeStatus,
} from "./types";

export type PaymentWebhookEvent = {
  provider: string;
  provider_charge_id: string;
  status: ChargeStatus;
  paid_at?: string;
  raw: unknown;
};

export interface PaymentProvider {
  name: string;
  createMarketplaceAccount(
    account: PaymentAccount,
  ): Promise<{ marketplace_account_id: string; status: PaymentAccount["status"] }>;
  createCharge(input: CreateChargeInput, account: PaymentAccount): Promise<ProviderChargeResponse>;
  cancelCharge(providerChargeId: string): Promise<void>;
  refundCharge(providerChargeId: string, amount?: number): Promise<void>;
  parseWebhook(payload: unknown, headers?: Record<string, string>): Promise<PaymentWebhookEvent>;
  createSplit(
    chargeId: string,
    split: PaymentSplit,
  ): Promise<{ provider_split_id: string; status: PaymentSplit["status"] }>;
}
