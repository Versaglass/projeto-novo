export type PaymentMethod =
  | "pix"
  | "boleto"
  | "credit_card"
  | "debit_card"
  | "payment_link"
  | "recurring";
export type ChargeStatus = "pending" | "paid" | "overdue" | "canceled" | "refunded" | "failed";
export type RecurringFrequency = "weekly" | "biweekly" | "monthly" | "quarterly" | "yearly";
export type PaymentAccountStatus = "pending" | "active" | "blocked" | "rejected";
export type PlatformFeeType = "fixed" | "percentage";

export type PaymentAccount = {
  id: string;
  company_id: string;
  company_name: string;
  cnpj: string;
  provider: string;
  marketplace_account_id?: string;
  bank_name: string;
  agency: string;
  account_number: string;
  account_type: string;
  pix_key?: string;
  financial_email?: string;
  financial_phone?: string;
  platform_fee_type: PlatformFeeType;
  platform_fee_value: number;
  status: PaymentAccountStatus;
  created_at: string;
};

export type Charge = {
  id: string;
  company_id: string;
  customer_id?: string;
  customer_name: string;
  sale_id?: string;
  order_service_id?: string;
  payment_method: PaymentMethod;
  status: ChargeStatus;
  description: string;
  amount: number;
  platform_fee: number;
  net_amount: number;
  due_date: string;
  paid_at?: string;
  payment_link?: string;
  boleto_url?: string;
  pix_qrcode?: string;
  pix_copy_paste?: string;
  provider_charge_id?: string;
  created_at: string;
};

export type PaymentSplit = {
  id: string;
  charge_id: string;
  company_id: string;
  gross_amount: number;
  platform_amount: number;
  company_amount: number;
  status: "pending" | "processing" | "done" | "failed";
  provider_split_id?: string;
  created_at: string;
};

export type RecurringCharge = {
  id: string;
  company_id: string;
  customer_id?: string;
  customer_name: string;
  amount: number;
  payment_method: PaymentMethod;
  frequency: RecurringFrequency;
  start_date: string;
  end_date?: string;
  next_charge_date: string;
  status: "active" | "paused" | "finished" | "canceled";
  created_at: string;
};

export type CreateChargeInput = Omit<
  Charge,
  "id" | "status" | "platform_fee" | "net_amount" | "created_at"
> & {
  platform_fee_type: PlatformFeeType;
  platform_fee_value: number;
};

export type ProviderChargeResponse = {
  provider_charge_id: string;
  payment_link?: string;
  boleto_url?: string;
  pix_qrcode?: string;
  pix_copy_paste?: string;
  status: ChargeStatus;
};
