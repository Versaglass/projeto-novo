import type { PaymentSplit, PlatformFeeType } from "./types";

export function calculatePlatformFee(amount: number, feeType: PlatformFeeType, feeValue: number) {
  const fee = feeType === "percentage" ? amount * (feeValue / 100) : feeValue;
  return Math.max(0, Math.min(amount, Number(fee.toFixed(2))));
}

export function createSplitDraft(
  chargeId: string,
  companyId: string,
  amount: number,
  platformFee: number,
): PaymentSplit {
  return {
    id: crypto.randomUUID(),
    charge_id: chargeId,
    company_id: companyId,
    gross_amount: amount,
    platform_amount: platformFee,
    company_amount: Number((amount - platformFee).toFixed(2)),
    status: "pending",
    created_at: new Date().toISOString(),
  };
}
