import { Bot, Loader2, Send, User, Volume2, VolumeX } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { AIVoiceButton } from "./AIVoiceButton";
import type { DialogMessage, DialogMode } from "./aiDialogService";

type Props = {
  messages: DialogMessage[];
  sending: boolean;
  voiceReply: boolean;
  mode: DialogMode;
  onToggleVoice: () => void;
  onSend: (text: string) => Promise<void>;
};

export function AIDialogChat({
  messages,
  sending,
  voiceReply,
  mode,
  onToggleVoice,
  onSend,
}: Props) {
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages.length, sending]);

  async function handleSend() {
    const text = input.trim();
    if (!text || sending) return;
    setInput("");
    await onSend(text);
  }

  return (
    <div className="flex h-[calc(100vh-320px)] min-h-[500px] flex-col rounded-2xl border bg-card">
      <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto p-6">
        {messages.length === 0 && (
          <div className="flex h-full flex-col items-center justify-center text-center text-muted-foreground">
            <Bot className="mb-3 h-10 w-10 text-primary" />
            <p className="font-medium">Diga o que você quer que a IA faça no sistema.</p>
            <p className="mt-1 text-sm">
              Ela responde, sugere melhorias e prepara alterações antes de executar.
            </p>
            <div className="mt-4 grid gap-1 text-xs">
              <span>
                Modo atual: <b className="text-foreground">{modeLabel(mode)}</b>
              </span>
            </div>
          </div>
        )}
        {messages.map((m) => (
          <MessageBubble key={m.id} message={m} />
        ))}
        {sending && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Pensando…
          </div>
        )}
      </div>

      <div className="border-t p-4">
        <div className="flex items-end gap-2">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={onToggleVoice}
            title={voiceReply ? "Desativar resposta em áudio" : "Ativar resposta em áudio"}
          >
            {voiceReply ? (
              <Volume2 className="h-4 w-4 text-primary" />
            ) : (
              <VolumeX className="h-4 w-4" />
            )}
          </Button>
          <AIVoiceButton
            onTranscript={(t) => setInput((cur) => (cur ? cur + " " : "") + t)}
            disabled={sending}
          />
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Fale com a IA… (Enter para enviar, Shift+Enter para nova linha)"
            className="min-h-[60px] flex-1 resize-none"
            disabled={sending}
          />
          <Button
            onClick={handleSend}
            disabled={sending || !input.trim()}
            size="icon"
            title="Enviar"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function modeLabel(m: DialogMode) {
  return {
    converse: "Apenas conversar",
    suggest: "Sugerir melhorias",
    plan: "Criar plano de alteração",
    execute: "Executar com confirmação",
  }[m];
}

function MessageBubble({ message }: { message: DialogMessage }) {
  const isUser = message.role === "user";
  return (
    <div className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}>
      <div
        className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full ${isUser ? "bg-primary text-primary-foreground" : "bg-muted"}`}
      >
        {isUser ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
      </div>
      <div
        className={`max-w-[75%] rounded-2xl px-4 py-2.5 ${isUser ? "bg-primary text-primary-foreground" : "bg-muted"}`}
      >
        <p className="whitespace-pre-wrap text-sm">{message.content}</p>
      </div>
    </div>
  );
}
