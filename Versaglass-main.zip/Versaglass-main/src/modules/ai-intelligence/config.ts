// =====================================================================
// Modo seguro da IA Intelligence administrativa (P-26).
//
// A EXECUÇÃO administrativa da IA depende de ~19 tabelas
// (ai_intelligence_commands, _executions, _snapshots, _approvals,
// _rollbacks, _scans, _scan_findings, _logs, _knowledge, ai_agents,
// ai_guided_workflows, integration_*, project_media_changes, ...) que NÃO
// existem no schema atual — vieram de migrations descartadas de propósito na
// baseline (P-19). Enquanto a persistência não é redesenhada, toda ação que
// grava/lê essas tabelas fica desligada por esta flag.
//
// Só a ORIENTAÇÃO da IA (`iaAdvise`, gateway externo) e a PRÉVIA (cálculo no
// cliente) não dependem dessas tabelas e permanecem disponíveis.
//
// REATIVAÇÃO (ver docs/PENDENCIAS_SUPABASE.md → P-26) exige, em conjunto:
//   1. schema curado APROVADO para a feature de IA;
//   2. persistência por SERVER FUNCTIONS + `supabaseAdmin` (padrão P-07),
//      nunca INSERT direto do navegador;
//   3. revisão de RLS (acesso do usuário separado do administrativo).
// NÃO reative recriando as migrations descartadas. Esta é uma constante de
// build: não vira variável de ambiente / `VITE_`, não usa localStorage e não
// pode ser alterada pelo cliente.
// =====================================================================

/** Liga/desliga a execução e a persistência administrativa da IA. */
export const AI_ADMIN_EXECUTION_ENABLED = false as const;

/** Mensagem única e neutra para ações administrativas indisponíveis. */
export const AI_ADMIN_DISABLED_MESSAGE =
  "Recurso em desenvolvimento. A execução administrativa da IA ainda não está disponível.";

/** Erro funcional tipado devolvido quando a execução está desligada. */
export type AIExecutionDisabledResult = {
  ok: false;
  disabled: true;
  code: "ai_admin_execution_disabled";
  message: string;
};

/** Resultado padrão quando a execução administrativa está desligada. */
export function aiExecutionDisabledResult(): AIExecutionDisabledResult {
  return {
    ok: false,
    disabled: true,
    code: "ai_admin_execution_disabled",
    message: AI_ADMIN_DISABLED_MESSAGE,
  };
}
