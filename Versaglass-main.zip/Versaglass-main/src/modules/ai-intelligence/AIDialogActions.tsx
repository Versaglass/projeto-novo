import { Lightbulb, Sparkles, Play } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { DialogSuggestion } from "./aiDialogService";

type Props = {
  suggestions: DialogSuggestion[];
  onUseSuggestion: (s: DialogSuggestion) => void;
  onGeneratePlan: (s: DialogSuggestion) => void;
};

const riskColor: Record<string, string> = {
  baixo: "bg-green-500/10 text-green-600 border-green-500/20",
  medio: "bg-yellow-500/10 text-yellow-600 border-yellow-500/20",
  alto: "bg-orange-500/10 text-orange-600 border-orange-500/20",
  critico: "bg-red-500/10 text-red-600 border-red-500/20",
};

export function AIDialogActions({ suggestions, onUseSuggestion, onGeneratePlan }: Props) {
  if (!suggestions.length) {
    return (
      <div className="rounded-2xl border border-dashed bg-muted/40 p-8 text-center">
        <Lightbulb className="mx-auto mb-3 h-8 w-8 text-muted-foreground" />
        <p className="text-sm text-muted-foreground">
          Nenhuma sugestão ainda. Converse com a IA e ela vai propor melhorias e ações.
        </p>
      </div>
    );
  }

  return (
    <div className="grid gap-3">
      {suggestions.map((s) => (
        <div key={s.id} className="rounded-2xl border bg-card p-4">
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1">
              <div className="mb-2 flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" />
                <h3 className="font-semibold">{s.title}</h3>
                <Badge variant="outline" className={riskColor[s.risk]}>
                  Risco {s.risk}
                </Badge>
                {s.applied && <Badge variant="secondary">Aplicada</Badge>}
              </div>
              {s.description && <p className="text-sm text-muted-foreground">{s.description}</p>}
            </div>
            <div className="flex flex-col gap-2">
              <Button size="sm" variant="outline" onClick={() => onUseSuggestion(s)}>
                Usar no chat
              </Button>
              <Button size="sm" onClick={() => onGeneratePlan(s)} className="gap-1">
                <Play className="h-3 w-3" /> Gerar plano
              </Button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
