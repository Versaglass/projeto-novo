import { supabase } from "@/integrations/supabase/client";

export type DialogMode = "converse" | "suggest" | "plan" | "execute";
export type MessageRole = "user" | "assistant" | "system";
export type PreviewStatus = "pending" | "approved" | "rejected" | "executed";
export type Risk = "baixo" | "medio" | "alto" | "critico";

export type DialogSession = {
  id: string;
  user_id: string;
  title: string;
  mode: DialogMode;
  status: "active" | "archived";
  created_at: string;
  updated_at: string;
};

export type DialogMessage = {
  id: string;
  session_id: string;
  role: MessageRole;
  content: string;
  audio_url?: string | null;
  tokens?: number | null;
  metadata?: Record<string, unknown>;
  created_at: string;
};

export type DialogSuggestion = {
  id: string;
  session_id: string;
  message_id?: string | null;
  title: string;
  description?: string | null;
  risk: Risk;
  applied: boolean;
  created_at: string;
};

export type DialogActionPreview = {
  id: string;
  session_id: string;
  message_id?: string | null;
  intent: Record<string, unknown>;
  preview: Record<string, unknown>;
  snapshot?: Record<string, unknown> | null;
  risk: Risk;
  status: PreviewStatus;
  created_at: string;
  updated_at: string;
};

export type DialogExecution = {
  id: string;
  preview_id?: string;
  success: boolean;
  error?: string | null;
  result?: unknown;
  rollback_available?: boolean;
  created_at: string;
};

const T = {
  sessions: "ai_dialog_sessions" as const,
  messages: "ai_dialog_messages" as const,
  suggestions: "ai_dialog_suggestions" as const,
  previews: "ai_dialog_action_previews" as const,
  executions: "ai_dialog_executions" as const,
};

export async function createSession(
  userId: string,
  title = "Nova conversa",
  mode: DialogMode = "converse",
) {
  const { data, error } = await supabase
    .from(T.sessions as any)
    .insert({ user_id: userId, title, mode })
    .select("*")
    .single();
  if (error) throw error;
  return data as unknown as DialogSession;
}

export async function listSessions(): Promise<DialogSession[]> {
  const { data, error } = await supabase
    .from(T.sessions as any)
    .select("*")
    .order("updated_at", { ascending: false })
    .limit(50);
  if (error) throw error;
  return (data as any) || [];
}

export async function updateSession(
  id: string,
  patch: Partial<Pick<DialogSession, "title" | "mode" | "status">>,
) {
  const { error } = await supabase
    .from(T.sessions as any)
    .update(patch)
    .eq("id", id);
  if (error) throw error;
}

export async function deleteSession(id: string) {
  const { error } = await supabase
    .from(T.sessions as any)
    .delete()
    .eq("id", id);
  if (error) throw error;
}

export async function listMessages(sessionId: string): Promise<DialogMessage[]> {
  const { data, error } = await supabase
    .from(T.messages as any)
    .select("*")
    .eq("session_id", sessionId)
    .order("created_at", { ascending: true });
  if (error) throw error;
  return (data as any) || [];
}

export async function addMessage(
  sessionId: string,
  role: MessageRole,
  content: string,
  metadata: Record<string, unknown> = {},
) {
  const { data, error } = await supabase
    .from(T.messages as any)
    .insert({ session_id: sessionId, role, content, metadata })
    .select("*")
    .single();
  if (error) throw error;
  await supabase
    .from(T.sessions as any)
    .update({ updated_at: new Date().toISOString() })
    .eq("id", sessionId);
  return data as unknown as DialogMessage;
}

export async function saveSuggestions(
  sessionId: string,
  messageId: string,
  suggestions: { title: string; description?: string; risk?: Risk }[],
) {
  if (!suggestions.length) return [];
  const rows = suggestions.map((s) => ({
    session_id: sessionId,
    message_id: messageId,
    title: s.title,
    description: s.description || null,
    risk: s.risk || "baixo",
  }));
  const { data, error } = await supabase
    .from(T.suggestions as any)
    .insert(rows)
    .select("*");
  if (error) throw error;
  return data as any as DialogSuggestion[];
}

export async function listSuggestions(sessionId: string): Promise<DialogSuggestion[]> {
  const { data, error } = await supabase
    .from(T.suggestions as any)
    .select("*")
    .eq("session_id", sessionId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data as any) || [];
}

export async function markSuggestionApplied(id: string) {
  const { error } = await supabase
    .from(T.suggestions as any)
    .update({ applied: true })
    .eq("id", id);
  if (error) throw error;
}

export async function createPreview(input: {
  sessionId: string;
  messageId?: string;
  intent: Record<string, unknown>;
  preview: Record<string, unknown>;
  snapshot?: Record<string, unknown> | null;
  risk: Risk;
}): Promise<DialogActionPreview> {
  const { data, error } = await supabase
    .from(T.previews as any)
    .insert({
      session_id: input.sessionId,
      message_id: input.messageId || null,
      intent: input.intent,
      preview: input.preview,
      snapshot: input.snapshot || null,
      risk: input.risk,
    })
    .select("*")
    .single();
  if (error) throw error;
  return data as unknown as DialogActionPreview;
}

export async function listPreviews(sessionId: string): Promise<DialogActionPreview[]> {
  const { data, error } = await supabase
    .from(T.previews as any)
    .select("*")
    .eq("session_id", sessionId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data as any) || [];
}

export async function updatePreviewStatus(id: string, status: PreviewStatus) {
  const { error } = await supabase
    .from(T.previews as any)
    .update({ status })
    .eq("id", id);
  if (error) throw error;
}

export async function recordExecution(input: {
  previewId: string;
  executedBy: string;
  result: Record<string, unknown>;
  success: boolean;
  rollbackAvailable: boolean;
  error?: string | null;
}) {
  const { data, error } = await supabase
    .from(T.executions as any)
    .insert({
      preview_id: input.previewId,
      executed_by: input.executedBy,
      result: input.result,
      success: input.success,
      rollback_available: input.rollbackAvailable,
      error: input.error || null,
    })
    .select("*")
    .single();
  if (error) throw error;
  return data as unknown as DialogExecution;
}

export async function listExecutions(sessionId: string) {
  const previews = await listPreviews(sessionId);
  if (!previews.length) return [];
  const ids = previews.map((p) => p.id);
  const { data, error } = await supabase
    .from(T.executions as any)
    .select("*")
    .in("preview_id", ids)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return { previews, executions: ((data as unknown as DialogExecution[] | null) || []) };
}
