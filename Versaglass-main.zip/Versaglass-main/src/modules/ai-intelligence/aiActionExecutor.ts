import { supabase } from "@/integrations/supabase/client";
import {
  confirmAdminPassword,
  executeIAAction,
  saveIACommand,
  type IAActionPlan,
} from "@/lib/ia-intelligence";
import { logAuditEvent } from "@/lib/logging.functions";
import { runLogCall } from "@/lib/server-log";
import { AI_ADMIN_DISABLED_MESSAGE, AI_ADMIN_EXECUTION_ENABLED } from "./config";
import { recordExecution, updatePreviewStatus, type DialogActionPreview } from "./aiDialogService";
import { mensagemDoErro } from "@/lib/erro-mensagem";

export type ExecuteInput = {
  preview: DialogActionPreview;
  actionPlan: IAActionPlan;
  originalCommand: string;
  userEmail: string;
  userId: string;
  password?: string;
  skipPassword?: boolean;
};

/**
 * Confirma senha ADM (opcional enquanto ai_password_enabled = false),
 * executa a ação, grava execução e audit_log e atualiza status da prévia.
 */
export async function executeApprovedAction(input: ExecuteInput) {
  // Modo seguro (P-26): a execução administrativa depende de tabelas ausentes.
  // Defesa em profundidade — não confia só no botão desabilitado. Interrompe
  // ANTES de consultar qualquer tabela e ANTES de `recordExecution`; não gera
  // auditoria (um clique bloqueado por flag não é falha real — evitar ruído).
  // Quando a flag voltar a ser `true`, este guard some e o fluxo (inclusive a
  // correção do caminho de erro abaixo) volta intacto.
  if (!AI_ADMIN_EXECUTION_ENABLED) {
    throw new Error(AI_ADMIN_DISABLED_MESSAGE);
  }

  const { preview, actionPlan, originalCommand, userEmail, userId, password, skipPassword } = input;
  if (!skipPassword && password) {
    await confirmAdminPassword(userEmail, password);
  }

  const commandId = await saveIACommand(userId, originalCommand, actionPlan).catch(() => undefined);

  let result: unknown;
  try {
    result = await executeIAAction(actionPlan, userId, commandId);
  } catch (e: unknown) {
    // Auditoria do erro PRIMEIRO e independente da persistência operacional.
    // `writeAudit` passa por `runLogCall`, que trata a própria falha e NUNCA lança
    // — então não esconde o erro original, não vira laço de log e não pode ser
    // impedida por uma falha de `recordExecution`. A sanitização do P-07 é
    // preservada (o metadata vai por `logAuditEvent`).
    await writeAudit(userId, "ai_dialog.execute_error", {
      previewId: preview.id,
      error: mensagemDoErro(e),
    });
    // Registro operacional é secundário: se falhar (tabela ausente, FK, RLS) a
    // falha é reportada, não engolida, e não substitui o erro principal.
    await safeRecordExecution({
      previewId: preview.id,
      executedBy: userId,
      result: {},
      success: false,
      rollbackAvailable: !!preview.snapshot,
      error: mensagemDoErro(e) || String(e),
    });
    throw e; // erro original preservado para a UI
  }

  // Execução deu certo: auditoria e bookkeeping não podem derrubá-la nem
  // transformá-la em erro. A auditoria de sucesso vem antes do registro
  // operacional; ambos são resilientes daqui em diante.
  await writeAudit(userId, "ai_dialog.execute", {
    previewId: preview.id,
    plan: actionPlan.title,
    risk: actionPlan.risk,
  });
  try {
    await updatePreviewStatus(preview.id, "executed");
  } catch (bookErr: unknown) {
    console.warn(
      `[ai:execute] updatePreviewStatus falhou (${mensagemDoErro(bookErr) || String(bookErr)})`,
    );
  }
  await safeRecordExecution({
    previewId: preview.id,
    executedBy: userId,
    result: (result || { ok: true }) as Record<string, unknown>,
    success: true,
    rollbackAvailable: !!preview.snapshot,
  });
  return { ok: true as const, result };
}

/**
 * Registro operacional resiliente em `ai_dialog_executions`. NUNCA lança: uma
 * falha aqui (tabela ausente, FK, RLS) é secundária ao fluxo principal — é
 * reportada no console, sem ser engolida em silêncio e sem mascarar o resultado
 * ou o erro que a chamou. Não chama helper de log (evita laço).
 */
async function safeRecordExecution(input: Parameters<typeof recordExecution>[0]) {
  try {
    await recordExecution(input);
  } catch (recErr: unknown) {
    console.warn(
      `[ai:execute] recordExecution falhou (${mensagemDoErro(recErr) || String(recErr)})`,
    );
  }
}

export type SafeExecuteResult =
  | { ok: true; result: any }
  | { ok: false; needsCode: boolean; message: string; error?: string };

/**
 * Wrapper defensivo: detecta ausência de tabela/estrutura no Supabase e
 * devolve um resultado tratável para a UI oferecer a geração de código.
 */
export async function safeExecuteAction(input: ExecuteInput): Promise<SafeExecuteResult> {
  // Modo seguro (P-26): execução desligada devolve resultado funcional tipado,
  // SEM tocar em nenhuma tabela e SEM oferecer "gerar código/migration" (as
  // migrations descartadas não devem ser recriadas). `needsCode: false` para a
  // UI mostrar só a mensagem neutra.
  if (!AI_ADMIN_EXECUTION_ENABLED) {
    return { ok: false, needsCode: false, message: AI_ADMIN_DISABLED_MESSAGE };
  }

  const { actionPlan } = input;
  if (!actionPlan?.targetTable) {
    return {
      ok: false,
      needsCode: true,
      message:
        "Essa ação ainda não possui destino técnico definido. Posso gerar o código para implementar.",
    };
  }
  try {
    const result = await executeApprovedAction(input);
    return { ok: true, result };
  } catch (error: unknown) {
    const msg = String(mensagemDoErro(error) || error);
    if (
      msg.includes("Could not find the table") ||
      msg.includes("schema cache") ||
      msg.includes("does not exist")
    ) {
      return {
        ok: false,
        needsCode: true,
        message:
          "A estrutura necessária ainda não existe no banco. Posso gerar a migration e os arquivos para implementar.",
        error: msg,
      };
    }
    return {
      ok: false,
      needsCode: false,
      message: "Não foi possível executar a ação. Verifique conexão, tabela ou permissão.",
      error: msg,
    };
  }
}

export async function rejectPreview(preview: DialogActionPreview, userId: string) {
  await updatePreviewStatus(preview.id, "rejected");
  await writeAudit(userId, "ai_dialog.reject", { previewId: preview.id });
}

/**
 * Registra uma ação em public.audit_logs.
 *
 * A gravação é feita por server function — o navegador não tem policy de
 * INSERT nesta tabela (P-07). O `actor_id` é derivado do Bearer token
 * validado no servidor, então não é possível auditar em nome de outro
 * usuário; o `userId` recebido aqui permanece só por compatibilidade com os
 * call sites e é ignorado.
 *
 * Falha de auditoria não derruba a ação principal, mas também não é mais
 * engolida: `runLogCall` devolve resultado tipado e avisa no console.
 */
async function writeAudit(userId: string, action: string, metadata: Record<string, unknown>) {
  void userId;
  await runLogCall(
    () => logAuditEvent({ data: { action, entity: "ai_dialog", metadata } }),
    `audit_logs:${action}`,
  );
}
