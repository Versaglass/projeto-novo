import { iaAdvise, type IAAdviseResult } from "@/lib/ia-intelligence-chat.functions";
import { buildIAActionPlan, type IAActionPlan } from "@/lib/ia-intelligence";
import type { DialogMessage } from "./aiDialogService";

export type PlannedResponse = {
  advice: IAAdviseResult;
  actionPlan: IAActionPlan;
};

/**
 * Consulta a IA (server fn) e transforma o refinedCommand em um IAActionPlan
 * pronto para prévia/execução pelo executor existente.
 */
export async function planFromCommand(
  command: string,
  history: DialogMessage[],
  contextInfo: string,
): Promise<PlannedResponse> {
  const shortHistory = history.slice(-6).map((m) => ({
    role: m.role === "assistant" ? ("assistant" as const) : ("user" as const),
    content: m.content,
  }));
  const advice = await iaAdvise({
    data: { command, history: shortHistory, context: contextInfo },
  });
  const actionPlan = buildIAActionPlan(advice.refinedCommand || command);
  return { advice, actionPlan };
}
