import {
  AlertTriangle,
  Code2,
  Copy,
  Download,
  KeyRound,
  Loader2,
  Play,
  ShieldOff,
  X,
} from "lucide-react";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { IAActionPlan } from "@/lib/ia-intelligence";
import type { DialogActionPreview } from "./aiDialogService";
import AIGeneratedCodePanel from "./AIGeneratedCodePanel";
import {
  copyTextToClipboard,
  downloadGeneratedFiles,
  generateCodeFromPrompt,
  serializeAllFiles,
  type GeneratedCodeResult,
} from "./aiCodeGenerator";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  preview: DialogActionPreview | null;
  actionPlan: IAActionPlan | null;
  running: boolean;
  onConfirm: (password: string, skipPassword?: boolean) => Promise<void>;
  onReject: () => Promise<void>;
};

const riskLabel: Record<string, string> = {
  baixo: "Baixo",
  medio: "Médio",
  alto: "Alto",
  critico: "Crítico",
};
const riskColor: Record<string, string> = {
  baixo: "bg-green-500/10 text-green-600 border-green-500/20",
  medio: "bg-yellow-500/10 text-yellow-600 border-yellow-500/20",
  alto: "bg-orange-500/10 text-orange-600 border-orange-500/20",
  critico: "bg-red-500/10 text-red-600 border-red-500/20",
};

export function AIExecutionPreview({
  open,
  onOpenChange,
  preview,
  actionPlan,
  running,
  onConfirm,
  onReject,
}: Props) {
  const [password, setPassword] = useState("");
  const [generated, setGenerated] = useState<GeneratedCodeResult | null>(null);
  const [generating, setGenerating] = useState(false);

  async function handleConfirm() {
    if (!password.trim()) return;
    await onConfirm(password, false);
    setPassword("");
  }

  async function handleConfirmNoPassword() {
    await onConfirm("", true);
    setPassword("");
  }

  async function handleReject() {
    await onReject();
    setPassword("");
    setGenerated(null);
  }

  async function handleGenerateCode() {
    if (!actionPlan) return;
    setGenerating(true);
    try {
      const result = await generateCodeFromPrompt(actionPlan.title + " — " + actionPlan.summary);
      setGenerated(result);
    } finally {
      setGenerating(false);
    }
  }

  async function handleCopyGenerated() {
    if (!generated) return;
    await copyTextToClipboard(serializeAllFiles(generated));
  }

  async function handleDownloadGenerated() {
    if (!generated) return;
    downloadGeneratedFiles(generated);
  }

  if (!preview || !actionPlan) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-orange-500" />
            Prévia de alteração
          </DialogTitle>
          <DialogDescription>
            Revise a alteração e execute. A senha do ADM está temporariamente opcional.
          </DialogDescription>
        </DialogHeader>

        <div className="max-h-[60vh] space-y-4 overflow-y-auto pr-1">
          <div className="rounded-xl border bg-muted/40 p-4">
            <div className="mb-2 flex items-center justify-between">
              <h3 className="font-semibold">{actionPlan.title}</h3>
              <Badge variant="outline" className={riskColor[actionPlan.risk]}>
                Risco {riskLabel[actionPlan.risk]}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground">{actionPlan.summary}</p>
          </div>

          <div>
            <Label className="text-xs uppercase text-muted-foreground">Alvo</Label>
            <div className="mt-1 rounded-lg border bg-card p-3 text-sm">
              <b>Tabela:</b> {actionPlan.targetTable || "—"} · <b>Operação:</b>{" "}
              {actionPlan.operation || "—"}
            </div>
          </div>

          <div>
            <Label className="text-xs uppercase text-muted-foreground">
              Dados que serão aplicados
            </Label>
            <pre className="mt-1 max-h-56 overflow-auto rounded-lg border bg-muted p-3 text-xs text-foreground">
              {JSON.stringify(actionPlan.payload, null, 2)}
            </pre>
          </div>

          {preview.snapshot && (
            <div>
              <Label className="text-xs uppercase text-muted-foreground">
                Snapshot salvo (para rollback)
              </Label>
              <pre className="mt-1 max-h-32 overflow-auto rounded-lg border bg-muted/40 p-3 text-xs">
                {JSON.stringify(preview.snapshot, null, 2)}
              </pre>
            </div>
          )}

          <div>
            <Label htmlFor="adm-password" className="flex items-center gap-2">
              <KeyRound className="h-4 w-4" /> Senha do ADM (opcional)
            </Label>
            <Input
              id="adm-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Deixe em branco para executar sem senha"
              autoComplete="current-password"
              disabled={running}
            />
          </div>

          {generated && (
            <div className="pt-2">
              <AIGeneratedCodePanel result={generated} />
            </div>
          )}
        </div>

        <div className="sticky bottom-0 -mx-6 -mb-6 flex flex-wrap items-center justify-end gap-2 border-t bg-background px-6 py-4">
          <Button variant="ghost" onClick={handleReject} disabled={running}>
            <X className="mr-1 h-4 w-4" /> Cancelar
          </Button>
          <Button
            variant="outline"
            onClick={handleGenerateCode}
            disabled={generating}
            className="border-cyan-500/30 text-cyan-200 hover:bg-cyan-500/10"
          >
            {generating ? (
              <Loader2 className="mr-1 h-4 w-4 animate-spin" />
            ) : (
              <Code2 className="mr-1 h-4 w-4" />
            )}
            Gerar código
          </Button>
          {generated && (
            <>
              <Button variant="outline" onClick={handleCopyGenerated}>
                <Copy className="mr-1 h-4 w-4" /> Copiar código
              </Button>
              <Button variant="outline" onClick={handleDownloadGenerated}>
                <Download className="mr-1 h-4 w-4" /> Baixar arquivos
              </Button>
            </>
          )}
          <Button
            variant="outline"
            onClick={handleConfirmNoPassword}
            disabled={running}
            className="border-yellow-500/30 text-yellow-200 hover:bg-yellow-500/10"
          >
            <ShieldOff className="mr-1 h-4 w-4" /> Executar sem senha
          </Button>
          <Button
            onClick={handleConfirm}
            disabled={running || !password.trim()}
            className="bg-green-600 text-white hover:bg-green-700"
          >
            {running ? (
              <Loader2 className="mr-1 h-4 w-4 animate-spin" />
            ) : (
              <Play className="mr-1 h-4 w-4" />
            )}
            Executar agora
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
