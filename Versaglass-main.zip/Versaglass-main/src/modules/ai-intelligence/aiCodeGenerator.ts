import { generateCode } from "@/lib/ai-code-gen.functions";
import { mensagemDoErro } from "@/lib/erro-mensagem";

export type GeneratedFile = {
  path: string;
  language: string;
  content: string;
};

export type GeneratedCodeResult = {
  title: string;
  description: string;
  files: GeneratedFile[];
  sqlMigrations: GeneratedFile[];
};

export async function generateCodeFromPrompt(prompt: string): Promise<GeneratedCodeResult> {
  // 1) Tentar geração real via Lovable AI
  try {
    const result = await generateCode({ data: { prompt } });
    if (result?.files?.length || result?.sqlMigrations?.length) {
      return result;
    }
  } catch (e: unknown) {
    console.warn(
      "[aiCodeGenerator] geração via IA falhou, usando template local:",
      mensagemDoErro(e),
    );
  }
  // 2) Fallback local (templates conhecidos)
  return localTemplate(prompt);
}

async function localTemplate(prompt: string): Promise<GeneratedCodeResult> {
  const lower = prompt.toLowerCase();

  if (lower.includes("login") || lower.includes("template")) {
    return {
      title: "Template de Login Enterprise",
      description: "Arquivos sugeridos para alterar o template da tela de login.",
      files: [
        {
          path: "src/pages/LoginPage.tsx",
          language: "tsx",
          content: `import React from "react";

export default function LoginPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-white grid grid-cols-1 lg:grid-cols-2">
      <section className="p-10 flex flex-col justify-center">
        <h1 className="text-5xl font-bold mb-6">
          Sistema completo para vidraçaria, serralheria, marcenaria e marmoraria
        </h1>
        <p className="text-slate-300 text-lg">
          Gerencie projetos, orçamentos, estoque, financeiro, produção e instalações em uma única plataforma.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-10">
          {["Vidraçaria", "Serralheria", "Marcenaria", "Marmoraria"].map((item) => (
            <div key={item} className="rounded-2xl border border-white/10 bg-white/5 p-5">
              <strong>{item}</strong>
            </div>
          ))}
        </div>
      </section>
      <section className="p-10 flex items-center justify-center">
        <div className="w-full max-w-md rounded-3xl bg-white/10 border border-white/10 p-8">
          <h2 className="text-3xl font-bold mb-6">Entrar</h2>
          <input className="w-full mb-4 rounded-xl bg-slate-900 p-4" placeholder="E-mail" />
          <input className="w-full mb-4 rounded-xl bg-slate-900 p-4" placeholder="Senha" type="password" />
          <select className="w-full mb-4 rounded-xl bg-slate-900 p-4">
            <option>Selecione sua área</option>
            <option>Vidraçaria</option>
            <option>Serralheria</option>
            <option>Marcenaria</option>
            <option>Marmoraria</option>
            <option>Completo</option>
          </select>
          <button className="w-full rounded-xl bg-blue-600 p-4 font-bold">Entrar</button>
        </div>
      </section>
    </div>
  );
}
`,
        },
      ],
      sqlMigrations: [
        {
          path: "supabase/migrations/20260705150200_company_segment.sql",
          language: "sql",
          content: `ALTER TABLE public.companies
ADD COLUMN IF NOT EXISTS segment text DEFAULT 'glass';

ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS preferred_segment text DEFAULT 'glass';
`,
        },
      ],
    };
  }

  return {
    title: "Código gerado pela IA",
    description: "Plano técnico gerado com base no comando informado.",
    files: [
      {
        path: "src/modules/ai-intelligence/generated/GeneratedImprovement.tsx",
        language: "tsx",
        content: `import React from "react";

export default function GeneratedImprovement() {
  return (
    <div className="p-6 rounded-2xl bg-slate-900 text-white">
      <h1 className="text-2xl font-bold">Melhoria gerada pela IA</h1>
      <p className="text-slate-300 mt-2">
        Esta é uma base de componente criada a partir do comando informado.
      </p>
    </div>
  );
}
`,
      },
    ],
    sqlMigrations: [],
  };
}

export async function copyTextToClipboard(text: string) {
  await navigator.clipboard.writeText(text);
}

export function downloadGeneratedFiles(result: GeneratedCodeResult) {
  const blob = new Blob([JSON.stringify(result, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "codigo-gerado-ia-intelligence.json";
  a.click();
  URL.revokeObjectURL(url);
}

export function serializeAllFiles(result: GeneratedCodeResult): string {
  const all = [...result.files, ...result.sqlMigrations];
  return all.map((f) => `// ===== ${f.path} =====\n${f.content}`).join("\n\n");
}
