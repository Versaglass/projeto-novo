import { useState } from "react";
import { Download, Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  type GeneratedCodeResult,
  copyTextToClipboard,
  downloadGeneratedFiles,
  serializeAllFiles,
} from "./aiCodeGenerator";

type Props = {
  result: GeneratedCodeResult;
};

export default function AIGeneratedCodePanel({ result }: Props) {
  const [copied, setCopied] = useState<string | null>(null);

  async function handleCopy(path: string, content: string) {
    await copyTextToClipboard(content);
    setCopied(path);
    setTimeout(() => setCopied(null), 2000);
  }

  async function handleCopyAll() {
    await copyTextToClipboard(serializeAllFiles(result));
    setCopied("__all__");
    setTimeout(() => setCopied(null), 2000);
  }

  const allFiles = [...result.files, ...result.sqlMigrations];

  return (
    <div className="rounded-2xl border bg-card p-4 text-card-foreground space-y-4">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h3 className="text-xl font-bold">{result.title}</h3>
          <p className="text-sm text-muted-foreground">{result.description}</p>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={handleCopyAll}>
            {copied === "__all__" ? (
              <Check className="mr-1 h-4 w-4" />
            ) : (
              <Copy className="mr-1 h-4 w-4" />
            )}
            Copiar tudo
          </Button>
          <Button size="sm" onClick={() => downloadGeneratedFiles(result)}>
            <Download className="mr-1 h-4 w-4" /> Baixar arquivos
          </Button>
        </div>
      </div>

      {allFiles.map((file) => (
        <div
          key={file.path}
          className="rounded-xl border bg-muted/40 overflow-hidden"
        >
          <div className="flex items-center justify-between px-4 py-2 bg-muted">
            <span className="text-sm text-foreground font-mono">{file.path}</span>
            <button
              onClick={() => handleCopy(file.path, file.content)}
              className="rounded-lg bg-primary/10 px-3 py-1 text-xs hover:bg-primary/20 inline-flex items-center gap-1"
            >
              {copied === file.path ? (
                <>
                  <Check className="h-3 w-3" /> Copiado!
                </>
              ) : (
                <>
                  <Copy className="h-3 w-3" /> Copiar código
                </>
              )}
            </button>
          </div>
          <pre className="max-h-96 overflow-auto p-4 text-xs text-foreground">
            <code>{file.content}</code>
          </pre>
        </div>
      ))}
    </div>
  );
}
