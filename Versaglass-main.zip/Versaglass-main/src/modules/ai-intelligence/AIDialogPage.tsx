import { useEffect, useMemo, useState } from "react";
import {
  Bot,
  ClipboardList,
  History,
  LockKeyhole,
  MessageSquare,
  Plus,
  Sparkles,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import type { IAActionPlan } from "@/lib/ia-intelligence";
import { AIDialogChat } from "./AIDialogChat";
import { AIDialogActions } from "./AIDialogActions";
import { AIExecutionPreview } from "./AIExecutionPreview";
import { rejectPreview, safeExecuteAction } from "./aiActionExecutor";
import { planFromCommand } from "./aiCommandPlanner";
import {
  addMessage,
  createPreview,
  createSession,
  deleteSession,
  listExecutions,
  listMessages,
  listPreviews,
  listSessions,
  listSuggestions,
  saveSuggestions,
  updateSession,
  type DialogActionPreview,
  type DialogExecution,
  type DialogMessage,
  type DialogMode,
  type DialogSession,
  type DialogSuggestion,
} from "./aiDialogService";
import { speak, stopSpeaking } from "./aiVoiceService";
import { campoTextoDoErro, mensagemDoErro } from "@/lib/erro-mensagem";

export function AIDialogPage() {
  const { isAdmin, user, role } = useAuth();
  const [sessions, setSessions] = useState<DialogSession[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<DialogMessage[]>([]);
  const [suggestions, setSuggestions] = useState<DialogSuggestion[]>([]);
  const [previews, setPreviews] = useState<DialogActionPreview[]>([]);
  const [executions, setExecutions] = useState<DialogExecution[]>([]);
  const [mode, setMode] = useState<DialogMode>("converse");
  const [voiceReply, setVoiceReply] = useState(() =>
    typeof window !== "undefined" ? localStorage.getItem("ai-dialog-voice") !== "false" : true,
  );
  const [sending, setSending] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [activePreview, setActivePreview] = useState<DialogActionPreview | null>(null);
  const [activePlan, setActivePlan] = useState<IAActionPlan | null>(null);
  const [activeCommand, setActiveCommand] = useState<string>("");
  const [running, setRunning] = useState(false);

  const activeSession = useMemo(
    () => sessions.find((s) => s.id === activeId) ?? null,
    [sessions, activeId],
  );

  useEffect(() => {
    if (!isAdmin) return;
    void bootstrap();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin]);

  useEffect(() => {
    if (!activeId) return;
    void loadSessionData(activeId);
    // `loadSessionData` fica FORA das dependências, mesmo motivo do efeito
    // acima: é recriada a cada render e chama vários `setState`, então incluí-la
    // faria laço infinito. Também não dá para memoizá-la sem cuidado, porque ela
    // lê `sessions` — e `sessions` muda por `setSessions`, o que reintroduziria
    // o laço por outro caminho. A intenção é recarregar ao trocar de sessão.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeId]);

  async function bootstrap() {
    try {
      const list = await listSessions();
      setSessions(list);
      if (list.length) setActiveId(list[0].id);
      else await handleNewSession();
    } catch (e: unknown) {
      toast.error("Não foi possível carregar as sessões: " + (mensagemDoErro(e) || ""));
    }
  }

  async function loadSessionData(id: string) {
    const [msgs, sugs, prevs, execs] = await Promise.all([
      listMessages(id),
      listSuggestions(id),
      listPreviews(id),
      listExecutions(id).then((r) => (Array.isArray(r) ? [] : r.executions)),
    ]);
    setMessages(msgs);
    setSuggestions(sugs);
    setPreviews(prevs);
    setExecutions(execs);
    const s = sessions.find((x) => x.id === id);
    if (s) setMode(s.mode);
  }

  async function handleNewSession() {
    if (!user?.id) return;
    try {
      const s = await createSession(user.id, "Nova conversa", mode);
      setSessions((cur) => [s, ...cur]);
      setActiveId(s.id);
      setMessages([]);
      setSuggestions([]);
      setPreviews([]);
      setExecutions([]);
    } catch (e: unknown) {
      toast.error("Falha ao criar sessão: " + (mensagemDoErro(e) || ""));
    }
  }

  async function handleDeleteSession(id: string) {
    if (!confirm("Excluir esta conversa?")) return;
    try {
      await deleteSession(id);
      const rest = sessions.filter((s) => s.id !== id);
      setSessions(rest);
      if (activeId === id) setActiveId(rest[0]?.id ?? null);
    } catch (e: unknown) {
      toast.error("Falha ao excluir: " + (mensagemDoErro(e) || ""));
    }
  }

  async function handleModeChange(m: DialogMode) {
    setMode(m);
    if (activeId) await updateSession(activeId, { mode: m });
    setSessions((cur) => cur.map((s) => (s.id === activeId ? { ...s, mode: m } : s)));
  }

  function toggleVoice() {
    const next = !voiceReply;
    setVoiceReply(next);
    localStorage.setItem("ai-dialog-voice", String(next));
    if (!next) stopSpeaking();
  }

  async function handleSend(text: string) {
    if (!activeId || !user) return;
    setSending(true);
    try {
      // 1. Salva mensagem do usuário
      const userMsg = await addMessage(activeId, "user", text);
      setMessages((cur) => [...cur, userMsg]);

      // 2. Consulta IA + gera plano de ação (mesmo em modo converse, geramos plano para uso opcional)
      const { advice, actionPlan } = await planFromCommand(
        text,
        [...messages, userMsg],
        `Usuário: ${user.email}. Papel: ${role}. Modo: ${mode}.`,
      );

      // 3. Salva resposta da IA
      const assistantMsg = await addMessage(activeId, "assistant", advice.reply, {
        risk: advice.risk,
        refinedCommand: advice.refinedCommand,
      });
      setMessages((cur) => [...cur, assistantMsg]);

      // 4. Fala a resposta se voz estiver ativa
      if (voiceReply) speak(advice.reply);

      // 5. Salva sugestões
      if (advice.suggestions?.length) {
        const rows = advice.suggestions.map((title) => ({
          title,
          description: undefined,
          risk: advice.risk,
        }));
        const saved = await saveSuggestions(activeId, assistantMsg.id, rows);
        setSuggestions((cur) => [...saved, ...cur]);
      }

      // 6. Se modo == plan ou execute → cria prévia
      if (mode === "plan" || mode === "execute") {
        const preview = await createPreview({
          sessionId: activeId,
          messageId: assistantMsg.id,
          intent: { command: text, refinedCommand: advice.refinedCommand, type: actionPlan.type },
          preview: {
            title: actionPlan.title,
            summary: actionPlan.summary,
            targetTable: actionPlan.targetTable,
            operation: actionPlan.operation,
            payload: actionPlan.payload,
          },
          snapshot: actionPlan.beforeSnapshot ?? null,
          risk: actionPlan.risk,
        });
        setPreviews((cur) => [preview, ...cur]);
        setActivePreview(preview);
        setActivePlan(actionPlan);
        setActiveCommand(text);
        if (mode === "execute") {
          setPreviewOpen(true);
        } else {
          toast.success("Plano de alteração criado. Confira na aba Plano.");
        }
      }
    } catch (e: unknown) {
      const detail =
        mensagemDoErro(e) ||
        campoTextoDoErro(e, "error_description") ||
        campoTextoDoErro(e, "hint") ||
        String(e);
      console.error("[AIDialog] erro em handleSend:", e);
      const fallback =
        "Tive uma falha momentânea de conexão com a IA, mas a conversa continua funcionando. Você pode: 1) tentar novamente, 2) me pedir para gerar um plano local do seu pedido, 3) abrir o painel de comandos para executar direto, ou 4) registrar isso como melhoria para eu preparar depois.\n\nDetalhe técnico: " +
        detail;
      if (activeId) {
        try {
          const errMsg = await addMessage(activeId, "assistant", fallback);
          setMessages((cur) => [...cur, errMsg]);
        } catch {
          setMessages((cur) => [
            ...cur,
            {
              id: `local-${Date.now()}`,
              session_id: activeId,
              role: "assistant",
              content: fallback,
              created_at: new Date().toISOString(),
              metadata: null,
            } as any,
          ]);
        }
      }
    } finally {
      setSending(false);
    }
  }

  async function handleUseSuggestion(s: DialogSuggestion) {
    // Insere a sugestão como próximo comando no chat
    toast.info("Sugestão pronta para envio no chat.");
    await handleSend(s.title);
  }

  async function handleGeneratePlanFromSuggestion(s: DialogSuggestion) {
    // Muda para modo plan e envia
    setMode("plan");
    if (activeId) await updateSession(activeId, { mode: "plan" });
    await handleSend(s.title);
  }

  function openPreview(p: DialogActionPreview) {
    setActivePreview(p);
    const payload = (p.preview as any)?.payload || {};
    const plan: IAActionPlan = {
      type: (p.intent as any)?.type || "general_system_change",
      title: (p.preview as any)?.title || "Ação",
      summary: (p.preview as any)?.summary || "",
      risk: p.risk,
      targetTable: (p.preview as any)?.targetTable,
      operation: (p.preview as any)?.operation,
      payload,
    };
    setActivePlan(plan);
    setActiveCommand((p.intent as any)?.command || "");
    setPreviewOpen(true);
  }

  async function handleConfirmExecute(password: string, skipPassword?: boolean) {
    if (!activePreview || !activePlan || !user?.email || !user?.id) return;
    setRunning(true);
    try {
      const outcome = await safeExecuteAction({
        preview: activePreview,
        actionPlan: activePlan,
        originalCommand: activeCommand,
        userEmail: user.email,
        userId: user.id,
        password,
        skipPassword,
      });
      if (outcome.ok) {
        toast.success("Alteração executada com sucesso");
        if (voiceReply) speak(`Executado: ${activePlan.title}`);
        setPreviewOpen(false);
        if (activeId) await loadSessionData(activeId);
      } else if (outcome.needsCode) {
        toast.warning(outcome.message + " Use ‘Gerar código’ na prévia.");
        if (activeId) {
          try {
            await addMessage(
              activeId,
              "assistant",
              outcome.message + (outcome.error ? `\n\nDetalhe: ${outcome.error}` : ""),
            );
            await loadSessionData(activeId);
          } catch {
            /* ignore */
          }
        }
      } else {
        toast.error(outcome.message + (outcome.error ? ` — ${outcome.error}` : ""));
      }
    } catch (e: unknown) {
      const msg = mensagemDoErro(e) || String(e);
      toast.error("Não foi possível executar. Verifique conexão, tabela ou permissão. " + msg);
    } finally {
      setRunning(false);
    }
  }

  async function handleRejectExecute() {
    if (!activePreview || !user?.id) return;
    try {
      await rejectPreview(activePreview, user.id);
      toast.info("Alteração cancelada.");
      setPreviewOpen(false);
      if (activeId) await loadSessionData(activeId);
    } catch (e: unknown) {
      toast.error(mensagemDoErro(e) || "Falha ao cancelar.");
    }
  }

  if (!isAdmin) {
    return (
      <div className="rounded-2xl border bg-card p-8 text-center">
        <LockKeyhole className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
        <h2 className="text-xl font-bold">Acesso restrito</h2>
        <p className="mt-2 text-muted-foreground">O diálogo com a IA aparece somente para ADM.</p>
      </div>
    );
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[260px,1fr]">
      {/* Sidebar de sessões */}
      <aside className="space-y-3">
        <Button onClick={handleNewSession} className="w-full gap-2">
          <Plus className="h-4 w-4" /> Nova conversa
        </Button>
        <div className="space-y-1 rounded-2xl border bg-card p-2">
          {sessions.length === 0 && (
            <p className="p-3 text-center text-sm text-muted-foreground">Nenhuma conversa ainda.</p>
          )}
          {sessions.map((s) => (
            <div
              key={s.id}
              className={`group flex items-center gap-1 rounded-lg px-2 py-1.5 text-sm ${activeId === s.id ? "bg-primary/10 text-foreground" : "hover:bg-muted"}`}
            >
              <button className="flex-1 truncate text-left" onClick={() => setActiveId(s.id)}>
                <MessageSquare className="mr-1 inline h-3 w-3" /> {s.title}
              </button>
              <button
                className="opacity-0 group-hover:opacity-100"
                onClick={() => handleDeleteSession(s.id)}
                title="Excluir"
              >
                <Trash2 className="h-3.5 w-3.5 text-muted-foreground hover:text-destructive" />
              </button>
            </div>
          ))}
        </div>
      </aside>

      {/* Área principal */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-card p-3">
          <div className="flex items-center gap-2">
            <Bot className="h-5 w-5 text-primary" />
            <b>{activeSession?.title || "Diálogo com a IA"}</b>
            <Badge variant="outline">ADM</Badge>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Modo</span>
            <Select value={mode} onValueChange={(v) => handleModeChange(v as DialogMode)}>
              <SelectTrigger className="h-9 w-[220px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="converse">Apenas conversar</SelectItem>
                <SelectItem value="suggest">Sugerir melhorias</SelectItem>
                <SelectItem value="plan">Criar plano de alteração</SelectItem>
                <SelectItem value="execute">Executar com confirmação</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Tabs defaultValue="chat">
          <TabsList>
            <TabsTrigger value="chat">
              <MessageSquare className="mr-1 h-4 w-4" />
              Conversa
            </TabsTrigger>
            <TabsTrigger value="suggestions">
              <Sparkles className="mr-1 h-4 w-4" />
              Sugestões ({suggestions.length})
            </TabsTrigger>
            <TabsTrigger value="plans">
              <ClipboardList className="mr-1 h-4 w-4" />
              Planos ({previews.length})
            </TabsTrigger>
            <TabsTrigger value="executions">
              <History className="mr-1 h-4 w-4" />
              Execuções ({executions.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="chat" className="mt-3">
            <AIDialogChat
              messages={messages}
              sending={sending}
              voiceReply={voiceReply}
              mode={mode}
              onToggleVoice={toggleVoice}
              onSend={handleSend}
            />
          </TabsContent>

          <TabsContent value="suggestions" className="mt-3">
            <AIDialogActions
              suggestions={suggestions}
              onUseSuggestion={handleUseSuggestion}
              onGeneratePlan={handleGeneratePlanFromSuggestion}
            />
          </TabsContent>

          <TabsContent value="plans" className="mt-3">
            <PlansList previews={previews} onOpen={openPreview} />
          </TabsContent>

          <TabsContent value="executions" className="mt-3">
            <ExecutionsList executions={executions} />
          </TabsContent>
        </Tabs>
      </div>

      <AIExecutionPreview
        open={previewOpen}
        onOpenChange={setPreviewOpen}
        preview={activePreview}
        actionPlan={activePlan}
        running={running}
        onConfirm={handleConfirmExecute}
        onReject={handleRejectExecute}
      />
    </div>
  );
}

function PlansList({
  previews,
  onOpen,
}: {
  previews: DialogActionPreview[];
  onOpen: (p: DialogActionPreview) => void;
}) {
  if (!previews.length) {
    return (
      <div className="rounded-2xl border border-dashed p-8 text-center text-sm text-muted-foreground">
        Nenhum plano criado. Use o modo Plano ou Executar para gerar prévias.
      </div>
    );
  }
  const statusColor: Record<string, string> = {
    pending: "bg-yellow-500/10 text-yellow-600 border-yellow-500/20",
    approved: "bg-blue-500/10 text-blue-600 border-blue-500/20",
    rejected: "bg-slate-500/10 text-slate-600 border-slate-500/20 dark:text-slate-300",
    executed: "bg-green-500/10 text-green-600 border-green-500/20",
  };
  return (
    <div className="grid gap-3">
      {previews.map((p) => (
        <div key={p.id} className="rounded-2xl border bg-card p-4">
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <b>{(p.preview as any)?.title || "Ação"}</b>
                <Badge variant="outline" className={statusColor[p.status]}>
                  {p.status}
                </Badge>
                <Badge variant="outline">Risco {p.risk}</Badge>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{(p.preview as any)?.summary}</p>
              <p className="mt-1 text-xs text-muted-foreground">
                {new Date(p.created_at).toLocaleString()}
              </p>
            </div>
            {p.status === "pending" && (
              <Button size="sm" onClick={() => onOpen(p)}>
                Revisar e executar
              </Button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

function ExecutionsList({ executions }: { executions: DialogExecution[] }) {
  if (!executions.length) {
    return (
      <div className="rounded-2xl border border-dashed p-8 text-center text-sm text-muted-foreground">
        Nenhuma execução ainda.
      </div>
    );
  }
  return (
    <div className="grid gap-3">
      {executions.map((e) => (
        <div key={e.id} className="rounded-2xl border bg-card p-4">
          <div className="flex items-center justify-between">
            <b className={e.success ? "text-green-600" : "text-red-600"}>
              {e.success ? "Sucesso" : "Falha"}
            </b>
            <span className="text-xs text-muted-foreground">
              {new Date(e.created_at).toLocaleString()}
            </span>
          </div>
          {e.error && <p className="mt-1 text-sm text-destructive">{e.error}</p>}
          <pre className="mt-2 max-h-40 overflow-auto rounded-lg bg-muted/40 p-2 text-xs">
            {JSON.stringify(e.result, null, 2)}
          </pre>
          {e.rollback_available && (
            <Badge variant="outline" className="mt-2">
              Rollback disponível
            </Badge>
          )}
        </div>
      ))}
    </div>
  );
}
