/**
 * Serviço de voz da IA Intelligence.
 * Encapsula SpeechRecognition (STT) e SpeechSynthesis (TTS) do navegador.
 */

export function voiceSupported() {
  if (typeof window === "undefined") return { stt: false, tts: false };
  const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  return { stt: !!SR, tts: "speechSynthesis" in window };
}

export async function ensureMicPermission(): Promise<boolean> {
  if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) return false;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((t) => t.stop());
    return true;
  } catch {
    return false;
  }
}

export function speak(
  text: string,
  opts: { lang?: string; rate?: number; onEnd?: () => void } = {},
) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text.replace(/[*_#`]/g, ""));
  u.lang = opts.lang || "pt-BR";
  u.rate = opts.rate ?? 0.98;
  if (opts.onEnd) {
    u.onend = opts.onEnd;
    u.onerror = opts.onEnd;
  }
  window.speechSynthesis.speak(u);
}

export function stopSpeaking() {
  if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
}

export function listenOnce(maxMs = 15000, silenceMs = 1800): Promise<string> {
  return new Promise((resolve, reject) => {
    const SR: any =
      typeof window !== "undefined" &&
      ((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
    if (!SR) return reject(new Error("Reconhecimento de voz não suportado. Use Chrome ou Edge."));
    const rec = new SR();
    rec.lang = "pt-BR";
    rec.continuous = true;
    rec.interimResults = true;
    let finalText = "";
    let silenceTimer: any = null;
    const maxTimer = setTimeout(() => {
      try {
        rec.stop();
      } catch {
        // Intencionalmente vazio: `SpeechRecognition.stop()` lança InvalidStateError
        // se o reconhecimento já parou sozinho. Parar o que já parou é o
        // resultado desejado; não há falha a tratar.
      }
    }, maxMs);
    const resetSilence = () => {
      if (silenceTimer) clearTimeout(silenceTimer);
      silenceTimer = setTimeout(() => {
        try {
          rec.stop();
        } catch {
          // Intencionalmente vazio: `SpeechRecognition.stop()` lança InvalidStateError
          // se o reconhecimento já parou sozinho. Parar o que já parou é o
          // resultado desejado; não há falha a tratar.
        }
      }, silenceMs);
    };
    rec.onresult = (e: any) => {
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) finalText += e.results[i][0].transcript + " ";
      }
      resetSilence();
    };
    rec.onerror = (e: any) => {
      clearTimeout(maxTimer);
      if (silenceTimer) clearTimeout(silenceTimer);
      if (e?.error === "no-speech") return resolve("");
      reject(new Error(e?.error || "erro no reconhecimento"));
    };
    rec.onend = () => {
      clearTimeout(maxTimer);
      if (silenceTimer) clearTimeout(silenceTimer);
      resolve(finalText.trim());
    };
    try {
      rec.start();
      resetSilence();
    } catch (err: unknown) {
      reject(err);
    }
  });
}
