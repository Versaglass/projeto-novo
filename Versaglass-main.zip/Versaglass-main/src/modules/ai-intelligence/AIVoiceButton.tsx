import { Mic, MicOff, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ensureMicPermission, listenOnce, voiceSupported } from "./aiVoiceService";
import { mensagemDoErro } from "@/lib/erro-mensagem";

type Props = {
  onTranscript: (text: string) => void;
  disabled?: boolean;
};

export function AIVoiceButton({ onTranscript, disabled }: Props) {
  const [listening, setListening] = useState(false);
  const { stt } = voiceSupported();

  async function handleClick() {
    if (!stt) {
      toast.error("Reconhecimento de voz não suportado. Use Chrome ou Edge.");
      return;
    }
    if (listening) return;
    const ok = await ensureMicPermission();
    if (!ok) {
      toast.error(
        "Permissão do microfone negada. Clique no cadeado da barra do navegador para liberar.",
      );
      return;
    }
    setListening(true);
    toast.info("Ouvindo… fale seu comando.");
    try {
      const text = await listenOnce(20000, 2000);
      if (text) onTranscript(text);
      else toast.info("Não entendi. Tente novamente.");
    } catch (e: unknown) {
      toast.error("Erro de voz: " + (mensagemDoErro(e) || "desconhecido"));
    } finally {
      setListening(false);
    }
  }

  return (
    <Button
      type="button"
      variant={listening ? "destructive" : "outline"}
      size="icon"
      onClick={handleClick}
      disabled={disabled}
      title="Falar comando"
    >
      {listening ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : stt ? (
        <Mic className="h-4 w-4" />
      ) : (
        <MicOff className="h-4 w-4" />
      )}
    </Button>
  );
}
