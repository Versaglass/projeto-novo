import type {
  CreateInvoiceInput,
  FiscalInvoice,
  FiscalProviderResponse,
  FiscalSettings,
} from "./types";

export type FiscalWebhookEvent = {
  provider: string;
  invoice_id?: string;
  provider_invoice_id?: string;
  status: FiscalInvoice["status"];
  response: Partial<FiscalProviderResponse>;
  raw: unknown;
};

export interface FiscalProvider {
  name: string;
  emitInvoice(input: CreateInvoiceInput, settings: FiscalSettings): Promise<FiscalProviderResponse>;
  cancelInvoice(
    invoice: FiscalInvoice,
    settings: FiscalSettings,
    reason: string,
  ): Promise<FiscalProviderResponse>;
  parseWebhook(payload: unknown, headers?: Record<string, string>): Promise<FiscalWebhookEvent>;
}
