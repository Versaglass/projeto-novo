import type { CreateInvoiceInput, FiscalInvoice, FiscalSettings } from "./types";
import type { FiscalProvider } from "./fiscalProvider";

export function buildInvoiceDraft(input: CreateInvoiceInput): FiscalInvoice {
  return {
    ...input,
    id: crypto.randomUUID(),
    status: "draft",
    created_at: new Date().toISOString(),
  };
}

export async function issueInvoice(
  input: CreateInvoiceInput,
  settings: FiscalSettings,
  provider: FiscalProvider,
): Promise<FiscalInvoice> {
  const draft = buildInvoiceDraft(input);
  const response = await provider.emitInvoice(input, settings);
  return {
    ...draft,
    ...response,
    issued_at:
      response.status === "authorized" ? response.issued_at || new Date().toISOString() : undefined,
  };
}

export async function cancelInvoice(
  invoice: FiscalInvoice,
  settings: FiscalSettings,
  provider: FiscalProvider,
  reason: string,
): Promise<FiscalInvoice> {
  const response = await provider.cancelInvoice(invoice, settings, reason);
  return {
    ...invoice,
    ...response,
    status: response.status,
    canceled_at: response.status === "canceled" ? new Date().toISOString() : invoice.canceled_at,
  };
}

export function attachFiscalToFinancialDashboard(invoices: FiscalInvoice[]) {
  return invoices.reduce(
    (acc, invoice) => {
      if (invoice.status === "authorized") acc.authorized += invoice.total_amount;
      if (invoice.status === "rejected") acc.rejected += 1;
      if (invoice.status === "processing") acc.processing += 1;
      return acc;
    },
    { authorized: 0, rejected: 0, processing: 0 },
  );
}
