import type { FiscalProvider } from "../fiscalProvider";

type TecnoSpeedWebhook = {
  chave?: string;
  situacao?: string;
};

export const tecnoSpeedProvider: FiscalProvider = {
  name: "tecnospeed",
  async emitInvoice(input, settings) {
    const id = crypto.randomUUID().slice(0, 8).toUpperCase();
    return {
      status: "processing",
      invoice_number: `TS-${id}`,
      access_key: `TS-${settings.cnpj}-${id}`,
      protocol: `TS-PROT-${id}`,
    };
  },
  async cancelInvoice(invoice) {
    return {
      status: "canceled",
      invoice_number: invoice.invoice_number,
      access_key: invoice.access_key,
    };
  },
  async parseWebhook(payload) {
    const data = (payload ?? {}) as TecnoSpeedWebhook;
    return {
      provider: "tecnospeed",
      provider_invoice_id: data.chave,
      status: data.situacao === "AUTORIZADA" ? "authorized" : "processing",
      response: data as Record<string, unknown>,
      raw: payload,
    };
  },
};
