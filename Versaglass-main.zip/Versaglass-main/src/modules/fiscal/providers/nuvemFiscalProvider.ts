import type { FiscalProvider } from "../fiscalProvider";

type NuvemWebhook = {
  chave_acesso?: string;
  status?: string;
};

export const nuvemFiscalProvider: FiscalProvider = {
  name: "nuvem_fiscal",
  async emitInvoice(input, settings) {
    const id = crypto.randomUUID().slice(0, 8).toUpperCase();
    return {
      status: "processing",
      invoice_number: `NF-${id}`,
      access_key: `NF-${settings.cnpj}-${id}`,
      protocol: `NF-PROT-${id}`,
    };
  },
  async cancelInvoice(invoice) {
    return {
      status: "canceled",
      invoice_number: invoice.invoice_number,
      access_key: invoice.access_key,
    };
  },
  async parseWebhook(payload) {
    const data = (payload ?? {}) as NuvemWebhook;
    return {
      provider: "nuvem_fiscal",
      provider_invoice_id: data?.chave_acesso,
      status: data?.status === "autorizado" ? "authorized" : "processing",
      response: (data || {}) as Record<string, unknown>,
      raw: payload,
    };
  },
};
