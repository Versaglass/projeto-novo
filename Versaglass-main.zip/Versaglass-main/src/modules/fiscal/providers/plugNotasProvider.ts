import type { FiscalProvider } from "../fiscalProvider";

type PlugNotasWebhook = {
  chave?: string;
  access_key?: string;
  status?: string;
};

export const plugNotasProvider: FiscalProvider = {
  name: "plugnotas",
  async emitInvoice(input, settings) {
    const id = crypto.randomUUID().slice(0, 8).toUpperCase();
    return {
      status: settings.environment === "homologation" ? "authorized" : "processing",
      invoice_number: `PN-${id}`,
      access_key: `352607${settings.cnpj.replace(/\D/g, "").padEnd(14, "0")}55${id}`,
      protocol: `PROT-${id}`,
      xml_url: `https://fiscal.exemplo/plugnotas/${id}.xml`,
      pdf_url: `https://fiscal.exemplo/plugnotas/${id}.pdf`,
      issued_at: new Date().toISOString(),
    };
  },
  async cancelInvoice(invoice) {
    return {
      status: "canceled",
      invoice_number: invoice.invoice_number,
      access_key: invoice.access_key,
    };
  },
  async parseWebhook(payload) {
    const data = (payload ?? {}) as PlugNotasWebhook;
    const statusRaw = data.status || "processing";
    return {
      provider: "plugnotas",
      provider_invoice_id: data.chave || data.access_key,
      status: (statusRaw === "authorized" ||
      statusRaw === "canceled" ||
      statusRaw === "rejected" ||
      statusRaw === "processing"
        ? statusRaw
        : "processing") as "processing" | "authorized" | "canceled" | "rejected",
      response: data as Record<string, unknown>,
      raw: payload,
    };
  },
};
