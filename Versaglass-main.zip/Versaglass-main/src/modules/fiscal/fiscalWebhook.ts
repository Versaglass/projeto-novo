import type { FiscalInvoice } from "./types";
import type { FiscalProvider } from "./fiscalProvider";

export async function handleFiscalWebhook(
  payload: unknown,
  provider: FiscalProvider,
  invoices: FiscalInvoice[],
  headers?: Record<string, string>,
) {
  const event = await provider.parseWebhook(payload, headers);
  return invoices.map((invoice) => {
    if (event.invoice_id && invoice.id !== event.invoice_id) return invoice;
    if (event.provider_invoice_id && invoice.access_key !== event.provider_invoice_id)
      return invoice;
    return { ...invoice, ...event.response, status: event.status };
  });
}
