export type FiscalProviderName = "plugnotas" | "tecnospeed" | "nuvem_fiscal" | "manual";
export type FiscalEnvironment = "homologation" | "production";
export type InvoiceType = "nfe" | "nfse" | "nfce";
export type InvoiceStatus = "draft" | "processing" | "authorized" | "rejected" | "canceled";

export type FiscalSettings = {
  id: string;
  company_id: string;
  legal_name: string;
  trade_name?: string;
  cnpj: string;
  state_registration?: string;
  municipal_registration?: string;
  tax_regime: string;
  city: string;
  state: string;
  certificate_url?: string;
  certificate_password?: string;
  environment: FiscalEnvironment;
  provider: FiscalProviderName;
  created_at: string;
};

export type FiscalInvoice = {
  id: string;
  company_id: string;
  customer_id?: string;
  customer_name: string;
  sale_id?: string;
  order_service_id?: string;
  invoice_type: InvoiceType;
  status: InvoiceStatus;
  invoice_number?: string;
  access_key?: string;
  protocol?: string;
  xml_url?: string;
  pdf_url?: string;
  total_amount: number;
  error_message?: string;
  issued_at?: string;
  canceled_at?: string;
  created_at: string;
};

export type CreateInvoiceInput = Omit<
  FiscalInvoice,
  | "id"
  | "status"
  | "invoice_number"
  | "access_key"
  | "protocol"
  | "xml_url"
  | "pdf_url"
  | "error_message"
  | "issued_at"
  | "canceled_at"
  | "created_at"
>;

export type FiscalProviderResponse = {
  status: InvoiceStatus;
  invoice_number?: string;
  access_key?: string;
  protocol?: string;
  xml_url?: string;
  pdf_url?: string;
  error_message?: string;
  issued_at?: string;
};
