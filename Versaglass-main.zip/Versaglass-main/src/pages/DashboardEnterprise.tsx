import type React from "react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  BriefcaseBusiness,
  CalendarCheck,
  FileText,
  Package,
  Plus,
  Users,
  WalletCards,
  type LucideIcon,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { brl } from "@/lib/format";
import { useAuth } from "@/hooks/use-auth";
import { finePermissionForNavTo, resolvesFinePermission } from "@/lib/fine-permissions";
import { currentMonthPeriod, useFinanceSummary } from "@/hooks/use-finance";
import { useCompany } from "@/contexts/company-context";
import { StorageImage } from "@/components/StorageImage";
import { ROTULO_AREA, type AreaProjeto } from "@/lib/project-area";
import { getDashboardSegment, SEGMENT_CONFIG, type SegmentSlug } from "@/lib/segmentAccess";
import type { FileRouteTypes } from "@/routeTree.gen";

import segmentVidracaria from "@/assets/segment-vidracaria.jpg";
import segmentSerralheria from "@/assets/segment-serralheria.jpg";
import segmentMarcenaria from "@/assets/segment-marcenaria.jpg";
import segmentMarmoraria from "@/assets/segment-marmoraria.jpg";
import projectPortoes from "@/assets/project-portoes.jpg";
import projectTelhados from "@/assets/project-telhados.jpg";
import projectPergolados from "@/assets/project-pergolados.jpg";
import projectGalpoes from "@/assets/project-galpoes.jpg";
import projectEscadas from "@/assets/project-escadas.jpg";
import projectMezaninos from "@/assets/project-mezaninos.jpg";

/**
 * Quantos itens de estoque em alerta o painel lista (Revisão 40).
 *
 * O card é um RESUMO, não a tela de Estoque: cinco linhas cabem sem rolagem e
 * já dizem o que é urgente. O número total continua no card "Estoque baixo", e
 * o link "Ver estoque completo" leva ao módulo quando houver mais.
 */
const MAX_ITENS_ALERTA = 5;

const moduleImages: Record<Exclude<SegmentSlug, "complete">, string> = {
  glass: segmentVidracaria,
  steel: segmentSerralheria,
  woodworking: segmentMarcenaria,
  stone: segmentMarmoraria,
};

const modules = [
  {
    slug: "glass" as const,
    title: "Vidraçaria",
    image: segmentVidracaria,
    color: "blue",
    href: "/app/projetos",
  },
  {
    slug: "steel" as const,
    title: "Serralheria",
    image: segmentSerralheria,
    color: "orange",
    href: "/app/projetos",
  },
  {
    slug: "woodworking" as const,
    title: "Marcenaria",
    image: segmentMarcenaria,
    color: "emerald",
    href: "/app/projetos",
  },
  {
    slug: "stone" as const,
    title: "Marmoraria",
    image: segmentMarmoraria,
    color: "purple",
    href: "/app/projetos",
  },
];

/**
 * ITEM 5 (Revisão 43) — destino de cada "ação rápida".
 *
 * Os seis botões eram `<button>` SEM `onClick`: clicavam e nada acontecia.
 * Aqui cada rótulo dos cinco segmentos (17 distintos) recebe a rota real
 * correspondente. Rótulo que não estiver neste mapa **não vira botão** — é
 * preferível mostrar cinco ações que funcionam a seis das quais uma mente.
 *
 * Os "criar peça X" (portão, móvel, bancada, estrutura) apontam todos para a
 * Biblioteca de Projetos: é de lá que sai qualquer modelo técnico novo,
 * seja qual for o segmento.
 */
type AppTo = FileRouteTypes["to"];

const DESTINO_ACAO: Record<string, AppTo> = {
  "Novo orçamento": "/app/orcamentos/novo",
  "Novo projeto": "/app/projetos",
  "Novo portão": "/app/projetos",
  "Nova estrutura": "/app/projetos",
  "Novo móvel": "/app/projetos",
  "Nova bancada": "/app/projetos",
  "Recorte de cuba": "/app/projetos",
  "Novo cliente": "/app/clientes",
  "Plano de corte": "/app/plano-corte",
  "Lista de ferragens": "/app/ferragens",
  // "Compra de aço" removido: página /app/compras saiu da experiência operacional.
  // Revisão 89: a rota era `/app/calculadora` e foi renomeada. A antiga
  // continua respondendo por redirect, mas o mapa aponta para a definitiva.
  "Nova venda": "/app/venda-direta",
  "Render 3D": "/app/editor-engenharia",
  // SEM DESTINO, de propósito: "Enviar WhatsApp" é uma ação sobre um cliente
  // ou orçamento específico (existe em Clientes e em Orçamentos), não uma tela.
  // Sem contexto, o botão não teria o que abrir — então não é renderizado.
  // "Ordem de serviço" e "Medição" removidos: módulos ocultos (OS / Agenda).
};

type PublicTable = keyof Database["public"]["Tables"];
type QuotesRow = Database["public"]["Tables"]["quotes"]["Row"];
type ChargesRow = Database["public"]["Tables"]["charges"]["Row"];
type InventoryRow = Database["public"]["Tables"]["inventory_items"]["Row"];
type SalesRow = Database["public"]["Tables"]["sales"]["Row"];
type CatalogDash = Pick<
  Database["public"]["Tables"]["platform_project_catalog"]["Row"],
  "id" | "nome" | "area" | "imagem_url" | "created_at"
>;
type TemplateDash = Pick<
  Database["public"]["Tables"]["project_templates"]["Row"],
  "id" | "nome" | "area" | "imagem_url" | "created_at"
>;

type QuoteDash = Pick<QuotesRow, "id" | "total" | "status" | "etapa" | "created_at">;
type ChargeDash = Pick<ChargesRow, "id" | "amount" | "status">;
type StockDash = Pick<InventoryRow, "id" | "nome" | "quantidade" | "estoque_minimo" | "unidade">;
type ModeloDash = {
  id: string;
  nome: string;
  area: string | null;
  imagem_url: string | null;
  created_at: string;
  imageBucket: "project-images" | "platform-catalog";
};
type SaleDash = Pick<SalesRow, "id" | "total" | "created_at">;
type DashQuery = {
  eq: (column: string, value: string | boolean) => DashQuery;
  gte: (column: string, value: string) => DashQuery;
  lt: (column: string, value: string) => DashQuery;
  order: (column: string, opts?: { ascending?: boolean }) => DashQuery;
  limit: (count: number) => DashQuery;
};

type CountResult = { count: number | null; error: { message: string } | null };
type SelectResult<T> = { data: T[] | null; error: { message: string } | null };

async function safeCount(table: PublicTable, cb?: (query: DashQuery) => DashQuery) {
  try {
    const base = supabase.from(table).select("*", { count: "exact", head: true });
    const query = cb ? cb(base as unknown as DashQuery) : (base as unknown as DashQuery);
    const { count, error } = await (query as unknown as PromiseLike<CountResult>);
    if (error) return 0;
    return count ?? 0;
  } catch {
    return 0;
  }
}

async function safeSelect<T>(
  table: PublicTable,
  columns: string,
  cb?: (query: DashQuery) => DashQuery,
): Promise<T[]> {
  try {
    const base = supabase.from(table).select(columns);
    const query = cb ? cb(base as unknown as DashQuery) : (base as unknown as DashQuery);
    const { data, error } = await (query as unknown as PromiseLike<SelectResult<T>>);
    if (error) return [];
    return data ?? [];
  } catch {
    return [];
  }
}

// REMOVIDA na Revisão 43: `safeSelectStatus`. Existia só para distinguir
// "consulta vazia" de "consulta falhou" no caso de `financial_entries` — e essa
// consulta saiu (item 8). O resumo financeiro do painel usa `useFinanceSummary`
// (Revisão 165), não esta sonda.

export function DashboardEnterprise() {
  const { user, isAdmin, permissions } = useAuth();
  const { activeCompany, companyRole } = useCompany();
  // O painel fala da empresa ATIVA. Entra na `queryKey` para que trocar de
  // empresa refaça a consulta em vez de reaproveitar o número da anterior.
  const companyId = activeCompany?.companyId ?? null;
  const activeSegment = getDashboardSegment();
  const segment = SEGMENT_CONFIG[activeSegment];

  const { data } = useQuery({
    queryKey: ["dashboard-command-center", activeSegment, companyId],
    queryFn: async () => {
      const now = new Date();
      const start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
      const end = new Date(now.getFullYear(), now.getMonth() + 1, 1).toISOString();
      const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();

      // ─────────────────────────────────────────────────────────────────
      // TODA consulta deste painel é escopada pela EMPRESA ATIVA (Revisão 39).
      //
      // Antes, `customers`, `quotes` e `charges` iam sem filtro, apoiadas só na
      // RLS. Para quem participa de UMA empresa dá no mesmo; para quem
      // participa de DUAS, as policies (`owner_id = auth.uid() OR
      // is_company_member(company_id)`) devolvem a UNIÃO — e o painel exibia a
      // SOMA das duas empresas, sem mudar ao trocar de empresa. Medido antes da
      // correção: com A = 2 clientes/R$1.000 e B = 5/R$7.000, a tela mostrava
      // "7 clientes" e "R$ 8.000,00" nas DUAS.
      //
      // Não é falha de RLS: a RLS faz o que promete (só dados de empresas do
      // usuário). É o painel que precisa dizer de QUAL delas está falando.
      // Sem empresa ativa não se consulta nada — não há a que se referir.
      // ─────────────────────────────────────────────────────────────────
      const [
        clientes,
        quotes,
        charges,
        stockItems,
        templatesRecentes,
        catalogRecentes,
        totalTemplates,
        totalCatalog,
        vendasMes,
      ] = await Promise.all([
        companyId
          ? safeCount("customers", (q) => q.eq("company_id", companyId))
          : Promise.resolve(0),
        companyId
          ? safeSelect<QuoteDash>("quotes", "id,total,status,etapa,created_at", (q) =>
              q.eq("company_id", companyId).gte("created_at", start).lt("created_at", end),
            )
          : Promise.resolve([] as QuoteDash[]),
        // ITEM 8 (Revisão 43) — a consulta a `financial_entries` SAIU (tabela
        // nunca existiu; 404 por carga). O resumo financeiro do card
        // "Financeiro do mês" veio depois via `useFinanceSummary` /
        // `get_finance_summary` (Revisão 165) — fora deste Promise.all.
        companyId
          ? safeSelect<ChargeDash>("charges", "id,amount,status", (q) =>
              q.eq("company_id", companyId).eq("status", "overdue").limit(25),
            )
          : Promise.resolve([] as ChargeDash[]),
        // ESTOQUE REAL (Revisão 38). Antes: `technical_stock_items`, tabela que
        // nunca existiu — 404 engolido por `safeSelect`, e o card mostrava "0
        // itens em alerta" para sempre. A tabela verdadeira é `inventory_items`
        // (módulo Estoque, validado ponta a ponta na Revisão 34).
        companyId
          ? safeSelect<StockDash>(
              "inventory_items",
              "id,nome,quantidade,estoque_minimo,unidade",
              (q) => q.eq("company_id", companyId).eq("ativo", true).limit(500),
            )
          : Promise.resolve([] as StockDash[]),
        // Projetos recentes — modelos da empresa + catálogo global (lista unificada).
        companyId
          ? safeSelect<TemplateDash>(
              "project_templates",
              "id,nome,area,imagem_url,created_at",
              (q) =>
                q
                  .eq("company_id", companyId)
                  .eq("ativo", true)
                  .order("created_at", { ascending: false })
                  .limit(4),
            )
          : Promise.resolve([] as TemplateDash[]),
        companyId
          ? safeSelect<CatalogDash>(
              "platform_project_catalog",
              "id,nome,area,imagem_url,created_at",
              (q) => q.eq("ativo", true).order("created_at", { ascending: false }).limit(4),
            )
          : Promise.resolve([] as CatalogDash[]),
        companyId
          ? safeCount("project_templates", (q) => q.eq("company_id", companyId).eq("ativo", true))
          : Promise.resolve(0),
        companyId
          ? safeCount("platform_project_catalog", (q) => q.eq("ativo", true))
          : Promise.resolve(0),
        // VENDAS DO MÊS (Revisão 89) — `public.sales`, tabela real desde a
        // migration 20260804120000. Mesmo escopo das outras consultas deste
        // painel: empresa ativa E janela do mês corrente. Nada de contagem
        // global nem de número inventado — se não houver venda, o card diz
        // "nenhuma venda", não "0" (regra das Revisões 37-44).
        companyId
          ? safeSelect<SaleDash>("sales", "id,total,created_at", (q) =>
              q.eq("company_id", companyId).gte("created_at", start).lt("created_at", end),
            )
          : Promise.resolve([] as SaleDash[]),
      ]);

      const modelosMerged: ModeloDash[] = [
        ...templatesRecentes.map((m) => ({
          id: String(m.id),
          nome: String(m.nome ?? "—"),
          area: m.area ?? null,
          imagem_url: m.imagem_url ?? null,
          created_at: String(m.created_at ?? ""),
          imageBucket: "project-images" as const,
        })),
        ...catalogRecentes.map((m) => ({
          id: String(m.id),
          nome: String(m.nome ?? "—"),
          area: m.area ?? null,
          imagem_url: m.imagem_url ?? null,
          created_at: String(m.created_at ?? ""),
          imageBucket: "platform-catalog" as const,
        })),
      ]
        .sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)))
        .slice(0, 4);

      const totalModelos = totalTemplates + totalCatalog;
      const abertos = quotes.filter(
        (q) => q.status === "enviado" || q.status === "rascunho",
      ).length;
      const producao = quotes.filter((q) => q.etapa === "producao").length;
      const instalacoes = quotes.filter((q) => q.etapa === "instalacao").length;
      // ITEM 7 (Revisão 43): `obras` foi REMOVIDA — era calculada, devolvida e
      // nunca renderizada. Mesmo destino de `financeData`, que percorria
      // `financial_entries` a cada carga sem ninguém consumir o resultado.
      // MESMA REGRA da tela de Estoque (`app.estoque.tsx`): item em alerta é o
      // que tem mínimo definido E saldo que já alcançou esse mínimo. Copiar a
      // regra é o ponto — um painel que resume o módulo não pode discordar
      // dele: contar diferente faria o card dizer "3" enquanto a listagem
      // destaca 4 linhas em vermelho.
      //
      // A CONTAGEM e a LISTA saem do MESMO array (Revisão 40). Filtrar duas
      // vezes com regras escritas em lugares diferentes é como o card de
      // contagem e a lista acabariam discordando um do outro com o tempo.
      const emAlerta = stockItems
        .filter(
          (item) =>
            Number(item.estoque_minimo ?? 0) > 0 &&
            Number(item.quantidade ?? 0) <= Number(item.estoque_minimo ?? 0),
        )
        // Mais crítico primeiro, por PROPORÇÃO do mínimo e não pela diferença
        // absoluta: 0 de 10 (0 %) é mais urgente que 90 de 100 (90 %), embora a
        // diferença absoluta seja maior no segundo. Empate resolvido por nome,
        // para a ordem ser estável entre carregamentos.
        .sort((a, b) => {
          const ra = Number(a.quantidade ?? 0) / Number(a.estoque_minimo ?? 1);
          const rb = Number(b.quantidade ?? 0) / Number(b.estoque_minimo ?? 1);
          if (ra !== rb) return ra - rb;
          return String(a.nome ?? "").localeCompare(String(b.nome ?? ""), "pt-BR");
        });

      // ORÇAMENTOS CRIADOS POR DIA no mês corrente (Revisão 41).
      //
      // Sai do array `quotes` que JÁ foi carregado acima — mesma consulta, mesmo
      // recorte de mês, mesma empresa. Zero consulta adicional e zero
      // dependência nova: é o dado real mais barato que este painel tinha à
      // disposição, e foi por isso que substituiu o gráfico desenhado à mão.
      const orcamentosPorDia = Array.from({ length: daysInMonth }, (_, i) => ({
        dia: i + 1,
        qtd: 0,
      }));
      for (const q of quotes) {
        if (!q.created_at) continue;
        const d = new Date(q.created_at).getDate();
        if (d >= 1 && d <= daysInMonth) orcamentosPorDia[d - 1].qtd += 1;
      }
      const totalOrcamentosMes = quotes.length;

      const estoqueBaixo = emAlerta.length;
      const itensEmAlerta = emAlerta.slice(0, MAX_ITENS_ALERTA).map((item) => ({
        id: String(item.id),
        nome: String(item.nome ?? "—"),
        quantidade: Number(item.quantidade ?? 0),
        minimo: Number(item.estoque_minimo ?? 0),
        unidade: String(item.unidade ?? ""),
      }));

      return {
        clientes,
        abertos,
        producao,
        instalacoes,
        cobrancasVencidas: charges.length,
        estoqueBaixo,
        itensEmAlerta,
        orcamentosPorDia,
        totalOrcamentosMes,
        modelos: modelosMerged.map((m) => ({
          id: m.id,
          nome: m.nome,
          area: String(m.area ?? ""),
          imagem: m.imagem_url,
          imageBucket: m.imageBucket,
        })),
        totalModelos,
        // Revisão 89 — os dois saem do MESMO array, pelo motivo que a Revisão 40
        // registrou para o estoque: contagem e valor calculados em lugares
        // diferentes acabam discordando entre si com o tempo.
        vendasMesQtd: vendasMes.length,
        vendasMesTotal: vendasMes.reduce((s, v) => s + Number(v.total || 0), 0),
      };
    },
  });

  const financePeriod = currentMonthPeriod();
  const {
    data: financeSummary,
    isLoading: loadingFinance,
    isError: financeError,
  } = useFinanceSummary(companyId, !companyId ? null : financePeriod);
  const caixaTotal = financeSummary
    ? financeSummary.caixa_vendas + financeSummary.caixa_cobrancas
    : null;

  const firstName =
    user?.user_metadata?.name?.split?.(" ")?.[0] || user?.email?.split("@")[0] || "usuário";

  const canCreateOrcamento = resolvesFinePermission(
    isAdmin,
    companyRole,
    permissions,
    "create_orcamentos",
  );

  const visibleModules =
    activeSegment === "complete" ? modules : modules.filter((item) => item.slug === activeSegment);
  const activeHeroImage =
    activeSegment === "complete"
      ? segmentVidracaria
      : moduleImages[activeSegment as Exclude<SegmentSlug, "complete">];

  return (
    <div className="space-y-6">
      <header className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">
            {new Date().toLocaleDateString("pt-BR", {
              weekday: "long",
              day: "2-digit",
              month: "long",
              year: "numeric",
            })}
          </p>
          <h1 className="font-display text-3xl font-bold tracking-tight md:text-4xl">
            Bom dia, {firstName}! 👋
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Sua central de comando para {segment.label}. {segment.description}
          </p>
        </div>
        {/* ITEM 4 (Revisão 43) — o campo "Buscar no sistema..." com o selo
              "Ctrl + K" foi REMOVIDO. Era um <input> sem handler e sem atalho
              registrado: não existe busca global no app. Implementar só o
              atalho deixaria o campo em foco e ainda sem buscar nada — tornaria
              a promessa falsa mais visível, não menos. Volta quando houver
              busca de verdade.

              ITEM 6 — o sino também saiu. Era um <button> sem onClick, e o
              `AppShell` (que ENVOLVE esta tela) já renderiza o
              `NotificationsBell` real, ligado a `auth_events`. Eram dois sinos
              na mesma tela, um deles falso. O número que ele exibia (cobranças
              vencidas) continua no card "Cobranças". */}
        <div className="flex flex-wrap items-center gap-3">
          {canCreateOrcamento && (
            <Link
              to="/app/orcamentos/novo"
              className="inline-flex h-12 items-center gap-2 rounded-2xl bg-primary px-5 text-sm font-semibold text-primary-foreground shadow-sm hover:opacity-90"
            >
              <Plus className="h-4 w-4" /> Novo orçamento
            </Link>
          )}
        </div>
      </header>

      {/* Ferramentas de plataforma (IA, etc.) ficam em Administração — não no
            Dashboard tenant. O herói ocupa a linha inteira para todos. */}
      <section className="grid gap-4">
        <div className="overflow-hidden rounded-3xl border bg-card shadow-sm">
          <div className="grid md:grid-cols-[1.2fr_0.8fr]">
            <div className="p-5 md:p-6">
              <h2 className="text-2xl font-bold md:text-3xl">Centro de comando da sua empresa</h2>
              <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
                Acompanhe operação, financeiro, estoque e projetos em um único painel. As
                informações aparecem conforme o segmento escolhido no login.
              </p>
            </div>
            <div
              className="min-h-[140px] bg-cover bg-center md:min-h-full"
              style={{
                backgroundImage: `linear-gradient(90deg, rgba(15,23,42,0.25), rgba(15,23,42,0.05)), url(${activeHeroImage})`,
              }}
            />
          </div>
        </div>
      </section>

      {/* ITEM 1 (Revisão 44) — saiu o card "Sugestões da IA", cujo valor era
            o literal "2". Não há consulta por trás dele: `ai_dialog_suggestions`
            existe no schema mas não tem `company_id`/`owner_id` (só `session_id`)
            e nada no dashboard a consultava. Cinco métricas reais valem mais que
            seis com uma inventada. */}
      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Metric
          icon={FileText}
          label="Orçamentos"
          value={String(data?.abertos ?? 0)}
          sub="Pendentes"
          color="blue"
        />
        <Metric
          icon={CalendarCheck}
          label="Instalações"
          value={String(data?.instalacoes ?? 0)}
          sub="Agendadas"
          color="green"
        />
        <Metric
          icon={Package}
          label="Estoque baixo"
          value={String(data?.estoqueBaixo ?? 0)}
          sub="Itens em alerta"
          color="orange"
        />
        <Metric
          icon={WalletCards}
          label="Cobranças"
          value={String(data?.cobrancasVencidas ?? 0)}
          sub="Vencidas"
          color="red"
        />
        <Metric
          icon={Users}
          label="Clientes"
          value={String(data?.clientes ?? 0)}
          sub="Cadastrados"
          color="cyan"
        />
      </section>

      <section className="rounded-3xl border bg-card p-4 shadow-sm">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold">Ações rápidas</h2>
        </div>
        <div className="grid gap-3 md:grid-cols-3 xl:grid-cols-6">
          {segment.quickActions
            .filter((action) => {
              const href = DESTINO_ACAO[action];
              if (!href) return false;
              const need = finePermissionForNavTo(href);
              if (!need) return true;
              return resolvesFinePermission(isAdmin, companyRole, permissions, need);
            })
            .map((action) => (
              <QuickAction key={action} label={action} href={DESTINO_ACAO[action]} />
            ))}
        </div>
      </section>

      <section className="grid gap-4 xl:grid-cols-[1.4fr_0.95fr]">
        <div className="rounded-3xl border bg-card p-5 shadow-sm">
          <div className="mb-4 flex items-center justify-between">
            {/* Contagem REAL: templates da empresa + catálogo global ativos. */}
            <h2 className="font-display text-lg font-bold">Projetos recentes</h2>
            <div className="flex items-center gap-3">
              {(data?.totalModelos ?? 0) > (data?.modelos ?? []).length && (
                <span className="text-sm text-muted-foreground">{data?.totalModelos} no total</span>
              )}
              <Link to="/app/projetos" className="text-sm font-semibold text-gold">
                Ver todos
              </Link>
            </div>
          </div>
          {(data?.modelos ?? []).length === 0 ? (
            <EmptyState text="Nenhum projeto disponível ainda." />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {(data?.modelos ?? []).map((m) => (
                <ProjectCard
                  key={`${m.imageBucket}-${m.id}`}
                  imagem={m.imagem}
                  imageBucket={m.imageBucket}
                  title={m.nome}
                  subtitle={ROTULO_AREA[m.area as AreaProjeto] ?? "Projeto técnico"}
                />
              ))}
            </div>
          )}
        </div>

        {/* Card "Agenda de hoje" removido: módulo Agenda oculto para tenants.
              Não havia query real de agenda no dashboard (só EmptyState + link). */}
        {/* Revisão 165 — card "Financeiro do mês". Antes: Faturamento dos
              orçamentos aprovados + Despesas/Lucro/"Fluxo de caixa" = "Sem
              dados" (módulo ainda não existia, Rev. 38–43). Agora usa o mesmo
              `useFinanceSummary` / `get_finance_summary` do Resumo em
              `/app/financeiro`, mês corrente. G4: Faturamento e Caixa total em
              linhas distintas; Lucro = caixa − despesas (sem misturar). */}
        <Card title="Financeiro do mês" link="Ver financeiro" href="/app/financeiro">
          {!companyId ? (
            <EmptyState text="Selecione uma empresa ativa para ver o financeiro do mês." />
          ) : loadingFinance && !financeSummary ? (
            <EmptyState text="Carregando resumo financeiro…" />
          ) : financeError || !financeSummary || caixaTotal === null ? (
            <EmptyState text="Não foi possível carregar o resumo financeiro." />
          ) : (
            <>
              <MoneyRow label="Faturamento" value={brl(financeSummary.faturamento)} positive />
              <MoneyRow label="Caixa total" value={brl(caixaTotal)} positive />
              <MoneyRow label="Despesas" value={brl(financeSummary.despesas)} />
              <MoneyRow
                label="Lucro estimado"
                value={brl(financeSummary.lucro_estimado)}
                positive={financeSummary.lucro_estimado >= 0}
              />
            </>
          )}
        </Card>
      </section>

      <section className="grid gap-4 xl:grid-cols-[0.9fr_0.9fr_0.9fr]">
        {/* Revisão 40 — este card listava `segment.stockFocus`, uma lista FIXA
              de nomes por segmento ("Vidro temperado 8mm"...), sempre com
              `current={0}`: itens que a empresa talvez nem tivesse, com saldo
              inventado. Agora são os itens reais de `inventory_items` da
              empresa ativa, os mais críticos primeiro. */}
        <Card title="Estoque - itens em alerta" link="Ver estoque completo" href="/app/estoque">
          {(data?.itensEmAlerta ?? []).length === 0 ? (
            <EmptyState text="Nenhum item em alerta. Os itens aparecem aqui quando o saldo atinge o estoque mínimo." />
          ) : (
            <>
              {(data?.itensEmAlerta ?? []).map((item) => (
                <StockRow
                  key={item.id}
                  name={item.nome}
                  current={item.quantidade}
                  min={item.minimo}
                  unit={item.unidade}
                />
              ))}
              {/* Só aparece quando há mais do que cabe na lista — para o
                    resumo não se passar por inventário completo. */}
              {(data?.estoqueBaixo ?? 0) > MAX_ITENS_ALERTA && (
                <p className="pt-1 text-xs text-muted-foreground">
                  e mais {(data?.estoqueBaixo ?? 0) - MAX_ITENS_ALERTA}{" "}
                  {(data?.estoqueBaixo ?? 0) - MAX_ITENS_ALERTA === 1 ? "item" : "itens"} em alerta
                </p>
              )}
            </>
          )}
        </Card>

        {/* Revisão 89 — a Venda direta passou a gravar (Rev. 87) e ganhou
              histórico (Rev. 88), mas o Dashboard não apontava para nenhum dos
              dois: quem chegava por aqui só via "Nova venda" nas ações rápidas
              e não descobria que existia consulta.

              Os dois números são REAIS e da empresa ativa — `public.sales`,
              janela do mês corrente, mesmo escopo das outras consultas do
              painel. Sem venda no mês o card diz isso por extenso, em vez de
              exibir "0 vendas · R$ 0,00", que se lê como medição de negócio
              parado quando na verdade é ausência de dado (Revisões 38 e 41). */}
        <Card title="Vendas do mês" link="Ver histórico" href="/app/vendas">
          {(data?.vendasMesQtd ?? 0) === 0 ? (
            <EmptyState text="Nenhuma venda registrada neste mês. As vendas de balcão aparecem aqui assim que forem finalizadas." />
          ) : (
            <>
              <MoneyRow
                label={(data?.vendasMesQtd ?? 0) === 1 ? "Venda registrada" : "Vendas registradas"}
                value={String(data?.vendasMesQtd ?? 0)}
              />
              <MoneyRow label="Total vendido" value={brl(data?.vendasMesTotal ?? 0)} positive />
            </>
          )}
        </Card>

        <Card title="Orçamentos em aberto" link="Ver todos" href="/app/orcamentos">
          {(data?.abertos ?? 0) === 0 ? (
            <EmptyState text="Nenhum orçamento pendente no momento." />
          ) : (
            <>
              <MoneyRow label="Orçamentos pendentes" value={String(data?.abertos ?? 0)} />
              <MoneyRow label="Produção" value={String(data?.producao ?? 0)} />
              <MoneyRow label="Instalações" value={String(data?.instalacoes ?? 0)} />
            </>
          )}
        </Card>

        {/* Revisão 41 — este card se chamava "Performance" e era um DESENHO:
              dois <path> SVG com curvas ascendentes fixas, sob a legenda "os
              gráficos passam a refletir dados reais conforme a empresa usa o
              sistema" — o que nunca aconteceria, porque não havia dado ligado.
              Agora mostra orçamentos criados por dia no mês, calculados do
              array `quotes` que a página já carrega. O link ia para
              `/app/relatorios`, rota INEXISTENTE; aponta para Orçamentos, que
              é onde se age sobre o que o gráfico mostra. */}
        <Card title="Orçamentos criados no mês" link="Ver orçamentos" href="/app/orcamentos">
          {(data?.totalOrcamentosMes ?? 0) === 0 ? (
            <EmptyState text="Nenhum orçamento criado neste mês. O gráfico aparece a partir do primeiro." />
          ) : (
            <>
              <GraficoBarras pontos={data?.orcamentosPorDia ?? []} />
              <p className="text-sm text-muted-foreground">
                <strong className="text-foreground">{data?.totalOrcamentosMes ?? 0}</strong>{" "}
                {(data?.totalOrcamentosMes ?? 0) === 1 ? "orçamento criado" : "orçamentos criados"}{" "}
                em {new Date().toLocaleDateString("pt-BR", { month: "long" })}.
              </p>
            </>
          )}
        </Card>
      </section>
    </div>
  );
}

function Metric({
  icon: Icon,
  label,
  value,
  sub,
  color,
}: {
  icon: LucideIcon;
  label: string;
  value: string;
  sub: string;
  color: string;
}) {
  const colorClass: Record<string, string> = {
    blue: "bg-sky-500/15 text-sky-600 dark:text-sky-300",
    green: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-300",
    orange: "bg-orange-500/15 text-orange-600 dark:text-orange-300",
    red: "bg-red-500/15 text-red-600 dark:text-red-300",
    purple: "bg-purple-500/15 text-purple-600 dark:text-purple-300",
    cyan: "bg-cyan-500/15 text-cyan-600 dark:text-cyan-300",
  };
  return (
    <div className="rounded-3xl border bg-card p-5 shadow-sm">
      <div className={`mb-4 grid h-12 w-12 place-items-center rounded-2xl ${colorClass[color]}`}>
        <Icon className="h-5 w-5" />
      </div>
      <p className="text-2xl font-bold">{value}</p>
      <p className="text-sm font-semibold text-foreground">{label}</p>
      <p className="text-xs text-muted-foreground">{sub}</p>
    </div>
  );
}

function QuickAction({ label, href }: { label: string; href: AppTo }) {
  return (
    <Link
      to={href}
      className="flex min-h-[76px] items-center gap-3 rounded-2xl border bg-muted p-4 text-left text-sm font-semibold text-foreground transition hover:border-primary/30 hover:bg-accent"
    >
      <span className="grid h-10 w-10 place-items-center rounded-2xl bg-primary/10 text-primary">
        <BriefcaseBusiness className="h-4 w-4" />
      </span>
      {label}
    </Link>
  );
}

function ProjectCard({
  imagem,
  imageBucket = "project-images",
  title,
  subtitle,
}: {
  imagem: string | null;
  imageBucket?: "project-images" | "platform-catalog";
  title: string;
  subtitle: string;
}) {
  // Sem foto → bloco neutro. Bucket conforme origem (empresa vs catálogo).
  return (
    <Link
      to="/app/projetos"
      className="overflow-hidden rounded-2xl border bg-card shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
    >
      {imagem ? (
        <StorageImage
          bucket={imageBucket}
          src={imagem}
          alt={title}
          className="h-40 w-full object-cover"
        />
      ) : (
        <div className="grid h-40 place-items-center bg-muted text-muted-foreground">
          <Package className="h-8 w-8" />
        </div>
      )}
      <div className="p-3">
        <p className="truncate font-semibold text-foreground" title={title}>
          {title}
        </p>
        <p className="text-xs text-muted-foreground">{subtitle}</p>
      </div>
    </Link>
  );
}

function Card({
  title,
  link,
  href,
  children,
}: {
  title: string;
  link: string;
  href: AppTo;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-3xl border bg-card p-5 shadow-sm">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="font-display text-lg font-bold">{title}</h2>
        <Link to={href} className="text-sm font-semibold text-gold">
          {link}
        </Link>
      </div>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

/**
 * Barras verticais simples, uma por dia do mês (Revisão 41).
 *
 * SVG puro de propósito: `recharts` está no projeto, mas exigiria `ClientOnly`
 * (não renderiza no servidor) e traria um gráfico completo para mostrar uma
 * contagem por dia. Aqui a altura de cada barra é proporcional ao maior dia do
 * mês, e o `title` de cada uma diz a data e a contagem no hover.
 */
function GraficoBarras({ pontos }: { pontos: { dia: number; qtd: number }[] }) {
  const maximo = Math.max(1, ...pontos.map((p) => p.qtd));
  return (
    <div className="flex h-36 items-end gap-[2px] rounded-2xl bg-gradient-to-t from-muted to-card p-3">
      {pontos.map((p) => (
        <div
          key={p.dia}
          title={`Dia ${p.dia}: ${p.qtd} ${p.qtd === 1 ? "orçamento" : "orçamentos"}`}
          className="flex-1 rounded-t-sm bg-primary/80"
          // Altura mínima visível para o dia com zero não sumir: a barra rasa
          // comunica "houve o dia, não houve orçamento".
          style={{ height: p.qtd === 0 ? "2px" : `${Math.max(6, (p.qtd / maximo) * 100)}%` }}
        />
      ))}
    </div>
  );
}

// REMOVIDO na Revisão 41: `Timeline`, que só existia para desenhar os quatro
// compromissos fixos da "Agenda de hoje". Sem fonte de dados real, o componente
// ficou sem uso — e manter componente morto "para quando a agenda existir" é
// exatamente como este arquivo acumulou o mock que a Revisão 40 catalogou.

function MoneyRow({
  label,
  value,
  positive,
}: {
  label: string;
  value: string;
  positive?: boolean;
}) {
  return (
    <div className="flex items-center justify-between border-b border-border pb-3 last:border-0 last:pb-0">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className={`font-bold ${positive ? "text-success" : "text-foreground"}`}>{value}</span>
    </div>
  );
}

function StockRow({
  name,
  current,
  min,
  unit,
}: {
  name: string;
  current: number;
  min: number;
  unit?: string;
}) {
  // "saldo / mínimo" na unidade do próprio item — sem a unidade, "1 / 10" não
  // diz se falta uma peça ou um metro.
  const medida = unit ? `${current} / ${min} ${unit}` : `${current} / ${min}`;
  return (
    <div className="grid grid-cols-[1fr_auto_70px] items-center gap-3 border-b border-border pb-3 text-sm last:border-0 last:pb-0">
      <span className="truncate font-semibold text-foreground" title={name}>
        {name}
      </span>
      <span className="whitespace-nowrap text-muted-foreground">{medida}</span>
      <span className="rounded-full bg-destructive/10 px-2 py-1 text-center text-xs font-semibold text-destructive">
        Baixo
      </span>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="rounded-2xl border border-dashed bg-muted p-6 text-center text-sm text-muted-foreground">
      {text}
    </div>
  );
}
