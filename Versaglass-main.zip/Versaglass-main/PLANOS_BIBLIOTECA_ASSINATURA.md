# Planos com biblioteca bloqueada por assinatura

Implementado no código:

- `/catalogo` com todos os modelos visíveis.
- Modelos bloqueados com blur, cadeado e botão de desbloqueio.
- `/planos` com FREE, PRO e PREMIUM.
- `/upgrade-premium` para clientes PRO desbloquearem tudo.
- `/editor/:modelId` respeitando regras de plano.
- `/projeto/:projectId` e `/pdf/:projectId` preparados para fluxo de projeto e PDF.
- `/admin/modelos` e `/admin/planos` para gestão administrativa.
- Hook `useSubscriptionAccess`.
- Serviço `accessControl` com `getUserPlan` e `canAccessModel`.
- Migration Supabase `20260703030000_subscription_locked_library.sql` com tabelas, seeds, funções e RLS.

Regras:

- Visitante/free: apenas modelos `freePreview`, sem edição, sem PDF e sem download.
- PRO: acesso parcial por categoria + edição, PDF, imagem, lista de corte, lista de materiais e salvar projeto.
- PREMIUM: acesso total + DXF, DWG, SVG, IA, render HD e suporte prioritário.
