# Biblioteca técnica por plano

Implementado no ZIP:

- Menu **Materiais** no painel lateral.
- Aba **Alumínios** própria em `/app/aluminios`.
- Aba **Estoque > Alumínios** em `/app/estoque/aluminios`.
- Botão dentro do estoque: **Catálogo de alumínios**.
- Bloqueio visual com cadeado para módulos fora do plano.
- Tela de upgrade quando o cliente tenta acessar módulo bloqueado.
- Migration Supabase para `platform_plans`, `platform_modules`, `plan_module_access` e `company_module_access`.

## Regras de acesso

Plano Vidraçaria libera:
- Vidros
- Alumínios
- Ferragens para vidro

Plano Marcenaria libera:
- MDF e chapas
- Ferragens para móveis

Plano Marmoraria libera:
- Mármores e granitos
- Quartzos
- Porcelanatos

Plano Serralheria libera:
- Serralheria
- Aço e metalon

Plano Completo libera tudo.
