# Upgrade da aba Projetos

Alterações aplicadas:

- Corrigida a aba **Projetos** para exibir imagens nos cards.
- Criados botões de filtro por área:
  - Vidraçaria
  - Serralheria de aço
  - Marcenaria
  - Marmoraria
- Adicionados filtros por modelo:
  - 2D
  - 3D
  - 2D + 3D
- Adicionada busca por nome, categoria e descrição.
- Criados projetos visuais em SVG dentro de `public/projetos/`.
- Criados modelos para:
  - Box de vidro 2D e 3D
  - Guarda-corpo de vidro 2D
  - Portão basculante de aço 2D e 3D
  - Grade de janela de aço 2D
  - Armário aéreo MDF 2D e 3D
  - Painel de TV ripado 2D
  - Bancada de pia em granito 2D e 3D
  - Escada em mármore/granito 2D
- Mantida compatibilidade com os projetos já cadastrados no Supabase em `project_templates`.
- Os projetos locais são modelos padrão e aparecem mesmo sem cadastro no banco.

Arquivo principal alterado:

- `src/routes/_authenticated/app.projetos.tsx`

Imagens adicionadas:

- `public/projetos/*.svg`

Observação:

Os projetos 2D e 3D adicionados são modelos técnicos ilustrativos para venda, orçamento e apresentação ao cliente. As medidas podem ser ajustadas em cada orçamento.
