# Upgrade: editor de desenho após orçamento criado

Foi adicionado ao detalhe do orçamento um editor técnico por item.

## O que permite fazer

- Abrir um orçamento já criado.
- Em cada item, clicar em **Editar desenho** ou **Alterar desenho**.
- Adicionar recortes retangulares.
- Adicionar furos redondos.
- Adicionar meia-lua ou rasgo.
- Adicionar ferragens como dobradiça, puxador, fechadura, trilho, roldana, mola, suporte tucano, prolongador e kit box.
- Posicionar tudo por coordenadas X/Y em milímetros.
- Salvar observações técnicas.
- Visualizar prévia SVG do projeto.

## Banco de dados

Migration adicionada:

`supabase/migrations/20260701023000_quote_drawing_editor.sql`

Campos novos em `quote_items`:

- `drawing_data jsonb`
- `drawing_notes text`
- `updated_at timestamptz`

## Arquivos criados/alterados

- `src/components/ProjectDrawingEditor.tsx`
- `src/routes/_authenticated/app.orcamentos.$id.tsx`
- `supabase/migrations/20260701023000_quote_drawing_editor.sql`

