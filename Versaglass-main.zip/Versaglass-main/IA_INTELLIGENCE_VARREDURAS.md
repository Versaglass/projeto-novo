# IA Intelligence — Aprendizado e Varreduras

Implementado:

- Aprendizado manual da IA por informação enviada pelo ADM.
- Botão de varredura por período:
  - 15 dias
  - 30 dias
  - 60 dias
  - 3 meses
  - 6 meses
- Varredura em estoque, financeiro, fiscal e logs da IA.
- Identificação de problema, causa provável e solução.
- Botão para autorizar solução com senha do ADM.
- Registro em tabelas próprias com RLS.
- A IA continua oculta para usuários comuns.

Fluxo:

1. ADM abre IA Intelligence.
2. Registra conhecimento ou executa varredura.
3. A IA mostra achados com problema, causa e solução.
4. ADM clica em autorizar solução.
5. Sistema gera prévia da ação.
6. ADM confirma com senha.
7. Ação é registrada em logs e snapshots.
