# Segurança de Acesso com 2 Fatores

Implementado no projeto:

- Tela `/first-password` para criar primeira senha com validação por código.
- Tela `/forgot-password-2fa` para recuperar senha por e-mail, celular ou e-mail + celular.
- Validação de senha forte.
- Integração com `supabase.auth.signInWithOtp`, `verifyOtp` e `updateUser`.
- Logs em `security_events`.
- Tabelas Supabase para auditoria, tokens, códigos 2FA e bloqueios.
- Página administrativa `/app/admin/acesso-seguro`.
- Link na tela de login para recuperação segura por código.

Observação: envio por SMS/WhatsApp depende do provedor de telefone configurado no Supabase ou função serverless própria.
