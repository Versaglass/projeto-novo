# IA Intelligence Administrativa

> ⚠️ **Modo seguro ativo (2026-07-23 · P-26 em `docs/PENDENCIAS_SUPABASE.md`).**
> A **execução administrativa da IA está temporariamente desativada** por uma flag
> central de build: `AI_ADMIN_EXECUTION_ENABLED = false`
> (`src/modules/ai-intelligence/config.ts`). Motivo: a persistência operacional
> (`ai_intelligence_commands`, `_logs`, `_snapshots`, `_approvals`, `_rollbacks`,
> `_scans`, `_scan_findings`, `_knowledge`, `ai_agents`, `ai_guided_workflows`,
> `integration_*`, `project_media_changes` — 19 tabelas) **não existe no schema**;
> essas estruturas vieram das migrations antigas descartadas na baseline (P-19).
>
> **O que permanece disponível:** a **orientação** da IA (`iaAdvise`, gateway externo,
> sem banco) e a **prévia** de uma ação (cálculo no cliente, somente leitura).
> **O que fica desligado:** enviar/confirmar execução, salvar conhecimento, varredura,
> criar/gerenciar IAs, fluxo assistido, histórico e restauração — botões desabilitados
> na UI **e** guardados no código (não tocam o Supabase), com defesa também no executor
> (`aiActionExecutor`). Nenhuma mensagem técnica, nome de tabela ou stack trace é
> exibido; falhas de execução (quando a flag voltar a `true`) continuam auditadas em
> `audit_logs` (correção de 2026-07-23).
>
> **Referências obsoletas (dívida técnica, sem correção nesta etapa):**
> `company_products` e `technical_stock_items` não existem; a tabela de estoque real é
> `inventory_items`. A substituição exige análise funcional, não troca automática.
>
> **Reativação** exige, em conjunto: (1) schema curado **aprovado**; (2) persistência
> por **server functions** + `supabaseAdmin` (padrão P-07), nunca INSERT direto do
> navegador; (3) revisão de RLS. **Não** recriar as migrations descartadas e **não**
> transformar a flag em variável de ambiente/`VITE_` ou valor editável pelo cliente.

Implementado no sistema:

- Botão flutuante **IA Intelligence** visível somente para ADM.
- Página `/app/ia-intelligence`.
- Comando explícito antes de qualquer ação.
- Prévia obrigatória da ação.
- Confirmação com senha do ADM em toda execução.
- Logs, snapshots, approvals e rollbacks no Supabase.
- Modo avançado para operar tabelas com JSON, respeitando RLS.
- Ações iniciais: criar produto, solicitação de inventário/estoque, template de login, operação avançada em tabela e registro de mudança geral.

Exemplo de comando avançado:

`Tabela: company_products; operação: update; json: {"id":"UUID","sale_price":899}`
