# Multiusuário e isolamento de dados

Implementado como regra de arquitetura:

- O administrador da plataforma controla planos, assinaturas e empresas assinantes.
- O administrador da plataforma **não vê** os clientes finais cadastrados pelas empresas assinantes.
- Clientes, orçamentos e estoque ficam isolados por `company_id` e/ou `owner_id`.
- Funcionários da mesma empresa podem compartilhar dados conforme o papel interno: owner, admin, manager, operator, installer ou seller.
- Módulos aparecem com cadeado quando o plano não libera o segmento.

Exemplo de acesso:

- Plano Marcenaria: libera MDF, ferragens de móveis, projetos e plano de corte da marcenaria.
- Plano Vidraçaria: libera vidros, alumínios, ferragens de vidro e projetos de vidro.
- Plano Serralheria: libera aço, metalon, portões, galpões e estruturas.
- Plano Marmoraria: libera pedras, bancadas, cubas, recortes e plano de corte.
- Plano Completo: libera tudo.

As políticas RLS do Supabase foram reforçadas na migration `20260703010000_multiuser_tenant_isolation_and_sales_finance.sql`.

---

## Estoque — de isolamento por usuário para por empresa (2026-07-27)

**Decisão de segurança nova.** O catálogo de materiais (`public.inventory_items`)
**já tinha** `company_id`, FK e policies por tenant desde a baseline, mas a aplicação
nunca gravava nem filtrava a coluna: com `company_id` sempre NULL, o único ramo ativo
da RLS era `owner_id = auth.uid()` e o estoque ficava **privado por usuário**. Agora o
catálogo é **da empresa**, compartilhado entre os membros. Migrations
`20260727000000_inventory_category_expand.sql` e
`20260727010000_inventory_company_crud.sql` (validadas localmente, **push pendente**).

- **`owner_id` permanece** como CRIADOR do item; **`company_id`** é o tenant, agora
  **NOT NULL**.
- **Leitura**: qualquer membro ativo da empresa (`is_company_member`). O ramo
  `owner_id = auth.uid()` **saiu da leitura** de propósito — quem deixa a empresa perde
  o acesso ao catálogo dela, inclusive aos itens que criou. Admin de plataforma **não**
  recebe acesso automático aos estoques dos tenants.
- **Edição/Exclusão**: criador **ou** papel empresarial owner/admin/manager
  (`is_company_admin`). Isso vale também para **alterar o saldo** e para **desativar**,
  que são UPDATE comum: um seller mexe apenas nos itens que ele mesmo cadastrou.
- **Criação**: qualquer membro; `owner_id = auth.uid()` e `company_id` de uma empresa da
  qual é membro — nunca do formulário.
- **Defesa no banco além da RLS**: trigger `inventory_items_lock_tenant` torna
  `company_id` e `owner_id` **imutáveis**; CHECK obriga `imagem_url` a ser NULL ou um
  PATH no prefixo da própria empresa; CHECKs impedem quantidade e preços negativos
  (antes só o Zod do navegador validava, e ele é contornável).
- **Storage**: **nenhuma policy nova**. O caminho passa a ser
  `<company_id>/estoque/<uuid>.<ext>` e as policies empresariais de `20260724040000` já
  o cobrem, porque chaveiam apenas o 1º segmento do path. As policies por pasta de
  usuário continuam existindo para os caminhos legados.
- **Orçamentos não são afetados**: `quote_items` não tem FK para `inventory_items` e
  guarda o próprio snapshot de descrição e preço. Editar ou excluir um item do Estoque
  **não altera** orçamento já salvo, e criar orçamento **não baixa saldo**.

Validado localmente (39/39): compartilhamento entre membros, permissões por papel,
isolamento entre empresas (B não lista, não lê, não edita, não exclui e não altera
quantidade), imutabilidade de company_id/owner_id, constraints de imagem_url e de
não-negativo, forja de company_id/owner_id/path rejeitada, snapshot do orçamento
preservado após mudança de preço, e Storage negando o prefixo de outra empresa.

---

## Biblioteca de Projetos Técnicos — de isolamento por usuário para por empresa (2026-07-24 · em vigor no remoto desde 2026-07-27)

**Decisão de segurança nova.** Os modelos técnicos reutilizáveis (`public.project_templates`)
eram isolados **por usuário** (`owner_id = auth.uid()`). Passam a ser isolados **por empresa**
(`company_id`), compartilhados entre os membros — decisão de domínio confirmada (vendedores,
projetistas e demais membros usam a mesma biblioteca). Migrations
`20260724030000_project_templates_company.sql` e
`20260724040000_project_templates_hardening.sql` — **ambas aplicadas no remoto** e alinhadas
local↔remoto (`db push --dry-run`: remoto atualizado).

- **`owner_id` permanece** como CRIADOR do modelo; **`company_id`** passa a ser o tenant.
- **Leitura**: qualquer membro ativo da empresa (`is_company_member`). Usuário de outra empresa
  não lê por ID. Admin de plataforma **não** recebe acesso automático aos templates dos tenants.
- **Edição/Exclusão**: criador **ou** papel empresarial owner/admin/manager (`is_company_admin`).
  Demais papéis (operator/installer/seller) visualizam e utilizam, mas não alteram.
- **Criação**: `owner_id = auth.uid()` e `company_id` de uma empresa da qual é membro — nunca do
  formulário. Backfill seguro só para owners com exatamente uma empresa; ambíguos ficam NULL
  (transitório: acessível só ao criador). Nenhum dado apagado.
- **Storage `project-images`** (privado): adicionadas policies por empresa para o caminho
  `<company_id>/<uuid>` (membro da empresa lê/envia); as policies por pasta de usuário são
  mantidas (Estoque e legado intactos). Comparação por texto (sem cast de path para uuid).
- **`public.quotes` continua sendo a obra/projeto comercial** do cliente (`quotes.etapa` = ciclo);
  `project_templates` **não** é vinculado a customers/quotes.

**Defesa no banco (além da RLS):** um **trigger `BEFORE UPDATE`**
(`project_templates_lock_tenant`) torna `company_id` e `owner_id` **imutáveis** (rejeita
`IS DISTINCT FROM`), impedindo mover o template de empresa ou trocar o criador por chamada
direta. Uma **CHECK constraint** garante que `imagem_url` seja NULL ou um PATH no prefixo da
própria empresa (`split_part(imagem_url,'/',1) = company_id::text`). No **Storage**,
UPDATE/DELETE de imagens da empresa são restritos a **quem enviou o objeto**
(`storage.objects.owner_id = auth.uid()`) **ou owner/admin/manager** — um seller que não
enviou não apaga/sobrescreve imagem alheia; as policies por-pasta-de-usuário (Estoque) só
autorizam `foldername[1]=auth.uid()`.

Validado localmente (24/24): compartilhamento entre membros, permissões por papel, isolamento
entre empresas, imutabilidade de company_id/owner_id, constraint de imagem_url, forja de
company_id/owner_id/path rejeitada, seller não apaga imagem de outro criador, Estoque preservado.

**Validado no remoto pela interface (2026-07-27).** Template criado com `company_id` correto e
`owner_id` do usuário autenticado; imagem gravada no prefixo empresarial; membro da mesma
empresa visualizou; **seller não conseguiu apagar imagem enviada por outro uploader**;
manager administrou; **outra empresa não acessou template nem imagem**; exclusão removeu o
template e sua imagem; "salvar como modelo" pelo editor de Orçamentos gravou no tenant certo;
troca de empresa recarregou a biblioteca; nenhum card mock apareceu. Detalhe em
`docs/PENDENCIAS_SUPABASE.md` → "Biblioteca de Projetos Técnicos → Validação remota".

---

## Autorização de rotas administrativas (2026-07-22)

Regra de arquitetura, aplicada a todas as 13 rotas administrativas.

### As camadas, em ordem de autoridade

1. **`beforeLoad: requireAdmin` no router — proteção obrigatória.**
   `src/lib/admin-guard.ts` é a **única** definição de "é administrador" no
   roteamento. Nenhuma rota administrativa pode replicar a consulta a
   `user_roles` inline. Sem sessão → `/auth`; autenticado sem o papel → `/app`.
   Roda antes de qualquer componente ou consulta da página.

2. **Guard de componente — defesa adicional, nunca a principal.**
   `if (!isAdmin) return null` continua onde já existia, mas não é mecanismo de
   autorização: ele só age depois que o componente foi montado.

3. **RLS no Postgres — última camada.**
   Vale mesmo que router e componente falhem. É o que impede vazamento de dado
   real, e por isso nenhuma rota administrativa deve depender só dela.

**O menu não é mecanismo de autorização.** `adminOnly` no `AppShell` apenas
esconde itens; a URL continua digitável. Ocultar não protege.

**Rotas sem consulta ao banco também precisam de guard.** `/app/admin/fiscal`,
`/app/admin/pagamentos`, `/admin/planos` e `/admin/modelos` servem dados mock ou
estáticos — mesmo assim recebem `requireAdmin`, porque o problema é autorização
de acesso, não vazamento atual. No dia em que o mock virar consulta real, a
proteção já está no lugar.

### Papéis são avaliados como conjunto

Um usuário pode ter mais de uma linha em `user_roles` — quem se cadastra recebe
`vendedor` do trigger `on_auth_user_created` e, se for promovido, passa a ter
`vendedor` **e** `admin`. Portanto:

- autorização usa **`roles.some(r => r === 'admin')`**, nunca `roles[0]`;
- a ordem de retorno de um `select` sem `order by` não é garantida;
- `useAuth` expõe `roles` (conjunto), `isAdmin`, `isVendedor` e `isInstalador`;
- o campo singular `role` permanece só para exibição, com precedência
  determinística `admin > vendedor > instalador`.

### Guard no cliente e SSR

A sessão do Supabase vive em `localStorage` e o servidor não a enxerga. Rotas
com guard precisam de `ssr: false`, senão o `beforeLoad` roda no servidor, não
encontra sessão e manda até o administrador para `/auth`. O layout
`_authenticated` já faz isso; `/admin/planos` e `/admin/modelos` passaram a
fazer, por estarem fora dele.

### Validação (2026-07-22)

Comportamento verificado em navegador para os três perfis:

| Perfil | Resultado |
|---|---|
| Administrador | Abre as 13 rotas; F5 em `/admin/planos` e `/admin/modelos` mantém o acesso; sem loop |
| Vendedor | Toda URL administrativa redireciona para `/app`, sem exibir conteúdo antes; menu sem itens administrativos |
| Anônimo | Redireciona para `/auth`; nenhuma rota entrega conteúdo administrativo por HTTP |

Detalhes e números em `docs/PENDENCIAS_SUPABASE.md` #P-25.

---

## Gravação de logs (2026-07-22)

Regra de arquitetura para as quatro tabelas de log — `auth_events`, `server_logs`,
`security_events` e `audit_logs`.

**O navegador não grava diretamente nessas tabelas.** Nenhuma delas tem policy de
INSERT para `anon` ou `authenticated`; só `service_role` escreve. A RLS **não foi
enfraquecida** para viabilizar logging — a escrita foi movida para o servidor.

**A identidade vem de token validado.** O cliente envia o access token apenas no
header `Authorization: Bearer`, anexado automaticamente pelo middleware global
`attachSupabaseAuth`. O servidor valida com `supabase.auth.getClaims(token)` e deriva
`user_id` / `actor_id` das claims. `user_id`, `actor_id`, `company_id`, `ip` e
`user_agent` enviados no payload são **ignorados** — seriam triviais de forjar.
Não é possível registrar evento nem auditar em nome de outro usuário.

**A chave privilegiada existe somente no backend.** `SUPABASE_SERVICE_ROLE_KEY` é
lida de `process.env` em `client.server.ts`, usado apenas por
`src/lib/log-ingest.server.ts`, que por sua vez só é carregado via `await import()`
dentro de handlers de `createServerFn`. Varredura do build confirma: o módulo e a
chave não aparecem no bundle público.

**Payloads são sanitizados.** Cada categoria tem schema Zod fechado, o servidor
escolhe a tabela de destino (o cliente não a nomeia) e a metadata passa por remoção
de campos sensíveis por nome, em qualquer profundidade, além de limites de string,
profundidade, número de chaves e tamanho total.

**Falhas de log são tratadas explicitamente.** Os helpers devolvem
`{ success: true }` ou `{ success: false, code, message }` — nunca engolem o erro
como antes. Uma falha de log não derruba a operação principal, e o tratamento de
falha nunca dispara outro log, para não criar laço.

Detalhes, limitações conhecidas e resultados dos testes em
`docs/PENDENCIAS_SUPABASE.md` #P-07.

---

## Onboarding empresarial e empresa ativa (2026-07-23)

### Modelo de empresas

- **`company_profiles`** é o tenant (a empresa). `user_id` é o **criador**.
- **`company_members`** liga `auth.users` ↔ `company_profiles` (N:N). `unique(company_id, user_id)` → um usuário **pode pertencer a várias empresas**. `role` (texto CHECK) é o **papel empresarial**: `owner`, `admin`, `manager`, `operator`, `installer`, `seller`. `status`: `active`, `blocked`, `invited` (convites são modelados por `status='invited'` — não há tabela de convites separada).
- Não há tabela de organização/equipe além dessas.

### Papel de PLATAFORMA ≠ papel de EMPRESA

- **Plataforma** (`user_roles`, enum `app_role`: `admin`/`vendedor`/`instalador`): quem administra o produto. Exposto em `useAuth` (`isAdmin`, `role`, `roles`).
- **Empresa** (`company_members.role`): papel dentro de um tenant. Exposto no novo `CompanyProvider` (`companyRole`).
- **Nunca são misturados.** `useAuth.isAdmin` (plataforma) e `company_members.role` (empresa) são fontes distintas. O onboarding **não concede** papel de plataforma.

### Fluxo do usuário sem empresa (Fluxo A — criar)

1. Usuário autenticado **sem** membership ativa é levado ao **`/app/onboarding`** (gate no `AppShell`; UX — a RLS continua sendo a proteção final).
   - **Regra explícita:** o **admin de plataforma NÃO** é forçado ao onboarding (pode não ter empresa).
2. O onboarding pede apenas o **nome da empresa** (obrigatório) + campos opcionais.
3. A criação ocorre pela **RPC `public.create_company_with_owner`** (migration `20260723020000_company_onboarding.sql`):
   - `SECURITY DEFINER`, identidade **sempre** de `auth.uid()` (sessão) — a função **não aceita** `user_id`/`owner_id`/`company_id` do cliente;
   - cria `company_profiles` + `company_members(role='owner', status='active')` na **mesma transação** (rollback em falha parcial);
   - **idempotente / anti-duplo-clique**: advisory lock por usuário; se já há membership ativa, devolve a empresa existente;
   - **não toca `user_roles`** → o criador vira **owner da empresa**, nunca admin da plataforma.
4. Concluído, redireciona para `/app`.

Convites (Fluxo B, `status='invited'`) são suportados pelo schema mas **não** têm envio/aceite construídos, e membros não-criadores ainda não leem `company_profiles` por RLS — ficam como extensão futura.

### Empresa ativa (`CompanyProvider`)

`src/contexts/company-context.tsx` carrega as memberships **uma vez** para toda a árvore autenticada e expõe: `companies`, `activeCompany`, `companyRole`, `hasCompany`, `loading`, `error`, `setActiveCompanyId`, `refresh`. A empresa ativa é a **preferência do `localStorage` validada contra as memberships**; valor inválido cai para uma membership válida; sem membership, é limpa. `setActiveCompanyId` só aceita um id que pertença ao usuário.

### Isolamento por RLS — testado localmente

Testes contra o banco local (papel `authenticated` + claims por usuário) confirmaram: usuário da empresa A **não** lê clientes da B; usuário **não** se adiciona a outra empresa nem cria empresa em nome de terceiro (`with check user_id = auth.uid()`); owner **não** se auto-promove a admin de plataforma (RLS de `user_roles` só admite admin); `seller` **não** altera papel empresarial; duplo envio não cria duas empresas; multiempresa funciona. A RLS de negócio isola por `is_company_member(company_id)` / `owner_id` (28 policies). Menu oculto nunca é autorização — a RLS é a proteção final.

Detalhes, testes e limitações em `docs/PENDENCIAS_SUPABASE.md` #P-16/#P-23.
