-- =====================================================================
-- SEED — Vidro & Metal Mestre
-- Arquivo: supabase/baseline-draft/seed.sql
-- Status: RASCUNHO — acompanha 20260721000000_baseline.sql
--
-- Executado automaticamente por `supabase db reset` no ambiente LOCAL.
-- Em produção deve ser aplicado de forma explícita e consciente.
--
-- GARANTIAS
--   · Nenhum INSERT/UPDATE/DELETE sobre auth.users
--   · Nenhuma senha, e-mail corporativo, UUID de usuário ou de empresa real
--   · Nenhum dado vinculado a um usuário específico
--   · Todos os blocos são idempotentes (ON CONFLICT)
--
-- ORGANIZAÇÃO (REGRA 17 — catálogo obrigatório ≠ dado demonstrativo)
--   BLOCO A — Catálogos obrigatórios: sem eles a aplicação não funciona.
--   BLOCO B — Dados demonstrativos: opcionais, apenas para avaliação local.
-- =====================================================================


-- #####################################################################
-- BLOCO A — CATÁLOGOS OBRIGATÓRIOS
-- Sem estas linhas, telas de planos, módulos e biblioteca ficam vazias.
-- São dados de configuração do produto, não de nenhum cliente.
-- #####################################################################

-- --- A.1 Planos por segmento (controle de acesso a módulos) -----------
-- Fonte: migrations 20260702083000 / 20260703040050
insert into public.platform_plans (id, nome, segmento, descricao) values
  ('vidracaria',  'Plano Vidraçaria',  'vidracaria',  'Libera vidros, alumínios, ferragens de vidro e projetos de vidraçaria.'),
  ('serralheria', 'Plano Serralheria', 'serralheria', 'Libera aço, metalon, portões, galpões, grades e móveis industriais.'),
  ('marcenaria',  'Plano Marcenaria',  'marcenaria',  'Libera MDF, chapas, ferragens de móveis, plano de corte e projetos de marcenaria.'),
  ('marmoraria',  'Plano Marmoraria',  'marmoraria',  'Libera mármores, granitos, quartzos, porcelanatos, recortes e projetos de marmoraria.'),
  ('completo',    'Plano Completo',    'completo',    'Libera todos os módulos da plataforma.')
on conflict (id) do update
  set nome = excluded.nome,
      segmento = excluded.segmento,
      descricao = excluded.descricao,
      ativo = true;

-- --- A.2 Módulos da plataforma ---------------------------------------
-- Fonte: migrations 20260702083000 / 20260703040050
-- NOTA: a coluna `rota` acopla o banco ao roteamento do frontend.
-- Ver PENDENCIAS.md #P-10.
insert into public.platform_modules (id, nome, segmento, rota, descricao) values
  ('vidros',           'Vidros',                  'vidracaria',  '/app/vidros',    'Catálogo técnico de vidros.'),
  ('aluminios',        'Alumínios',               'vidracaria',  '/app/aluminios', 'Catálogo técnico de alumínios com códigos, medidas, peso e estoque.'),
  ('ferragens_vidro',  'Ferragens para vidro',    'vidracaria',  '/app/ferragens', 'Ferragens e acessórios para vidro.'),
  ('serralheria',      'Projetos de serralheria', 'serralheria', '/app/projetos',  'Portões, grades, galpões e estruturas.'),
  ('aco_metalon',      'Aço e Metalon',           'serralheria', '/app/estoque',   'Tubos, chapas, barras e perfis de aço.'),
  ('mdf',              'MDF e chapas',            'marcenaria',  '/app/projetos',  'Chapas, MDF, fitas e plano de corte.'),
  ('ferragens_moveis', 'Ferragens para móveis',   'marcenaria',  '/app/ferragens', 'Dobradiças, corrediças, puxadores e acessórios.'),
  ('marmores',         'Mármores e granitos',     'marmoraria',  '/app/projetos',  'Pedras naturais, bancadas, soleiras, cubas e recortes.'),
  ('quartzos',         'Quartzos',                'marmoraria',  '/app/projetos',  'Superfícies de quartzo e bancadas.'),
  ('porcelanatos',     'Porcelanatos',            'marmoraria',  '/app/projetos',  'Porcelanatos para bancada, cuba esculpida e revestimentos.')
on conflict (id) do update
  set nome = excluded.nome,
      segmento = excluded.segmento,
      rota = excluded.rota,
      descricao = excluded.descricao,
      ativo = true;

-- --- A.3 Quais módulos cada plano libera ------------------------------
insert into public.plan_module_access (plan_id, module_id, enabled)
select 'vidracaria', id, true from public.platform_modules
 where id in ('vidros', 'aluminios', 'ferragens_vidro')
on conflict (plan_id, module_id) do update set enabled = excluded.enabled;

insert into public.plan_module_access (plan_id, module_id, enabled)
select 'serralheria', id, true from public.platform_modules
 where id in ('serralheria', 'aco_metalon')
on conflict (plan_id, module_id) do update set enabled = excluded.enabled;

insert into public.plan_module_access (plan_id, module_id, enabled)
select 'marcenaria', id, true from public.platform_modules
 where id in ('mdf', 'ferragens_moveis')
on conflict (plan_id, module_id) do update set enabled = excluded.enabled;

insert into public.plan_module_access (plan_id, module_id, enabled)
select 'marmoraria', id, true from public.platform_modules
 where id in ('marmores', 'quartzos', 'porcelanatos')
on conflict (plan_id, module_id) do update set enabled = excluded.enabled;

insert into public.plan_module_access (plan_id, module_id, enabled)
select 'completo', id, true from public.platform_modules
on conflict (plan_id, module_id) do update set enabled = excluded.enabled;

-- --- A.4 Categorias da biblioteca de projetos -------------------------
-- Fonte: migrations 20260703030000 / 20260703040050
insert into public.project_categories (name, slug, active) values
  ('Portões',                 'portoes',                 true),
  ('Telhados',                'telhados',                true),
  ('Pergolados',              'pergolados',              true),
  ('Coberturas',              'coberturas',              true),
  ('Portas metálicas',        'portas-metalicas',        true),
  ('Escadas',                 'escadas',                 true),
  ('Mezaninos',               'mezaninos',               true),
  ('Galpões',                 'galpoes',                 true),
  ('Energia solar',           'energia-solar',           true),
  ('Estruturas industriais',  'estruturas-industriais',  true)
on conflict (slug) do update
  set name = excluded.name,
      active = true;


-- #####################################################################
-- BLOCO A' — CATÁLOGO COMERCIAL (preço — revisar antes de produção)
-- Separado do A porque são valores de negócio, não estrutura.
-- Alterar preço NÃO deve exigir migration; por isso vive no seed.
-- CONFIRMAR os valores com a área comercial antes de aplicar em produção.
-- #####################################################################

-- --- A'.1 Planos de assinatura da biblioteca --------------------------
-- Fonte: migrations 20260703030000 / 20260703040050
insert into public.plans (name, slug, price, billing_cycle, active) values
  ('Plano PRO',     'pro',     149.90, 'monthly', true),
  ('Plano PREMIUM', 'premium', 299.90, 'monthly', true)
on conflict (slug) do update
  set name = excluded.name,
      price = excluded.price,
      billing_cycle = excluded.billing_cycle,
      active = true;

-- --- A'.2 Limites de modelos por plano e categoria --------------------
insert into public.plan_model_limits (plan_slug, category_slug, model_limit, allow_all) values
  ('pro',     'portoes',                5,    false),
  ('pro',     'telhados',               10,   false),
  ('pro',     'pergolados',             5,    false),
  ('pro',     'coberturas',             5,    false),
  ('pro',     'portas-metalicas',       5,    false),
  ('pro',     'escadas',                3,    false),
  ('pro',     'mezaninos',              2,    false),
  ('premium', 'portoes',                null, true),
  ('premium', 'telhados',               null, true),
  ('premium', 'pergolados',             null, true),
  ('premium', 'coberturas',             null, true),
  ('premium', 'portas-metalicas',       null, true),
  ('premium', 'escadas',                null, true),
  ('premium', 'mezaninos',              null, true),
  ('premium', 'galpoes',                null, true),
  ('premium', 'energia-solar',          null, true),
  ('premium', 'estruturas-industriais', null, true)
on conflict (plan_slug, category_slug) do update
  set model_limit = excluded.model_limit,
      allow_all = excluded.allow_all;


-- #####################################################################
-- BLOCO B — DADOS DEMONSTRATIVOS
-- #####################################################################
--
-- INTENCIONALMENTE VAZIO — agora com confirmação do dump.
--
-- CONFIRMAÇÃO (revisão 2): o dump `tmp/supabase-antigo/public-schema.sql` não contém
-- nenhuma tabela e, portanto, nenhum dado (0 `INSERT`, 0 `COPY`). Não existe dado de
-- produção a preservar ou reproduzir aqui. Ver PENDENCIAS.md #P-00.
--
-- Motivos:
--   1. As 49 migrations antigas NÃO continham clientes, orçamentos, produtos
--      ou projetos de exemplo. Não há dado demonstrativo a recuperar.
--   2. Todo dado operacional (customers, quotes, inventory_items,
--      project_templates, company_profiles) pertence a um `owner_id` /
--      `company_id`. Semear qualquer linha exigiria inventar um UUID de usuário
--      — proibido pelas regras 1, 2 e 20 desta fase.
--   3. `project_models` (a biblioteca de modelos) também está vazia: as
--      migrations criaram a tabela e as categorias, mas nunca inseriram modelos.
--      O catálogo visível hoje no app vem de src/data/projectLibrary.ts, não do
--      banco. Ver PENDENCIAS.md #P-11.
--
-- Se você quiser dados de avaliação local, o caminho seguro é:
--   1. criar um usuário de teste pelo Dashboard local (supabase start);
--   2. copiar o UUID gerado;
--   3. rodar um script fora do controle de versão, ou usar a própria UI.
--
-- Não adicione UUIDs fixos aqui: eles não existirão em auth.users de outro
-- ambiente e as FKs vão falhar.
--
-- ===================== FIM DO SEED =====================
