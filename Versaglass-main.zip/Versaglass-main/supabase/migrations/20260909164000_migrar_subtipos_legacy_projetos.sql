-- =====================================================================
-- 20260909164000_migrar_subtipos_legacy_projetos.sql
--
-- Reclassifica os 7 project_templates com subtipos legacy da taxonomia
-- pré-comercial de Vidraçaria para os 13 tipos comerciais atuais, e em
-- seguida remove a aceitação desses aliases (e dos legado de Esquadrias)
-- dos CHECK constraints project_templates_area_subtipo e
-- platform_project_catalog_area_subtipo.
--
-- NÃO altera:
--   · quote_items (tipo_projeto, project_data, snapshots históricos)
--   · nome, descrição, tipo, categoria, imagens, ativo, company_id
--   · platform_project_catalog (0 linhas legacy; só o CHECK)
--   · enum project_area / quote_item_tipo_projeto
--   · taxonomia de Serralheria / Marcenaria / Marmoraria
--
-- UPDATEs por ID + área + subtipo anterior (não há WHERE global só pelo
-- subtipo). Se restar qualquer valor fora da taxonomia atual após os
-- UPDATEs, RAISE EXCEPTION aborta antes de restringir os CHECKs.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. UPDATEs determinísticos (7 IDs auditados)
-- ---------------------------------------------------------------------

-- 1.1 Janela 3 folhas → janela (3)
UPDATE public.project_templates
   SET subtipo = 'janela'
 WHERE id IN (
         '00138f5c-e83f-448e-b01a-2772836aaaf7'::uuid,
         '7f3d8deb-ae89-4101-8bad-07fe82bda73e'::uuid,
         'c8519b7f-2c26-44e7-937a-a2e8b4454d1b'::uuid
       )
   AND area = 'vidracaria'::public.project_area
   AND subtipo = 'janela_vidro';

-- 1.2 Porta / Porta de vidro → porta (2)
UPDATE public.project_templates
   SET subtipo = 'porta'
 WHERE id IN (
         'f07150da-34b2-4edd-9312-161c5c4a1827'::uuid,
         '703d11f7-a8ab-4c74-b848-727e70f36ed9'::uuid
       )
   AND area = 'vidracaria'::public.project_area
   AND subtipo = 'porta_vidro';

-- 1.3 Parede de Vidro → fixo (decisão humana)
UPDATE public.project_templates
   SET subtipo = 'fixo'
 WHERE id = '6fd73d98-b1d1-452e-a6b4-f5c2863035da'::uuid
   AND area = 'vidracaria'::public.project_area
   AND subtipo = 'janela_vidro';

-- 1.4 Substituição de aluminios… → reposicao (decisão humana)
UPDATE public.project_templates
   SET subtipo = 'reposicao'
 WHERE id = '3a2801be-9e6c-4225-88ab-d45369c38762'::uuid
   AND area = 'vidracaria'::public.project_area
   AND subtipo = 'outro_vidracaria';

-- ---------------------------------------------------------------------
-- 2. Assert: zero subtipos fora da taxonomia atual (ambas as tabelas)
-- ---------------------------------------------------------------------
DO $$
DECLARE
  v_restantes integer;
  v_amostra   text;
BEGIN
  SELECT COUNT(*)::integer,
         string_agg(origem || ':' || id::text || '/' || area::text || '/' || subtipo, ', ' ORDER BY origem, subtipo)
    INTO v_restantes, v_amostra
    FROM (
      SELECT 'project_templates'::text AS origem, id, area, subtipo
        FROM public.project_templates
       WHERE NOT (
         (area = 'vidracaria'::public.project_area AND subtipo IN (
           'janela','porta','fixo','box','fechamento_pia','espelho',
           'bascula_maxiar_pivotante','guarda_corpo','reposicao','sacadas',
           'articulados','muro','vitrine'
         ))
         OR (area = 'esquadrias'::public.project_area AND subtipo IN (
           'janela_esquadrias','porta_esquadrias','maxim_ar_esquadrias',
           'fixos_esquadrias','portao_esquadrias','fachada_esquadrias',
           'porta_pivotante_esquadrias','diversos_esquadrias',
           'basculantes_esquadrias','janela_pivotante_esquadrias',
           'camarao_esquadrias','janela_abrir_esquadrias','gradil_esquadrias'
         ))
         OR (area = 'serralheria'::public.project_area AND subtipo IN (
           'portao','grade','corrimao','estrutura_metalica','cobertura',
           'esquadria_metalica','outro_serralheria'
         ))
         OR (area = 'marcenaria'::public.project_area AND subtipo IN (
           'armario','porta_madeira','painel','bancada_madeira',
           'movel_planejado','prateleira','outro_marcenaria'
         ))
         OR (area = 'marmoraria'::public.project_area AND subtipo IN (
           'bancada_pedra','pia','soleira','revestimento','escada',
           'peitoril','outro_marmoraria'
         ))
       )
      UNION ALL
      SELECT 'platform_project_catalog', id, area, subtipo
        FROM public.platform_project_catalog
       WHERE NOT (
         (area = 'vidracaria'::public.project_area AND subtipo IN (
           'janela','porta','fixo','box','fechamento_pia','espelho',
           'bascula_maxiar_pivotante','guarda_corpo','reposicao','sacadas',
           'articulados','muro','vitrine'
         ))
         OR (area = 'esquadrias'::public.project_area AND subtipo IN (
           'janela_esquadrias','porta_esquadrias','maxim_ar_esquadrias',
           'fixos_esquadrias','portao_esquadrias','fachada_esquadrias',
           'porta_pivotante_esquadrias','diversos_esquadrias',
           'basculantes_esquadrias','janela_pivotante_esquadrias',
           'camarao_esquadrias','janela_abrir_esquadrias','gradil_esquadrias'
         ))
         OR (area = 'serralheria'::public.project_area AND subtipo IN (
           'portao','grade','corrimao','estrutura_metalica','cobertura',
           'esquadria_metalica','outro_serralheria'
         ))
         OR (area = 'marcenaria'::public.project_area AND subtipo IN (
           'armario','porta_madeira','painel','bancada_madeira',
           'movel_planejado','prateleira','outro_marcenaria'
         ))
         OR (area = 'marmoraria'::public.project_area AND subtipo IN (
           'bancada_pedra','pia','soleira','revestimento','escada',
           'peitoril','outro_marmoraria'
         ))
       )
    ) ilegais;

  IF v_restantes > 0 THEN
    RAISE EXCEPTION
      'migrar_subtipos_legacy_projetos: ainda há % subtipo(s) fora da taxonomia atual antes de restringir CHECKs: %',
      v_restantes, COALESCE(v_amostra, '(sem amostra)');
  END IF;
END $$;

-- ---------------------------------------------------------------------
-- 3. CHECK constraints — taxonomia atual apenas (sem aliases legacy)
--
-- Base: expressão de 20260904130000_esquadrias_subtipos_comerciais.sql /
-- definição remota atual, removendo somente:
--   Vidraçaria: porta_vidro, janela_vidro, fechamento_vidro, outro_vidracaria
--   Esquadrias alumínio: janela_aluminio_esquadrias, porta_aluminio_esquadrias,
--     porta_correr_esquadrias, veneziana_esquadrias, guarda_corpo_esquadrias,
--     outro_esquadrias
--   Esquadrias espelho visual: box_esquadrias, porta_vidro_esquadrias,
--     janela_vidro_esquadrias, espelho_esquadrias, fechamento_vidro_esquadrias
-- Serralheria / Marcenaria / Marmoraria permanecem intactas.
-- ---------------------------------------------------------------------

ALTER TABLE public.project_templates
  DROP CONSTRAINT IF EXISTS project_templates_area_subtipo;

ALTER TABLE public.project_templates
  ADD CONSTRAINT project_templates_area_subtipo CHECK (
    CASE area
      WHEN 'vidracaria'::public.project_area THEN (subtipo = ANY (ARRAY[
        'janela'::text,
        'porta'::text,
        'fixo'::text,
        'box'::text,
        'fechamento_pia'::text,
        'espelho'::text,
        'bascula_maxiar_pivotante'::text,
        'guarda_corpo'::text,
        'reposicao'::text,
        'sacadas'::text,
        'articulados'::text,
        'muro'::text,
        'vitrine'::text
      ]))
      WHEN 'esquadrias'::public.project_area THEN (subtipo = ANY (ARRAY[
        'janela_esquadrias'::text,
        'porta_esquadrias'::text,
        'maxim_ar_esquadrias'::text,
        'fixos_esquadrias'::text,
        'portao_esquadrias'::text,
        'fachada_esquadrias'::text,
        'porta_pivotante_esquadrias'::text,
        'diversos_esquadrias'::text,
        'basculantes_esquadrias'::text,
        'janela_pivotante_esquadrias'::text,
        'camarao_esquadrias'::text,
        'janela_abrir_esquadrias'::text,
        'gradil_esquadrias'::text
      ]))
      WHEN 'serralheria'::public.project_area THEN (subtipo = ANY (ARRAY[
        'portao'::text,
        'grade'::text,
        'corrimao'::text,
        'estrutura_metalica'::text,
        'cobertura'::text,
        'esquadria_metalica'::text,
        'outro_serralheria'::text
      ]))
      WHEN 'marcenaria'::public.project_area THEN (subtipo = ANY (ARRAY[
        'armario'::text,
        'porta_madeira'::text,
        'painel'::text,
        'bancada_madeira'::text,
        'movel_planejado'::text,
        'prateleira'::text,
        'outro_marcenaria'::text
      ]))
      WHEN 'marmoraria'::public.project_area THEN (subtipo = ANY (ARRAY[
        'bancada_pedra'::text,
        'pia'::text,
        'soleira'::text,
        'revestimento'::text,
        'escada'::text,
        'peitoril'::text,
        'outro_marmoraria'::text
      ]))
      ELSE NULL::boolean
    END
  );

COMMENT ON COLUMN public.project_templates.subtipo IS
  'Tipo de projeto DENTRO da area. Vidracaria e Esquadrias: 13 tipos comerciais (sem aliases legacy). Demais areas: 7 opcoes. Par (area, subtipo) validado por project_templates_area_subtipo.';

ALTER TABLE public.platform_project_catalog
  DROP CONSTRAINT IF EXISTS platform_project_catalog_area_subtipo;

ALTER TABLE public.platform_project_catalog
  ADD CONSTRAINT platform_project_catalog_area_subtipo CHECK (
    CASE area
      WHEN 'vidracaria'::public.project_area THEN (subtipo = ANY (ARRAY[
        'janela'::text,
        'porta'::text,
        'fixo'::text,
        'box'::text,
        'fechamento_pia'::text,
        'espelho'::text,
        'bascula_maxiar_pivotante'::text,
        'guarda_corpo'::text,
        'reposicao'::text,
        'sacadas'::text,
        'articulados'::text,
        'muro'::text,
        'vitrine'::text
      ]))
      WHEN 'esquadrias'::public.project_area THEN (subtipo = ANY (ARRAY[
        'janela_esquadrias'::text,
        'porta_esquadrias'::text,
        'maxim_ar_esquadrias'::text,
        'fixos_esquadrias'::text,
        'portao_esquadrias'::text,
        'fachada_esquadrias'::text,
        'porta_pivotante_esquadrias'::text,
        'diversos_esquadrias'::text,
        'basculantes_esquadrias'::text,
        'janela_pivotante_esquadrias'::text,
        'camarao_esquadrias'::text,
        'janela_abrir_esquadrias'::text,
        'gradil_esquadrias'::text
      ]))
      WHEN 'serralheria'::public.project_area THEN (subtipo = ANY (ARRAY[
        'portao'::text,
        'grade'::text,
        'corrimao'::text,
        'estrutura_metalica'::text,
        'cobertura'::text,
        'esquadria_metalica'::text,
        'outro_serralheria'::text
      ]))
      WHEN 'marcenaria'::public.project_area THEN (subtipo = ANY (ARRAY[
        'armario'::text,
        'porta_madeira'::text,
        'painel'::text,
        'bancada_madeira'::text,
        'movel_planejado'::text,
        'prateleira'::text,
        'outro_marcenaria'::text
      ]))
      WHEN 'marmoraria'::public.project_area THEN (subtipo = ANY (ARRAY[
        'bancada_pedra'::text,
        'pia'::text,
        'soleira'::text,
        'revestimento'::text,
        'escada'::text,
        'peitoril'::text,
        'outro_marmoraria'::text
      ]))
      ELSE NULL::boolean
    END
  );

COMMENT ON COLUMN public.platform_project_catalog.subtipo IS
  'Tipo de projeto DENTRO da area (catálogo global). Vidracaria e Esquadrias: 13 tipos comerciais (sem aliases legacy). Demais areas: 7 opcoes. Par (area, subtipo) validado por platform_project_catalog_area_subtipo.';
