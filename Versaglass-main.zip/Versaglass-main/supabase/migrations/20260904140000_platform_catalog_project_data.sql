-- 20260904140000_platform_catalog_project_data.sql
--
-- Aditivo: `platform_project_catalog` passa a aceitar o mesmo envelope
-- `project_data` (jsonb) já usado em `project_templates` / `quote_items`.
--
-- Motivo: o catálogo global é a fonte única de Projetos; aplicar no orçamento
-- precisa poder copiar o desenho paramétrico como snapshot independente.
--
-- NÃO destrutivo:
--   · sem DROP de project_templates
--   · sem apagar dados
--   · sem converter registros privados automaticamente
--   · coluna nova nullable (itens existentes ficam sem desenho)

alter table public.platform_project_catalog
  add column if not exists project_data jsonb;

comment on column public.platform_project_catalog.project_data is
  'Desenho parametrico (mesmo formato de project_templates.project_data / ProjectDataV1). NULL = sem desenho. Snapshot ao aplicar no orcamento.';

-- Envelope: objeto JSON, versao de formato = 1, tamanho <= 256 KB
-- (espelha project_templates_project_data_* de 20260727070000).
alter table public.platform_project_catalog
  drop constraint if exists platform_project_catalog_project_data_object;
alter table public.platform_project_catalog
  add constraint platform_project_catalog_project_data_object
    check (project_data is null or jsonb_typeof(project_data) = 'object');

alter table public.platform_project_catalog
  drop constraint if exists platform_project_catalog_project_data_size;
alter table public.platform_project_catalog
  add constraint platform_project_catalog_project_data_size
    check (project_data is null or octet_length(project_data::text) <= 262144);

alter table public.platform_project_catalog
  drop constraint if exists platform_project_catalog_project_data_version;
alter table public.platform_project_catalog
  add constraint platform_project_catalog_project_data_version
    check (
      project_data is null
      or (
        coalesce(jsonb_typeof(project_data -> 'versao'), 'ausente') = 'number'
        and (project_data -> 'versao') = to_jsonb(1)
      )
    );

-- area interno do JSON deve coincidir com a coluna area
-- (espelha project_templates_project_data_area de 20260727090000).
alter table public.platform_project_catalog
  drop constraint if exists platform_project_catalog_project_data_area;
alter table public.platform_project_catalog
  add constraint platform_project_catalog_project_data_area
    check (project_data is null or coalesce(project_data ->> 'area', '') = area::text);
