-- =====================================================================
-- 20260904120000_vidracaria_subtipos_comerciais.sql
--
-- Substitui os 7 subtipos antigos de Vidraçaria pelos 13 tipos comerciais
-- alinhados a `public.quote_item_tipo_projeto` / UI do orçamento:
--
--   janela, porta, fixo, box, fechamento_pia, espelho,
--   bascula_maxiar_pivotante, guarda_corpo, reposicao, sacadas,
--   articulados, muro, vitrine
--
-- NÃO altera:
--   · enum project_area
--   · enum quote_item_tipo_projeto
--   · taxonomia de Esquadrias / Serralheria / Marcenaria / Marmoraria
--   · dados existentes (sem UPDATE/DELETE de subtipo)
--
-- Legado: IDs antigos de Vidraçaria (porta_vidro, janela_vidro,
-- fechamento_vidro, outro_vidracaria) CONTINUAM aceitos no CHECK para que
-- linhas existentes não quebrem ao aplicar a migration. A UI deixa de
-- oferecê-los em novos cadastros; reclassificação manual fica para rodada
-- futura (aprovada).
--
-- NÃO aplicar no remoto nesta rodada — só preparar o arquivo.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. CHECK project_templates_area_subtipo
-- ---------------------------------------------------------------------
alter table public.project_templates
  drop constraint if exists project_templates_area_subtipo;

alter table public.project_templates
  add constraint project_templates_area_subtipo check (
    case area
      when 'vidracaria'  then subtipo in (
        -- atuais (13 comerciais)
        'janela',
        'porta',
        'fixo',
        'box',
        'fechamento_pia',
        'espelho',
        'bascula_maxiar_pivotante',
        'guarda_corpo',
        'reposicao',
        'sacadas',
        'articulados',
        'muro',
        'vitrine',
        -- legado (somente leitura / edição sem forçar conversão)
        'porta_vidro',
        'janela_vidro',
        'fechamento_vidro',
        'outro_vidracaria'
      )
      when 'esquadrias'  then subtipo in (
        'janela_aluminio_esquadrias',
        'porta_aluminio_esquadrias',
        'porta_correr_esquadrias',
        'fachada_esquadrias',
        'veneziana_esquadrias',
        'guarda_corpo_esquadrias',
        'outro_esquadrias'
      )
      when 'serralheria' then subtipo in ('portao','grade','corrimao','estrutura_metalica','cobertura','esquadria_metalica','outro_serralheria')
      when 'marcenaria'  then subtipo in ('armario','porta_madeira','painel','bancada_madeira','movel_planejado','prateleira','outro_marcenaria')
      when 'marmoraria'  then subtipo in ('bancada_pedra','pia','soleira','revestimento','escada','peitoril','outro_marmoraria')
    end
  );

comment on column public.project_templates.subtipo is
  'Tipo de projeto DENTRO da area. Vidracaria: 13 tipos comerciais (+ legado aceito no CHECK). Demais areas: 7 opcoes. Par (area, subtipo) validado por project_templates_area_subtipo.';

-- ---------------------------------------------------------------------
-- 2. CHECK platform_project_catalog_area_subtipo
-- ---------------------------------------------------------------------
alter table public.platform_project_catalog
  drop constraint if exists platform_project_catalog_area_subtipo;

alter table public.platform_project_catalog
  add constraint platform_project_catalog_area_subtipo check (
    case area
      when 'vidracaria'  then subtipo in (
        'janela',
        'porta',
        'fixo',
        'box',
        'fechamento_pia',
        'espelho',
        'bascula_maxiar_pivotante',
        'guarda_corpo',
        'reposicao',
        'sacadas',
        'articulados',
        'muro',
        'vitrine',
        'porta_vidro',
        'janela_vidro',
        'fechamento_vidro',
        'outro_vidracaria'
      )
      when 'esquadrias'  then subtipo in (
        'janela_aluminio_esquadrias',
        'porta_aluminio_esquadrias',
        'porta_correr_esquadrias',
        'fachada_esquadrias',
        'veneziana_esquadrias',
        'guarda_corpo_esquadrias',
        'outro_esquadrias'
      )
      when 'serralheria' then subtipo in ('portao','grade','corrimao','estrutura_metalica','cobertura','esquadria_metalica','outro_serralheria')
      when 'marcenaria'  then subtipo in ('armario','porta_madeira','painel','bancada_madeira','movel_planejado','prateleira','outro_marcenaria')
      when 'marmoraria'  then subtipo in ('bancada_pedra','pia','soleira','revestimento','escada','peitoril','outro_marmoraria')
    end
  );
