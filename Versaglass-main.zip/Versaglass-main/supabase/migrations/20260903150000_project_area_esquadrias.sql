-- =====================================================================
-- 20260903150000_project_area_esquadrias.sql
--
-- Adiciona `esquadrias` ao enum `public.project_area`.
-- Constraints que usam o novo valor ficam na migration seguinte
-- (ADD VALUE e uso no mesmo transaction podem falhar em alguns setups).
-- =====================================================================

alter type public.project_area add value if not exists 'esquadrias';

comment on type public.project_area is
  'Area do modelo tecnico: vidracaria | esquadrias | serralheria | marcenaria | marmoraria.';
