-- =====================================================================
-- 20260727090000_project_templates_area.sql
--
-- ÁREA do modelo técnico — a classificação principal da Biblioteca.
--
-- PROBLEMA QUE ORIGINA ESTA MIGRATION
--   A interface separa o negócio em quatro ÁREAS (vidraçaria, serralheria de
--   aço, marcenaria, marmoraria), mas `public.project_templates` não tinha
--   nenhuma coluna para isso. O que existia era `categoria`
--   (`public.project_category`: vidro_comum, temperado, espelho, esquadria),
--   que descreve o MATERIAL/produto de vidraçaria — não a área. Usar `categoria`
--   como área obriga a adivinhar: `esquadria` é a única saída para serralheria,
--   marcenaria e marmoraria ao mesmo tempo, e o editor acabava perguntando ao
--   usuário qual paleta abrir, ou pior, abria a de vidraçaria em um armário.
--
-- O QUE ESTA MIGRATION FAZ
--   1. cria o enum `public.project_area` (quatro valores, sem texto livre);
--   2. adiciona `project_templates.area` (NULL só durante o backfill);
--   3. classifica automaticamente o que é determinístico;
--   4. INTERROMPE se sobrar qualquer linha ambígua — sem escolher em silêncio;
--   5. torna `area` NOT NULL;
--   6. cria o índice de listagem (company_id, area, ativo);
--   7. amarra `project_data->>'area'` à coluna `area`, para o desenho não
--      divergir da classificação comercial.
--
-- O QUE ESTA MIGRATION NÃO FAZ
--   · não altera `categoria` nem o enum `public.project_category`;
--   · não apaga nem reescreve `project_data` (a chave `area` continua lá);
--   · não mexe em RLS, policies, triggers de tenant ou em `quote_items`.
--
-- AUDITORIA DE DADOS (service_role, somente contagens, 2026-07-28)
--   remoto: 2 project_templates · categoria temperado 2 · esquadria 0 ·
--           com project_data 0 · com project_data.area 0 ·
--           classificáveis automaticamente 2 · AMBÍGUOS 0
--   quote_items: 9 itens · com project_data 0
--   Ou seja: o backfill classifica 100% do acervo pela regra determinística e
--   o guarda do passo 4 não deve disparar. Ele existe para a próxima base —
--   um dump de produção com `esquadria` real — e não como formalidade.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 1. ENUM
--
-- Enum, não `text` com CHECK: o valor inválido é recusado pelo TIPO, em
-- qualquer caminho de escrita (aplicação, SQL manual, importação), e o
-- gerador de tipos do Supabase transforma isso em uma união TypeScript —
-- o front-end passa a errar em tempo de compilação, não em produção.
--
-- `serralheria` (e não `serralheria_aco`): o rótulo da interface é
-- "Serralheria de aço", mas o identificador acompanha o resto do sistema, que
-- já usa `serralheria` em `src/lib/especialidade.ts`, `src/lib/module-access.ts`
-- e nas áreas do estoque. Rótulo é da tela; identificador é do banco.
-- ---------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from pg_type where typname = 'project_area' and typnamespace = 'public'::regnamespace) then
    create type public.project_area as enum ('vidracaria', 'serralheria', 'marcenaria', 'marmoraria');
  end if;
end $$;

comment on type public.project_area is
  'Area principal do modelo tecnico. NAO confundir com public.project_category (vidro_comum/temperado/espelho/esquadria), que descreve o material do produto de vidracaria.';


-- ---------------------------------------------------------------------
-- 2. COLUNA (nascendo anulável — vira NOT NULL no passo 5)
-- ---------------------------------------------------------------------
alter table public.project_templates
  add column if not exists area public.project_area;

comment on column public.project_templates.area is
  'Area principal do modelo (vidracaria/serralheria/marcenaria/marmoraria). Controla agrupamento, filtros da biblioteca e a paleta do editor parametrico. Obrigatoria. Independente de categoria.';


-- ---------------------------------------------------------------------
-- 3. BACKFILL
--
-- Ordem deliberada: primeiro o desenho, depois a categoria.
--
-- 3.1 `project_data->>'area'` é ESCOLHA EXPLÍCITA de um usuário — foi ele quem
--     respondeu "qual é a área deste modelo?" no editor antigo. Vale mais que
--     qualquer dedução a partir da categoria, inclusive quando as duas
--     discordam (um modelo de categoria `temperado` cujo desenho é de
--     marcenaria existe, e o desenho é que diz a verdade sobre a paleta).
--     `serralheria_aco` é o identificador ANTIGO da mesma área no front-end e
--     é traduzido aqui; sem essa linha o modelo cairia como não classificado.
--
-- 3.2 Categoria → área apenas onde é determinístico: as três categorias de
--     vidro só existem em vidraçaria. `esquadria` fica DE FORA de propósito
--     (ver passo 4).
-- ---------------------------------------------------------------------
update public.project_templates
   set area = case project_data ->> 'area'
                when 'vidracaria'      then 'vidracaria'::public.project_area
                when 'serralheria'     then 'serralheria'::public.project_area
                when 'serralheria_aco' then 'serralheria'::public.project_area
                when 'marcenaria'      then 'marcenaria'::public.project_area
                when 'marmoraria'      then 'marmoraria'::public.project_area
              end
 where area is null
   and jsonb_typeof(project_data) = 'object'
   and project_data ->> 'area' in ('vidracaria', 'serralheria', 'serralheria_aco', 'marcenaria', 'marmoraria');

update public.project_templates
   set area = 'vidracaria'::public.project_area
 where area is null
   and categoria in ('vidro_comum', 'temperado', 'espelho');

-- 3.3 Identificador antigo dentro do desenho → identificador canônico.
--
--     `serralheria_aco` e `serralheria` são A MESMA área com dois nomes: o
--     primeiro é o identificador que o editor usava antes deste enum existir.
--     A chave `area` do desenho NÃO é apagada — só passa a escrever o mesmo
--     valor que a coluna, que é o que o passo 7 exige e o que o front-end
--     grava daqui em diante. Sem isto, um desenho legado deixaria a linha
--     permanentemente em desacordo com a própria classificação.
--
--     (Contagem auditada no remoto: 0 linhas. A instrução existe para bases
--     que tenham desenho legado, não para a de hoje.)
update public.project_templates
   set project_data = jsonb_set(project_data, '{area}', '"serralheria"'::jsonb, false)
 where jsonb_typeof(project_data) = 'object'
   and project_data ->> 'area' = 'serralheria_aco';


-- ---------------------------------------------------------------------
-- 4. GUARDA DO AMBÍGUO — a migration PARA em vez de escolher
--
-- `esquadria` é rotulada "Esquadria / outros" na interface e é a única saída
-- do enum de categoria para serralheria, marcenaria e marmoraria — e para
-- esquadria de alumínio, que é vidraçaria. Não há regra que separe as quatro
-- possibilidades a partir do que está gravado: `tipo`, `nome` e `descricao`
-- são texto livre digitado por gente ("Portão", "Janela", "Box"), e casar
-- substring neles acertaria por acaso e erraria em silêncio — que é
-- exatamente o defeito que esta migration existe para eliminar.
--
-- Chutar aqui é pior do que falhar: o modelo entraria na área errada, seria
-- filtrado no card errado e o editor abriria a paleta errada, tudo sem aviso.
-- Então a migration aborta, informa QUANTOS registros faltam (nunca nome, id
-- ou empresa) e devolve o trabalho a quem sabe a resposta.
--
-- Como resolver, uma vez, antes de reaplicar:
--     update public.project_templates
--        set area = 'serralheria'   -- ou marcenaria / marmoraria / vidracaria
--      where id = '<uuid>';
-- ---------------------------------------------------------------------
do $$
declare v_sem_area integer;
begin
  select count(*) into v_sem_area from public.project_templates where area is null;
  if v_sem_area > 0 then
    raise exception
      'Backfill incompleto: % project_templates sem area (categoria "esquadria" e sem project_data.area). A categoria esquadria e ambigua — pode ser serralheria, marcenaria, marmoraria ou vidracaria — e esta migration NAO escolhe por voce. Defina a area manualmente e reaplique.',
      v_sem_area using errcode = '23502';
  end if;
end $$;


-- ---------------------------------------------------------------------
-- 5. OBRIGATÓRIA
-- ---------------------------------------------------------------------
alter table public.project_templates
  alter column area set not null;


-- ---------------------------------------------------------------------
-- 6. ÍNDICE DA LISTAGEM
--
-- Espelha exatamente a consulta da biblioteca (`useProjectTemplates`):
-- `where company_id = ? [and area = ?] [and ativo = true] order by area, nome`.
-- `company_id` lidera porque é o filtro presente em 100% das consultas e o que
-- mais corta linhas; `area` é o filtro dos quatro cards; `ativo` fecha o
-- recorte de quem só consulta a biblioteca. Com `area` na segunda posição, o
-- índice serve tanto o filtro "Todos" (só company_id) quanto os quatro cards.
-- ---------------------------------------------------------------------
create index if not exists idx_project_templates_company_area_ativo
  on public.project_templates (company_id, area, ativo);


-- ---------------------------------------------------------------------
-- 7. DESENHO E CLASSIFICAÇÃO NÃO PODEM DIVERGIR
--
-- `project_data.area` decide a paleta que o editor abre; `area` decide o card,
-- o filtro e o badge. Se os dois discordarem, o modelo aparece como marcenaria
-- na biblioteca e abre com ferramentas de vidraçaria — e nada no sistema
-- avisa. A constraint torna esse estado inalcançável, inclusive para quem
-- chamar a API direto: o navegador não consegue mais "informar" uma área
-- diferente da do modelo, porque o banco compara as duas na mesma linha.
--
-- Efeito colateral DESEJADO: trocar a área de um modelo que já tem desenho
-- passa a falhar no banco. É a mesma regra que a interface aplica antes
-- ("Remova ou recrie o desenho antes de alterar a área") — aqui ela deixa de
-- depender da interface. Modelo sem desenho (project_data NULL) troca de área
-- livremente.
--
-- `is null or` cobre o modelo sem desenho; `->>` devolve NULL para chave
-- ausente, e a comparação com NULL daria um CHECK "satisfeito" — por isso o
-- `coalesce`, que transforma a ausência em divergência explícita.
-- ---------------------------------------------------------------------
do $$
declare v_divergentes integer;
begin
  select count(*) into v_divergentes
    from public.project_templates
   where project_data is not null
     and coalesce(project_data ->> 'area', '') <> area::text;
  if v_divergentes > 0 then
    raise exception
      'Existem % project_templates cujo project_data.area diverge da coluna area. Alinhe os dois antes de aplicar esta migration.',
      v_divergentes using errcode = '23514';
  end if;
end $$;

alter table public.project_templates
  drop constraint if exists project_templates_project_data_area;
alter table public.project_templates
  add constraint project_templates_project_data_area
    check (project_data is null or coalesce(project_data ->> 'area', '') = area::text);
