-- =====================================================================
-- P-12 · Integridade referencial — foreign keys para auth.users
--
-- Adiciona as 4 FKs que a baseline preservou SEM FK "por fidelidade" às
-- migrations antigas (ver docs/PENDENCIAS_SUPABASE.md -> P-12). As 4 colunas
-- sao user-owned, NOT NULL, e seguem o MESMO padrao dos irmaos ja existentes
-- no schema (profiles.id, user_roles.user_id, customers.owner_id,
-- quotes.owner_id, user_subscriptions.user_id, company_members.user_id — todos
-- `references auth.users(id) on delete cascade`).
--
-- Verificado antes de aplicar (2026-07-23):
--   * as 4 tabelas estao VAZIAS no remoto -> zero linhas orfas;
--   * cada coluna ja possui indice lider utilizavel -> nenhum indice novo aqui;
--   * nenhuma policy, RLS, tipo, dado, seed ou tabela e alterado.
--
-- ON DELETE CASCADE (nao SET NULL): as colunas sao NOT NULL e os registros nao
-- tem sentido sem o usuario dono. Os registros fiscais/financeiros reais
-- (charges, fiscal_invoices, payment_*) referenciam company_profiles, nao
-- auth.users, e portanto sobrevivem a exclusao de um usuario.
-- ON UPDATE fica em NO ACTION (padrao): auth.users.id e UUID estavel, nunca
-- atualizado — identico a todas as FKs irmas.
-- =====================================================================

-- subscriptions.user_id — assinatura 1:1 do usuario (coluna UNIQUE ja indexada).
alter table public.subscriptions
  add constraint subscriptions_user_id_fkey
  foreign key (user_id) references auth.users (id) on delete cascade;

-- project_templates.owner_id — catalogo tecnico do assinante
-- (idx_project_templates_owner_tipo cobre owner_id como coluna lider).
alter table public.project_templates
  add constraint project_templates_owner_id_fkey
  foreign key (owner_id) references auth.users (id) on delete cascade;

-- inventory_items.owner_id — estoque do assinante
-- (idx_inventory_owner ja existe sobre owner_id).
alter table public.inventory_items
  add constraint inventory_items_owner_id_fkey
  foreign key (owner_id) references auth.users (id) on delete cascade;

-- billing_notifications.user_id — notificacoes de cobranca do usuario
-- (idx_notif_user cobre user_id como coluna lider). Nao e registro fiscal:
-- sao lembretes/status, sem valor historico apos a exclusao do usuario.
alter table public.billing_notifications
  add constraint billing_notifications_user_id_fkey
  foreign key (user_id) references auth.users (id) on delete cascade;
