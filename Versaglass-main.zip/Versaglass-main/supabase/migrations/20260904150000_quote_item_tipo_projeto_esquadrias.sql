-- =====================================================================
-- 20260904150000_quote_item_tipo_projeto_esquadrias.sql
--
-- Expande `public.quote_item_tipo_projeto` com os 13 IDs canônicos de
-- Esquadrias (`SUBTIPOS_POR_AREA.esquadrias` / migration 20260904130000).
--
-- Somente aditivo:
--   · ADD VALUE IF NOT EXISTS (sem DML, sem backfill, sem rename)
--   · preserva os 13 valores de Vidraçaria
--
-- Não adiciona Serralheria / Marcenaria / Marmoraria.
-- Não recria a tabela nem a função save_quote_with_items (cast do enum
-- passa a aceitar os novos valores automaticamente).
--
-- NÃO aplicar no remoto nesta rodada — só preparar o arquivo local.
-- =====================================================================

alter type public.quote_item_tipo_projeto add value if not exists 'janela_esquadrias';
alter type public.quote_item_tipo_projeto add value if not exists 'porta_esquadrias';
alter type public.quote_item_tipo_projeto add value if not exists 'maxim_ar_esquadrias';
alter type public.quote_item_tipo_projeto add value if not exists 'fixos_esquadrias';
alter type public.quote_item_tipo_projeto add value if not exists 'portao_esquadrias';
alter type public.quote_item_tipo_projeto add value if not exists 'fachada_esquadrias';
alter type public.quote_item_tipo_projeto add value if not exists 'porta_pivotante_esquadrias';
alter type public.quote_item_tipo_projeto add value if not exists 'diversos_esquadrias';
alter type public.quote_item_tipo_projeto add value if not exists 'basculantes_esquadrias';
alter type public.quote_item_tipo_projeto add value if not exists 'janela_pivotante_esquadrias';
alter type public.quote_item_tipo_projeto add value if not exists 'camarao_esquadrias';
alter type public.quote_item_tipo_projeto add value if not exists 'janela_abrir_esquadrias';
alter type public.quote_item_tipo_projeto add value if not exists 'gradil_esquadrias';

comment on type public.quote_item_tipo_projeto is
  'Tipo comercial do item de orcamento: 13 de Vidracaria + 13 de Esquadrias (IDs *_esquadrias).';

comment on column public.quote_items.tipo_projeto is
  'Tipo comercial do item (Vidracaria ou Esquadrias). NULL = legado ou nao classificado. Distinto de descricao (texto livre) e de project_templates.subtipo; para areas operacionais o ID coincide com o subtipo.';
