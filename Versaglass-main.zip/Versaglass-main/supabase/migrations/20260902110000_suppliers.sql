-- =====================================================================
-- Fornecedores — `public.suppliers` + FK opcional em `inventory_items`
--
-- Design: Revisão 223 (2026-09-02). Substitui CRUD fictício em localStorage.
-- RLS: padrão Estoque (`20260727010000_inventory_company_crud.sql`).
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Enums
-- ---------------------------------------------------------------------
create type public.supplier_area as enum (
  'vidracaria',
  'serralheria',
  'esquadrias',
  'marcenaria',
  'marmoraria',
  'geral'
);

comment on type public.supplier_area is
  'Segmento do fornecedor (filtro Área na tela /app/fornecedores).';

create type public.supplier_status as enum (
  'ativo',
  'inativo',
  'bloqueado'
);

comment on type public.supplier_status is
  'Situação comercial do fornecedor (Ativo / Inativo / Bloqueado).';

-- ---------------------------------------------------------------------
-- 2. Tabela suppliers
-- ---------------------------------------------------------------------
create table public.suppliers (
  id                   uuid primary key default gen_random_uuid(),
  owner_id             uuid not null references auth.users(id) on delete cascade,
  company_id           uuid not null references public.company_profiles(id) on delete cascade,

  codigo               text,
  nome                 text not null,
  area                 public.supplier_area not null default 'geral',
  cnpj                 text,
  telefone             text,
  whatsapp             text,
  vendedor_contato     text,
  prazo_entrega        text,
  produtos_fornecidos  text,
  endereco             text,
  cidade               text,
  observacoes          text,
  status               public.supplier_status not null default 'ativo',

  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now(),

  constraint suppliers_cnpj_len check (cnpj is null or char_length(cnpj) = 14),
  constraint suppliers_nome_len check (char_length(btrim(nome)) >= 1)
);

create index suppliers_company_id_idx on public.suppliers (company_id);
create index suppliers_company_nome_idx on public.suppliers (company_id, lower(nome));

create unique index suppliers_company_codigo_uq
  on public.suppliers (company_id, lower(codigo))
  where codigo is not null and btrim(codigo) <> '';

create unique index suppliers_company_cnpj_uq
  on public.suppliers (company_id, cnpj)
  where cnpj is not null;

create trigger suppliers_updated_at
  before update on public.suppliers
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------
-- 3. RLS — isolamento por empresa (membro lê; criador ou admin edita/apaga)
-- ---------------------------------------------------------------------
alter table public.suppliers enable row level security;

create policy "suppliers_select_company" on public.suppliers
  for select to authenticated
  using (public.is_company_member(company_id, auth.uid()));

create policy "suppliers_insert_company" on public.suppliers
  for insert to authenticated
  with check (
    owner_id = auth.uid()
    and public.is_company_member(company_id, auth.uid())
  );

create policy "suppliers_update_company" on public.suppliers
  for update to authenticated
  using (owner_id = auth.uid() or public.is_company_admin(company_id, auth.uid()))
  with check (public.is_company_member(company_id, auth.uid()));

create policy "suppliers_delete_company" on public.suppliers
  for delete to authenticated
  using (owner_id = auth.uid() or public.is_company_admin(company_id, auth.uid()));

create or replace function public.suppliers_lock_tenant()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.company_id is distinct from old.company_id then
    raise exception 'company_id de suppliers é imutável.' using errcode = '42501';
  end if;
  if new.owner_id is distinct from old.owner_id then
    raise exception 'owner_id de suppliers é imutável.' using errcode = '42501';
  end if;
  return new;
end;
$$;

create trigger suppliers_lock_tenant_biu
  before update on public.suppliers
  for each row execute function public.suppliers_lock_tenant();

-- ---------------------------------------------------------------------
-- 4. Estoque — FK opcional; texto legado `fornecedor` permanece
-- ---------------------------------------------------------------------
alter table public.inventory_items
  add column supplier_id uuid references public.suppliers(id) on delete set null;

create index inventory_items_supplier_id_idx on public.inventory_items (supplier_id)
  where supplier_id is not null;
