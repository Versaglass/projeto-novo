-- =====================================================================
-- 20260727050000_company_owner_membership_fix.sql
--
-- OBJETIVO
--   Fechar o ciclo de CONTAS EMPRESARIAIS:
--     (1) quem cria a empresa é reconhecido como `owner` de forma atômica e
--         verificável pela aplicação;
--     (2) owner/admin empresarial consegue adicionar VENDEDORES sem que o
--         navegador escreva em `company_members` nem veja `auth.users`.
--
-- AUDITORIA QUE PRECEDEU ESTA MIGRATION (leitura por service_role, 2026-07-27)
--   · company_profiles ......................... 2
--   · company_members .......................... 2 (todas role=owner/status=active)
--   · criador SEM membership ................... 0
--   · criador com membership de papel incorreto  0
--   · empresas sem owner ativo ................. 0
--   · empresas com mais de um owner ativo ...... 0
--   · memberships órfãs / sem user_id .......... 0
--   · pares (company_id,user_id) duplicados .... 0
--   O backfill do §3 é, portanto, NO-OP nos dados de hoje. Ele existe apenas
--   como rede de segurança idempotente para linhas criadas entre a auditoria e
--   a aplicação desta migration. Nenhuma promoção automática de papel é feita.
--
-- ESTRUTURA REAL CONFERIDA (baseline 20260721000000)
--   · company_members.role   → TEXT + CHECK ('owner','admin','manager',
--                              'operator','installer','seller') — NÃO é enum.
--   · company_members.status → TEXT + CHECK ('active','blocked','invited').
--     NÃO existe 'pending'. Não há coluna updated_at.
--   · constraint de unicidade REAL: `company_members_company_id_user_id_key`
--     = unique (company_id, user_id) — é a usada em todo ON CONFLICT abaixo.
--   · profiles NÃO possui coluna de e-mail; o e-mail só existe em auth.users.
--   · profiles_select_own restringe a leitura à PRÓPRIA linha — por isso a
--     listagem de funcionários precisa da RPC do §5, e não de um SELECT direto.
--
-- O QUE ESTA MIGRATION NÃO FAZ
--   · não cria, promove nem remove papel de PLATAFORMA (user_roles/app_role);
--   · não toca auth.users, senhas, tokens ou identidades;
--   · não altera dados de outras empresas nem memberships legítimas;
--   · não usa upsert que possa mover uma pessoa de empresa;
--   · não insere dado demonstrativo.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 1. Predicado owner/admin EMPRESARIAL
--
-- `is_company_admin` da baseline inclui 'manager' e trata o criador da empresa
-- como admin implícito mesmo SEM membership. Para o convite de vendedores a
-- decisão de produto é mais estreita: SOMENTE owner e admin, e SOMENTE com
-- membership ativa — nada de admin implícito e nada de manager. Por isso um
-- predicado próprio, em vez de afrouxar o existente (que outras policies usam).
--
-- O guarda `_user_id <> auth.uid()` replica o padrão das funções is_company_*:
-- ninguém consulta o papel de outra pessoa. Quando chamada por service_role
-- (Edge Function), auth.uid() é NULL e o guarda não se aplica.
-- ---------------------------------------------------------------------
create or replace function public.is_company_owner_or_admin(
  _company_id uuid,
  _user_id uuid default auth.uid()
)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when auth.uid() is not null and _user_id <> auth.uid() then false
    else exists (
      select 1 from public.company_members cm
       where cm.company_id = _company_id
         and cm.user_id    = _user_id
         and cm.status     = 'active'
         and cm.role in ('owner', 'admin'))
  end;
$$;

comment on function public.is_company_owner_or_admin(uuid, uuid) is
  'TRUE se o usuário tem membership ATIVA com papel owner ou admin na empresa. Mais estrito que is_company_admin: exclui manager e o "criador implícito sem membership".';

revoke all on function public.is_company_owner_or_admin(uuid, uuid) from public, anon;
grant execute on function public.is_company_owner_or_admin(uuid, uuid) to authenticated;


-- ---------------------------------------------------------------------
-- 2. Onboarding — versão 2 da RPC atômica
--
-- CORREÇÕES sobre a versão aplicada em 20260723020000:
--
--   a) IDEMPOTÊNCIA ESCOPADA A `owner`. A v1 devolvia a primeira empresa em que
--      o usuário fosse membro ATIVO com QUALQUER papel. Consequência: um
--      vendedor convidado para a empresa A que chegasse ao onboarding receberia
--      silenciosamente o id da empresa A como se a tivesse criado — e nunca
--      conseguiria criar a própria. A v2 só considera membership `owner`, o que
--      preserva a proteção anti-duplo-clique (o 2º clique enxerga o owner criado
--      pelo 1º, dentro do mesmo advisory lock) sem sequestrar empresa alheia.
--
--   b) RETORNO ÚTIL. A v1 devolvia só o uuid, obrigando o CompanyProvider a uma
--      segunda ida ao banco para saber nome e papel. A v2 devolve exatamente o
--      necessário para o provider se atualizar: id, nome, papel e status.
--      Mudança de tipo de retorno exige DROP + CREATE (não há `create or
--      replace` entre uuid e jsonb).
--
-- MANTIDO da v1 (continua correto): identidade só de auth.uid(); nenhum
-- user_id/owner_id/company_id/role na assinatura — não há o que forjar;
-- advisory lock por usuário; company_profiles + company_members na MESMA
-- transação, de modo que falha parcial reverte tudo.
-- ---------------------------------------------------------------------
drop function if exists public.create_company_with_owner(text, text, text, text, text, text, text);

create function public.create_company_with_owner(
  p_company_name text,
  p_cnpj    text default null,
  p_phone   text default null,
  p_email   text default null,
  p_city    text default null,
  p_state   text default null,
  p_segment text default 'geral'
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid        uuid := auth.uid();
  v_name       text := nullif(btrim(p_company_name), '');
  v_company_id uuid;
  v_created    boolean := false;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;
  if v_name is null then
    raise exception 'O nome da empresa e obrigatorio.' using errcode = '22023';
  end if;
  if length(v_name) > 160 then
    raise exception 'Nome da empresa acima de 160 caracteres.' using errcode = '22023';
  end if;

  -- Serializa chamadas concorrentes do MESMO usuario (duplo clique / corrida).
  perform pg_advisory_xact_lock(hashtext('company_onboarding:' || v_uid::text));

  select cm.company_id into v_company_id
    from public.company_members cm
   where cm.user_id = v_uid
     and cm.status  = 'active'
     and cm.role    = 'owner'
   order by cm.created_at asc
   limit 1;

  if v_company_id is null then
    insert into public.company_profiles
      (user_id, company_name, cnpj, phone, email, city, state, segment)
    values
      (v_uid, v_name,
       nullif(btrim(p_cnpj), ''), nullif(btrim(p_phone), ''), nullif(btrim(p_email), ''),
       nullif(btrim(p_city), ''), nullif(btrim(p_state), ''),
       coalesce(nullif(btrim(p_segment), ''), 'geral'))
    returning id into v_company_id;

    -- Papel literal, nunca vindo do cliente.
    insert into public.company_members (company_id, user_id, role, status)
    values (v_company_id, v_uid, 'owner', 'active');

    v_created := true;
  end if;

  return (
    select jsonb_build_object(
             'company_id',   cp.id,
             'company_name', cp.company_name,
             'role',         'owner',
             'status',       'active',
             'created',      v_created)
      from public.company_profiles cp
     where cp.id = v_company_id
  );
end;
$$;

comment on function public.create_company_with_owner(text, text, text, text, text, text, text) is
  'Onboarding: cria a empresa do usuario autenticado (auth.uid()) e sua membership owner/active de forma atomica e idempotente. Devolve {company_id, company_name, role, status, created}. Nao concede papel de plataforma.';

revoke all on function public.create_company_with_owner(text, text, text, text, text, text, text) from public, anon;
grant execute on function public.create_company_with_owner(text, text, text, text, text, text, text) to authenticated;


-- ---------------------------------------------------------------------
-- 3. Backfill — criador de empresa SEM membership vira owner/active
--
-- Regras seguidas à risca:
--   · insere SOMENTE quando o criador (company_profiles.user_id) não tem
--     NENHUMA linha em company_members para aquela empresa;
--   · ON CONFLICT sobre a constraint REAL (company_id, user_id) → nunca duplica;
--   · NÃO promove membership existente do criador (ex.: criador registrado como
--     'seller'): esses casos são apenas CONTADOS e reportados por NOTICE, para
--     decisão humana. Promover automaticamente seria mudar papel sem prova;
--   · não toca membros de outras empresas — o filtro é `cm.company_id = cp.id`.
-- ---------------------------------------------------------------------
do $$
declare
  v_faltando   integer;
  v_inseridas  integer;
  v_divergente integer;
  v_sem_dono   integer;
begin
  select count(*) into v_faltando
    from public.company_profiles cp
   where cp.user_id is not null
     and not exists (select 1 from public.company_members cm
                      where cm.company_id = cp.id and cm.user_id = cp.user_id);

  insert into public.company_members (company_id, user_id, role, status)
  select cp.id, cp.user_id, 'owner', 'active'
    from public.company_profiles cp
   where cp.user_id is not null
     and not exists (select 1 from public.company_members cm
                      where cm.company_id = cp.id and cm.user_id = cp.user_id)
  on conflict (company_id, user_id) do nothing;
  get diagnostics v_inseridas = row_count;

  select count(*) into v_divergente
    from public.company_profiles cp
    join public.company_members cm
      on cm.company_id = cp.id and cm.user_id = cp.user_id
   where cm.role <> 'owner' or cm.status <> 'active';

  select count(*) into v_sem_dono
    from public.company_profiles cp
   where not exists (select 1 from public.company_members cm
                      where cm.company_id = cp.id
                        and cm.role = 'owner' and cm.status = 'active');

  raise notice 'backfill owner: % criador(es) sem membership, % inserida(s)', v_faltando, v_inseridas;
  if v_divergente > 0 then
    raise notice 'ATENCAO: % membership(s) do criador com papel/status != owner/active. NAO promovidas automaticamente — revisao humana.', v_divergente;
  end if;
  if v_sem_dono > 0 then
    raise notice 'ATENCAO: % empresa(s) seguem sem owner ativo (criador nulo ou removido) — revisao humana.', v_sem_dono;
  end if;
end $$;


-- ---------------------------------------------------------------------
-- 4. Imutabilidade de tenant em company_members
--
-- "usuário não altera company_id" e "usuário não altera user_id" deixam de
-- depender de policy: um UPDATE que troque a empresa ou a pessoa da linha é
-- rejeitado no banco, venha de onde vier (inclusive service_role). Mover alguém
-- de empresa passa a exigir DELETE + INSERT explícitos.
-- Mesmo padrão de trigger de imutabilidade já usado em project_templates
-- (20260724040000) e inventory_items (20260727010000).
-- ---------------------------------------------------------------------
create or replace function public.company_members_immutable_tenant()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.company_id is distinct from old.company_id then
    raise exception 'company_id de uma membership e imutavel.' using errcode = '42501';
  end if;
  if new.user_id is distinct from old.user_id then
    raise exception 'user_id de uma membership e imutavel.' using errcode = '42501';
  end if;
  return new;
end;
$$;

revoke all on function public.company_members_immutable_tenant() from public, anon, authenticated;

drop trigger if exists company_members_immutable_tenant on public.company_members;
create trigger company_members_immutable_tenant
  before update on public.company_members
  for each row execute function public.company_members_immutable_tenant();


-- ---------------------------------------------------------------------
-- 5. Listagem de funcionários (a página Funcionários consome ESTA função)
--
-- POR QUE UMA RPC, E NÃO UM SELECT DIRETO
--   · `profiles_select_own` só devolve a PRÓPRIA linha: um SELECT de
--     company_members + profiles traria todos os nomes como NULL;
--   · o e-mail não existe em profiles — só em auth.users, que o navegador não
--     deve consultar (e não consegue: auth não é exposto pelo PostgREST).
--
-- PRIVACIDADE
--   · Qualquer membro ATIVO enxerga a equipe (nome, papel, status, entrada).
--   · E-mail e "convite pendente" só para owner/admin.
--   · Nada de provider, tokens, encrypted_password ou metadata administrativa.
--   · O escopo é sempre UMA empresa, validada contra a membership de quem chama:
--     admin de plataforma SEM membership recebe erro, não a lista.
-- ---------------------------------------------------------------------
create or replace function public.list_company_members(p_company_id uuid)
returns table (
  user_id          uuid,
  nome             text,
  email            text,
  role             text,
  status           text,
  created_at       timestamptz,
  convite_pendente boolean
)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_uid  uuid := auth.uid();
  v_role text;
  v_ve_email boolean;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;
  if p_company_id is null then
    raise exception 'Empresa nao informada.' using errcode = '22023';
  end if;

  select cm.role into v_role
    from public.company_members cm
   where cm.company_id = p_company_id
     and cm.user_id    = v_uid
     and cm.status     = 'active';

  if v_role is null then
    raise exception 'Sem vinculo ativo com esta empresa.' using errcode = '42501';
  end if;

  v_ve_email := v_role in ('owner', 'admin');

  return query
    select cm.user_id,
           p.nome,
           case when v_ve_email then u.email::text end,
           cm.role,
           cm.status,
           cm.created_at,
           case when v_ve_email
                then (u.last_sign_in_at is null)
           end
      from public.company_members cm
      left join public.profiles  p on p.id = cm.user_id
      left join auth.users       u on u.id = cm.user_id
     where cm.company_id = p_company_id
     order by case cm.role
                when 'owner'   then 0
                when 'admin'   then 1
                when 'manager' then 2
                else 3
              end,
              cm.created_at asc;
end;
$$;

comment on function public.list_company_members(uuid) is
  'Equipe da empresa informada, escopada pela membership ATIVA de auth.uid(). E-mail e convite pendente somente para owner/admin. Nunca expoe provider, tokens nem metadata de auth.';

revoke all on function public.list_company_members(uuid) from public, anon;
grant execute on function public.list_company_members(uuid) to authenticated;


-- ---------------------------------------------------------------------
-- 6. Suporte à Edge Function de convite — EXCLUSIVO de service_role
--
-- Estas duas funções NÃO são executáveis por anon nem por authenticated: o
-- navegador não as alcança nem com JWT válido. Só a Edge Function, que roda a
-- secret key fora do bundle, consegue chamá-las.
-- ---------------------------------------------------------------------

-- 6.1 Localizar usuário por e-mail SEM paginar auth.users.
-- auth.users.email é indexado; a busca é pontual. Esta é a resposta ao caso
-- "e-mail já possui conta, mas não pertence à empresa" (ETAPA 8, caso 3) sem
-- varredura completa de usuários. service_role já lê auth.users diretamente,
-- então a função não amplia superfície de exposição — apenas a torna barata.
create or replace function public.auth_user_id_by_email(p_email text)
returns uuid
language sql
stable
security definer
set search_path = ''
as $$
  select u.id
    from auth.users u
   where lower(u.email) = lower(btrim(p_email))
   order by u.created_at asc
   limit 1;
$$;

comment on function public.auth_user_id_by_email(text) is
  'Uso EXCLUSIVO da Edge Function invite-company-seller (service_role). Resolve e-mail -> id sem listar auth.users. Nao devolve nenhum outro dado do usuario.';

revoke all on function public.auth_user_id_by_email(text) from public, anon, authenticated;
grant execute on function public.auth_user_id_by_email(text) to service_role;


-- 6.2 Vincular vendedor à empresa, revalidando o solicitante DENTRO do banco.
--
-- A Edge Function já valida o JWT e a membership antes de chamar; esta função
-- valida DE NOVO, com os mesmos critérios, na mesma transação do INSERT. Assim
-- um companyId forjado falha mesmo que a checagem da borda seja contornada.
--
--   · papel FIXO 'seller' e status FIXO 'active' — não há parâmetro de papel,
--     então payload com role não tem por onde entrar;
--   · manager, operator, installer, seller e admin de plataforma sem membership
--     são recusados (42501);
--   · INSERT puro + ON CONFLICT DO NOTHING sobre (company_id, user_id): jamais
--     um UPDATE disfarçado, jamais altera a membership de outra empresa e
--     jamais promove/rebaixa quem já é membro desta.
create or replace function public.add_company_seller(
  p_company_id uuid,
  p_requester  uuid,
  p_user_id    uuid
)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_autorizado boolean;
begin
  if p_company_id is null or p_requester is null or p_user_id is null then
    raise exception 'Parametros obrigatorios ausentes.' using errcode = '22023';
  end if;

  select exists (
    select 1 from public.company_members cm
     where cm.company_id = p_company_id
       and cm.user_id    = p_requester
       and cm.status     = 'active'
       and cm.role in ('owner', 'admin')
  ) into v_autorizado;

  if not v_autorizado then
    raise exception 'Solicitante sem permissao nesta empresa.' using errcode = '42501';
  end if;

  if exists (select 1 from public.company_members cm
              where cm.company_id = p_company_id and cm.user_id = p_user_id) then
    return 'already_member';
  end if;

  insert into public.company_members (company_id, user_id, role, status)
  values (p_company_id, p_user_id, 'seller', 'active')
  on conflict (company_id, user_id) do nothing;

  if not found then
    return 'already_member';
  end if;
  return 'inserted';
end;
$$;

comment on function public.add_company_seller(uuid, uuid, uuid) is
  'Uso EXCLUSIVO da Edge Function invite-company-seller (service_role). Revalida owner/admin ATIVO do solicitante e insere membership seller/active. Papel fixado no servidor; nunca promove nem move membership existente.';

revoke all on function public.add_company_seller(uuid, uuid, uuid) from public, anon, authenticated;
grant execute on function public.add_company_seller(uuid, uuid, uuid) to service_role;


-- ---------------------------------------------------------------------
-- 7. Policies — o navegador deixa de escrever em company_members
--
-- ANTES (baseline): `company_members_insert` autorizava INSERT a qualquer
-- `is_company_admin` — que inclui manager E o criador implícito sem membership.
-- Isso permitia "convidar" alguém escrevendo a linha direto do navegador com um
-- user_id arbitrário, sem passar por Auth nenhum, e permitia a um manager criar
-- membros. A decisão de produto desta etapa é o oposto: convite só pela função
-- de servidor, e só owner/admin.
--
-- Depois desta migration NÃO existe policy de INSERT em company_members: com RLS
-- ligada e sem policy permissiva, todo INSERT vindo de authenticated é negado.
-- A única porta é SECURITY DEFINER (onboarding do §2, convite do §6.2), que
-- roda como dono da tabela e não passa por RLS.
--
-- UPDATE/DELETE continuam existindo (owner/admin precisa poder bloquear ou
-- remover alguém), porém endurecidos: manager sai, ninguém edita ou remove a
-- própria linha (portanto ninguém se autopromove nem se autoexclui), e só um
-- owner mexe em outro owner. company_id/user_id são imutáveis pelo §4.
-- ---------------------------------------------------------------------
drop policy if exists "company_members_insert" on public.company_members;

drop policy if exists "company_members_update" on public.company_members;
create policy "company_members_update" on public.company_members
  for update to authenticated
  using (
    public.is_company_owner_or_admin(company_id, auth.uid())
    and user_id <> auth.uid()
    and (role <> 'owner' or public.is_company_owner(company_id, auth.uid()))
  )
  with check (
    public.is_company_owner_or_admin(company_id, auth.uid())
    and user_id <> auth.uid()
    and (role <> 'owner' or public.is_company_owner(company_id, auth.uid()))
  );

drop policy if exists "company_members_delete" on public.company_members;
create policy "company_members_delete" on public.company_members
  for delete to authenticated
  using (
    public.is_company_owner_or_admin(company_id, auth.uid())
    and user_id <> auth.uid()
    and (role <> 'owner' or public.is_company_owner(company_id, auth.uid()))
  );

comment on table public.company_members is
  'Vinculo pessoa <-> empresa e papel EMPRESARIAL. INSERT so por funcao de servidor (create_company_with_owner, add_company_seller); o navegador nao insere. UPDATE/DELETE: owner/admin ativo, nunca na propria linha, owner so por owner. company_id/user_id imutaveis.';


-- ---------------------------------------------------------------------
-- 8. Empresa só nasce pela RPC atômica
--
-- `company_profiles_insert_own` permitia ao navegador criar a linha da empresa
-- sozinha, sem membership — exatamente o estado "empresa sem owner" que esta
-- migration existe para impedir. Removida: a criação passa a ser possível só
-- por create_company_with_owner, que cria empresa + membership na mesma
-- transação. SELECT/UPDATE/DELETE de company_profiles ficam INALTERADOS.
-- ---------------------------------------------------------------------
drop policy if exists "company_profiles_insert_own" on public.company_profiles;

comment on table public.company_profiles is
  'Empresa assinante (tenant). INSERT somente via RPC create_company_with_owner (empresa + membership owner na mesma transacao). Leitura: criador, membro ativo ou admin de plataforma. Escrita: somente o criador.';
