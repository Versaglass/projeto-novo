-- =====================================================================
-- Venda direta — `public.sales` + `public.sale_items` + baixa ATOMICA de estoque.
--
-- Motivo: a tela "Venda direta" (`/app/calculadora`) nunca persistiu nada — a
-- Revisao 79 mediu: 0 requisicoes ao salvar, 0 chaves novas em localStorage, e
-- o "Salvar rascunho" era so um toast. Esta migration cria o registro da venda
-- e, na MESMA transacao, debita o saldo do estoque.
--
-- Desenho aprovado na Revisao 81; auditoria pre-migration na Revisao 82 (sem
-- colisao de nomes, CHECK de quantidade nao-negativa confirmado, base vazia).
--
-- Seguranca (mesmo padrao de save_quote_with_items e create_company_with_owner):
--   * A RPC e SECURITY DEFINER com search_path travado; ignora RLS, entao valida
--     tudo manualmente aqui.
--   * Identidade SEMPRE de auth.uid(); owner_id nunca vem do cliente.
--   * Empresa validada por is_company_member; o company_id enviado NAO e
--     autorizacao — e conferido contra a membership.
--   * `sales` e `sale_items` recebem SOMENTE policy de SELECT. Sem policy de
--     INSERT/UPDATE/DELETE e com negacao por padrao, a venda so pode nascer pela
--     RPC — ou seja, NAO EXISTE venda gravada sem baixa de estoque.
--
-- Concorrencia: a baixa faz `select ... for update` na linha do inventory_items
-- ANTES de validar o saldo, agregada por item e ORDENADA por id (evita deadlock
-- entre duas vendas com os mesmos itens em ordens diferentes). O CHECK
-- `inventory_items_quantidade_nao_negativa` (20260727010000) continua sendo a
-- rede de seguranca final.
--
-- NAO cria tabela de movimentacao de estoque, NAO cria status de venda e NAO
-- cria cancelamento/estorno — decisoes explicitas da v1 (Revisao 81). Nenhuma
-- migration anterior e editada; nenhuma tabela existente e recriada; nenhuma
-- policy existente e alterada.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 1. Sequencia propria da venda.
--    Separada de `quote_number_seq` de proposito: a numeracao de vendas nao
--    deve saltar porque alguem emitiu orcamentos. Continua GLOBAL (nao por
--    empresa), igual a de orcamentos — limitacao herdada e registrada.
-- ---------------------------------------------------------------------
create sequence public.sale_number_seq start 1;


-- ---------------------------------------------------------------------
-- 2. Forma de pagamento como ENUM — nada de texto livre.
--    Os cinco valores que a tela ja oferecia, mais uma saida honesta.
--    Enum aceita valor novo depois (`alter type ... add value`) sem backfill.
-- ---------------------------------------------------------------------
create type public.sale_payment_method as enum
  ('pix', 'dinheiro', 'cartao', 'boleto', 'parcelado', 'outro');


-- ---------------------------------------------------------------------
-- 3. Cabecalho da venda.
--    company_id e owner_id NOT NULL desde o nascimento — `quotes` nasceu com
--    company_id nullable e deixou 1 orcamento orfao que nao lista, nao edita e
--    nao apaga. Aqui o defeito nao tem como acontecer.
--    NAO ha coluna `status`: toda linha aqui e uma venda FINALIZADA (v1).
-- ---------------------------------------------------------------------
create table public.sales (
  id              uuid primary key default gen_random_uuid(),
  owner_id        uuid not null references auth.users(id) on delete cascade,
  company_id      uuid not null references public.company_profiles(id) on delete cascade,
  customer_id     uuid references public.customers(id) on delete restrict,
  cliente_nome    text,
  numero          integer not null default nextval('public.sale_number_seq'),
  forma_pagamento public.sale_payment_method not null default 'dinheiro',
  subtotal        numeric(12,2) not null default 0,
  desconto        numeric(12,2) not null default 0,
  acrescimo       numeric(12,2) not null default 0,
  total           numeric(12,2) not null default 0,
  observacoes     text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),

  -- Cliente cadastrado OU nome avulso, nunca os dois: duas fontes de verdade
  -- para a mesma informacao divergem com o tempo.
  constraint sales_cliente_fonte_unica
    check (customer_id is null or cliente_nome is null),
  constraint sales_cliente_nome_nao_vazio
    check (cliente_nome is null or btrim(cliente_nome) <> ''),
  constraint sales_desconto_nao_negativo  check (desconto  >= 0),
  constraint sales_acrescimo_nao_negativo check (acrescimo >= 0),
  constraint sales_subtotal_nao_negativo  check (subtotal  >= 0),
  constraint sales_total_nao_negativo     check (total     >= 0)
);


-- ---------------------------------------------------------------------
-- 4. Itens da venda.
--    DIVERGENCIA DELIBERADA de `quote_items`, que NAO tem inventory_item_id
--    (20260727010000 registra que e de proposito, porque orcamento nao
--    movimenta estoque). Aqui a coluna e necessaria: e o que liga a baixa ao
--    item. `on delete set null` para que excluir um item do catalogo NAO apague
--    historico de venda — a descricao fica como snapshot.
-- ---------------------------------------------------------------------
create table public.sale_items (
  id                uuid primary key default gen_random_uuid(),
  sale_id           uuid not null references public.sales(id) on delete cascade,
  company_id        uuid not null references public.company_profiles(id) on delete cascade,
  inventory_item_id uuid references public.inventory_items(id) on delete set null,
  descricao         text not null,
  unidade           public.inventory_unit not null default 'un',
  largura           numeric(10,3) not null default 0,
  altura            numeric(10,3) not null default 0,
  m2                numeric(12,4) not null default 0,
  quantidade        numeric(12,3) not null,
  preco_unit        numeric(12,2) not null default 0,
  desconto          numeric(12,2) not null default 0,
  subtotal          numeric(12,2) not null default 0,
  quantidade_baixa  numeric(12,4) not null default 0,
  ordem             integer not null default 0,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),

  constraint sale_items_descricao_nao_vazia   check (btrim(descricao) <> ''),
  constraint sale_items_quantidade_positiva   check (quantidade > 0),
  constraint sale_items_largura_nao_negativa  check (largura  >= 0),
  constraint sale_items_altura_nao_negativa   check (altura   >= 0),
  constraint sale_items_m2_nao_negativo       check (m2       >= 0),
  constraint sale_items_preco_nao_negativo    check (preco_unit >= 0),
  constraint sale_items_desconto_nao_negativo check (desconto   >= 0),
  constraint sale_items_subtotal_nao_negativo check (subtotal   >= 0),
  constraint sale_items_baixa_nao_negativa    check (quantidade_baixa >= 0)
);


-- ---------------------------------------------------------------------
-- 5. Indices.
-- ---------------------------------------------------------------------
create index idx_sales_company_created on public.sales (company_id, created_at desc);
create index idx_sales_owner           on public.sales (owner_id);
create index idx_sales_customer        on public.sales (customer_id) where customer_id is not null;
create index idx_sale_items_sale       on public.sale_items (sale_id);
create index idx_sale_items_company    on public.sale_items (company_id);
create index idx_sale_items_inventory  on public.sale_items (inventory_item_id) where inventory_item_id is not null;


-- ---------------------------------------------------------------------
-- 6. updated_at — mesma funcao usada por todas as tabelas da baseline.
-- ---------------------------------------------------------------------
create trigger sales_updated_at
  before update on public.sales
  for each row execute function public.set_updated_at();

create trigger sale_items_updated_at
  before update on public.sale_items
  for each row execute function public.set_updated_at();


-- ---------------------------------------------------------------------
-- 7. RLS — leitura por membro da empresa; ESCRITA SO PELA RPC.
--
--    Nao ha policy de INSERT, UPDATE ou DELETE, e isso e o ponto central do
--    desenho: com negacao por padrao, nem o PostgREST nem um fetch forjado
--    criam venda sem passar pela RPC que debita o estoque. Tambem ninguem
--    reescreve o `total` depois, e o historico nao some.
--
--    Sem fallback por `owner_id` na leitura, mesmo endurecimento que a
--    20260727010000 aplicou ao Estoque: quem sai da empresa perde o acesso.
-- ---------------------------------------------------------------------
alter table public.sales      enable row level security;
alter table public.sale_items enable row level security;

create policy "sales_select_company" on public.sales
  for select to authenticated
  using (public.is_company_member(company_id, auth.uid()));

create policy "sale_items_select_company" on public.sale_items
  for select to authenticated
  using (public.is_company_member(company_id, auth.uid()));


-- ---------------------------------------------------------------------
-- 8. RPC — cria a venda e debita o estoque na MESMA transacao.
--
--    Largura e altura chegam em METROS (mesma convencao de save_quote_with_items).
--    Formato de cada item em p_items:
--      { "inventory_item_id": uuid|null, "descricao": text, "unidade": text,
--        "largura": numeric, "altura": numeric, "quantidade": numeric,
--        "preco_unit": numeric, "desconto": numeric }
-- ---------------------------------------------------------------------
create or replace function public.create_sale_with_items(
  p_company_id      uuid,
  p_items           jsonb,
  p_customer_id     uuid                       default null,
  p_cliente_nome    text                       default null,
  p_forma_pagamento public.sale_payment_method default 'dinheiro',
  p_observacoes     text                       default null,
  p_desconto        numeric                    default 0,
  p_acrescimo       numeric                    default 0
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid     uuid    := auth.uid();
  v_sid     uuid;
  v_desc    numeric := round(coalesce(p_desconto, 0), 2);
  v_acr     numeric := round(coalesce(p_acrescimo, 0), 2);
  v_nome    text    := nullif(btrim(coalesce(p_cliente_nome, '')), '');
  v_count   integer;
  v_sum     numeric := 0;
  v_total   numeric;
  v_item    jsonb;
  v_idx     integer := 0;
  v_txt     text;
  v_inv     uuid;
  v_un      public.inventory_unit;
  v_larg    numeric;
  v_alt     numeric;
  v_qtd     numeric;
  v_preco   numeric;
  v_dsc     numeric;
  v_m2      numeric;
  v_base    numeric;
  v_sub     numeric;
  v_baixa   numeric;
  v_saldo   numeric;
  v_it_nome text;
  v_it_un   public.inventory_unit;
  r         record;
begin
  -- Identidade obrigatoria da sessao.
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  -- Empresa: precisa ser membro ativo.
  if p_company_id is null or not public.is_company_member(p_company_id, v_uid) then
    raise exception 'Empresa invalida ou sem permissao.' using errcode = '42501';
  end if;

  -- Cliente e OPCIONAL (venda avulsa). So valida se veio.
  if p_customer_id is not null then
    if v_nome is not null then
      raise exception 'Informe o cliente cadastrado ou o nome avulso, nao os dois.'
        using errcode = '22023';
    end if;
    if not exists (
      select 1 from public.customers c
      where c.id = p_customer_id and c.company_id = p_company_id
    ) then
      raise exception 'Cliente nao pertence a empresa ativa.' using errcode = '23503';
    end if;
  end if;

  -- Itens: array com 1..200 elementos.
  if p_items is null or jsonb_typeof(p_items) <> 'array' then
    raise exception 'Itens invalidos.' using errcode = '22023';
  end if;
  v_count := jsonb_array_length(p_items);
  if v_count < 1 or v_count > 200 then
    raise exception 'A venda deve ter de 1 a 200 itens.' using errcode = '22023';
  end if;

  if v_desc < 0 or v_acr < 0 then
    raise exception 'Desconto e acrescimo nao podem ser negativos.' using errcode = '22023';
  end if;

  -- -------------------------------------------------------------------
  -- PASSO 1 — validacao item a item, ANTES de tocar em qualquer saldo.
  -- -------------------------------------------------------------------
  for v_item in select value from jsonb_array_elements(p_items)
  loop
    v_idx := v_idx + 1;
    v_txt := nullif(btrim(coalesce(v_item->>'descricao', '')), '');
    v_inv := nullif(v_item->>'inventory_item_id', '')::uuid;

    begin
      v_un := coalesce(nullif(v_item->>'unidade', ''), 'un')::public.inventory_unit;
    exception when invalid_text_representation then
      raise exception 'Item % com unidade invalida.', v_idx using errcode = '22023';
    end;

    v_larg  := coalesce((v_item->>'largura')::numeric, 0);
    v_alt   := coalesce((v_item->>'altura')::numeric, 0);
    v_qtd   := coalesce((v_item->>'quantidade')::numeric, 0);
    v_preco := coalesce((v_item->>'preco_unit')::numeric, 0);
    v_dsc   := coalesce((v_item->>'desconto')::numeric, 0);

    if v_txt is null then
      raise exception 'Item % sem descricao.', v_idx using errcode = '22023';
    end if;
    if v_qtd <= 0 then
      raise exception 'Item % com quantidade invalida.', v_idx using errcode = '22023';
    end if;
    if v_larg < 0 or v_alt < 0 or v_preco < 0 or v_dsc < 0 then
      raise exception 'Item % com valor negativo.', v_idx using errcode = '22023';
    end if;

    -- Item em m2 PRECISA de medida. Sem isto, "m2 sem largura/altura" cobraria
    -- uma area inventada — foi exatamente o defeito que a Revisao 79 mediu na
    -- tela antiga, que abria marcando R$ 350,00 com "area vendida 0,00 m2".
    if v_un = 'm2' and (v_larg <= 0 or v_alt <= 0) then
      raise exception 'Item % em m2 precisa de largura e altura maiores que zero.', v_idx
        using errcode = '22023';
    end if;

    -- Item de catalogo: precisa existir, ser da empresa, estar ativo e ter a
    -- MESMA unidade. Unidade divergente debitaria a grandeza errada (vender
    -- "1 un" de um item cadastrado em m2 tiraria 1 do saldo em vez da area).
    if v_inv is not null then
      select i.nome, i.unidade into v_it_nome, v_it_un
        from public.inventory_items i
       where i.id = v_inv
         and i.company_id = p_company_id
         and i.ativo;
      if not found then
        raise exception 'Item "%" nao esta disponivel no estoque desta empresa.', v_txt
          using errcode = '23503';
      end if;
      if v_un is distinct from v_it_un then
        raise exception 'Item "%" esta cadastrado em % no estoque; a venda enviou %.',
          v_it_nome, v_it_un, v_un using errcode = '22023';
      end if;
    end if;
  end loop;

  -- -------------------------------------------------------------------
  -- PASSO 2 — baixa de estoque.
  --   (a) AGREGADA por item: duas linhas de 3 un do mesmo item passariam, uma
  --       a uma, num saldo de 5.
  --   (b) ORDENADA por inventory_item_id: duas vendas concorrentes com os
  --       mesmos itens em ordens diferentes dariam DEADLOCK.
  --   (c) `for update` ANTES de validar: o concorrente espera o commit e rele
  --       o saldo ja reduzido. O CHECK de quantidade nao-negativa e a rede
  --       final, caso algo escape.
  -- -------------------------------------------------------------------
  for r in
    select x.inventory_item_id as inv_id,
           sum(
             case when x.unidade = 'm2'
                  then round(coalesce(x.largura, 0) * coalesce(x.altura, 0), 4) * x.quantidade
                  else x.quantidade
             end
           ) as baixa
      from jsonb_to_recordset(p_items)
        as x(inventory_item_id uuid, unidade text, largura numeric,
             altura numeric, quantidade numeric)
     where x.inventory_item_id is not null
     group by x.inventory_item_id
     order by x.inventory_item_id
  loop
    select i.quantidade, i.nome, i.unidade
      into v_saldo, v_it_nome, v_it_un
      from public.inventory_items i
     where i.id = r.inv_id
       and i.company_id = p_company_id
       and i.ativo
     for update;

    if not found then
      raise exception 'Item "%" nao esta disponivel no estoque desta empresa.', r.inv_id
        using errcode = '23503';
    end if;

    if v_saldo < r.baixa then
      raise exception 'Estoque insuficiente para "%": disponivel % %, venda pede %.',
        v_it_nome, v_saldo, v_it_un, r.baixa using errcode = '23514';
    end if;

    update public.inventory_items
       set quantidade = quantidade - r.baixa
     where id = r.inv_id;
  end loop;

  -- -------------------------------------------------------------------
  -- PASSO 3 — cabecalho (subtotal/total provisorios; recalculados ao final).
  -- -------------------------------------------------------------------
  insert into public.sales
    (owner_id, company_id, customer_id, cliente_nome, forma_pagamento,
     observacoes, desconto, acrescimo, subtotal, total)
  values
    (v_uid, p_company_id, p_customer_id,
     case when p_customer_id is null then v_nome else null end,
     coalesce(p_forma_pagamento, 'dinheiro'),
     nullif(btrim(coalesce(p_observacoes, '')), ''),
     v_desc, v_acr, 0, 0)
  returning id into v_sid;

  -- -------------------------------------------------------------------
  -- PASSO 4 — itens. m2, subtotal e baixa calculados NO BANCO.
  -- -------------------------------------------------------------------
  v_idx := 0;
  for v_item in select value from jsonb_array_elements(p_items)
  loop
    v_txt   := nullif(btrim(coalesce(v_item->>'descricao', '')), '');
    v_inv   := nullif(v_item->>'inventory_item_id', '')::uuid;
    v_un    := coalesce(nullif(v_item->>'unidade', ''), 'un')::public.inventory_unit;
    v_larg  := coalesce((v_item->>'largura')::numeric, 0);
    v_alt   := coalesce((v_item->>'altura')::numeric, 0);
    v_qtd   := coalesce((v_item->>'quantidade')::numeric, 0);
    v_preco := coalesce((v_item->>'preco_unit')::numeric, 0);
    v_dsc   := coalesce((v_item->>'desconto')::numeric, 0);

    v_m2    := round(v_larg * v_alt * v_qtd, 4);
    v_base  := case when v_un = 'm2' then v_m2 else v_qtd end;
    v_sub   := greatest(0, round(v_base * v_preco - v_dsc, 2));
    -- Item avulso (sem vinculo com o catalogo) NAO debita nada.
    v_baixa := case when v_inv is null then 0 else round(v_base, 4) end;
    v_sum   := v_sum + v_sub;

    insert into public.sale_items
      (sale_id, company_id, inventory_item_id, descricao, unidade,
       largura, altura, m2, quantidade, preco_unit, desconto, subtotal,
       quantidade_baixa, ordem)
    values
      (v_sid, p_company_id, v_inv, v_txt, v_un,
       round(v_larg, 3), round(v_alt, 3), v_m2, round(v_qtd, 3),
       round(v_preco, 2), round(v_dsc, 2), v_sub, v_baixa, v_idx);

    v_idx := v_idx + 1;
  end loop;

  -- -------------------------------------------------------------------
  -- PASSO 5 — totais definitivos no banco. Desconto nunca leva a negativo.
  -- -------------------------------------------------------------------
  v_total := greatest(0, round(v_sum - v_desc + v_acr, 2));
  update public.sales
     set subtotal = round(v_sum, 2),
         total    = v_total
   where id = v_sid;

  return v_sid;
end;
$$;


-- ---------------------------------------------------------------------
-- 9. Comentarios — o que cada decisao significa para quem ler depois.
-- ---------------------------------------------------------------------
comment on table public.sales is
  'Venda direta (balcao) finalizada. NAO ha coluna de status na v1: toda linha aqui e uma venda concluida. Escrita exclusivamente pela RPC create_sale_with_items.';
comment on table public.sale_items is
  'Itens da venda direta. `descricao` e SNAPSHOT: o item pode ser renomeado ou excluido do catalogo depois sem alterar o historico.';
comment on column public.sales.customer_id is
  'Cliente cadastrado — OPCIONAL. Venda avulsa usa `cliente_nome`; os dois juntos sao proibidos por CHECK.';
comment on column public.sales.cliente_nome is
  'Nome digitado na venda avulsa. Snapshot: nao cria nem vincula cadastro em customers.';
comment on column public.sales.observacoes is
  'Observacoes da venda. Aparece na nota simples impressa e na tela de detalhe — coluna sem leitor nao entra (Revisao 79).';
comment on column public.sales.total is
  'Recalculado no banco pela RPC (subtotal - desconto + acrescimo, piso 0). Nunca aceito do cliente.';
comment on column public.sale_items.inventory_item_id is
  'Item do catalogo que originou a linha, ou NULL para item avulso. `on delete set null`: excluir do estoque NAO apaga historico de venda.';
comment on column public.sale_items.quantidade_baixa is
  'Quanto foi EFETIVAMENTE subtraido de inventory_items.quantidade (area, quando a unidade e m2; 0 para item avulso). Guardado para um estorno futuro ser exato em vez de recalculado.';
comment on function public.create_sale_with_items(uuid, jsonb, uuid, text, public.sale_payment_method, text, numeric, numeric) is
  'Cria uma venda direta (sales) + itens (sale_items) e DEBITA o estoque na mesma transacao. Identidade de auth.uid(); valida membership da empresa; cliente opcional e, se informado, precisa ser da mesma empresa. Baixa agregada por item, ordenada por id e com select ... for update. Rejeita a venda inteira por saldo insuficiente.';


-- ---------------------------------------------------------------------
-- 10. Privilegios — a regra P-22 exige repetir o revoke em tabela nova, ou o
--     default privilege volta a conceder para anon.
--
--     O grant para `authenticated` nao supera RLS: sem policy de INSERT/UPDATE/
--     DELETE, essas operacoes continuam negadas. Ele existe por simetria com o
--     bloco de grants da baseline.
-- ---------------------------------------------------------------------
revoke all on public.sales      from anon;
revoke all on public.sale_items from anon;
revoke all on sequence public.sale_number_seq from anon;

grant select, insert, update, delete on public.sales      to authenticated;
grant select, insert, update, delete on public.sale_items to authenticated;
grant all on public.sales      to service_role;
grant all on public.sale_items to service_role;
grant usage, select on sequence public.sale_number_seq to authenticated, service_role;

-- Somente autenticados executam a RPC; anon nunca.
revoke all on function public.create_sale_with_items(uuid, jsonb, uuid, text, public.sale_payment_method, text, numeric, numeric) from public;
revoke all on function public.create_sale_with_items(uuid, jsonb, uuid, text, public.sale_payment_method, text, numeric, numeric) from anon;
grant execute on function public.create_sale_with_items(uuid, jsonb, uuid, text, public.sale_payment_method, text, numeric, numeric) to authenticated;
