-- =====================================================================
-- 20260903160000_esquadrias_subtipos_aluminio.sql
--
-- Substitui a taxonomia visual de Esquadrias (antes alinhada a Vidraçaria)
-- por tipos de alumínio / fachada / veneziana.
--
-- NÃO altera o enum `project_area`.
-- NÃO migra dados (não havia registros com os IDs antigos no remoto).
-- Preserva `outro_esquadrias` e `guarda_corpo_esquadrias`.
-- Preserva integralmente Vidraçaria / Serralheria / Marcenaria / Marmoraria.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. CHECK project_templates_area_subtipo
-- ---------------------------------------------------------------------
alter table public.project_templates
  drop constraint if exists project_templates_area_subtipo;

alter table public.project_templates
  add constraint project_templates_area_subtipo check (
    case area
      when 'vidracaria'  then subtipo in ('box','porta_vidro','janela_vidro','guarda_corpo','espelho','fechamento_vidro','outro_vidracaria')
      when 'esquadrias'  then subtipo in (
        'janela_aluminio_esquadrias',
        'porta_aluminio_esquadrias',
        'porta_correr_esquadrias',
        'fachada_esquadrias',
        'veneziana_esquadrias',
        'guarda_corpo_esquadrias',
        'outro_esquadrias'
      )
      when 'serralheria' then subtipo in ('portao','grade','corrimao','estrutura_metalica','cobertura','esquadria_metalica','outro_serralheria')
      when 'marcenaria'  then subtipo in ('armario','porta_madeira','painel','bancada_madeira','movel_planejado','prateleira','outro_marcenaria')
      when 'marmoraria'  then subtipo in ('bancada_pedra','pia','soleira','revestimento','escada','peitoril','outro_marmoraria')
    end
  );

-- ---------------------------------------------------------------------
-- 2. CHECK platform_project_catalog_area_subtipo
-- ---------------------------------------------------------------------
alter table public.platform_project_catalog
  drop constraint if exists platform_project_catalog_area_subtipo;

alter table public.platform_project_catalog
  add constraint platform_project_catalog_area_subtipo check (
    case area
      when 'vidracaria'  then subtipo in ('box','porta_vidro','janela_vidro','guarda_corpo','espelho','fechamento_vidro','outro_vidracaria')
      when 'esquadrias'  then subtipo in (
        'janela_aluminio_esquadrias',
        'porta_aluminio_esquadrias',
        'porta_correr_esquadrias',
        'fachada_esquadrias',
        'veneziana_esquadrias',
        'guarda_corpo_esquadrias',
        'outro_esquadrias'
      )
      when 'serralheria' then subtipo in ('portao','grade','corrimao','estrutura_metalica','cobertura','esquadria_metalica','outro_serralheria')
      when 'marcenaria'  then subtipo in ('armario','porta_madeira','painel','bancada_madeira','movel_planejado','prateleira','outro_marcenaria')
      when 'marmoraria'  then subtipo in ('bancada_pedra','pia','soleira','revestimento','escada','peitoril','outro_marmoraria')
    end
  );
