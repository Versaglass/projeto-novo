-- =====================================================================
-- 20260910150000_catalog_import_validation_warnings.sql
--
-- Hardening Fase 2 — separa warnings do importador (sistema) dos da IA.
-- NÃO altera 20260910140000 (já aplicada).
-- =====================================================================

alter table public.catalog_import_items
  add column if not exists validation_warnings jsonb not null default '[]'::jsonb;

do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conname = 'catalog_import_items_validation_warnings_is_array'
  ) then
    alter table public.catalog_import_items
      add constraint catalog_import_items_validation_warnings_is_array
      check (jsonb_typeof(validation_warnings) = 'array');
  end if;
end $$;

comment on column public.catalog_import_items.validation_warnings is
  'Warnings produzidos pelo importador VersaGlass (ex.: unidade não mapeada). Distintos de ai_warnings.';
