-- =====================================================================
-- company_invitations — convite pendente para quem JÁ tem empresa (Rev. 247/248)
--
-- Conta órfã (0 memberships) continua linkando via add_company_seller.
-- Conta com ≥1 empresa: Edge Function cria pending aqui; aceite via RPC.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Enum + tabela
-- ---------------------------------------------------------------------
do $$ begin
  create type public.company_invitation_status as enum (
    'pending',
    'accepted',
    'rejected',
    'expired',
    'cancelled'
  );
exception
  when duplicate_object then null;
end $$;

create table if not exists public.company_invitations (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null references public.company_profiles(id) on delete cascade,
  invited_user_id uuid not null references auth.users(id) on delete cascade,
  invited_email   text not null,
  invited_by      uuid not null references auth.users(id) on delete restrict,
  proposed_role   text not null default 'seller'
                  check (proposed_role in (
                    'owner', 'admin', 'manager', 'operator', 'installer', 'seller'
                  )),
  status          public.company_invitation_status not null default 'pending',
  created_at      timestamptz not null default now(),
  expires_at      timestamptz not null,
  responded_at    timestamptz,
  constraint company_invitations_email_format
    check (
      invited_email = lower(btrim(invited_email))
      and invited_email ~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$'
    )
);

create unique index if not exists company_invitations_one_pending
  on public.company_invitations (company_id, invited_user_id)
  where status = 'pending';

create index if not exists company_invitations_invitee_pending
  on public.company_invitations (invited_user_id)
  where status = 'pending';

create index if not exists company_invitations_company
  on public.company_invitations (company_id);

comment on table public.company_invitations is
  'Convite pendente para usuario que ja possui empresa. Aceite cria company_members; nao confundir com company_members.status=invited nem com convite_pendente (last_sign_in_at).';

-- ---------------------------------------------------------------------
-- 2. RLS — sem INSERT/UPDATE/DELETE para authenticated (só RPCs / service_role)
-- ---------------------------------------------------------------------
alter table public.company_invitations enable row level security;

drop policy if exists "company_invitations_select_invitee" on public.company_invitations;
create policy "company_invitations_select_invitee"
  on public.company_invitations
  for select to authenticated
  using (invited_user_id = auth.uid());

drop policy if exists "company_invitations_select_company_admin" on public.company_invitations;
create policy "company_invitations_select_company_admin"
  on public.company_invitations
  for select to authenticated
  using (public.is_company_owner_or_admin(company_id, auth.uid()));

revoke all on table public.company_invitations from public, anon;
grant select on table public.company_invitations to authenticated;
grant all on table public.company_invitations to service_role;

-- ---------------------------------------------------------------------
-- 3. list_my_pending_company_invitations
-- ---------------------------------------------------------------------
create or replace function public.list_my_pending_company_invitations()
returns table (
  id              uuid,
  company_id      uuid,
  company_name    text,
  proposed_role   text,
  invited_by_nome text,
  created_at      timestamptz,
  expires_at      timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  -- Lazy expire
  update public.company_invitations i
     set status = 'expired',
         responded_at = coalesce(i.responded_at, now())
   where i.invited_user_id = v_uid
     and i.status = 'pending'
     and i.expires_at <= now();

  return query
    select i.id,
           i.company_id,
           cp.company_name::text,
           i.proposed_role,
           p.nome::text,
           i.created_at,
           i.expires_at
      from public.company_invitations i
      join public.company_profiles cp on cp.id = i.company_id
      left join public.profiles p on p.id = i.invited_by
     where i.invited_user_id = v_uid
       and i.status = 'pending'
       and i.expires_at > now()
     order by i.created_at asc;
end;
$$;

comment on function public.list_my_pending_company_invitations() is
  'Convites pending nao expirados do auth.uid(), com nome da empresa. SECURITY DEFINER; marca expirados lazy.';

revoke all on function public.list_my_pending_company_invitations() from public, anon;
grant execute on function public.list_my_pending_company_invitations() to authenticated;

-- ---------------------------------------------------------------------
-- 4. accept_company_invitation — atômico
-- ---------------------------------------------------------------------
create or replace function public.accept_company_invitation(p_invitation_id uuid)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_inv public.company_invitations%rowtype;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;
  if p_invitation_id is null then
    raise exception 'Convite nao informado.' using errcode = '22023';
  end if;

  select * into v_inv
    from public.company_invitations i
   where i.id = p_invitation_id
   for update;

  if not found then
    raise exception 'Convite nao encontrado.' using errcode = 'P0002';
  end if;

  if v_inv.invited_user_id <> v_uid then
    raise exception 'Sem permissao neste convite.' using errcode = '42501';
  end if;

  if v_inv.status = 'pending' and v_inv.expires_at <= now() then
    update public.company_invitations
       set status = 'expired', responded_at = now()
     where id = v_inv.id;
    return 'expired';
  end if;

  if v_inv.status <> 'pending' then
    return v_inv.status::text;
  end if;

  if exists (
    select 1 from public.company_members cm
     where cm.company_id = v_inv.company_id
       and cm.user_id = v_uid
  ) then
    update public.company_invitations
       set status = 'accepted', responded_at = coalesce(responded_at, now())
     where id = v_inv.id;
    return 'already_member';
  end if;

  insert into public.company_members (company_id, user_id, role, status)
  values (v_inv.company_id, v_uid, v_inv.proposed_role, 'active');

  update public.company_invitations
     set status = 'accepted', responded_at = now()
   where id = v_inv.id;

  return 'accepted';
end;
$$;

comment on function public.accept_company_invitation(uuid) is
  'Convidado (auth.uid) aceita pending: INSERT company_members active + marca accepted na mesma transacao.';

revoke all on function public.accept_company_invitation(uuid) from public, anon;
grant execute on function public.accept_company_invitation(uuid) to authenticated;

-- ---------------------------------------------------------------------
-- 5. reject_company_invitation
-- ---------------------------------------------------------------------
create or replace function public.reject_company_invitation(p_invitation_id uuid)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_inv public.company_invitations%rowtype;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;
  if p_invitation_id is null then
    raise exception 'Convite nao informado.' using errcode = '22023';
  end if;

  select * into v_inv
    from public.company_invitations i
   where i.id = p_invitation_id
   for update;

  if not found then
    raise exception 'Convite nao encontrado.' using errcode = 'P0002';
  end if;

  if v_inv.invited_user_id <> v_uid then
    raise exception 'Sem permissao neste convite.' using errcode = '42501';
  end if;

  if v_inv.status = 'pending' and v_inv.expires_at <= now() then
    update public.company_invitations
       set status = 'expired', responded_at = now()
     where id = v_inv.id;
    return 'expired';
  end if;

  if v_inv.status <> 'pending' then
    return v_inv.status::text;
  end if;

  update public.company_invitations
     set status = 'rejected', responded_at = now()
   where id = v_inv.id;

  return 'rejected';
end;
$$;

comment on function public.reject_company_invitation(uuid) is
  'Convidado (auth.uid) rejeita pending. Nao toca company_members.';

revoke all on function public.reject_company_invitation(uuid) from public, anon;
grant execute on function public.reject_company_invitation(uuid) to authenticated;
