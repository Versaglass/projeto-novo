-- =====================================================================
-- Orçamentos — a RPC passa a PRESERVAR o desenho técnico dos itens.
--
-- DEFEITO COMPROVADO. `save_quote_with_items`, na EDIÇÃO, faz
-- `delete from public.quote_items where quote_id = v_qid` e regrava os itens do
-- zero — mas o INSERT nunca incluiu `drawing_data` nem `drawing_notes`. Logo,
-- qualquer edição de orçamento (trocar um preço, corrigir uma descrição)
-- APAGAVA os recortes, furos, ferragens e observações técnicas de todos os
-- itens, silenciosamente. Hoje isso não machucou ninguém porque nenhum
-- quote_item real tem desenho (confirmado no remoto: os 8 itens existentes
-- estão todos com o default vazio) — mas machucaria assim que o recurso
-- passasse a ser usado, e o fluxo Projeto → Orçamento amplia justamente esse uso.
--
-- Correção: os dois campos passam a viajar DENTRO de cada item de `p_items` e a
-- ser persistidos. A ASSINATURA NÃO MUDA — nenhum parâmetro novo, nenhuma
-- sobrecarga ambígua, e chamadas antigas (sem os campos) continuam válidas.
-- Substitui a função por CREATE OR REPLACE; não edita migrations aplicadas,
-- não altera tabela, tenant, RLS nem regra financeira.
--
-- SOBRE "REMOVER O DESENHO": `quote_items.drawing_data` é `jsonb NOT NULL
-- default '{"versao":1,"recortes":[],"ferragens":[]}'`. NULL é impossível sem
-- mudar a coluna, e afrouxar o NOT NULL criaria um terceiro estado que o
-- editor, o preview da tela e o PDF teriam de tratar. Por isso remover o
-- desenho significa VOLTAR AO DEFAULT VAZIO — que é exatamente o que a
-- aplicação já lê como "sem desenho" (`hasTechnicalDrawing`, `planItemDrawing`).
-- `drawing_notes` é nullable e vira NULL de verdade.
-- =====================================================================

create or replace function public.save_quote_with_items(
  p_company_id    uuid,
  p_customer_id   uuid,
  p_items         jsonb,
  p_quote_id      uuid                 default null,
  p_status        public.quote_status  default 'rascunho',
  p_observacoes   text                 default null,
  p_desconto      numeric              default 0,
  p_acrescimo     numeric              default 0,
  p_validade_dias integer              default 15
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  -- Estado "sem desenho": mesmo default da coluna.
  c_draw_vazio constant jsonb := '{"versao":1,"recortes":[],"ferragens":[]}'::jsonb;
  c_draw_max   constant integer := 65536; -- 64 KB por item

  v_uid   uuid := auth.uid();
  v_qid   uuid := p_quote_id;
  v_desc  numeric := round(coalesce(p_desconto, 0), 2);
  v_acr   numeric := round(coalesce(p_acrescimo, 0), 2);
  v_val   integer := coalesce(p_validade_dias, 15);
  v_sum   numeric := 0;
  v_total numeric;
  v_count integer;
  v_item  jsonb;
  v_idx   integer := 0;
  v_desc_txt text;
  v_larg  numeric;
  v_alt   numeric;
  v_qtd   integer;
  v_preco numeric;
  v_m2    numeric;
  v_sub   numeric;
  v_draw  jsonb;
  v_notes text;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if p_company_id is null or not public.is_company_member(p_company_id, v_uid) then
    raise exception 'Empresa invalida ou sem permissao.' using errcode = '42501';
  end if;

  if not exists (
    select 1 from public.customers c
    where c.id = p_customer_id and c.company_id = p_company_id
  ) then
    raise exception 'Cliente nao pertence a empresa ativa.' using errcode = '23503';
  end if;

  if p_items is null or jsonb_typeof(p_items) <> 'array' then
    raise exception 'Itens invalidos.' using errcode = '22023';
  end if;
  v_count := jsonb_array_length(p_items);
  if v_count < 1 or v_count > 200 then
    raise exception 'O orcamento deve ter de 1 a 200 itens.' using errcode = '22023';
  end if;

  if v_desc < 0 or v_acr < 0 then
    raise exception 'Desconto e acrescimo nao podem ser negativos.' using errcode = '22023';
  end if;
  if v_val < 0 then v_val := 0; end if;

  if v_qid is not null then
    if not exists (
      select 1 from public.quotes q
      where q.id = v_qid
        and q.company_id = p_company_id
        and (q.owner_id = v_uid or public.is_company_admin(p_company_id, v_uid))
    ) then
      raise exception 'Orcamento nao encontrado ou sem permissao.' using errcode = '42501';
    end if;
  end if;

  if v_qid is null then
    insert into public.quotes
      (owner_id, company_id, customer_id, status, observacoes, desconto, acrescimo, validade_dias, total)
    values
      (v_uid, p_company_id, p_customer_id, p_status,
       nullif(btrim(coalesce(p_observacoes, '')), ''), v_desc, v_acr, v_val, 0)
    returning id into v_qid;
  else
    update public.quotes set
      customer_id   = p_customer_id,
      status        = p_status,
      observacoes   = nullif(btrim(coalesce(p_observacoes, '')), ''),
      desconto      = v_desc,
      acrescimo     = v_acr,
      validade_dias = v_val
    where id = v_qid;
    delete from public.quote_items where quote_id = v_qid;
  end if;

  for v_item in select value from jsonb_array_elements(p_items)
  loop
    v_desc_txt := nullif(btrim(coalesce(v_item->>'descricao', '')), '');
    v_larg  := coalesce((v_item->>'largura')::numeric, 0);
    v_alt   := coalesce((v_item->>'altura')::numeric, 0);
    v_qtd   := coalesce((v_item->>'quantidade')::integer, 0);
    v_preco := coalesce((v_item->>'preco_unit')::numeric, 0);

    if v_desc_txt is null then
      raise exception 'Item % sem descricao.', v_idx + 1 using errcode = '22023';
    end if;
    if v_qtd <= 0 then
      raise exception 'Item % com quantidade invalida.', v_idx + 1 using errcode = '22023';
    end if;
    if v_larg < 0 or v_alt < 0 or v_preco < 0 then
      raise exception 'Item % com valor negativo.', v_idx + 1 using errcode = '22023';
    end if;

    -- ---------------------------------------------------------------
    -- Desenho técnico — OPCIONAL. Ausente, null ou omitido = sem desenho.
    -- Presente precisa ser OBJETO json; qualquer outro tipo é rejeitado
    -- (não se adivinha estrutura). `recortes`/`ferragens` são normalizados
    -- para array vazio quando vierem ausentes ou com tipo errado, e o
    -- tamanho é limitado para o payload não virar vetor de abuso.
    -- ---------------------------------------------------------------
    v_draw := v_item -> 'drawing_data';
    if v_draw is null or jsonb_typeof(v_draw) = 'null' then
      v_draw := c_draw_vazio;
    elsif jsonb_typeof(v_draw) <> 'object' then
      raise exception 'Item % com desenho tecnico invalido.', v_idx + 1 using errcode = '22023';
    else
      if jsonb_typeof(v_draw -> 'recortes') is distinct from 'array' then
        v_draw := jsonb_set(v_draw, '{recortes}', '[]'::jsonb, true);
      end if;
      if jsonb_typeof(v_draw -> 'ferragens') is distinct from 'array' then
        v_draw := jsonb_set(v_draw, '{ferragens}', '[]'::jsonb, true);
      end if;
      if jsonb_array_length(v_draw -> 'recortes') > 200
         or jsonb_array_length(v_draw -> 'ferragens') > 200 then
        raise exception 'Item % com desenho tecnico acima do limite.', v_idx + 1 using errcode = '22023';
      end if;
      if octet_length(v_draw::text) > c_draw_max then
        raise exception 'Item % com desenho tecnico acima do limite.', v_idx + 1 using errcode = '22023';
      end if;
    end if;

    v_notes := nullif(btrim(coalesce(v_item->>'drawing_notes', '')), '');
    if v_notes is not null then v_notes := left(v_notes, 2000); end if;

    v_m2 := round(v_larg * v_alt * v_qtd, 4);
    -- Sem dimensoes: preco por UNIDADE. Com dimensoes: por m². Permite item manual.
    if v_larg > 0 and v_alt > 0 then
      v_sub := round(v_m2 * v_preco, 2);
    else
      v_sub := round(v_qtd * v_preco, 2);
    end if;
    v_sum := v_sum + v_sub;

    insert into public.quote_items
      (quote_id, company_id, descricao, largura, altura, quantidade, m2, preco_unit, subtotal, ordem,
       drawing_data, drawing_notes)
    values
      (v_qid, p_company_id, v_desc_txt, round(v_larg, 3), round(v_alt, 3),
       v_qtd, v_m2, round(v_preco, 2), v_sub, v_idx,
       v_draw, v_notes);

    v_idx := v_idx + 1;
  end loop;

  v_total := greatest(0, round(v_sum - v_desc + v_acr, 2));
  update public.quotes set total = v_total where id = v_qid;

  return v_qid;
end;
$$;

comment on function public.save_quote_with_items(uuid, uuid, jsonb, uuid, public.quote_status, text, numeric, numeric, integer) is
  'Cria ou edita um orcamento com seus itens em uma transacao. Desde 20260727030000 cada item pode trazer `drawing_data` (objeto jsonb) e `drawing_notes` (texto), preservados na edicao. Totais continuam calculados no banco; nada de subtotal/total vem do cliente.';
