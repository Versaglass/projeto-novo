-- =====================================================================
-- 20260826120000_project_templates_categoria_acabamento_cor.sql
--
-- Revisão 182 — Implementação do design da Revisão 180 (auditoria Rev. 181 OK).
--
-- Três eixos na Biblioteca (project_templates), alinhados à lista de vidros
-- (sem SKU no enum):
--   · material  → project_category  (+ refletivo, organico, canelado)
--   · processo  → coluna nullable acabamento (enum project_acabamento)
--   · cor       → coluna nullable cor (enum project_cor_refletivo), só refletivo
--
-- Premissas (Rev. 181):
--   · labels novos ainda NÃO existem em project_category
--   · tipos project_acabamento / project_cor_refletivo ainda NÃO existem
--   · colunas acabamento / cor ainda NÃO existem em project_templates
--   · RLS/triggers NÃO citam categoria/acabamento/cor — ADD COLUMN NULL é seguro
--   · linhas existentes ficam com acabamento/cor NULL (sem backfill)
--
-- O que NÃO faz:
--   · não mexe em policies, triggers, RPCs, índices
--   · não altera inventory_category / Estoque / Orçamentos
--   · LED / jateamento fora do escopo (Rev. 180 §6)
--
-- Ordem (Rev. 180 §4): CREATE TYPE → ADD VALUE → ADD COLUMN → CHECK → COMMENT.
-- CHECKs comparam via categoria::text: ADD VALUE nao pode ser USADO como literal
-- do enum na mesma transacao (SQLSTATE 55P04) — mesmo padrao documentado em
-- 20260727000000_inventory_category_expand.sql.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. ENUMS NOVOS (acabamento + cor)
-- ---------------------------------------------------------------------
create type public.project_acabamento as enum (
  'cortado',
  'lapidado',
  'bisote',
  'com_moldura'
);

create type public.project_cor_refletivo as enum (
  'prata',
  'neutro',
  'champanhe',
  'cinza',
  'verde',
  'azul'
);

-- ---------------------------------------------------------------------
-- 2. ESTENDE project_category (mantém os 4 existentes)
-- ATENÇÃO: add value é IRREVERSÍVEL — PostgreSQL não tem drop value.
-- ---------------------------------------------------------------------
alter type public.project_category add value if not exists 'refletivo';
alter type public.project_category add value if not exists 'organico';
alter type public.project_category add value if not exists 'canelado';

-- ---------------------------------------------------------------------
-- 3. COLUNAS NULLABLE (sem default — omitir = NULL)
-- ---------------------------------------------------------------------
alter table public.project_templates
  add column if not exists acabamento public.project_acabamento;

alter table public.project_templates
  add column if not exists cor public.project_cor_refletivo;

comment on column public.project_templates.acabamento is
  'Processo do vidro (cortado/lapidado/bisote/com_moldura). Opcional. NULL = nao informado. Temperado/refletivo/esquadria tipicamente NULL. Ver CHECK project_templates_acabamento_categoria.';

comment on column public.project_templates.cor is
  'Cor do refletivo (prata/neutro/champanhe/cinza/verde/azul). So faz sentido com categoria = refletivo. Ver CHECK project_templates_cor_refletivo.';

-- ---------------------------------------------------------------------
-- 4. CHECKs (Rev. 180 §2 e §3)
--   · acabamento frouxo: evita lixo em aço/MDF; pares finos ficam na UI
--   · cor: NOT NULL so quando categoria = refletivo
-- ---------------------------------------------------------------------
alter table public.project_templates
  drop constraint if exists project_templates_acabamento_categoria;

alter table public.project_templates
  add constraint project_templates_acabamento_categoria check (
    acabamento is null
    or categoria::text in ('vidro_comum', 'espelho', 'organico', 'canelado')
  );

alter table public.project_templates
  drop constraint if exists project_templates_cor_refletivo;

alter table public.project_templates
  add constraint project_templates_cor_refletivo check (
    cor is null
    or categoria::text = 'refletivo'
  );
