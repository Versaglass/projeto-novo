-- =====================================================================
-- 20260910120000_manufacturer_catalog.sql
--
-- Fase 1 — Catálogo global de produtos de fabricantes + Kit para IA.
--
-- Domínio NOVO (não misturar com):
--   · platform_project_catalog …… projetos técnicos
--   · inventory_items …………… estoque por empresa (company_id)
--   · suppliers ………………… fornecedores por empresa
--
-- Gestão (INSERT/UPDATE/DELETE): is_platform_admin (user_roles.role = 'admin')
-- Leitura (SELECT): authenticated (ativos; admin vê inativos) — espelha
-- o padrão de platform_project_catalog para adoção futura pelas empresas.
--
-- Bucket: manufacturer-catalog (privado; imagens do catálogo global).
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. FABRICANTES GLOBAIS
-- ---------------------------------------------------------------------
create table public.product_manufacturers (
  id               uuid primary key default gen_random_uuid(),
  name             text not null,
  normalized_name  text not null,
  active           boolean not null default true,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),

  constraint product_manufacturers_name_len
    check (char_length(btrim(name)) >= 1),
  constraint product_manufacturers_normalized_name_len
    check (char_length(btrim(normalized_name)) >= 1)
);

comment on table public.product_manufacturers is
  'Fabricantes GLOBAIS do catálogo de produtos. Não confundir com suppliers (fornecedor por empresa). Escrita: is_platform_admin. Leitura: authenticated.';

comment on column public.product_manufacturers.normalized_name is
  'Nome normalizado pelo backend VersaGlass (determinístico). Chave de unicidade global. Não confiar em valor vindo da IA.';

create unique index product_manufacturers_normalized_name_uq
  on public.product_manufacturers (normalized_name);

create index product_manufacturers_active_idx
  on public.product_manufacturers (active);

create trigger product_manufacturers_updated_at
  before update on public.product_manufacturers
  for each row execute function public.set_updated_at();

alter table public.product_manufacturers enable row level security;

create policy "product_manufacturers_select"
  on public.product_manufacturers
  for select to authenticated
  using (
    active = true
    or public.is_platform_admin(auth.uid())
  );

create policy "product_manufacturers_insert"
  on public.product_manufacturers
  for insert to authenticated
  with check (public.is_platform_admin(auth.uid()));

create policy "product_manufacturers_update"
  on public.product_manufacturers
  for update to authenticated
  using (public.is_platform_admin(auth.uid()))
  with check (public.is_platform_admin(auth.uid()));

create policy "product_manufacturers_delete"
  on public.product_manufacturers
  for delete to authenticated
  using (public.is_platform_admin(auth.uid()));

revoke all on table public.product_manufacturers from public, anon;
grant select, insert, update, delete on table public.product_manufacturers
  to authenticated, service_role;

-- ---------------------------------------------------------------------
-- 2. PRODUTOS GLOBAIS DE FABRICANTES
-- ---------------------------------------------------------------------
create table public.manufacturer_products (
  id                      uuid primary key default gen_random_uuid(),
  manufacturer_id         uuid not null
                            references public.product_manufacturers(id) on delete restrict,

  source_code             text not null,
  normalized_source_code  text not null,
  base_code               text,

  name                    text not null,
  description             text,

  product_type            text,
  product_line            text,

  suggested_category      text,
  inventory_category      public.inventory_category,
  unit                    public.inventory_unit,

  primary_image_path      text,
  technical_image_paths   jsonb not null default '[]'::jsonb,

  attributes              jsonb not null default '[]'::jsonb,
  observations            jsonb not null default '[]'::jsonb,

  source_catalog_name     text,
  source_catalog_date     text,
  source_page             integer,
  source_excerpt          text,

  active                  boolean not null default true,
  created_at              timestamptz not null default now(),
  updated_at              timestamptz not null default now(),

  constraint manufacturer_products_name_len
    check (char_length(btrim(name)) >= 1),
  constraint manufacturer_products_source_code_len
    check (char_length(btrim(source_code)) >= 1),
  constraint manufacturer_products_normalized_source_code_len
    check (char_length(btrim(normalized_source_code)) >= 1),
  constraint manufacturer_products_technical_image_paths_is_array
    check (jsonb_typeof(technical_image_paths) = 'array'),
  constraint manufacturer_products_attributes_is_array
    check (jsonb_typeof(attributes) = 'array'),
  constraint manufacturer_products_observations_is_array
    check (jsonb_typeof(observations) = 'array'),
  constraint manufacturer_products_source_page_positive
    check (source_page is null or source_page > 0),
  constraint manufacturer_products_manufacturer_source_uq
    unique (manufacturer_id, normalized_source_code)
);

comment on table public.manufacturer_products is
  'Catálogo GLOBAL de produtos de fabricantes. Sem estoque/preço/NCM/supplier. Escrita: is_platform_admin. Leitura: authenticated. Adoção futura → inventory_items por empresa.';

comment on column public.manufacturer_products.normalized_source_code is
  'Código original normalizado pelo backend VersaGlass. Unicidade com manufacturer_id. Não confiar em valor vindo da IA.';

comment on column public.manufacturer_products.suggested_category is
  'Sugestão textual da IA (livre). Mapeamento para inventory_category é feito na revisão pelo Super Admin.';

comment on column public.manufacturer_products.inventory_category is
  'Categoria de estoque mapeada (enum inventory_category). Nullable até a revisão.';

comment on column public.manufacturer_products.primary_image_path is
  'PATH no bucket storage manufacturer-catalog. Não é URL pública.';

comment on column public.manufacturer_products.technical_image_paths is
  'Array JSON de paths no bucket manufacturer-catalog.';

comment on column public.manufacturer_products.attributes is
  'Array JSON flexível do manifesto (name/value/unit/source_text). Sem colunas específicas por atributo.';

create index manufacturer_products_manufacturer_id_idx
  on public.manufacturer_products (manufacturer_id);

create index manufacturer_products_active_idx
  on public.manufacturer_products (active);

create index manufacturer_products_inventory_category_idx
  on public.manufacturer_products (inventory_category)
  where inventory_category is not null;

create trigger manufacturer_products_updated_at
  before update on public.manufacturer_products
  for each row execute function public.set_updated_at();

alter table public.manufacturer_products enable row level security;

create policy "manufacturer_products_select"
  on public.manufacturer_products
  for select to authenticated
  using (
    active = true
    or public.is_platform_admin(auth.uid())
  );

create policy "manufacturer_products_insert"
  on public.manufacturer_products
  for insert to authenticated
  with check (public.is_platform_admin(auth.uid()));

create policy "manufacturer_products_update"
  on public.manufacturer_products
  for update to authenticated
  using (public.is_platform_admin(auth.uid()))
  with check (public.is_platform_admin(auth.uid()));

create policy "manufacturer_products_delete"
  on public.manufacturer_products
  for delete to authenticated
  using (public.is_platform_admin(auth.uid()));

revoke all on table public.manufacturer_products from public, anon;
grant select, insert, update, delete on table public.manufacturer_products
  to authenticated, service_role;

-- ---------------------------------------------------------------------
-- 3. STORAGE — bucket manufacturer-catalog
--
-- Bucket PRIVADO. Leitura: qualquer authenticated (signed URL).
-- Escrita: só is_platform_admin.
-- Path sugerido: manufacturers/<manufacturer_id>/<uuid>.<ext>
-- MIME: jpeg/png/webp · limite 5 MiB (mesmo padrão dos buckets existentes).
-- Não reutiliza platform-catalog (domínio de projetos técnicos).
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'manufacturer-catalog',
  'manufacturer-catalog',
  false,
  5242880,
  array['image/jpeg', 'image/png', 'image/webp']
)
on conflict (id) do nothing;

create policy "manufacturer_catalog_select_authenticated"
  on storage.objects
  for select to authenticated
  using (bucket_id = 'manufacturer-catalog');

create policy "manufacturer_catalog_insert_platform_admin"
  on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'manufacturer-catalog'
    and public.is_platform_admin(auth.uid())
  );

create policy "manufacturer_catalog_update_platform_admin"
  on storage.objects
  for update to authenticated
  using (
    bucket_id = 'manufacturer-catalog'
    and public.is_platform_admin(auth.uid())
  )
  with check (
    bucket_id = 'manufacturer-catalog'
    and public.is_platform_admin(auth.uid())
  );

create policy "manufacturer_catalog_delete_platform_admin"
  on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'manufacturer-catalog'
    and public.is_platform_admin(auth.uid())
  );
