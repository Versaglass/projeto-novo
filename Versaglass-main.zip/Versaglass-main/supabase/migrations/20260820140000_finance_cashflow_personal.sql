-- =====================================================================
-- Financeiro Nivel 2.1 — fluxo de caixa real + gastos pessoais
--
-- Design aprovado: Revisao 159. Auditoria pre-migration: Revisao 160
-- (A1-A5 sem colisao, expenses 11 colunas Rev. 156, helpers OK).
--
-- Escopo:
--   * enum expense_kind + coluna em expenses (default operacional)
--   * CHECK categorias por kind (operacional vs pessoal)
--   * RLS: pessoais visiveis/editaveis so owner/admin
--   * RPC get_finance_cashflow (serie semanal caixa vs despesas operacionais)
--   * REPLACE get_finance_summary (despesas operacionais only)
--
-- Fora do escopo: frontend, retiradas no grafico, push producao.
-- NAO altera migrations anteriores.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 1. enum expense_kind + coluna
-- ---------------------------------------------------------------------
create type public.expense_kind as enum ('operacional', 'pessoal');

alter table public.expenses
  add column expense_kind public.expense_kind not null default 'operacional';

create index idx_expenses_company_kind_date
  on public.expenses (company_id, expense_kind, expense_date desc);


-- ---------------------------------------------------------------------
-- 2. CHECK categorias por kind
-- ---------------------------------------------------------------------
alter table public.expenses
  drop constraint expenses_category_valid;

alter table public.expenses
  add constraint expenses_category_operacional check (
    expense_kind <> 'operacional'::public.expense_kind
    or category in (
      'fornecedor', 'frete', 'combustivel', 'salario', 'imposto',
      'aluguel', 'servico', 'compra', 'outros'
    )
  );

alter table public.expenses
  add constraint expenses_category_pessoal check (
    expense_kind <> 'pessoal'::public.expense_kind
    or category in (
      'alimentacao', 'casa', 'transporte', 'cartao', 'emprestimo',
      'lazer', 'pro_labore', 'outros_pessoal'
    )
  );


-- ---------------------------------------------------------------------
-- 3. Trigger — imutabilidade expense_kind
-- ---------------------------------------------------------------------
create or replace function public.expenses_lock_tenant()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.company_id is distinct from old.company_id then
    raise exception 'company_id de expenses e imutavel.' using errcode = '42501';
  end if;
  if new.owner_id is distinct from old.owner_id then
    raise exception 'owner_id de expenses e imutavel.' using errcode = '42501';
  end if;
  if new.expense_kind is distinct from old.expense_kind then
    raise exception 'expense_kind de expenses e imutavel.' using errcode = '42501';
  end if;
  return new;
end;
$$;


-- ---------------------------------------------------------------------
-- 4. RLS — policies separadas por expense_kind
-- ---------------------------------------------------------------------
drop policy if exists "expenses_select_company" on public.expenses;
drop policy if exists "expenses_insert_company" on public.expenses;
drop policy if exists "expenses_update_company" on public.expenses;
drop policy if exists "expenses_delete_company" on public.expenses;

create policy "expenses_select_operacional" on public.expenses
  for select to authenticated
  using (
    expense_kind = 'operacional'::public.expense_kind
    and public.is_company_member(company_id, auth.uid())
  );

create policy "expenses_select_pessoal" on public.expenses
  for select to authenticated
  using (
    expense_kind = 'pessoal'::public.expense_kind
    and public.is_company_owner_or_admin(company_id, auth.uid())
  );

create policy "expenses_insert_operacional" on public.expenses
  for insert to authenticated
  with check (
    expense_kind = 'operacional'::public.expense_kind
    and owner_id = auth.uid()
    and public.is_company_member(company_id, auth.uid())
  );

create policy "expenses_insert_pessoal" on public.expenses
  for insert to authenticated
  with check (
    expense_kind = 'pessoal'::public.expense_kind
    and owner_id = auth.uid()
    and public.is_company_owner_or_admin(company_id, auth.uid())
  );

create policy "expenses_update_operacional" on public.expenses
  for update to authenticated
  using (
    expense_kind = 'operacional'::public.expense_kind
    and (
      owner_id = auth.uid()
      or public.is_company_admin(company_id, auth.uid())
    )
  )
  with check (
    expense_kind = 'operacional'::public.expense_kind
    and public.is_company_member(company_id, auth.uid())
  );

create policy "expenses_update_pessoal" on public.expenses
  for update to authenticated
  using (
    expense_kind = 'pessoal'::public.expense_kind
    and public.is_company_owner_or_admin(company_id, auth.uid())
    and (
      owner_id = auth.uid()
      or public.is_company_admin(company_id, auth.uid())
    )
  )
  with check (
    expense_kind = 'pessoal'::public.expense_kind
    and public.is_company_owner_or_admin(company_id, auth.uid())
  );

create policy "expenses_delete_operacional" on public.expenses
  for delete to authenticated
  using (
    expense_kind = 'operacional'::public.expense_kind
    and (
      owner_id = auth.uid()
      or public.is_company_admin(company_id, auth.uid())
    )
  );

create policy "expenses_delete_pessoal" on public.expenses
  for delete to authenticated
  using (
    expense_kind = 'pessoal'::public.expense_kind
    and public.is_company_owner_or_admin(company_id, auth.uid())
    and (
      owner_id = auth.uid()
      or public.is_company_admin(company_id, auth.uid())
    )
  );


-- ---------------------------------------------------------------------
-- 5. RPC — get_finance_summary (despesas operacionais only)
-- ---------------------------------------------------------------------
create or replace function public.get_finance_summary(
  p_company_id uuid,
  p_start      timestamptz,
  p_end        timestamptz
)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_uid             uuid := auth.uid();
  v_faturamento     numeric(12,2);
  v_caixa_vendas    numeric(12,2);
  v_caixa_cobrancas numeric(12,2);
  v_caixa_total     numeric(12,2);
  v_despesas        numeric(12,2);
  v_lucro           numeric(12,2);
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if not public.is_company_member(p_company_id, v_uid) then
    raise exception 'Sem permissao para esta empresa.' using errcode = '42501';
  end if;

  if p_start is null or p_end is null or p_start >= p_end then
    raise exception 'Intervalo invalido: p_start deve ser anterior a p_end.' using errcode = '22023';
  end if;

  select coalesce(sum(q.total), 0)::numeric(12,2)
    into v_faturamento
    from public.quotes q
   where q.company_id = p_company_id
     and q.status = 'aprovado'::public.quote_status
     and q.created_at >= p_start
     and q.created_at < p_end;

  select coalesce(sum(s.total), 0)::numeric(12,2)
    into v_caixa_vendas
    from public.sales s
   where s.company_id = p_company_id
     and s.created_at >= p_start
     and s.created_at < p_end;

  select coalesce(sum(c.amount), 0)::numeric(12,2)
    into v_caixa_cobrancas
    from public.charges c
   where c.company_id = p_company_id
     and c.status = 'paid'
     and c.paid_at >= p_start
     and c.paid_at < p_end
     and c.sale_id is null;

  v_caixa_total := v_caixa_vendas + v_caixa_cobrancas;

  select coalesce(sum(e.amount), 0)::numeric(12,2)
    into v_despesas
    from public.expenses e
   where e.company_id = p_company_id
     and e.expense_kind = 'operacional'::public.expense_kind
     and e.expense_date >= p_start::date
     and e.expense_date < p_end::date;

  v_lucro := v_caixa_total - v_despesas;

  return jsonb_build_object(
    'period', jsonb_build_object(
      'start', p_start,
      'end', p_end
    ),
    'faturamento', v_faturamento::text,
    'caixa_vendas', v_caixa_vendas::text,
    'caixa_cobrancas', v_caixa_cobrancas::text,
    'caixa_total', v_caixa_total::text,
    'despesas_total', v_despesas::text,
    'lucro_estimado', v_lucro::text,
    'moeda', 'BRL'
  );
end;
$$;


-- ---------------------------------------------------------------------
-- 6. RPC — get_finance_cashflow (serie semanal)
-- ---------------------------------------------------------------------
create or replace function public.get_finance_cashflow(
  p_company_id  uuid,
  p_start       timestamptz,
  p_end         timestamptz,
  p_granularity text default 'week'
)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_uid            uuid := auth.uid();
  v_granularity    text := coalesce(nullif(btrim(p_granularity), ''), 'week');
  v_d_start        date;
  v_d_end          date;
  v_bucket_count   integer;
  v_buckets        jsonb := '[]'::jsonb;
  v_total_caixa    numeric(12,2) := 0;
  v_total_desp     numeric(12,2) := 0;
  v_b_start        date;
  v_b_end          date;
  v_b_start_ts     timestamptz;
  v_b_end_ts       timestamptz;
  v_caixa          numeric(12,2);
  v_despesas       numeric(12,2);
  v_label          text;
  v_last_day       integer;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if not public.is_company_member(p_company_id, v_uid) then
    raise exception 'Sem permissao para esta empresa.' using errcode = '42501';
  end if;

  if p_start is null or p_end is null or p_start >= p_end then
    raise exception 'Intervalo invalido: p_start deve ser anterior a p_end.' using errcode = '22023';
  end if;

  if v_granularity <> 'week' then
    raise exception 'Granularidade invalida: fase 1 suporta apenas week.' using errcode = '22023';
  end if;

  v_d_start := p_start::date;
  v_d_end   := p_end::date;

  if v_d_start >= v_d_end then
    raise exception 'Intervalo invalido apos conversao para date.' using errcode = '22023';
  end if;

  v_bucket_count := ceil((v_d_end - v_d_start)::numeric / 7)::integer;

  for v_bucket_idx in 0 .. v_bucket_count - 1 loop
    v_b_start := v_d_start + (v_bucket_idx * 7);
    exit when v_b_start >= v_d_end;

    v_b_end := least(v_b_start + 7, v_d_end);
    v_b_start_ts := v_b_start::timestamptz;
    v_b_end_ts   := v_b_end::timestamptz;

    select coalesce(sum(s.total), 0)::numeric(12,2)
      into v_caixa
      from public.sales s
     where s.company_id = p_company_id
       and s.created_at >= v_b_start_ts
       and s.created_at < v_b_end_ts;

    select v_caixa + coalesce(sum(c.amount), 0)::numeric(12,2)
      into v_caixa
      from public.charges c
     where c.company_id = p_company_id
       and c.status = 'paid'
       and c.paid_at >= v_b_start_ts
       and c.paid_at < v_b_end_ts
       and c.sale_id is null;

    select coalesce(sum(e.amount), 0)::numeric(12,2)
      into v_despesas
      from public.expenses e
     where e.company_id = p_company_id
       and e.expense_kind = 'operacional'::public.expense_kind
       and e.expense_date >= v_b_start
       and e.expense_date < v_b_end;

    v_last_day := extract(day from (v_b_end - 1))::integer;
    v_label := format(
      'Sem. %s (%s–%s)',
      v_bucket_idx + 1,
      extract(day from v_b_start)::integer,
      v_last_day
    );

    v_buckets := v_buckets || jsonb_build_array(
      jsonb_build_object(
        'label', v_label,
        'bucket_start', v_b_start_ts,
        'bucket_end', v_b_end_ts,
        'caixa_entrada', v_caixa::text,
        'despesas_operacionais', v_despesas::text
      )
    );

    v_total_caixa := v_total_caixa + v_caixa;
    v_total_desp  := v_total_desp + v_despesas;
  end loop;

  return jsonb_build_object(
    'period', jsonb_build_object(
      'start', p_start,
      'end', p_end
    ),
    'granularity', v_granularity,
    'buckets', v_buckets,
    'totals', jsonb_build_object(
      'caixa_entrada', v_total_caixa::text,
      'despesas_operacionais', v_total_desp::text
    ),
    'moeda', 'BRL'
  );
end;
$$;


-- ---------------------------------------------------------------------
-- 7. Comentarios
-- ---------------------------------------------------------------------
comment on type public.expense_kind is
  'Classificacao de despesa: operacional (negocio) ou pessoal (retirada/pro-labore do dono).';

comment on column public.expenses.expense_kind is
  'operacional = despesa do negocio; pessoal = retirada visivel so owner/admin.';

comment on function public.get_finance_cashflow(uuid, timestamptz, timestamptz, text) is
  'Serie semanal de caixa real (vendas + cobrancas pagas sem sale_id) vs despesas operacionais. Sem faturamento nem pessoal.';


-- ---------------------------------------------------------------------
-- 8. Privilegios — P-22
-- ---------------------------------------------------------------------
revoke all on function public.get_finance_cashflow(uuid, timestamptz, timestamptz, text) from public;
revoke all on function public.get_finance_cashflow(uuid, timestamptz, timestamptz, text) from anon;
grant execute on function public.get_finance_cashflow(uuid, timestamptz, timestamptz, text) to authenticated;
