-- =====================================================================
-- 20260910160000_catalog_import_publish.sql
--
-- Fase 3 — revisão humana, decisão e publicação no catálogo global.
-- NÃO altera migrations anteriores já aplicadas.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. JOB: status publishing + resolução de fabricante + contagens
-- ---------------------------------------------------------------------
alter table public.catalog_import_jobs
  drop constraint if exists catalog_import_jobs_status_check;

alter table public.catalog_import_jobs
  add constraint catalog_import_jobs_status_check check (
    status in (
      'awaiting_upload',
      'processing',
      'ready',
      'publishing',
      'failed',
      'completed',
      'cancelled'
    )
  );

alter table public.catalog_import_jobs
  add column if not exists resolved_manufacturer_id uuid
    references public.product_manufacturers(id) on delete set null;

alter table public.catalog_import_jobs
  add column if not exists resolved_manufacturer_name text;

alter table public.catalog_import_jobs
  add column if not exists approved_items integer not null default 0;

alter table public.catalog_import_jobs
  add column if not exists rejected_items integer not null default 0;

alter table public.catalog_import_jobs
  add column if not exists published_items integer not null default 0;

alter table public.catalog_import_jobs
  add column if not exists duplicates_at_publish integer not null default 0;

alter table public.catalog_import_jobs
  add column if not exists completed_at timestamptz;

alter table public.catalog_import_jobs
  add column if not exists completed_by uuid references auth.users(id) on delete set null;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'catalog_import_jobs_publish_counts_nonneg'
  ) then
    alter table public.catalog_import_jobs
      add constraint catalog_import_jobs_publish_counts_nonneg check (
        approved_items >= 0
        and rejected_items >= 0
        and published_items >= 0
        and duplicates_at_publish >= 0
      );
  end if;
end $$;

comment on column public.catalog_import_jobs.resolved_manufacturer_id is
  'Fabricante escolhido pelo Super Admin para publicação. Não apaga manufacturer_name da Fase 2.';

comment on column public.catalog_import_jobs.resolved_manufacturer_name is
  'Nome corrigido para criar novo fabricante, se resolved_manufacturer_id for null.';

-- ---------------------------------------------------------------------
-- 2. ITEMS: decisão humana + categoria definitiva + published_product_id
-- ---------------------------------------------------------------------
alter table public.catalog_import_items
  add column if not exists review_decision text not null default 'pending';

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'catalog_import_items_review_decision_check'
  ) then
    alter table public.catalog_import_items
      add constraint catalog_import_items_review_decision_check
      check (review_decision in ('pending', 'approved', 'rejected'));
  end if;
end $$;

alter table public.catalog_import_items
  add column if not exists reviewed_by uuid references auth.users(id) on delete set null;

alter table public.catalog_import_items
  add column if not exists reviewed_at timestamptz;

alter table public.catalog_import_items
  add column if not exists published_product_id uuid
    references public.manufacturer_products(id) on delete set null;

alter table public.catalog_import_items
  add column if not exists inventory_category public.inventory_category;

comment on column public.catalog_import_items.review_decision is
  'Decisão humana: pending|approved|rejected. Independente de validation_status.';

comment on column public.catalog_import_items.inventory_category is
  'Categoria VersaGlass escolhida na revisão (definitiva). Distinta de suggested_category.';

comment on column public.catalog_import_items.published_product_id is
  'Produto criado em manufacturer_products após publicação bem-sucedida.';

create index if not exists catalog_import_items_job_decision_idx
  on public.catalog_import_items (import_job_id, review_decision);

create index if not exists catalog_import_items_published_product_idx
  on public.catalog_import_items (published_product_id)
  where published_product_id is not null;

-- ---------------------------------------------------------------------
-- 3. RPC transacional — apenas DB (sem Storage)
--
-- ServerFn: claim ready→publishing, copia imagens, monta payload,
-- chama esta RPC, depois completed + cleanup staging.
-- ---------------------------------------------------------------------
create or replace function public.publish_catalog_import_batch(
  p_job_id uuid,
  p_manufacturer_id uuid,
  p_new_manufacturer_name text,
  p_new_manufacturer_normalized_name text,
  p_products jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_job record;
  v_mfg_id uuid;
  v_mfg_name text;
  v_norm_mfg text;
  v_item jsonb;
  v_prod_id uuid;
  v_item_id uuid;
  v_norm_code text;
  v_existing uuid;
  v_rowcount integer;
  v_published jsonb := '[]'::jsonb;
  v_conflicts jsonb := '[]'::jsonb;
  v_pub_count integer := 0;
  v_dup_count integer := 0;
  v_approved integer := 0;
  v_rejected integer := 0;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if not public.is_platform_admin(v_uid) then
    raise exception 'Apenas Super Admin da plataforma.' using errcode = '42501';
  end if;

  select * into v_job
  from public.catalog_import_jobs j
  where j.id = p_job_id
  for update;

  if not found then
    raise exception 'Importacao nao encontrada.' using errcode = 'P0002';
  end if;

  if v_job.status <> 'publishing' then
    raise exception 'Job nao esta em publishing.' using errcode = '22023';
  end if;

  if p_products is null or jsonb_typeof(p_products) <> 'array' then
    raise exception 'Produtos invalidos.' using errcode = '22023';
  end if;

  if jsonb_array_length(p_products) < 1 then
    raise exception 'Nenhum produto aprovado para publicar.' using errcode = '22023';
  end if;

  if p_manufacturer_id is not null then
    select m.id, m.name into v_mfg_id, v_mfg_name
    from public.product_manufacturers m
    where m.id = p_manufacturer_id;
    if v_mfg_id is null then
      raise exception 'Fabricante informado nao existe.' using errcode = '22023';
    end if;
  else
    v_mfg_name := nullif(btrim(coalesce(p_new_manufacturer_name, '')), '');
    v_norm_mfg := nullif(btrim(coalesce(p_new_manufacturer_normalized_name, '')), '');
    if v_mfg_name is null or v_norm_mfg is null then
      raise exception 'Nome/normalized do fabricante obrigatorios.' using errcode = '22023';
    end if;

    insert into public.product_manufacturers (name, normalized_name, active)
    values (v_mfg_name, v_norm_mfg, true)
    on conflict (normalized_name) do nothing
    returning id into v_mfg_id;

    if v_mfg_id is null then
      select m.id, m.name into v_mfg_id, v_mfg_name
      from public.product_manufacturers m
      where m.normalized_name = v_norm_mfg;
    end if;

    if v_mfg_id is null then
      raise exception 'Falha ao resolver fabricante.' using errcode = 'P0001';
    end if;
  end if;

  for v_item in select value from jsonb_array_elements(p_products)
  loop
    v_item_id := nullif(v_item->>'staging_item_id', '')::uuid;
    v_prod_id := nullif(v_item->>'product_id', '')::uuid;
    v_norm_code := nullif(btrim(coalesce(v_item->>'normalized_source_code', '')), '');

    if v_item_id is null or v_prod_id is null or v_norm_code is null then
      raise exception 'Payload de produto incompleto.' using errcode = '22023';
    end if;

    if not exists (
      select 1 from public.catalog_import_items i
      where i.id = v_item_id
        and i.import_job_id = p_job_id
        and i.review_decision = 'approved'
        and i.validation_status in ('valid', 'review')
    ) then
      raise exception 'Item nao aprovado para publicacao.' using errcode = '22023';
    end if;

    insert into public.manufacturer_products (
      id,
      manufacturer_id,
      source_code,
      normalized_source_code,
      base_code,
      name,
      description,
      product_type,
      product_line,
      suggested_category,
      inventory_category,
      unit,
      primary_image_path,
      technical_image_paths,
      attributes,
      observations,
      source_catalog_name,
      source_catalog_date,
      source_page,
      source_excerpt,
      active
    ) values (
      v_prod_id,
      v_mfg_id,
      btrim(v_item->>'source_code'),
      v_norm_code,
      nullif(v_item->>'base_code', ''),
      btrim(v_item->>'name'),
      nullif(v_item->>'description', ''),
      nullif(v_item->>'product_type', ''),
      nullif(v_item->>'product_line', ''),
      nullif(v_item->>'suggested_category', ''),
      nullif(v_item->>'inventory_category', '')::public.inventory_category,
      nullif(v_item->>'unit', '')::public.inventory_unit,
      nullif(v_item->>'primary_image_path', ''),
      coalesce(v_item->'technical_image_paths', '[]'::jsonb),
      coalesce(v_item->'attributes', '[]'::jsonb),
      coalesce(v_item->'observations', '[]'::jsonb),
      nullif(v_item->>'source_catalog_name', ''),
      nullif(v_item->>'source_catalog_date', ''),
      nullif(v_item->>'source_page', '')::integer,
      nullif(v_item->>'source_excerpt', ''),
      true
    )
    on conflict (manufacturer_id, normalized_source_code) do nothing;

    get diagnostics v_rowcount = row_count;

    if v_rowcount > 0 then
      update public.catalog_import_items
      set published_product_id = v_prod_id,
          duplicate_product_id = null,
          updated_at = now()
      where id = v_item_id;

      v_published := v_published || jsonb_build_array(
        jsonb_build_object('staging_item_id', v_item_id, 'product_id', v_prod_id)
      );
      v_pub_count := v_pub_count + 1;
    else
      select mp.id into v_existing
      from public.manufacturer_products mp
      where mp.manufacturer_id = v_mfg_id
        and mp.normalized_source_code = v_norm_code
      limit 1;

      update public.catalog_import_items
      set validation_status = 'duplicate',
          duplicate_product_id = v_existing,
          published_product_id = null,
          review_decision = 'pending',
          updated_at = now()
      where id = v_item_id;

      v_conflicts := v_conflicts || jsonb_build_array(
        jsonb_build_object(
          'staging_item_id', v_item_id,
          'existing_product_id', v_existing
        )
      );
      v_dup_count := v_dup_count + 1;
    end if;
  end loop;

  select
    count(*) filter (where review_decision = 'approved'),
    count(*) filter (where review_decision = 'rejected')
  into v_approved, v_rejected
  from public.catalog_import_items
  where import_job_id = p_job_id;

  update public.catalog_import_jobs
  set
    resolved_manufacturer_id = v_mfg_id,
    published_items = v_pub_count,
    duplicates_at_publish = v_dup_count,
    approved_items = coalesce(v_approved, 0),
    rejected_items = coalesce(v_rejected, 0),
    status = 'completed',
    completed_at = now(),
    completed_by = v_uid,
    error_message = null,
    error_code = null,
    updated_at = now()
  where id = p_job_id;

  return jsonb_build_object(
    'manufacturer_id', v_mfg_id,
    'manufacturer_name', v_mfg_name,
    'published', v_published,
    'conflicts', v_conflicts,
    'published_count', v_pub_count,
    'duplicates_at_publish', v_dup_count
  );
end;
$$;

revoke all on function public.publish_catalog_import_batch(uuid, uuid, text, text, jsonb)
  from public, anon;
grant execute on function public.publish_catalog_import_batch(uuid, uuid, text, text, jsonb)
  to authenticated;

comment on function public.publish_catalog_import_batch is
  'Publica lote de itens approved do catalog import. SECURITY DEFINER + is_platform_admin. Sem Storage.';
