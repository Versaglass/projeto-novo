-- =====================================================================
-- 20260910200000_inventory_items_rls_manage_estoque.sql
--
-- Fase 5 — alinha RLS de escrita de inventory_items com manage_estoque
-- (mesma regra de can_manage_company_estoque / UI de Estoque).
--
-- SELECT permanece por membership (catálogo compartilhado).
-- INSERT/UPDATE/DELETE exigem can_manage_company_estoque.
-- Platform admin sem membership NÃO bypassa.
-- Sales DEFINER RPCs (baixa/estorno de qty) não são alterados.
-- =====================================================================

drop policy if exists "inventory_insert_company" on public.inventory_items;
drop policy if exists "inventory_update_company" on public.inventory_items;
drop policy if exists "inventory_delete_company" on public.inventory_items;

-- CRIAÇÃO: sessão = owner_id + permissão de gestão de estoque na empresa.
create policy "inventory_insert_company" on public.inventory_items
  for insert to authenticated
  with check (
    owner_id = auth.uid()
    and public.can_manage_company_estoque(company_id, auth.uid())
  );

-- EDIÇÃO (inclui saldo / ativo): mesma capacidade da UI manage_estoque.
create policy "inventory_update_company" on public.inventory_items
  for update to authenticated
  using (public.can_manage_company_estoque(company_id, auth.uid()))
  with check (
    public.is_company_member(company_id, auth.uid())
    and public.can_manage_company_estoque(company_id, auth.uid())
  );

-- EXCLUSÃO: mesma capacidade.
create policy "inventory_delete_company" on public.inventory_items
  for delete to authenticated
  using (public.can_manage_company_estoque(company_id, auth.uid()));

comment on policy "inventory_insert_company" on public.inventory_items is
  'INSERT: owner_id = auth.uid() e can_manage_company_estoque (membership + gestor/checkbox).';

comment on policy "inventory_update_company" on public.inventory_items is
  'UPDATE: can_manage_company_estoque. Sem bypass de platform admin sem membership.';

comment on policy "inventory_delete_company" on public.inventory_items is
  'DELETE: can_manage_company_estoque.';
