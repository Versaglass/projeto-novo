-- =====================================================================
-- Biblioteca de Projetos Técnicos — project_templates passa a pertencer à EMPRESA.
--
-- Decisão de domínio (confirmada): os modelos técnicos reutilizáveis
-- (project_templates) deixam de ser isolados por usuário e passam a ser
-- compartilhados entre os membros da MESMA empresa. `owner_id` continua sendo o
-- CRIADOR; `company_id` passa a ser o tenant do registro. `public.quotes` continua
-- representando a obra/projeto comercial (quotes.etapa é o ciclo) — NÃO se cria
-- entidade de projeto de cliente, e project_templates NÃO é ligado a customers/quotes.
--
-- Backfill seguro: preenche company_id de templates cujo owner pertence a
-- EXATAMENTE uma empresa (membership ativa OU criador da empresa). Dados reais do
-- remoto CONFERIDOS: 1 template · 1 backfill seguro · 0 sem empresa · 0 ambíguos.
-- Por isso, após o backfill, verifica-se que NÃO restou nenhum NULL (aborta com
-- erro claro se restar) e company_id vira **NOT NULL** — não há template sem
-- empresa, nem regra de fallback para NULL.
--
-- Segurança: RLS permanece habilitada. Sem USING(true). Admin de plataforma NÃO
-- recebe acesso automático aos templates dos tenants. Usa as funções existentes
-- is_company_member/is_company_admin (assinaturas reais: (_company_id uuid,
-- _user_id uuid default auth.uid())). Não altera migrations anteriores nem tabelas.
-- =====================================================================

-- 1. Coluna do tenant + FK + índice (mesmo padrão de customers/quotes/inventory).
alter table public.project_templates
  add column if not exists company_id uuid references public.company_profiles(id) on delete cascade;

create index if not exists idx_project_templates_company
  on public.project_templates (company_id);

-- 2. Backfill NÃO-ambíguo: owner com exatamente 1 empresa (membro ativo OU criador).
--    A lateral devolve as empresas DISTINTAS do owner; a window `n` conta quantas
--    são. Filtra n = 1 e usa essa única empresa. (Evita min/max sobre uuid.)
update public.project_templates t
set company_id = m.cid
from (
  select owner_id, cid
  from (
    select o.owner_id,
           c.cid,
           count(*) over (partition by o.owner_id) as n
    from (select distinct owner_id from public.project_templates where company_id is null) o
    join lateral (
      select distinct src.cid
      from (
        select cm.company_id as cid
          from public.company_members cm
         where cm.user_id = o.owner_id and cm.status = 'active'
        union
        select cp.id as cid
          from public.company_profiles cp
         where cp.user_id = o.owner_id
      ) src
    ) c on true
  ) z
  where z.n = 1
) m
where t.owner_id = m.owner_id and t.company_id is null;

-- 2b. Verificação: o backfill DEVE cobrir todos os templates. Dados reais do
--     remoto confirmados (1 template · 1 backfill seguro · 0 sem empresa · 0
--     ambíguos). Se ainda assim algum ficar NULL (owner com 0 ou 2+ empresas),
--     ABORTA com erro claro — atribuição manual necessária antes deste push.
do $$
declare v_orfaos integer;
begin
  select count(*) into v_orfaos from public.project_templates where company_id is null;
  if v_orfaos > 0 then
    raise exception
      'Backfill incompleto: % project_templates sem company_id (owner com 0 ou 2+ empresas). Atribua company_id manualmente antes de aplicar esta migration.',
      v_orfaos using errcode = '23502';
  end if;
end $$;

-- 2c. company_id passa a ser OBRIGATÓRIO — não existe template sem empresa.
alter table public.project_templates alter column company_id set not null;

-- 3. Substitui INTEGRALMENTE as policies por-usuário por policies por-EMPRESA.
--    Sem fallback para NULL (a coluna é NOT NULL a partir daqui).
drop policy if exists "project_templates_select_own" on public.project_templates;
drop policy if exists "project_templates_insert_own" on public.project_templates;
drop policy if exists "project_templates_update_own" on public.project_templates;
drop policy if exists "project_templates_delete_own" on public.project_templates;

-- LEITURA: qualquer membro ativo da empresa.
create policy "project_templates_select_company" on public.project_templates
  for select to authenticated
  using (public.is_company_member(company_id, auth.uid()));

-- CRIAÇÃO: owner_id = sessão; company_id de uma empresa da qual é membro.
create policy "project_templates_insert_company" on public.project_templates
  for insert to authenticated
  with check (
    owner_id = auth.uid()
    and public.is_company_member(company_id, auth.uid())
  );

-- EDIÇÃO: criador OU owner/admin/manager (is_company_admin). O with check impede
-- mover o registro para uma empresa da qual o usuário não é membro.
create policy "project_templates_update_company" on public.project_templates
  for update to authenticated
  using (owner_id = auth.uid() or public.is_company_admin(company_id, auth.uid()))
  with check (public.is_company_member(company_id, auth.uid()));

-- EXCLUSÃO: criador OU owner/admin/manager.
create policy "project_templates_delete_company" on public.project_templates
  for delete to authenticated
  using (owner_id = auth.uid() or public.is_company_admin(company_id, auth.uid()));

-- =====================================================================
-- 3b. IMUTABILIDADE de company_id e owner_id (defesa no banco, além da RLS).
-- Uma policy de UPDATE não impede um membro de A+B mover o template para B, nem
-- um admin trocar owner_id, por chamada direta. Este trigger BEFORE UPDATE rejeita
-- qualquer mudança nessas duas colunas; os demais campos seguem editáveis.
-- =====================================================================
create or replace function public.project_templates_lock_tenant()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.company_id is distinct from old.company_id then
    raise exception 'company_id de project_templates é imutável.' using errcode = '42501';
  end if;
  if new.owner_id is distinct from old.owner_id then
    raise exception 'owner_id de project_templates é imutável.' using errcode = '42501';
  end if;
  return new;
end;
$$;

drop trigger if exists project_templates_lock_tenant_biu on public.project_templates;
create trigger project_templates_lock_tenant_biu
  before update on public.project_templates
  for each row execute function public.project_templates_lock_tenant();

-- =====================================================================
-- 3c. imagem_url = NULL ou PATH no prefixo da PRÓPRIA empresa.
-- Normaliza '' → NULL e proíbe caminho por usuário, de outra empresa ou URL
-- completa. split_part por TEXTO — sem cast do path para uuid. O único template
-- remoto (0 imagens confirmado) não é afetado.
-- =====================================================================
update public.project_templates set imagem_url = null where imagem_url = '';

alter table public.project_templates
  add constraint project_templates_imagem_url_company
  check (imagem_url is null or split_part(imagem_url, '/', 1) = company_id::text);

-- =====================================================================
-- 4. STORAGE — compartilhamento por empresa no bucket `project-images` (privado).
--
-- ADITIVO: as 4 policies por-pasta-de-usuário (foldername[1]=auth.uid(), migration
-- 02) são MANTIDAS porque OUTROS MÓDULOS ainda gravam em `<user_id>/...` neste
-- bucket e dependem delas:
--   · Estoque — app.estoque.tsx:461 → `<user_id>/estoque/<uuid>` (inventory_items)
--   · Orçamentos — editor de modelo (após correção, grava no prefixo empresarial;
--     mas outros fluxos legados por usuário permanecem cobertos).
-- Elas só autorizam caminhos cujo 1º segmento é auth.uid()::text e não tornam o
-- bucket público (bucket segue privado). Não há imagem LEGADA de project_templates.
--
-- Estas policies cobrem o prefixo empresarial `<company_id>/<uuid>.<ext>`. As
-- funções auxiliares comparam por TEXTO (company_id::text = segmento) — NUNCA
-- fazem cast do segmento do path para uuid (falha fechada). Um objeto de Estoque
-- (`<user_id>/...`) não é company de ninguém → estas policies não concedem nada.
--
-- UPDATE/DELETE são RESTRITOS: só quem ENVIOU o objeto (storage.objects.owner_id
-- = auth.uid) OU owner/admin/manager da empresa. Um seller que não enviou NÃO
-- altera nem apaga imagem alheia — a RLS da TABELA não protege chamada direta a
-- storage.objects, por isso a restrição vive aqui.
-- =====================================================================

-- Membro ativo (ou criador) da empresa `_seg`.
create or replace function public.project_image_is_member(_seg text)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.company_members cm
                  where cm.user_id = auth.uid() and cm.status = 'active'
                    and cm.company_id::text = _seg)
      or exists (select 1 from public.company_profiles cp
                  where cp.user_id = auth.uid() and cp.id::text = _seg);
$$;

-- Pode GERIR (apagar/sobrescrever) imagens da empresa `_seg`: owner/admin/manager
-- OU criador da empresa. (O uploader é tratado à parte via storage.objects.owner_id.)
create or replace function public.project_image_can_manage(_seg text)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.company_members cm
                  where cm.user_id = auth.uid() and cm.status = 'active'
                    and cm.role in ('owner','admin','manager') and cm.company_id::text = _seg)
      or exists (select 1 from public.company_profiles cp
                  where cp.user_id = auth.uid() and cp.id::text = _seg);
$$;

revoke all on function public.project_image_is_member(text) from public, anon;
grant execute on function public.project_image_is_member(text) to authenticated, service_role;
revoke all on function public.project_image_can_manage(text) from public, anon;
grant execute on function public.project_image_can_manage(text) to authenticated, service_role;

-- LEITURA: qualquer membro ativo da empresa do 1º segmento.
create policy "project_images_company_select" on storage.objects
  for select to authenticated
  using (bucket_id = 'project-images' and public.project_image_is_member(split_part(name, '/', 1)));

-- UPLOAD: membro ativo grava no prefixo da própria empresa.
create policy "project_images_company_insert" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'project-images' and public.project_image_is_member(split_part(name, '/', 1)));

-- UPDATE: uploader do objeto OU gestor da empresa; nunca move para fora do prefixo.
create policy "project_images_company_update" on storage.objects
  for update to authenticated
  using (bucket_id = 'project-images' and (owner_id = auth.uid()::text or public.project_image_can_manage(split_part(name, '/', 1))))
  with check (bucket_id = 'project-images' and public.project_image_is_member(split_part(name, '/', 1)));

-- DELETE: uploader do objeto OU gestor da empresa.
create policy "project_images_company_delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'project-images' and (owner_id = auth.uid()::text or public.project_image_can_manage(split_part(name, '/', 1))));
