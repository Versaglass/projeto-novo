-- =====================================================================
-- 20260910193000_adopt_estoque_permission_hardening.sql
--
-- Hardening Fase 4B: permissão manage_estoque server-side na adoção.
-- NÃO altera a migration 20260910190000 (já aplicada).
--
-- Regra: membership ativa + (papel owner/admin/manager OU checkbox
-- manage_estoque). Platform admin NÃO bypassa sem membership/permissão.
-- =====================================================================

-- Espelha a UI de Estoque SEM o atalho de platform admin (has_permission).
create or replace function public.can_manage_company_estoque(
  _company_id uuid,
  _user_id uuid default auth.uid()
)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when _company_id is null or _user_id is null then false
    -- Cliente autenticado só consulta a si mesmo (padrão do projeto).
    when auth.uid() is not null and _user_id <> auth.uid() then false
    -- Sem membership ativa (ou criador em company_profiles) → negado.
    when not public.is_company_member(_company_id, _user_id) then false
    -- Gestores empresariais (owner/admin/manager) ou criador da empresa.
    when public.is_company_admin(_company_id, _user_id) then true
    -- Checkbox fino — NÃO usar has_permission (esse concede platform admin).
    else coalesce(
      (
        select (p.permissions ->> 'manage_estoque')::boolean
        from public.profiles p
        where p.id = _user_id
      ),
      false
    )
  end;
$$;

revoke all on function public.can_manage_company_estoque(uuid, uuid) from public, anon;
grant execute on function public.can_manage_company_estoque(uuid, uuid) to authenticated;

comment on function public.can_manage_company_estoque is
  'Permissão de estoque na empresa: membership + (gestor OU manage_estoque). Sem bypass de platform admin.';

-- ---------------------------------------------------------------------
-- RPC de adoção endurecida (SECURITY INVOKER: RLS continua valendo).
-- owner_id = auth.uid(); company_id validado; manage_estoque explícito.
-- Negativos rejeitados (não clamp). Sem escrita no catálogo global.
-- ---------------------------------------------------------------------
create or replace function public.adopt_manufacturer_product_to_inventory(
  p_company_id uuid,
  p_manufacturer_product_id uuid,
  p_nome text,
  p_descricao text,
  p_sku text,
  p_categoria public.inventory_category,
  p_unidade public.inventory_unit,
  p_quantidade numeric,
  p_estoque_minimo numeric,
  p_custo_unit numeric,
  p_preco_venda numeric,
  p_ncm text default null,
  p_observacoes text default null
)
returns uuid
language plpgsql
security invoker
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_prod_id uuid;
  v_mfg_active boolean;
  v_item_id uuid;
  v_nome text := nullif(btrim(coalesce(p_nome, '')), '');
  v_descricao text := nullif(btrim(coalesce(p_descricao, '')), '');
  v_sku text := nullif(btrim(coalesce(p_sku, '')), '');
  v_ncm text := nullif(btrim(coalesce(p_ncm, '')), '');
  v_observacoes text := nullif(btrim(coalesce(p_observacoes, '')), '');
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if p_company_id is null or p_manufacturer_product_id is null then
    raise exception 'Parametros obrigatorios ausentes.' using errcode = '22023';
  end if;

  if v_nome is null then
    raise exception 'Nome obrigatorio.' using errcode = '22023';
  end if;

  if char_length(v_nome) > 120 then
    raise exception 'Nome excede o limite.' using errcode = '22023';
  end if;

  if v_descricao is not null and char_length(v_descricao) > 255 then
    raise exception 'Descricao excede o limite.' using errcode = '22023';
  end if;

  if v_sku is not null and char_length(v_sku) > 64 then
    raise exception 'SKU excede o limite.' using errcode = '22023';
  end if;

  if v_ncm is not null and char_length(v_ncm) > 20 then
    raise exception 'NCM excede o limite.' using errcode = '22023';
  end if;

  if v_observacoes is not null and char_length(v_observacoes) > 1000 then
    raise exception 'Observacoes excedem o limite.' using errcode = '22023';
  end if;

  -- categoria/unidade NOT NULL no schema; enums validados pelo tipo do parâmetro.
  if p_categoria is null then
    raise exception 'Categoria obrigatoria.' using errcode = '22023';
  end if;

  if p_unidade is null then
    raise exception 'Unidade obrigatoria.' using errcode = '22023';
  end if;

  if p_quantidade is null or p_quantidade < 0
     or p_estoque_minimo is null or p_estoque_minimo < 0
     or p_custo_unit is null or p_custo_unit < 0
     or p_preco_venda is null or p_preco_venda < 0 then
    raise exception 'Valores comerciais invalidos.' using errcode = '23514';
  end if;

  -- company_id do cliente NÃO é autoridade: membership + manage_estoque.
  if not public.is_company_member(p_company_id, v_uid) then
    raise exception 'Sem permissao nesta empresa.' using errcode = '42501';
  end if;

  if not public.can_manage_company_estoque(p_company_id, v_uid) then
    raise exception 'Sem permissao de estoque nesta empresa.' using errcode = '42501';
  end if;

  -- Produto global ativo (autoridade server-side)
  select mp.id into v_prod_id
  from public.manufacturer_products mp
  where mp.id = p_manufacturer_product_id
    and mp.active = true;

  if v_prod_id is null then
    raise exception 'PRODUTO_INDISPONIVEL' using errcode = 'P0002';
  end if;

  select pm.active into v_mfg_active
  from public.manufacturer_products mp
  join public.product_manufacturers pm on pm.id = mp.manufacturer_id
  where mp.id = p_manufacturer_product_id;

  if v_mfg_active is distinct from true then
    raise exception 'PRODUTO_INDISPONIVEL' using errcode = 'P0002';
  end if;

  begin
    insert into public.inventory_items (
      owner_id,
      company_id,
      categoria,
      nome,
      descricao,
      unidade,
      quantidade,
      estoque_minimo,
      custo_unit,
      preco_venda,
      sku,
      ncm,
      observacoes,
      imagem_url,
      fornecedor,
      supplier_id,
      localizacao,
      ativo,
      originado_de_projeto,
      manufacturer_product_id
    ) values (
      v_uid, -- owner_id server-side; nunca do payload
      p_company_id,
      p_categoria,
      v_nome,
      v_descricao,
      p_unidade,
      p_quantidade,
      p_estoque_minimo,
      p_custo_unit,
      p_preco_venda,
      v_sku,
      v_ncm,
      v_observacoes,
      null, -- sem cópia de imagem global / sem path manufacturer-catalog
      null, -- fabricante ≠ fornecedor; criação manual também limpa supplier
      null,
      null,
      true,
      false,
      p_manufacturer_product_id
    )
    returning id into v_item_id;
  exception
    when unique_violation then
      raise exception 'JA_ADOTADO' using errcode = '23505';
  end;

  return v_item_id;
end;
$$;

comment on function public.adopt_manufacturer_product_to_inventory is
  'Adota manufacturer_product → inventory_items (snapshot). Exige membership + manage_estoque. Sem sync/Storage. SECURITY INVOKER.';
