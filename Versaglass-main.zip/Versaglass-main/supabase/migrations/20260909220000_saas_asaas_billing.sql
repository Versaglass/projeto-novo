-- =====================================================================
-- 20260909220000_saas_asaas_billing.sql
--
-- Billing SaaS do VersaGlass via Asaas (mensalidade da plataforma).
-- NÃO altera a tabela legacy `subscriptions` (billing manual por user_id).
-- NÃO toca marketplace (payment_accounts / charges / splits).
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. saas_plans — catálogo canônico de preços (server-side)
-- ---------------------------------------------------------------------
create table public.saas_plans (
  slug          text primary key,
  name          text not null,
  price_monthly numeric(10, 2) not null,
  cycle         text not null,
  active        boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  constraint saas_plans_slug_check check (slug in ('basic', 'premium')),
  constraint saas_plans_cycle_check check (cycle in ('MONTHLY')),
  constraint saas_plans_price_check check (price_monthly > 0)
);

comment on table public.saas_plans is
  'Planos SaaS VersaGlass (mensalidade). Preços canônicos — o frontend nunca define valor.';

insert into public.saas_plans (slug, name, price_monthly, cycle, active) values
  ('basic', 'Básico', 49.90, 'MONTHLY', true),
  ('premium', 'Premium', 99.90, 'MONTHLY', true);

create trigger saas_plans_updated_at
  before update on public.saas_plans
  for each row execute function public.set_updated_at();

alter table public.saas_plans enable row level security;

create policy "saas_plans_select_active" on public.saas_plans
  for select to authenticated
  using (active = true);

-- Sem policies de INSERT/UPDATE/DELETE para authenticated:
-- escrita só via migration / service_role.

grant select on public.saas_plans to authenticated;
grant all on public.saas_plans to service_role;

-- ---------------------------------------------------------------------
-- 2. company_subscriptions — estado atual do contrato SaaS por empresa
-- ---------------------------------------------------------------------
create table public.company_subscriptions (
  id                    uuid primary key default gen_random_uuid(),
  company_id            uuid not null references public.company_profiles(id) on delete cascade,
  plan_slug             text not null references public.saas_plans(slug),
  status                text not null default 'pending',
  created_by            uuid references auth.users(id) on delete set null,
  asaas_customer_id     text,
  asaas_checkout_id     text,
  asaas_subscription_id text,
  checkout_status       text,
  billing_type          text,
  last_payment_at       timestamptz,
  next_due_date         date,
  checkout_expires_at   timestamptz,
  canceled_at           timestamptz,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now(),
  constraint company_subscriptions_company_id_key unique (company_id),
  constraint company_subscriptions_status_check
    check (status in ('pending', 'active', 'past_due', 'suspended', 'canceled')),
  constraint company_subscriptions_checkout_status_check
    check (checkout_status is null or checkout_status in ('ACTIVE', 'PAID', 'CANCELED', 'EXPIRED')),
  constraint company_subscriptions_billing_type_check
    check (billing_type is null or billing_type in ('CREDIT_CARD'))
);

comment on table public.company_subscriptions is
  'Assinatura SaaS atual por empresa (VersaGlass ↔ Asaas). Escrita apenas via Edge Functions / service_role.';

create unique index company_subscriptions_asaas_customer_id_uq
  on public.company_subscriptions (asaas_customer_id)
  where asaas_customer_id is not null;

create unique index company_subscriptions_asaas_checkout_id_uq
  on public.company_subscriptions (asaas_checkout_id)
  where asaas_checkout_id is not null;

create unique index company_subscriptions_asaas_subscription_id_uq
  on public.company_subscriptions (asaas_subscription_id)
  where asaas_subscription_id is not null;

create index company_subscriptions_status_idx
  on public.company_subscriptions (status);

create trigger company_subscriptions_updated_at
  before update on public.company_subscriptions
  for each row execute function public.set_updated_at();

alter table public.company_subscriptions enable row level security;

-- Membro ativo da empresa lê a própria assinatura.
create policy "company_subscriptions_select_member" on public.company_subscriptions
  for select to authenticated
  using (public.is_company_member(company_id, auth.uid()));

-- Super Admin de plataforma lê todas.
create policy "company_subscriptions_select_platform_admin" on public.company_subscriptions
  for select to authenticated
  using (public.is_platform_admin(auth.uid()));

-- Sem INSERT/UPDATE/DELETE para authenticated — Edge Functions usam service_role.

grant select on public.company_subscriptions to authenticated;
grant all on public.company_subscriptions to service_role;

-- ---------------------------------------------------------------------
-- 3. asaas_webhook_events — idempotência + auditoria mínima
-- ---------------------------------------------------------------------
create table public.asaas_webhook_events (
  event_id                 text primary key,
  event_type               text not null,
  resource_id              text,
  company_subscription_id  uuid references public.company_subscriptions(id) on delete set null,
  received_at              timestamptz not null default now(),
  processed_at             timestamptz,
  processing_error         text
);

comment on table public.asaas_webhook_events is
  'Eventos Asaas processados (idempotência). Somente service_role; sem policies tenant.';

create index asaas_webhook_events_type_idx
  on public.asaas_webhook_events (event_type);

create index asaas_webhook_events_subscription_idx
  on public.asaas_webhook_events (company_subscription_id)
  where company_subscription_id is not null;

alter table public.asaas_webhook_events enable row level security;

-- RLS ligado + zero policies para authenticated = sem acesso tenant.
-- service_role bypassa RLS.

grant all on public.asaas_webhook_events to service_role;

-- ---------------------------------------------------------------------
-- 4. Hardening anon (padrão do projeto — DEFAULT PRIVILEGES)
-- ---------------------------------------------------------------------
revoke all on table public.saas_plans from anon;
revoke all on table public.company_subscriptions from anon;
revoke all on table public.asaas_webhook_events from anon;
