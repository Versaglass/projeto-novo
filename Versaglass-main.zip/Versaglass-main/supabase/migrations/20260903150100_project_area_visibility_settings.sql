-- =====================================================================
-- 20260903150100_project_area_visibility_settings.sql
--
-- 1. Atualiza CHECKs (area, subtipo): Esquadrias aceita só `outro_esquadrias`
--    (placeholder até taxonomia de negócio; demais áreas inalteradas).
-- 2. Cria `platform_settings` (config GLOBAL, sem company_id).
-- 3. Seed: esquadrias=true; serralheria/marcenaria/marmoraria=false.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. CHECK project_templates_area_subtipo
-- ---------------------------------------------------------------------
alter table public.project_templates
  drop constraint if exists project_templates_area_subtipo;

alter table public.project_templates
  add constraint project_templates_area_subtipo check (
    case area
      when 'vidracaria'  then subtipo in ('box','porta_vidro','janela_vidro','guarda_corpo','espelho','fechamento_vidro','outro_vidracaria')
      when 'esquadrias'  then subtipo in ('outro_esquadrias')
      when 'serralheria' then subtipo in ('portao','grade','corrimao','estrutura_metalica','cobertura','esquadria_metalica','outro_serralheria')
      when 'marcenaria'  then subtipo in ('armario','porta_madeira','painel','bancada_madeira','movel_planejado','prateleira','outro_marcenaria')
      when 'marmoraria'  then subtipo in ('bancada_pedra','pia','soleira','revestimento','escada','peitoril','outro_marmoraria')
    end
  );

-- ---------------------------------------------------------------------
-- 2. CHECK platform_project_catalog_area_subtipo
-- ---------------------------------------------------------------------
alter table public.platform_project_catalog
  drop constraint if exists platform_project_catalog_area_subtipo;

alter table public.platform_project_catalog
  add constraint platform_project_catalog_area_subtipo check (
    case area
      when 'vidracaria'  then subtipo in ('box','porta_vidro','janela_vidro','guarda_corpo','espelho','fechamento_vidro','outro_vidracaria')
      when 'esquadrias'  then subtipo in ('outro_esquadrias')
      when 'serralheria' then subtipo in ('portao','grade','corrimao','estrutura_metalica','cobertura','esquadria_metalica','outro_serralheria')
      when 'marcenaria'  then subtipo in ('armario','porta_madeira','painel','bancada_madeira','movel_planejado','prateleira','outro_marcenaria')
      when 'marmoraria'  then subtipo in ('bancada_pedra','pia','soleira','revestimento','escada','peitoril','outro_marmoraria')
    end
  );

-- ---------------------------------------------------------------------
-- 3. platform_settings — configuração GLOBAL (sem company_id / tenant)
-- ---------------------------------------------------------------------
create table if not exists public.platform_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users (id) on delete set null
);

comment on table public.platform_settings is
  'Configuracoes GLOBAIS da plataforma (sem tenant). Leitura: authenticated. Escrita: is_platform_admin.';

drop trigger if exists platform_settings_updated_at on public.platform_settings;
create trigger platform_settings_updated_at
  before update on public.platform_settings
  for each row execute function public.set_updated_at();

alter table public.platform_settings enable row level security;

drop policy if exists "platform_settings_select_authenticated" on public.platform_settings;
create policy "platform_settings_select_authenticated"
  on public.platform_settings
  for select
  to authenticated
  using (true);

drop policy if exists "platform_settings_insert_platform_admin" on public.platform_settings;
create policy "platform_settings_insert_platform_admin"
  on public.platform_settings
  for insert
  to authenticated
  with check (public.is_platform_admin(auth.uid()));

drop policy if exists "platform_settings_update_platform_admin" on public.platform_settings;
create policy "platform_settings_update_platform_admin"
  on public.platform_settings
  for update
  to authenticated
  using (public.is_platform_admin(auth.uid()))
  with check (public.is_platform_admin(auth.uid()));

drop policy if exists "platform_settings_delete_platform_admin" on public.platform_settings;
create policy "platform_settings_delete_platform_admin"
  on public.platform_settings
  for delete
  to authenticated
  using (public.is_platform_admin(auth.uid()));

insert into public.platform_settings (key, value)
values (
  'project_area_visibility',
  jsonb_build_object(
    'esquadrias', true,
    'serralheria', false,
    'marcenaria', false,
    'marmoraria', false
  )
)
on conflict (key) do nothing;

grant select, insert, update, delete on public.platform_settings to authenticated;
grant all on public.platform_settings to service_role;
