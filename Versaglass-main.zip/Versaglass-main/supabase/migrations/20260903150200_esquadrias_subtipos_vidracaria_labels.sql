-- =====================================================================
-- 20260903150200_esquadrias_subtipos_vidracaria_labels.sql
--
-- Expande os subtipos de `esquadrias` para espelhar os NOMES VISUAIS de
-- Vidraçaria, com IDs próprios (sufixo `_esquadrias`).
--
-- NÃO altera o enum `project_area`.
-- NÃO migra dados existentes.
-- Preserva `outro_esquadrias` (já pode haver registros).
-- Preserva integralmente Vidraçaria / Serralheria / Marcenaria / Marmoraria.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. CHECK project_templates_area_subtipo
-- ---------------------------------------------------------------------
alter table public.project_templates
  drop constraint if exists project_templates_area_subtipo;

alter table public.project_templates
  add constraint project_templates_area_subtipo check (
    case area
      when 'vidracaria'  then subtipo in ('box','porta_vidro','janela_vidro','guarda_corpo','espelho','fechamento_vidro','outro_vidracaria')
      when 'esquadrias'  then subtipo in (
        'box_esquadrias',
        'porta_vidro_esquadrias',
        'janela_vidro_esquadrias',
        'guarda_corpo_esquadrias',
        'espelho_esquadrias',
        'fechamento_vidro_esquadrias',
        'outro_esquadrias'
      )
      when 'serralheria' then subtipo in ('portao','grade','corrimao','estrutura_metalica','cobertura','esquadria_metalica','outro_serralheria')
      when 'marcenaria'  then subtipo in ('armario','porta_madeira','painel','bancada_madeira','movel_planejado','prateleira','outro_marcenaria')
      when 'marmoraria'  then subtipo in ('bancada_pedra','pia','soleira','revestimento','escada','peitoril','outro_marmoraria')
    end
  );

-- ---------------------------------------------------------------------
-- 2. CHECK platform_project_catalog_area_subtipo
-- ---------------------------------------------------------------------
alter table public.platform_project_catalog
  drop constraint if exists platform_project_catalog_area_subtipo;

alter table public.platform_project_catalog
  add constraint platform_project_catalog_area_subtipo check (
    case area
      when 'vidracaria'  then subtipo in ('box','porta_vidro','janela_vidro','guarda_corpo','espelho','fechamento_vidro','outro_vidracaria')
      when 'esquadrias'  then subtipo in (
        'box_esquadrias',
        'porta_vidro_esquadrias',
        'janela_vidro_esquadrias',
        'guarda_corpo_esquadrias',
        'espelho_esquadrias',
        'fechamento_vidro_esquadrias',
        'outro_esquadrias'
      )
      when 'serralheria' then subtipo in ('portao','grade','corrimao','estrutura_metalica','cobertura','esquadria_metalica','outro_serralheria')
      when 'marcenaria'  then subtipo in ('armario','porta_madeira','painel','bancada_madeira','movel_planejado','prateleira','outro_marcenaria')
      when 'marmoraria'  then subtipo in ('bancada_pedra','pia','soleira','revestimento','escada','peitoril','outro_marmoraria')
    end
  );
