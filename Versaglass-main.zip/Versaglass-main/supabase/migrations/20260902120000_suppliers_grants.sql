-- =====================================================================
-- Fornecedores — GRANT authenticated + REVOKE anon (P-22)
--
-- Revisão 225: `public.suppliers` nasceu com RLS/policies corretas, mas sem
-- GRANT explícito. Default privileges desta instância deixaram só `Dxtm` para
-- `authenticated` → PostgREST GET 404 / POST 403. RLS restringe o que o GRANT
-- já permite; sem GRANT, as policies não entram em jogo.
--
-- Sem sequence: `id` é uuid `gen_random_uuid()`.
-- =====================================================================

revoke all on table public.suppliers from anon;
revoke all on table public.suppliers from public;

grant select, insert, update, delete on table public.suppliers to authenticated;
grant all on table public.suppliers to service_role;

revoke all on function public.suppliers_lock_tenant() from public;
revoke all on function public.suppliers_lock_tenant() from anon;
