-- =====================================================================
-- Endurecimento da Biblioteca de Projetos Técnicos — follow-up de 20260724030000.
--
-- CONTEXTO / DIVERGÊNCIA: a migration 20260724030000 JÁ foi aplicada no remoto com
-- uma versão ANTERIOR, sem os três endurecimentos abaixo (bloqueadores 2/3/4). O
-- arquivo LOCAL de 30000 divergiu (contém os endurecimentos adicionados DEPOIS do
-- push). Como o `db push` compara NOMES de migration, editar a 30000 não chega ao
-- remoto — por isso as correções ausentes vão NESTA migration nova.
--
-- TUDO É IDEMPOTENTE (CREATE OR REPLACE / DROP … IF EXISTS) para ser seguro nos DOIS
-- cenários: no REMOTO (onde ainda não existem) e no `db reset --local` (onde a 30000
-- local já cria os mesmos objetos). O schema FINAL é idêntico nos dois casos.
--
-- NÃO usa migration repair, reset remoto, include-all nem edição manual da tabela de
-- migrations. NÃO altera migrations anteriores. NÃO remove as policies de Storage
-- por-pasta-de-usuário (Estoque e o editor de Orçamentos ainda dependem delas).
-- =====================================================================

-- ---------------------------------------------------------------------
-- BLOQUEADOR 2 — IMUTABILIDADE de company_id e owner_id (trigger BEFORE UPDATE).
-- Uma policy de UPDATE não impede um membro de A+B mover o template para B nem um
-- admin trocar owner_id por chamada direta. Este trigger rejeita ambas as mudanças.
-- ---------------------------------------------------------------------
create or replace function public.project_templates_lock_tenant()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.company_id is distinct from old.company_id then
    raise exception 'company_id de project_templates é imutável.' using errcode = '42501';
  end if;
  if new.owner_id is distinct from old.owner_id then
    raise exception 'owner_id de project_templates é imutável.' using errcode = '42501';
  end if;
  return new;
end;
$$;

drop trigger if exists project_templates_lock_tenant_biu on public.project_templates;
create trigger project_templates_lock_tenant_biu
  before update on public.project_templates
  for each row execute function public.project_templates_lock_tenant();

-- ---------------------------------------------------------------------
-- BLOQUEADOR 3 — imagem_url = NULL ou PATH no prefixo da PRÓPRIA empresa.
-- Normaliza '' → NULL e proíbe caminho por usuário, de outra empresa ou URL
-- completa. split_part por TEXTO — sem cast do path para uuid. O único template
-- remoto tem imagem_url NULL, então a constraint é compatível com os dados atuais.
-- ---------------------------------------------------------------------
update public.project_templates set imagem_url = null where imagem_url = '';

alter table public.project_templates
  drop constraint if exists project_templates_imagem_url_company;
alter table public.project_templates
  add constraint project_templates_imagem_url_company
  check (imagem_url is null or split_part(imagem_url, '/', 1) = company_id::text);

-- ---------------------------------------------------------------------
-- BLOQUEADOR 4 — Storage: substitui SOMENTE as policies EMPRESARIAIS do bucket
-- project-images. As policies por-pasta-de-usuário (migration 02) são PRESERVADAS
-- porque Estoque (`<user_id>/estoque/...`) e fluxos de Orçamentos ainda as usam.
--
-- storage.objects.owner_id (text) = quem ENVIOU o objeto (definido pelo servidor).
-- SELECT/INSERT: qualquer membro ativo da empresa do 1º segmento do path.
-- UPDATE/DELETE: SÓ o uploader (owner_id = auth.uid) OU owner/admin/manager da
-- empresa — um seller que não enviou NÃO apaga/sobrescreve imagem alheia.
-- Comparação por TEXTO (company_id::text = segmento), sem cast do path para uuid.
-- ---------------------------------------------------------------------
create or replace function public.project_image_is_member(_seg text)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.company_members cm
                  where cm.user_id = auth.uid() and cm.status = 'active'
                    and cm.company_id::text = _seg)
      or exists (select 1 from public.company_profiles cp
                  where cp.user_id = auth.uid() and cp.id::text = _seg);
$$;

create or replace function public.project_image_can_manage(_seg text)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.company_members cm
                  where cm.user_id = auth.uid() and cm.status = 'active'
                    and cm.role in ('owner','admin','manager') and cm.company_id::text = _seg)
      or exists (select 1 from public.company_profiles cp
                  where cp.user_id = auth.uid() and cp.id::text = _seg);
$$;

revoke all on function public.project_image_is_member(text) from public, anon;
grant execute on function public.project_image_is_member(text) to authenticated, service_role;
revoke all on function public.project_image_can_manage(text) from public, anon;
grant execute on function public.project_image_can_manage(text) to authenticated, service_role;

-- Substitui as policies empresariais (nomes iguais aos da 30000 antiga/local).
drop policy if exists "project_images_company_select" on storage.objects;
drop policy if exists "project_images_company_insert" on storage.objects;
drop policy if exists "project_images_company_update" on storage.objects;
drop policy if exists "project_images_company_delete" on storage.objects;

create policy "project_images_company_select" on storage.objects
  for select to authenticated
  using (bucket_id = 'project-images' and public.project_image_is_member(split_part(name, '/', 1)));

create policy "project_images_company_insert" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'project-images' and public.project_image_is_member(split_part(name, '/', 1)));

create policy "project_images_company_update" on storage.objects
  for update to authenticated
  using (bucket_id = 'project-images' and (owner_id = auth.uid()::text or public.project_image_can_manage(split_part(name, '/', 1))))
  with check (bucket_id = 'project-images' and public.project_image_is_member(split_part(name, '/', 1)));

create policy "project_images_company_delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'project-images' and (owner_id = auth.uid()::text or public.project_image_can_manage(split_part(name, '/', 1))));
