-- =====================================================================
-- Orcamentos — item manual sem dimensoes (correcao comprovada do calculo).
--
-- Defeito: `save_quote_with_items` calculava sempre `subtotal = m2 * preco_unit`,
-- com `m2 = largura * altura * quantidade`. Um item MANUAL sem largura/altura
-- (ex.: servico, kit de ferragem, taxa) resultava em `m2 = 0` e portanto
-- `subtotal = 0` e total 0, mesmo com preco informado — impossivel precificar
-- itens sem dimensao. As dimensoes sao "quando aplicaveis".
--
-- Correcao: quando NAO ha dimensoes (largura ou altura = 0), o preco vale por
-- UNIDADE (`quantidade * preco_unit`). Com dimensoes, segue por m² como antes.
-- Nada mais muda: mesma assinatura, mesmas validacoes e seguranca. Substitui a
-- funcao via CREATE OR REPLACE (nao altera a migration anterior nem a tabela).
-- =====================================================================

create or replace function public.save_quote_with_items(
  p_company_id    uuid,
  p_customer_id   uuid,
  p_items         jsonb,
  p_quote_id      uuid                 default null,
  p_status        public.quote_status  default 'rascunho',
  p_observacoes   text                 default null,
  p_desconto      numeric              default 0,
  p_acrescimo     numeric              default 0,
  p_validade_dias integer              default 15
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid   uuid := auth.uid();
  v_qid   uuid := p_quote_id;
  v_desc  numeric := round(coalesce(p_desconto, 0), 2);
  v_acr   numeric := round(coalesce(p_acrescimo, 0), 2);
  v_val   integer := coalesce(p_validade_dias, 15);
  v_sum   numeric := 0;
  v_total numeric;
  v_count integer;
  v_item  jsonb;
  v_idx   integer := 0;
  v_desc_txt text;
  v_larg  numeric;
  v_alt   numeric;
  v_qtd   integer;
  v_preco numeric;
  v_m2    numeric;
  v_sub   numeric;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if p_company_id is null or not public.is_company_member(p_company_id, v_uid) then
    raise exception 'Empresa invalida ou sem permissao.' using errcode = '42501';
  end if;

  if not exists (
    select 1 from public.customers c
    where c.id = p_customer_id and c.company_id = p_company_id
  ) then
    raise exception 'Cliente nao pertence a empresa ativa.' using errcode = '23503';
  end if;

  if p_items is null or jsonb_typeof(p_items) <> 'array' then
    raise exception 'Itens invalidos.' using errcode = '22023';
  end if;
  v_count := jsonb_array_length(p_items);
  if v_count < 1 or v_count > 200 then
    raise exception 'O orcamento deve ter de 1 a 200 itens.' using errcode = '22023';
  end if;

  if v_desc < 0 or v_acr < 0 then
    raise exception 'Desconto e acrescimo nao podem ser negativos.' using errcode = '22023';
  end if;
  if v_val < 0 then v_val := 0; end if;

  if v_qid is not null then
    if not exists (
      select 1 from public.quotes q
      where q.id = v_qid
        and q.company_id = p_company_id
        and (q.owner_id = v_uid or public.is_company_admin(p_company_id, v_uid))
    ) then
      raise exception 'Orcamento nao encontrado ou sem permissao.' using errcode = '42501';
    end if;
  end if;

  if v_qid is null then
    insert into public.quotes
      (owner_id, company_id, customer_id, status, observacoes, desconto, acrescimo, validade_dias, total)
    values
      (v_uid, p_company_id, p_customer_id, p_status,
       nullif(btrim(coalesce(p_observacoes, '')), ''), v_desc, v_acr, v_val, 0)
    returning id into v_qid;
  else
    update public.quotes set
      customer_id   = p_customer_id,
      status        = p_status,
      observacoes   = nullif(btrim(coalesce(p_observacoes, '')), ''),
      desconto      = v_desc,
      acrescimo     = v_acr,
      validade_dias = v_val
    where id = v_qid;
    delete from public.quote_items where quote_id = v_qid;
  end if;

  for v_item in select value from jsonb_array_elements(p_items)
  loop
    v_desc_txt := nullif(btrim(coalesce(v_item->>'descricao', '')), '');
    v_larg  := coalesce((v_item->>'largura')::numeric, 0);
    v_alt   := coalesce((v_item->>'altura')::numeric, 0);
    v_qtd   := coalesce((v_item->>'quantidade')::integer, 0);
    v_preco := coalesce((v_item->>'preco_unit')::numeric, 0);

    if v_desc_txt is null then
      raise exception 'Item % sem descricao.', v_idx + 1 using errcode = '22023';
    end if;
    if v_qtd <= 0 then
      raise exception 'Item % com quantidade invalida.', v_idx + 1 using errcode = '22023';
    end if;
    if v_larg < 0 or v_alt < 0 or v_preco < 0 then
      raise exception 'Item % com valor negativo.', v_idx + 1 using errcode = '22023';
    end if;

    v_m2 := round(v_larg * v_alt * v_qtd, 4);
    -- Sem dimensoes: preco por UNIDADE. Com dimensoes: por m². Permite item manual.
    if v_larg > 0 and v_alt > 0 then
      v_sub := round(v_m2 * v_preco, 2);
    else
      v_sub := round(v_qtd * v_preco, 2);
    end if;
    v_sum := v_sum + v_sub;

    insert into public.quote_items
      (quote_id, company_id, descricao, largura, altura, quantidade, m2, preco_unit, subtotal, ordem)
    values
      (v_qid, p_company_id, v_desc_txt, round(v_larg, 3), round(v_alt, 3),
       v_qtd, v_m2, round(v_preco, 2), v_sub, v_idx);

    v_idx := v_idx + 1;
  end loop;

  v_total := greatest(0, round(v_sum - v_desc + v_acr, 2));
  update public.quotes set total = v_total where id = v_qid;

  return v_qid;
end;
$$;
