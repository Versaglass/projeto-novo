-- =====================================================================
-- 20260831140000_platform_project_catalog.sql
--
-- Revisão 202 — Implementação do design da Revisão 201 (auditoria pré-OK).
--
-- Catálogo GLOBAL de projetos técnicos (foto + metadados), compartilhado
-- entre todas as empresas. Gestão: admin de PLATAFORMA (is_platform_admin).
-- Leitura: qualquer authenticated (ativos; admin vê inativos).
--
-- Premissas (auditoria local 2026-08-31):
--   · tabela platform_project_catalog AUSENTE
--   · bucket platform-catalog AUSENTE
--   · is_platform_admin(uuid), project_area, project_category (7),
--     project_acabamento, project_cor_refletivo, set_updated_at() OK
--   · project_templates INSERT exige is_company_admin (fluxo de cópia ok)
--
-- O que NÃO faz:
--   · não mexe em project_templates / Login / Estoque / Orçamentos
--   · não cria project_data no catálogo (v1 = foto + metadados)
--   · não seeda itens
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. TABELA
-- ---------------------------------------------------------------------
create table public.platform_project_catalog (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  descricao text,
  imagem_url text,
  area public.project_area not null,
  subtipo text not null,
  categoria public.project_category not null,
  acabamento public.project_acabamento,
  cor public.project_cor_refletivo,
  espessura text,
  largura_padrao numeric not null default 1
    constraint platform_project_catalog_largura_padrao_positive check (largura_padrao > 0),
  altura_padrao numeric not null default 1
    constraint platform_project_catalog_altura_padrao_positive check (altura_padrao > 0),
  preco_referencia_m2 numeric not null default 0
    constraint platform_project_catalog_preco_referencia_nonneg check (preco_referencia_m2 >= 0),
  observacoes text,
  ativo boolean not null default true,
  ordem integer not null default 0,
  created_by uuid references auth.users (id) on delete set null,
  updated_by uuid references auth.users (id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint platform_project_catalog_area_subtipo check (
    case area
      when 'vidracaria'  then subtipo in ('box','porta_vidro','janela_vidro','guarda_corpo','espelho','fechamento_vidro','outro_vidracaria')
      when 'serralheria' then subtipo in ('portao','grade','corrimao','estrutura_metalica','cobertura','esquadria_metalica','outro_serralheria')
      when 'marcenaria'  then subtipo in ('armario','porta_madeira','painel','bancada_madeira','movel_planejado','prateleira','outro_marcenaria')
      when 'marmoraria'  then subtipo in ('bancada_pedra','pia','soleira','revestimento','escada','peitoril','outro_marmoraria')
    end
  ),
  constraint platform_project_catalog_acabamento_categoria check (
    acabamento is null
    or categoria::text in ('vidro_comum', 'espelho', 'organico', 'canelado')
  ),
  constraint platform_project_catalog_cor_refletivo check (
    cor is null
    or categoria::text = 'refletivo'
  )
);

comment on table public.platform_project_catalog is
  'Catalogo GLOBAL de projetos tecnicos (foto + metadados). Compartilhado entre empresas. Escrita: is_platform_admin. Leitura: authenticated (ativos; admin ve inativos). Sem company_id.';

comment on column public.platform_project_catalog.imagem_url is
  'PATH no bucket storage platform-catalog (ex.: catalog/<uuid>.jpg). Nao e URL publica.';

comment on column public.platform_project_catalog.preco_referencia_m2 is
  'Sugestao de preco m2 da plataforma — nao e preco de tenant. Snapshot ao aplicar/copiar.';

-- ---------------------------------------------------------------------
-- 2. INDICES + updated_at
-- ---------------------------------------------------------------------
create index idx_platform_project_catalog_ativo_area_subtipo
  on public.platform_project_catalog (ativo, area, subtipo);

create index idx_platform_project_catalog_ativo_categoria
  on public.platform_project_catalog (ativo, categoria);

create trigger platform_project_catalog_updated_at
  before update on public.platform_project_catalog
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------
-- 3. RLS
-- ---------------------------------------------------------------------
alter table public.platform_project_catalog enable row level security;

create policy "platform_project_catalog_select"
  on public.platform_project_catalog
  for select to authenticated
  using (
    ativo = true
    or public.is_platform_admin(auth.uid())
  );

create policy "platform_project_catalog_insert"
  on public.platform_project_catalog
  for insert to authenticated
  with check (public.is_platform_admin(auth.uid()));

create policy "platform_project_catalog_update"
  on public.platform_project_catalog
  for update to authenticated
  using (public.is_platform_admin(auth.uid()))
  with check (public.is_platform_admin(auth.uid()));

create policy "platform_project_catalog_delete"
  on public.platform_project_catalog
  for delete to authenticated
  using (public.is_platform_admin(auth.uid()));

revoke all on table public.platform_project_catalog from public, anon;
grant select, insert, update, delete on table public.platform_project_catalog
  to authenticated, service_role;

-- ---------------------------------------------------------------------
-- 4. STORAGE — bucket platform-catalog (via migration, padrao project-images)
--
-- Bucket PRIVADO. Leitura: qualquer authenticated (signed URL).
-- Escrita/atualizacao/exclusao: so is_platform_admin.
-- Path sugerido: catalog/<uuid>.<ext> (sem company_id).
-- =====================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'platform-catalog',
  'platform-catalog',
  false,
  5242880,
  array['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif']
)
on conflict (id) do nothing;

create policy "platform_catalog_select_authenticated"
  on storage.objects
  for select to authenticated
  using (bucket_id = 'platform-catalog');

create policy "platform_catalog_insert_platform_admin"
  on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'platform-catalog'
    and public.is_platform_admin(auth.uid())
  );

create policy "platform_catalog_update_platform_admin"
  on storage.objects
  for update to authenticated
  using (
    bucket_id = 'platform-catalog'
    and public.is_platform_admin(auth.uid())
  )
  with check (
    bucket_id = 'platform-catalog'
    and public.is_platform_admin(auth.uid())
  );

create policy "platform_catalog_delete_platform_admin"
  on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'platform-catalog'
    and public.is_platform_admin(auth.uid())
  );
