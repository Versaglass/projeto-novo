-- =====================================================================
-- Biblioteca de Projetos Técnicos — criar modelo exige papel de GESTÃO.
--
-- LACUNA COMPROVADA. A policy `project_templates_insert_company` (migration
-- 20260724030000) exigia apenas:
--     owner_id = auth.uid() AND is_company_member(company_id, auth.uid())
-- ou seja, QUALQUER membro ativo podia criar modelo. Na interface o botão
-- "Novo projeto" só aparece para owner/admin/manager, mas um `seller` (ou
-- operator/installer) criava normalmente por chamada direta ao PostgREST —
-- esconder o botão era a única barreira, e esconder botão nunca é segurança.
-- Reproduzido em teste: o INSERT do seller retornava 201.
--
-- Correção: a criação passa a exigir papel EMPRESARIAL de gestão, usando a
-- MESMA função que UPDATE e DELETE já usam. Assinatura real conferida antes de
-- escrever esta migration:
--     public.is_company_admin(_company_id uuid, _user_id uuid default auth.uid())
--     → true para company_members.role in ('owner','admin','manager') com
--       status 'active', OU para o criador da empresa (company_profiles.user_id);
--     → SECURITY DEFINER, search_path travado, e devolve false quando
--       `_user_id` não é o próprio chamador (não dá para consultar por terceiro).
--
-- Escopo: SÓ a policy de INSERT é substituída. SELECT (leitura por membro),
-- UPDATE e DELETE (criador OU gestor) já estão corretos e ficam intactos —
-- seller, operator e installer continuam VENDO os modelos ativos e USANDO-os
-- em orçamentos, que é a permissão pretendida para eles.
--
-- Admin de PLATAFORMA sem membership não ganha nada aqui: `is_company_admin`
-- olha membership e criação da empresa, não `user_roles`. Nenhum USING(true),
-- nenhum WITH CHECK(true), nenhuma migration aplicada é editada, nenhum dado é
-- alterado.
-- =====================================================================

drop policy if exists "project_templates_insert_company" on public.project_templates;

-- CRIAÇÃO: owner_id continua sendo forçado à sessão (ninguém cria em nome de
-- terceiro) e o company_id continua tendo de ser de uma empresa do usuário —
-- agora com papel de gestão nela.
create policy "project_templates_insert_company" on public.project_templates
  for insert to authenticated
  with check (
    owner_id = auth.uid()
    and public.is_company_admin(company_id, auth.uid())
  );

comment on table public.project_templates is
  'Biblioteca de modelos técnicos da empresa. Leitura: qualquer membro ativo. Criação (desde 20260727040000), edição e exclusão: owner/admin/manager da empresa — o criador também edita e exclui o que fez.';
