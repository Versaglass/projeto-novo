-- =====================================================================
-- Dados empresariais no PDF do orçamento: logotipo + leitura por membro.
--
-- Duas mudanças, ambas exigidas pelo cabeçalho empresarial e pela seção de
-- assinaturas do PDF. Auditoria dos campos REAIS de `company_profiles` feita
-- antes desta migration: já existem `company_name` (not null), `cnpj`, `phone`,
-- `email`, `address`, `city`, `state`. Só o logotipo não tinha onde morar.
--
-- Decisão humana (2026-07-27): adicionar SOMENTE `logo_url`. Razão social usa
-- `company_name`; o endereço é montado com `address` + `city`/`state`, que já
-- existem. Nenhuma coluna de razão social/nome fantasia separadas, nenhum
-- número/complemento/bairro/CEP — não foram inventados.
--
-- DADOS REAIS DO REMOTO CONFERIDOS (2026-07-27, leitura por service_role):
--   1 company_profile · company_name "Vidraçaria" · cnpj preenchido ·
--   phone preenchido · email NULL · address NULL · city/state preenchidos.
-- Nenhum dado é alterado por esta migration.
--
-- Nada de RPC, cálculo, quote_items, Estoque ou Projetos é tocado.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Logotipo da empresa.
--
-- Guarda o PATH no bucket privado `project-images` (nunca a URL assinada —
-- URL assinada expira e não se persiste). O caminho é
-- `<company_id>/logo/<uuid>.<ext>`: o 1º segmento continua sendo o company_id,
-- então as 4 policies empresariais de Storage criadas em 20260724040000 já
-- autorizam leitura/upload por membro ativo e UPDATE/DELETE pelo uploader ou
-- por owner/admin/manager. NENHUMA policy de Storage nova é necessária.
-- ---------------------------------------------------------------------
alter table public.company_profiles
  add column if not exists logo_url text;

-- Mesmo endurecimento já aplicado a project_templates e inventory_items: o
-- arquivo tem de viver no prefixo da PRÓPRIA empresa. Proíbe caminho por
-- usuário, de outra empresa ou URL completa. `split_part` por TEXTO, sem cast.
update public.company_profiles set logo_url = null where logo_url = '';

do $$
declare v_fora integer;
begin
  select count(*) into v_fora
    from public.company_profiles
   where logo_url is not null
     and split_part(logo_url, '/', 1) <> id::text;
  if v_fora > 0 then
    raise exception
      'Existem % company_profiles com logo fora do prefixo da empresa. Migre os arquivos antes de aplicar esta migration.',
      v_fora using errcode = '23514';
  end if;
end $$;

alter table public.company_profiles
  add constraint company_profiles_logo_url_prefix
  check (logo_url is null or split_part(logo_url, '/', 1) = id::text);

comment on column public.company_profiles.logo_url is
  'PATH do logotipo no bucket privado project-images, sempre no prefixo <company_id>/logo/. Nunca guarda URL assinada.';

-- ---------------------------------------------------------------------
-- 2. LEITURA da empresa por qualquer membro ativo.
--
-- DEFEITO CORRIGIDO. As policies da baseline só deixam o CRIADOR ler a linha
-- (`company_profiles_select_own`: user_id = auth.uid()). Um seller ou manager
-- que gerasse o PDF não conseguia ler razão social, CNPJ, endereço ou telefone
-- da própria empresa — o cabeçalho empresarial e o bloco CONTRATADO sairiam
-- vazios para todos, menos o dono, e o MESMO orçamento geraria documentos
-- diferentes conforme quem clicasse. É a pendência já registrada em P-16/P-17
-- ("sem RLS de leitura de company_profiles para membros não-criadores").
--
-- Só LEITURA é ampliada. INSERT/UPDATE/DELETE continuam exatamente como estavam
-- (`user_id = auth.uid()`), então nenhum membro passa a editar os dados da
-- empresa. `is_company_member` é SECURITY DEFINER e pertence ao dono da tabela,
-- portanto não reentra na RLS de company_profiles — sem recursão de policy.
-- ---------------------------------------------------------------------
create policy "company_profiles_select_member" on public.company_profiles
  for select to authenticated
  using (public.is_company_member(id, auth.uid()));

comment on table public.company_profiles is
  'Empresa assinante (tenant). Leitura: criador, membro ativo (desde 20260727020000) ou admin de plataforma. Escrita: somente o criador.';
