-- =====================================================================
-- 20260910190000_inventory_adopt_manufacturer_product.sql
--
-- Fase 4B — vínculo de origem (snapshot) do catálogo global → estoque.
-- manufacturer_product_id é proveniência, NÃO sincronização automática.
-- =====================================================================

alter table public.inventory_items
  add column if not exists manufacturer_product_id uuid
    references public.manufacturer_products(id) on delete set null;

comment on column public.inventory_items.manufacturer_product_id is
  'Origem no catálogo global (snapshot na adoção). Sem sincronização automática. ON DELETE SET NULL.';

-- Uma empresa não adota o mesmo produto global duas vezes.
-- Itens manuais (NULL) não entram no índice.
create unique index if not exists inventory_items_company_manufacturer_product_uq
  on public.inventory_items (company_id, manufacturer_product_id)
  where manufacturer_product_id is not null;

create index if not exists inventory_items_manufacturer_product_id_idx
  on public.inventory_items (manufacturer_product_id)
  where manufacturer_product_id is not null;

-- ---------------------------------------------------------------------
-- RPC: adota produto global no estoque da empresa (SECURITY INVOKER + RLS)
-- Revalida produto/fabricante ativos. Não copia Storage.
-- ---------------------------------------------------------------------
create or replace function public.adopt_manufacturer_product_to_inventory(
  p_company_id uuid,
  p_manufacturer_product_id uuid,
  p_nome text,
  p_descricao text,
  p_sku text,
  p_categoria public.inventory_category,
  p_unidade public.inventory_unit,
  p_quantidade numeric,
  p_estoque_minimo numeric,
  p_custo_unit numeric,
  p_preco_venda numeric,
  p_ncm text default null,
  p_observacoes text default null
)
returns uuid
language plpgsql
security invoker
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_prod_id uuid;
  v_mfg_active boolean;
  v_item_id uuid;
  v_nome text := nullif(btrim(coalesce(p_nome, '')), '');
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if p_company_id is null or p_manufacturer_product_id is null then
    raise exception 'Parametros obrigatorios ausentes.' using errcode = '22023';
  end if;

  if v_nome is null then
    raise exception 'Nome obrigatorio.' using errcode = '22023';
  end if;

  if p_categoria is null or p_unidade is null then
    raise exception 'Categoria e unidade obrigatorias.' using errcode = '22023';
  end if;

  if not public.is_company_member(p_company_id, v_uid) then
    raise exception 'Sem permissao nesta empresa.' using errcode = '42501';
  end if;

  -- Produto global ativo (RLS + filtro explícito)
  select mp.id into v_prod_id
  from public.manufacturer_products mp
  where mp.id = p_manufacturer_product_id
    and mp.active = true;

  if v_prod_id is null then
    raise exception 'PRODUTO_INDISPONIVEL' using errcode = 'P0002';
  end if;

  select pm.active into v_mfg_active
  from public.manufacturer_products mp
  join public.product_manufacturers pm on pm.id = mp.manufacturer_id
  where mp.id = p_manufacturer_product_id;

  if v_mfg_active is distinct from true then
    raise exception 'PRODUTO_INDISPONIVEL' using errcode = 'P0002';
  end if;

  begin
    insert into public.inventory_items (
      owner_id,
      company_id,
      categoria,
      nome,
      descricao,
      unidade,
      quantidade,
      estoque_minimo,
      custo_unit,
      preco_venda,
      sku,
      ncm,
      observacoes,
      imagem_url,
      fornecedor,
      supplier_id,
      localizacao,
      ativo,
      originado_de_projeto,
      manufacturer_product_id
    ) values (
      v_uid,
      p_company_id,
      p_categoria,
      v_nome,
      nullif(btrim(coalesce(p_descricao, '')), ''),
      p_unidade,
      greatest(coalesce(p_quantidade, 0), 0),
      greatest(coalesce(p_estoque_minimo, 0), 0),
      greatest(coalesce(p_custo_unit, 0), 0),
      greatest(coalesce(p_preco_venda, 0), 0),
      nullif(btrim(coalesce(p_sku, '')), ''),
      nullif(btrim(coalesce(p_ncm, '')), ''),
      nullif(btrim(coalesce(p_observacoes, '')), ''),
      null, -- sem cópia de imagem global
      null, -- fabricante ≠ fornecedor
      null,
      null,
      true,
      false,
      p_manufacturer_product_id
    )
    returning id into v_item_id;
  exception
    when unique_violation then
      raise exception 'JA_ADOTADO' using errcode = '23505';
  end;

  return v_item_id;
end;
$$;

revoke all on function public.adopt_manufacturer_product_to_inventory(
  uuid, uuid, text, text, text, public.inventory_category, public.inventory_unit,
  numeric, numeric, numeric, numeric, text, text
) from public, anon;

grant execute on function public.adopt_manufacturer_product_to_inventory(
  uuid, uuid, text, text, text, public.inventory_category, public.inventory_unit,
  numeric, numeric, numeric, numeric, text, text
) to authenticated;

comment on function public.adopt_manufacturer_product_to_inventory is
  'Adota manufacturer_product no inventory_items da empresa (snapshot). Sem sync, sem cópia Storage.';
