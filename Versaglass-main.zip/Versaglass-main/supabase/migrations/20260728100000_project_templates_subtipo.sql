-- =====================================================================
-- 20260728100000_project_templates_subtipo.sql
--
-- SUBTIPO do modelo técnico — o "Tipo de projeto" DENTRO da área.
--
-- PROBLEMA QUE ORIGINA ESTA MIGRATION
--   Desde 20260727090000 o modelo tem `area` (vidracaria/serralheria/
--   marcenaria/marmoraria). Falta o degrau seguinte: DENTRO da vidraçaria um
--   box não é uma janela, dentro da serralheria um portão não é um corrimão. O
--   único campo que carregava isso era `tipo` — TEXT LIVRE, digitado à mão
--   ("Box", "box correr", "BOX 2 FLS"), que não filtra, não agrupa e não pode
--   ser validado. E `categoria` (`public.project_category`) descreve o MATERIAL
--   do vidro, não o produto.
--
--   Sem subtipo, a biblioteca só sabe separar quatro gavetas e a única forma de
--   achar "todos os guarda-corpos" é procurar substring em texto livre — que é
--   exatamente o defeito que 20260727090000 removeu do filtro de área.
--
-- O QUE ESTA MIGRATION FAZ
--   1. adiciona `project_templates.subtipo text` (NULL só durante o backfill);
--   2. classifica o acervo existente — regra INEQUÍVOCA ou `outro_<area>`;
--   3. torna `subtipo` NOT NULL;
--   4. amarra o par (area, subtipo) por CHECK: 7 subtipos por área, e nenhum
--      subtipo de uma área é aceito em outra.
--
-- O QUE ESTA MIGRATION NÃO FAZ
--   · não altera nem remove `categoria` (nem o enum `public.project_category`);
--   · não altera `tipo`, `nome`, `preco_m2`, `largura_padrao`, `altura_padrao`
--     nem `project_data` — o desenho não é tocado por esta migration;
--   · não mexe em RLS, policies, triggers, `quotes` ou `quote_items`;
--   · não cria coluna em `quote_items` (o orçamento é autossuficiente).
--
-- POR QUE `text` + CHECK E NÃO UM ENUM
--   A regra a proteger não é "o valor pertence a uma lista" — é "o valor
--   pertence à lista DAQUELA ÁREA". Um enum de 28 valores garantiria o primeiro
--   e não o segundo: `portao` continuaria aceito em `marcenaria`. O CHECK
--   condicionado por `area` é o que torna a combinação inválida inalcançável, e
--   é ele que faz o trabalho. Continua não havendo texto livre: fora dos 28
--   pares abaixo, nada entra.
--
-- AUDITORIA DE DADOS (service_role, SOMENTE contagens, 2026-07-28)
--   remoto: 2 project_templates · vidracaria 2 · serralheria 0 · marcenaria 0 ·
--           marmoraria 0 · com project_data 0
--   vidraçaria cujo nome/tipo casa "box" 0 · "espelho" 0 · "porta de vidro" 0
--   Ou seja: as duas linhas caem na regra de segurança e recebem
--   `outro_vidracaria`. Nenhuma é classificada por adivinhação — não há o que
--   adivinhar. As regras determinísticas do passo 2 existem para a próxima base
--   (um dump com acervo real), não para a de hoje.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 1. COLUNA (nascendo anulável — vira NOT NULL no passo 3)
-- ---------------------------------------------------------------------
alter table public.project_templates
  add column if not exists subtipo text;

comment on column public.project_templates.subtipo is
  'Tipo de projeto DENTRO da area (7 opcoes por area). Obrigatorio. O par (area, subtipo) e validado por project_templates_area_subtipo. NAO confundir com "tipo" (texto livre legado) nem com "categoria" (material do vidro).';


-- ---------------------------------------------------------------------
-- 2. BACKFILL
--
-- Duas passagens, nesta ordem, e nenhuma delas escreve em `nome`, `tipo`,
-- `categoria`, medidas, preço ou `project_data`.
--
-- 2.1 CLASSIFICAÇÃO INEQUÍVOCA — só vidraçaria, só três produtos.
--
--     `nome` e `tipo` são texto livre digitado por gente. Casar substring neles
--     é o método que 20260727090000 rejeitou para deduzir ÁREA, e com razão:
--     "Portão de vidro" tem "vidro" e não é vidraçaria. Aqui o risco é
--     radicalmente menor e por um motivo concreto: a ÁREA JÁ ESTÁ DECIDIDA. O
--     recorte é `area = 'vidracaria'`, então "box" não pode significar caixa de
--     marcenaria e "espelho" não pode ser um espelho d'água de marmoraria.
--
--     Ainda assim, três travas:
--       a) casamento por PALAVRA INTEIRA (`[[:alnum:]]` como fronteira), não por
--          substring — senão "Boxe", "Caixote" ou "Portaria" casariam;
--       b) mais de uma regra casando ao mesmo tempo ("Box com espelho") NÃO é
--          inequívoco: cai em `outro_vidracaria`;
--       c) qualquer outra coisa cai em `outro_vidracaria`.
--
--     O usuário reclassifica em dois cliques pelo formulário. O contrário —
--     descobrir que o sistema decidiu sozinho que um fechamento é um box — não
--     tem conserto barato, porque ninguém vai auditar o que "já veio certo".
-- ---------------------------------------------------------------------
with candidatos as (
  select id,
         coalesce(nome, '') || ' ' || coalesce(tipo, '') as texto
    from public.project_templates
   where subtipo is null
     and area = 'vidracaria'::public.project_area
),
marcado as (
  select id,
         (texto ~* '(^|[^[:alnum:]])box([^[:alnum:]]|$)')                                   as eh_box,
         (texto ~* '(^|[^[:alnum:]])espelhos?([^[:alnum:]]|$)')                              as eh_espelho,
         (texto ~* '(^|[^[:alnum:]])portas?[[:space:]]+de[[:space:]]+vidro([^[:alnum:]]|$)') as eh_porta_vidro
    from candidatos
)
update public.project_templates t
   set subtipo = case
                   -- zero regras (nada reconhecido) ou duas/três (contraditório):
                   -- nos dois casos NÃO dá para determinar com segurança.
                   when m.eh_box::int + m.eh_espelho::int + m.eh_porta_vidro::int <> 1
                     then 'outro_vidracaria'
                   when m.eh_box         then 'box'
                   when m.eh_espelho     then 'espelho'
                   else                       'porta_vidro'
                 end
  from marcado m
 where t.id = m.id;

-- 2.2 RESTO → `outro_<area>`.
--
--     Serralheria, marcenaria e marmoraria não recebem regra de texto nenhuma,
--     de propósito: não há acervo auditado nessas áreas (contagens acima) e
--     inventar heurística para dado que não existe é escrever código que
--     ninguém pode testar. Os quatro identificadores `outro_*` foram nomeados
--     justamente para que esta linha seja `'outro_' || area`, sem tabela de-para.
update public.project_templates
   set subtipo = 'outro_' || area::text
 where subtipo is null;


-- ---------------------------------------------------------------------
-- 3. OBRIGATÓRIO
--
-- O guarda antes do NOT NULL é redundante por construção (o passo 2.2 varre
-- tudo o que sobrou) — mas se um dia alguém editar o backfill e quebrar a
-- cobertura, a mensagem diz QUANTAS linhas ficaram de fora, em vez de o
-- Postgres devolver "column contains null values" sem contexto. Nenhum id,
-- nome ou empresa é exposto.
-- ---------------------------------------------------------------------
do $$
declare v_sem_subtipo integer;
begin
  select count(*) into v_sem_subtipo from public.project_templates where subtipo is null;
  if v_sem_subtipo > 0 then
    raise exception
      'Backfill incompleto: % project_templates sem subtipo. Verifique o passo 2 desta migration antes de reaplicar.',
      v_sem_subtipo using errcode = '23502';
  end if;
end $$;

alter table public.project_templates
  alter column subtipo set not null;


-- ---------------------------------------------------------------------
-- 4. O PAR (area, subtipo) — a constraint que faz o trabalho
--
-- 7 subtipos por área, 28 pares, e nada além disso. Um `portao` em
-- `marcenaria`, um `box` em `marmoraria` ou um `armario` em `vidracaria` são
-- recusados pelo BANCO, em qualquer caminho de escrita — formulário, chamada
-- direta ao PostgREST, importação, SQL manual. O front-end monta o `<select>` a
-- partir da mesma tabela (`src/lib/project-subtypes.ts`), mas quem garante é
-- esta linha, não a tela.
--
-- `case area ... end` é exaustivo porque `area` é NOT NULL e o enum tem
-- exatamente quatro valores; não há ramo `else` a alcançar. Se um quinto valor
-- for algum dia adicionado ao enum, o CASE devolve NULL, o CHECK não é
-- satisfeito e o INSERT falha — o que é o comportamento desejado: uma área nova
-- sem lista de subtipos não deve aceitar subtipo nenhum em silêncio.
--
-- A validação prévia repete a checagem ANTES de criar a constraint. Depois do
-- passo 2 ela não pode falhar (todo valor gravado saiu de `outro_<area>` ou das
-- três regras de vidraçaria), mas ela cobre a base que já tivesse `subtipo`
-- preenchido por outro caminho antes desta migration rodar.
-- ---------------------------------------------------------------------
do $$
declare v_invalidos integer;
begin
  select count(*) into v_invalidos
    from public.project_templates
   where subtipo is not null
     and not (subtipo = any (case area
         when 'vidracaria'  then array['box','porta_vidro','janela_vidro','guarda_corpo','espelho','fechamento_vidro','outro_vidracaria']
         when 'serralheria' then array['portao','grade','corrimao','estrutura_metalica','cobertura','esquadria_metalica','outro_serralheria']
         when 'marcenaria'  then array['armario','porta_madeira','painel','bancada_madeira','movel_planejado','prateleira','outro_marcenaria']
         when 'marmoraria'  then array['bancada_pedra','pia','soleira','revestimento','escada','peitoril','outro_marmoraria']
       end));
  if v_invalidos > 0 then
    raise exception
      'Existem % project_templates cujo subtipo nao pertence a propria area. Corrija a combinacao antes de aplicar esta migration.',
      v_invalidos using errcode = '23514';
  end if;
end $$;

alter table public.project_templates
  drop constraint if exists project_templates_area_subtipo;

alter table public.project_templates
  add constraint project_templates_area_subtipo check (
    case area
      when 'vidracaria'  then subtipo in ('box','porta_vidro','janela_vidro','guarda_corpo','espelho','fechamento_vidro','outro_vidracaria')
      when 'serralheria' then subtipo in ('portao','grade','corrimao','estrutura_metalica','cobertura','esquadria_metalica','outro_serralheria')
      when 'marcenaria'  then subtipo in ('armario','porta_madeira','painel','bancada_madeira','movel_planejado','prateleira','outro_marcenaria')
      when 'marmoraria'  then subtipo in ('bancada_pedra','pia','soleira','revestimento','escada','peitoril','outro_marmoraria')
    end
  );


-- ---------------------------------------------------------------------
-- 5. ÍNDICE DO FILTRO "TIPO DE PROJETO"
--
-- O filtro de subtipo da biblioteca só existe DEPOIS de uma área ser escolhida
-- (decisão de interface), então a consulta é sempre
-- `where company_id = ? and area = ? and subtipo = ? [and ativo = true]` — um
-- prefixo do índice existente `idx_project_templates_company_area_ativo`
-- (company_id, area, ativo) mais uma coluna. Estender o índice para
-- (company_id, area, subtipo, ativo) atenderia os dois filtros com um objeto só,
-- mas trocaria a posição de `ativo`, que hoje serve o recorte "Todos".
--
-- Nada é criado aqui de propósito: com o acervo auditado (2 linhas) e o recorte
-- por empresa já aplicado, um índice a mais custa manutenção em toda escrita
-- para poupar um filtro sobre um punhado de linhas. Quando uma empresa passar
-- de alguns milhares de modelos, o índice certo é
-- (company_id, area, subtipo, ativo) — e aí ele substitui o atual, em vez de
-- conviver com ele.
-- ---------------------------------------------------------------------
