-- =====================================================================
-- 20260722000000_auth_user_provisioning.sql
--
-- OBJETIVO
--   Ativar o provisionamento automático de novos usuários, que a baseline
--   20260721000000 deixou pronto porém DESLIGADO na §16.1 ("revisão manual
--   antes de ativar"). Esta migration faz essa revisão e liga o gatilho.
--
-- ESTADO ANTES DESTA MIGRATION
--   · public.handle_new_user() existe desde a baseline (§8);
--   · nenhum trigger em auth.users — a função nunca era executada;
--   · cadastro criava apenas a linha em auth.users;
--   · profiles e user_roles permaneciam vazios;
--   · o frontend assumia "vendedor" como fallback NÃO persistido.
--
-- O QUE ESTA MIGRATION FAZ
--   1. Substitui public.handle_new_user() por uma versão endurecida.
--   2. Cria o trigger on_auth_user_created em auth.users.
--
-- O QUE ESTA MIGRATION NÃO FAZ
--   · não cria company_members — vínculo com empresa é decisão de onboarding,
--     nunca consequência de um cadastro;
--   · não define company_id em lugar algum;
--   · não cria, promove nem insinua papel administrativo;
--   · não altera policies, RLS, grants de tabela ou auth.users;
--   · não concede INSERT em user_roles a authenticated — a escrita continua
--     restrita ao admin da plataforma, conforme comment on table user_roles.
--
-- PAPEL PADRÃO
--   Todo usuário novo recebe EXATAMENTE 'vendedor'::public.app_role.
--   O enum public.app_role é ('admin', 'vendedor', 'instalador'); não existe
--   'super_admin'. Promoção a 'admin' é operação manual e única, descrita em
--   docs/BOOTSTRAP_ADMIN_SUPABASE.md. A lógica "primeiro usuário vira admin"
--   permanece REMOVIDA — era janela de sequestro em banco vazio.
--
-- METADATA NÃO É FONTE DE PRIVILÉGIO
--   raw_user_meta_data é controlado pelo cliente: qualquer pessoa pode enviar
--   {"role":"admin","is_admin":true,"company_id":"..."} no signUp. Por isso a
--   função lê SOMENTE campos cosméticos — nome, empresa e segment — e ignora
--   silenciosamente qualquer outra chave. Papel, empresa, permissões e o flag
--   `ativo` nunca vêm do cliente: são constantes ou defaults de coluna.
--   raw_app_meta_data também não é consultado.
--
-- ATOMICIDADE
--   O trigger é AFTER INSERT ... FOR EACH ROW, executado dentro da MESMA
--   transação do INSERT em auth.users feito pelo GoTrue. Se qualquer um dos
--   dois INSERTs falhar, a exceção propaga, a transação inteira é revertida e
--   o usuário NÃO é criado. Não existe estado intermediário possível:
--   ou há (auth.users + profile + role), ou não há nada. Por isso a função não
--   tem bloco EXCEPTION — engolir o erro é justamente o que criaria o
--   provisionamento parcial que se quer evitar.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 1. Função de provisionamento
--
-- SECURITY DEFINER é necessário: o INSERT em auth.users é executado por
-- supabase_auth_admin, que não possui privilégio sobre public.profiles nem
-- public.user_roles. A função pertence a postgres (dono de ambas as tabelas),
-- então roda com os privilégios necessários e sem esbarrar em RLS.
--
-- `set search_path = ''` evita sequestro de resolução de nomes por objetos
-- criados em schemas sob controle de terceiros; todas as referências abaixo
-- são qualificadas com schema.
-- ---------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_nome    text;
  v_empresa text;
  v_segment text;
begin
  -- Campos cosméticos. Ausentes ou vazios viram NULL; o nome cai para a parte
  -- local do e-mail apenas como rótulo de exibição.
  v_nome := nullif(btrim(coalesce(
    new.raw_user_meta_data ->> 'nome',
    new.raw_user_meta_data ->> 'full_name',
    split_part(coalesce(new.email, ''), '@', 1)
  )), '');

  -- `empresa` é rótulo textual livre em profiles. NÃO é vínculo societário:
  -- o vínculo real mora em public.company_members e não é criado aqui.
  v_empresa := nullif(btrim(coalesce(new.raw_user_meta_data ->> 'empresa', '')), '');

  -- `segment` é validado contra a MESMA lista de profiles_segment_check.
  -- Um valor fora da lista faria o INSERT violar a constraint e derrubar o
  -- signup inteiro; preferimos degradar para 'complete' a negar o cadastro.
  v_segment := coalesce(nullif(new.raw_user_meta_data ->> 'segment', ''), 'complete');
  if v_segment not in ('glass', 'steel', 'woodworking', 'stone', 'complete') then
    v_segment := 'complete';
  end if;

  -- profiles.permissions e profiles.ativo NÃO são informados de propósito:
  -- assumem o default da coluna. Aceitá-los do cliente seria escalada de
  -- privilégio direta.
  insert into public.profiles (id, nome, empresa, segment)
  values (new.id, left(v_nome, 120), left(v_empresa, 120), v_segment)
  on conflict (id) do nothing;  -- idempotente via profiles_pkey

  -- Papel padrão, literal e constante. Nunca derivado de entrada do cliente.
  insert into public.user_roles (user_id, role)
  values (new.id, 'vendedor'::public.app_role)
  on conflict (user_id, role) do nothing;  -- idempotente via user_roles_user_id_role_key

  return new;
end;
$$;


-- ---------------------------------------------------------------------
-- 2. Privilégios da função
--
-- Regra da baseline §15/P-22: o projeto Supabase tem ALTER DEFAULT PRIVILEGES
-- concedendo a `anon`, então todo objeto criado ou substituído em public deve
-- repetir o revoke. Nenhum cliente precisa executar esta função diretamente —
-- ela só é chamada pelo trigger, e o privilégio de trigger é verificado na
-- criação, não a cada disparo.
-- ---------------------------------------------------------------------
revoke all on function public.handle_new_user() from public, anon, authenticated;

comment on function public.handle_new_user() is
  'Provisiona profile + papel vendedor no signup. Papel é constante literal; metadata do cliente só alimenta nome/empresa/segment. Nunca cria company_members nem papel admin. Atômica com o INSERT em auth.users.';


-- ---------------------------------------------------------------------
-- 3. Trigger em auth.users
--
-- Remoção explícita antes de criar: `create trigger if not exists` não existe
-- no PostgreSQL, e um trigger homônimo remanescente de qualquer tentativa
-- anterior precisa sair antes, para não haver dois gatilhos com o mesmo fim.
-- ---------------------------------------------------------------------
drop trigger if exists on_auth_user_created on auth.users;

-- NOTA: não há `comment on trigger` aqui de propósito. auth.users pertence a
-- supabase_auth_admin e COMMENT exige ser dono da relação — o papel das
-- migrations (postgres) tem privilégio de TRIGGER, mas não é dono, então o
-- COMMENT falharia com "must be owner of relation users" (42501). A descrição
-- do gatilho fica neste comentário e no comment da função.
create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();
