-- =====================================================================
-- 20260909200000_project_templates_delete_owner_only.sql
--
-- DELETE em project_templates: somente o autor (owner_id = auth.uid()).
-- Owner/admin/manager da empresa NÃO podem mais excluir templates de outros.
--
-- SELECT / INSERT / UPDATE inalterados.
-- Sem alteração de schema de colunas.
-- =====================================================================

drop policy if exists "project_templates_delete_company" on public.project_templates;

-- EXCLUSÃO: somente o criador (owner_id). Sem is_company_admin.
create policy "project_templates_delete_company" on public.project_templates
  for delete to authenticated
  using (owner_id = auth.uid());
