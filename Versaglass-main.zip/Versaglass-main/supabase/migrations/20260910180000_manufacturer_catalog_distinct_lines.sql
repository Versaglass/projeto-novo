-- =====================================================================
-- 20260910180000_manufacturer_catalog_distinct_lines.sql
--
-- Fase 4A hardening — DISTINCT product_line para filtro do catálogo.
-- SECURITY INVOKER: RLS do caller; somente linhas de produtos/fabricantes ativos.
-- =====================================================================

create or replace function public.list_manufacturer_product_lines(
  p_manufacturer_id uuid default null
)
returns table (product_line text)
language sql
stable
security invoker
set search_path = ''
as $$
  select distinct btrim(mp.product_line) as product_line
  from public.manufacturer_products mp
  inner join public.product_manufacturers pm
    on pm.id = mp.manufacturer_id
  where mp.active = true
    and pm.active = true
    and mp.product_line is not null
    and btrim(mp.product_line) <> ''
    and (
      p_manufacturer_id is null
      or mp.manufacturer_id = p_manufacturer_id
    )
  order by 1;
$$;

revoke all on function public.list_manufacturer_product_lines(uuid) from public, anon;
grant execute on function public.list_manufacturer_product_lines(uuid) to authenticated;

comment on function public.list_manufacturer_product_lines is
  'Linhas distintas do catálogo ativo (SECURITY INVOKER + filtros active). Sem amostragem.';
