-- =====================================================================
-- 20260911130000_save_manufacturer_product_inventory.sql
--
-- Hardening overlay Estoque:
-- 1) save_* — primeira materialização ATÔMICA com dados do formulário
--    (sem INSERT parcial + UPDATE posterior).
-- 2) ensure_* — sem fallback arbitrário outros/un; exige categoria/unidade
--    explícitas ou herdadas do manufacturer_product.
-- NÃO altera 20260911120000 (já aplicada).
-- =====================================================================

-- ---------------------------------------------------------------------
-- save: materializa com snapshot completo do formulário.
-- Em corrida (unique): devolve o id existente SEM sobrescrever (created=false).
-- ---------------------------------------------------------------------
create or replace function public.save_manufacturer_product_inventory_item(
  p_company_id uuid,
  p_manufacturer_product_id uuid,
  p_nome text,
  p_categoria public.inventory_category,
  p_unidade public.inventory_unit,
  p_quantidade numeric,
  p_estoque_minimo numeric,
  p_custo_unit numeric,
  p_preco_venda numeric,
  p_descricao text default null,
  p_sku text default null,
  p_ncm text default null,
  p_observacoes text default null,
  p_fornecedor text default null,
  p_supplier_id uuid default null,
  p_localizacao text default null,
  p_imagem_url text default null,
  p_ativo boolean default true
)
returns table (inventory_item_id uuid, created boolean)
language plpgsql
security invoker
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_prod public.manufacturer_products%rowtype;
  v_mfg_active boolean;
  v_item_id uuid;
  v_nome text := nullif(btrim(coalesce(p_nome, '')), '');
  v_descricao text := nullif(btrim(coalesce(p_descricao, '')), '');
  v_sku text := nullif(btrim(coalesce(p_sku, '')), '');
  v_ncm text := nullif(btrim(coalesce(p_ncm, '')), '');
  v_observacoes text := nullif(btrim(coalesce(p_observacoes, '')), '');
  v_fornecedor text := nullif(btrim(coalesce(p_fornecedor, '')), '');
  v_localizacao text := nullif(btrim(coalesce(p_localizacao, '')), '');
  v_imagem_url text := nullif(btrim(coalesce(p_imagem_url, '')), '');
  v_ativo boolean := coalesce(p_ativo, true);
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if p_company_id is null or p_manufacturer_product_id is null then
    raise exception 'Parametros obrigatorios ausentes.' using errcode = '22023';
  end if;

  if not public.is_company_member(p_company_id, v_uid) then
    raise exception 'Sem permissao nesta empresa.' using errcode = '42501';
  end if;

  if not public.can_manage_company_estoque(p_company_id, v_uid) then
    raise exception 'Sem permissao de estoque nesta empresa.' using errcode = '42501';
  end if;

  if v_nome is null then
    raise exception 'Nome obrigatorio.' using errcode = '22023';
  end if;
  if char_length(v_nome) > 120 then
    raise exception 'Nome excede o limite.' using errcode = '22023';
  end if;

  if p_categoria is null then
    raise exception 'Categoria obrigatoria.' using errcode = '22023';
  end if;

  if p_unidade is null then
    raise exception 'Unidade obrigatoria.' using errcode = '22023';
  end if;

  if v_descricao is not null and char_length(v_descricao) > 255 then
    raise exception 'Descricao excede o limite.' using errcode = '22023';
  end if;
  if v_sku is not null and char_length(v_sku) > 64 then
    raise exception 'SKU excede o limite.' using errcode = '22023';
  end if;
  if v_ncm is not null and char_length(v_ncm) > 20 then
    raise exception 'NCM excede o limite.' using errcode = '22023';
  end if;
  if v_observacoes is not null and char_length(v_observacoes) > 1000 then
    raise exception 'Observacoes excedem o limite.' using errcode = '22023';
  end if;
  if v_fornecedor is not null and char_length(v_fornecedor) > 120 then
    raise exception 'Fornecedor excede o limite.' using errcode = '22023';
  end if;
  if v_localizacao is not null and char_length(v_localizacao) > 120 then
    raise exception 'Localizacao excede o limite.' using errcode = '22023';
  end if;

  if v_imagem_url is not null and (
    v_imagem_url like 'manufacturer-catalog/%'
    or v_imagem_url like '%/manufacturer-catalog/%'
  ) then
    v_imagem_url := null;
  end if;
  if v_imagem_url is not null and char_length(v_imagem_url) > 500 then
    raise exception 'Imagem excede o limite.' using errcode = '22023';
  end if;

  if p_quantidade is null or p_estoque_minimo is null
     or p_custo_unit is null or p_preco_venda is null
     or p_quantidade < 0 or p_estoque_minimo < 0
     or p_custo_unit < 0 or p_preco_venda < 0 then
    raise exception 'Valores comerciais invalidos.' using errcode = '23514';
  end if;

  -- Já materializado: NÃO sobrescreve (corrida / segunda tentativa).
  select ii.id into v_item_id
  from public.inventory_items ii
  where ii.company_id = p_company_id
    and ii.manufacturer_product_id = p_manufacturer_product_id
  limit 1;

  if v_item_id is not null then
    inventory_item_id := v_item_id;
    created := false;
    return next;
    return;
  end if;

  select mp.* into v_prod
  from public.manufacturer_products mp
  where mp.id = p_manufacturer_product_id
    and mp.active = true;

  if not found then
    raise exception 'PRODUTO_INDISPONIVEL' using errcode = 'P0002';
  end if;

  select pm.active into v_mfg_active
  from public.product_manufacturers pm
  where pm.id = v_prod.manufacturer_id;

  if v_mfg_active is distinct from true then
    raise exception 'PRODUTO_INDISPONIVEL' using errcode = 'P0002';
  end if;

  begin
    insert into public.inventory_items (
      owner_id,
      company_id,
      categoria,
      nome,
      descricao,
      unidade,
      quantidade,
      estoque_minimo,
      custo_unit,
      preco_venda,
      sku,
      ncm,
      observacoes,
      imagem_url,
      fornecedor,
      supplier_id,
      localizacao,
      ativo,
      originado_de_projeto,
      manufacturer_product_id
    ) values (
      v_uid,
      p_company_id,
      p_categoria,
      v_nome,
      v_descricao,
      p_unidade,
      p_quantidade,
      p_estoque_minimo,
      p_custo_unit,
      p_preco_venda,
      v_sku,
      v_ncm,
      v_observacoes,
      v_imagem_url,
      v_fornecedor,
      p_supplier_id,
      v_localizacao,
      v_ativo,
      false,
      p_manufacturer_product_id
    )
    returning id into v_item_id;

    inventory_item_id := v_item_id;
    created := true;
    return next;
    return;
  exception
    when unique_violation then
      -- Corrida: vencedor mantém seus dados; perdedor não sobrescreve.
      select ii.id into v_item_id
      from public.inventory_items ii
      where ii.company_id = p_company_id
        and ii.manufacturer_product_id = p_manufacturer_product_id
      limit 1;
      if v_item_id is null then
        raise;
      end if;
      inventory_item_id := v_item_id;
      created := false;
      return next;
      return;
  end;
end;
$$;

revoke all on function public.save_manufacturer_product_inventory_item(
  uuid, uuid, text, public.inventory_category, public.inventory_unit,
  numeric, numeric, numeric, numeric, text, text, text, text, text, uuid, text, text, boolean
) from public, anon;

grant execute on function public.save_manufacturer_product_inventory_item(
  uuid, uuid, text, public.inventory_category, public.inventory_unit,
  numeric, numeric, numeric, numeric, text, text, text, text, text, uuid, text, text, boolean
) to authenticated;

comment on function public.save_manufacturer_product_inventory_item is
  'Materializa manufacturer_product com dados do formulario (atomico). Race: created=false sem overwrite.';

-- ---------------------------------------------------------------------
-- ensure: remove fallback arbitrario outros/un.
-- Categoria/unidade: parametro OU valor do global; se ambos ausentes → erro.
-- ---------------------------------------------------------------------
create or replace function public.ensure_manufacturer_product_inventory_item(
  p_company_id uuid,
  p_manufacturer_product_id uuid,
  p_nome text default null,
  p_descricao text default null,
  p_sku text default null,
  p_categoria public.inventory_category default null,
  p_unidade public.inventory_unit default null,
  p_quantidade numeric default null,
  p_estoque_minimo numeric default null,
  p_custo_unit numeric default null,
  p_preco_venda numeric default null,
  p_ncm text default null,
  p_observacoes text default null,
  p_fornecedor text default null,
  p_supplier_id uuid default null,
  p_localizacao text default null,
  p_imagem_url text default null,
  p_ativo boolean default true
)
returns uuid
language plpgsql
security invoker
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_prod public.manufacturer_products%rowtype;
  v_mfg_active boolean;
  v_item_id uuid;
  v_nome text;
  v_descricao text;
  v_sku text;
  v_ncm text;
  v_observacoes text;
  v_fornecedor text;
  v_localizacao text;
  v_imagem_url text;
  v_categoria public.inventory_category;
  v_unidade public.inventory_unit;
  v_quantidade numeric;
  v_estoque_minimo numeric;
  v_custo_unit numeric;
  v_preco_venda numeric;
  v_ativo boolean;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if p_company_id is null or p_manufacturer_product_id is null then
    raise exception 'Parametros obrigatorios ausentes.' using errcode = '22023';
  end if;

  if not public.is_company_member(p_company_id, v_uid) then
    raise exception 'Sem permissao nesta empresa.' using errcode = '42501';
  end if;

  if not public.can_manage_company_estoque(p_company_id, v_uid) then
    raise exception 'Sem permissao de estoque nesta empresa.' using errcode = '42501';
  end if;

  select ii.id into v_item_id
  from public.inventory_items ii
  where ii.company_id = p_company_id
    and ii.manufacturer_product_id = p_manufacturer_product_id
  limit 1;

  if v_item_id is not null then
    return v_item_id;
  end if;

  select mp.* into v_prod
  from public.manufacturer_products mp
  where mp.id = p_manufacturer_product_id
    and mp.active = true;

  if not found then
    raise exception 'PRODUTO_INDISPONIVEL' using errcode = 'P0002';
  end if;

  select pm.active into v_mfg_active
  from public.product_manufacturers pm
  where pm.id = v_prod.manufacturer_id;

  if v_mfg_active is distinct from true then
    raise exception 'PRODUTO_INDISPONIVEL' using errcode = 'P0002';
  end if;

  v_nome := nullif(btrim(coalesce(p_nome, v_prod.name, '')), '');
  if v_nome is null then
    raise exception 'Nome obrigatorio.' using errcode = '22023';
  end if;
  if char_length(v_nome) > 120 then
    raise exception 'Nome excede o limite.' using errcode = '22023';
  end if;

  v_descricao := nullif(btrim(coalesce(p_descricao, v_prod.description, '')), '');
  if v_descricao is not null and char_length(v_descricao) > 255 then
    raise exception 'Descricao excede o limite.' using errcode = '22023';
  end if;

  v_sku := nullif(btrim(coalesce(p_sku, v_prod.source_code, '')), '');
  if v_sku is not null and char_length(v_sku) > 64 then
    raise exception 'SKU excede o limite.' using errcode = '22023';
  end if;

  v_ncm := nullif(btrim(coalesce(p_ncm, '')), '');
  if v_ncm is not null and char_length(v_ncm) > 20 then
    raise exception 'NCM excede o limite.' using errcode = '22023';
  end if;

  v_observacoes := nullif(btrim(coalesce(p_observacoes, '')), '');
  if v_observacoes is not null and char_length(v_observacoes) > 1000 then
    raise exception 'Observacoes excedem o limite.' using errcode = '22023';
  end if;

  v_fornecedor := nullif(btrim(coalesce(p_fornecedor, '')), '');
  if v_fornecedor is not null and char_length(v_fornecedor) > 120 then
    raise exception 'Fornecedor excede o limite.' using errcode = '22023';
  end if;

  v_localizacao := nullif(btrim(coalesce(p_localizacao, '')), '');
  if v_localizacao is not null and char_length(v_localizacao) > 120 then
    raise exception 'Localizacao excede o limite.' using errcode = '22023';
  end if;

  v_imagem_url := nullif(btrim(coalesce(p_imagem_url, '')), '');
  if v_imagem_url is not null and (
    v_imagem_url like 'manufacturer-catalog/%'
    or v_imagem_url like '%/manufacturer-catalog/%'
  ) then
    v_imagem_url := null;
  end if;
  if v_imagem_url is not null and char_length(v_imagem_url) > 500 then
    raise exception 'Imagem excede o limite.' using errcode = '22023';
  end if;

  -- Sem fallback arbitrario: parametro OU valor do global.
  v_categoria := coalesce(p_categoria, v_prod.inventory_category);
  v_unidade := coalesce(p_unidade, v_prod.unit);

  if v_categoria is null then
    raise exception 'Categoria obrigatoria.' using errcode = '22023';
  end if;
  if v_unidade is null then
    raise exception 'Unidade obrigatoria.' using errcode = '22023';
  end if;

  v_quantidade := coalesce(p_quantidade, 0);
  v_estoque_minimo := coalesce(p_estoque_minimo, 0);
  v_custo_unit := coalesce(p_custo_unit, 0);
  v_preco_venda := coalesce(p_preco_venda, 0);
  v_ativo := coalesce(p_ativo, true);

  if v_quantidade < 0 or v_estoque_minimo < 0 or v_custo_unit < 0 or v_preco_venda < 0 then
    raise exception 'Valores comerciais invalidos.' using errcode = '23514';
  end if;

  begin
    insert into public.inventory_items (
      owner_id,
      company_id,
      categoria,
      nome,
      descricao,
      unidade,
      quantidade,
      estoque_minimo,
      custo_unit,
      preco_venda,
      sku,
      ncm,
      observacoes,
      imagem_url,
      fornecedor,
      supplier_id,
      localizacao,
      ativo,
      originado_de_projeto,
      manufacturer_product_id
    ) values (
      v_uid,
      p_company_id,
      v_categoria,
      v_nome,
      v_descricao,
      v_unidade,
      v_quantidade,
      v_estoque_minimo,
      v_custo_unit,
      v_preco_venda,
      v_sku,
      v_ncm,
      v_observacoes,
      v_imagem_url,
      v_fornecedor,
      p_supplier_id,
      v_localizacao,
      v_ativo,
      false,
      p_manufacturer_product_id
    )
    returning id into v_item_id;
  exception
    when unique_violation then
      select ii.id into v_item_id
      from public.inventory_items ii
      where ii.company_id = p_company_id
        and ii.manufacturer_product_id = p_manufacturer_product_id
      limit 1;
      if v_item_id is null then
        raise;
      end if;
  end;

  return v_item_id;
end;
$$;

comment on function public.ensure_manufacturer_product_inventory_item is
  'Ensure inventory_item id. Sem fallback outros/un. Race-safe. Membership + manage_estoque.';
