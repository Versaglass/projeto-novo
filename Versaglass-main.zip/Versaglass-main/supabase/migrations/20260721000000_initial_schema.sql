-- =====================================================================
-- BASELINE CANDIDATA — Vidro & Metal Mestre
-- Arquivo: 20260721000000_baseline.sql
-- Status: RASCUNHO — NÃO É MIGRATION OFICIAL. Não executar em remoto.
--
-- Fontes (ordem de prioridade aplicada):
--   1. tmp/supabase-antigo/public-schema.sql ...... DISPONÍVEL, PORÉM O SCHEMA ESTÁ VAZIO.
--        Dump bem formado (101 linhas) contendo: CREATE SCHEMA public, UMA função de
--        infraestrutura (public.rls_auto_enable) e ALTER DEFAULT PRIVILEGES.
--        ZERO tabelas, ZERO tipos, ZERO views, ZERO policies, ZERO índices,
--        ZERO triggers, ZERO sequências, ZERO dados.
--        => NÃO confirma nem desmente nenhuma coluna, FK, policy ou índice desta baseline.
--        Ver PENDENCIAS.md #P-00 (a pendência mais importante do arquivo).
--   2. Uso real do banco em src/ (auditoria §8) ... 13 tabelas + 2 RPCs + 1 bucket
--   3. src/integrations/supabase/types.ts ......... FONTE PRIMÁRIA DE ESTRUTURA
--                                                   (39 tabelas, 11 enums, 12 funções, 2 views)
--   4. supabase/migrations/20260703040050_5367a5a3-… (consolidada)
--   5. Migrations posteriores compatíveis com o schema real
--   6. Migrations antigas apenas para recuperar definições ausentes de types.ts
--      (types.ts NÃO descreve policies, triggers, índices, grants, Storage nem Realtime)
--
-- O QUE O DUMP ENSINOU (aplicado nesta baseline):
--   a) Existe public.rls_auto_enable(): função de event trigger que liga RLS
--      automaticamente em toda tabela criada em `public`. É infraestrutura da
--      plataforma — esta baseline NÃO a recria. O `enable row level security`
--      explícito da §10 continua correto e é idempotente.
--   b) O projeto tem ALTER DEFAULT PRIVILEGES concedendo ALL ON TABLES a `anon`.
--      Isso torna o `revoke ... from anon` da §12 OBRIGATÓRIO, não opcional.
--
-- Decisões registradas em: supabase/baseline-draft/PENDENCIAS.md
-- Plano completo em:       docs/PLANO_BASELINE_SUPABASE.md
--
-- GARANTIAS DESTE ARQUIVO
--   · Nenhum INSERT/UPDATE/DELETE sobre auth.users
--   · Nenhuma senha, e-mail corporativo, UUID de usuário ou de empresa real
--   · Nenhum "CREATE POLICY IF NOT EXISTS" (sintaxe inexistente no PostgreSQL)
--   · Nenhum "CREATE TABLE IF NOT EXISTS" — cada objeto é criado uma única vez
--   · O primeiro usuário cadastrado NÃO vira administrador
--   · Toda função SECURITY DEFINER tem SET search_path = '' e validação de auth.uid()
--   · Nenhum bucket de Storage e nenhuma publicação Realtime (fonte insuficiente)
--   · NENHUMA coluna de `public` armazena segredo: certificate_password foi
--     removida e não substituída (P-05). Nada de senha, token ou chave no schema.
--   · NENHUMA policy de INSERT/UPDATE/DELETE em tabela de log para `anon` ou
--     `authenticated`. Log só é escrito por service_role (P-07).
-- =====================================================================


-- =====================================================================
-- 1. EXTENSÕES
-- =====================================================================
-- Nenhuma extensão é criada por esta baseline.
--   · gen_random_uuid() é nativo do PostgreSQL >= 13 (Supabase usa 15+).
--   · pgcrypto NÃO é necessária: crypt()/gen_salt() eram usados apenas pelas
--     migrations de redefinição de senha, deliberadamente descartadas.
-- Ver PENDENCIAS.md #P-01.


-- =====================================================================
-- 2. ENUMS E TIPOS
-- Fonte: types.ts §Enums (11 enums) — confere 1:1 com as migrations de origem.
-- =====================================================================

create type public.app_role as enum ('admin', 'vendedor', 'instalador');
create type public.quote_status as enum ('rascunho', 'enviado', 'aprovado', 'recusado');
create type public.quote_stage as enum ('orcamento', 'producao', 'instalacao', 'pago');
create type public.project_category as enum ('vidro_comum', 'temperado', 'espelho', 'esquadria');
create type public.inventory_category as enum ('aluminio', 'vidro', 'ferragem', 'acessorio', 'perfil', 'led', 'cola', 'outros');
create type public.inventory_unit as enum ('m', 'm2', 'un', 'kg', 'pc', 'cx');
create type public.sub_status as enum ('ativo', 'suspenso', 'cancelado');
create type public.notif_kind as enum ('lembrete', 'atraso', 'aviso');
create type public.notif_status as enum ('pendente', 'enviada', 'lida');
create type public.auth_event_kind as enum ('signup', 'login_success', 'login_error', 'payment', 'subscription_created');
create type public.server_log_level as enum ('info', 'warn', 'error');

-- NOTA DE SEGURANÇA: 'super_admin' NÃO existe neste enum. As migrations antigas
-- 20260704114000 e 20260704133000 comparavam user_roles.role com 'super_admin',
-- o que é um erro fatal de replay. Papel de plataforma = 'admin'.


-- =====================================================================
-- 3. SEQUÊNCIAS
-- =====================================================================

create sequence public.quote_number_seq start 1000;


-- =====================================================================
-- 4. TABELAS INDEPENDENTES
-- (sem FK para outras tabelas de public; podem referenciar auth.users)
-- =====================================================================

-- --- Identidade e papéis -------------------------------------------------
create table public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  nome         text,
  telefone     text,
  empresa      text,
  ativo        boolean not null default true,
  segment      text not null default 'complete',
  permissions  jsonb not null default '{
    "manage_projetos": false,
    "manage_estoque": false,
    "manage_clientes": true,
    "create_orcamentos": true,
    "edit_orcamentos": true,
    "delete_orcamentos": false,
    "use_plano_corte": true
  }'::jsonb,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  constraint profiles_segment_check check (segment in ('glass', 'steel', 'woodworking', 'stone', 'complete'))
);

create table public.user_roles (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  role       public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);

-- --- Empresa (tenant) ----------------------------------------------------
-- Fonte: types.ts (schema v2). A v1 da migration 20260701021500 foi descartada.
create table public.company_profiles (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid references auth.users(id) on delete cascade,
  company_name text not null,
  cnpj         text,
  phone        text,
  email        text,
  address      text,
  city         text,
  state        text,
  segment      text default 'geral',
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

-- --- Catálogo de planos e módulos da plataforma --------------------------
create table public.platform_plans (
  id         text primary key,
  nome       text not null,
  segmento   text not null,
  descricao  text,
  ativo      boolean not null default true,
  created_at timestamptz not null default now(),
  constraint platform_plans_segmento_check
    check (segmento in ('vidracaria', 'serralheria', 'marcenaria', 'marmoraria', 'completo'))
);

create table public.platform_modules (
  id         text primary key,
  nome       text not null,
  segmento   text not null,
  rota       text,
  descricao  text,
  ativo      boolean not null default true,
  created_at timestamptz not null default now(),
  constraint platform_modules_segmento_check
    check (segmento in ('vidracaria', 'serralheria', 'marcenaria', 'marmoraria', 'completo'))
);

create table public.plans (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  slug          text not null unique,
  price         numeric not null,
  billing_cycle text default 'monthly',
  active        boolean default true,
  created_at    timestamptz default now()
);

create table public.project_categories (
  id         uuid primary key default gen_random_uuid(),
  name       text not null,
  slug       text not null unique,
  active     boolean default true,
  created_at timestamptz default now()
);

create table public.plan_model_limits (
  id            uuid primary key default gen_random_uuid(),
  plan_slug     text not null,
  category_slug text not null,
  model_limit   integer,
  allow_all     boolean default false,
  created_at    timestamptz default now(),
  unique (plan_slug, category_slug)
);

-- --- Assinaturas administradas pela plataforma ---------------------------
-- NOTA: `user_id` NÃO tem FK para auth.users nas fontes (migration 20260519040113).
-- Ver PENDENCIAS.md #P-12.
create table public.subscriptions (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null unique,
  plano              text not null default 'Mensal',
  valor              numeric not null default 0,
  dia_vencimento     integer not null default 10 check (dia_vencimento between 1 and 28),
  proximo_vencimento date not null default (date_trunc('month', now()) + interval '1 month' + interval '9 days')::date,
  ultimo_pagamento   date,
  status             public.sub_status not null default 'ativo',
  observacoes        text,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

-- --- Catálogo técnico do assinante --------------------------------------
-- NOTA: `owner_id` NÃO tem FK para auth.users nas fontes (migration 20260519032738).
-- Preservado sem FK por fidelidade. Ver PENDENCIAS.md #P-12.
create table public.project_templates (
  id             uuid primary key default gen_random_uuid(),
  owner_id       uuid not null,
  categoria      public.project_category not null,
  nome           text not null,
  descricao      text,
  espessura      text,
  tipo           text,
  imagem_url     text,
  largura_padrao numeric not null default 1.0,
  altura_padrao  numeric not null default 1.0,
  preco_m2       numeric not null default 0,
  observacoes    text,
  ativo          boolean not null default true,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

-- --- Registros administrativos ------------------------------------------
create table public.auth_events (
  id         uuid primary key default gen_random_uuid(),
  kind       public.auth_event_kind not null,
  email      text,
  user_id    uuid,
  ip         text,
  user_agent text,
  metadata   jsonb default '{}'::jsonb,
  read_at    timestamptz,
  created_at timestamptz not null default now()
);

create table public.server_logs (
  id          uuid primary key default gen_random_uuid(),
  action      text not null,
  level       public.server_log_level not null default 'info',
  status      integer,
  user_id     uuid,
  user_email  text,
  duration_ms integer,
  message     text,
  metadata    jsonb not null default '{}'::jsonb,
  created_at  timestamptz not null default now()
);

-- audit_logs NÃO consta em types.ts, mas é consultada por
-- src/routes/_authenticated/app.admin.auditoria.tsx via (supabase as any).
-- Definição recuperada da migration 20260701020000. Ver PENDENCIAS.md #P-02.
create table public.audit_logs (
  id          uuid primary key default gen_random_uuid(),
  actor_id    uuid references auth.users(id) on delete set null,
  actor_email text,
  action      text not null,
  entity      text,
  entity_id   text,
  ip          text,
  metadata    jsonb not null default '{}'::jsonb,
  created_at  timestamptz not null default now()
);

-- --- Segurança / recuperação de acesso ----------------------------------
create table public.security_events (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid references auth.users(id) on delete set null,
  company_id uuid,
  flow       text not null,
  action     text not null,
  email      text,
  phone      text,
  success    boolean not null default true,
  ip_address text,
  user_agent text,
  metadata   jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table public.security_lockouts (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid references auth.users(id) on delete cascade,
  email        text,
  phone        text,
  reason       text not null,
  locked_until timestamptz not null,
  created_at   timestamptz not null default now()
);

create table public.password_reset_tokens (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid references auth.users(id) on delete cascade,
  email      text,
  phone      text,
  channel    text not null check (channel in ('email', 'phone')),
  flow       text not null default 'password_recovery',
  token_hash text,
  expires_at timestamptz not null default (now() + interval '15 minutes'),
  used_at    timestamptz,
  ip_address text,
  user_agent text,
  created_at timestamptz not null default now()
);

create table public.two_factor_codes (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid references auth.users(id) on delete cascade,
  company_id   uuid,
  channel      text not null check (channel in ('email', 'phone', 'whatsapp', 'sms')),
  purpose      text not null check (purpose in ('first_password', 'password_recovery', 'admin_confirmation', 'ia_action')),
  destination  text not null,
  code_hash    text,
  attempts     integer not null default 0,
  max_attempts integer not null default 5,
  expires_at   timestamptz not null default (now() + interval '10 minutes'),
  verified_at  timestamptz,
  created_at   timestamptz not null default now()
);

-- --- IA / assistente administrativo -------------------------------------
-- Fonte: types.ts (schema v2 de 20260705172639). A v1 (`key`/`value`) foi descartada.
create table public.ai_system_settings (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid,
  setting_key   text not null,
  setting_value jsonb not null default '{}'::jsonb,
  category      text not null default 'general',
  created_by    uuid,
  updated_by    uuid,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (company_id, setting_key)
);

create table public.ai_generated_code (
  id               uuid primary key default gen_random_uuid(),
  company_id       uuid,
  user_id          uuid not null,
  prompt           text not null,
  title            text,
  description      text,
  files            jsonb not null default '[]'::jsonb,
  sql_migrations   jsonb not null default '[]'::jsonb,
  status           text not null default 'draft',
  copied_count     integer not null default 0,
  downloaded_count integer not null default 0,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

create table public.ai_dialog_sessions (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  title      text not null default 'Nova conversa',
  mode       text not null default 'converse' check (mode in ('converse', 'suggest', 'plan', 'execute')),
  status     text not null default 'active' check (status in ('active', 'archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);


-- =====================================================================
-- 5. TABELAS DEPENDENTES E FOREIGN KEYS
-- =====================================================================

-- --- Núcleo operacional (multiempresa) ----------------------------------
create table public.customers (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references auth.users(id) on delete cascade,
  company_id  uuid references public.company_profiles(id) on delete cascade,
  nome        text not null,
  documento   text,
  telefone    text,
  email       text,
  endereco    text,
  cidade      text,
  observacoes text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table public.quotes (
  id            uuid primary key default gen_random_uuid(),
  owner_id      uuid not null references auth.users(id) on delete cascade,
  company_id    uuid references public.company_profiles(id) on delete cascade,
  customer_id   uuid not null references public.customers(id) on delete restrict,
  numero        integer not null default nextval('public.quote_number_seq'),
  status        public.quote_status not null default 'rascunho',
  etapa         public.quote_stage not null default 'orcamento',
  desconto      numeric(12,2) not null default 0,
  acrescimo     numeric(12,2) not null default 0,
  total         numeric(12,2) not null default 0,
  observacoes   text,
  validade_dias integer not null default 15,
  instalacao_em date,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- drawing_data / drawing_notes / updated_at NÃO constam em types.ts, mas são
-- lidos e escritos por src/components/ProjectDrawingEditor.tsx.
-- Definição recuperada da migration 20260701023000. Ver PENDENCIAS.md #P-03.
create table public.quote_items (
  id            uuid primary key default gen_random_uuid(),
  quote_id      uuid not null references public.quotes(id) on delete cascade,
  company_id    uuid references public.company_profiles(id) on delete cascade,
  descricao     text not null,
  largura       numeric(10,3) not null default 0,
  altura        numeric(10,3) not null default 0,
  quantidade    integer not null default 1,
  m2            numeric(12,4) not null default 0,
  preco_unit    numeric(12,2) not null default 0,
  subtotal      numeric(12,2) not null default 0,
  ordem         integer not null default 0,
  drawing_data  jsonb not null default '{"versao":1,"recortes":[],"ferragens":[]}'::jsonb,
  drawing_notes text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- NOTA: `owner_id` NÃO tem FK para auth.users nas fontes (migration 20260519033247).
-- Ver PENDENCIAS.md #P-12.
create table public.inventory_items (
  id             uuid primary key default gen_random_uuid(),
  owner_id       uuid not null,
  company_id     uuid references public.company_profiles(id) on delete cascade,
  categoria      public.inventory_category not null,
  nome           text not null,
  descricao      text,
  unidade        public.inventory_unit not null default 'un',
  quantidade     numeric not null default 0,
  estoque_minimo numeric not null default 0,
  custo_unit     numeric not null default 0,
  preco_venda    numeric not null default 0,
  fornecedor     text,
  localizacao    text,
  location       text,
  segment        text default 'geral',
  sku            text,
  ncm            text,
  cest           text,
  gtin           text,
  imagem_url     text,
  observacoes    text,
  ativo          boolean not null default true,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
-- NOTA: `localizacao` (original) e `location` (adicionada depois) coexistem no
-- schema real. Duplicação preservada por fidelidade. Ver PENDENCIAS.md #P-04.

-- --- Associação usuário <-> empresa -------------------------------------
create table public.company_members (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid references public.company_profiles(id) on delete cascade,
  user_id     uuid references auth.users(id) on delete cascade,
  role        text not null default 'operator'
              check (role in ('owner', 'admin', 'manager', 'operator', 'installer', 'seller')),
  permissions jsonb not null default '{}'::jsonb,
  status      text not null default 'active' check (status in ('active', 'blocked', 'invited')),
  created_at  timestamptz not null default now(),
  unique (company_id, user_id)
);

-- --- Acesso a módulos por plano -----------------------------------------
create table public.plan_module_access (
  plan_id   text not null references public.platform_plans(id) on delete cascade,
  module_id text not null references public.platform_modules(id) on delete cascade,
  enabled   boolean not null default true,
  primary key (plan_id, module_id)
);

create table public.company_module_access (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid references public.company_profiles(id) on delete cascade,
  user_id       uuid references auth.users(id) on delete cascade,
  plan_id       text references public.platform_plans(id) on delete set null,
  module_id     text references public.platform_modules(id) on delete cascade,
  enabled       boolean not null default true,
  locked_reason text,
  created_at    timestamptz not null default now(),
  unique (company_id, user_id, module_id)
);

-- --- Biblioteca de modelos por assinatura -------------------------------
create table public.project_models (
  id           uuid primary key default gen_random_uuid(),
  category_id  uuid references public.project_categories(id) on delete set null,
  title        text not null,
  slug         text not null unique,
  description  text,
  image_2d_url text,
  image_3d_url text,
  file_url     text,
  is_premium   boolean default false,
  free_preview boolean default false,
  active       boolean default true,
  created_at   timestamptz default now()
);

create table public.user_subscriptions (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  company_id uuid references public.company_profiles(id) on delete cascade,
  plan_slug  text not null,
  status     text default 'active' check (status in ('active', 'past_due', 'canceled', 'expired', 'trialing')),
  started_at timestamptz default now(),
  expires_at timestamptz,
  created_at timestamptz default now()
);

-- NOTA: `user_id` NÃO tem FK para auth.users nas fontes (migration 20260519040113).
-- Ver PENDENCIAS.md #P-12.
create table public.billing_notifications (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null,
  subscription_id uuid references public.subscriptions(id) on delete cascade,
  kind            public.notif_kind not null default 'lembrete',
  status          public.notif_status not null default 'pendente',
  titulo          text not null,
  mensagem        text not null,
  valor           numeric default 0,
  vencimento      date,
  dias_atraso     integer default 0,
  read_at         timestamptz,
  created_at      timestamptz not null default now()
);

-- --- Pagamentos ---------------------------------------------------------
create table public.payment_accounts (
  id                     uuid primary key default gen_random_uuid(),
  company_id             uuid not null unique references public.company_profiles(id) on delete cascade,
  company_name           text,
  cnpj                   text,
  provider               text not null default 'asaas',
  marketplace_account_id text,
  bank_name              text,
  agency                 text,
  account_number         text,
  account_type           text,
  pix_key                text,
  financial_email        text,
  financial_phone        text,
  platform_fee_type      text not null default 'fixed' check (platform_fee_type in ('fixed', 'percentage')),
  platform_fee_value     numeric(12,2) not null default 0,
  status                 text not null default 'pending' check (status in ('pending', 'active', 'blocked', 'rejected')),
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now()
);

create table public.charges (
  id                 uuid primary key default gen_random_uuid(),
  company_id         uuid not null references public.company_profiles(id) on delete cascade,
  customer_id        uuid references public.customers(id) on delete set null,
  sale_id            uuid,
  order_service_id   uuid,
  payment_method     text not null check (payment_method in ('pix', 'boleto', 'credit_card', 'debit_card', 'payment_link', 'recurring')),
  status             text not null default 'pending' check (status in ('pending', 'paid', 'overdue', 'canceled', 'refunded', 'failed')),
  description        text,
  amount             numeric(12,2) not null default 0,
  platform_fee       numeric(12,2) not null default 0,
  net_amount         numeric(12,2) generated always as (greatest(amount - platform_fee, 0)) stored,
  due_date           date,
  paid_at            timestamptz,
  payment_link       text,
  boleto_url         text,
  pix_qrcode         text,
  pix_copy_paste     text,
  provider_charge_id text,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

create table public.payment_splits (
  id                uuid primary key default gen_random_uuid(),
  charge_id         uuid not null references public.charges(id) on delete cascade,
  company_id        uuid not null references public.company_profiles(id) on delete cascade,
  gross_amount      numeric(12,2) not null default 0,
  platform_amount   numeric(12,2) not null default 0,
  company_amount    numeric(12,2) not null default 0,
  status            text not null default 'pending' check (status in ('pending', 'processing', 'done', 'failed')),
  provider_split_id text,
  created_at        timestamptz not null default now()
);

create table public.recurring_charges (
  id               uuid primary key default gen_random_uuid(),
  company_id       uuid not null references public.company_profiles(id) on delete cascade,
  customer_id      uuid references public.customers(id) on delete set null,
  amount           numeric(12,2) not null default 0,
  payment_method   text not null check (payment_method in ('pix', 'boleto', 'credit_card', 'debit_card', 'payment_link')),
  frequency        text not null check (frequency in ('weekly', 'biweekly', 'monthly', 'quarterly', 'yearly')),
  start_date       date not null,
  end_date         date,
  next_charge_date date not null,
  status           text not null default 'active' check (status in ('active', 'paused', 'finished', 'canceled')),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

-- --- Fiscal -------------------------------------------------------------
create table public.fiscal_settings (
  id                     uuid primary key default gen_random_uuid(),
  company_id             uuid not null unique references public.company_profiles(id) on delete cascade,
  legal_name             text not null,
  trade_name             text,
  cnpj                   text not null,
  state_registration     text,
  municipal_registration text,
  tax_regime             text,
  city                   text,
  state                  text,
  certificate_url        text,
  environment            text not null default 'homologation' check (environment in ('homologation', 'production')),
  provider               text not null default 'plugnotas' check (provider in ('plugnotas', 'tecnospeed', 'nuvem_fiscal', 'manual')),
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now()
);
-- P-05 — RESOLVIDA PARA A BASELINE INICIAL: `certificate_password` NÃO EXISTE.
--
-- A coluna `certificate_password text` das migrations antigas foi REMOVIDA e não
-- foi substituída por nenhuma outra coluna — nem texto, nem cifrada, nem
-- `secret_id` apontando para o Vault. O schema `public` desta baseline não
-- guarda segredo de certificado digital A1 em nenhuma forma.
--
-- POR QUE: a integração fiscal é hoje 100% SIMULADA. Os três "provedores"
-- (src/modules/fiscal/providers/{plugNotas,tecnoSpeed,nuvemFiscal}Provider.ts)
-- geram número, chave e protocolo com crypto.randomUUID() e devolvem URLs de
-- exemplo; nenhum deles faz requisição de rede e NENHUM deles lê a senha do
-- certificado. Criar hoje uma coluna de segredo seria persistir credencial real
-- para um consumidor que não existe — risco sem contrapartida.
--
-- CONSEQUÊNCIA ACEITA: a configuração de certificado digital fica INDISPONÍVEL
-- no produto até que a integração fiscal segura seja implementada. O formulário
-- de src/routes/_authenticated/app.fiscal.tsx é mock (estado local, storageKey
-- "vmm_fiscal_settings") e não grava no banco, então nada quebra hoje.
--
-- ESTRATÉGIA FUTURA (migration posterior, fora desta baseline):
--   · segredo em Supabase Vault ou serviço de segredos equivalente;
--   · gravação e leitura exclusivamente por código servidor confiável;
--   · nenhuma senha jamais retornada ao navegador;
--   · nenhum segredo em log, mensagem de erro ou telemetria;
--   · vínculo empresa → segredo por identificador OPACO, criado somente quando
--     existir a integração servidor que de fato o consuma.
-- Ver PENDENCIAS.md #P-05.

-- Fonte: types.ts (schema v2). A v1 da migration 20260701030000
-- (owner_id/numero/cliente/valor) foi descartada.
create table public.fiscal_invoices (
  id               uuid primary key default gen_random_uuid(),
  company_id       uuid not null references public.company_profiles(id) on delete cascade,
  customer_id      uuid references public.customers(id) on delete set null,
  sale_id          uuid,
  order_service_id uuid,
  invoice_type     text not null check (invoice_type in ('nfe', 'nfse', 'nfce')),
  status           text not null default 'draft' check (status in ('draft', 'processing', 'authorized', 'rejected', 'canceled')),
  invoice_number   text,
  access_key       text,
  protocol         text,
  xml_url          text,
  pdf_url          text,
  total_amount     numeric(12,2) not null default 0,
  error_message    text,
  issued_at        timestamptz,
  canceled_at      timestamptz,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

-- --- IA: diálogo administrativo -----------------------------------------
create table public.ai_dialog_messages (
  id         uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.ai_dialog_sessions(id) on delete cascade,
  role       text not null check (role in ('user', 'assistant', 'system')),
  content    text not null,
  audio_url  text,
  tokens     integer,
  metadata   jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table public.ai_dialog_suggestions (
  id          uuid primary key default gen_random_uuid(),
  session_id  uuid not null references public.ai_dialog_sessions(id) on delete cascade,
  message_id  uuid references public.ai_dialog_messages(id) on delete set null,
  title       text not null,
  description text,
  risk        text not null default 'baixo' check (risk in ('baixo', 'medio', 'alto', 'critico')),
  applied     boolean not null default false,
  created_at  timestamptz not null default now()
);

create table public.ai_dialog_action_previews (
  id         uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.ai_dialog_sessions(id) on delete cascade,
  message_id uuid references public.ai_dialog_messages(id) on delete set null,
  intent     jsonb not null default '{}'::jsonb,
  preview    jsonb not null default '{}'::jsonb,
  snapshot   jsonb,
  risk       text not null default 'medio' check (risk in ('baixo', 'medio', 'alto', 'critico')),
  status     text not null default 'pending' check (status in ('pending', 'approved', 'rejected', 'executed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.ai_dialog_executions (
  id                 uuid primary key default gen_random_uuid(),
  preview_id         uuid not null references public.ai_dialog_action_previews(id) on delete cascade,
  executed_by        uuid not null references auth.users(id) on delete cascade,
  result             jsonb not null default '{}'::jsonb,
  success            boolean not null default false,
  rollback_available boolean not null default false,
  error              text,
  created_at         timestamptz not null default now()
);


-- =====================================================================
-- 6. ÍNDICES
-- Fonte: migrations (types.ts não descreve índices).
-- =====================================================================

create index idx_inventory_owner        on public.inventory_items (owner_id);
create index idx_inventory_categoria    on public.inventory_items (categoria);
create index idx_inventory_company      on public.inventory_items (company_id);
create index idx_customers_company      on public.customers (company_id);
create index idx_quotes_company         on public.quotes (company_id);
create index idx_quote_items_quote      on public.quote_items (quote_id);
create index idx_quote_items_drawing    on public.quote_items using gin (drawing_data);
create index idx_project_templates_owner_tipo on public.project_templates (owner_id, tipo);

create index idx_notif_user             on public.billing_notifications (user_id, created_at desc);
create index auth_events_created_at_idx on public.auth_events (created_at desc);
create index auth_events_kind_idx       on public.auth_events (kind);
create index server_logs_created_at_idx on public.server_logs (created_at desc);
create index server_logs_level_idx      on public.server_logs (level);
create index idx_audit_logs_created_at  on public.audit_logs (created_at desc);

create index idx_security_events_user_created on public.security_events (user_id, created_at desc);
create index idx_security_events_flow_created on public.security_events (flow, created_at desc);
create index idx_two_factor_codes_destination on public.two_factor_codes (destination, purpose, created_at desc);

create index idx_company_profiles_user  on public.company_profiles (user_id);
create index idx_company_members_company on public.company_members (company_id);
create index idx_company_members_user   on public.company_members (user_id);

create index idx_payment_accounts_company   on public.payment_accounts (company_id);
create index idx_charges_company            on public.charges (company_id);
create index idx_charges_customer           on public.charges (customer_id);
create index idx_charges_status_due         on public.charges (status, due_date);
create index idx_charges_provider_id        on public.charges (provider_charge_id);
create index idx_payment_splits_company     on public.payment_splits (company_id);
create index idx_payment_splits_charge      on public.payment_splits (charge_id);
create index idx_recurring_charges_company  on public.recurring_charges (company_id);
create index idx_recurring_charges_next     on public.recurring_charges (next_charge_date, status);
create index idx_fiscal_settings_company    on public.fiscal_settings (company_id);
create index idx_fiscal_invoices_company    on public.fiscal_invoices (company_id);
create index idx_fiscal_invoices_status     on public.fiscal_invoices (status);
create index idx_fiscal_invoices_access_key on public.fiscal_invoices (access_key);

create index idx_user_subscriptions_user_status on public.user_subscriptions (user_id, status);
create index idx_user_subscriptions_company     on public.user_subscriptions (company_id);
create index idx_project_models_category        on public.project_models (category_id);
create index idx_plan_model_limits_plan_category on public.plan_model_limits (plan_slug, category_slug);

create index ai_dialog_messages_session_idx    on public.ai_dialog_messages (session_id, created_at);
create index idx_ai_system_settings_company    on public.ai_system_settings (company_id);
create index idx_ai_system_settings_key        on public.ai_system_settings (setting_key);


-- =====================================================================
-- 7. FUNÇÕES NORMAIS (SECURITY INVOKER)
-- =====================================================================

create function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create function public.subscription_state(_proximo date, _status public.sub_status)
returns text
language sql
stable
set search_path = ''
as $$
  select case
    when _status = 'cancelado' then 'cancelado'
    when _status = 'suspenso'  then 'suspenso'
    when _proximo < current_date then 'atrasado'
    when _proximo <= current_date + interval '5 days' then 'proximo'
    else 'em_dia'
  end;
$$;


-- =====================================================================
-- 8. FUNÇÕES SECURITY DEFINER
--
-- Regras aplicadas a TODAS elas:
--   · SET search_path = '' (todos os objetos qualificados explicitamente)
--   · Validação de auth.uid(): um cliente não consulta o estado de terceiros.
--     `auth.uid() is null` identifica o contexto service_role/servidor (sem JWT)
--     e é liberado — service_role já ignora RLS por definição.
--   · EXECUTE revogado de PUBLIC e anon; concedido apenas onde necessário.
-- =====================================================================

create function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.user_roles
    where user_id = _user_id
      and role = _role
      -- impede enumeração de papéis de terceiros por clientes autenticados
      and (auth.uid() is null or _user_id = auth.uid())
  );
$$;

create function public.has_permission(_user_id uuid, _perm text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when auth.uid() is not null and _user_id <> auth.uid() then false
    else public.has_role(_user_id, 'admin'::public.app_role)
         or coalesce(
              (select (p.permissions ->> _perm)::boolean
                 from public.profiles p
                where p.id = _user_id),
              false)
  end;
$$;

create function public.is_platform_admin(_user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select public.has_role(_user_id, 'admin'::public.app_role);
$$;

create function public.is_company_member(_company_id uuid, _user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when auth.uid() is not null and _user_id <> auth.uid() then false
    else exists (
           select 1 from public.company_members cm
            where cm.company_id = _company_id
              and cm.user_id = _user_id
              and cm.status = 'active')
         or exists (
           select 1 from public.company_profiles cp
            where cp.id = _company_id
              and cp.user_id = _user_id)
  end;
$$;

create function public.is_company_admin(_company_id uuid, _user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when auth.uid() is not null and _user_id <> auth.uid() then false
    else exists (
           select 1 from public.company_members cm
            where cm.company_id = _company_id
              and cm.user_id = _user_id
              and cm.status = 'active'
              and cm.role in ('owner', 'admin', 'manager'))
         or exists (
           select 1 from public.company_profiles cp
            where cp.id = _company_id
              and cp.user_id = _user_id)
  end;
$$;

create function public.is_company_owner(_company_id uuid, _user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when auth.uid() is not null and _user_id <> auth.uid() then false
    else exists (
           select 1 from public.company_members cm
            where cm.company_id = _company_id
              and cm.user_id = _user_id
              and cm.status = 'active'
              and cm.role = 'owner')
         or exists (
           select 1 from public.company_profiles cp
            where cp.id = _company_id
              and cp.user_id = _user_id)
  end;
$$;

create function public.get_user_plan(_user_id uuid)
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when auth.uid() is not null and _user_id <> auth.uid() then 'free'
    else coalesce((
      select case when us.plan_slug in ('pro', 'premium') then us.plan_slug else 'free' end
        from public.user_subscriptions us
       where us.user_id = _user_id
         and us.status = 'active'
         and (us.expires_at is null or us.expires_at > now())
       order by us.created_at desc
       limit 1), 'free')
  end;
$$;

-- Lógica pura sobre catálogo público; não lê dados de usuário.
create function public.can_access_model(
  _user_plan text,
  _category_slug text,
  _model_index integer,
  _free_preview boolean default false
)
returns boolean
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  _limit integer;
  _allow_all boolean;
begin
  if _user_plan = 'premium' then
    return true;
  end if;

  if _user_plan = 'pro' then
    select model_limit, allow_all into _limit, _allow_all
      from public.plan_model_limits
     where plan_slug = 'pro' and category_slug = _category_slug;

    if coalesce(_allow_all, false) then
      return true;
    end if;

    return _limit is not null and _model_index < _limit;
  end if;

  return coalesce(_free_preview, false);
end;
$$;

create function public.company_payment_dashboard(_company_id uuid)
returns table (
  total_received      numeric,
  total_pending       numeric,
  total_overdue       numeric,
  total_pix           numeric,
  total_boleto        numeric,
  total_card          numeric,
  platform_fees       numeric,
  expected_receivable numeric
)
language sql
stable
security definer
set search_path = ''
as $$
  select
    coalesce(sum(amount) filter (where status = 'paid'), 0),
    coalesce(sum(amount) filter (where status = 'pending'), 0),
    coalesce(sum(amount) filter (where status = 'overdue'), 0),
    coalesce(sum(amount) filter (where payment_method = 'pix'), 0),
    coalesce(sum(amount) filter (where payment_method = 'boleto'), 0),
    coalesce(sum(amount) filter (where payment_method in ('credit_card', 'debit_card')), 0),
    coalesce(sum(platform_fee) filter (where status = 'paid'), 0),
    coalesce(sum(amount) filter (where status in ('pending', 'overdue')), 0)
  from public.charges
  where company_id = _company_id
    and public.is_company_member(_company_id, auth.uid());
$$;

create function public.company_fiscal_dashboard(_company_id uuid)
returns table (
  authorized_amount numeric,
  authorized_count  bigint,
  rejected_count    bigint,
  processing_count  bigint
)
language sql
stable
security definer
set search_path = ''
as $$
  select
    coalesce(sum(total_amount) filter (where status = 'authorized'), 0),
    count(*) filter (where status = 'authorized'),
    count(*) filter (where status = 'rejected'),
    count(*) filter (where status = 'processing')
  from public.fiscal_invoices
  where company_id = _company_id
    and public.is_company_member(_company_id, auth.uid());
$$;

create function public.generate_billing_notifications()
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  s record;
  diff integer;
  k public.notif_kind;
  ttl text;
  msg text;
  created_count integer := 0;
begin
  if not public.has_role(auth.uid(), 'admin'::public.app_role) then
    raise exception 'forbidden';
  end if;

  for s in select * from public.subscriptions where status = 'ativo' loop
    diff := s.proximo_vencimento - current_date;

    if diff < 0 then
      k := 'atraso';
      ttl := 'Mensalidade em atraso';
      msg := 'Sua mensalidade ' || s.plano || ' venceu há ' || abs(diff)
             || ' dia(s). Valor: R$ ' || to_char(s.valor, 'FM999G990D00')
             || '. Regularize para evitar suspensão.';
    elsif diff <= 5 then
      k := 'lembrete';
      ttl := 'Lembrete de vencimento';
      msg := 'Sua mensalidade ' || s.plano || ' vence em ' || diff || ' dia(s) ('
             || to_char(s.proximo_vencimento, 'DD/MM/YYYY') || '). Valor: R$ '
             || to_char(s.valor, 'FM999G990D00') || '.';
    else
      continue;
    end if;

    if not exists (
      select 1 from public.billing_notifications
       where subscription_id = s.id and kind = k and created_at::date = current_date
    ) then
      insert into public.billing_notifications
        (user_id, subscription_id, kind, titulo, mensagem, valor, vencimento, dias_atraso)
      values
        (s.user_id, s.id, k, ttl, msg, s.valor, s.proximo_vencimento, greatest(0, -diff));
      created_count := created_count + 1;
    end if;
  end loop;

  return created_count;
end;
$$;

-- Cria o profile do novo usuário.
-- REGRA 3/4: o papel atribuído é SEMPRE 'vendedor'.
-- A lógica antiga "primeiro usuário vira admin" foi REMOVIDA — era uma janela
-- de sequestro em banco vazio. Promoção a admin é operação manual: ver §14.
create function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, nome, empresa, segment)
  values (
    new.id,
    coalesce(
      new.raw_user_meta_data ->> 'nome',
      new.raw_user_meta_data ->> 'full_name',
      split_part(new.email, '@', 1)
    ),
    new.raw_user_meta_data ->> 'empresa',
    coalesce(nullif(new.raw_user_meta_data ->> 'segment', ''), 'complete')
  );

  insert into public.user_roles (user_id, role)
  values (new.id, 'vendedor'::public.app_role);

  return new;
end;
$$;


-- =====================================================================
-- 9. TRIGGERS DE TABELAS PÚBLICAS
-- =====================================================================

create trigger profiles_updated_at            before update on public.profiles            for each row execute function public.set_updated_at();
create trigger customers_updated_at           before update on public.customers           for each row execute function public.set_updated_at();
create trigger quotes_updated_at              before update on public.quotes              for each row execute function public.set_updated_at();
create trigger quote_items_updated_at         before update on public.quote_items         for each row execute function public.set_updated_at();
create trigger inventory_items_updated_at     before update on public.inventory_items     for each row execute function public.set_updated_at();
create trigger project_templates_updated_at   before update on public.project_templates   for each row execute function public.set_updated_at();
create trigger company_profiles_updated_at    before update on public.company_profiles    for each row execute function public.set_updated_at();
create trigger subscriptions_updated_at       before update on public.subscriptions       for each row execute function public.set_updated_at();
create trigger payment_accounts_updated_at    before update on public.payment_accounts    for each row execute function public.set_updated_at();
create trigger charges_updated_at             before update on public.charges             for each row execute function public.set_updated_at();
create trigger recurring_charges_updated_at   before update on public.recurring_charges   for each row execute function public.set_updated_at();
create trigger fiscal_settings_updated_at     before update on public.fiscal_settings     for each row execute function public.set_updated_at();
create trigger fiscal_invoices_updated_at     before update on public.fiscal_invoices     for each row execute function public.set_updated_at();
create trigger ai_system_settings_updated_at  before update on public.ai_system_settings  for each row execute function public.set_updated_at();
create trigger ai_generated_code_updated_at   before update on public.ai_generated_code   for each row execute function public.set_updated_at();
create trigger ai_dialog_sessions_updated_at  before update on public.ai_dialog_sessions  for each row execute function public.set_updated_at();
create trigger ai_dialog_previews_updated_at  before update on public.ai_dialog_action_previews for each row execute function public.set_updated_at();


-- =====================================================================
-- 10. ROW LEVEL SECURITY — habilitado em TODAS as tabelas expostas
-- Negação por padrão: sem policy correspondente, a operação é negada.
-- =====================================================================

alter table public.profiles                  enable row level security;
alter table public.user_roles                enable row level security;
alter table public.company_profiles          enable row level security;
alter table public.company_members           enable row level security;
alter table public.customers                 enable row level security;
alter table public.quotes                    enable row level security;
alter table public.quote_items               enable row level security;
alter table public.inventory_items           enable row level security;
alter table public.project_templates         enable row level security;
alter table public.subscriptions             enable row level security;
alter table public.billing_notifications     enable row level security;
alter table public.auth_events               enable row level security;
alter table public.server_logs               enable row level security;
alter table public.audit_logs                enable row level security;
alter table public.security_events           enable row level security;
alter table public.security_lockouts         enable row level security;
alter table public.password_reset_tokens     enable row level security;
alter table public.two_factor_codes          enable row level security;
alter table public.platform_plans            enable row level security;
alter table public.platform_modules          enable row level security;
alter table public.plan_module_access        enable row level security;
alter table public.company_module_access     enable row level security;
alter table public.plans                     enable row level security;
alter table public.user_subscriptions        enable row level security;
alter table public.project_categories        enable row level security;
alter table public.project_models            enable row level security;
alter table public.plan_model_limits         enable row level security;
alter table public.payment_accounts          enable row level security;
alter table public.charges                   enable row level security;
alter table public.payment_splits            enable row level security;
alter table public.recurring_charges         enable row level security;
alter table public.fiscal_settings           enable row level security;
alter table public.fiscal_invoices           enable row level security;
alter table public.ai_system_settings        enable row level security;
alter table public.ai_generated_code         enable row level security;
alter table public.ai_dialog_sessions        enable row level security;
alter table public.ai_dialog_messages        enable row level security;
alter table public.ai_dialog_suggestions     enable row level security;
alter table public.ai_dialog_action_previews enable row level security;
alter table public.ai_dialog_executions      enable row level security;


-- =====================================================================
-- 11. POLICIES
-- Convenção: todas declaram `to authenticated` explicitamente.
-- Nenhuma policy é concedida a `anon`.
-- =====================================================================

-- ---------- profiles ----------
create policy "profiles_select_own" on public.profiles
  for select to authenticated
  using (id = auth.uid());

create policy "profiles_select_platform_admin" on public.profiles
  for select to authenticated
  using (public.is_platform_admin(auth.uid()));

create policy "profiles_insert_own" on public.profiles
  for insert to authenticated
  with check (id = auth.uid());

-- REGRA 13: o usuário não pode elevar os próprios privilégios alterando
-- `permissions`, `ativo` ou `segment` — apenas dados de contato.
create policy "profiles_update_own" on public.profiles
  for update to authenticated
  using (id = auth.uid())
  with check (
    id = auth.uid()
    and permissions is not distinct from (select p.permissions from public.profiles p where p.id = auth.uid())
    and ativo       is not distinct from (select p.ativo       from public.profiles p where p.id = auth.uid())
  );

create policy "profiles_update_platform_admin" on public.profiles
  for update to authenticated
  using (public.is_platform_admin(auth.uid()))
  with check (public.is_platform_admin(auth.uid()));

-- ---------- user_roles ----------
create policy "user_roles_select_own" on public.user_roles
  for select to authenticated
  using (user_id = auth.uid());

create policy "user_roles_select_platform_admin" on public.user_roles
  for select to authenticated
  using (public.is_platform_admin(auth.uid()));

create policy "user_roles_insert_platform_admin" on public.user_roles
  for insert to authenticated
  with check (public.is_platform_admin(auth.uid()));

create policy "user_roles_update_platform_admin" on public.user_roles
  for update to authenticated
  using (public.is_platform_admin(auth.uid()))
  with check (public.is_platform_admin(auth.uid()));

create policy "user_roles_delete_platform_admin" on public.user_roles
  for delete to authenticated
  using (public.is_platform_admin(auth.uid()));

-- Defesa em profundidade contra escalonamento de privilégio.
-- Aplicada só a INSERT/UPDATE/DELETE — uma RESTRICTIVE FOR ALL bloquearia
-- também o SELECT do próprio papel, quebrando o login. Ver PENDENCIAS.md #P-06.
create policy "user_roles_restrict_writes_ins" on public.user_roles
  as restrictive for insert to authenticated
  with check (public.is_platform_admin(auth.uid()));

create policy "user_roles_restrict_writes_upd" on public.user_roles
  as restrictive for update to authenticated
  using (public.is_platform_admin(auth.uid()))
  with check (public.is_platform_admin(auth.uid()));

create policy "user_roles_restrict_writes_del" on public.user_roles
  as restrictive for delete to authenticated
  using (public.is_platform_admin(auth.uid()));

-- ---------- company_profiles ----------
create policy "company_profiles_select_own" on public.company_profiles
  for select to authenticated
  using (user_id = auth.uid());

create policy "company_profiles_select_platform_admin" on public.company_profiles
  for select to authenticated
  using (public.is_platform_admin(auth.uid()));

create policy "company_profiles_insert_own" on public.company_profiles
  for insert to authenticated
  with check (user_id = auth.uid());

create policy "company_profiles_update_own" on public.company_profiles
  for update to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

create policy "company_profiles_delete_own" on public.company_profiles
  for delete to authenticated
  using (user_id = auth.uid());

-- ---------- company_members ----------
create policy "company_members_select" on public.company_members
  for select to authenticated
  using (
    public.is_company_member(company_id, auth.uid())
    or public.is_platform_admin(auth.uid())
  );

-- REGRA 13: só um `owner` pode criar/alterar/remover outro `owner`.
create policy "company_members_insert" on public.company_members
  for insert to authenticated
  with check (
    public.is_company_admin(company_id, auth.uid())
    and (role <> 'owner' or public.is_company_owner(company_id, auth.uid()))
  );

create policy "company_members_update" on public.company_members
  for update to authenticated
  using (
    public.is_company_admin(company_id, auth.uid())
    and (role <> 'owner' or public.is_company_owner(company_id, auth.uid()))
  )
  with check (
    public.is_company_admin(company_id, auth.uid())
    and (role <> 'owner' or public.is_company_owner(company_id, auth.uid()))
  );

create policy "company_members_delete" on public.company_members
  for delete to authenticated
  using (
    public.is_company_admin(company_id, auth.uid())
    and (role <> 'owner' or public.is_company_owner(company_id, auth.uid()))
  );

-- ---------- customers ----------
create policy "customers_select_tenant" on public.customers
  for select to authenticated
  using (
    owner_id = auth.uid()
    or (company_id is not null and public.is_company_member(company_id, auth.uid()))
  );

-- REGRA 13: `owner_id` é forçado a auth.uid(); `company_id`, se informado,
-- precisa ser uma empresa da qual o usuário é membro.
create policy "customers_insert_tenant" on public.customers
  for insert to authenticated
  with check (
    owner_id = auth.uid()
    and (company_id is null or public.is_company_member(company_id, auth.uid()))
  );

create policy "customers_update_tenant" on public.customers
  for update to authenticated
  using (
    owner_id = auth.uid()
    or (company_id is not null and public.is_company_admin(company_id, auth.uid()))
  )
  with check (
    owner_id = auth.uid()
    and (company_id is null or public.is_company_member(company_id, auth.uid()))
  );

create policy "customers_delete_tenant" on public.customers
  for delete to authenticated
  using (
    owner_id = auth.uid()
    or (company_id is not null and public.is_company_admin(company_id, auth.uid()))
  );

-- ---------- quotes ----------
create policy "quotes_select_tenant" on public.quotes
  for select to authenticated
  using (
    owner_id = auth.uid()
    or (company_id is not null and public.is_company_member(company_id, auth.uid()))
  );

create policy "quotes_insert_tenant" on public.quotes
  for insert to authenticated
  with check (
    owner_id = auth.uid()
    and (company_id is null or public.is_company_member(company_id, auth.uid()))
  );

create policy "quotes_update_tenant" on public.quotes
  for update to authenticated
  using (
    owner_id = auth.uid()
    or (company_id is not null and public.is_company_admin(company_id, auth.uid()))
  )
  with check (
    owner_id = auth.uid()
    and (company_id is null or public.is_company_member(company_id, auth.uid()))
  );

create policy "quotes_delete_tenant" on public.quotes
  for delete to authenticated
  using (
    owner_id = auth.uid()
    or (company_id is not null and public.is_company_admin(company_id, auth.uid()))
  );

-- ---------- quote_items (herda o dono via quotes) ----------
create policy "quote_items_select_tenant" on public.quote_items
  for select to authenticated
  using (exists (
    select 1 from public.quotes q
     where q.id = quote_items.quote_id
       and (q.owner_id = auth.uid()
            or (q.company_id is not null and public.is_company_member(q.company_id, auth.uid())))
  ));

create policy "quote_items_insert_tenant" on public.quote_items
  for insert to authenticated
  with check (exists (
    select 1 from public.quotes q
     where q.id = quote_items.quote_id
       and (q.owner_id = auth.uid()
            or (q.company_id is not null and public.is_company_member(q.company_id, auth.uid())))
  ));

create policy "quote_items_update_tenant" on public.quote_items
  for update to authenticated
  using (exists (
    select 1 from public.quotes q
     where q.id = quote_items.quote_id
       and (q.owner_id = auth.uid()
            or (q.company_id is not null and public.is_company_member(q.company_id, auth.uid())))
  ))
  with check (exists (
    select 1 from public.quotes q
     where q.id = quote_items.quote_id
       and (q.owner_id = auth.uid()
            or (q.company_id is not null and public.is_company_member(q.company_id, auth.uid())))
  ));

create policy "quote_items_delete_tenant" on public.quote_items
  for delete to authenticated
  using (exists (
    select 1 from public.quotes q
     where q.id = quote_items.quote_id
       and (q.owner_id = auth.uid()
            or (q.company_id is not null and public.is_company_member(q.company_id, auth.uid())))
  ));

-- ---------- inventory_items ----------
create policy "inventory_select_tenant" on public.inventory_items
  for select to authenticated
  using (
    owner_id = auth.uid()
    or (company_id is not null and public.is_company_member(company_id, auth.uid()))
  );

create policy "inventory_insert_tenant" on public.inventory_items
  for insert to authenticated
  with check (
    owner_id = auth.uid()
    and (company_id is null or public.is_company_member(company_id, auth.uid()))
  );

create policy "inventory_update_tenant" on public.inventory_items
  for update to authenticated
  using (
    owner_id = auth.uid()
    or (company_id is not null and public.is_company_admin(company_id, auth.uid()))
  )
  with check (
    owner_id = auth.uid()
    and (company_id is null or public.is_company_member(company_id, auth.uid()))
  );

create policy "inventory_delete_tenant" on public.inventory_items
  for delete to authenticated
  using (
    owner_id = auth.uid()
    or (company_id is not null and public.is_company_admin(company_id, auth.uid()))
  );

-- ---------- project_templates (sempre por dono) ----------
create policy "project_templates_select_own" on public.project_templates
  for select to authenticated using (owner_id = auth.uid());

create policy "project_templates_insert_own" on public.project_templates
  for insert to authenticated with check (owner_id = auth.uid());

create policy "project_templates_update_own" on public.project_templates
  for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy "project_templates_delete_own" on public.project_templates
  for delete to authenticated using (owner_id = auth.uid());

-- ---------- subscriptions (geridas pela plataforma) ----------
create policy "subscriptions_select_own" on public.subscriptions
  for select to authenticated using (user_id = auth.uid());

create policy "subscriptions_select_platform_admin" on public.subscriptions
  for select to authenticated using (public.is_platform_admin(auth.uid()));

create policy "subscriptions_insert_platform_admin" on public.subscriptions
  for insert to authenticated with check (public.is_platform_admin(auth.uid()));

create policy "subscriptions_update_platform_admin" on public.subscriptions
  for update to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

create policy "subscriptions_delete_platform_admin" on public.subscriptions
  for delete to authenticated using (public.is_platform_admin(auth.uid()));

-- ---------- billing_notifications ----------
create policy "billing_notifications_select_own" on public.billing_notifications
  for select to authenticated using (user_id = auth.uid());

create policy "billing_notifications_select_platform_admin" on public.billing_notifications
  for select to authenticated using (public.is_platform_admin(auth.uid()));

create policy "billing_notifications_insert_platform_admin" on public.billing_notifications
  for insert to authenticated with check (public.is_platform_admin(auth.uid()));

-- o usuário só pode marcar como lida a própria notificação
create policy "billing_notifications_update_own" on public.billing_notifications
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "billing_notifications_update_platform_admin" on public.billing_notifications
  for update to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

create policy "billing_notifications_delete_platform_admin" on public.billing_notifications
  for delete to authenticated using (public.is_platform_admin(auth.uid()));

-- ---------- auth_events / server_logs / audit_logs ----------
-- P-07 — DECISÃO TOMADA E FECHADA NO NÍVEL DO SCHEMA: opção A (servidor
-- confiável com service_role). NÃO existe policy de INSERT/UPDATE/DELETE para
-- `anon` nem para `authenticated` em auth_events, server_logs e audit_logs.
-- As opções B (insert pelo autenticado) e C (híbrida) foram DESCARTADAS: ambas
-- permitem que um usuário comum forje ou polua a trilha, e nenhuma cobre o
-- evento de `login_error`, que ocorre antes de existir sessão.
--
-- Escrita: exclusivamente por service_role, que ignora RLS por ser BYPASSRLS.
-- Leitura: apenas is_platform_admin(). UPDATE/DELETE: apenas is_platform_admin()
-- (marcar como lido / expurgar), e mesmo assim nunca por usuário comum.
-- Nenhuma função SECURITY DEFINER desta baseline escreve nestas tabelas — não
-- há caminho indireto para forjar registro.
--
-- CONSEQUÊNCIA CONHECIDA, ACEITA: src/lib/server-log.ts, src/lib/log-event.ts e
-- src/lib/access-security.ts gravam direto do browser com a chave publicável e
-- passarão a falhar. Eles DEVEM migrar para endpoint/função de servidor antes de
-- o produto depender de log. A chave privilegiada nunca vai ao navegador.
-- Lista exata dos arquivos a corrigir: PENDENCIAS.md #P-07.

create policy "auth_events_select_platform_admin" on public.auth_events
  for select to authenticated using (public.is_platform_admin(auth.uid()));

create policy "auth_events_update_platform_admin" on public.auth_events
  for update to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

create policy "auth_events_delete_platform_admin" on public.auth_events
  for delete to authenticated using (public.is_platform_admin(auth.uid()));

create policy "server_logs_select_platform_admin" on public.server_logs
  for select to authenticated using (public.is_platform_admin(auth.uid()));

create policy "server_logs_update_platform_admin" on public.server_logs
  for update to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

create policy "server_logs_delete_platform_admin" on public.server_logs
  for delete to authenticated using (public.is_platform_admin(auth.uid()));

create policy "audit_logs_select_platform_admin" on public.audit_logs
  for select to authenticated using (public.is_platform_admin(auth.uid()));

-- ---------- Tabelas de segurança (somente leitura própria) ----------
-- Escrita exclusivamente por service_role. Nenhuma policy de INSERT/UPDATE/DELETE.
create policy "security_events_select_own" on public.security_events
  for select to authenticated using (user_id = auth.uid());

create policy "security_events_select_platform_admin" on public.security_events
  for select to authenticated using (public.is_platform_admin(auth.uid()));

create policy "security_lockouts_select_own" on public.security_lockouts
  for select to authenticated using (user_id = auth.uid());

create policy "password_reset_tokens_select_own" on public.password_reset_tokens
  for select to authenticated using (user_id = auth.uid());

create policy "two_factor_codes_select_own" on public.two_factor_codes
  for select to authenticated using (user_id = auth.uid());

-- ---------- Catálogo público da plataforma ----------
create policy "platform_plans_select_active" on public.platform_plans
  for select to authenticated using (ativo = true);

create policy "platform_plans_manage_platform_admin" on public.platform_plans
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

create policy "platform_modules_select_active" on public.platform_modules
  for select to authenticated using (ativo = true);

create policy "platform_modules_manage_platform_admin" on public.platform_modules
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

-- JUSTIFICATIVA DE `using (true)` (REGRA 12):
-- plan_module_access é o mapa "plano X libera módulo Y". É catálogo comercial
-- público — a mesma informação aparece na página de planos. Não contém dado de
-- usuário, de empresa nem valor financeiro. Leitura liberada a qualquer
-- autenticado é intencional; a escrita continua restrita ao admin da plataforma.
create policy "plan_module_access_select_public_catalog" on public.plan_module_access
  for select to authenticated using (true);

create policy "plan_module_access_manage_platform_admin" on public.plan_module_access
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

-- JUSTIFICATIVA DE `using (true)` (REGRA 12):
-- plan_model_limits define quantos modelos cada plano libera por categoria.
-- É regra comercial pública, exibida na comparação de planos. Sem dado pessoal.
create policy "plan_model_limits_select_public_catalog" on public.plan_model_limits
  for select to authenticated using (true);

create policy "plan_model_limits_manage_platform_admin" on public.plan_model_limits
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

create policy "plans_select_active" on public.plans
  for select to authenticated using (active = true);

create policy "plans_manage_platform_admin" on public.plans
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

create policy "project_categories_select_active" on public.project_categories
  for select to authenticated using (active = true);

create policy "project_categories_manage_platform_admin" on public.project_categories
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

create policy "project_models_select_active" on public.project_models
  for select to authenticated using (active = true);

create policy "project_models_manage_platform_admin" on public.project_models
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

-- ---------- company_module_access ----------
create policy "company_module_access_select_own" on public.company_module_access
  for select to authenticated using (user_id = auth.uid());

create policy "company_module_access_select_platform_admin" on public.company_module_access
  for select to authenticated using (public.is_platform_admin(auth.uid()));

create policy "company_module_access_manage_platform_admin" on public.company_module_access
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

-- ---------- user_subscriptions ----------
create policy "user_subscriptions_select_own" on public.user_subscriptions
  for select to authenticated using (user_id = auth.uid());

create policy "user_subscriptions_select_company_admin" on public.user_subscriptions
  for select to authenticated
  using (company_id is not null and public.is_company_admin(company_id, auth.uid()));

create policy "user_subscriptions_select_platform_admin" on public.user_subscriptions
  for select to authenticated using (public.is_platform_admin(auth.uid()));

-- REGRA 13: o assinante NÃO cria nem altera a própria assinatura.
create policy "user_subscriptions_manage_platform_admin" on public.user_subscriptions
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

-- ---------- Pagamentos (isolamento por empresa) ----------
create policy "payment_accounts_select_company" on public.payment_accounts
  for select to authenticated using (public.is_company_member(company_id, auth.uid()));

create policy "payment_accounts_manage_company_admin" on public.payment_accounts
  for all to authenticated
  using (public.is_company_admin(company_id, auth.uid()))
  with check (public.is_company_admin(company_id, auth.uid()));

create policy "charges_select_company" on public.charges
  for select to authenticated using (public.is_company_member(company_id, auth.uid()));

create policy "charges_insert_company" on public.charges
  for insert to authenticated with check (public.is_company_member(company_id, auth.uid()));

create policy "charges_update_company_admin" on public.charges
  for update to authenticated
  using (public.is_company_admin(company_id, auth.uid()))
  with check (public.is_company_admin(company_id, auth.uid()));

create policy "charges_delete_company_admin" on public.charges
  for delete to authenticated using (public.is_company_admin(company_id, auth.uid()));

create policy "payment_splits_select_company" on public.payment_splits
  for select to authenticated using (public.is_company_member(company_id, auth.uid()));

create policy "payment_splits_manage_company_admin" on public.payment_splits
  for all to authenticated
  using (public.is_company_admin(company_id, auth.uid()))
  with check (public.is_company_admin(company_id, auth.uid()));

create policy "recurring_charges_select_company" on public.recurring_charges
  for select to authenticated using (public.is_company_member(company_id, auth.uid()));

create policy "recurring_charges_manage_company_admin" on public.recurring_charges
  for all to authenticated
  using (public.is_company_admin(company_id, auth.uid()))
  with check (public.is_company_admin(company_id, auth.uid()));

-- ---------- Fiscal ----------
-- Diferença deliberada em relação à migration 20260703020000: o admin da
-- plataforma NÃO lê fiscal_settings.
-- O motivo original era `certificate_password` — coluna agora REMOVIDA (P-05).
-- A restrição é MANTIDA mesmo assim: a tabela continua guardando dado fiscal
-- identificável da empresa (CNPJ, inscrições, razão social) e nenhuma tela
-- precisa desse acesso. O painel da plataforma usa a view agregada
-- platform_fiscal_summary. Conceder leitura ao admin seria ampliar privilégio
-- sem consumidor — decisão adiada para quando houver necessidade real.
create policy "fiscal_settings_select_company" on public.fiscal_settings
  for select to authenticated using (public.is_company_member(company_id, auth.uid()));

create policy "fiscal_settings_manage_company_admin" on public.fiscal_settings
  for all to authenticated
  using (public.is_company_admin(company_id, auth.uid()))
  with check (public.is_company_admin(company_id, auth.uid()));

create policy "fiscal_invoices_select_company" on public.fiscal_invoices
  for select to authenticated using (public.is_company_member(company_id, auth.uid()));

create policy "fiscal_invoices_insert_company" on public.fiscal_invoices
  for insert to authenticated with check (public.is_company_member(company_id, auth.uid()));

create policy "fiscal_invoices_update_company_admin" on public.fiscal_invoices
  for update to authenticated
  using (public.is_company_admin(company_id, auth.uid()))
  with check (public.is_company_admin(company_id, auth.uid()));

create policy "fiscal_invoices_delete_company_admin" on public.fiscal_invoices
  for delete to authenticated using (public.is_company_admin(company_id, auth.uid()));

-- ---------- IA (restrito ao admin da plataforma) ----------
create policy "ai_system_settings_manage_platform_admin" on public.ai_system_settings
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

create policy "ai_generated_code_select_own" on public.ai_generated_code
  for select to authenticated using (user_id = auth.uid());

create policy "ai_generated_code_manage_own" on public.ai_generated_code
  for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "ai_generated_code_manage_platform_admin" on public.ai_generated_code
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

create policy "ai_dialog_sessions_manage_platform_admin" on public.ai_dialog_sessions
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

create policy "ai_dialog_messages_manage_platform_admin" on public.ai_dialog_messages
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

create policy "ai_dialog_suggestions_manage_platform_admin" on public.ai_dialog_suggestions
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

create policy "ai_dialog_previews_manage_platform_admin" on public.ai_dialog_action_previews
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));

create policy "ai_dialog_executions_manage_platform_admin" on public.ai_dialog_executions
  for all to authenticated
  using (public.is_platform_admin(auth.uid())) with check (public.is_platform_admin(auth.uid()));


-- =====================================================================
-- 12. GRANTS E REVOKES
-- =====================================================================

-- OBRIGATÓRIO, NÃO OPCIONAL.
-- O dump do projeto (tmp/supabase-antigo/public-schema.sql) mostra que existe
--   ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public
--     GRANT ALL ON TABLES / SEQUENCES / FUNCTIONS TO anon;
-- ou seja, TODA tabela nova nasce com ALL concedido ao papel anônimo.
-- Sem os REVOKEs abaixo, as 40 tabelas ficariam com GRANT para `anon`.
-- (A RLS ainda bloquearia a leitura por falta de policy para anon, mas depender
--  só disso é defesa única — aqui a defesa é dupla.)
-- ATENÇÃO: toda migration FUTURA que criar tabela precisa repetir o revoke,
-- ou o default privilege volta a conceder. Ver PENDENCIAS.md #P-22.
revoke all on all tables in schema public from anon;
revoke all on all sequences in schema public from anon;
revoke all on all functions in schema public from anon;

grant usage on schema public to authenticated, service_role;

-- DML para `authenticated`: o acesso efetivo é decidido pelas policies de RLS
-- acima. Sem GRANT não há como a policy sequer ser avaliada.
grant select, insert, update, delete on all tables in schema public to authenticated;
grant all on all tables in schema public to service_role;

grant usage, select on sequence public.quote_number_seq to authenticated, service_role;

-- --- EXECUTE das funções ------------------------------------------------
-- Padrão: revogar de todos e conceder explicitamente.
revoke all on function public.set_updated_at()                                        from public, anon, authenticated;
revoke all on function public.handle_new_user()                                       from public, anon, authenticated;

revoke all on function public.subscription_state(date, public.sub_status)             from public, anon;
grant execute on function public.subscription_state(date, public.sub_status)          to authenticated, service_role;

revoke all on function public.has_role(uuid, public.app_role)                         from public, anon;
grant execute on function public.has_role(uuid, public.app_role)                      to authenticated, service_role;

revoke all on function public.has_permission(uuid, text)                              from public, anon;
grant execute on function public.has_permission(uuid, text)                           to authenticated, service_role;

revoke all on function public.is_platform_admin(uuid)                                 from public, anon;
grant execute on function public.is_platform_admin(uuid)                              to authenticated, service_role;

revoke all on function public.is_company_member(uuid, uuid)                           from public, anon;
grant execute on function public.is_company_member(uuid, uuid)                        to authenticated, service_role;

revoke all on function public.is_company_admin(uuid, uuid)                            from public, anon;
grant execute on function public.is_company_admin(uuid, uuid)                         to authenticated, service_role;

revoke all on function public.is_company_owner(uuid, uuid)                            from public, anon;
grant execute on function public.is_company_owner(uuid, uuid)                         to authenticated, service_role;

revoke all on function public.get_user_plan(uuid)                                     from public, anon;
grant execute on function public.get_user_plan(uuid)                                  to authenticated, service_role;

revoke all on function public.can_access_model(text, text, integer, boolean)          from public, anon;
grant execute on function public.can_access_model(text, text, integer, boolean)       to authenticated, service_role;

revoke all on function public.company_payment_dashboard(uuid)                         from public, anon;
grant execute on function public.company_payment_dashboard(uuid)                      to authenticated, service_role;

revoke all on function public.company_fiscal_dashboard(uuid)                          from public, anon;
grant execute on function public.company_fiscal_dashboard(uuid)                       to authenticated, service_role;

revoke all on function public.generate_billing_notifications()                        from public, anon;
grant execute on function public.generate_billing_notifications()                     to authenticated, service_role;

grant usage on type public.app_role to authenticated, service_role;


-- =====================================================================
-- 13. VIEWS
-- security_invoker = true → a RLS das tabelas de origem continua valendo.
-- Sem isso a view seria uma DEFINER implícita e vazaria dados entre empresas.
-- =====================================================================

create view public.platform_payment_summary
with (security_invoker = true) as
select
  cp.id           as company_id,
  cp.company_name,
  pa.provider,
  pa.status       as account_status,
  count(c.id)                                       as total_charges,
  coalesce(sum(c.amount), 0)                        as gross_amount,
  coalesce(sum(c.platform_fee), 0)                  as platform_fees,
  coalesce(avg(c.amount), 0)                        as avg_ticket,
  count(*) filter (where c.status = 'failed')       as failed_charges,
  count(*) filter (where c.status = 'paid')         as paid_charges
from public.company_profiles cp
left join public.payment_accounts pa on pa.company_id = cp.id
left join public.charges c            on c.company_id = cp.id
group by cp.id, cp.company_name, pa.provider, pa.status;

create view public.platform_fiscal_summary
with (security_invoker = true) as
select
  cp.id           as company_id,
  cp.company_name,
  fs.provider,
  fs.environment,
  count(fi.id) filter (where fi.status = 'authorized')  as authorized_invoices,
  count(fi.id) filter (where fi.status = 'rejected')    as rejected_invoices,
  count(fi.id) filter (where fi.status = 'processing')  as processing_invoices,
  coalesce(sum(fi.total_amount) filter (where fi.status = 'authorized'), 0) as authorized_amount
from public.company_profiles cp
left join public.fiscal_settings fs  on fs.company_id = cp.id
left join public.fiscal_invoices fi  on fi.company_id = cp.id
group by cp.id, cp.company_name, fs.provider, fs.environment;

grant select on public.platform_payment_summary to authenticated;
grant select on public.platform_fiscal_summary  to authenticated;

-- ATENÇÃO: com security_invoker = true, o admin da plataforma vê estas views
-- FILTRADAS pela RLS de charges/fiscal_invoices — ou seja, vazias, pois ele não
-- é membro das empresas. A visão agregada da plataforma exige uma decisão
-- explícita. Ver PENDENCIAS.md #P-08.


-- =====================================================================
-- 14. COMENTÁRIOS DE SEGURANÇA (persistidos no catálogo)
-- =====================================================================

comment on table public.user_roles is
  'Papéis de plataforma. Escrita restrita ao admin por policy permissiva + RESTRICTIVE. Nunca conceder INSERT a authenticated.';
comment on table public.audit_logs is
  'Trilha de auditoria. Leitura somente para admin da plataforma; escrita exclusiva via service_role. Nenhuma policy de INSERT para anon ou authenticated. Nunca gravar senha, token, chave ou credencial em metadata. Ver PENDENCIAS.md #P-07.';
comment on table public.server_logs is
  'Registro do servidor. Escrita exclusiva via service_role — nenhuma policy de INSERT para anon ou authenticated. Nunca gravar senha, token, chave ou credencial em message/metadata. Ver PENDENCIAS.md #P-07.';
comment on table public.auth_events is
  'Eventos de autenticação. Escrita exclusiva via service_role — nenhuma policy de INSERT para anon ou authenticated. Guarda e-mail e user_agent; NUNCA senha, token de sessão ou código de verificação. Ver PENDENCIAS.md #P-07.';
comment on table public.security_events is
  'Eventos de recuperação de acesso. Leitura do próprio usuário e do admin da plataforma; escrita exclusiva via service_role. Nunca gravar senha nem o código de verificação em claro. Ver PENDENCIAS.md #P-07.';
comment on table public.fiscal_settings is
  'Configuracao fiscal por empresa. NAO guarda segredo: a coluna certificate_password foi removida (P-05) e nao ha substituta cifrada nem secret_id. A senha do certificado A1 so voltara a existir no Vault, gravada e lida apenas pelo servidor. Nunca adicionar coluna de senha aqui.';
comment on function public.handle_new_user() is
  'Cria profile e atribui SEMPRE o papel vendedor. Promocao a admin e manual e explicita.';
comment on function public.has_role(uuid, public.app_role) is
  'SECURITY DEFINER. Retorna false quando _user_id difere de auth.uid() em contexto de cliente.';


-- =====================================================================
-- 15. REVOKES FINAIS DE `anon` — ÚLTIMO PASSO EXECUTÁVEL
--
-- POR QUE ESTA SEÇÃO EXISTE (defeito encontrado no 1º teste local):
--   Os REVOKEs da §12 rodam ANTES de as views da §13 existirem. Como o projeto
--   Supabase tem
--     ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public
--       GRANT ALL ON TABLES / SEQUENCES / FUNCTIONS TO anon;
--   as duas views nasceram com privilégios residuais para `anon`
--   (TRUNCATE, REFERENCES, TRIGGER — verificado em pg_catalog).
--   Não havia exposição de dados (SELECT nunca foi concedido), mas o estado
--   final contrariava o princípio de negação por padrão.
--
--   `ALL TABLES IN SCHEMA` abrange tabelas E VIEWS. Repetir os REVOKEs aqui,
--   depois que TODOS os objetos de `public` já existem, fecha a janela.
--
-- REGRA PARA O FUTURO: toda migration que criar tabela, view, sequência ou
-- função em `public` deve terminar repetindo este bloco, ou o ALTER DEFAULT
-- PRIVILEGES volta a conceder privilégio a `anon`. Ver PENDENCIAS.md #P-22.
--
-- Esta seção NÃO altera policies, RLS, isolamento por usuário/empresa, nem os
-- privilégios de `authenticated` e `service_role`.
-- =====================================================================

-- Abrange as 40 tabelas E as 2 views (platform_payment_summary,
-- platform_fiscal_summary), que na §12 ainda não existiam.
revoke all on all tables in schema public from anon;

-- Sequências: `anon` não deve consumir quote_number_seq.
revoke all on all sequences in schema public from anon;

-- Nenhuma função de `public` é pública nesta aplicação. Inclui funções
-- provisionadas pela plataforma que porventura existam no schema (ex.:
-- rls_auto_enable), cuja execução por `anon` também não é desejada.
revoke all on all functions in schema public from anon;

-- --- Reafirmação explícita dos papéis que DEVEM funcionar -------------
-- As views são criadas na §13, depois do `grant ... to service_role` da §12;
-- sem estas linhas o service_role dependeria do ALTER DEFAULT PRIVILEGES.
grant select on public.platform_payment_summary to authenticated;
grant select on public.platform_fiscal_summary  to authenticated;
grant all    on public.platform_payment_summary to service_role;
grant all    on public.platform_fiscal_summary  to service_role;


-- =====================================================================
-- 16. >>> SEÇÃO SEPARADA — REVISÃO MANUAL ANTES DE ATIVAR <<<
--
-- Nada abaixo é executado: está comentado de propósito.
-- Estes gatilhos alteram o comportamento de cadastro e de auth.users.
-- Ative somente após validar o fluxo de signup no ambiente local.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 16.1 Criação automática de profile no signup
-- Depende de: public.handle_new_user() (já definida na §8).
-- Sem este gatilho, nenhum profile é criado e o app não encontra o usuário.
-- Descomente APÓS revisar handle_new_user().
-- ---------------------------------------------------------------------
-- create trigger on_auth_user_created
--   after insert on auth.users
--   for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- 16.2 Catálogo inicial de 13 project_templates por usuário
-- A migration antiga 20260519032738 embutia 13 linhas de produto dentro de uma
-- função SECURITY DEFINER disparada por profiles. Isso é dado de catálogo em
-- lugar de código e NÃO foi portado para esta baseline.
-- Decisão pendente (PENDENCIAS.md #P-09): transformar em tabela de catálogo
-- global + cópia sob demanda, ou recriar o gatilho.
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- 16.3 PRIMEIRO ADMINISTRADOR — OPERAÇÃO MANUAL E EXPLÍCITA
--
-- Esta baseline NÃO promove ninguém a admin automaticamente.
-- Procedimento correto, executado UMA vez, por um humano:
--
--   1. Criar o usuário pelo Dashboard do Supabase (Authentication > Users)
--      ou pela Auth Admin API. NUNCA por migration.
--   2. Copiar o UUID do usuário no Dashboard.
--   3. No SQL Editor do projeto, executar manualmente:
--
--        insert into public.user_roles (user_id, role)
--        values ('<COLE-O-UUID-AQUI>', 'admin');
--
--   4. Conferir: select * from public.user_roles where role = 'admin';
--   5. Registrar quem executou e quando, fora do repositório.
--
-- Não versionar o UUID, o e-mail nem a senha deste usuário.
-- ---------------------------------------------------------------------

-- ===================== FIM DA BASELINE CANDIDATA =====================
