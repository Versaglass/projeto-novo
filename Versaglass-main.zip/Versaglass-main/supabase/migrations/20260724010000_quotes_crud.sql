-- =====================================================================
-- Orcamentos — persistencia atomica de quote + quote_items.
--
-- Motivo: criar/editar um orcamento envolve o cabecalho (quotes) + varios itens
-- (quote_items) + o total. Feito com INSERTs separados no navegador, uma falha
-- parcial deixa orcamento sem itens (ou com total errado) e sem rollback; alem
-- disso o total nao pode ser confiado ao cliente. Esta RPC faz tudo na MESMA
-- transacao e RECALCULA o total no banco.
--
-- Seguranca (mesmo padrao de create_company_with_owner e das is_company_*):
--   * SECURITY DEFINER com search_path travado; ignora RLS, entao valida tudo
--     manualmente aqui.
--   * Identidade SEMPRE de auth.uid(); owner_id nunca vem do cliente.
--   * Empresa validada por is_company_member; cliente precisa pertencer a MESMA
--     empresa; editar exige dono ou is_company_admin (espelha as policies).
--   * company_id enviado pelo cliente NAO e autorizacao — e checado contra a
--     membership; um id forjado falha.
--
-- Nao altera nenhuma policy, RLS, tabela, tipo, sequencia ou dado. Nenhum dado
-- demonstrativo. Nao recria tabelas nem toca migrations anteriores.
-- =====================================================================

create or replace function public.save_quote_with_items(
  p_company_id    uuid,
  p_customer_id   uuid,
  p_items         jsonb,
  p_quote_id      uuid                 default null,   -- null = criar; senao editar
  p_status        public.quote_status  default 'rascunho',
  p_observacoes   text                 default null,
  p_desconto      numeric              default 0,
  p_acrescimo     numeric              default 0,
  p_validade_dias integer              default 15
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid   uuid := auth.uid();
  v_qid   uuid := p_quote_id;
  v_desc  numeric := round(coalesce(p_desconto, 0), 2);
  v_acr   numeric := round(coalesce(p_acrescimo, 0), 2);
  v_val   integer := coalesce(p_validade_dias, 15);
  v_sum   numeric := 0;
  v_total numeric;
  v_count integer;
  v_item  jsonb;
  v_idx   integer := 0;
  v_desc_txt text;
  v_larg  numeric;
  v_alt   numeric;
  v_qtd   integer;
  v_preco numeric;
  v_m2    numeric;
  v_sub   numeric;
begin
  -- Identidade obrigatoria da sessao.
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  -- Empresa: precisa ser membro ativo (criador conta como owner implicito).
  if p_company_id is null or not public.is_company_member(p_company_id, v_uid) then
    raise exception 'Empresa invalida ou sem permissao.' using errcode = '42501';
  end if;

  -- Cliente precisa pertencer a MESMA empresa (evita vincular cliente de outra).
  if not exists (
    select 1 from public.customers c
    where c.id = p_customer_id and c.company_id = p_company_id
  ) then
    raise exception 'Cliente nao pertence a empresa ativa.' using errcode = '23503';
  end if;

  -- Itens: array com 1..200 elementos.
  if p_items is null or jsonb_typeof(p_items) <> 'array' then
    raise exception 'Itens invalidos.' using errcode = '22023';
  end if;
  v_count := jsonb_array_length(p_items);
  if v_count < 1 or v_count > 200 then
    raise exception 'O orcamento deve ter de 1 a 200 itens.' using errcode = '22023';
  end if;

  -- Desconto e acrescimo nao podem ser negativos.
  if v_desc < 0 or v_acr < 0 then
    raise exception 'Desconto e acrescimo nao podem ser negativos.' using errcode = '22023';
  end if;
  if v_val < 0 then v_val := 0; end if;

  -- Edicao: o orcamento precisa ser da empresa e do dono ou de um admin dela.
  if v_qid is not null then
    if not exists (
      select 1 from public.quotes q
      where q.id = v_qid
        and q.company_id = p_company_id
        and (q.owner_id = v_uid or public.is_company_admin(p_company_id, v_uid))
    ) then
      raise exception 'Orcamento nao encontrado ou sem permissao.' using errcode = '42501';
    end if;
  end if;

  -- Cabecalho (total provisorio 0; recalculado ao final). numero/etapa usam os
  -- defaults na criacao e sao preservados na edicao.
  if v_qid is null then
    insert into public.quotes
      (owner_id, company_id, customer_id, status, observacoes, desconto, acrescimo, validade_dias, total)
    values
      (v_uid, p_company_id, p_customer_id, p_status,
       nullif(btrim(coalesce(p_observacoes, '')), ''), v_desc, v_acr, v_val, 0)
    returning id into v_qid;
  else
    update public.quotes set
      customer_id   = p_customer_id,
      status        = p_status,
      observacoes   = nullif(btrim(coalesce(p_observacoes, '')), ''),
      desconto      = v_desc,
      acrescimo     = v_acr,
      validade_dias = v_val
    where id = v_qid;
    -- Recalculo integral: remove os itens antigos e regrava.
    delete from public.quote_items where quote_id = v_qid;
  end if;

  -- Itens validados; subtotal e m2 calculados no banco (largura/altura em METROS).
  for v_item in select value from jsonb_array_elements(p_items)
  loop
    v_desc_txt := nullif(btrim(coalesce(v_item->>'descricao', '')), '');
    v_larg  := coalesce((v_item->>'largura')::numeric, 0);
    v_alt   := coalesce((v_item->>'altura')::numeric, 0);
    v_qtd   := coalesce((v_item->>'quantidade')::integer, 0);
    v_preco := coalesce((v_item->>'preco_unit')::numeric, 0);

    if v_desc_txt is null then
      raise exception 'Item % sem descricao.', v_idx + 1 using errcode = '22023';
    end if;
    if v_qtd <= 0 then
      raise exception 'Item % com quantidade invalida.', v_idx + 1 using errcode = '22023';
    end if;
    if v_larg < 0 or v_alt < 0 or v_preco < 0 then
      raise exception 'Item % com valor negativo.', v_idx + 1 using errcode = '22023';
    end if;

    v_m2  := round(v_larg * v_alt * v_qtd, 4);
    v_sub := round(v_m2 * v_preco, 2);
    v_sum := v_sum + v_sub;

    insert into public.quote_items
      (quote_id, company_id, descricao, largura, altura, quantidade, m2, preco_unit, subtotal, ordem)
    values
      (v_qid, p_company_id, v_desc_txt, round(v_larg, 3), round(v_alt, 3),
       v_qtd, v_m2, round(v_preco, 2), v_sub, v_idx);

    v_idx := v_idx + 1;
  end loop;

  -- Total definitivo no banco: desconto nunca leva a total negativo.
  v_total := greatest(0, round(v_sum - v_desc + v_acr, 2));
  update public.quotes set total = v_total where id = v_qid;

  return v_qid;
end;
$$;

comment on function public.save_quote_with_items(uuid, uuid, jsonb, uuid, public.quote_status, text, numeric, numeric, integer)
  is 'Cria/edita um orcamento (quotes) e seus itens (quote_items) de forma atomica. Identidade de auth.uid(); valida membership da empresa e cliente-na-empresa; edicao exige dono ou admin. Recalcula subtotais e total no banco.';

-- Somente autenticados executam; anon nunca.
revoke all on function public.save_quote_with_items(uuid, uuid, jsonb, uuid, public.quote_status, text, numeric, numeric, integer) from public;
revoke all on function public.save_quote_with_items(uuid, uuid, jsonb, uuid, public.quote_status, text, numeric, numeric, integer) from anon;
grant execute on function public.save_quote_with_items(uuid, uuid, jsonb, uuid, public.quote_status, text, numeric, numeric, integer) to authenticated;
