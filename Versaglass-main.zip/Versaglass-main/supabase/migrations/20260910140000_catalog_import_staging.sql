-- =====================================================================
-- 20260910140000_catalog_import_staging.sql
--
-- Fase 2 — Staging da Importação de Catálogo com IA.
--
-- Domínio: jobs/itens TEMPORÁRIOS do Super Admin.
-- NÃO publica em manufacturer_products / product_manufacturers.
-- NÃO mistura com manufacturer-catalog (bucket final).
--
-- Bucket: manufacturer-catalog-staging
--   · privado
--   · ZIP até 50 MiB (alinhado a config.toml [storage] file_size_limit)
--   · imagens jpeg/png/webp até 5 MiB (file_size_limit do bucket = teto ZIP)
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. JOBS
-- ---------------------------------------------------------------------
create table public.catalog_import_jobs (
  id                            uuid primary key default gen_random_uuid(),
  created_by                    uuid not null references auth.users(id) on delete cascade,

  original_filename             text not null,
  declared_size_bytes           bigint not null,
  storage_path                  text not null,
  storage_bucket                text not null default 'manufacturer-catalog-staging',

  manufacturer_name             text,
  normalized_manufacturer_name  text,
  existing_manufacturer_id      uuid references public.product_manufacturers(id) on delete set null,

  catalog_name                  text,
  catalog_date                  text,
  source_filename               text,
  schema_version                text,

  status                        text not null default 'awaiting_upload'
    constraint catalog_import_jobs_status_check check (
      status in (
        'awaiting_upload',
        'processing',
        'ready',
        'failed',
        'completed',
        'cancelled'
      )
    ),

  total_items                   integer not null default 0,
  valid_items                   integer not null default 0,
  review_items                  integer not null default 0,
  duplicate_items               integer not null default 0,
  invalid_items                 integer not null default 0,

  warnings                      jsonb not null default '[]'::jsonb,
  error_message                 text,
  error_code                    text,

  actual_size_bytes             bigint,
  processed_at                  timestamptz,

  created_at                    timestamptz not null default now(),
  updated_at                    timestamptz not null default now(),

  constraint catalog_import_jobs_declared_size_nonneg check (declared_size_bytes >= 0),
  constraint catalog_import_jobs_actual_size_nonneg
    check (actual_size_bytes is null or actual_size_bytes >= 0),
  constraint catalog_import_jobs_counts_nonneg check (
    total_items >= 0
    and valid_items >= 0
    and review_items >= 0
    and duplicate_items >= 0
    and invalid_items >= 0
  ),
  constraint catalog_import_jobs_warnings_is_array
    check (jsonb_typeof(warnings) = 'array'),
  constraint catalog_import_jobs_filename_len
    check (char_length(btrim(original_filename)) >= 1),
  constraint catalog_import_jobs_storage_path_len
    check (char_length(btrim(storage_path)) >= 1)
);

comment on table public.catalog_import_jobs is
  'Jobs de importação de catálogo (staging). Escrita/leitura: is_platform_admin. Sem company_id.';

comment on column public.catalog_import_jobs.storage_path is
  'Path gerado pelo servidor (ex.: imports/{jobId}/source.zip). Nunca confiar em path do cliente.';

comment on column public.catalog_import_jobs.declared_size_bytes is
  'Tamanho informado pelo browser (UX). Autoridade: actual_size_bytes do Storage.';

create index catalog_import_jobs_created_by_idx
  on public.catalog_import_jobs (created_by);

create index catalog_import_jobs_status_idx
  on public.catalog_import_jobs (status);

create index catalog_import_jobs_created_at_idx
  on public.catalog_import_jobs (created_at desc);

create trigger catalog_import_jobs_updated_at
  before update on public.catalog_import_jobs
  for each row execute function public.set_updated_at();

alter table public.catalog_import_jobs enable row level security;

create policy "catalog_import_jobs_select_platform_admin"
  on public.catalog_import_jobs for select to authenticated
  using (public.is_platform_admin(auth.uid()));

create policy "catalog_import_jobs_insert_platform_admin"
  on public.catalog_import_jobs for insert to authenticated
  with check (
    public.is_platform_admin(auth.uid())
    and created_by = auth.uid()
  );

create policy "catalog_import_jobs_update_platform_admin"
  on public.catalog_import_jobs for update to authenticated
  using (public.is_platform_admin(auth.uid()))
  with check (public.is_platform_admin(auth.uid()));

create policy "catalog_import_jobs_delete_platform_admin"
  on public.catalog_import_jobs for delete to authenticated
  using (public.is_platform_admin(auth.uid()));

revoke all on table public.catalog_import_jobs from public, anon;
grant select, insert, update, delete on table public.catalog_import_jobs
  to authenticated, service_role;

-- ---------------------------------------------------------------------
-- 2. ITENS DE STAGING
-- ---------------------------------------------------------------------
create table public.catalog_import_items (
  id                            uuid primary key default gen_random_uuid(),
  import_job_id                 uuid not null
                                  references public.catalog_import_jobs(id) on delete cascade,
  position                      integer not null,

  source_code                   text,
  normalized_source_code        text,
  base_code                     text,

  name                          text,
  description                   text,

  product_type                  text,
  product_line                  text,

  suggested_category            text,
  suggested_inventory_category  public.inventory_category,
  unit                          public.inventory_unit,

  source_page                   integer,
  source_excerpt                text,

  primary_image_staging_path    text,
  technical_image_staging_paths jsonb not null default '[]'::jsonb,

  attributes                    jsonb not null default '[]'::jsonb,
  observations                  jsonb not null default '[]'::jsonb,

  ai_review_required            boolean not null default false,
  ai_warnings                   jsonb not null default '[]'::jsonb,

  validation_status             text not null
    constraint catalog_import_items_validation_status_check check (
      validation_status in ('valid', 'review', 'duplicate', 'invalid')
    ),
  validation_errors             jsonb not null default '[]'::jsonb,

  duplicate_product_id          uuid
                                  references public.manufacturer_products(id) on delete set null,

  raw_manifest_item             jsonb not null default '{}'::jsonb,

  created_at                    timestamptz not null default now(),
  updated_at                    timestamptz not null default now(),

  constraint catalog_import_items_position_positive check (position >= 1),
  constraint catalog_import_items_source_page_positive
    check (source_page is null or source_page > 0),
  constraint catalog_import_items_tech_paths_is_array
    check (jsonb_typeof(technical_image_staging_paths) = 'array'),
  constraint catalog_import_items_attributes_is_array
    check (jsonb_typeof(attributes) = 'array'),
  constraint catalog_import_items_observations_is_array
    check (jsonb_typeof(observations) = 'array'),
  constraint catalog_import_items_ai_warnings_is_array
    check (jsonb_typeof(ai_warnings) = 'array'),
  constraint catalog_import_items_validation_errors_is_array
    check (jsonb_typeof(validation_errors) = 'array'),
  constraint catalog_import_items_job_position_uq unique (import_job_id, position)
);

comment on table public.catalog_import_items is
  'Itens em staging de importação. Escrita/leitura: is_platform_admin. Não é manufacturer_products.';

create index catalog_import_items_job_id_idx
  on public.catalog_import_items (import_job_id);

create index catalog_import_items_job_status_idx
  on public.catalog_import_items (import_job_id, validation_status);

create trigger catalog_import_items_updated_at
  before update on public.catalog_import_items
  for each row execute function public.set_updated_at();

alter table public.catalog_import_items enable row level security;

create policy "catalog_import_items_select_platform_admin"
  on public.catalog_import_items for select to authenticated
  using (public.is_platform_admin(auth.uid()));

create policy "catalog_import_items_insert_platform_admin"
  on public.catalog_import_items for insert to authenticated
  with check (public.is_platform_admin(auth.uid()));

create policy "catalog_import_items_update_platform_admin"
  on public.catalog_import_items for update to authenticated
  using (public.is_platform_admin(auth.uid()))
  with check (public.is_platform_admin(auth.uid()));

create policy "catalog_import_items_delete_platform_admin"
  on public.catalog_import_items for delete to authenticated
  using (public.is_platform_admin(auth.uid()));

revoke all on table public.catalog_import_items from public, anon;
grant select, insert, update, delete on table public.catalog_import_items
  to authenticated, service_role;

-- ---------------------------------------------------------------------
-- 3. STORAGE — manufacturer-catalog-staging
--
-- Paths:
--   imports/{jobId}/source.zip
--   imports/{jobId}/items/{itemId}/primary.{ext}
--   imports/{jobId}/items/{itemId}/technical/{uuid}.{ext}
--
-- file_size_limit 50 MiB = teto do ZIP (config.toml global).
-- Imagens individuais são validadas em app para ≤ 5 MiB.
-- MIME allowlist inclui ZIP + imagens (mesmo bucket, paths isolados).
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'manufacturer-catalog-staging',
  'manufacturer-catalog-staging',
  false,
  52428800,
  array[
    'application/zip',
    'application/x-zip-compressed',
    'application/octet-stream',
    'image/jpeg',
    'image/png',
    'image/webp'
  ]
)
on conflict (id) do nothing;

create policy "mfg_catalog_staging_select_platform_admin"
  on storage.objects for select to authenticated
  using (
    bucket_id = 'manufacturer-catalog-staging'
    and public.is_platform_admin(auth.uid())
  );

create policy "mfg_catalog_staging_insert_platform_admin"
  on storage.objects for insert to authenticated
  with check (
    bucket_id = 'manufacturer-catalog-staging'
    and public.is_platform_admin(auth.uid())
  );

create policy "mfg_catalog_staging_update_platform_admin"
  on storage.objects for update to authenticated
  using (
    bucket_id = 'manufacturer-catalog-staging'
    and public.is_platform_admin(auth.uid())
  )
  with check (
    bucket_id = 'manufacturer-catalog-staging'
    and public.is_platform_admin(auth.uid())
  );

create policy "mfg_catalog_staging_delete_platform_admin"
  on storage.objects for delete to authenticated
  using (
    bucket_id = 'manufacturer-catalog-staging'
    and public.is_platform_admin(auth.uid())
  );
