-- =====================================================================
-- 20260727070000_project_templates_project_data.sql
--
-- Onde o desenho paramétrico do modelo técnico passa a morar.
--
-- ANTES: o ParametricProjectEditor gravava o estado em `localStorage` (some ao
-- trocar de navegador) e, no "Salvar como novo", enfiava
-- `{"editor":"realistic-2d-3d","state":{...}}` dentro de `observacoes` — uma
-- coluna de texto humano que acaba impressa no orçamento. Nenhum dos dois é
-- lugar de geometria.
--
-- AGORA: coluna própria, `project_data jsonb`, NULL enquanto o modelo não tiver
-- desenho. `observacoes` volta a ser exclusivamente texto de gente.
--
-- AUDITORIA DE DADOS ANTIGOS (leitura por service_role, 2026-07-27, somente
-- contagens):
--   remoto: 1 project_template · observacoes NULL 1 · com o padrao antigo
--   {"editor":"realistic-2d-3d"} 0 · outro JSON em observacoes 0
-- Não há nada a migrar; nenhum backfill é executado nesta migration.
--
-- DIVISÃO DE RESPONSABILIDADE NA VALIDAÇÃO
--   O banco valida só o ENVELOPE: é objeto, tem versão numérica suportada e
--   cabe no limite de tamanho. A forma de cada peça é validada em TypeScript
--   (`src/types/project-data.ts`), compartilhada por leitura e escrita. Fixar
--   o schema de peça em CHECK engessaria o editor: qualquer campo novo exigiria
--   migration, e o editor evolui a cada etapa.
--
-- Não altera observacoes, RLS, policies, nem qualquer outra coluna.
-- Não cria default artificial: modelo sem desenho é NULL, e NULL quer dizer
-- exatamente isso.
-- =====================================================================

alter table public.project_templates
  add column if not exists project_data jsonb;

comment on column public.project_templates.project_data is
  'Desenho parametrico do modelo (formato ProjectDataV1). NULL = modelo sem desenho. Dimensoes e coordenadas em MILIMETROS (largura_padrao/altura_padrao continuam em METROS). Validacao detalhada em src/types/project-data.ts.';


-- ---------------------------------------------------------------------
-- Constraints do envelope.
--
-- Todas aceitam NULL: modelo sem desenho não é modelo inválido.
--
-- 1. OBJETO — recusa array, número, string e booleano na raiz. O editor lê
--    `project_data.pecas`; um array na raiz produziria `undefined` e a tela
--    renderizaria um desenho vazio sem nenhum aviso.
-- 2. TAMANHO — 256 KB por modelo, medidos em BYTES sobre o JSON em texto
--    (`octet_length(project_data::text)`). Duas escolhas deliberadas:
--      · não se usa `pg_column_size`, que mede o valor já comprimido pelo TOAST
--        — o limite efetivo variaria com a compressibilidade e um mesmo JSON
--        poderia passar ou não;
--      · não se usa `length`, que conta CARACTERES: nomes de peça com acento
--        ou "²" ocupam 2 bytes em UTF-8, então `length` deixaria passar um JSON
--        maior que o limite real. `octet_length` é a mesma unidade que o
--        frontend mede (`TextEncoder` em project-data.ts) e os dois concordam.
-- 3. VERSÃO — exige `versao` INTEIRA e IGUAL A 1, que é a única versão que a
--    aplicação sabe ler hoje. Aceitar "qualquer número" deixaria entrar `1.5`
--    ou `7` e o erro só apareceria na tela, ao tentar interpretar o desenho.
--    Quando existir `versao: 2`, esta constraint é ampliada por migration
--    própria, junto com a função de migração do formato — que é exatamente o
--    momento em que se quer revisar isso.
--    `coalesce` é ESSENCIAL: com a chave ausente, `project_data -> 'versao'`
--    é SQL NULL, `jsonb_typeof(NULL)` também é NULL, e um CHECK que resulta em
--    NULL é considerado SATISFEITO — ou seja, sem o coalesce a constraint
--    deixaria passar exatamente o caso que ela existe para barrar.
-- ---------------------------------------------------------------------
do $$
declare v_invalidas integer;
begin
  select count(*) into v_invalidas
    from public.project_templates
   where project_data is not null
     and (jsonb_typeof(project_data) <> 'object'
          or coalesce(jsonb_typeof(project_data -> 'versao'), 'ausente') <> 'number'
          or (project_data -> 'versao') <> to_jsonb(1)
          or octet_length(project_data::text) > 262144);
  if v_invalidas > 0 then
    raise exception
      'Existem % project_templates com project_data fora do formato esperado. Trate antes de aplicar esta migration.',
      v_invalidas using errcode = '23514';
  end if;
end $$;

alter table public.project_templates
  add constraint project_templates_project_data_object
    check (project_data is null or jsonb_typeof(project_data) = 'object'),
  add constraint project_templates_project_data_size
    check (project_data is null or octet_length(project_data::text) <= 262144),
  add constraint project_templates_project_data_version
    check (project_data is null
           or (coalesce(jsonb_typeof(project_data -> 'versao'), 'ausente') = 'number'
               and (project_data -> 'versao') = to_jsonb(1)));
