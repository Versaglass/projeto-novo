-- =====================================================================
-- 20260910170000_catalog_import_publish_hardening.sql
--
-- Hardening Fase 3:
-- - fabricante novo criado SOMENTE dentro da RPC (transação);
-- - resolução a partir do job (não confiar em manufacturer_id arbitrário);
-- - retorno estruturado por item (published | duplicate).
-- NÃO altera 20260910160000.
-- =====================================================================

create or replace function public.publish_catalog_import_batch(
  p_job_id uuid,
  p_manufacturer_id uuid,
  p_new_manufacturer_name text,
  p_new_manufacturer_normalized_name text,
  p_products jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_job record;
  v_mfg_id uuid;
  v_mfg_name text;
  v_norm_mfg text;
  v_item jsonb;
  v_prod_id uuid;
  v_item_id uuid;
  v_norm_code text;
  v_existing uuid;
  v_rowcount integer;
  v_items jsonb := '[]'::jsonb;
  v_pub_count integer := 0;
  v_dup_count integer := 0;
  v_approved integer := 0;
  v_rejected integer := 0;
  v_total integer := 0;
  v_invalid integer := 0;
  v_duplicate_items integer := 0;
  v_new_name text;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if not public.is_platform_admin(v_uid) then
    raise exception 'Apenas Super Admin da plataforma.' using errcode = '42501';
  end if;

  select * into v_job
  from public.catalog_import_jobs j
  where j.id = p_job_id
  for update;

  if not found then
    raise exception 'Importacao nao encontrada.' using errcode = 'P0002';
  end if;

  if v_job.status <> 'publishing' then
    raise exception 'Job nao esta em publishing.' using errcode = '22023';
  end if;

  if p_products is null or jsonb_typeof(p_products) <> 'array' then
    raise exception 'Produtos invalidos.' using errcode = '22023';
  end if;

  if jsonb_array_length(p_products) < 1 then
    raise exception 'Nenhum produto aprovado para publicar.' using errcode = '22023';
  end if;

  -- ---------------------------------------------------------------------
  -- Fabricante: autoridade = resolução do job (não p_manufacturer_id solto)
  -- ---------------------------------------------------------------------
  if v_job.resolved_manufacturer_id is not null then
    if p_manufacturer_id is not null and p_manufacturer_id is distinct from v_job.resolved_manufacturer_id then
      raise exception 'Fabricante informado nao corresponde a resolucao do job.' using errcode = '22023';
    end if;

    select m.id, m.name into v_mfg_id, v_mfg_name
    from public.product_manufacturers m
    where m.id = v_job.resolved_manufacturer_id;

    if v_mfg_id is null then
      raise exception 'Fabricante resolvido nao existe.' using errcode = '22023';
    end if;

  elsif nullif(btrim(coalesce(v_job.resolved_manufacturer_name, '')), '') is not null then
    v_new_name := btrim(v_job.resolved_manufacturer_name);
    if p_new_manufacturer_name is not null
       and btrim(p_new_manufacturer_name) is distinct from v_new_name then
      raise exception 'Nome do fabricante nao corresponde a resolucao do job.' using errcode = '22023';
    end if;

    v_mfg_name := v_new_name;
    v_norm_mfg := nullif(btrim(coalesce(p_new_manufacturer_normalized_name, '')), '');
    if v_norm_mfg is null then
      raise exception 'normalized_name do fabricante obrigatorio.' using errcode = '22023';
    end if;

    insert into public.product_manufacturers (name, normalized_name, active)
    values (v_mfg_name, v_norm_mfg, true)
    on conflict (normalized_name) do nothing
    returning id into v_mfg_id;

    if v_mfg_id is null then
      select m.id, m.name into v_mfg_id, v_mfg_name
      from public.product_manufacturers m
      where m.normalized_name = v_norm_mfg;
    end if;

    if v_mfg_id is null then
      raise exception 'Falha ao resolver fabricante.' using errcode = 'P0001';
    end if;

  elsif v_job.existing_manufacturer_id is not null then
    if p_manufacturer_id is not null and p_manufacturer_id is distinct from v_job.existing_manufacturer_id then
      raise exception 'Fabricante informado nao corresponde ao fabricante detectado.' using errcode = '22023';
    end if;

    select m.id, m.name into v_mfg_id, v_mfg_name
    from public.product_manufacturers m
    where m.id = v_job.existing_manufacturer_id;

    if v_mfg_id is null then
      raise exception 'Fabricante detectado nao existe.' using errcode = '22023';
    end if;

  elsif nullif(btrim(coalesce(v_job.manufacturer_name, '')), '') is not null then
    v_mfg_name := btrim(v_job.manufacturer_name);
    v_norm_mfg := nullif(btrim(coalesce(p_new_manufacturer_normalized_name, '')), '');
    if v_norm_mfg is null then
      raise exception 'normalized_name do fabricante obrigatorio.' using errcode = '22023';
    end if;

    insert into public.product_manufacturers (name, normalized_name, active)
    values (v_mfg_name, v_norm_mfg, true)
    on conflict (normalized_name) do nothing
    returning id into v_mfg_id;

    if v_mfg_id is null then
      select m.id, m.name into v_mfg_id, v_mfg_name
      from public.product_manufacturers m
      where m.normalized_name = v_norm_mfg;
    end if;

    if v_mfg_id is null then
      raise exception 'Falha ao resolver fabricante.' using errcode = 'P0001';
    end if;

  else
    raise exception 'Fabricante nao resolvido.' using errcode = '22023';
  end if;

  for v_item in select value from jsonb_array_elements(p_products)
  loop
    v_item_id := nullif(v_item->>'staging_item_id', '')::uuid;
    v_prod_id := nullif(v_item->>'product_id', '')::uuid;
    v_norm_code := nullif(btrim(coalesce(v_item->>'normalized_source_code', '')), '');

    if v_item_id is null or v_prod_id is null or v_norm_code is null then
      raise exception 'Payload de produto incompleto.' using errcode = '22023';
    end if;

    if not exists (
      select 1 from public.catalog_import_items i
      where i.id = v_item_id
        and i.import_job_id = p_job_id
        and i.review_decision = 'approved'
        and i.validation_status in ('valid', 'review')
    ) then
      raise exception 'Item nao aprovado para publicacao.' using errcode = '22023';
    end if;

    insert into public.manufacturer_products (
      id,
      manufacturer_id,
      source_code,
      normalized_source_code,
      base_code,
      name,
      description,
      product_type,
      product_line,
      suggested_category,
      inventory_category,
      unit,
      primary_image_path,
      technical_image_paths,
      attributes,
      observations,
      source_catalog_name,
      source_catalog_date,
      source_page,
      source_excerpt,
      active
    ) values (
      v_prod_id,
      v_mfg_id,
      btrim(v_item->>'source_code'),
      v_norm_code,
      nullif(v_item->>'base_code', ''),
      btrim(v_item->>'name'),
      nullif(v_item->>'description', ''),
      nullif(v_item->>'product_type', ''),
      nullif(v_item->>'product_line', ''),
      nullif(v_item->>'suggested_category', ''),
      nullif(v_item->>'inventory_category', '')::public.inventory_category,
      nullif(v_item->>'unit', '')::public.inventory_unit,
      nullif(v_item->>'primary_image_path', ''),
      coalesce(v_item->'technical_image_paths', '[]'::jsonb),
      coalesce(v_item->'attributes', '[]'::jsonb),
      coalesce(v_item->'observations', '[]'::jsonb),
      nullif(v_item->>'source_catalog_name', ''),
      nullif(v_item->>'source_catalog_date', ''),
      nullif(v_item->>'source_page', '')::integer,
      nullif(v_item->>'source_excerpt', ''),
      true
    )
    on conflict (manufacturer_id, normalized_source_code) do nothing;

    get diagnostics v_rowcount = row_count;

    if v_rowcount > 0 then
      update public.catalog_import_items
      set published_product_id = v_prod_id,
          duplicate_product_id = null,
          updated_at = now()
      where id = v_item_id;

      v_items := v_items || jsonb_build_array(
        jsonb_build_object(
          'import_item_id', v_item_id,
          'outcome', 'published',
          'product_id', v_prod_id
        )
      );
      v_pub_count := v_pub_count + 1;
    else
      select mp.id into v_existing
      from public.manufacturer_products mp
      where mp.manufacturer_id = v_mfg_id
        and mp.normalized_source_code = v_norm_code
      limit 1;

      update public.catalog_import_items
      set validation_status = 'duplicate',
          duplicate_product_id = v_existing,
          published_product_id = null,
          review_decision = 'pending',
          updated_at = now()
      where id = v_item_id;

      v_items := v_items || jsonb_build_array(
        jsonb_build_object(
          'import_item_id', v_item_id,
          'outcome', 'duplicate',
          'duplicate_product_id', v_existing
        )
      );
      v_dup_count := v_dup_count + 1;
    end if;
  end loop;

  select
    count(*),
    count(*) filter (where review_decision = 'approved'),
    count(*) filter (where review_decision = 'rejected'),
    count(*) filter (where validation_status = 'invalid'),
    count(*) filter (where validation_status = 'duplicate')
  into v_total, v_approved, v_rejected, v_invalid, v_duplicate_items
  from public.catalog_import_items
  where import_job_id = p_job_id;

  update public.catalog_import_jobs
  set
    resolved_manufacturer_id = v_mfg_id,
    resolved_manufacturer_name = v_mfg_name,
    published_items = v_pub_count,
    duplicates_at_publish = v_dup_count,
    approved_items = coalesce(v_approved, 0),
    rejected_items = coalesce(v_rejected, 0),
    status = 'completed',
    completed_at = now(),
    completed_by = v_uid,
    error_message = null,
    error_code = null,
    updated_at = now()
  where id = p_job_id;

  return jsonb_build_object(
    'manufacturer_id', v_mfg_id,
    'manufacturer_name', v_mfg_name,
    'items', v_items,
    'published_count', v_pub_count,
    'duplicates_at_publish', v_dup_count,
    'total_items', coalesce(v_total, 0),
    'approved_items', coalesce(v_approved, 0),
    'rejected_items', coalesce(v_rejected, 0),
    'invalid_items', coalesce(v_invalid, 0),
    'duplicate_items', coalesce(v_duplicate_items, 0)
  );
end;
$$;

comment on function public.publish_catalog_import_batch is
  'Publica lote approved. Fabricante novo só dentro da transação. Retorno por item. Sem Storage.';
