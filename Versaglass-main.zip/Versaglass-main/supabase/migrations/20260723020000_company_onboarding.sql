-- =====================================================================
-- Onboarding empresarial — criacao atomica de empresa + membership owner.
--
-- Motivo: o schema ja permite ao usuario criar sua propria empresa
-- (company_profiles_insert_own exige user_id = auth.uid(); as funcoes
-- is_company_* tratam o criador como owner implicito). Mas o onboarding correto
-- precisa criar company_profiles + company_members na MESMA transacao (rollback
-- em falha parcial) e ser anti-duplo-clique — o que dois INSERTs separados do
-- navegador nao garantem. Esta RPC resolve exatamente isso.
--
-- Seguranca:
--   * SECURITY DEFINER com search_path travado — mesmo padrao das funcoes
--     is_company_* e do handle_new_user ja existentes.
--   * A identidade vem SEMPRE de auth.uid() (sessao validada). A funcao NAO
--     aceita user_id/owner_id/company_id do cliente — esses parametros nem
--     existem na assinatura.
--   * NAO concede papel de plataforma: user_roles nao e tocado. O criador
--     recebe apenas o papel EMPRESARIAL 'owner' em company_members.
--   * Idempotente / anti-duplo-clique: advisory lock por usuario + se ja existe
--     membership ativa, devolve a empresa existente em vez de criar outra.
--
-- Nao altera nenhuma policy, RLS, tabela, tipo ou dado. Nao adiciona empresa no
-- trigger de auth.users. Nenhum dado demonstrativo.
-- =====================================================================

create or replace function public.create_company_with_owner(
  p_company_name text,
  p_cnpj    text default null,
  p_phone   text default null,
  p_email   text default null,
  p_city    text default null,
  p_state   text default null,
  p_segment text default 'geral'
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid        uuid := auth.uid();
  v_name       text := nullif(btrim(p_company_name), '');
  v_company_id uuid;
begin
  -- Identidade obrigatoria da sessao.
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;
  if v_name is null then
    raise exception 'O nome da empresa e obrigatorio.' using errcode = '22023';
  end if;

  -- Serializa chamadas concorrentes do MESMO usuario (duplo clique / corrida).
  perform pg_advisory_xact_lock(hashtext('company_onboarding:' || v_uid::text));

  -- Idempotencia: se ja e membro ativo de alguma empresa, nao cria outra.
  select cm.company_id into v_company_id
  from public.company_members cm
  where cm.user_id = v_uid and cm.status = 'active'
  order by cm.created_at asc
  limit 1;
  if v_company_id is not null then
    return v_company_id;
  end if;

  -- Empresa + membership owner na mesma transacao (falha parcial reverte tudo).
  insert into public.company_profiles
    (user_id, company_name, cnpj, phone, email, city, state, segment)
  values
    (v_uid, v_name,
     nullif(btrim(p_cnpj), ''), nullif(btrim(p_phone), ''), nullif(btrim(p_email), ''),
     nullif(btrim(p_city), ''), nullif(btrim(p_state), ''),
     coalesce(nullif(btrim(p_segment), ''), 'geral'))
  returning id into v_company_id;

  insert into public.company_members (company_id, user_id, role, status)
  values (v_company_id, v_uid, 'owner', 'active');

  return v_company_id;
end;
$$;

comment on function public.create_company_with_owner(text, text, text, text, text, text, text)
  is 'Onboarding: cria a empresa do usuario autenticado (auth.uid()) e sua membership owner de forma atomica e idempotente. Nao concede papel de plataforma.';

-- Somente usuarios autenticados executam. anon nunca.
revoke all on function public.create_company_with_owner(text, text, text, text, text, text, text) from public;
revoke all on function public.create_company_with_owner(text, text, text, text, text, text, text) from anon;
grant execute on function public.create_company_with_owner(text, text, text, text, text, text, text) to authenticated;
