-- =====================================================================
-- Estoque — `public.inventory_items` passa a pertencer à EMPRESA.
--
-- DEFEITO CORRIGIDO (aplicação). A coluna `company_id`, a FK para
-- `company_profiles` e o índice `idx_inventory_company` JÁ EXISTIAM desde a
-- baseline, e as policies de RLS já eram por tenant — mas a tela de Estoque
-- nunca gravava `company_id` (`app.estoque.tsx:121`) e listava com `select("*")`
-- sem filtro (`:75`). Resultado prático: o ramo `owner_id = auth.uid()` das
-- policies era o único ativo e o catálogo ficava PRIVADO POR USUÁRIO — um sócio
-- não enxergava o estoque do outro dentro da mesma empresa.
--
-- Decisão humana (2026-07-27): catálogo COMPARTILHADO PELA EMPRESA, com o mesmo
-- endurecimento já aprovado para `project_templates` (migrations 20260724030000 e
-- 20260724040000). `owner_id` continua sendo o CRIADOR; `company_id` é o tenant.
--
-- DADOS REAIS DO REMOTO CONFERIDOS (2026-07-27, leitura por service_role):
--   · inventory_items ............ 0 linhas
--   · objetos no bucket project-images ... 0 (bucket inteiro vazio)
--   · company_profiles ........... 1 · company_members ... 1 (owner, active)
-- Ou seja: NÃO há backfill ambíguo, NÃO há imagem legada em `<user_id>/estoque/`
-- e NÃO há arquivo a mover. O backfill seguro abaixo é mantido mesmo assim,
-- porque a mesma migration roda em `db reset --local` e em qualquer ambiente.
--
-- NADA de movimentação de estoque é criado aqui: não existe `inventory_movements`
-- no schema e nenhuma tabela, função ou regra de entrada/saída, custo médio ou
-- financeiro foi inventada. `quantidade` continua sendo o saldo atual absoluto.
--
-- STORAGE: NENHUMA policy nova. As 4 policies empresariais criadas em
-- 20260724040000 chaveiam apenas o 1º segmento do path
-- (`split_part(name,'/',1)`), então `<company_id>/estoque/<uuid>.<ext>` já é
-- autorizado por elas — leitura/upload por membro ativo, UPDATE/DELETE só do
-- uploader (`storage.objects.owner_id`) ou de owner/admin/manager. As 4 policies
-- legadas por pasta de usuário permanecem intactas.
--
-- Segurança: RLS permanece habilitada. Sem USING(true). Admin de plataforma NÃO
-- recebe acesso automático aos estoques dos tenants. Nenhuma migration anterior
-- é editada; nenhuma tabela é recriada.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Backfill NÃO-ambíguo: owner com exatamente 1 empresa (membro ativo OU
--    criador). Mesmo algoritmo já validado em project_templates: a lateral
--    devolve as empresas DISTINTAS do owner e a window `n` conta quantas são.
--    Owner com 0 ou 2+ empresas fica NULL e a verificação seguinte aborta.
-- ---------------------------------------------------------------------
update public.inventory_items t
set company_id = m.cid
from (
  select owner_id, cid
  from (
    select o.owner_id,
           c.cid,
           count(*) over (partition by o.owner_id) as n
    from (select distinct owner_id from public.inventory_items where company_id is null) o
    join lateral (
      select distinct src.cid
      from (
        select cm.company_id as cid
          from public.company_members cm
         where cm.user_id = o.owner_id and cm.status = 'active'
        union
        select cp.id as cid
          from public.company_profiles cp
         where cp.user_id = o.owner_id
      ) src
    ) c on true
  ) z
  where z.n = 1
) m
where t.owner_id = m.owner_id and t.company_id is null;

-- 1b. O backfill DEVE cobrir todos os itens. Se restar algum NULL (owner com 0 ou
--     2+ empresas), ABORTA com erro claro — atribuição manual antes do push.
do $$
declare v_orfaos integer;
begin
  select count(*) into v_orfaos from public.inventory_items where company_id is null;
  if v_orfaos > 0 then
    raise exception
      'Backfill incompleto: % inventory_items sem company_id (owner com 0 ou 2+ empresas). Atribua company_id manualmente antes de aplicar esta migration.',
      v_orfaos using errcode = '23502';
  end if;
end $$;

-- 1c. company_id passa a ser OBRIGATÓRIO — não existe item de estoque sem empresa.
alter table public.inventory_items alter column company_id set not null;

-- ---------------------------------------------------------------------
-- 2. Policies por EMPRESA substituem as de tenant com fallback por usuário.
--    O ramo `owner_id = auth.uid()` sai da LEITURA de propósito: quem deixa a
--    empresa perde o acesso ao catálogo dela, mesmo aos itens que criou.
-- ---------------------------------------------------------------------
drop policy if exists "inventory_select_tenant" on public.inventory_items;
drop policy if exists "inventory_insert_tenant" on public.inventory_items;
drop policy if exists "inventory_update_tenant" on public.inventory_items;
drop policy if exists "inventory_delete_tenant" on public.inventory_items;

-- LEITURA: qualquer membro ativo da empresa (catálogo compartilhado).
create policy "inventory_select_company" on public.inventory_items
  for select to authenticated
  using (public.is_company_member(company_id, auth.uid()));

-- CRIAÇÃO: owner_id = sessão; company_id de uma empresa da qual é membro.
create policy "inventory_insert_company" on public.inventory_items
  for insert to authenticated
  with check (
    owner_id = auth.uid()
    and public.is_company_member(company_id, auth.uid())
  );

-- EDIÇÃO: criador OU owner/admin/manager. Cobre também a alteração de saldo e a
-- desativação (`ativo = false`), que são UPDATE comum — um seller altera apenas
-- os itens que ele mesmo cadastrou.
create policy "inventory_update_company" on public.inventory_items
  for update to authenticated
  using (owner_id = auth.uid() or public.is_company_admin(company_id, auth.uid()))
  with check (public.is_company_member(company_id, auth.uid()));

-- EXCLUSÃO FÍSICA: criador OU owner/admin/manager. Nenhuma FK referencia
-- inventory_items (quote_items NÃO tem inventory_item_id) — nada é apagado em
-- cascata e nenhum orçamento existente é afetado.
create policy "inventory_delete_company" on public.inventory_items
  for delete to authenticated
  using (owner_id = auth.uid() or public.is_company_admin(company_id, auth.uid()));

-- ---------------------------------------------------------------------
-- 3. IMUTABILIDADE de company_id e owner_id (defesa no banco, além da RLS).
--    A policy de UPDATE não impede um membro de A+B mover o item para B, nem um
--    admin trocar o criador, por chamada direta ao PostgREST.
-- ---------------------------------------------------------------------
create or replace function public.inventory_items_lock_tenant()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.company_id is distinct from old.company_id then
    raise exception 'company_id de inventory_items é imutável.' using errcode = '42501';
  end if;
  if new.owner_id is distinct from old.owner_id then
    raise exception 'owner_id de inventory_items é imutável.' using errcode = '42501';
  end if;
  return new;
end;
$$;

drop trigger if exists inventory_items_lock_tenant_biu on public.inventory_items;
create trigger inventory_items_lock_tenant_biu
  before update on public.inventory_items
  for each row execute function public.inventory_items_lock_tenant();

-- ---------------------------------------------------------------------
-- 4. imagem_url = NULL ou PATH no prefixo da PRÓPRIA empresa.
--    Normaliza '' → NULL e proíbe caminho por usuário, de outra empresa ou URL
--    completa. `split_part` por TEXTO — sem cast do path para uuid.
--    O caminho novo do Estoque é `<company_id>/estoque/<uuid>.<ext>`: o 1º
--    segmento continua sendo o company_id, então a constraint o aceita.
-- ---------------------------------------------------------------------
update public.inventory_items set imagem_url = null where imagem_url = '';

-- 4b. Nenhuma imagem legada pode ser perdida em silêncio. Se houver algum
--     `<user_id>/estoque/...` remanescente, ABORTA — a migração dos arquivos é
--     decisão administrativa, não efeito colateral desta migration. Confirmado
--     no remoto: 0 objetos no bucket, portanto nada a abortar.
do $$
declare v_legado integer;
begin
  select count(*) into v_legado
    from public.inventory_items
   where imagem_url is not null
     and split_part(imagem_url, '/', 1) <> company_id::text;
  if v_legado > 0 then
    raise exception
      'Existem % inventory_items com imagem fora do prefixo da empresa (path legado por usuário). Migre os arquivos e atualize imagem_url antes de aplicar esta migration.',
      v_legado using errcode = '23514';
  end if;
end $$;

alter table public.inventory_items
  add constraint inventory_items_imagem_url_company
  check (imagem_url is null or split_part(imagem_url, '/', 1) = company_id::text);

-- ---------------------------------------------------------------------
-- 5. Valores não negativos. O schema aceitava saldo e preço negativos (as
--    colunas são `numeric not null default 0`, sem CHECK) e a única validação
--    vivia no Zod do navegador — contornável por chamada direta.
--    NÃO existe regra de saldo negativo no projeto (não há movimentações, não há
--    reserva, não há venda a descoberto), então o piso é 0 para as quatro.
--    Nenhuma regra de custo médio, margem ou financeiro é criada.
-- ---------------------------------------------------------------------
alter table public.inventory_items
  add constraint inventory_items_quantidade_nao_negativa     check (quantidade >= 0),
  add constraint inventory_items_estoque_minimo_nao_negativo check (estoque_minimo >= 0),
  add constraint inventory_items_custo_unit_nao_negativo     check (custo_unit >= 0),
  add constraint inventory_items_preco_venda_nao_negativo    check (preco_venda >= 0);

comment on column public.inventory_items.company_id is
  'Tenant do item de estoque (empresa). NOT NULL e imutável desde 20260727010000; catálogo compartilhado entre os membros.';
comment on column public.inventory_items.custo_unit is
  'Custo por unidade da coluna `unidade`. NÃO é preço de venda e não alimenta nenhum cálculo de orçamento.';
comment on column public.inventory_items.preco_venda is
  'Preço de venda por unidade da coluna `unidade`. Copiado como SNAPSHOT para quote_items.preco_unit; não há vínculo posterior.';
comment on column public.inventory_items.quantidade is
  'Saldo atual absoluto. NÃO existe tabela de movimentações: não há histórico de entrada/saída nem trilha de auditoria de saldo.';
