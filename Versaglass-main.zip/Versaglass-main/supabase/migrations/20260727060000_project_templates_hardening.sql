-- =====================================================================
-- 20260727060000_project_templates_hardening.sql
--
-- Duas correções em `public.project_templates`, ambas de banco:
--   1. LEITURA de modelo INATIVO deixa de ser franqueada a todo membro;
--   2. medidas e preço passam a ter constraint — a validação era só do
--      formulário, e escrita direta pela API aceitava zero e negativo.
--
-- Não toca INSERT, UPDATE nem DELETE. Não altera nenhum valor existente.
-- Não concede acesso a admin de plataforma. Nenhum `using (true)`.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 1. Policy de SELECT
--
-- ANTES (baseline 20260724030000):
--   policy "project_templates_select_company" for select to authenticated
--     using (public.is_company_member(company_id, auth.uid()))
--
-- O predicado não olhava `ativo`. Quem escondia o modelo inativo do vendedor
-- era a CONSULTA da aplicação (`incluirInativos = false` em
-- use-project-templates.ts) — ou seja, uma decisão de tela. Uma chamada direta
-- ao PostgREST por qualquer membro devolvia os inativos da própria empresa, o
-- que foi comprovado em teste. Modelo fora de circulação é decisão comercial de
-- quem administra a empresa; não deve aparecer para quem apenas orça.
--
-- DEPOIS: quem GERE (owner/admin/manager) continua vendo tudo, porque precisa
-- enxergar o inativo para reativá-lo; os demais papéis (seller, operator,
-- installer) só alcançam `ativo = true`.
--
-- Funções REAIS conferidas antes de escrever (assinaturas idênticas):
--   public.is_company_admin(_company_id uuid, _user_id uuid) -> boolean
--     ... membership ATIVA com papel owner/admin/manager, ou criador da empresa;
--   public.is_company_member(_company_id uuid, _user_id uuid) -> boolean
--     ... membership ATIVA de qualquer papel, ou criador da empresa.
-- Ambas são SECURITY DEFINER com search_path travado e recusam consulta sobre
-- terceiro (`_user_id <> auth.uid()` devolve false), então não há como um
-- usuário sondar o vínculo alheio por meio delas.
--
-- Quem NÃO é membro continua sem ver nada — inclusive o admin de PLATAFORMA,
-- que não aparece em predicado algum aqui de propósito: papel de plataforma não
-- dá acesso ao acervo técnico dos tenants.
-- ---------------------------------------------------------------------
drop policy if exists "project_templates_select_company" on public.project_templates;

create policy "project_templates_select_company" on public.project_templates
  for select to authenticated
  using (
    public.is_company_admin(company_id, auth.uid())
    or (
      ativo = true
      and public.is_company_member(company_id, auth.uid())
    )
  );

comment on table public.project_templates is
  'Biblioteca de modelos tecnicos da EMPRESA. Leitura: owner/admin/manager veem ativos e inativos; demais membros somente ativos. Escrita: criador ou owner/admin/manager. Admin de plataforma sem membership nao le.';


-- ---------------------------------------------------------------------
-- 2. Constraints de integridade
--
-- AUDITORIA PRÉVIA (2026-07-27, leitura por service_role — somente contagens,
-- nenhum id ou nome consultado):
--   * remoto: 1 linha .... largura invalida 0 · altura invalida 0 · preco invalido 0
--   * local:  0 linhas ... idem
-- Nenhuma linha precisaria de correção, então nada é alterado silenciosamente.
--
-- O bloco abaixo repete a contagem NO MOMENTO DA APLICAÇÃO e ABORTA se algo
-- inválido tiver entrado entre a auditoria e o deploy. Preferimos falhar a
-- migration a "consertar" dado de cliente por conta própria: largura zero pode
-- significar cadastro incompleto (apagar) ou erro de digitação (corrigir), e a
-- diferença é decisão humana.
--
-- Por que > 0 e não >= 0 nas medidas: um modelo com dimensão zero, ao ser
-- levado ao orçamento, vira item SEM dimensões — que o formulário precifica por
-- UNIDADE em vez de por m². O erro aparece no total, longe da causa.
-- `preco_m2 >= 0` porque zero é legítimo: modelo cujo preço é definido item a
-- item no orçamento.
-- ---------------------------------------------------------------------
do $$
declare
  v_largura integer;
  v_altura  integer;
  v_preco   integer;
begin
  select count(*) filter (where not (largura_padrao > 0)),
         count(*) filter (where not (altura_padrao  > 0)),
         count(*) filter (where not (preco_m2      >= 0))
    into v_largura, v_altura, v_preco
    from public.project_templates;

  if v_largura > 0 or v_altura > 0 or v_preco > 0 then
    raise exception
      'project_templates com valores invalidos: % largura(s) <= 0, % altura(s) <= 0, % preco(s) < 0. Trate os registros antes de aplicar esta migration.',
      v_largura, v_altura, v_preco
      using errcode = '23514';
  end if;

  raise notice 'project_templates: nenhuma medida ou preco invalido encontrado.';
end $$;

alter table public.project_templates
  add constraint project_templates_largura_padrao_positive check (largura_padrao > 0),
  add constraint project_templates_altura_padrao_positive  check (altura_padrao  > 0),
  add constraint project_templates_preco_m2_nonnegative    check (preco_m2      >= 0);

comment on column public.project_templates.largura_padrao is
  'Largura padrao em METROS. Sempre > 0 (project_templates_largura_padrao_positive).';
comment on column public.project_templates.altura_padrao is
  'Altura padrao em METROS. Sempre > 0 (project_templates_altura_padrao_positive).';
comment on column public.project_templates.preco_m2 is
  'Preco por metro quadrado. Zero e permitido (preco definido no orcamento); negativo nao (project_templates_preco_m2_nonnegative).';
