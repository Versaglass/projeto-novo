-- =====================================================================
-- Estoque — amplia o enum `public.inventory_category` para as áreas que o
-- produto já anuncia (Serralheria, Marcenaria, Marmoraria).
--
-- DEFEITO CORRIGIDO. A tela de Estoque (`app.estoque.tsx`) oferece 17 categorias,
-- mas o enum real só tem 8 (aluminio, vidro, ferragem, acessorio, perfil, led,
-- cola, outros). Cadastrar em qualquer uma das 9 restantes falhava com
-- `22P02 invalid input value for enum inventory_category`. Como `inventory_items`
-- está VAZIA (0 linhas no remoto, confirmado), o defeito nunca chegou a produzir
-- dado inconsistente — mas tornava as três áreas inutilizáveis.
--
-- Decisão humana (2026-07-27): ESTENDER o enum, mantendo as áreas anunciadas.
-- ATENÇÃO: `alter type ... add value` é IRREVERSÍVEL — o PostgreSQL não tem
-- `drop value`. Reverter exigiria recriar o tipo e reescrever a coluna.
--
-- Isolada em migration própria de propósito: `add value` não pode ser USADO na
-- mesma transação em que é criado. Aqui nenhum valor novo é referenciado — a
-- migration seguinte (20260727010000) faz o endurecimento do tenant sem tocar em
-- categoria. Nenhuma tabela, policy, índice ou trigger é alterado neste arquivo.
-- =====================================================================

-- Serralheria
alter type public.inventory_category add value if not exists 'aco_metalon';
alter type public.inventory_category add value if not exists 'chapa_aco';
alter type public.inventory_category add value if not exists 'solda';

-- Marcenaria
alter type public.inventory_category add value if not exists 'mdf';
alter type public.inventory_category add value if not exists 'ferragem_moveis';
alter type public.inventory_category add value if not exists 'fita_borda';

-- Marmoraria
alter type public.inventory_category add value if not exists 'marmore';
alter type public.inventory_category add value if not exists 'quartzo';
alter type public.inventory_category add value if not exists 'porcelanato';
