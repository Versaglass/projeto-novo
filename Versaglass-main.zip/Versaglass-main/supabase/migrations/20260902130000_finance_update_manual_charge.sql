-- =====================================================================
-- Financeiro — RPC update_manual_charge (editar cobranca manual)
--
-- Design: Revisao 230. Despesas operacionais: UPDATE via PostgREST + RLS
-- (policies expenses_update_* ja existentes). Cobrancas: escrita somente RPC.
--
-- Escopo:
--   * update_manual_charge — pending/overdue, payment_method manual,
--     sem sale_id nem provider_charge_id
--   * Mesmo gate de permissao que mark_charge_paid (criador ou admin)
--
-- Fora do escopo: editar cobranca paga/cancelada, despesas pessoais (RLS
-- ja cobre; UI fora do pedido desta rodada).
-- NAO altera migrations anteriores.
-- =====================================================================

create or replace function public.update_manual_charge(
  p_charge_id   uuid,
  p_amount      numeric,
  p_description text,
  p_customer_id uuid default null,
  p_quote_id    uuid default null,
  p_due_date    date default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid            uuid := auth.uid();
  v_company_id     uuid;
  v_owner_id       uuid;
  v_status         text;
  v_payment_method text;
  v_sale_id        uuid;
  v_provider       text;
  v_amount         numeric := round(coalesce(p_amount, 0), 2);
  v_desc           text := nullif(btrim(coalesce(p_description, '')), '');
  v_new_status     text;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if p_charge_id is null then
    raise exception 'Cobranca nao encontrada.' using errcode = '23503';
  end if;

  select c.company_id, c.owner_id, c.status, c.payment_method, c.sale_id, c.provider_charge_id
    into v_company_id, v_owner_id, v_status, v_payment_method, v_sale_id, v_provider
    from public.charges c
   where c.id = p_charge_id
   for update;

  if not found then
    raise exception 'Cobranca nao encontrada.' using errcode = '23503';
  end if;

  if not public.is_company_member(v_company_id, v_uid) then
    raise exception 'Sem permissao para esta empresa.' using errcode = '42501';
  end if;

  if not (v_owner_id = v_uid or public.is_company_admin(v_company_id, v_uid)) then
    raise exception 'Sem permissao para editar esta cobranca.' using errcode = '42501';
  end if;

  if v_status not in ('pending', 'overdue') then
    raise exception 'Somente cobrancas pendentes ou vencidas podem ser editadas.' using errcode = '22023';
  end if;

  if v_payment_method <> 'manual' then
    raise exception 'Somente cobrancas manuais podem ser editadas por esta funcao.' using errcode = '22023';
  end if;

  if v_sale_id is not null then
    raise exception 'Cobranca vinculada a venda nao pode ser editada.' using errcode = '22023';
  end if;

  if v_provider is not null then
    raise exception 'Cobranca com provedor de pagamento nao pode ser editada.' using errcode = '22023';
  end if;

  if v_amount <= 0 then
    raise exception 'Valor da cobranca deve ser positivo.' using errcode = '22023';
  end if;

  if v_desc is null then
    raise exception 'Descricao da cobranca e obrigatoria.' using errcode = '22023';
  end if;

  if p_customer_id is not null then
    perform 1
       from public.customers c
      where c.id = p_customer_id
        and c.company_id = v_company_id;
    if not found then
      raise exception 'Cliente nao pertence a esta empresa.' using errcode = '23503';
    end if;
  end if;

  if p_quote_id is not null then
    perform 1
       from public.quotes q
      where q.id = p_quote_id
        and q.company_id = v_company_id
        and q.status = 'aprovado'::public.quote_status;
    if not found then
      raise exception 'Orcamento nao encontrado ou nao esta aprovado nesta empresa.' using errcode = '23503';
    end if;
  end if;

  v_new_status := case
    when p_due_date is not null and p_due_date < current_date then 'overdue'
    else 'pending'
  end;

  update public.charges
     set description = v_desc,
         amount      = v_amount,
         customer_id = p_customer_id,
         quote_id    = p_quote_id,
         due_date    = p_due_date,
         status      = v_new_status
   where id = p_charge_id;
end;
$$;

comment on function public.update_manual_charge(uuid, numeric, text, uuid, uuid, date) is
  'Edita cobranca manual pendente/vencida. Mesmo gate de mark_charge_paid.';

revoke all on function public.update_manual_charge(uuid, numeric, text, uuid, uuid, date) from public;
revoke all on function public.update_manual_charge(uuid, numeric, text, uuid, uuid, date) from anon;
grant execute on function public.update_manual_charge(uuid, numeric, text, uuid, uuid, date) to authenticated;
