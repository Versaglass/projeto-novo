-- =====================================================================
-- 20260727080000_quote_items_project_data.sql
--
-- O desenho paramétrico passa a viajar do MODELO para o ITEM do orçamento,
-- como SNAPSHOT independente.
--
-- POR QUE UMA COLUNA NOVA, E NÃO `drawing_data`
--   São duas coisas diferentes e o item pode ter as duas ao mesmo tempo:
--     · `project_data`  → projeto paramétrico completo copiado do modelo
--                         (peças, materiais, acabamento, área, revisão);
--     · `drawing_data`  → desenho técnico do editor de recortes e ferragens,
--                         específico DAQUELE orçamento;
--     · `drawing_notes` → observação técnica em texto.
--   Espremer o paramétrico dentro de `drawing_data` obrigaria os dois editores
--   a entender o formato do outro, e o item perderia a capacidade de ter os
--   dois desenhos. Esta migration não encosta em `drawing_data` nem em
--   `drawing_notes`.
--
-- SNAPSHOT, NÃO REFERÊNCIA
--   Nenhuma FK para `project_templates` e nenhuma coluna `source_template_id`.
--   O orçamento é AUTOSSUFICIENTE: alterar, desativar ou excluir o modelo não
--   mexe em orçamento nenhum, e reabrir um orçamento antigo não consulta a
--   biblioteca de modelos. É a mesma regra que já vale para descrição, medidas
--   e preço desde o início do fluxo Projeto → Orçamento.
--
-- AUDITORIA PRÉVIA (leitura por service_role, somente contagens):
--   remoto: 8 quote_items · nenhum com `drawing_data` preenchido · nenhum com
--   `drawing_notes` · coluna `project_data` inexistente.
--   Nada a migrar: nenhum backfill é executado e nenhum item antigo recebe
--   desenho inventado. Item sem snapshot fica NULL, que é o que NULL quer dizer.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 1. Coluna + constraints do envelope
--
-- Mesmas três regras já usadas em `project_templates.project_data`
-- (20260727070000), pelo mesmo motivo e com os mesmos números — os dois lados
-- guardam exatamente o mesmo formato, então divergir aqui criaria um snapshot
-- que o modelo aceita e o item recusa (ou o contrário).
--
--   · objeto na raiz — array ou primitivo produziriam `undefined` na leitura;
--   · 256 KB em BYTES (`octet_length`), a mesma unidade que o frontend mede;
--   · `versao` inteira e igual a 1, a única que a aplicação sabe interpretar.
--     O `coalesce` cobre a chave AUSENTE: `-> 'versao'` devolveria SQL NULL,
--     `jsonb_typeof(NULL)` também, e um CHECK que resulta em NULL é dado como
--     satisfeito — sem ele a constraint deixaria passar o caso que existe para
--     barrar.
-- ---------------------------------------------------------------------
alter table public.quote_items
  add column if not exists project_data jsonb;

comment on column public.quote_items.project_data is
  'SNAPSHOT do desenho parametrico copiado do modelo tecnico no momento do orcamento (formato ProjectDataV1). NULL = item sem desenho parametrico. Independente de project_templates: nao ha FK e alterar o modelo nao altera o item. Nao confundir com drawing_data, que e o desenho tecnico de recortes/ferragens do proprio orcamento.';

do $$
declare v_invalidos integer;
begin
  select count(*) into v_invalidos
    from public.quote_items
   where project_data is not null
     and (jsonb_typeof(project_data) <> 'object'
          or coalesce(jsonb_typeof(project_data -> 'versao'), 'ausente') <> 'number'
          or (project_data -> 'versao') <> to_jsonb(1)
          or octet_length(project_data::text) > 262144);
  if v_invalidos > 0 then
    raise exception
      'Existem % quote_items com project_data fora do formato esperado. Trate antes de aplicar esta migration.',
      v_invalidos using errcode = '23514';
  end if;
end $$;

alter table public.quote_items
  add constraint quote_items_project_data_object
    check (project_data is null or jsonb_typeof(project_data) = 'object'),
  add constraint quote_items_project_data_size
    check (project_data is null or octet_length(project_data::text) <= 262144),
  add constraint quote_items_project_data_version
    check (project_data is null
           or (coalesce(jsonb_typeof(project_data -> 'versao'), 'ausente') = 'number'
               and (project_data -> 'versao') = to_jsonb(1)));


-- ---------------------------------------------------------------------
-- 2. save_quote_with_items — o snapshot passa a viajar em p_items
--
-- A ASSINATURA EXTERNA NÃO MUDA: nenhum parâmetro novo, nenhuma sobrecarga
-- ambígua, e chamadas antigas (sem o campo) continuam válidas — item sem
-- `project_data` grava NULL.
--
-- A RPC continua APAGANDO e regravando os itens na edição, então o snapshot
-- precisa voltar no payload a cada gravação — exatamente como já acontece com
-- `drawing_data`/`drawing_notes` desde a 20260727030000. Quem não reenviar,
-- perde; quem enviar `null` explicitamente, remove de propósito.
--
-- A VALIDAÇÃO É REFEITA AQUI. O frontend já valida antes de enviar, mas a RPC
-- é `security definer` e alcançável direto pelo PostgREST: confiar só no
-- navegador seria confiar em quem não controlamos.
--
-- Nada de financeiro muda: totais continuam calculados no banco a partir de
-- largura/altura/quantidade/preço, e subtotal, m2 e total enviados pelo cliente
-- seguem ignorados. Tenant e isolamento intactos.
-- ---------------------------------------------------------------------
create or replace function public.save_quote_with_items(
  p_company_id    uuid,
  p_customer_id   uuid,
  p_items         jsonb,
  p_quote_id      uuid                 default null,
  p_status        public.quote_status  default 'rascunho',
  p_observacoes   text                 default null,
  p_desconto      numeric              default 0,
  p_acrescimo     numeric              default 0,
  p_validade_dias integer              default 15
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  -- Estado "sem desenho tecnico": mesmo default da coluna.
  c_draw_vazio constant jsonb := '{"versao":1,"recortes":[],"ferragens":[]}'::jsonb;
  c_draw_max   constant integer := 65536;  -- 64 KB por item (desenho tecnico)
  c_proj_max   constant integer := 262144; -- 256 KB por item (parametrico)

  v_uid   uuid := auth.uid();
  v_qid   uuid := p_quote_id;
  v_desc  numeric := round(coalesce(p_desconto, 0), 2);
  v_acr   numeric := round(coalesce(p_acrescimo, 0), 2);
  v_val   integer := coalesce(p_validade_dias, 15);
  v_sum   numeric := 0;
  v_total numeric;
  v_count integer;
  v_item  jsonb;
  v_idx   integer := 0;
  v_desc_txt text;
  v_larg  numeric;
  v_alt   numeric;
  v_qtd   integer;
  v_preco numeric;
  v_m2    numeric;
  v_sub   numeric;
  v_draw  jsonb;
  v_notes text;
  v_proj  jsonb;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if p_company_id is null or not public.is_company_member(p_company_id, v_uid) then
    raise exception 'Empresa invalida ou sem permissao.' using errcode = '42501';
  end if;

  if not exists (
    select 1 from public.customers c
    where c.id = p_customer_id and c.company_id = p_company_id
  ) then
    raise exception 'Cliente nao pertence a empresa ativa.' using errcode = '23503';
  end if;

  if p_items is null or jsonb_typeof(p_items) <> 'array' then
    raise exception 'Itens invalidos.' using errcode = '22023';
  end if;
  v_count := jsonb_array_length(p_items);
  if v_count < 1 or v_count > 200 then
    raise exception 'O orcamento deve ter de 1 a 200 itens.' using errcode = '22023';
  end if;

  if v_desc < 0 or v_acr < 0 then
    raise exception 'Desconto e acrescimo nao podem ser negativos.' using errcode = '22023';
  end if;
  if v_val < 0 then v_val := 0; end if;

  if v_qid is not null then
    if not exists (
      select 1 from public.quotes q
      where q.id = v_qid
        and q.company_id = p_company_id
        and (q.owner_id = v_uid or public.is_company_admin(p_company_id, v_uid))
    ) then
      raise exception 'Orcamento nao encontrado ou sem permissao.' using errcode = '42501';
    end if;
  end if;

  if v_qid is null then
    insert into public.quotes
      (owner_id, company_id, customer_id, status, observacoes, desconto, acrescimo, validade_dias, total)
    values
      (v_uid, p_company_id, p_customer_id, p_status,
       nullif(btrim(coalesce(p_observacoes, '')), ''), v_desc, v_acr, v_val, 0)
    returning id into v_qid;
  else
    update public.quotes set
      customer_id   = p_customer_id,
      status        = p_status,
      observacoes   = nullif(btrim(coalesce(p_observacoes, '')), ''),
      desconto      = v_desc,
      acrescimo     = v_acr,
      validade_dias = v_val
    where id = v_qid;
    delete from public.quote_items where quote_id = v_qid;
  end if;

  for v_item in select value from jsonb_array_elements(p_items)
  loop
    v_desc_txt := nullif(btrim(coalesce(v_item->>'descricao', '')), '');
    v_larg  := coalesce((v_item->>'largura')::numeric, 0);
    v_alt   := coalesce((v_item->>'altura')::numeric, 0);
    v_qtd   := coalesce((v_item->>'quantidade')::integer, 0);
    v_preco := coalesce((v_item->>'preco_unit')::numeric, 0);

    if v_desc_txt is null then
      raise exception 'Item % sem descricao.', v_idx + 1 using errcode = '22023';
    end if;
    if v_qtd <= 0 then
      raise exception 'Item % com quantidade invalida.', v_idx + 1 using errcode = '22023';
    end if;
    if v_larg < 0 or v_alt < 0 or v_preco < 0 then
      raise exception 'Item % com valor negativo.', v_idx + 1 using errcode = '22023';
    end if;

    -- ---------------------------------------------------------------
    -- Desenho técnico — OPCIONAL. Ausente, null ou omitido = sem desenho.
    -- Inalterado desde 20260727030000.
    -- ---------------------------------------------------------------
    v_draw := v_item -> 'drawing_data';
    if v_draw is null or jsonb_typeof(v_draw) = 'null' then
      v_draw := c_draw_vazio;
    elsif jsonb_typeof(v_draw) <> 'object' then
      raise exception 'Item % com desenho tecnico invalido.', v_idx + 1 using errcode = '22023';
    else
      if jsonb_typeof(v_draw -> 'recortes') is distinct from 'array' then
        v_draw := jsonb_set(v_draw, '{recortes}', '[]'::jsonb, true);
      end if;
      if jsonb_typeof(v_draw -> 'ferragens') is distinct from 'array' then
        v_draw := jsonb_set(v_draw, '{ferragens}', '[]'::jsonb, true);
      end if;
      if jsonb_array_length(v_draw -> 'recortes') > 200
         or jsonb_array_length(v_draw -> 'ferragens') > 200 then
        raise exception 'Item % com desenho tecnico acima do limite.', v_idx + 1 using errcode = '22023';
      end if;
      if octet_length(v_draw::text) > c_draw_max then
        raise exception 'Item % com desenho tecnico acima do limite.', v_idx + 1 using errcode = '22023';
      end if;
    end if;

    -- ---------------------------------------------------------------
    -- Snapshot PARAMÉTRICO — OPCIONAL e independente do desenho técnico.
    --
    -- Ausente ou `null` viram NULL de verdade (a coluna é nullable, ao
    -- contrário de drawing_data), o que também é a forma de REMOVER o
    -- snapshot: basta reenviar o item com `project_data: null`.
    --
    -- Presente precisa passar pelas MESMAS regras da constraint da tabela —
    -- checadas aqui para o erro sair com a linha do item, e não como violação
    -- crua de CHECK. A validação detalhada de cada peça continua no
    -- TypeScript compartilhado; aqui se valida o envelope.
    -- ---------------------------------------------------------------
    v_proj := v_item -> 'project_data';
    if v_proj is null or jsonb_typeof(v_proj) = 'null' then
      v_proj := null;
    elsif jsonb_typeof(v_proj) <> 'object' then
      raise exception 'Item % com desenho parametrico invalido.', v_idx + 1 using errcode = '22023';
    else
      if coalesce(jsonb_typeof(v_proj -> 'versao'), 'ausente') <> 'number'
         or (v_proj -> 'versao') <> to_jsonb(1) then
        raise exception 'Item % com versao de desenho parametrico nao suportada.', v_idx + 1 using errcode = '22023';
      end if;
      if octet_length(v_proj::text) > c_proj_max then
        raise exception 'Item % com desenho parametrico acima do limite.', v_idx + 1 using errcode = '22023';
      end if;
    end if;

    v_notes := nullif(btrim(coalesce(v_item->>'drawing_notes', '')), '');
    if v_notes is not null then v_notes := left(v_notes, 2000); end if;

    v_m2 := round(v_larg * v_alt * v_qtd, 4);
    -- Sem dimensoes: preco por UNIDADE. Com dimensoes: por m². Permite item manual.
    if v_larg > 0 and v_alt > 0 then
      v_sub := round(v_m2 * v_preco, 2);
    else
      v_sub := round(v_qtd * v_preco, 2);
    end if;
    v_sum := v_sum + v_sub;

    insert into public.quote_items
      (quote_id, company_id, descricao, largura, altura, quantidade, m2, preco_unit, subtotal, ordem,
       drawing_data, drawing_notes, project_data)
    values
      (v_qid, p_company_id, v_desc_txt, round(v_larg, 3), round(v_alt, 3),
       v_qtd, v_m2, round(v_preco, 2), v_sub, v_idx,
       v_draw, v_notes, v_proj);

    v_idx := v_idx + 1;
  end loop;

  v_total := greatest(0, round(v_sum - v_desc + v_acr, 2));
  update public.quotes set total = v_total where id = v_qid;

  return v_qid;
end;
$$;

comment on function public.save_quote_with_items(uuid, uuid, jsonb, uuid, public.quote_status, text, numeric, numeric, integer) is
  'Cria ou edita um orcamento com seus itens em uma transacao. Cada item pode trazer `drawing_data` (desenho tecnico, desde 20260727030000), `drawing_notes` e `project_data` (snapshot parametrico do modelo, desde 20260727080000) — todos reenviados a cada gravacao, porque a RPC apaga e recria os itens. Totais continuam calculados no banco; nada de subtotal/m2/total vem do cliente.';
