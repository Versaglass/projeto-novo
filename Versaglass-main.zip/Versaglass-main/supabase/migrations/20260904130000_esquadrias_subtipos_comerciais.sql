-- =====================================================================
-- 20260904130000_esquadrias_subtipos_comerciais.sql
--
-- Substitui a taxonomia de Esquadrias (alumínio / veneziana) pelos 13 tipos
-- comerciais definidos pelo cliente:
--
--   janela_esquadrias, porta_esquadrias, maxim_ar_esquadrias,
--   fixos_esquadrias, portao_esquadrias, fachada_esquadrias,
--   porta_pivotante_esquadrias, diversos_esquadrias, basculantes_esquadrias,
--   janela_pivotante_esquadrias, camarao_esquadrias, janela_abrir_esquadrias,
--   gradil_esquadrias
--
-- NÃO altera:
--   · enum project_area
--   · enum quote_item_tipo_projeto (continua sendo lista de Vidraçaria)
--   · taxonomia de Vidraçaria / Serralheria / Marcenaria / Marmoraria
--   · dados existentes (sem UPDATE/DELETE de subtipo)
--
-- Legado: IDs antigos de Esquadrias CONTINUAM aceitos no CHECK:
--   · taxonomia alumínio (20260903160000)
--   · espelho visual de Vidraçaria (20260903150200), se ainda houver linha
--
-- Preserva `fachada_esquadrias` (permanece na lista comercial).
--
-- NÃO aplicar no remoto nesta rodada — só preparar o arquivo.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. CHECK project_templates_area_subtipo
-- ---------------------------------------------------------------------
alter table public.project_templates
  drop constraint if exists project_templates_area_subtipo;

alter table public.project_templates
  add constraint project_templates_area_subtipo check (
    case area
      when 'vidracaria'  then subtipo in (
        'janela',
        'porta',
        'fixo',
        'box',
        'fechamento_pia',
        'espelho',
        'bascula_maxiar_pivotante',
        'guarda_corpo',
        'reposicao',
        'sacadas',
        'articulados',
        'muro',
        'vitrine',
        'porta_vidro',
        'janela_vidro',
        'fechamento_vidro',
        'outro_vidracaria'
      )
      when 'esquadrias'  then subtipo in (
        -- atuais (13 comerciais)
        'janela_esquadrias',
        'porta_esquadrias',
        'maxim_ar_esquadrias',
        'fixos_esquadrias',
        'portao_esquadrias',
        'fachada_esquadrias',
        'porta_pivotante_esquadrias',
        'diversos_esquadrias',
        'basculantes_esquadrias',
        'janela_pivotante_esquadrias',
        'camarao_esquadrias',
        'janela_abrir_esquadrias',
        'gradil_esquadrias',
        -- legado alumínio (20260903160000)
        'janela_aluminio_esquadrias',
        'porta_aluminio_esquadrias',
        'porta_correr_esquadrias',
        'veneziana_esquadrias',
        'guarda_corpo_esquadrias',
        'outro_esquadrias',
        -- legado espelho visual (20260903150200)
        'box_esquadrias',
        'porta_vidro_esquadrias',
        'janela_vidro_esquadrias',
        'espelho_esquadrias',
        'fechamento_vidro_esquadrias'
      )
      when 'serralheria' then subtipo in ('portao','grade','corrimao','estrutura_metalica','cobertura','esquadria_metalica','outro_serralheria')
      when 'marcenaria'  then subtipo in ('armario','porta_madeira','painel','bancada_madeira','movel_planejado','prateleira','outro_marcenaria')
      when 'marmoraria'  then subtipo in ('bancada_pedra','pia','soleira','revestimento','escada','peitoril','outro_marmoraria')
    end
  );

comment on column public.project_templates.subtipo is
  'Tipo de projeto DENTRO da area. Vidracaria e Esquadrias: 13 tipos comerciais (+ legado no CHECK). Demais areas: 7 opcoes. Par (area, subtipo) validado por project_templates_area_subtipo.';

-- ---------------------------------------------------------------------
-- 2. CHECK platform_project_catalog_area_subtipo
-- ---------------------------------------------------------------------
alter table public.platform_project_catalog
  drop constraint if exists platform_project_catalog_area_subtipo;

alter table public.platform_project_catalog
  add constraint platform_project_catalog_area_subtipo check (
    case area
      when 'vidracaria'  then subtipo in (
        'janela',
        'porta',
        'fixo',
        'box',
        'fechamento_pia',
        'espelho',
        'bascula_maxiar_pivotante',
        'guarda_corpo',
        'reposicao',
        'sacadas',
        'articulados',
        'muro',
        'vitrine',
        'porta_vidro',
        'janela_vidro',
        'fechamento_vidro',
        'outro_vidracaria'
      )
      when 'esquadrias'  then subtipo in (
        'janela_esquadrias',
        'porta_esquadrias',
        'maxim_ar_esquadrias',
        'fixos_esquadrias',
        'portao_esquadrias',
        'fachada_esquadrias',
        'porta_pivotante_esquadrias',
        'diversos_esquadrias',
        'basculantes_esquadrias',
        'janela_pivotante_esquadrias',
        'camarao_esquadrias',
        'janela_abrir_esquadrias',
        'gradil_esquadrias',
        'janela_aluminio_esquadrias',
        'porta_aluminio_esquadrias',
        'porta_correr_esquadrias',
        'veneziana_esquadrias',
        'guarda_corpo_esquadrias',
        'outro_esquadrias',
        'box_esquadrias',
        'porta_vidro_esquadrias',
        'janela_vidro_esquadrias',
        'espelho_esquadrias',
        'fechamento_vidro_esquadrias'
      )
      when 'serralheria' then subtipo in ('portao','grade','corrimao','estrutura_metalica','cobertura','esquadria_metalica','outro_serralheria')
      when 'marcenaria'  then subtipo in ('armario','porta_madeira','painel','bancada_madeira','movel_planejado','prateleira','outro_marcenaria')
      when 'marmoraria'  then subtipo in ('bancada_pedra','pia','soleira','revestimento','escada','peitoril','outro_marmoraria')
    end
  );
