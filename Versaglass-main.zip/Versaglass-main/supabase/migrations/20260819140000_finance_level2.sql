-- =====================================================================
-- Financeiro Nivel 2 — despesas (expenses), cobrancas manuais (charges)
-- e resumo financeiro (get_finance_summary).
--
-- Design aprovado: Revisao 154. Auditoria pre-migration: Revisao 155
-- (20 colunas charges, payment_method text+CHECK, 0 linhas, RLS esperado).
--
-- Escopo:
--   * Tabela nova public.expenses (despesas manuais realizadas)
--   * Alteracoes incrementais em charges (owner_id, quote_id, manual)
--   * RPCs: create_manual_charge, mark_charge_paid, get_finance_summary
--   * RLS: expenses como inventory_items; charges INSERT/UPDATE direto revogado
--
-- Fora do escopo: Pay/webhook, NF-e, cancel_manual_charge, migracao localStorage.
-- NAO altera migrations anteriores.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 1. Tabela public.expenses
-- ---------------------------------------------------------------------
create table public.expenses (
  id            uuid primary key default gen_random_uuid(),
  owner_id      uuid not null references auth.users(id) on delete restrict,
  company_id    uuid not null references public.company_profiles(id) on delete cascade,
  category      text not null,
  description   text not null,
  amount        numeric(12,2) not null,
  expense_date  date not null,
  quote_id      uuid references public.quotes(id) on delete set null,
  notes         text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),

  constraint expenses_category_valid check (
    category in (
      'fornecedor', 'frete', 'combustivel', 'salario', 'imposto',
      'aluguel', 'servico', 'compra', 'outros'
    )
  ),
  constraint expenses_description_nao_vazia check (btrim(description) <> ''),
  constraint expenses_amount_positivo check (amount > 0)
);

create index idx_expenses_company_date
  on public.expenses (company_id, expense_date desc);

create index idx_expenses_company_category
  on public.expenses (company_id, category);

create trigger expenses_updated_at
  before update on public.expenses
  for each row execute function public.set_updated_at();


-- ---------------------------------------------------------------------
-- 2. Alteracoes incrementais em public.charges
-- ---------------------------------------------------------------------
alter table public.charges
  add column owner_id uuid references auth.users(id) on delete restrict,
  add column quote_id uuid references public.quotes(id) on delete set null;

-- Backfill owner_id se houver linhas legadas (producao auditada: 0).
update public.charges
   set owner_id = (
     select cm.user_id
       from public.company_members cm
      where cm.company_id = charges.company_id
        and cm.role = 'owner'
        and cm.status = 'active'
      order by cm.created_at asc
      limit 1
   )
 where owner_id is null;

do $$
declare v_orfaos integer;
begin
  select count(*) into v_orfaos from public.charges where owner_id is null;
  if v_orfaos > 0 then
    raise exception
      'Backfill incompleto: % charges sem owner_id. Atribua manualmente antes de aplicar esta migration.',
      v_orfaos using errcode = '23502';
  end if;
end $$;

alter table public.charges
  alter column owner_id set not null;

alter table public.charges
  drop constraint if exists charges_payment_method_check;

alter table public.charges
  add constraint charges_payment_method_check check (
    payment_method in (
      'pix', 'boleto', 'credit_card', 'debit_card',
      'payment_link', 'recurring', 'manual'
    )
  );

alter table public.charges
  add constraint charges_manual_sem_provedor check (
    payment_method <> 'manual'
    or provider_charge_id is null
  ),
  add constraint charges_paid_tem_paid_at check (
    status <> 'paid'
    or paid_at is not null
  ),
  add constraint charges_amount_positivo check (amount > 0);


-- ---------------------------------------------------------------------
-- 3. RLS — expenses (padrao inventory_items)
-- ---------------------------------------------------------------------
alter table public.expenses enable row level security;

create policy "expenses_select_company" on public.expenses
  for select to authenticated
  using (public.is_company_member(company_id, auth.uid()));

create policy "expenses_insert_company" on public.expenses
  for insert to authenticated
  with check (
    owner_id = auth.uid()
    and public.is_company_member(company_id, auth.uid())
  );

create policy "expenses_update_company" on public.expenses
  for update to authenticated
  using (
    owner_id = auth.uid()
    or public.is_company_admin(company_id, auth.uid())
  )
  with check (public.is_company_member(company_id, auth.uid()));

create policy "expenses_delete_company" on public.expenses
  for delete to authenticated
  using (
    owner_id = auth.uid()
    or public.is_company_admin(company_id, auth.uid())
  );

create or replace function public.expenses_lock_tenant()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.company_id is distinct from old.company_id then
    raise exception 'company_id de expenses e imutavel.' using errcode = '42501';
  end if;
  if new.owner_id is distinct from old.owner_id then
    raise exception 'owner_id de expenses e imutavel.' using errcode = '42501';
  end if;
  return new;
end;
$$;

create trigger expenses_lock_tenant_biu
  before update on public.expenses
  for each row execute function public.expenses_lock_tenant();


-- ---------------------------------------------------------------------
-- 4. RLS — charges: revoga INSERT/UPDATE direto (so RPC)
-- ---------------------------------------------------------------------
drop policy if exists "charges_insert_company" on public.charges;
drop policy if exists "charges_update_company_admin" on public.charges;


-- ---------------------------------------------------------------------
-- 5. RPC — create_manual_charge
-- ---------------------------------------------------------------------
create or replace function public.create_manual_charge(
  p_company_id     uuid,
  p_amount         numeric,
  p_description    text,
  p_customer_id    uuid         default null,
  p_quote_id       uuid         default null,
  p_due_date       date         default null,
  p_payment_method text         default 'manual'
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid    uuid := auth.uid();
  v_amount numeric := round(coalesce(p_amount, 0), 2);
  v_desc   text := nullif(btrim(coalesce(p_description, '')), '');
  v_method text := coalesce(nullif(btrim(p_payment_method), ''), 'manual');
  v_status text;
  v_id     uuid;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if not public.is_company_member(p_company_id, v_uid) then
    raise exception 'Sem permissao para esta empresa.' using errcode = '42501';
  end if;

  if v_method <> 'manual' then
    raise exception 'Nesta fase so cobranca manual e permitida.' using errcode = '22023';
  end if;

  if v_amount <= 0 then
    raise exception 'Valor da cobranca deve ser positivo.' using errcode = '22023';
  end if;

  if v_desc is null then
    raise exception 'Descricao da cobranca e obrigatoria.' using errcode = '22023';
  end if;

  if p_customer_id is not null then
    perform 1
       from public.customers c
      where c.id = p_customer_id
        and c.company_id = p_company_id;
    if not found then
      raise exception 'Cliente nao pertence a esta empresa.' using errcode = '23503';
    end if;
  end if;

  if p_quote_id is not null then
    perform 1
       from public.quotes q
      where q.id = p_quote_id
        and q.company_id = p_company_id
        and q.status = 'aprovado'::public.quote_status;
    if not found then
      raise exception 'Orcamento nao encontrado ou nao esta aprovado nesta empresa.' using errcode = '23503';
    end if;
  end if;

  v_status := case
    when p_due_date is not null and p_due_date < current_date then 'overdue'
    else 'pending'
  end;

  insert into public.charges (
    company_id, owner_id, customer_id, quote_id, sale_id, order_service_id,
    payment_method, status, description, amount, platform_fee,
    due_date, paid_at, payment_link, boleto_url, pix_qrcode, pix_copy_paste,
    provider_charge_id
  ) values (
    p_company_id, v_uid, p_customer_id, p_quote_id, null, null,
    'manual', v_status, v_desc, v_amount, 0,
    p_due_date, null, null, null, null, null,
    null
  )
  returning id into v_id;

  return v_id;
end;
$$;


-- ---------------------------------------------------------------------
-- 6. RPC — mark_charge_paid
-- ---------------------------------------------------------------------
create or replace function public.mark_charge_paid(
  p_charge_id uuid,
  p_paid_at   timestamptz default now()
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid        uuid := auth.uid();
  v_company_id uuid;
  v_owner_id   uuid;
  v_status     text;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if p_charge_id is null then
    raise exception 'Cobranca nao encontrada.' using errcode = '23503';
  end if;

  select c.company_id, c.owner_id, c.status
    into v_company_id, v_owner_id, v_status
    from public.charges c
   where c.id = p_charge_id
   for update;

  if not found then
    raise exception 'Cobranca nao encontrada.' using errcode = '23503';
  end if;

  if not public.is_company_member(v_company_id, v_uid) then
    raise exception 'Sem permissao para esta empresa.' using errcode = '42501';
  end if;

  if not (v_owner_id = v_uid or public.is_company_admin(v_company_id, v_uid)) then
    raise exception 'Sem permissao para marcar esta cobranca como paga.' using errcode = '42501';
  end if;

  if v_status not in ('pending', 'overdue') then
    raise exception 'Cobranca nao pode ser marcada como paga neste status.' using errcode = '22023';
  end if;

  update public.charges
     set status  = 'paid',
         paid_at = coalesce(p_paid_at, now())
   where id = p_charge_id;
end;
$$;


-- ---------------------------------------------------------------------
-- 7. RPC — get_finance_summary (G4: campos separados, nunca total misto)
-- ---------------------------------------------------------------------
create or replace function public.get_finance_summary(
  p_company_id uuid,
  p_start      timestamptz,
  p_end        timestamptz
)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_uid             uuid := auth.uid();
  v_faturamento     numeric(12,2);
  v_caixa_vendas    numeric(12,2);
  v_caixa_cobrancas numeric(12,2);
  v_caixa_total     numeric(12,2);
  v_despesas        numeric(12,2);
  v_lucro           numeric(12,2);
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if not public.is_company_member(p_company_id, v_uid) then
    raise exception 'Sem permissao para esta empresa.' using errcode = '42501';
  end if;

  if p_start is null or p_end is null or p_start >= p_end then
    raise exception 'Intervalo invalido: p_start deve ser anterior a p_end.' using errcode = '22023';
  end if;

  select coalesce(sum(q.total), 0)::numeric(12,2)
    into v_faturamento
    from public.quotes q
   where q.company_id = p_company_id
     and q.status = 'aprovado'::public.quote_status
     and q.created_at >= p_start
     and q.created_at < p_end;

  select coalesce(sum(s.total), 0)::numeric(12,2)
    into v_caixa_vendas
    from public.sales s
   where s.company_id = p_company_id
     and s.created_at >= p_start
     and s.created_at < p_end;

  select coalesce(sum(c.amount), 0)::numeric(12,2)
    into v_caixa_cobrancas
    from public.charges c
   where c.company_id = p_company_id
     and c.status = 'paid'
     and c.paid_at >= p_start
     and c.paid_at < p_end
     and c.sale_id is null;

  v_caixa_total := v_caixa_vendas + v_caixa_cobrancas;

  select coalesce(sum(e.amount), 0)::numeric(12,2)
    into v_despesas
    from public.expenses e
   where e.company_id = p_company_id
     and e.expense_date >= p_start::date
     and e.expense_date < p_end::date;

  v_lucro := v_caixa_total - v_despesas;

  return jsonb_build_object(
    'period', jsonb_build_object(
      'start', p_start,
      'end', p_end
    ),
    'faturamento', v_faturamento::text,
    'caixa_vendas', v_caixa_vendas::text,
    'caixa_cobrancas', v_caixa_cobrancas::text,
    'caixa_total', v_caixa_total::text,
    'despesas_total', v_despesas::text,
    'lucro_estimado', v_lucro::text,
    'moeda', 'BRL'
  );
end;
$$;


-- ---------------------------------------------------------------------
-- 8. Comentarios
-- ---------------------------------------------------------------------
comment on table public.expenses is
  'Despesas manuais realizadas (saida de caixa). CRUD via PostgREST + RLS; nao usar charges para AP.';

comment on table public.charges is
  'Contas a receber / cobrancas. Nivel 2: escrita somente via RPC (create_manual_charge, mark_charge_paid).';

comment on function public.create_manual_charge(uuid, numeric, text, uuid, uuid, date, text) is
  'Cria cobranca manual (payment_method=manual, sem gateway). Requer membro da empresa; quote opcional precisa estar aprovado.';

comment on function public.mark_charge_paid(uuid, timestamptz) is
  'Marca cobranca pending/overdue como paid com paid_at. Criador ou admin da empresa.';

comment on function public.get_finance_summary(uuid, timestamptz, timestamptz) is
  'Resumo financeiro do periodo [p_start, p_end): faturamento (orc. aprovados), caixa (vendas + cobrancas pagas sem sale_id), despesas e lucro estimado — campos separados (G4).';


-- ---------------------------------------------------------------------
-- 9. Privilegios — P-22: REVOKE anon em tabela nova e funcoes novas
-- ---------------------------------------------------------------------
revoke all on public.expenses from anon;

grant select, insert, update, delete on public.expenses to authenticated;
grant all on public.expenses to service_role;

revoke all on function public.create_manual_charge(uuid, numeric, text, uuid, uuid, date, text) from public;
revoke all on function public.create_manual_charge(uuid, numeric, text, uuid, uuid, date, text) from anon;
grant execute on function public.create_manual_charge(uuid, numeric, text, uuid, uuid, date, text) to authenticated;

revoke all on function public.mark_charge_paid(uuid, timestamptz) from public;
revoke all on function public.mark_charge_paid(uuid, timestamptz) from anon;
grant execute on function public.mark_charge_paid(uuid, timestamptz) to authenticated;

revoke all on function public.get_finance_summary(uuid, timestamptz, timestamptz) from public;
revoke all on function public.get_finance_summary(uuid, timestamptz, timestamptz) from anon;
grant execute on function public.get_finance_summary(uuid, timestamptz, timestamptz) to authenticated;

revoke all on function public.expenses_lock_tenant() from public;
revoke all on function public.expenses_lock_tenant() from anon;
