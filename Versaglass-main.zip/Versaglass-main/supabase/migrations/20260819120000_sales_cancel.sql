-- =====================================================================
-- Cancelamento de venda v2 — `sale_status` + RPC `cancel_sale` com estorno
-- EXATO de estoque.
--
-- Desenho aprovado na Revisao 134; auditoria pre-migration na Revisao 135
-- (sem colisao de nomes, helpers confirmados, quantidade_baixa intacta).
--
-- Seguranca (mesmo padrao de create_sale_with_items):
--   * RPC SECURITY DEFINER com search_path travado; ignora RLS.
--   * Identidade SEMPRE de auth.uid(); cancelada_por nunca vem do cliente.
--   * Cancelamento restrito a is_company_owner_or_admin (owner/admin ativos).
--   * `sales` e `sale_items` continuam SELECT-only — escrita so via RPC.
--
-- Estorno: credita EXATAMENTE sale_items.quantidade_baixa (historica), somando
-- sobre o saldo ATUAL. Rejeita se algum item tiver inventory_item_id NULL com
-- quantidade_baixa > 0 (catalogo excluido depois da venda). Rejeita venda ja
-- cancelada. Atomico: trava venda + linhas de estoque com FOR UPDATE.
--
-- NAO altera migrations anteriores; NAO cria tabela de movimentacao.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 1. Estado da venda — enum + metadados de cancelamento.
--    Default 'finalizada' acerta linhas existentes sem backfill.
-- ---------------------------------------------------------------------
create type public.sale_status as enum ('finalizada', 'cancelada');

alter table public.sales
  add column status public.sale_status not null default 'finalizada',
  add column cancelada_em timestamptz,
  add column cancelada_por uuid references auth.users(id),
  add column motivo_cancelamento text;


-- ---------------------------------------------------------------------
-- 2. RPC — cancela a venda e credita o estoque na MESMA transacao.
-- ---------------------------------------------------------------------
create or replace function public.cancel_sale(
  p_sale_id uuid,
  p_motivo  text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid        uuid := auth.uid();
  v_motivo     text := nullif(btrim(coalesce(p_motivo, '')), '');
  v_company_id uuid;
  v_status     public.sale_status;
  v_orfaos     integer;
  r            record;
begin
  if v_uid is null then
    raise exception 'Autenticacao obrigatoria.' using errcode = '28000';
  end if;

  if v_motivo is null then
    raise exception 'Informe o motivo de cancelamento.' using errcode = '22023';
  end if;

  if p_sale_id is null then
    raise exception 'Venda nao encontrada.' using errcode = '23503';
  end if;

  -- Trava a venda para impedir cancelamento concorrente duplicado.
  select s.company_id, s.status
    into v_company_id, v_status
    from public.sales s
   where s.id = p_sale_id
   for update;

  if not found then
    raise exception 'Venda nao encontrada.' using errcode = '23503';
  end if;

  -- Membro da empresa + owner/admin ativo (mais estrito que quem cria venda).
  if not public.is_company_member(v_company_id, v_uid)
     or not public.is_company_owner_or_admin(v_company_id, v_uid) then
    raise exception 'Sem permissao para cancelar vendas desta empresa.' using errcode = '42501';
  end if;

  if v_status = 'cancelada' then
    raise exception 'Venda ja esta cancelada.' using errcode = '22023';
  end if;

  -- Item excluido do catalogo (inventory_item_id virou NULL) com baixa > 0:
  -- nao ha linha de estoque para creditar — rejeita tudo.
  select count(*)::integer
    into v_orfaos
    from public.sale_items si
   where si.sale_id = p_sale_id
     and si.inventory_item_id is null
     and si.quantidade_baixa > 0;

  if v_orfaos > 0 then
    raise exception
      'Nao e possivel cancelar: % item(ns) da venda perderam o vinculo com o estoque (catalogo excluido). Ajuste manualmente.',
      v_orfaos using errcode = '23503';
  end if;

  -- Estorno agregado por item, ordenado por id (evita deadlock).
  for r in
    select si.inventory_item_id as inv_id,
           sum(si.quantidade_baixa) as total_baixa
      from public.sale_items si
     where si.sale_id = p_sale_id
       and si.inventory_item_id is not null
       and si.quantidade_baixa > 0
     group by si.inventory_item_id
     order by si.inventory_item_id
  loop
    perform 1
       from public.inventory_items i
      where i.id = r.inv_id
        and i.company_id = v_company_id
        and i.ativo = true
      for update;

    if not found then
      raise exception 'Item nao esta disponivel no estoque desta empresa.' using errcode = '23503';
    end if;

    update public.inventory_items
       set quantidade = quantidade + r.total_baixa
     where id = r.inv_id;
  end loop;

  update public.sales
     set status = 'cancelada',
         cancelada_em = now(),
         cancelada_por = v_uid,
         motivo_cancelamento = v_motivo
   where id = p_sale_id;

  return p_sale_id;
end;
$$;


-- ---------------------------------------------------------------------
-- 3. Comentarios — atualiza o que mudou desde a v1.
-- ---------------------------------------------------------------------
comment on type public.sale_status is
  'Estado da venda direta: finalizada (padrao) ou cancelada (via RPC cancel_sale).';

comment on column public.sales.status is
  'Estado da venda. Default finalizada; cancelada so pela RPC cancel_sale (estorno atomico).';

comment on column public.sales.cancelada_em is
  'Timestamp do cancelamento. NULL enquanto status = finalizada.';

comment on column public.sales.cancelada_por is
  'Usuario (auth.users) que cancelou. Sempre auth.uid() na RPC — nunca vem do cliente.';

comment on column public.sales.motivo_cancelamento is
  'Motivo informado no cancelamento. Obrigatorio na RPC cancel_sale.';

comment on table public.sales is
  'Venda direta (balcao). Escrita de cabecalho exclusivamente pela RPC create_sale_with_items; cancelamento exclusivamente pela RPC cancel_sale.';

comment on function public.cancel_sale(uuid, text) is
  'Cancela uma venda finalizada e CREDITA o estoque na mesma transacao, usando EXATAMENTE sale_items.quantidade_baixa. Restrito a is_company_owner_or_admin. Rejeita venda ja cancelada e itens orfaos (inventory_item_id NULL com baixa > 0). Trava venda e linhas de estoque com FOR UPDATE.';


-- ---------------------------------------------------------------------
-- 4. Privilegios — anon nunca executa (regra P-22).
-- ---------------------------------------------------------------------
revoke all on function public.cancel_sale(uuid, text) from public;
revoke all on function public.cancel_sale(uuid, text) from anon;
grant execute on function public.cancel_sale(uuid, text) to authenticated;
