-- =====================================================================
-- Ordens de serviço — `public.service_orders`
--
-- A tela `/app/ordens-servico` existia só com localStorage (EnterpriseCrudPage).
-- Esta migration cria a tabela real, com isolamento por empresa e as mesmas
-- regras de edição/exclusão já usadas no Estoque e nos modelos técnicos.
-- =====================================================================

create type public.service_order_segment as enum (
  'vidracaria',
  'serralheria',
  'esquadrias',
  'marcenaria',
  'marmoraria'
);

create type public.service_order_stage as enum (
  'orcamento',
  'medicao',
  'producao',
  'corte',
  'instalacao',
  'finalizado',
  'pago'
);

create type public.service_order_status as enum (
  'ativo',
  'atrasado',
  'finalizado',
  'cancelado'
);

create sequence public.service_order_number_seq start 1;

create table public.service_orders (
  id               uuid primary key default gen_random_uuid(),
  owner_id         uuid not null references auth.users(id) on delete cascade,
  company_id       uuid not null references public.company_profiles(id) on delete cascade,
  customer_id      uuid references public.customers(id) on delete set null,
  quote_id         uuid references public.quotes(id) on delete set null,
  numero           integer not null default nextval('public.service_order_number_seq'),
  titulo           text not null,
  segmento         public.service_order_segment not null default 'vidracaria',
  etapa            public.service_order_stage not null default 'orcamento',
  status           public.service_order_status not null default 'ativo',
  responsavel      text,
  data_medicao     date,
  data_instalacao  date,
  valor            numeric(12,2) not null default 0,
  custo            numeric(12,2) not null default 0,
  observacoes      text,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),

  constraint service_orders_titulo_nao_vazio check (btrim(titulo) <> ''),
  constraint service_orders_valor_nao_negativo check (valor >= 0),
  constraint service_orders_custo_nao_negativo check (custo >= 0)
);

create index idx_service_orders_company_created
  on public.service_orders (company_id, created_at desc);

create index idx_service_orders_company_etapa
  on public.service_orders (company_id, etapa);

create index idx_service_orders_customer
  on public.service_orders (customer_id)
  where customer_id is not null;

create index idx_service_orders_quote
  on public.service_orders (quote_id)
  where quote_id is not null;

-- Uma OS por orçamento — evita duplicata ao clicar "Gerar OS" duas vezes.
create unique index idx_service_orders_quote_unique
  on public.service_orders (quote_id)
  where quote_id is not null;

create trigger service_orders_updated_at
  before update on public.service_orders
  for each row execute function public.set_updated_at();

alter table public.service_orders enable row level security;

create policy "service_orders_select_company" on public.service_orders
  for select to authenticated
  using (public.is_company_member(company_id, auth.uid()));

create policy "service_orders_insert_company" on public.service_orders
  for insert to authenticated
  with check (
    owner_id = auth.uid()
    and public.is_company_member(company_id, auth.uid())
  );

create policy "service_orders_update_company" on public.service_orders
  for update to authenticated
  using (owner_id = auth.uid() or public.is_company_admin(company_id, auth.uid()))
  with check (public.is_company_member(company_id, auth.uid()));

create policy "service_orders_delete_company" on public.service_orders
  for delete to authenticated
  using (owner_id = auth.uid() or public.is_company_admin(company_id, auth.uid()));

create or replace function public.service_orders_lock_tenant()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.company_id is distinct from old.company_id then
    raise exception 'company_id de service_orders é imutável.' using errcode = '42501';
  end if;
  if new.owner_id is distinct from old.owner_id then
    raise exception 'owner_id de service_orders é imutável.' using errcode = '42501';
  end if;
  return new;
end;
$$;

create trigger service_orders_lock_tenant_biu
  before update on public.service_orders
  for each row execute function public.service_orders_lock_tenant();
