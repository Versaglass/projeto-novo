-- =====================================================================
-- MIGRATION 02 — STORAGE + REALTIME
-- Arquivo: 20260721010000_storage_realtime.sql
-- Depende de: 20260721000000_initial_schema.sql (não altera nada dele)
--
-- Fecha PENDENCIAS_SUPABASE.md #P-13 (Storage) e #P-14 (Realtime).
--
-- PRINCÍPIO: só entra aqui o que o código em src/ COMPROVADAMENTE usa.
-- Nada foi adicionado "para o futuro". Cada objeto abaixo tem, no comentário,
-- o arquivo e a linha que o exigem.
-- =====================================================================


-- =====================================================================
-- 1. STORAGE — bucket `project-images`
--
-- INVENTÁRIO COMPLETO DO CÓDIGO (3 pontos, 1 único bucket):
--
--   ESCRITA
--     src/routes/_authenticated/app.estoque.tsx:461
--       supabase.storage.from('project-images').upload(path, file)
--       path = `${user.id}/estoque/${crypto.randomUUID()}.${ext}`
--       destino: public.inventory_items.imagem_url (guarda o PATH, não a URL)
--
--     src/routes/_authenticated/app.orcamentos.novo.tsx:545
--       supabase.storage.from("project-images").upload(path, file, {upsert:false})
--       path = `${user.id}/${crypto.randomUUID()}.${ext}`
--       destino: public.project_templates.imagem_url (guarda o PATH)
--
--   LEITURA
--     src/components/StorageImage.tsx:30
--       supabase.storage.from("project-images").createSignedUrl(path, 7 dias)
--
--   NÃO EXISTE no projeto: getPublicUrl, .remove(), .list(), .download(),
--   .update(), .move(), .copy() — verificado por varredura em todo o src/.
--   Também não existe nenhum segundo bucket.
--
-- DECISÃO 1 — BUCKET PRIVADO.
--   O frontend JÁ lê por createSignedUrl. Não há uma única chamada a
--   getPublicUrl (o regex de StorageImage.tsx:12 apenas *interpreta* URLs
--   públicas legadas para extrair o path — não gera nenhuma).
--   Portanto bucket privado é 100% compatível com o código atual: nenhuma
--   mudança em src/ é necessária.
--
-- DECISÃO 2 — O PATH COMEÇA COM auth.uid().
--   Os dois uploads montam o path com o id do usuário na PRIMEIRA pasta.
--   As policies validam exatamente isso via storage.foldername(name)[1],
--   e não confiam em nenhum outro pedaço do nome enviado pelo cliente.
--   Path sem pasta (ex.: "foto.jpg") faz foldername() devolver {} e o
--   índice [1] virar NULL — a comparação falha e o acesso é NEGADO.
--   Falha fechada, por construção.
--
-- DECISÃO 3 — LIMITES NO BUCKET, NÃO NO NAVEGADOR.
--   O único controle hoje é accept="image/*" nos <input type="file">
--   (app.estoque.tsx:540, app.orcamentos.novo.tsx:630), que é dica de UI e
--   se contorna trivialmente. Tamanho não é verificado em lugar nenhum.
--   Por isso o limite de 5 MiB e a lista de MIME ficam NO BUCKET, onde o
--   servidor os aplica.
--
-- ISOLAMENTO: é por USUÁRIO (owner_id), não por empresa. Coerente com o
--   schema: inventory_items e project_templates são isolados por owner_id,
--   e company_id nunca é preenchido pela aplicação (ver #P-16).
-- =====================================================================

-- Colunas conferidas em `\d storage.buckets` no banco local antes de escrever:
-- id, name, owner, created_at, updated_at, public, avif_autodetection,
-- file_size_limit, allowed_mime_types, owner_id, type. Nenhuma inventada.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'project-images',
  'project-images',
  false,                 -- PRIVADO. Leitura só por URL assinada.
  5242880,               -- 5 MiB por arquivo.
  array['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif']
);

-- ---------------------------------------------------------------------
-- 1.1 Policies de storage.objects — SOMENTE para `project-images`
--
-- storage.objects já vem com RLS habilitado e ZERO policies (verificado em
-- pg_policies). Negação por padrão: sem as policies abaixo, ninguém além de
-- service_role acessa nada.
--
-- Todas as quatro são restritas a `bucket_id = 'project-images'`. Nenhuma
-- policy genérica que valha para todos os buckets. Nenhum USING (true) ou
-- WITH CHECK (true). Nenhuma policy para `anon` — o papel anônimo não lê,
-- não envia, não atualiza e não remove.
--
-- service_role não precisa de policy: ignora RLS por ser BYPASSRLS.
-- ---------------------------------------------------------------------

-- SELECT: necessário para createSignedUrl (StorageImage.tsx:30).
create policy "project_images_select_own_folder" on storage.objects
  for select to authenticated
  using (
    bucket_id = 'project-images'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- INSERT: os dois uploads. O usuário só grava dentro da própria pasta.
create policy "project_images_insert_own_folder" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'project-images'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- UPDATE: nenhum ponto do código atualiza objeto (upload usa upsert:false).
-- Mantida assim mesmo para que uma troca de imagem futura não exija migration,
-- e porque sem ela um UPDATE seria negado — mas o dono continua sendo o único
-- que pode: `using` impede tocar no arquivo alheio e `with check` impede mover
-- o arquivo para a pasta de outro usuário.
create policy "project_images_update_own_folder" on storage.objects
  for update to authenticated
  using (
    bucket_id = 'project-images'
    and (storage.foldername(name))[1] = auth.uid()::text
  )
  with check (
    bucket_id = 'project-images'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- DELETE: nenhum ponto do código remove objeto hoje. Restrita ao dono para
-- que a limpeza de imagem órfã, quando for implementada, já nasça segura.
create policy "project_images_delete_own_folder" on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'project-images'
    and (storage.foldername(name))[1] = auth.uid()::text
  );


-- =====================================================================
-- 2. REALTIME — publicação `supabase_realtime`
--
-- INVENTÁRIO COMPLETO DAS ASSINATURAS (3 canais, 2 tabelas):
--
--   src/components/NotificationsBell.tsx:20-30
--     canal "auth_events_bell" · public.auth_events
--     INSERT  -> incrementa contador  (ignora o payload)
--     UPDATE  -> refaz a contagem     (ignora o payload)
--     DELETE  -> refaz a contagem     (ignora o payload)
--     limpeza: removeChannel no unmount (linha 33) ✔
--
--   src/routes/_authenticated/app.admin.notificacoes.tsx:46-53
--     canal "auth_events" · public.auth_events
--     INSERT  -> usa payload.new (kind, email)
--     limpeza: removeChannel no unmount (linha 55) ✔
--
--   src/routes/_authenticated/app.admin.logs.tsx:45-50
--     canal "server_logs" · public.server_logs
--     INSERT  -> usa payload.new (linha completa do log)
--     limpeza: removeChannel no unmount (linha 52) ✔
--
-- Nenhum filtro é usado em nenhuma das três. Ambas as tabelas existem na
-- migration inicial. NENHUMA outra tabela é assinada em todo o projeto.
--
-- POR QUE APENAS ESTAS DUAS: publicar tabela não assinada só aumenta o volume
-- de WAL e a superfície de exposição. As outras 38 tabelas ficam de fora.
--
-- RLS CONTINUA VALENDO. Realtime não substitui policy: o servidor de Realtime
-- reavalia a RLS do assinante antes de entregar cada linha. auth_events e
-- server_logs só são legíveis por is_platform_admin(), então apenas o admin
-- da plataforma recebe eventos. O NotificationsBell é montado para todo
-- usuário autenticado, mas um usuário comum simplesmente não recebe nada —
-- é o comportamento correto, não um defeito.
--
-- REPLICA IDENTITY: mantida em DEFAULT (chave primária) nas duas tabelas.
--   Nenhum dos três callbacks lê `payload.old`. Os dois que reagem a UPDATE e
--   DELETE (NotificationsBell) descartam o payload e refazem a consulta.
--   REPLICA IDENTITY FULL faria o WAL carregar TODAS as colunas antigas de
--   cada linha alterada — inclusive e-mail e metadata de auth_events — sem
--   nenhum consumidor para isso. Seria custo e exposição sem ganho.
--   Ver regra 6 desta fase.
--
-- A publicação supabase_realtime é criada pela plataforma e NÃO é recriada
-- aqui; apenas recebe duas tabelas. Nada é removido dela.
-- =====================================================================

-- Alimenta NotificationsBell.tsx (INSERT/UPDATE/DELETE) e
-- app.admin.notificacoes.tsx (INSERT). Leitura restrita ao admin por RLS.
alter publication supabase_realtime add table public.auth_events;

-- Alimenta app.admin.logs.tsx (INSERT). Leitura restrita ao admin por RLS.
alter publication supabase_realtime add table public.server_logs;


-- =====================================================================
-- 3. O QUE ESTA MIGRATION DELIBERADAMENTE NÃO FAZ
--
--   · Não cria segundo bucket: não existe outro no código.
--   · Não torna project-images público: o código já usa URL assinada.
--   · Não insere nenhum objeto de demonstração.
--   · Não referencia project ref, URL ou id de nenhum projeto remoto.
--   · Não altera policy, tabela, função ou view da migration inicial.
--   · Não publica as outras 38 tabelas em supabase_realtime.
--   · Não define REPLICA IDENTITY FULL.
-- =====================================================================
