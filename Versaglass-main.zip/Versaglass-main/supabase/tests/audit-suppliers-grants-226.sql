-- Revisão 226 — auditoria pré-push (somente leitura)
-- Confirma que a tabela existe e que o GRANT ainda NÃO está completo.

with audit as (
  select 1 as n, 'A1 · tabela suppliers existe?'::text as verificacao,
    coalesce((select tablename from pg_tables where schemaname='public' and tablename='suppliers'), '(nenhuma)') as resultado,
    'suppliers'::text as esperado
  union all
  select 2, 'A2 · sequence ligada a suppliers?',
    coalesce((
      select string_agg(c.relname, ' | ' order by c.relname)
      from pg_class c
      join pg_depend d on d.objid = c.oid
      join pg_class t on t.oid = d.refobjid
      join pg_namespace n on n.oid = t.relnamespace
      where c.relkind = 'S' and n.nspname = 'public' and t.relname = 'suppliers'
    ), '(nenhuma)'),
    '(nenhuma)'
  union all
  select 3, 'A3 · GRANT select authenticated?',
    coalesce((
      select has_table_privilege('authenticated', 'public.suppliers', 'select')::text
    ), 'false'),
    'true'
  union all
  select 4, 'A4 · GRANT insert authenticated?',
    coalesce((
      select has_table_privilege('authenticated', 'public.suppliers', 'insert')::text
    ), 'false'),
    'true'
  union all
  select 5, 'A5 · GRANT update authenticated?',
    coalesce((
      select has_table_privilege('authenticated', 'public.suppliers', 'update')::text
    ), 'false'),
    'true'
  union all
  select 6, 'A6 · GRANT delete authenticated?',
    coalesce((
      select has_table_privilege('authenticated', 'public.suppliers', 'delete')::text
    ), 'false'),
    'true'
  union all
  select 7, 'A7 · anon SEM select (P-22)?',
    coalesce((
      select (not has_table_privilege('anon', 'public.suppliers', 'select'))::text
    ), 'false'),
    'true'
)
select n, verificacao, resultado, esperado,
       case when resultado = esperado then 'OK' else 'PENDENTE_GRANT' end as status
  from audit order by n;
