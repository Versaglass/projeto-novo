with audit as (
  select
    1 as n,
    'A1 · colisoes: tabelas sales/sale_items existem (baseline da v1)?'::text as verificacao,
    coalesce(
      (select string_agg(tablename, ' | ' order by tablename)
         from pg_tables
        where schemaname='public'
          and tablename in ('sales','sale_items')),
      '(nenhuma)'
    )::text as resultado,
    'sale_items | sales'::text as esperado

  union all
  select
    2,
    'A2 · colisoes: enum sale_status ja existe?',
    coalesce(
      (select string_agg(t.typname, ' | ' order by t.typname)
         from pg_type t
         join pg_namespace n on n.oid = t.typnamespace
        where n.nspname='public'
          and t.typname='sale_status'),
      '(nenhuma)'
    ),
    '(nenhuma)'

  union all
  select
    3,
    'A3 · colisoes: colunas novas em sales ja existem?',
    coalesce(
      (select string_agg(column_name, ' | ' order by column_name)
         from information_schema.columns
        where table_schema='public'
          and table_name='sales'
          and column_name in ('status','cancelada_em','cancelada_por','motivo_cancelamento')),
      '(nenhuma)'
    ),
    '(nenhuma)'

  union all
  select
    4,
    'A4 · colisoes: funcao cancel_sale ja existe?',
    coalesce(
      (select string_agg(p.proname, ' | ' order by p.proname)
         from pg_proc p
         join pg_namespace n on n.oid = p.pronamespace
        where n.nspname='public'
          and p.proname='cancel_sale'),
      '(nenhuma)'
    ),
    '(nenhuma)'
)
select n, verificacao, resultado, esperado
  from audit
 order by n;
