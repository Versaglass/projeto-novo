/**
 * Testes locais da migration Financeiro Nivel 2.1 (Revisao 160).
 * Uso: node supabase/tests/test-finance-cashflow-personal.mjs
 * Requer: supabase db reset --local ja aplicado + Docker rodando.
 */
import { execSync } from "node:child_process";
import { writeFileSync, unlinkSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { createClient } from "@supabase/supabase-js";

const URL = "http://127.0.0.1:55321";
const ANON =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6ImFub24iLCJleHAiOjE5ODM4MTI5OTZ9.CRXP1A7WOeoJeXxjNni43kdQwgnWNReilDMblYTn_I0";
const SERVICE =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImV4cCI6MTk4MzgxMjk5Nn0.EGIM96RAZx35lJzdJsyH-qQwv8Hdp7fsn3W0YpN81IU";

const admin = createClient(URL, SERVICE, {
  auth: { autoRefreshToken: false, persistSession: false },
});

let passed = 0;
let failed = 0;

function assert(name, cond, detail = "") {
  if (cond) {
    passed++;
    console.log(`  OK  ${name}`);
  } else {
    failed++;
    console.error(`  FAIL ${name}${detail ? ` — ${detail}` : ""}`);
  }
}

async function signUp(email, password) {
  const { data, error } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
  });
  if (error) throw error;
  return data.user;
}

async function clientFor(email, password) {
  const c = createClient(URL, ANON, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
  const { error } = await c.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return c;
}

function monthBounds() {
  const now = new Date();
  const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1, 0, 0, 0));
  const end = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1, 0, 0, 0));
  return { start: start.toISOString(), end: end.toISOString() };
}

async function main() {
  const ts = Date.now();
  const ownerEmail = `fin160-owner-${ts}@test.local`;
  const sellerEmail = `fin160-seller-${ts}@test.local`;
  const pass = "TestPass123!";
  const { start, end } = monthBounds();
  const expenseDate = new Date().toISOString().slice(0, 10);

  console.log("=== Financeiro Nivel 2.1 — testes locais (Rev. 160) ===\n");

  const ownerUser = await signUp(ownerEmail, pass);
  const sellerUser = await signUp(sellerEmail, pass);
  const owner = await clientFor(ownerEmail, pass);
  const seller = await clientFor(sellerEmail, pass);

  const { data: co, error: coErr } = await owner.rpc("create_company_with_owner", {
    p_company_name: `Empresa Fin160 ${ts}`,
  });
  if (coErr) throw coErr;
  const companyId = co.company_id;

  const { error: addSellerErr } = await admin.rpc("add_company_seller", {
    p_company_id: companyId,
    p_requester: ownerUser.id,
    p_user_id: sellerUser.id,
  });
  if (addSellerErr) throw addSellerErr;

  const { data: saleId, error: saleErr } = await owner.rpc("create_sale_with_items", {
    p_company_id: companyId,
    p_items: [
      {
        descricao: "Venda caixa teste",
        unidade: "un",
        largura: 0,
        altura: 0,
        quantidade: 1,
        preco_unit: 1000,
        desconto: 0,
      },
    ],
    p_forma_pagamento: "dinheiro",
  });
  if (saleErr) throw saleErr;

  const { data: opExpense, error: opErr } = await owner
    .from("expenses")
    .insert({
      company_id: companyId,
      owner_id: ownerUser.id,
      expense_kind: "operacional",
      category: "fornecedor",
      description: "Material operacional",
      amount: 150,
      expense_date: expenseDate,
    })
    .select("id")
    .single();
  if (opErr) throw opErr;
  assert("owner insere despesa operacional", !!opExpense?.id);

  const { data: pessoalExpense, error: pesErr } = await owner
    .from("expenses")
    .insert({
      company_id: companyId,
      owner_id: ownerUser.id,
      expense_kind: "pessoal",
      category: "pro_labore",
      description: "Retirada pessoal teste",
      amount: 500,
      expense_date: expenseDate,
    })
    .select("id")
    .single();
  if (pesErr) throw pesErr;
  assert("owner insere despesa pessoal", !!pessoalExpense?.id);

  const { data: sellerOp, error: sellerOpErr } = await seller
    .from("expenses")
    .select("id, expense_kind")
    .eq("company_id", companyId);
  if (sellerOpErr) throw sellerOpErr;

  assert(
    "seller ve despesa operacional",
    sellerOp?.some((r) => r.id === opExpense.id),
    JSON.stringify(sellerOp)
  );
  assert(
    "seller NAO ve despesa pessoal",
    !sellerOp?.some((r) => r.id === pessoalExpense.id),
    JSON.stringify(sellerOp)
  );

  const { error: sellerPesInsErr } = await seller.from("expenses").insert({
    company_id: companyId,
    owner_id: sellerUser.id,
    expense_kind: "pessoal",
    category: "lazer",
    description: "Tentativa seller pessoal",
    amount: 50,
    expense_date: expenseDate,
  });
  assert("seller NAO insere despesa pessoal", !!sellerPesInsErr);

  const { data: summary, error: sumErr } = await owner.rpc("get_finance_summary", {
    p_company_id: companyId,
    p_start: start,
    p_end: end,
  });
  if (sumErr) throw sumErr;

  assert(
    "summary despesas_total exclui pessoal (150)",
    summary.despesas_total === "150.00",
    summary.despesas_total
  );
  assert(
    "summary lucro = caixa - operacional",
    summary.lucro_estimado === "850.00",
    summary.lucro_estimado
  );
  assert(
    "faturamento presente mas separado do caixa (G4)",
    summary.faturamento !== undefined && summary.caixa_total !== summary.faturamento
  );

  const { data: cashflow, error: cfErr } = await owner.rpc("get_finance_cashflow", {
    p_company_id: companyId,
    p_start: start,
    p_end: end,
  });
  if (cfErr) throw cfErr;

  assert("cashflow granularity week", cashflow.granularity === "week");
  assert("cashflow tem buckets", Array.isArray(cashflow.buckets) && cashflow.buckets.length >= 1);

  const totals = cashflow.totals;
  assert(
    "cashflow caixa_entrada inclui venda (1000)",
    totals.caixa_entrada === "1000.00",
    totals.caixa_entrada
  );
  assert(
    "cashflow despesas_operacionais exclui pessoal (150)",
    totals.despesas_operacionais === "150.00",
    totals.despesas_operacionais
  );

  const bucketSum = cashflow.buckets.reduce(
    (acc, b) => ({
      caixa: acc.caixa + parseFloat(b.caixa_entrada),
      desp: acc.desp + parseFloat(b.despesas_operacionais),
    }),
    { caixa: 0, desp: 0 }
  );
  assert(
    "soma buckets bate totals caixa",
    bucketSum.caixa.toFixed(2) === totals.caixa_entrada,
    `${bucketSum.caixa} vs ${totals.caixa_entrada}`
  );
  assert(
    "soma buckets bate totals despesas",
    bucketSum.desp.toFixed(2) === totals.despesas_operacionais,
    `${bucketSum.desp} vs ${totals.despesas_operacionais}`
  );

  console.log(`\n=== Resultado: ${passed} OK, ${failed} FAIL ===`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
