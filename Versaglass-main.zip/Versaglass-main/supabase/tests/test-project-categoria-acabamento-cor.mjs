/**
 * Testes locais — Rev. 182 (categoria + acabamento + cor).
 * Uso: node supabase/tests/test-project-categoria-acabamento-cor.mjs
 * Requer: supabase db reset --local ja aplicado.
 */
import { createClient } from "@supabase/supabase-js";

const URL = "http://127.0.0.1:55321";
const ANON =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6ImFub24iLCJleHAiOjE5ODM4MTI5OTZ9.CRXP1A7WOeoJeXxjNni43kdQwgnWNReilDMblYTn_I0";
const SERVICE =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImV4cCI6MTk4MzgxMjk5Nn0.EGIM96RAZx35lJzdJsyH-qQwv8Hdp7fsn3W0YpN81IU";

const admin = createClient(URL, SERVICE, {
  auth: { autoRefreshToken: false, persistSession: false },
});

let passed = 0;
let failed = 0;

function assert(name, cond, detail = "") {
  if (cond) {
    passed++;
    console.log(`  OK  ${name}`);
  } else {
    failed++;
    console.error(`  FAIL ${name}${detail ? ` — ${detail}` : ""}`);
  }
}

async function signUp(email, password) {
  const { data, error } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
  });
  if (error) throw error;
  return data.user;
}

async function clientFor(email, password) {
  const c = createClient(URL, ANON, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
  const { error } = await c.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return c;
}

function baseRow(companyId, userId, overrides) {
  return {
    company_id: companyId,
    owner_id: userId,
    area: "vidracaria",
    subtipo: "box",
    nome: "Modelo teste",
    largura_padrao: 1,
    altura_padrao: 1,
    preco_m2: 0,
    ...overrides,
  };
}

async function main() {
  const ts = Date.now();
  const email = `cat-acab-${ts}@test.local`;
  const pass = "TestPass123!";

  console.log("=== project_templates categoria/acabamento/cor — testes locais ===\n");

  const user = await signUp(email, pass);
  const client = await clientFor(email, pass);

  const { data: co, error: coErr } = await client.rpc("create_company_with_owner", {
    p_company_name: `Empresa Cat ${ts}`,
  });
  if (coErr) throw coErr;
  const companyId = co.company_id;

  // 1) refletivo + cor → OK
  {
    const { data, error } = await client
      .from("project_templates")
      .insert(
        baseRow(companyId, user.id, {
          nome: "Refletivo prata",
          categoria: "refletivo",
          cor: "prata",
        }),
      )
      .select("id, categoria, cor, acabamento")
      .single();
    assert("refletivo + cor=prata grava", !error && data?.categoria === "refletivo" && data?.cor === "prata", error?.message);
  }

  // 2) cor preenchida com categoria != refletivo → CHECK rejeita
  {
    const { error } = await client
      .from("project_templates")
      .insert(
        baseRow(companyId, user.id, {
          nome: "Temperado com cor ilegal",
          categoria: "temperado",
          cor: "azul",
        }),
      );
    const msg = String(error?.message ?? error?.code ?? "");
    assert(
      "cor com categoria!=refletivo rejeitado pelo CHECK",
      !!error && (msg.includes("project_templates_cor_refletivo") || msg.includes("check") || error?.code === "23514"),
      msg,
    );
  }

  // 3) tres categorias novas
  for (const cat of ["refletivo", "organico", "canelado"]) {
    const { data, error } = await client
      .from("project_templates")
      .insert(
        baseRow(companyId, user.id, {
          nome: `Novo ${cat}`,
          categoria: cat,
          subtipo: cat === "organico" ? "espelho" : "box",
        }),
      )
      .select("id, categoria")
      .single();
    assert(`categoria=${cat} grava`, !error && data?.categoria === cat, error?.message);
  }

  // 4) acabamento preenchido (vidro_comum) → OK
  {
    const { data, error } = await client
      .from("project_templates")
      .insert(
        baseRow(companyId, user.id, {
          nome: "Comum lapidado",
          categoria: "vidro_comum",
          acabamento: "lapidado",
        }),
      )
      .select("id, acabamento")
      .single();
    assert("acabamento=lapidado grava", !error && data?.acabamento === "lapidado", error?.message);
  }

  // 5) acabamento NULL (temperado) → OK
  {
    const { data, error } = await client
      .from("project_templates")
      .insert(
        baseRow(companyId, user.id, {
          nome: "Temperado sem acabamento",
          categoria: "temperado",
        }),
      )
      .select("id, acabamento, cor")
      .single();
    assert(
      "acabamento/cor omitidos = NULL",
      !error && data?.acabamento === null && data?.cor === null,
      error?.message,
    );
  }

  // 6) acabamento em temperado → CHECK rejeita (design Rev. 180 §2)
  {
    const { error } = await client
      .from("project_templates")
      .insert(
        baseRow(companyId, user.id, {
          nome: "Temperado com acabamento ilegal",
          categoria: "temperado",
          acabamento: "cortado",
        }),
      );
    const msg = String(error?.message ?? error?.code ?? "");
    assert(
      "acabamento com categoria=temperado rejeitado pelo CHECK",
      !!error && (msg.includes("project_templates_acabamento_categoria") || msg.includes("check") || error?.code === "23514"),
      msg,
    );
  }

  // 7) enums legados intactos
  {
    const { data, error } = await client
      .from("project_templates")
      .insert(
        baseRow(companyId, user.id, {
          nome: "Espelho legado",
          categoria: "espelho",
          acabamento: "bisote",
        }),
      )
      .select("categoria, acabamento")
      .single();
    assert("espelho + bisote (legado+acabamento) grava", !error && data?.categoria === "espelho" && data?.acabamento === "bisote", error?.message);
  }

  console.log(`\n=== Resultado: ${passed} OK · ${failed} FAIL ===`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
