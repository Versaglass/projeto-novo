-- =====================================================================
-- Testes manuais / locais de autorização — manufacturer catalog (Fase 1)
--
-- Executar no SQL Editor do Supabase (ou psql) COM sessões distintas.
-- NÃO rodar em produção com dados reais sem cuidado.
--
-- Premissa: migration 20260910120000_manufacturer_catalog aplicada.
--
-- Papéis a validar:
--   A) platform admin  → user_roles.role = 'admin'     → SELECT/INSERT/UPDATE/DELETE OK
--   B) company admin   → company_members.role = 'admin'
--                        SEM user_roles.role = 'admin' → SELECT OK (ativos); INSERT NEGADO
--   C) vendedor        → user_roles.role = 'vendedor'  → SELECT OK; INSERT NEGADO
--   D) instalador      → user_roles.role = 'instalador'→ SELECT OK; INSERT NEGADO
-- =====================================================================

-- 0) Sanity: policies existem
select
  pol.polname,
  rel.relname
from pg_policy pol
join pg_class rel on rel.oid = pol.polrelid
join pg_namespace n on n.oid = rel.relnamespace
where n.nspname = 'public'
  and rel.relname in ('product_manufacturers', 'manufacturer_products')
order by rel.relname, pol.polname;

-- Esperado (8 policies):
-- manufacturer_products_{select,insert,update,delete}
-- product_manufacturers_{select,insert,update,delete}

-- 1) Como platform admin (substitua USER_ID):
-- select set_config('request.jwt.claim.sub', '<platform-admin-uuid>', true);
-- ou use o SQL Editor autenticado como esse usuário.
--
-- insert into public.product_manufacturers (name, normalized_name)
-- values ('Fabricante Teste', 'fabricante teste')
-- returning id;
-- → deve SUCCEED
--
-- insert into public.manufacturer_products (
--   manufacturer_id, source_code, normalized_source_code, name
-- ) values (
--   '<id>', 'AL 1', 'al 1', 'Produto teste'
-- );
-- → deve SUCCEED
--
-- delete from public.manufacturer_products where normalized_source_code = 'al 1';
-- delete from public.product_manufacturers where normalized_name = 'fabricante teste';

-- 2) Como company admin / vendedor / instalador (sem user_roles.admin):
-- insert into public.product_manufacturers (name, normalized_name)
-- values ('Hack', 'hack');
-- → deve FALHAR com policy violation (42501)
--
-- select count(*) from public.product_manufacturers where active = true;
-- → deve SUCCEED (leitura permitida)

-- 3) Unicidade
-- insert ... mesmo normalized_name duas vezes → unique_violation
-- insert ... mesmo (manufacturer_id, normalized_source_code) → unique_violation

-- 4) Confirmar que company_members.role = 'admin' NÃO implica is_platform_admin:
-- select public.is_platform_admin('<company-admin-user-uuid>');
-- → false
-- select public.has_role('<company-admin-user-uuid>', 'admin');
-- → false
