-- Revisao 157 — pre-push: colisao A1-A9 (Financeiro Nivel 2)
with audit as (
  select 1 as n, 'A1 · tabela expenses/financial_entries/despesas'::text as verificacao,
    coalesce((select string_agg(tablename, ' | ' order by tablename) from pg_tables
      where schemaname = 'public' and tablename in ('expenses', 'financial_entries', 'despesas')), '(nenhuma)') as resultado,
    '(nenhuma)' as esperado
  union all
  select 2, 'A2 · coluna charges.owner_id',
    coalesce((select string_agg(column_name || ':' || data_type, ' | ') from information_schema.columns
      where table_schema = 'public' and table_name = 'charges' and column_name = 'owner_id'), '(nenhuma)'),
    '(nenhuma)'
  union all
  select 3, 'A3 · coluna charges.quote_id',
    coalesce((select string_agg(column_name || ':' || data_type, ' | ') from information_schema.columns
      where table_schema = 'public' and table_name = 'charges' and column_name = 'quote_id'), '(nenhuma)'),
    '(nenhuma)'
  union all
  select 4, 'A4 · funcoes RPC financeiro',
    coalesce((select string_agg(p.proname, ' | ' order by p.proname) from pg_proc p
      join pg_namespace n on n.oid = p.pronamespace where n.nspname = 'public'
      and p.proname in ('create_manual_charge', 'mark_charge_paid', 'get_finance_summary', 'cancel_manual_charge')), '(nenhuma)'),
    '(nenhuma)'
  union all
  select 5, 'A5 · enum expense_category/expense_status',
    coalesce((select string_agg(t.typname, ' | ' order by t.typname) from pg_type t
      join pg_namespace n on n.oid = t.typnamespace where n.nspname = 'public'
      and t.typname in ('expense_category', 'expense_status')), '(nenhuma)'),
    '(nenhuma)'
  union all
  select 6, 'A6 · payment_method tipo',
    coalesce((select c.data_type || coalesce(' -> ' || c.udt_name, '') from information_schema.columns c
      where c.table_schema = 'public' and c.table_name = 'charges' and c.column_name = 'payment_method'), '(ausente)'),
    'text (CHECK inline — NAO enum)'
  union all
  select 7, 'A7 · manual ja no CHECK',
    case when exists (select 1 from pg_constraint con join pg_class rel on rel.oid = con.conrelid
      join pg_namespace nsp on nsp.oid = rel.relnamespace where nsp.nspname = 'public' and rel.relname = 'charges'
      and con.contype = 'c' and pg_get_constraintdef(con.oid) ilike '%payment_method%'
      and pg_get_constraintdef(con.oid) ilike '%manual%') then 'true' else 'false' end,
    'false'
  union all
  select 8, 'A8 · FK charges.sale_id',
    coalesce((select string_agg(con.conname || '->' || ccu.table_name, ' | ') from information_schema.table_constraints con
      join information_schema.key_column_usage kcu on kcu.constraint_name = con.constraint_name and kcu.table_schema = con.table_schema
      join information_schema.constraint_column_usage ccu on ccu.constraint_name = con.constraint_name and ccu.table_schema = con.table_schema
      where con.table_schema = 'public' and con.table_name = 'charges' and con.constraint_type = 'FOREIGN KEY' and kcu.column_name = 'sale_id'), '(nenhuma)'),
    '(nenhuma) — P-12; uuid livre'
  union all
  select 9, 'A9 · indices idx_expenses_* / idx_charges_quote',
    coalesce((select string_agg(indexname, ' | ' order by indexname) from pg_indexes where schemaname = 'public'
      and (indexname like 'idx_expenses%' or indexname = 'idx_charges_quote' or indexname = 'idx_charges_owner')), '(nenhuma)'),
    '(nenhuma)'
)
select n, verificacao, resultado, esperado from audit order by n;
