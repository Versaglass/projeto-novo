/**
 * Verificação pontual — cenário 1 (Revisão 136): consulta Postgres após cancelamento.
 * Uso: node supabase/tests/verify-cancel-scenario1.mjs
 */
import { createClient } from "@supabase/supabase-js";

const URL = "http://127.0.0.1:55321";
const ANON =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6ImFub24iLCJleHAiOjE5ODM4MTI5OTZ9.CRXP1A7WOeoJeXxjNni43kdQwgnWNReilDMblYTn_I0";
const SERVICE =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImV4cCI6MTk4MzgxMjk5Nn0.EGIM96RAZx35lJzdJsyH-qQwv8Hdp7fsn3W0YpN81IU";

const admin = createClient(URL, SERVICE, {
  auth: { autoRefreshToken: false, persistSession: false },
});

async function signUp(email, password) {
  const { data, error } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
  });
  if (error) throw error;
  return data.user;
}

async function clientFor(email, password) {
  const c = createClient(URL, ANON, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
  const { error } = await c.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return c;
}

async function main() {
  const ts = Date.now();
  const ownerEmail = `verify-owner-${ts}@test.local`;
  const pass = "TestPass123!";

  const ownerUser = await signUp(ownerEmail, pass);
  const owner = await clientFor(ownerEmail, pass);

  const { data: co, error: coErr } = await owner.rpc("create_company_with_owner", {
    p_company_name: `Verify Empresa ${ts}`,
  });
  if (coErr) throw coErr;
  const companyId = co.company_id;

  const { data: inv, error: invErr } = await owner
    .from("inventory_items")
    .insert({
      company_id: companyId,
      owner_id: ownerUser.id,
      categoria: "ferragem",
      nome: "Parafuso verify scenario1",
      unidade: "un",
      quantidade: 10,
      preco_venda: 2,
      ativo: true,
    })
    .select("id, quantidade")
    .single();
  if (invErr) throw invErr;

  const { data: saleId, error: saleErr } = await owner.rpc("create_sale_with_items", {
    p_company_id: companyId,
    p_items: [
      {
        inventory_item_id: inv.id,
        descricao: "Parafuso verify scenario1",
        unidade: "un",
        largura: 0,
        altura: 0,
        quantidade: 3,
        preco_unit: 2,
        desconto: 0,
      },
    ],
    p_forma_pagamento: "dinheiro",
  });
  if (saleErr) throw saleErr;

  const motivo = "Teste de estorno automatico";

  const { error: cancelErr } = await owner.rpc("cancel_sale", {
    p_sale_id: saleId,
    p_motivo: motivo,
  });
  if (cancelErr) throw cancelErr;

  // Consulta direta via service_role (Postgres/PostgREST — linha real)
  const { data: row, error: rowErr } = await admin
    .from("sales")
    .select("id, numero, status, cancelada_em, cancelada_por, motivo_cancelamento, company_id")
    .eq("id", saleId)
    .single();
  if (rowErr) throw rowErr;

  // Simula listagem atual (useSales — sem filtrar canceladas)
  const { data: listagem, error: listErr } = await owner
    .from("sales")
    .select("id, numero, created_at, total, forma_pagamento, cliente_nome")
    .eq("company_id", companyId)
    .order("created_at", { ascending: false });
  if (listErr) throw listErr;

  const naListagem = listagem?.some((s) => s.id === saleId);

  console.log(JSON.stringify({
    sale_id: saleId,
    owner_user_id: ownerUser.id,
    company_id: companyId,
    postgres_direto: {
      status: row.status,
      cancelada_em: row.cancelada_em,
      cancelada_por: row.cancelada_por,
      motivo_cancelamento: row.motivo_cancelamento,
    },
    listagem: {
      total_vendas_retornadas: listagem?.length ?? 0,
      venda_cancelada_aparece: naListagem,
      ids: listagem?.map((s) => s.id),
    },
  }, null, 2));
}

main().catch((e) => {
  console.error("ERRO:", e);
  process.exit(1);
});
