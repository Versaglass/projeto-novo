-- Revisão 226 — verificação pós-push (somente leitura)

with audit as (
  select 1 as n, 'B1 · GRANT select+insert+update+delete authenticated'::text as verificacao,
    (
      has_table_privilege('authenticated', 'public.suppliers', 'select')
      and has_table_privilege('authenticated', 'public.suppliers', 'insert')
      and has_table_privilege('authenticated', 'public.suppliers', 'update')
      and has_table_privilege('authenticated', 'public.suppliers', 'delete')
    )::text as resultado,
    'true'::text as esperado
  union all
  select 2, 'B2 · anon SEM select/insert/update/delete (P-22)',
    (
      not has_table_privilege('anon', 'public.suppliers', 'select')
      and not has_table_privilege('anon', 'public.suppliers', 'insert')
      and not has_table_privilege('anon', 'public.suppliers', 'update')
      and not has_table_privilege('anon', 'public.suppliers', 'delete')
    )::text,
    'true'
  union all
  select 3, 'B3 · policies suppliers ainda 4',
    coalesce((select count(*)::text from pg_policies where schemaname='public' and tablename='suppliers'), '0'),
    '4'
)
select n, verificacao, resultado, esperado,
       case when resultado = esperado then 'OK' else 'VERIFICAR' end as status
  from audit order by n;
