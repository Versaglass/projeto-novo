-- Revisao 161 pre-push — colisao A1-A5 (Financeiro 2.1)
with audit as (
  select
    1 as n,
    'A1 · colisao: tipo expense_kind ja existe?'::text as verificacao,
    coalesce(
      (select string_agg(t.typname, ' | ' order by t.typname)
         from pg_type t
         join pg_namespace n on n.oid = t.typnamespace
        where n.nspname = 'public'
          and t.typname in ('expense_kind', 'expense_category')),
      '(nenhuma)'
    )::text as resultado,
    '(nenhuma)'::text as esperado

  union all
  select
    2,
    'A2 · colisao: coluna expenses.expense_kind ja existe?',
    coalesce(
      (select string_agg(column_name || ':' || data_type, ' | ')
         from information_schema.columns
        where table_schema = 'public'
          and table_name = 'expenses'
          and column_name = 'expense_kind'),
      '(nenhuma)'
    ),
    '(nenhuma)'

  union all
  select
    3,
    'A3 · colisao: RPC get_finance_cashflow ja existe?',
    coalesce(
      (select string_agg(p.proname, ' | ' order by p.proname)
         from pg_proc p
         join pg_namespace n on n.oid = p.pronamespace
        where n.nspname = 'public'
          and p.proname in ('get_finance_cashflow')),
      '(nenhuma)'
    ),
    '(nenhuma)'

  union all
  select
    4,
    'A4 · colisao: tabela owner_withdrawals / personal_expenses?',
    coalesce(
      (select string_agg(tablename, ' | ' order by tablename)
         from pg_tables
        where schemaname = 'public'
          and tablename in ('owner_withdrawals', 'personal_expenses', 'gastos_pessoais')),
      '(nenhuma)'
    ),
    '(nenhuma)'

  union all
  select
    5,
    'A5 · colisao: indice idx_expenses_kind?',
    coalesce(
      (select string_agg(indexname, ' | ' order by indexname)
         from pg_indexes
        where schemaname = 'public'
          and tablename = 'expenses'
          and indexname like '%kind%'),
      '(nenhuma)'
    ),
    '(nenhuma)'
)
select n, verificacao, resultado, esperado
  from audit
 order by n;
