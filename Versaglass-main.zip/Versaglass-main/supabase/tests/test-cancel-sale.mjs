/**
 * Testes locais da migration cancel_sale (Revisao 136).
 * Uso: node supabase/tests/test-cancel-sale.mjs
 * Requer: supabase db reset --local ja aplicado + Docker rodando.
 */
import { createClient } from "@supabase/supabase-js";

const URL = "http://127.0.0.1:55321";
const ANON =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6ImFub24iLCJleHAiOjE5ODM4MTI5OTZ9.CRXP1A7WOeoJeXxjNni43kdQwgnWNReilDMblYTn_I0";
const SERVICE =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImV4cCI6MTk4MzgxMjk5Nn0.EGIM96RAZx35lJzdJsyH-qQwv8Hdp7fsn3W0YpN81IU";

const admin = createClient(URL, SERVICE, {
  auth: { autoRefreshToken: false, persistSession: false },
});

let passed = 0;
let failed = 0;

function assert(name, cond, detail = "") {
  if (cond) {
    passed++;
    console.log(`  OK  ${name}`);
  } else {
    failed++;
    console.error(`  FAIL ${name}${detail ? ` — ${detail}` : ""}`);
  }
}

function expectErr(err, code) {
  return err && (err.code === code || String(err.message).includes(code));
}

async function signUp(email, password) {
  const { data, error } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
  });
  if (error) throw error;
  return data.user;
}

async function clientFor(email, password) {
  const c = createClient(URL, ANON, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
  const { error } = await c.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return c;
}

async function main() {
  const ts = Date.now();
  const ownerEmail = `owner-${ts}@test.local`;
  const sellerEmail = `seller-${ts}@test.local`;
  const pass = "TestPass123!";

  console.log("=== cancel_sale — testes locais ===\n");

  const ownerUser = await signUp(ownerEmail, pass);
  const sellerUser = await signUp(sellerEmail, pass);
  const owner = await clientFor(ownerEmail, pass);
  const seller = await clientFor(sellerEmail, pass);

  const { data: co, error: coErr } = await owner.rpc("create_company_with_owner", {
    p_company_name: `Empresa Teste ${ts}`,
  });
  if (coErr) throw coErr;
  const companyId = co.company_id;

  const { error: addErr } = await admin.rpc("add_company_seller", {
    p_company_id: companyId,
    p_requester: ownerUser.id,
    p_user_id: sellerUser.id,
  });
  if (addErr) throw addErr;

  const { data: inv, error: invErr } = await owner
    .from("inventory_items")
    .insert({
      company_id: companyId,
      owner_id: ownerUser.id,
      categoria: "ferragem",
      nome: "Parafuso teste cancel",
      unidade: "un",
      quantidade: 10,
      preco_venda: 2,
      ativo: true,
    })
    .select("id, quantidade")
    .single();
  if (invErr) throw invErr;

  const saldoInicial = Number(inv.quantidade);
  assert("saldo inicial = 10", saldoInicial === 10);

  const items = [
    {
      inventory_item_id: inv.id,
      descricao: "Parafuso teste cancel",
      unidade: "un",
      largura: 0,
      altura: 0,
      quantidade: 3,
      preco_unit: 2,
      desconto: 0,
    },
  ];

  const { data: saleId, error: saleErr } = await owner.rpc("create_sale_with_items", {
    p_company_id: companyId,
    p_items: items,
    p_forma_pagamento: "dinheiro",
  });
  if (saleErr) throw saleErr;

  const { data: afterSale } = await owner
    .from("inventory_items")
    .select("quantidade")
    .eq("id", inv.id)
    .single();
  assert("baixa de 3 un apos venda", Number(afterSale.quantidade) === saldoInicial - 3);

  const { data: cancelledId, error: cancelErr } = await owner.rpc("cancel_sale", {
    p_sale_id: saleId,
    p_motivo: "Teste de estorno automatico",
  });
  assert("cancel_sale retorna sale_id", !cancelErr && cancelledId === saleId, cancelErr?.message);

  const { data: afterCancel } = await owner
    .from("inventory_items")
    .select("quantidade")
    .eq("id", inv.id)
    .single();
  assert(
    "estoque volta ao saldo original apos cancelamento",
    Number(afterCancel.quantidade) === saldoInicial,
    `got ${afterCancel?.quantidade}, expected ${saldoInicial}`,
  );

  const { data: saleRow } = await owner
    .from("sales")
    .select("status, cancelada_por, motivo_cancelamento")
    .eq("id", saleId)
    .single();
  assert("status = cancelada", saleRow?.status === "cancelada");
  assert("cancelada_por = owner", saleRow?.cancelada_por === ownerUser.id);
  assert("motivo gravado", saleRow?.motivo_cancelamento === "Teste de estorno automatico");

  const { error: cancel2Err } = await owner.rpc("cancel_sale", {
    p_sale_id: saleId,
    p_motivo: "Segunda tentativa",
  });
  assert(
    "segundo cancelamento rejeitado (22023)",
    cancel2Err && /cancelada|22023/i.test(cancel2Err.message),
    cancel2Err?.message,
  );

  // Venda 2 — item excluido do catalogo depois
  const { data: inv2, error: inv2Err } = await owner
    .from("inventory_items")
    .insert({
      company_id: companyId,
      owner_id: ownerUser.id,
      categoria: "ferragem",
      nome: "Item orfao teste",
      unidade: "un",
      quantidade: 5,
      preco_venda: 1,
      ativo: true,
    })
    .select("id")
    .single();
  if (inv2Err) throw inv2Err;

  const { data: sale2Id, error: sale2Err } = await owner.rpc("create_sale_with_items", {
    p_company_id: companyId,
    p_items: [
      {
        inventory_item_id: inv2.id,
        descricao: "Item orfao teste",
        unidade: "un",
        largura: 0,
        altura: 0,
        quantidade: 2,
        preco_unit: 1,
        desconto: 0,
      },
    ],
    p_forma_pagamento: "pix",
  });
  if (sale2Err) throw sale2Err;

  const { error: delErr } = await owner.from("inventory_items").delete().eq("id", inv2.id);
  assert("item excluido do catalogo", !delErr, delErr?.message);

  const { data: orphanItem } = await owner
    .from("sale_items")
    .select("inventory_item_id, quantidade_baixa")
    .eq("sale_id", sale2Id)
    .single();
  assert("inventory_item_id virou NULL apos delete", orphanItem?.inventory_item_id === null);
  assert("quantidade_baixa > 0 no item orfao", Number(orphanItem?.quantidade_baixa) > 0);

  const { error: cancelOrphanErr } = await owner.rpc("cancel_sale", {
    p_sale_id: sale2Id,
    p_motivo: "Tentativa com item orfao",
  });
  assert(
    "cancelamento rejeitado quando item perdeu vinculo",
    cancelOrphanErr && /vinculo|estoque|23503/i.test(cancelOrphanErr.message),
    cancelOrphanErr?.message,
  );

  const { data: sale2Still } = await owner.from("sales").select("status").eq("id", sale2Id).single();
  assert("venda orfa continua finalizada (nao cancelou)", sale2Still?.status === "finalizada");

  // Venda 3 — vendedor cria, vendedor nao cancela
  const { data: inv3, error: inv3Err } = await owner
    .from("inventory_items")
    .insert({
      company_id: companyId,
      owner_id: ownerUser.id,
      categoria: "ferragem",
      nome: "Item perm teste",
      unidade: "un",
      quantidade: 8,
      preco_venda: 3,
      ativo: true,
    })
    .select("id")
    .single();
  if (inv3Err) throw inv3Err;

  const { data: sale3Id, error: sale3Err } = await seller.rpc("create_sale_with_items", {
    p_company_id: companyId,
    p_items: [
      {
        inventory_item_id: inv3.id,
        descricao: "Item perm teste",
        unidade: "un",
        largura: 0,
        altura: 0,
        quantidade: 1,
        preco_unit: 3,
        desconto: 0,
      },
    ],
    p_forma_pagamento: "dinheiro",
  });
  assert("vendedor consegue criar venda", !sale3Err && !!sale3Id, sale3Err?.message);

  const { error: sellerCancelErr } = await seller.rpc("cancel_sale", {
    p_sale_id: sale3Id,
    p_motivo: "Vendedor tentando cancelar",
  });
  assert(
    "vendedor NAO cancela (42501)",
    sellerCancelErr && /permissao|42501/i.test(sellerCancelErr.message),
    sellerCancelErr?.message,
  );

  const { data: sale3Still } = await seller.from("sales").select("status").eq("id", sale3Id).single();
  assert("venda do vendedor continua finalizada", sale3Still?.status === "finalizada");

  console.log(`\n=== ${passed} passaram · ${failed} falharam ===`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((e) => {
  console.error("ERRO FATAL:", e);
  process.exit(1);
});
