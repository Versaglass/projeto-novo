-- Pos-push: contagem charges/expenses (somente agregados)
select
  (select count(*)::text from public.charges) as charges_total,
  (select count(*)::text from public.expenses) as expenses_total,
  exists (select 1 from pg_tables where schemaname = 'public' and tablename = 'expenses') as expenses_table_exists;
