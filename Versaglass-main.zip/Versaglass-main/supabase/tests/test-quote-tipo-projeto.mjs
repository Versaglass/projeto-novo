/**
 * Testes locais da migration quote_items.tipo_projeto (Revisao 144).
 * Uso: node supabase/tests/test-quote-tipo-projeto.mjs
 * Requer: supabase db reset --local ja aplicado + Docker rodando.
 */
import { execSync } from "node:child_process";
import { writeFileSync, unlinkSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { createClient } from "@supabase/supabase-js";

const URL = "http://127.0.0.1:55321";
const ANON =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6ImFub24iLCJleHAiOjE5ODM4MTI5OTZ9.CRXP1A7WOeoJeXxjNni43kdQwgnWNReilDMblYTn_I0";
const SERVICE =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImV4cCI6MTk4MzgxMjk5Nn0.EGIM96RAZx35lJzdJsyH-qQwv8Hdp7fsn3W0YpN81IU";

const admin = createClient(URL, SERVICE, {
  auth: { autoRefreshToken: false, persistSession: false },
});

let passed = 0;
let failed = 0;

function assert(name, cond, detail = "") {
  if (cond) {
    passed++;
    console.log(`  OK  ${name}`);
  } else {
    failed++;
    console.error(`  FAIL ${name}${detail ? ` — ${detail}` : ""}`);
  }
}

async function signUp(email, password) {
  const { data, error } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
  });
  if (error) throw error;
  return data.user;
}

async function clientFor(email, password) {
  const c = createClient(URL, ANON, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
  const { error } = await c.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return c;
}

const BACKFILL_SQL = `
update public.quote_items qi
set tipo_projeto = map.tipo::public.quote_item_tipo_projeto
from (
  values
    ('janela', 'janela'),
    ('porta', 'porta'),
    ('fixo', 'fixo'),
    ('box', 'box'),
    ('espelho', 'espelho'),
    ('sacadas', 'sacadas'),
    ('articulados', 'articulados'),
    ('muro', 'muro'),
    ('vitrine', 'vitrine'),
    ('fechamento de pia', 'fechamento_pia'),
    ('bascula/maxi-ar/pivotante', 'bascula_maxiar_pivotante'),
    ('guarda-corpo', 'guarda_corpo'),
    ('reposição', 'reposicao'),
    ('reposicao', 'reposicao')
) as map(label, tipo)
where lower(trim(qi.descricao)) = map.label;
`.trim();

function runLocalSql(sql) {
  const file = join(tmpdir(), `quote-tipo-backfill-${Date.now()}.sql`);
  writeFileSync(file, sql, "utf8");
  try {
    execSync(`supabase db query --local -f "${file}"`, {
      stdio: "pipe",
      cwd: process.cwd(),
      shell: true,
    });
  } finally {
    unlinkSync(file);
  }
}

async function main() {
  const ts = Date.now();
  const email = `tipo-proj-${ts}@test.local`;
  const pass = "TestPass123!";

  console.log("=== quote_items.tipo_projeto — testes locais ===\n");

  const user = await signUp(email, pass);
  const client = await clientFor(email, pass);

  const { data: co, error: coErr } = await client.rpc("create_company_with_owner", {
    p_company_name: `Empresa Tipo ${ts}`,
  });
  if (coErr) throw coErr;
  const companyId = co.company_id;

  const { data: cust, error: custErr } = await client
    .from("customers")
    .insert({
      company_id: companyId,
      owner_id: user.id,
      nome: "Cliente teste tipo",
    })
    .select("id")
    .single();
  if (custErr) throw custErr;

  const { data: qidComTipo, error: saveComErr } = await client.rpc("save_quote_with_items", {
    p_company_id: companyId,
    p_customer_id: cust.id,
    p_items: [
      {
        descricao: "Porta suite 302",
        tipo_projeto: "porta",
        largura: 0.9,
        altura: 2.1,
        quantidade: 1,
        preco_unit: 350,
      },
    ],
  });
  if (saveComErr) throw saveComErr;

  const { data: itemComTipo, error: selComErr } = await client
    .from("quote_items")
    .select("tipo_projeto, descricao, subtotal")
    .eq("quote_id", qidComTipo)
    .single();
  if (selComErr) throw selComErr;

  assert("item novo grava tipo_projeto = porta", itemComTipo.tipo_projeto === "porta");
  assert("subtotal dimensionado intacto", Number(itemComTipo.subtotal) === 661.5);

  const { data: qidSemTipo, error: saveSemErr } = await client.rpc("save_quote_with_items", {
    p_company_id: companyId,
    p_customer_id: cust.id,
    p_items: [
      {
        descricao: "Item legado sem tipo",
        largura: 1,
        altura: 1,
        quantidade: 2,
        preco_unit: 100,
      },
    ],
  });
  if (saveSemErr) throw saveSemErr;

  const { data: itemSemTipo, error: selSemErr } = await client
    .from("quote_items")
    .select("tipo_projeto, subtotal")
    .eq("quote_id", qidSemTipo)
    .single();
  if (selSemErr) throw selSemErr;

  assert("item sem tipo_projeto grava NULL", itemSemTipo.tipo_projeto === null);
  assert("subtotal legado intacto", Number(itemSemTipo.subtotal) === 200);

  const { error: badTipoErr } = await client.rpc("save_quote_with_items", {
    p_company_id: companyId,
    p_customer_id: cust.id,
    p_items: [
      {
        descricao: "X",
        tipo_projeto: "nao_existe",
        largura: 1,
        altura: 1,
        quantidade: 1,
        preco_unit: 10,
      },
    ],
  });
  assert(
    "tipo_projeto invalido rejeitado",
    badTipoErr && String(badTipoErr.message).includes("tipo_projeto"),
  );

  const { data: quoteLeg, error: qLegErr } = await admin
    .from("quotes")
    .insert({
      owner_id: user.id,
      company_id: companyId,
      customer_id: cust.id,
      status: "rascunho",
      total: 0,
    })
    .select("id")
    .single();
  if (qLegErr) throw qLegErr;

  const { error: insLegErr } = await admin.from("quote_items").insert([
    {
      quote_id: quoteLeg.id,
      company_id: companyId,
      descricao: "Porta",
      largura: 1,
      altura: 1,
      quantidade: 1,
      m2: 1,
      preco_unit: 10,
      subtotal: 10,
      ordem: 0,
    },
    {
      quote_id: quoteLeg.id,
      company_id: companyId,
      descricao: "Janela",
      largura: 1,
      altura: 1,
      quantidade: 1,
      m2: 1,
      preco_unit: 10,
      subtotal: 10,
      ordem: 1,
    },
    {
      quote_id: quoteLeg.id,
      company_id: companyId,
      descricao: "Porta de vidro 8mm",
      largura: 1,
      altura: 1,
      quantidade: 1,
      m2: 1,
      preco_unit: 10,
      subtotal: 10,
      ordem: 2,
    },
  ]);
  if (insLegErr) throw insLegErr;

  runLocalSql(BACKFILL_SQL);

  const { data: afterBf, error: bfSelErr } = await admin
    .from("quote_items")
    .select("descricao, tipo_projeto")
    .eq("quote_id", quoteLeg.id)
    .order("ordem");
  if (bfSelErr) throw bfSelErr;

  assert(
    "backfill: Porta -> porta",
    afterBf.find((r) => r.descricao === "Porta")?.tipo_projeto === "porta",
  );
  assert(
    "backfill: Janela -> janela",
    afterBf.find((r) => r.descricao === "Janela")?.tipo_projeto === "janela",
  );
  assert(
    "backfill: texto misto permanece NULL",
    afterBf.find((r) => r.descricao === "Porta de vidro 8mm")?.tipo_projeto === null,
  );

  console.log(`\n=== ${passed} passed, ${failed} failed ===`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
