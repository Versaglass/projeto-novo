-- Revisão 223 — auditoria pré-migration (somente leitura)
-- Verifica colisões antes de criar suppliers + inventory_items.supplier_id

with audit as (
  select
    1 as n,
    'A1 · colisão: tabela suppliers já existe?'::text as verificacao,
    coalesce(
      (select string_agg(tablename, ' | ' order by tablename)
         from pg_tables
        where schemaname = 'public'
          and tablename in ('suppliers', 'fornecedores')),
      '(nenhuma)'
    )::text as resultado,
    '(nenhuma)'::text as esperado

  union all
  select
    2,
    'A2 · colisão: enums supplier_area / supplier_status já existem?',
    coalesce(
      (select string_agg(t.typname, ' | ' order by t.typname)
         from pg_type t
         join pg_namespace n on n.oid = t.typnamespace
        where n.nspname = 'public'
          and t.typname in ('supplier_area', 'supplier_status')),
      '(nenhuma)'
    ),
    '(nenhuma)'

  union all
  select
    3,
    'A3 · colisão: inventory_items.supplier_id já existe?',
    coalesce(
      (select string_agg(column_name, ' | ' order by column_name)
         from information_schema.columns
        where table_schema = 'public'
          and table_name = 'inventory_items'
          and column_name = 'supplier_id'),
      '(nenhuma)'
    ),
    '(nenhuma)'

  union all
  select
    4,
    'A4 · baseline: colunas atuais de inventory_items (fornecedor + tenant)',
    coalesce(
      (select string_agg(column_name, ' | ' order by ordinal_position)
         from information_schema.columns
        where table_schema = 'public'
          and table_name = 'inventory_items'
          and column_name in (
            'id', 'owner_id', 'company_id', 'fornecedor',
            'nome', 'categoria', 'ativo', 'created_at', 'updated_at'
          )),
      '(nenhuma)'
    ),
    'id | owner_id | company_id | categoria | nome | fornecedor | ativo | created_at | updated_at'

  union all
  select
    5,
    'A5 · baseline: inventory_items.company_id é NOT NULL?',
    coalesce(
      (select case when is_nullable = 'NO' then 'NOT NULL' else 'NULLABLE' end
         from information_schema.columns
        where table_schema = 'public'
          and table_name = 'inventory_items'
          and column_name = 'company_id'),
      '(coluna ausente)'
    ),
    'NOT NULL'

  union all
  select
    6,
    'A6 · colisão: função suppliers_lock_tenant já existe?',
    coalesce(
      (select string_agg(p.proname, ' | ' order by p.proname)
         from pg_proc p
         join pg_namespace n on n.oid = p.pronamespace
        where n.nspname = 'public'
          and p.proname = 'suppliers_lock_tenant'),
      '(nenhuma)'
    ),
    '(nenhuma)'

  union all
  select
    7,
    'A7 · colisão: policies suppliers_* já existem?',
    coalesce(
      (select string_agg(policyname, ' | ' order by policyname)
         from pg_policies
        where schemaname = 'public'
          and tablename = 'suppliers'),
      '(nenhuma)'
    ),
    '(nenhuma)'
)
select n, verificacao, resultado, esperado,
       case when resultado = esperado then 'OK' else 'VERIFICAR' end as status
  from audit
 order by n;
