/**
 * Verifica get_finance_summary com periodo vazio (mes sem dados).
 * Uso: node supabase/tests/verify-finance-empty-period.mjs
 */
import { createClient } from "@supabase/supabase-js";

const URL = "http://127.0.0.1:55321";
const ANON =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6ImFub24iLCJleHAiOjE5ODM4MTI5OTZ9.CRXP1A7WOeoJeXxjNni43kdQwgnWNReilDMblYTn_I0";
const SERVICE =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImV4cCI6MTk4MzgxMjk5Nn0.EGIM96RAZx35lJzdJsyH-qQwv8Hdp7fsn3W0YpN81IU";

const admin = createClient(URL, SERVICE, {
  auth: { autoRefreshToken: false, persistSession: false },
});

function brl(n) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(n || 0);
}

async function main() {
  const ts = Date.now();
  const email = `fin-empty-${ts}@test.local`;
  const pass = "TestPass123!";

  const { data: userData, error: userErr } = await admin.auth.admin.createUser({
    email,
    password: pass,
    email_confirm: true,
  });
  if (userErr) throw userErr;

  const client = createClient(URL, ANON, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
  await client.auth.signInWithPassword({ email, password: pass });

  const { data: co, error: coErr } = await client.rpc("create_company_with_owner", {
    p_company_name: `Empresa vazia ${ts}`,
  });
  if (coErr) throw coErr;
  const companyId = co.company_id;

  // Janeiro 2020 — empresa nova, zero movimento
  const start = "2020-01-01T03:00:00.000Z";
  const end = "2020-02-01T03:00:00.000Z";

  const { data: summary, error: sumErr } = await client.rpc("get_finance_summary", {
    p_company_id: companyId,
    p_start: start,
    p_end: end,
  });
  if (sumErr) throw sumErr;

  const fields = {
    faturamento: summary.faturamento,
    caixa_vendas: summary.caixa_vendas,
    caixa_cobrancas: summary.caixa_cobrancas,
    despesas_total: summary.despesas_total,
    lucro_estimado: summary.lucro_estimado,
  };

  console.log("RPC bruto:", JSON.stringify(fields, null, 2));
  console.log("Como a UI renderizaria (brl()):");
  for (const [k, v] of Object.entries(fields)) {
    console.log(`  ${k}: ${brl(Number(v))}`);
  }

  const allZero = Object.values(fields).every((v) => v === "0.00" || v === 0 || v === "0");
  if (!allZero) {
    console.error("FAIL: esperava todos zero");
    process.exit(1);
  }
  console.log("OK: periodo vazio retorna zeros (UI mostrara R$ 0,00)");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
