-- Revisao 160 — Financeiro Nivel 2.1 (Rev. 159)
-- Somente leitura: pg_catalog + count(*) agregados
with audit as (
  -- ========== A — COLISAO DE NOMES ==========
  select
    1 as n,
    'A1 · colisao: tipo expense_kind ja existe?'::text as verificacao,
    coalesce(
      (select string_agg(t.typname, ' | ' order by t.typname)
         from pg_type t
         join pg_namespace n on n.oid = t.typnamespace
        where n.nspname = 'public'
          and t.typname in ('expense_kind', 'expense_category')),
      '(nenhuma)'
    )::text as resultado,
    '(nenhuma)'::text as esperado

  union all
  select
    2,
    'A2 · colisao: coluna expenses.expense_kind ja existe?',
    coalesce(
      (select string_agg(column_name || ':' || data_type, ' | ')
         from information_schema.columns
        where table_schema = 'public'
          and table_name = 'expenses'
          and column_name = 'expense_kind'),
      '(nenhuma)'
    ),
    '(nenhuma)'

  union all
  select
    3,
    'A3 · colisao: RPC get_finance_cashflow ja existe?',
    coalesce(
      (select string_agg(p.proname, ' | ' order by p.proname)
         from pg_proc p
         join pg_namespace n on n.oid = p.pronamespace
        where n.nspname = 'public'
          and p.proname in ('get_finance_cashflow')),
      '(nenhuma)'
    ),
    '(nenhuma)'

  union all
  select
    4,
    'A4 · colisao: tabela owner_withdrawals / personal_expenses?',
    coalesce(
      (select string_agg(tablename, ' | ' order by tablename)
         from pg_tables
        where schemaname = 'public'
          and tablename in ('owner_withdrawals', 'personal_expenses', 'gastos_pessoais')),
      '(nenhuma)'
    ),
    '(nenhuma)'

  union all
  select
    5,
    'A5 · colisao: indice idx_expenses_kind?',
    coalesce(
      (select string_agg(indexname, ' | ' order by indexname)
         from pg_indexes
        where schemaname = 'public'
          and tablename = 'expenses'
          and indexname like '%kind%'),
      '(nenhuma)'
    ),
    '(nenhuma)'

  -- ========== B — SCHEMA ATUAL expenses ==========
  union all
  select
    6,
    'B1 · expenses: inventario de colunas (nome:tipo)',
    coalesce(
      (select string_agg(column_name || ':' || data_type, ' | ' order by ordinal_position)
         from information_schema.columns
        where table_schema = 'public'
          and table_name = 'expenses'),
      '(tabela ausente)'
    ),
    'amount:numeric | category:text | company_id:uuid | created_at:timestamp with time zone | description:text | expense_date:date | id:uuid | notes:text | owner_id:uuid | quote_id:uuid | updated_at:timestamp with time zone'

  union all
  select
    7,
    'B2 · expenses: contagem de colunas',
    (select count(*)::text
       from information_schema.columns
      where table_schema = 'public'
        and table_name = 'expenses'),
    '11'

  union all
  select
    8,
    'B3 · expenses: constraint category (CHECK)',
    coalesce(
      (select con.conname || ' -> ' || pg_get_constraintdef(con.oid)
         from pg_constraint con
         join pg_class rel on rel.oid = con.conrelid
         join pg_namespace nsp on nsp.oid = rel.relnamespace
        where nsp.nspname = 'public'
          and rel.relname = 'expenses'
          and con.contype = 'c'
          and pg_get_constraintdef(con.oid) ilike '%category%'
        limit 1),
      '(nenhuma)'
    ),
    'expenses_category_valid (9 categorias operacionais)'

  union all
  select
    9,
    'B4 · expenses: policies RLS (nome:cmd)',
    coalesce(
      (select string_agg(policyname || ':' || cmd, ' | ' order by policyname)
         from pg_policies
        where schemaname = 'public'
          and tablename = 'expenses'),
      '(nenhuma)'
    ),
    'expenses_delete_company:DELETE | expenses_insert_company:INSERT | expenses_select_company:SELECT | expenses_update_company:UPDATE'

  union all
  select
    10,
    'B5 · expenses: trigger lock_tenant',
    coalesce(
      (select tgname || ' -> ' || case tgenabled when 'O' then 'enabled' else tgenabled::text end
         from pg_trigger tg
         join pg_class c on c.oid = tg.tgrelid
         join pg_namespace n on n.oid = c.relnamespace
        where n.nspname = 'public'
          and c.relname = 'expenses'
          and not tg.tgisinternal
          and tgname ilike '%lock%'),
      '(nenhum)'
    ),
    'expenses_lock_tenant_biu -> enabled'

  -- ========== C — GARANTIAS Rev. 159 ==========
  union all
  select
    11,
    'C1 · public.expenses existe?',
    case when to_regclass('public.expenses') is not null then 'true' else 'false' end,
    'true'

  union all
  select
    12,
    'C2 · RPC get_finance_summary existe?',
    case when to_regprocedure('public.get_finance_summary(uuid,timestamptz,timestamptz)') is not null
         then 'true' else 'false' end,
    'true'

  union all
  select
    13,
    'C3 · helper is_company_owner_or_admin(uuid,uuid)?',
    case when to_regprocedure('public.is_company_owner_or_admin(uuid,uuid)') is not null
         then 'true' else 'false' end,
    'true'

  union all
  select
    14,
    'C4 · sales + charges + get_finance_summary (premissas caixa)',
    case
      when to_regclass('public.sales') is null then 'false — sales'
      when to_regclass('public.charges') is null then 'false — charges'
      when to_regprocedure('public.get_finance_summary(uuid,timestamptz,timestamptz)') is null
        then 'false — summary'
      else 'true'
    end,
    'true'

  union all
  select
    15,
    'C5 · charges.sale_id sem FK (anti-dupla-contagem)?',
    coalesce(
      (select string_agg(tc.constraint_name, ' | ')
         from information_schema.table_constraints tc
         join information_schema.key_column_usage kcu
           on kcu.constraint_name = tc.constraint_name
          and kcu.table_schema = tc.table_schema
        where tc.table_schema = 'public'
          and tc.table_name = 'charges'
          and tc.constraint_type = 'FOREIGN KEY'
          and kcu.column_name = 'sale_id'),
      '(nenhuma)'
    ),
    '(nenhuma) — P-12'

  -- ========== D — DADOS ==========
  union all
  select
    16,
    'D1 · total linhas public.expenses',
    (select count(*)::text from public.expenses),
    '0 (ideal pre-migration; anotar se > 0)'

  union all
  select
    17,
    'D2 · expenses com category fora do CHECK operacional atual?',
    (select count(*)::text
       from public.expenses
      where category not in (
        'fornecedor', 'frete', 'combustivel', 'salario', 'imposto',
        'aluguel', 'servico', 'compra', 'outros'
      )),
    '0'
)
select n, verificacao, resultado, esperado
  from audit
 order by n;
