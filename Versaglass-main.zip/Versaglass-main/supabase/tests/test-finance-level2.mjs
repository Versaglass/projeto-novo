/**
 * Testes locais da migration Financeiro Nivel 2 (Revisao 156).
 * Uso: node supabase/tests/test-finance-level2.mjs
 * Requer: supabase db reset --local ja aplicado + Docker rodando.
 */
import { execSync } from "node:child_process";
import { writeFileSync, unlinkSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { createClient } from "@supabase/supabase-js";

const URL = "http://127.0.0.1:55321";
const ANON =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6ImFub24iLCJleHAiOjE5ODM4MTI5OTZ9.CRXP1A7WOeoJeXxjNni43kdQwgnWNReilDMblYTn_I0";
const SERVICE =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImV4cCI6MTk4MzgxMjk5Nn0.EGIM96RAZx35lJzdJsyH-qQwv8Hdp7fsn3W0YpN81IU";

const admin = createClient(URL, SERVICE, {
  auth: { autoRefreshToken: false, persistSession: false },
});

let passed = 0;
let failed = 0;

function assert(name, cond, detail = "") {
  if (cond) {
    passed++;
    console.log(`  OK  ${name}`);
  } else {
    failed++;
    console.error(`  FAIL ${name}${detail ? ` — ${detail}` : ""}`);
  }
}

function expectErr(err) {
  return !!err;
}

async function signUp(email, password) {
  const { data, error } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
  });
  if (error) throw error;
  return data.user;
}

async function clientFor(email, password) {
  const c = createClient(URL, ANON, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
  const { error } = await c.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return c;
}

function runLocalSql(sql) {
  const file = join(tmpdir(), `finance-test-${Date.now()}.sql`);
  writeFileSync(file, sql, "utf8");
  try {
    execSync(`supabase db query --local -f "${file}"`, {
      stdio: "pipe",
      cwd: process.cwd(),
      shell: true,
    });
  } finally {
    unlinkSync(file);
  }
}

function monthBounds() {
  const now = new Date();
  const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1, 0, 0, 0));
  const end = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1, 0, 0, 0));
  return { start: start.toISOString(), end: end.toISOString() };
}

async function main() {
  const ts = Date.now();
  const emailA = `fin-a-${ts}@test.local`;
  const emailB = `fin-b-${ts}@test.local`;
  const pass = "TestPass123!";
  const { start, end } = monthBounds();

  console.log("=== Financeiro Nivel 2 — testes locais ===\n");

  const userA = await signUp(emailA, pass);
  const userB = await signUp(emailB, pass);
  const clientA = await clientFor(emailA, pass);
  const clientB = await clientFor(emailB, pass);

  const { data: coA, error: coAErr } = await clientA.rpc("create_company_with_owner", {
    p_company_name: `Empresa Fin A ${ts}`,
  });
  if (coAErr) throw coAErr;
  const companyA = coA.company_id;

  const { data: coB, error: coBErr } = await clientB.rpc("create_company_with_owner", {
    p_company_name: `Empresa Fin B ${ts}`,
  });
  if (coBErr) throw coBErr;

  const { data: cust, error: custErr } = await clientA
    .from("customers")
    .insert({
      company_id: companyA,
      owner_id: userA.id,
      nome: "Cliente financeiro teste",
    })
    .select("id")
    .single();
  if (custErr) throw custErr;

  const { data: quoteId, error: quoteErr } = await clientA.rpc("save_quote_with_items", {
    p_company_id: companyA,
    p_customer_id: cust.id,
    p_items: [
      {
        descricao: "Projeto teste financeiro",
        unidade: "un",
        largura: 0,
        altura: 0,
        quantidade: 1,
        preco_unit: 5000,
        desconto: 0,
      },
    ],
    p_status: "aprovado",
  });
  if (quoteErr) throw quoteErr;

  const { data: saleId, error: saleErr } = await clientA.rpc("create_sale_with_items", {
    p_company_id: companyA,
    p_items: [
      {
        descricao: "Venda balcao teste",
        unidade: "un",
        largura: 0,
        altura: 0,
        quantidade: 1,
        preco_unit: 890,
        desconto: 0,
      },
    ],
    p_forma_pagamento: "dinheiro",
  });
  if (saleErr) throw saleErr;

  const { data: chargeId, error: chErr } = await clientA.rpc("create_manual_charge", {
    p_company_id: companyA,
    p_customer_id: cust.id,
    p_quote_id: quoteId,
    p_amount: 500,
    p_description: "Entrada orcamento manual",
  });
  if (chErr) throw chErr;

  const paidAt = new Date().toISOString();
  const { error: payErr } = await clientA.rpc("mark_charge_paid", {
    p_charge_id: chargeId,
    p_paid_at: paidAt,
  });
  if (payErr) throw payErr;

  runLocalSql(`
    insert into public.charges (
      company_id, owner_id, sale_id, payment_method, status,
      description, amount, platform_fee, paid_at, provider_charge_id
    ) values (
      '${companyA}', '${userA.id}', '${saleId}', 'manual', 'paid',
      'Cobranca ligada a venda (nao deve duplicar caixa)', 200, 0, now(), null
    );
  `);

  const expenseDate = new Date().toISOString().slice(0, 10);
  const { data: expenseRow, error: expErr } = await clientA
    .from("expenses")
    .insert({
      company_id: companyA,
      owner_id: userA.id,
      category: "fornecedor",
      description: "Material teste",
      amount: 320,
      expense_date: expenseDate,
    })
    .select("id")
    .single();
  if (expErr) throw expErr;
  assert("despesa manual persiste", !!expenseRow?.id);

  const { data: summary, error: sumErr } = await clientA.rpc("get_finance_summary", {
    p_company_id: companyA,
    p_start: start,
    p_end: end,
  });
  if (sumErr) throw sumErr;

  assert("faturamento = 5000", summary.faturamento === "5000.00", summary.faturamento);
  assert("caixa_vendas = 890", summary.caixa_vendas === "890.00", summary.caixa_vendas);
  assert(
    "caixa_cobrancas = 500 (sem sale_id)",
    summary.caixa_cobrancas === "500.00",
    summary.caixa_cobrancas
  );
  assert("caixa_total = 1390", summary.caixa_total === "1390.00", summary.caixa_total);
  assert("despesas_total = 320", summary.despesas_total === "320.00", summary.despesas_total);
  assert("lucro_estimado = 1070", summary.lucro_estimado === "1070.00", summary.lucro_estimado);
  assert(
    "faturamento != caixa_total (G4)",
    summary.faturamento !== summary.caixa_total,
    `${summary.faturamento} vs ${summary.caixa_total}`
  );

  const { error: directInsErr } = await clientA.from("charges").insert({
    company_id: companyA,
    owner_id: userA.id,
    payment_method: "manual",
    status: "pending",
    description: "insert direto",
    amount: 100,
  });
  assert("INSERT direto em charges bloqueado", expectErr(directInsErr));

  const { data: directUpd, error: directUpdErr } = await clientA
    .from("charges")
    .update({ status: "pending", paid_at: null })
    .eq("id", chargeId)
    .select("id");
  assert(
    "UPDATE direto em charges bloqueado",
    expectErr(directUpdErr) || (directUpd?.length ?? 0) === 0,
    directUpdErr?.message ?? `rows=${directUpd?.length ?? 0}`
  );

  const { data: chargeAfter, error: chReadErr } = await clientA
    .from("charges")
    .select("status")
    .eq("id", chargeId)
    .single();
  assert(
    "cobranca permanece paid apos UPDATE direto",
    !chReadErr && chargeAfter?.status === "paid",
    chargeAfter?.status
  );

  const { data: expB, error: expBListErr } = await clientB
    .from("expenses")
    .select("id")
    .eq("company_id", companyA);
  assert("RLS: B nao lista despesas de A", !expBListErr && (expB?.length ?? 0) === 0);

  const { data: chB, error: chBListErr } = await clientB
    .from("charges")
    .select("id")
    .eq("company_id", companyA);
  assert("RLS: B nao lista cobrancas de A", !chBListErr && (chB?.length ?? 0) === 0);

  const { error: expBInsErr } = await clientB.from("expenses").insert({
    company_id: companyA,
    owner_id: userB.id,
    category: "outros",
    description: "Tentativa cross-tenant",
    amount: 50,
    expense_date: expenseDate,
  });
  assert("RLS: B nao insere despesa em A", expectErr(expBInsErr), expBInsErr?.message);

  const { error: sumBErr } = await clientB.rpc("get_finance_summary", {
    p_company_id: companyA,
    p_start: start,
    p_end: end,
  });
  assert("RLS: B nao le resumo de A", expectErr(sumBErr), sumBErr?.message);

  console.log(`\n=== ${passed} OK, ${failed} FAIL ===`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
