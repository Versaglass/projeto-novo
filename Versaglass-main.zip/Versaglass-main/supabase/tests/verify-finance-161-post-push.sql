-- Pos-push Rev. 161 — expenses + RPCs financeiros (somente agregados)
select
  (select count(*)::text from public.expenses) as expenses_total,
  exists (
    select 1
      from pg_proc p
      join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public'
       and p.proname = 'get_finance_summary'
  ) as get_finance_summary_exists,
  exists (
    select 1
      from pg_proc p
      join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public'
       and p.proname = 'get_finance_cashflow'
  ) as get_finance_cashflow_exists,
  exists (
    select 1
      from pg_type t
      join pg_namespace n on n.oid = t.typnamespace
     where n.nspname = 'public'
       and t.typname = 'expense_kind'
  ) as expense_kind_enum_exists;
