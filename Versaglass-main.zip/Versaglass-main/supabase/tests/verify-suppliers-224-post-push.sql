-- Revisão 224 — verificação pós-push (somente leitura)

with audit as (
  select 1 as n, 'B1 · tabela suppliers existe?'::text as verificacao,
    coalesce((select tablename from pg_tables where schemaname='public' and tablename='suppliers'), '(nenhuma)') as resultado,
    'suppliers'::text as esperado
  union all
  select 2, 'B2 · enums supplier_area / supplier_status',
    coalesce((select string_agg(t.typname, ' | ' order by t.typname) from pg_type t join pg_namespace n on n.oid=t.typnamespace
      where n.nspname='public' and t.typname in ('supplier_area','supplier_status')), '(nenhuma)'),
    'supplier_area | supplier_status'
  union all
  select 3, 'B3 · inventory_items.supplier_id',
    coalesce((select column_name from information_schema.columns where table_schema='public' and table_name='inventory_items' and column_name='supplier_id'), '(nenhuma)'),
    'supplier_id'
  union all
  select 4, 'B4 · policies suppliers (4)',
    coalesce((select count(*)::text from pg_policies where schemaname='public' and tablename='suppliers'), '0'),
    '4'
  union all
  select 5, 'B5 · trigger suppliers_lock_tenant_biu',
    coalesce((select tgname from pg_trigger t join pg_class c on c.oid=t.tgrelid where c.relname='suppliers' and tgname='suppliers_lock_tenant_biu' and not t.tgisinternal), '(nenhuma)'),
    'suppliers_lock_tenant_biu'
  union all
  select 6, 'B6 · índices parciais únicos',
    coalesce((select string_agg(indexname, ' | ' order by indexname) from pg_indexes where schemaname='public' and tablename='suppliers'
      and indexname in ('suppliers_company_codigo_uq','suppliers_company_cnpj_uq')), '(nenhuma)'),
    'suppliers_company_cnpj_uq | suppliers_company_codigo_uq'
  union all
  select 7, 'B7 · FK inventory_items → suppliers ON DELETE SET NULL',
    coalesce((select confdeltype::text from pg_constraint where conname='inventory_items_supplier_id_fkey'), '(nenhuma)'),
    'n'
)
select n, verificacao, resultado, esperado,
       case when resultado = esperado then 'OK' else 'VERIFICAR' end as status
  from audit order by n;
