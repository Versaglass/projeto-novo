// Helpers Asaas — somente Edge Functions (server-side).
// Nunca importar este módulo no frontend.

export type AsaasCustomer = {
  id: string;
  name?: string;
  cpfCnpj?: string;
  email?: string;
  externalReference?: string;
};

export type AsaasCheckout = {
  id: string;
  status?: string;
  link?: string | null;
  externalReference?: string | null;
  customer?: string | null;
};

export type AsaasListResponse<T> = {
  data?: T[];
  totalCount?: number;
};

export class AsaasHttpError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.name = "AsaasHttpError";
    this.status = status;
  }
}

export function getAsaasConfig() {
  const apiKey = Deno.env.get("ASAAS_API_KEY")?.trim() ?? "";
  const baseUrl = (Deno.env.get("ASAAS_API_BASE_URL")?.trim() ?? "").replace(/\/$/, "");
  if (!apiKey || !baseUrl) {
    return null;
  }
  return { apiKey, baseUrl };
}

export function checkoutPublicUrl(
  baseUrl: string,
  checkoutId: string,
  linkFromApi?: string | null,
) {
  if (linkFromApi && /^https?:\/\//i.test(linkFromApi)) return linkFromApi;
  const sandbox = /sandbox/i.test(baseUrl);
  if (sandbox) {
    return `https://sandbox.asaas.com/checkoutSession/show/${checkoutId}`;
  }
  return `https://asaas.com/checkoutSession/show?id=${checkoutId}`;
}

export async function asaasFetch<T>(
  path: string,
  init: { method?: string; body?: unknown } = {},
): Promise<T> {
  const cfg = getAsaasConfig();
  if (!cfg) throw new AsaasHttpError(503, "Asaas não configurado.");

  const url = `${cfg.baseUrl}${path.startsWith("/") ? path : `/${path}`}`;
  const headers: Record<string, string> = {
    accept: "application/json",
    access_token: cfg.apiKey,
    "Content-Type": "application/json",
    "User-Agent": "VersaGlass-SaaS/1.0",
  };

  const res = await fetch(url, {
    method: init.method ?? (init.body ? "POST" : "GET"),
    headers,
    body: init.body === undefined ? undefined : JSON.stringify(init.body),
  });

  const text = await res.text();
  let json: unknown = null;
  if (text) {
    try {
      json = JSON.parse(text);
    } catch {
      json = null;
    }
  }

  if (!res.ok) {
    console.error("[asaas] HTTP", res.status, path);
    throw new AsaasHttpError(res.status, "Falha na API Asaas.");
  }

  return json as T;
}

export function onlyDigits(value: string | null | undefined): string {
  return (value ?? "").replace(/\D/g, "");
}

export function isValidEmail(value: string | null | undefined): boolean {
  if (!value) return false;
  const v = value.trim();
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) && v.length <= 160;
}

/** CNPJ empresa: 14 dígitos. Não aceita CPF do owner. */
export function isValidCnpjDigits(digits: string): boolean {
  return digits.length === 14;
}

export function todayDateString(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function timingSafeEqualString(a: string, b: string): boolean {
  const enc = new TextEncoder();
  const aa = enc.encode(a);
  const bb = enc.encode(b);
  if (aa.length !== bb.length) return false;
  let out = 0;
  for (let i = 0; i < aa.length; i++) out |= aa[i] ^ bb[i];
  return out === 0;
}
