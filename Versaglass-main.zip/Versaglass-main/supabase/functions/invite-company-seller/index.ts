// =====================================================================
// invite-company-seller — convite de VENDEDOR por owner/admin empresarial.
//
// POR QUE UMA EDGE FUNCTION
//   Convidar alguém exige a Auth Admin API, que só funciona com a secret key
//   (service_role). Essa chave IGNORA RLS: se chegasse ao navegador, qualquer
//   pessoa leria e escreveria qualquer linha de qualquer empresa. Ela existe
//   somente aqui dentro, lida de variável de ambiente do servidor, e nunca é
//   devolvida, logada nem embutida no bundle.
//
// AUTORIZAÇÃO — TRÊS CAMADAS INDEPENDENTES
//   1. O JWT do solicitante é validado pelo GoTrue (`getUser`), não decodificado
//      à mão. Sem Authorization válido, nada acontece.
//   2. A membership do solicitante é lida com o cliente do PRÓPRIO usuário, sob
//      RLS. `is_platform_admin` NÃO é consultado em lugar nenhum: admin de
//      plataforma sem membership é recusado como qualquer estranho.
//   3. `public.add_company_seller` revalida owner/admin ATIVO dentro do banco,
//      na mesma transação do INSERT. Um companyId forjado falha aqui mesmo que
//      a camada 2 fosse contornada.
//
// O PAPEL NUNCA VEM DO CLIENTE
//   O corpo aceita apenas companyId, name e email. Não há parâmetro de papel,
//   status, permissões ou user_id: `seller`/`active` são literais do servidor.
//   Qualquer campo extra no JSON é ignorado — inclusive "role".
//   O nome vai para user_metadata só como rótulo de perfil; NADA em
//   user_metadata é usado como autorização, aqui ou no banco.
// =====================================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.105.4";

const CORS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// Resposta mínima e genérica. O detalhe do erro fica no log do servidor, nunca
// na resposta: mensagens específicas viram oráculo de enumeração de contas.
function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);

  const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
  // A chave publicável é a usada para o cliente do SOLICITANTE: ele age com o
  // próprio JWT, sob RLS. A secret key jamais é usada para representá-lo.
  const PUBLISHABLE = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
  const SECRET = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? Deno.env.get("SUPABASE_SECRET_KEY");
  // Rota REAL da aplicação onde o convidado define a própria senha. Precisa
  // constar na allow-list de redirect do projeto (ver relatório).
  const REDIRECT_TO = Deno.env.get("INVITE_REDIRECT_URL");

  if (!SUPABASE_URL || !PUBLISHABLE || !SECRET) {
    console.error("[invite] ambiente incompleto"); // sem citar qual chave falta
    return json({ error: "Serviço indisponível." }, 500);
  }
  if (REDIRECT_TO && !/^https?:\/\//i.test(REDIRECT_TO)) {
    console.error("[invite] INVITE_REDIRECT_URL nao e uma URL absoluta");
    return json({ error: "Serviço indisponível." }, 500);
  }

  // ---- 1. JWT do solicitante -----------------------------------------
  const authHeader = req.headers.get("Authorization") ?? "";
  if (!authHeader.toLowerCase().startsWith("bearer ")) {
    return json({ error: "Autenticação obrigatória." }, 401);
  }

  const userClient = createClient(SUPABASE_URL, PUBLISHABLE, {
    global: { headers: { Authorization: authHeader } },
    auth: { autoRefreshToken: false, persistSession: false, detectSessionInUrl: false },
  });

  const { data: userData, error: userErr } = await userClient.auth.getUser();
  if (userErr || !userData?.user) {
    return json({ error: "Autenticação obrigatória." }, 401);
  }
  const requesterId = userData.user.id;

  // ---- 2. Entrada ------------------------------------------------------
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Requisição inválida." }, 400);
  }

  const companyId = typeof body.companyId === "string" ? body.companyId.trim() : "";
  const name = typeof body.name === "string" ? body.name.trim().replace(/\s+/g, " ") : "";
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";

  if (!UUID_RE.test(companyId)) return json({ error: "Empresa inválida." }, 400);
  if (name.length < 2 || name.length > 120) {
    return json({ error: "Informe o nome do vendedor (2 a 120 caracteres)." }, 400);
  }
  if (!EMAIL_RE.test(email) || email.length > 160) {
    return json({ error: "Informe um e-mail válido." }, 400);
  }

  // ---- 3. Autorização empresarial (RLS, sem is_platform_admin) ---------
  const { data: membership, error: memErr } = await userClient
    .from("company_members")
    .select("role, status")
    .eq("company_id", companyId)
    .eq("user_id", requesterId)
    .maybeSingle();

  if (memErr) {
    console.error("[invite] falha ao ler membership:", memErr.code ?? "sem código");
    return json({ error: "Não foi possível concluir o convite." }, 500);
  }
  // Mesma resposta para "não é membro" e "é membro sem permissão": não revela
  // a existência da empresa a quem não pertence a ela.
  if (
    !membership ||
    membership.status !== "active" ||
    (membership.role !== "owner" && membership.role !== "admin")
  ) {
    return json({ error: "Você não tem permissão para adicionar vendedores nesta empresa." }, 403);
  }

  // ---- 4. Cliente administrativo (secret key confinada a este escopo) --
  const adminClient = createClient(SUPABASE_URL, SECRET, {
    auth: { autoRefreshToken: false, persistSession: false, detectSessionInUrl: false },
  });

  // Papel e status são literais do servidor — declarados aqui só para leitura.
  const PAPEL_FIXO = "seller";

  // ---- 5. O e-mail já tem conta? ---------------------------------------
  // Resolvido por índice em auth.users (RPC restrita a service_role), nunca
  // paginando a lista completa de usuários.
  const { data: existingId, error: lookupErr } = await adminClient.rpc("auth_user_id_by_email", {
    p_email: email,
  });

  if (lookupErr) {
    console.error("[invite] falha ao resolver e-mail:", lookupErr.code ?? "sem código");
    return json({ error: "Não foi possível concluir o convite." }, 500);
  }

  // Conta já existe: órfão (0 memberships) linka direto; com empresa → pending
  // + e-mail Resend (Rev. 247/248). Nunca inviteUserByEmail neste ramo.
  if (existingId) {
    const existingUserId = existingId as string;

    const { count: membershipCount, error: countErr } = await adminClient
      .from("company_members")
      .select("id", { count: "exact", head: true })
      .eq("user_id", existingUserId);

    if (countErr) {
      console.error("[invite] falha ao contar memberships:", countErr.code ?? "sem código");
      return json({ error: "Não foi possível concluir o convite." }, 500);
    }

    // Órfão — mesmo comportamento histórico (linked).
    if (!membershipCount) {
      const { data: outcome, error: linkErr } = await adminClient.rpc("add_company_seller", {
        p_company_id: companyId,
        p_requester: requesterId,
        p_user_id: existingUserId,
      });

      if (linkErr) {
        console.error("[invite] falha ao vincular orfao:", linkErr.code ?? "sem código");
        return json({ error: "Não foi possível concluir o convite." }, 500);
      }
      return outcome === "already_member"
        ? json({ status: "already_member", role: PAPEL_FIXO })
        : json({ status: "linked", role: PAPEL_FIXO });
    }

    const { data: alreadyHere, error: hereErr } = await adminClient
      .from("company_members")
      .select("id")
      .eq("company_id", companyId)
      .eq("user_id", existingUserId)
      .maybeSingle();

    if (hereErr) {
      console.error("[invite] falha ao checar membership local:", hereErr.code ?? "sem código");
      return json({ error: "Não foi possível concluir o convite." }, 500);
    }
    if (alreadyHere) {
      return json({ status: "already_member", role: PAPEL_FIXO });
    }

    const { data: pendingRow, error: pendingErr } = await adminClient
      .from("company_invitations")
      .select("id")
      .eq("company_id", companyId)
      .eq("invited_user_id", existingUserId)
      .eq("status", "pending")
      .maybeSingle();

    if (pendingErr) {
      console.error("[invite] falha ao ler convite pendente:", pendingErr.code ?? "sem código");
      return json({ error: "Não foi possível concluir o convite." }, 500);
    }
    if (pendingRow) {
      return json({ status: "pending_already", role: PAPEL_FIXO, email_sent: false });
    }

    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    const { data: createdInv, error: createInvErr } = await adminClient
      .from("company_invitations")
      .insert({
        company_id: companyId,
        invited_user_id: existingUserId,
        invited_email: email,
        invited_by: requesterId,
        proposed_role: PAPEL_FIXO,
        status: "pending",
        expires_at: expiresAt,
      })
      .select("id")
      .single();

    if (createInvErr || !createdInv) {
      console.error("[invite] falha ao criar company_invitations:", createInvErr?.code ?? "sem código");
      return json({ error: "Não foi possível concluir o convite." }, 500);
    }

    const { data: companyProf } = await adminClient
      .from("company_profiles")
      .select("company_name")
      .eq("id", companyId)
      .maybeSingle();
    const companyName = (companyProf?.company_name as string | undefined)?.trim() || "uma empresa";

    const emailSent = await sendCompanyInviteResendEmail({
      to: email,
      inviteeName: name,
      companyName,
      redirectBase: REDIRECT_TO,
    });

    return json({
      status: "pending_acceptance",
      role: PAPEL_FIXO,
      invitation_id: createdInv.id,
      email_sent: emailSent,
    });
  }

  // ---- 6. CASO 1 — e-mail novo: convite por e-mail ---------------------
  // O convidado define a PRÓPRIA senha pelo link. A senha nunca é criada,
  // enviada nem vista por quem convidou.
  const { data: invited, error: inviteErr } = await adminClient.auth.admin.inviteUserByEmail(
    email,
    {
      data: { nome: name }, // rótulo de perfil; jamais fonte de papel
      ...(REDIRECT_TO ? { redirectTo: REDIRECT_TO } : {}),
    },
  );

  if (inviteErr || !invited?.user) {
    console.error("[invite] falha no convite:", inviteErr?.status ?? "sem status");
    return json({ error: "Não foi possível enviar o convite." }, 502);
  }
  const novoUserId = invited.user.id;

  // ---- 7. Membership + rollback compensatório --------------------------
  // O convite vive no Auth e a membership no Postgres: não há transação comum.
  // Se o vínculo falhar, o usuário recém-criado POR ESTA operação é removido,
  // para não deixar conta órfã sem empresa. Um usuário PREEXISTENTE jamais
  // chega aqui (foi tratado no passo 5), então nunca é excluído.
  const { data: outcome, error: bindErr } = await adminClient.rpc("add_company_seller", {
    p_company_id: companyId,
    p_requester: requesterId,
    p_user_id: novoUserId,
  });

  if (bindErr) {
    console.error("[invite] falha ao criar membership:", bindErr.code ?? "sem código");
    const { error: rbErr } = await adminClient.auth.admin.deleteUser(novoUserId);
    if (rbErr) {
      // Estado a reconciliar manualmente: conta criada sem empresa.
      console.error("[invite] rollback do convite falhou:", rbErr.status ?? "sem status");
    }
    return json({ error: "Não foi possível concluir o convite." }, 500);
  }

  return json({
    status: outcome === "already_member" ? "already_member" : "invited",
    role: PAPEL_FIXO,
  });
});

/** Aviso a quem já tem conta — Resend HTTP (secrets RESEND_API_KEY + RESEND_FROM). */
async function sendCompanyInviteResendEmail(params: {
  to: string;
  inviteeName: string;
  companyName: string;
  redirectBase: string | undefined;
}): Promise<boolean> {
  const apiKey = Deno.env.get("RESEND_API_KEY");
  const from = Deno.env.get("RESEND_FROM");
  if (!apiKey || !from) {
    console.error("[invite] RESEND_API_KEY ou RESEND_FROM ausente — e-mail nao enviado");
    return false;
  }

  let appUrl = "https://versaglass.vercel.app/app";
  if (params.redirectBase) {
    try {
      const u = new URL(params.redirectBase);
      appUrl = `${u.origin}/app`;
    } catch {
      /* mantém default */
    }
  }

  const subject = `Convite para a equipe de ${params.companyName} — VersaGlass`;
  const html = `
    <p>Olá${params.inviteeName ? ` ${params.inviteeName}` : ""},</p>
    <p>Você foi convidado(a) a entrar na equipe de <strong>${params.companyName}</strong> no VersaGlass.</p>
    <p>Entre na sua conta para <strong>aceitar ou recusar</strong> o convite. O pedido expira em 7 dias.</p>
    <p><a href="${appUrl}">Abrir VersaGlass</a></p>
  `;

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from,
        to: [params.to],
        subject,
        html,
      }),
    });
    if (!res.ok) {
      const body = await res.text();
      console.error("[invite] Resend falhou:", res.status, body.slice(0, 200));
      return false;
    }
    return true;
  } catch (e) {
    console.error("[invite] Resend exception:", e instanceof Error ? e.message : "erro");
    return false;
  }
}
