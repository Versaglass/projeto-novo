// =====================================================================
// asaas-webhook — recebe eventos Asaas (conta única VersaGlass SaaS)
//
// verify_jwt = false no config.toml.
// Auth própria: header asaas-access-token === ASAAS_WEBHOOK_TOKEN.
//
// Idempotência (asaas_webhook_events):
//   - processed_at IS NOT NULL → já concluído → 200, sem reexecutar
//   - event_id existe e processed_at IS NULL → retry permitido
//   - sucesso → processed_at = now(), processing_error = null → 200
//   - falha  → processing_error sanitizado, processed_at = null → 500 (Asaas retry)
// =====================================================================

import { createClient, type SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.105.4";
import { timingSafeEqualString } from "../_shared/asaas.ts";

const CORS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, asaas-access-token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });
}

type JsonObj = Record<string, unknown>;

function asObj(v: unknown): JsonObj | null {
  return v && typeof v === "object" && !Array.isArray(v) ? (v as JsonObj) : null;
}

function asStr(v: unknown): string | null {
  return typeof v === "string" && v.trim() ? v.trim() : null;
}

/** Mensagem curta, sem secrets/tokens/payload bruto. */
function sanitizeError(err: unknown): string {
  let raw = "erro de processamento";
  if (err instanceof Error && err.message) raw = err.message;
  else if (typeof err === "string" && err.trim()) raw = err.trim();
  return raw
    .replace(/access_token\s*[:=]\s*\S+/gi, "access_token=[redacted]")
    .replace(/asaas-access-token\s*[:=]\s*\S+/gi, "asaas-access-token=[redacted]")
    .replace(/Bearer\s+\S+/gi, "Bearer [redacted]")
    .replace(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g, "[jwt-redacted]")
    .slice(0, 300);
}

class ReconciliationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ReconciliationError";
  }
}

type SubRow = {
  id: string;
  status: string;
  asaas_customer_id: string | null;
  asaas_checkout_id: string | null;
  asaas_subscription_id: string | null;
};

const SUB_SELECT = "id, status, asaas_customer_id, asaas_checkout_id, asaas_subscription_id";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);

  const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
  const SECRET = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? Deno.env.get("SUPABASE_SECRET_KEY");
  const WEBHOOK_TOKEN = Deno.env.get("ASAAS_WEBHOOK_TOKEN")?.trim() ?? "";

  if (!SUPABASE_URL || !SECRET || !WEBHOOK_TOKEN) {
    console.error("[asaas-webhook] ambiente incompleto");
    return json({ error: "Serviço indisponível." }, 500);
  }

  const provided = req.headers.get("asaas-access-token") ?? "";
  if (!provided || !timingSafeEqualString(provided, WEBHOOK_TOKEN)) {
    return json({ error: "Não autorizado." }, 401);
  }

  let payload: JsonObj;
  try {
    payload = (await req.json()) as JsonObj;
  } catch {
    return json({ error: "Payload inválido." }, 400);
  }

  const eventType = asStr(payload.event) ?? asStr(payload.type) ?? "UNKNOWN";
  const eventId =
    asStr(payload.id) ??
    asStr(payload.eventId) ??
    `${eventType}:${asStr(asObj(payload.payment)?.id) ?? asStr(asObj(payload.checkout)?.id) ?? asStr(asObj(payload.subscription)?.id) ?? "none"}:${asStr(payload.dateCreated) ?? "nodate"}`;

  const admin = createClient(SUPABASE_URL, SECRET, {
    auth: { autoRefreshToken: false, persistSession: false, detectSessionInUrl: false },
  });

  // ---- Claim / idempotência ----------------------------------------------
  const claim = await claimEvent(admin, eventId, eventType);
  if (claim.kind === "already_processed") {
    return json({ ok: true, duplicate: true });
  }
  if (claim.kind === "error") {
    return json({ error: "Falha ao registrar evento." }, 500);
  }

  let companySubscriptionId: string | null = null;
  let resourceId: string | null = null;

  try {
    const result = await dispatchEvent(admin, eventType, payload);
    companySubscriptionId = result.companySubscriptionId;
    resourceId = result.resourceId;

    const { error: okErr } = await admin
      .from("asaas_webhook_events")
      .update({
        resource_id: resourceId,
        company_subscription_id: companySubscriptionId,
        processed_at: new Date().toISOString(),
        processing_error: null,
      })
      .eq("event_id", eventId);

    if (okErr) {
      console.error("[asaas-webhook] mark processed:", okErr.code ?? "falha");
      throw new Error("Falha ao marcar evento como processado.");
    }

    return json({ ok: true });
  } catch (e) {
    const msg = sanitizeError(e);
    console.error("[asaas-webhook] process error", { eventType, eventId });

    await admin
      .from("asaas_webhook_events")
      .update({
        resource_id: resourceId,
        company_subscription_id: companySubscriptionId,
        processed_at: null,
        processing_error: msg,
      })
      .eq("event_id", eventId);

    // 500 intencional: Asaas deve reenviar (retry).
    return json({ error: "Falha ao processar evento." }, 500);
  }
});

type ClaimResult = { kind: "claimed" } | { kind: "already_processed" } | { kind: "error" };

async function claimEvent(
  admin: SupabaseClient,
  eventId: string,
  eventType: string,
): Promise<ClaimResult> {
  const { error: insertEvtErr } = await admin.from("asaas_webhook_events").insert({
    event_id: eventId,
    event_type: eventType,
    resource_id: null,
    received_at: new Date().toISOString(),
    processed_at: null,
    processing_error: null,
  });

  if (!insertEvtErr) return { kind: "claimed" };

  if (insertEvtErr.code !== "23505") {
    console.error("[asaas-webhook] insert event:", insertEvtErr.code ?? "falha");
    return { kind: "error" };
  }

  // event_id já existe — só pular se realmente concluído.
  const { data: existing, error: selErr } = await admin
    .from("asaas_webhook_events")
    .select("processed_at")
    .eq("event_id", eventId)
    .maybeSingle();

  if (selErr) {
    console.error("[asaas-webhook] select event:", selErr.code ?? "falha");
    return { kind: "error" };
  }

  if (existing?.processed_at) {
    return { kind: "already_processed" };
  }

  // processed_at IS NULL → falhou antes ou ainda em andamento; permitir retry.
  return { kind: "claimed" };
}

async function dispatchEvent(
  admin: SupabaseClient,
  eventType: string,
  payload: JsonObj,
): Promise<{ companySubscriptionId: string | null; resourceId: string | null }> {
  switch (eventType) {
    case "CHECKOUT_CREATED":
    case "CHECKOUT_PAID":
    case "CHECKOUT_CANCELED":
    case "CHECKOUT_EXPIRED":
      return handleCheckout(admin, eventType, asObj(payload.checkout) ?? payload);

    case "SUBSCRIPTION_CREATED":
    case "SUBSCRIPTION_UPDATED":
    case "SUBSCRIPTION_INACTIVATED":
    case "SUBSCRIPTION_DELETED":
      return handleSubscription(admin, eventType, asObj(payload.subscription) ?? payload);

    case "PAYMENT_CREATED":
    case "PAYMENT_CONFIRMED":
    case "PAYMENT_RECEIVED":
    case "PAYMENT_OVERDUE":
    case "PAYMENT_CREDIT_CARD_CAPTURE_REFUSED":
      return handlePayment(admin, eventType, asObj(payload.payment) ?? payload);

    case "PAYMENT_REFUNDED":
    case "PAYMENT_CHARGEBACK_REQUESTED":
      // Reconhecido; sem entitlement nesta etapa — processamento válido.
      console.error("[asaas-webhook] evento financeiro sem entitlement", { eventType });
      return {
        companySubscriptionId: null,
        resourceId: asStr((asObj(payload.payment) ?? payload).id),
      };

    default:
      // Desconhecido / deliberadamente ignorado — sucesso (sem retry eterno).
      console.error("[asaas-webhook] evento não tratado", { eventType });
      return { companySubscriptionId: null, resourceId: null };
  }
}

async function findSubByCheckout(admin: SupabaseClient, checkout: JsonObj): Promise<SubRow | null> {
  const checkoutId = asStr(checkout.id);
  const externalRef = asStr(checkout.externalReference);

  if (checkoutId) {
    const { data, error } = await admin
      .from("company_subscriptions")
      .select(SUB_SELECT)
      .eq("asaas_checkout_id", checkoutId)
      .maybeSingle();
    if (error) throw new ReconciliationError("Falha ao buscar assinatura por checkout.");
    if (data) return data as SubRow;
  }

  if (externalRef) {
    const { data, error } = await admin
      .from("company_subscriptions")
      .select(SUB_SELECT)
      .eq("id", externalRef)
      .maybeSingle();
    if (error) throw new ReconciliationError("Falha ao buscar assinatura por externalReference.");
    if (data) return data as SubRow;
  }

  return null;
}

async function handleCheckout(
  admin: SupabaseClient,
  eventType: string,
  checkout: JsonObj,
): Promise<{ companySubscriptionId: string | null; resourceId: string | null }> {
  const resourceId = asStr(checkout.id);
  const sub = await findSubByCheckout(admin, checkout);
  if (!sub) {
    throw new ReconciliationError("Checkout sem company_subscription local.");
  }

  const patch: JsonObj = {};
  if (resourceId) patch.asaas_checkout_id = resourceId;

  if (eventType === "CHECKOUT_CREATED") {
    patch.checkout_status = "ACTIVE";
  } else if (eventType === "CHECKOUT_PAID") {
    // Conclusão paga da jornada Checkout (doc Asaas). Ativa o plano.
    patch.checkout_status = "PAID";
    patch.status = "active";
    patch.last_payment_at = new Date().toISOString();
  } else if (eventType === "CHECKOUT_CANCELED") {
    patch.checkout_status = "CANCELED";
    if (sub.status !== "active") patch.status = "pending";
  } else if (eventType === "CHECKOUT_EXPIRED") {
    patch.checkout_status = "EXPIRED";
    if (sub.status !== "active") patch.status = "pending";
  }

  const customer = asStr(checkout.customer);
  if (customer) patch.asaas_customer_id = customer;

  const { error } = await admin.from("company_subscriptions").update(patch).eq("id", sub.id);
  if (error) throw new ReconciliationError("Falha ao atualizar assinatura no checkout.");

  return { companySubscriptionId: sub.id, resourceId };
}

/**
 * SUBSCRIPTION_*:
 * 1) externalReference somente se vier preenchido (NÃO assumir propagação do Checkout)
 * 2) asaas_subscription_id já conhecido
 * 3) fallback estruturado: subscription.customer → asaas_customer_id
 */
async function findSubForSubscription(
  admin: SupabaseClient,
  subscription: JsonObj,
): Promise<SubRow | null> {
  const externalRef = asStr(subscription.externalReference);
  if (externalRef) {
    const { data, error } = await admin
      .from("company_subscriptions")
      .select(SUB_SELECT)
      .eq("id", externalRef)
      .maybeSingle();
    if (error) throw new ReconciliationError("Falha ao buscar por externalReference.");
    if (data) return data as SubRow;
  }

  const subId = asStr(subscription.id);
  if (subId) {
    const { data, error } = await admin
      .from("company_subscriptions")
      .select(SUB_SELECT)
      .eq("asaas_subscription_id", subId)
      .maybeSingle();
    if (error) throw new ReconciliationError("Falha ao buscar por asaas_subscription_id.");
    if (data) return data as SubRow;
  }

  const customerId = asStr(subscription.customer);
  if (customerId) {
    return await findExactlyOneByCustomer(admin, customerId);
  }

  return null;
}

async function findExactlyOneByCustomer(
  admin: SupabaseClient,
  customerId: string,
): Promise<SubRow | null> {
  // Sem .limit(1): ambiguidade deve falhar, não escolher arbitrariamente.
  const { data, error } = await admin
    .from("company_subscriptions")
    .select(SUB_SELECT)
    .eq("asaas_customer_id", customerId);

  if (error) throw new ReconciliationError("Falha ao buscar por asaas_customer_id.");

  const rows = (data ?? []) as SubRow[];
  if (rows.length === 0) return null;
  if (rows.length > 1) {
    throw new ReconciliationError("Customer Asaas ambíguo: múltiplas company_subscriptions.");
  }
  return rows[0];
}

async function handleSubscription(
  admin: SupabaseClient,
  eventType: string,
  subscription: JsonObj,
): Promise<{ companySubscriptionId: string | null; resourceId: string | null }> {
  const resourceId = asStr(subscription.id);
  const sub = await findSubForSubscription(admin, subscription);
  if (!sub) {
    throw new ReconciliationError("Subscription Asaas sem company_subscription local.");
  }

  const patch: JsonObj = {};
  if (resourceId) patch.asaas_subscription_id = resourceId;

  const customer = asStr(subscription.customer);
  if (customer) patch.asaas_customer_id = customer;

  const nextDue = asStr(subscription.nextDueDate);
  if (nextDue) patch.next_due_date = nextDue.slice(0, 10);

  const billingType = asStr(subscription.billingType);
  if (billingType === "CREDIT_CARD") patch.billing_type = "CREDIT_CARD";

  if (eventType === "SUBSCRIPTION_CREATED" || eventType === "SUBSCRIPTION_UPDATED") {
    // Não forçar active — pagamento confirma via PAYMENT_* / CHECKOUT_PAID.
  } else if (eventType === "SUBSCRIPTION_INACTIVATED") {
    patch.status = "suspended";
  } else if (eventType === "SUBSCRIPTION_DELETED") {
    patch.status = "canceled";
    patch.canceled_at = new Date().toISOString();
  }

  const { error } = await admin.from("company_subscriptions").update(patch).eq("id", sub.id);
  if (error) throw new ReconciliationError("Falha ao atualizar assinatura local.");

  return { companySubscriptionId: sub.id, resourceId };
}

/**
 * PAYMENT_* com payment.subscription:
 * 1) asaas_subscription_id = payment.subscription
 * 2) fallback: payment.customer → exatamente 1 linha;
 *    se asaas_subscription_id IS NULL → aprender o ID;
 *    se já houver ID diferente → erro (não sobrescrever).
 *
 * PAYMENT_CREATED não ativa plano.
 * Datas: paymentDate / clientPaymentDate / confirmedDate (quando houver); senão now().
 */
async function resolveSubForPayment(admin: SupabaseClient, payment: JsonObj): Promise<SubRow> {
  const asaasSubId = asStr(payment.subscription);
  if (!asaasSubId) {
    throw new ReconciliationError("Payment sem subscription — fora do escopo SaaS.");
  }

  const { data: bySub, error: bySubErr } = await admin
    .from("company_subscriptions")
    .select(SUB_SELECT)
    .eq("asaas_subscription_id", asaasSubId);

  if (bySubErr) throw new ReconciliationError("Falha ao buscar payment.subscription.");

  const bySubRows = (bySub ?? []) as SubRow[];
  if (bySubRows.length > 1) {
    throw new ReconciliationError("Múltiplas linhas com o mesmo asaas_subscription_id.");
  }
  if (bySubRows.length === 1) return bySubRows[0];

  // Fallback: customer (cobre PAYMENT_* antes de SUBSCRIPTION_CREATED).
  const customerId = asStr(payment.customer);
  if (!customerId) {
    throw new ReconciliationError("Payment sem subscription local e sem customer.");
  }

  const byCustomer = await findExactlyOneByCustomer(admin, customerId);
  if (!byCustomer) {
    throw new ReconciliationError("Payment sem company_subscription reconciliável.");
  }

  if (byCustomer.asaas_subscription_id == null) {
    const { error: learnErr } = await admin
      .from("company_subscriptions")
      .update({ asaas_subscription_id: asaasSubId })
      .eq("id", byCustomer.id)
      .is("asaas_subscription_id", null);

    if (learnErr) {
      throw new ReconciliationError("Falha ao aprender asaas_subscription_id via payment.");
    }
    return { ...byCustomer, asaas_subscription_id: asaasSubId };
  }

  if (byCustomer.asaas_subscription_id !== asaasSubId) {
    throw new ReconciliationError(
      "Conflito: asaas_subscription_id local difere de payment.subscription.",
    );
  }

  return byCustomer;
}

function paymentConfirmedAt(payment: JsonObj): string {
  // Preferência: datas oficiais do Payment Asaas (SDK: paymentDate, clientPaymentDate).
  // confirmedDate permanece como fallback legado se aparecer no payload.
  const raw =
    asStr(payment.paymentDate) ?? asStr(payment.clientPaymentDate) ?? asStr(payment.confirmedDate);
  if (raw) {
    const d = new Date(raw);
    if (!Number.isNaN(d.getTime())) return d.toISOString();
  }
  return new Date().toISOString();
}

async function handlePayment(
  admin: SupabaseClient,
  eventType: string,
  payment: JsonObj,
): Promise<{ companySubscriptionId: string | null; resourceId: string | null }> {
  const resourceId = asStr(payment.id);
  const asaasSubId = asStr(payment.subscription);

  // Cobrança avulsa (sem subscription) — fora do SaaS; ignorar com sucesso.
  if (!asaasSubId) {
    return { companySubscriptionId: null, resourceId };
  }

  const sub = await resolveSubForPayment(admin, payment);
  const patch: JsonObj = {};

  const dueDate = asStr(payment.dueDate);
  if (eventType === "PAYMENT_CREATED") {
    // Não ativa plano — só aprende IDs (já feito) e next_due_date.
    if (dueDate) patch.next_due_date = dueDate.slice(0, 10);
  }

  if (eventType === "PAYMENT_CONFIRMED" || eventType === "PAYMENT_RECEIVED") {
    patch.status = "active";
    patch.last_payment_at = paymentConfirmedAt(payment);
  } else if (
    eventType === "PAYMENT_OVERDUE" ||
    eventType === "PAYMENT_CREDIT_CARD_CAPTURE_REFUSED"
  ) {
    patch.status = "past_due";
  }

  if (Object.keys(patch).length) {
    const { error } = await admin.from("company_subscriptions").update(patch).eq("id", sub.id);
    if (error) throw new ReconciliationError("Falha ao atualizar status via payment.");
  }

  return { companySubscriptionId: sub.id, resourceId };
}
