// =====================================================================
// asaas-create-checkout — inicia Checkout Asaas RECURRENT (SaaS VersaGlass)
//
// Frontend envia SOMENTE { companyId, planSlug }.
// Preço/ciclo/billing vêm de saas_plans no servidor.
// Autorização: JWT + membership owner/admin ativa.
// Escrita em company_subscriptions via service_role.
// =====================================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.105.4";
import {
  AsaasHttpError,
  asaasFetch,
  checkoutPublicUrl,
  getAsaasConfig,
  isValidCnpjDigits,
  isValidEmail,
  onlyDigits,
  todayDateString,
  type AsaasCheckout,
  type AsaasCustomer,
  type AsaasListResponse,
} from "../_shared/asaas.ts";

const CORS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const PLAN_SLUGS = new Set(["basic", "premium"]);

type CompanyRow = {
  id: string;
  company_name: string;
  cnpj: string | null;
  email: string | null;
  phone: string | null;
};

type SubRow = {
  id: string;
  company_id: string;
  plan_slug: string;
  status: string;
  asaas_customer_id: string | null;
  asaas_checkout_id: string | null;
  asaas_subscription_id: string | null;
  checkout_status: string | null;
  checkout_expires_at: string | null;
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);

  const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
  const PUBLISHABLE = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
  const SECRET = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? Deno.env.get("SUPABASE_SECRET_KEY");
  const APP_BASE_URL = (Deno.env.get("APP_BASE_URL") ?? "").replace(/\/$/, "");

  if (!SUPABASE_URL || !PUBLISHABLE || !SECRET) {
    console.error("[asaas-create-checkout] ambiente incompleto");
    return json({ error: "Serviço indisponível." }, 500);
  }
  if (!getAsaasConfig() || !APP_BASE_URL || !/^https?:\/\//i.test(APP_BASE_URL)) {
    console.error("[asaas-create-checkout] Asaas/APP_BASE_URL não configurados");
    return json({ error: "Serviço indisponível." }, 500);
  }

  // ---- 1. JWT ------------------------------------------------------------
  const authHeader = req.headers.get("Authorization") ?? "";
  if (!authHeader.toLowerCase().startsWith("bearer ")) {
    return json({ error: "Autenticação obrigatória." }, 401);
  }

  const userClient = createClient(SUPABASE_URL, PUBLISHABLE, {
    global: { headers: { Authorization: authHeader } },
    auth: { autoRefreshToken: false, persistSession: false, detectSessionInUrl: false },
  });

  const { data: userData, error: userErr } = await userClient.auth.getUser();
  if (userErr || !userData?.user) {
    return json({ error: "Autenticação obrigatória." }, 401);
  }
  const requesterId = userData.user.id;

  // ---- 2. Body (somente companyId + planSlug) ----------------------------
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Requisição inválida." }, 400);
  }

  const companyId = typeof body.companyId === "string" ? body.companyId.trim() : "";
  const planSlug = typeof body.planSlug === "string" ? body.planSlug.trim().toLowerCase() : "";

  if (!UUID_RE.test(companyId)) return json({ error: "Empresa inválida." }, 400);
  if (!PLAN_SLUGS.has(planSlug)) return json({ error: "Plano inválido." }, 400);

  // ---- 3. Autorização owner/admin ----------------------------------------
  const { data: membership, error: memErr } = await userClient
    .from("company_members")
    .select("role, status")
    .eq("company_id", companyId)
    .eq("user_id", requesterId)
    .maybeSingle();

  if (memErr) {
    console.error("[asaas-create-checkout] membership:", memErr.code ?? "sem código");
    return json({ error: "Não foi possível iniciar o pagamento. Tente novamente." }, 500);
  }
  if (
    !membership ||
    membership.status !== "active" ||
    (membership.role !== "owner" && membership.role !== "admin")
  ) {
    return json(
      { error: "Somente proprietários ou administradores podem gerenciar a assinatura." },
      403,
    );
  }

  const admin = createClient(SUPABASE_URL, SECRET, {
    auth: { autoRefreshToken: false, persistSession: false, detectSessionInUrl: false },
  });

  // ---- 4. Plano canônico -------------------------------------------------
  const { data: plan, error: planErr } = await admin
    .from("saas_plans")
    .select("slug, name, price_monthly, cycle, active")
    .eq("slug", planSlug)
    .eq("active", true)
    .maybeSingle();

  if (planErr || !plan) {
    console.error("[asaas-create-checkout] plano:", planErr?.code ?? "ausente");
    return json({ error: "Plano inválido." }, 400);
  }

  // ---- 5. Empresa (dados Customer) ---------------------------------------
  const { data: company, error: companyErr } = await admin
    .from("company_profiles")
    .select("id, company_name, cnpj, email, phone")
    .eq("id", companyId)
    .maybeSingle();

  if (companyErr || !company) {
    console.error("[asaas-create-checkout] company:", companyErr?.code ?? "ausente");
    return json({ error: "Empresa inválida." }, 400);
  }

  const companyRow = company as CompanyRow;
  const companyName = (companyRow.company_name ?? "").trim();
  const cnpjDigits = onlyDigits(companyRow.cnpj);

  if (!companyName || !isValidCnpjDigits(cnpjDigits)) {
    return json(
      {
        error:
          "Complete os dados da empresa antes de assinar. Nome da empresa e CNPJ são obrigatórios.",
      },
      400,
    );
  }

  // ---- 6. Garantir company_subscriptions ---------------------------------
  const { data: existingSub, error: subErr } = await admin
    .from("company_subscriptions")
    .select(
      "id, company_id, plan_slug, status, asaas_customer_id, asaas_checkout_id, asaas_subscription_id, checkout_status, checkout_expires_at",
    )
    .eq("company_id", companyId)
    .maybeSingle();

  if (subErr) {
    console.error("[asaas-create-checkout] sub select:", subErr.code ?? "sem código");
    return json({ error: "Não foi possível iniciar o pagamento. Tente novamente." }, 500);
  }

  let sub = existingSub as SubRow | null;

  if (sub && sub.status === "active" && sub.asaas_subscription_id) {
    return json({ error: "Esta empresa já possui uma assinatura ativa." }, 409);
  }

  if (!sub) {
    const { data: inserted, error: insertErr } = await admin
      .from("company_subscriptions")
      .insert({
        company_id: companyId,
        plan_slug: planSlug,
        status: "pending",
        created_by: requesterId,
        billing_type: "CREDIT_CARD",
      })
      .select(
        "id, company_id, plan_slug, status, asaas_customer_id, asaas_checkout_id, asaas_subscription_id, checkout_status, checkout_expires_at",
      )
      .single();

    if (insertErr || !inserted) {
      console.error("[asaas-create-checkout] sub insert:", insertErr?.code ?? "falha");
      return json({ error: "Não foi possível iniciar o pagamento. Tente novamente." }, 500);
    }
    sub = inserted as SubRow;
  } else if (!sub.asaas_subscription_id || sub.status !== "active") {
    if (sub.plan_slug !== planSlug) {
      const { data: updated, error: updErr } = await admin
        .from("company_subscriptions")
        .update({ plan_slug: planSlug, status: "pending", canceled_at: null })
        .eq("id", sub.id)
        .select(
          "id, company_id, plan_slug, status, asaas_customer_id, asaas_checkout_id, asaas_subscription_id, checkout_status, checkout_expires_at",
        )
        .single();
      if (updErr || !updated) {
        console.error("[asaas-create-checkout] sub plan update:", updErr?.code ?? "falha");
        return json({ error: "Não foi possível iniciar o pagamento. Tente novamente." }, 500);
      }
      sub = updated as SubRow;
    }
  }

  // ---- 7. Checkout ACTIVE ainda válido → reutilizar ----------------------
  const cfg = getAsaasConfig()!;
  if (
    sub.asaas_checkout_id &&
    sub.checkout_status === "ACTIVE" &&
    sub.status === "pending" &&
    sub.checkout_expires_at &&
    new Date(sub.checkout_expires_at).getTime() > Date.now()
  ) {
    const checkoutUrl = checkoutPublicUrl(cfg.baseUrl, sub.asaas_checkout_id);
    console.error("[asaas-create-checkout] reuse checkout", {
      company_id: companyId,
      plan_slug: planSlug,
      asaas_checkout_id: sub.asaas_checkout_id,
    });
    return json({
      checkoutUrl,
      checkoutId: sub.asaas_checkout_id,
      reused: true,
    });
  }

  // ---- 8. Customer Asaas (local → externalReference → create) ------------
  let customerId = sub.asaas_customer_id;

  try {
    if (!customerId) {
      const listed = await asaasFetch<AsaasListResponse<AsaasCustomer>>(
        `/customers?externalReference=${encodeURIComponent(companyId)}&limit=1`,
      );
      const found = listed.data?.[0];
      if (found?.id) {
        customerId = found.id;
      } else {
        const payload: Record<string, string> = {
          name: companyName,
          cpfCnpj: cnpjDigits,
          externalReference: companyId,
        };
        if (isValidEmail(companyRow.email)) payload.email = companyRow.email!.trim();
        const phoneDigits = onlyDigits(companyRow.phone);
        if (phoneDigits.length >= 10) {
          payload.mobilePhone = phoneDigits;
          payload.phone = phoneDigits;
        }
        // address/city/state de company_profiles são texto livre (sem CEP/IBGE);
        // não enviar — formato inválido quebraria o POST /customers.

        const created = await asaasFetch<AsaasCustomer>("/customers", {
          method: "POST",
          body: payload,
        });
        if (!created?.id) throw new AsaasHttpError(502, "Customer sem id.");
        customerId = created.id;
      }

      const { error: saveCustErr } = await admin
        .from("company_subscriptions")
        .update({ asaas_customer_id: customerId })
        .eq("id", sub.id);

      if (saveCustErr) {
        // Customer pode já existir no Asaas — próxima tentativa reutiliza via externalReference.
        console.error("[asaas-create-checkout] save customer id:", saveCustErr.code ?? "falha", {
          company_id: companyId,
          asaas_customer_id: customerId,
        });
        return json({ error: "Não foi possível iniciar o pagamento. Tente novamente." }, 500);
      }
      sub.asaas_customer_id = customerId;
    }

    // ---- 9. Criar Checkout RECURRENT -------------------------------------
    const price = Number(plan.price_monthly);
    const checkoutBody = {
      billingTypes: ["CREDIT_CARD"],
      chargeTypes: ["RECURRENT"],
      minutesToExpire: 60,
      externalReference: sub.id,
      customer: customerId,
      callback: {
        successUrl: `${APP_BASE_URL}/app/minha-assinatura?checkout=success`,
        cancelUrl: `${APP_BASE_URL}/app/minha-assinatura?checkout=cancel`,
        expiredUrl: `${APP_BASE_URL}/app/minha-assinatura?checkout=expired`,
      },
      items: [
        {
          name: `Plano ${plan.name}`,
          description: "Assinatura mensal do VersaGlass",
          quantity: 1,
          value: price,
        },
      ],
      subscription: {
        cycle: "MONTHLY",
        nextDueDate: todayDateString(),
        // endDate omitido de propósito — schema Asaas marca como opcional
        // (assinatura sem prazo final).
      },
    };

    const checkout = await asaasFetch<AsaasCheckout>("/checkouts", {
      method: "POST",
      body: checkoutBody,
    });

    if (!checkout?.id) throw new AsaasHttpError(502, "Checkout sem id.");

    const expiresAt = new Date(Date.now() + 60 * 60 * 1000).toISOString();
    const { error: saveCheckoutErr } = await admin
      .from("company_subscriptions")
      .update({
        asaas_checkout_id: checkout.id,
        asaas_customer_id: customerId,
        checkout_status: "ACTIVE",
        checkout_expires_at: expiresAt,
        status: "pending",
        billing_type: "CREDIT_CARD",
        plan_slug: planSlug,
      })
      .eq("id", sub.id);

    if (saveCheckoutErr) {
      console.error("[asaas-create-checkout] save checkout:", saveCheckoutErr.code ?? "falha", {
        company_id: companyId,
        asaas_checkout_id: checkout.id,
        asaas_customer_id: customerId,
      });
      // Checkout existe no Asaas — devolver link mesmo assim para o usuário pagar;
      // próxima tentativa reutiliza se salvarmos em retry, ou cria conflito de unique.
      // Tentamos reconciliar numa segunda escrita mínima.
      await admin
        .from("company_subscriptions")
        .update({
          asaas_checkout_id: checkout.id,
          checkout_status: "ACTIVE",
          checkout_expires_at: expiresAt,
        })
        .eq("id", sub.id);
    }

    const checkoutUrl = checkoutPublicUrl(cfg.baseUrl, checkout.id, checkout.link);
    console.error("[asaas-create-checkout] ok", {
      company_id: companyId,
      plan_slug: planSlug,
      asaas_customer_id: customerId,
      asaas_checkout_id: checkout.id,
    });

    return json({
      checkoutUrl,
      checkoutId: checkout.id,
      reused: false,
    });
  } catch (e) {
    if (e instanceof AsaasHttpError) {
      console.error("[asaas-create-checkout] asaas error", {
        company_id: companyId,
        plan_slug: planSlug,
        status: e.status,
      });
    } else {
      console.error("[asaas-create-checkout] unexpected");
    }
    return json({ error: "Não foi possível iniciar o pagamento. Tente novamente." }, 502);
  }
});
