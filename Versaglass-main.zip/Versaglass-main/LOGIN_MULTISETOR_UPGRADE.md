# Login multissetor implementado

Alteração aplicada em `src/routes/auth.tsx`.

## O que foi feito

- Substituída a tela de login focada apenas em vidraçaria por uma capa multissetor.
- Novo posicionamento: plataforma para vidraçaria, serralheria, marcenaria, marmoraria, esquadrias e construção civil.
- Cards visuais em SVG técnico, sem depender de imagens externas.
- Formulário de login/cadastro/recuperação mantido.
- Login por e-mail/senha mantido.
- Login Google mantido.
- Redirecionamento para `/app` após login mantido.
- Mensagem multiempresa incluída para reforçar isolamento de dados.
- Layout responsivo para desktop e mobile.

## Arquivo principal alterado

- `src/routes/auth.tsx`

## Build

Build testado com sucesso com `npm run build`.
