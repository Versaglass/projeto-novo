# Upgrade Projetos Premium por Área

Implementado na aba **Projetos**:

- Botões por área: Vidraçaria, Serralheria de aço, Marcenaria e Marmoraria.
- Sub-botões por modelos/local:
  - Serralheria de aço: Galpão, Portão, Janela, Móveis industriais e Grades.
  - Vidraçaria: Box, Portas de vidro, Espelhos e Guarda-corpo.
  - Marcenaria: Cozinha, Painel, Closet e Banheiro.
  - Marmoraria: Bancadas, Escadas, Cubas e Nichos.
- Projetos organizados por local certo.
- Limite de 3 projetos gratuitos por categoria/local.
- Projetos acima do limite aparecem como Premium/PRO com cadeado.
- Ao clicar em projeto bloqueado, direciona para `/app/minha-assinatura` para pagamento/liberação.
- Mantido filtro 2D/3D e busca por nome/categoria/descrição.
- Adicionadas imagens SVG para novos projetos 2D e 3D.

Build validado com `npm run build`.
