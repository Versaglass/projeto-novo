# Atualização aplicada

## Projetos mais realistas e editáveis
- O editor paramétrico foi substituído por uma interface visual realista em código React/SVG.
- O usuário vê o projeto enquanto altera medidas, peças, recortes, furos e ferragens.
- Tem abas: Editor 2D, Visualização 3D, Explodido e Plano de Corte.
- Painel esquerdo: componentes e camadas.
- Painel direito: propriedades da peça selecionada.
- O desenho atualiza em tempo real, junto com lista de materiais, plano de corte e resumo do orçamento.
- Permite salvar localmente, salvar como novo projeto e exportar JSON técnico.

## Catálogo de alumínios
- Adicionado catálogo real na aba Produtos > Alumínios.
- Itens com código, SKU, categoria, medida, peso kg/m, medidas A/B/C, polegadas, NCM, GTIN e estoque.
- Imagens/desenhos técnicos são gerados por código SVG limpo, sem marca de fornecedor.
- Exportação CSV incluída.
- Migration Supabase criada para aluminum_categories e aluminum_profiles.
