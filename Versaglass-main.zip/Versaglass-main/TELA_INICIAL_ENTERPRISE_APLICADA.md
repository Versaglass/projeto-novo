# Tela inicial Enterprise aplicada

Esta versão garante que a nova tela inicial seja exibida em `/app` de duas formas:

1. `src/routes/_authenticated/app.index.tsx` renderiza `DashboardEnterprise`.
2. `src/routes/_authenticated/app.tsx` também verifica se a URL é `/app` ou `/app/` e renderiza `DashboardEnterprise` diretamente.

Isso evita que a tela antiga apareça caso o index route do TanStack não seja resolvido no ambiente de deploy.

Arquivos principais:
- `src/pages/DashboardEnterprise.tsx`
- `src/components/dashboard/MetricCard.tsx`
- `src/components/dashboard/ModuleCard.tsx`
- `src/components/dashboard/FinanceChart.tsx`
- `src/components/dashboard/AIAssistantCard.tsx`
- `src/components/dashboard/TodayAgendaCard.tsx`
- `src/components/dashboard/FeaturedProjects.tsx`
- `src/components/dashboard/MarketplaceCard.tsx`
- `src/routes/_authenticated/app.tsx`
- `src/routes/_authenticated/app.index.tsx`
