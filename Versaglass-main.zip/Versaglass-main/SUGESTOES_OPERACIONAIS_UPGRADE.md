# Melhorias operacionais adicionadas

Foram adicionados módulos para transformar a plataforma em gestão completa:

- Central de Obras com localização, fotos, equipe, materiais, custo, lucro e garantia.
- Agenda de instalação com rota, confirmação, status e checklist.
- App do Instalador com materiais, fotos, assinatura e sem acesso financeiro.
- CRM com funil comercial.
- Compras automáticas por materiais faltantes.
- Garantias e pós-venda.
- Assinaturas digitais para orçamento, contrato, entrega e instalação.
- Marketplace interno de projetos.
- Área do fabricante para catálogos, tabelas e promoções.
- Backups automáticos com restauração.
- IA para criar projetos por texto.
- Chat IA interno para apoio técnico e comercial.

Banco de dados: migration `20260701033000_operational_modules.sql`.
