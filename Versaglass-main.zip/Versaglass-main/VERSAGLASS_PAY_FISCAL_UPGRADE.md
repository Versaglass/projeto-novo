# Upgrade implementado: VersaGlass Pay + Fiscal

## VersaGlass Pay

Arquivos adicionados:

- `src/modules/payments/types.ts`
- `src/modules/payments/paymentProvider.ts`
- `src/modules/payments/paymentService.ts`
- `src/modules/payments/splitService.ts`
- `src/modules/payments/recurringService.ts`
- `src/modules/payments/webhookHandler.ts`
- `src/modules/payments/providers/asaasProvider.ts`
- `src/modules/payments/providers/efiProvider.ts`
- `src/modules/payments/providers/pagarmeProvider.ts`
- `src/routes/_authenticated/app.pay.tsx`
- `src/routes/_authenticated/app.admin.pagamentos.tsx`

Funcionalidades preparadas:

- Conta de recebimento por empresa.
- PIX, boleto, cartão, débito, link de pagamento e recorrência.
- Geração de cobrança com taxa da plataforma.
- Cálculo de split automático.
- Webhook genérico para baixa automática.
- Painel da empresa.
- Painel agregado para super_admin.
- Interface `PaymentProvider` para Asaas, Efí, Iugu, Mercado Pago e Pagar.me.

## Fiscal

Arquivos adicionados:

- `src/modules/fiscal/types.ts`
- `src/modules/fiscal/fiscalProvider.ts`
- `src/modules/fiscal/fiscalService.ts`
- `src/modules/fiscal/fiscalWebhook.ts`
- `src/modules/fiscal/providers/plugNotasProvider.ts`
- `src/modules/fiscal/providers/tecnoSpeedProvider.ts`
- `src/modules/fiscal/providers/nuvemFiscalProvider.ts`
- `src/routes/_authenticated/app.fiscal.tsx`
- `src/routes/_authenticated/app.admin.fiscal.tsx`

Funcionalidades preparadas:

- Configuração fiscal por empresa.
- NF-e, NFS-e e estrutura futura para NFC-e.
- Emissão por provedor fiscal genérico.
- XML, DANFE PDF, chave de acesso, protocolo e status.
- Cancelamento e reemissão rejeitada.
- Integração lógica com dashboard financeiro.
- Painel agregado para super_admin.

## Banco Supabase

Migration adicionada:

- `supabase/migrations/20260703020000_versaglass_pay_and_fiscal.sql`

Tabelas criadas:

- `payment_accounts`
- `charges`
- `payment_splits`
- `recurring_charges`
- `fiscal_settings`
- `fiscal_invoices`

Views agregadas:

- `platform_payment_summary`
- `platform_fiscal_summary`

RPCs:

- `company_payment_dashboard(company_id)`
- `company_fiscal_dashboard(company_id)`

## Segurança multiusuário

- RLS ativado em todas as tabelas.
- Empresas acessam apenas seus próprios dados.
- Clientes finais e notas fiscais não aparecem para outras empresas.
- Super admin utiliza views agregadas para relatórios de plataforma.
- `payment_splits` permite visão de taxas da plataforma sem expor clientes finais.

## Observação importante

Os providers foram criados com adapters de estrutura e retorno simulado para manter o build independente de credenciais. Para produção, conectar cada provider às APIs oficiais no backend/edge functions e manter chaves secretas fora do frontend.
