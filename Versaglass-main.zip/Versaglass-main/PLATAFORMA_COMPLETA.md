# Plataforma completa adicionada

Este pacote adiciona os módulos principais para transformar o sistema em plataforma para usuários de vidraçaria, serralheria de metal, esquadrias, marcenaria e marmoraria.

## Módulos atualizados

- Produtos: SKU, NCM, CEST, GTIN/EAN, preço, custo, margem, estoque, imagem, categoria e fornecedor.
- Vidros: tipo, espessura, cor, acabamento, preço por m², custo por m², estoque e fornecedor.
- Ferragens: categoria, marca, preço, custo, estoque mínimo e imagem.
- Fornecedores: CNPJ, telefone, WhatsApp, vendedor, prazo de entrega e produtos fornecidos.
- Funcionários: função, comissão, produtividade, status e permissões.
- Ordens de Serviço: orçamento, medição, produção, corte, instalação, finalizado e pago.
- Financeiro: contas a receber, contas a pagar, lucro estimado, vencimentos e inadimplência.

## Banco de dados

Incluída migration:

`supabase/migrations/20260701021500_complete_platform_modules.sql`

Tabelas novas:

- company_profiles
- enterprise_products
- glass_catalog
- hardware_catalog
- suppliers
- employees
- service_orders
- financial_entries
- audit_events
- admin_security_events

## Segurança

- Exclusão protegida no front-end: apenas admin.
- Botões de edição bloqueados para usuário comum/operator.
- Migration com RLS habilitado.
- Estrutura de auditoria e eventos de segurança criada.

## Ambiente

- `.env` removido.
- `.env.example` criado.
- `bun.lock` e `bunfig.toml` removidos.
- Projeto mantido com npm e package-lock.json.

## Observação

Os CRUDs funcionam no front-end com estado local/localStorage como base pronta de interface. Para produção multiusuário, conectar os CRUDs às tabelas Supabase adicionadas na migration, mantendo as regras por company_id e role.
