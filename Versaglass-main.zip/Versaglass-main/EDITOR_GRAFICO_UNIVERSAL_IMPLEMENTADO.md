# Editor Gráfico Universal implementado

Implementação adicionada para evoluir os projetos de imagens estáticas para um motor gráfico técnico editável.

## Nova rota

- `/app/editor-engenharia`

## Arquivos criados

- `src/lib/engineering/engine.ts`
- `src/components/engineering/UniversalEngineeringEditor.tsx`
- `src/routes/_authenticated/app.editor-engenharia.tsx`

## Recursos incluídos

- Editor 2D vetorial em SVG
- Segmentos: Vidraçaria, Marcenaria, Marmoraria e Serralheria
- Biblioteca de componentes técnicos por segmento
- Seleção de peças por camada
- Alteração em tempo real de largura, altura, posição, espessura, material, quantidade e custo
- Campos numéricos vazios por padrão quando valor for zero, sem `0` travado
- Prévia 3D técnica preparada para futura integração Three.js
- Plano de corte com medidas das peças e das sobras
- Lista de materiais automática
- Resumo automático de materiais, mão de obra, margem e total
- Histórico simples das alterações
- Exportação JSON do projeto técnico

## Integração no menu

O menu lateral recebeu o item:

- `Editor 2D/3D`

## Próxima etapa recomendada

Conectar o editor aos orçamentos reais:

- salvar JSON do projeto no Supabase
- vincular projeto ao orçamento
- usar a lista de materiais no orçamento
- gerar PDF técnico com o SVG
- criar exportação DXF/SVG
- substituir a prévia técnica por Three.js real quando a dependência for adicionada ao projeto
