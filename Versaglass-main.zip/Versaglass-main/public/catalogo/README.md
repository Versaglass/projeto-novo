# Catálogo

Estrutura criada para organizar imagens, desenhos e dados dos produtos de vidraçaria/espelharia.

Use `catalogo.json` como índice principal. As pastas estão vazias com `.gitkeep` para serem preservadas no ZIP/repositório.

Sugestão por produto:
- `principal.webp`
- `thumb.webp`
- `desenho.svg`
- `produto.json`
