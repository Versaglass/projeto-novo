# Configurar o projeto em outra máquina

Como abrir o VersaGlass num computador novo e continuar de onde parou, com a
aplicação rodando **localmente** e conectada ao **Supabase remoto** (o mesmo
projeto de sempre, que serve como ambiente de desenvolvimento/homologação).

Nenhum valor real aparece aqui. Só nomes de variável e comandos.

---

## 1. Requisitos

| Ferramenta | Para quê | Obrigatório? |
|---|---|---|
| **Git** | clonar o repositório | sim |
| **Bun** | instalar dependências e rodar a aplicação | sim |
| **Supabase CLI** (via `bunx`, sem instalar) | migrations, Edge Functions, tipos | só se for mexer em banco/funções |
| **Docker Desktop** | subir o Supabase **local** | **não** — desnecessário para trabalhar contra o remoto |

> **Você não precisa de `supabase start` nem de Docker** para desenvolver contra
> o banco remoto. Docker só entra se quiser um banco local isolado para testar
> migrations sem tocar no remoto.

---

## 2. Clonar

```bash
git clone https://github.com/1Prode/Versaglass.git
cd Versaglass
git checkout fix/baseline-supabase
```

`fix/baseline-supabase` é a branch de trabalho atual — **não** use a `main`, que
está atrasada em relação a ela.

Confira que veio tudo:

```bash
git log -1 --oneline
git status --short      # deve sair vazio
```

---

## 3. Instalar dependências

```bash
bun install
```

---

## 4. Configurar `.env.local`

Crie um arquivo `.env.local` na raiz (ele é ignorado pelo Git e **nunca** deve
ser commitado):

```
VITE_SUPABASE_URL=
VITE_SUPABASE_PUBLISHABLE_KEY=
SUPABASE_URL=
SUPABASE_PUBLISHABLE_KEY=
```

Onde pegar os valores, no painel do Supabase → **Project Settings → API**:

- `VITE_SUPABASE_URL` e `SUPABASE_URL` → o **Project URL**;
- `VITE_SUPABASE_PUBLISHABLE_KEY` e `SUPABASE_PUBLISHABLE_KEY` → a chave
  **publishable** (nas versões antigas do painel chama-se **anon public**).

As duas são **públicas**: vão embutidas no bundle e chegam ao navegador. Quem
protege os dados é a RLS, não o segredo da chave.

**Não** coloque aqui a `service_role` / secret key, nem a senha do banco. Elas
não são necessárias para rodar a aplicação. Ver `.env.example`.

---

## 5. Rodar

```bash
bun run dev
```

A aplicação sobe em **http://localhost:8080** (porta fixa — o preset
`@lovable.dev/vite-tanstack-config` usa `strictPort`). Ela já estará falando com
o Supabase remoto.

---

## 6. Entrar no sistema

A sessão **não** é transferida entre computadores: cookies e `localStorage`
ficam no navegador da máquina antiga. No notebook você faz login normalmente,
com o mesmo e-mail e senha de sempre — os usuários vivem no Supabase remoto.

---

## 7. Supabase CLI no notebook (só se for mexer em banco ou funções)

```bash
bunx supabase login                                # abre o navegador
bunx supabase link --project-ref <PROJECT_REF>     # pede a senha do banco
```

O `<PROJECT_REF>` é o identificador do projeto, visível na URL do painel e em
Project Settings → General.

**Nunca** salve a senha do banco nem o access token da CLI dentro do
repositório. O `link` guarda o estado em `supabase/.temp/`, que já é ignorado
pelo Git.

---

## 8. Comandos de validação

```bash
bunx tsc --noEmit                      # tipos
bun run build                          # build de produção
bunx supabase migration list --linked  # migrations locais x remotas
bunx supabase db push --dry-run        # o que ainda falta aplicar
```

Se o `db push --dry-run` disser que o remoto está atualizado, banco e código
estão em sincronia.

`bun run lint` roda, mas o projeto tem uma linha de base grande de avisos de
formatação (`prettier/prettier`) — use só para comparar a contagem, não espere
zero.

---

## 9. O que **não** vai junto

Estes itens vivem só na máquina antiga e **não** são sincronizados:

- login do navegador, cookies e sessão do Supabase;
- rascunhos do `localStorage` (inclusive rascunhos do editor paramétrico que
  não foram salvos com **“Salvar desenho”**);
- preferência de empresa ativa (`vmm_active_company_id:<uid>`);
- banco **local** do Supabase e seus dados (`supabase start` / Docker volumes);
- e-mails capturados no Mailpit local;
- `node_modules/`, `.output/`, caches de build;
- `.env.local` e qualquer `.env`;
- PDFs gerados em testes e dumps temporários.

> **Antes de trocar de máquina:** qualquer desenho paramétrico que você queira
> levar precisa ter sido salvo com **“Salvar desenho”** — o rascunho local
> não atravessa. O mesmo vale para orçamentos: só o que foi salvo existe no
> remoto.

---

## 10. Voltando para a máquina antiga

Nas duas pontas, antes de começar a trabalhar:

```bash
git pull
bun install     # caso o lockfile tenha mudado
```

E ao terminar, commite e faça push antes de trocar de máquina de novo.
