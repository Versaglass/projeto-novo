# Auditoria estática do Supabase — Vidro & Metal Mestre

> **Escopo:** análise 100 % estática de `supabase/migrations/` (49 arquivos, 3.360 linhas, ~183 KB),
> `supabase/config.toml`, `.env.example` e do uso do Supabase em `src/`.
> **Nenhum banco foi conectado, nenhuma migration foi executada, nenhum SQL foi modificado.**
>
> Data da auditoria: 2026-07-21 · Branch: `fix/estabilizacao-base` · Estado: build OK, `tsc --noEmit` 0 erros.

---

## Sumário executivo

| Indicador | Valor |
|---|---|
| Migrations analisadas | 49 |
| Tabelas distintas criadas nas migrations | **87** |
| Tabelas que existem no banco real (via `types.ts`) | **39** |
| Tabelas nas migrations que **não** existem no banco real | **48** |
| Tabelas realmente usadas pelo frontend | **13** |
| Migrations bloqueadoras (erro de SQL) | **6** |
| Migrations com senha em texto puro | **3** |
| Tabelas com RLS ligado e **zero** policies (deny-all) | **10** |
| Policies `USING (true)` sem isolamento de tenant | **~20** |
| Funções `SECURITY DEFINER` | **14** |

**Conclusão antecipada:** o conjunto de 49 migrations **não reproduz o banco atual** e **não roda até o fim em um banco vazio**. A primeira falha ocorre na 24ª migration. A recomendação é **baseline consolidada** (§10.7).

---

# Parte 1 — Inventário das migrations

Legenda de classificação: 🟢 **Segura** · 🟡 **Exige revisão** · 🔴 **Bloqueadora**

### 1. `20260519025716_b6062458….sql` 🟢
- **Objetivo:** schema base do produto.
- **Enums:** `app_role` (admin, vendedor, instalador), `quote_status`.
- **Tabelas criadas:** `profiles`, `user_roles`, `customers`, `quotes`, `quote_items`. Sequência `quote_number_seq`.
- **Funções:** `has_role` (SD), `set_updated_at`, `handle_new_user` (SD).
- **Triggers:** `profiles_updated_at`, `customers_updated_at`, `quotes_updated_at`, `on_auth_user_created` (em `auth.users`).
- **Policies:** 15, todas `TO authenticated` com isolamento por `owner_id`/`auth.uid()` + bypass admin.
- **Dependências:** `auth.users`, `gen_random_uuid()`.

### 2. `20260519025805_c6e49d4e….sql` 🟢
- Endurecimento: `ALTER FUNCTION set_updated_at SET search_path`; `REVOKE EXECUTE` de `has_role` e `handle_new_user` de PUBLIC/anon/authenticated.
- **Depende de:** #1.

### 3. `20260519032738_60bd5fa8….sql` 🟢
- **Enum:** `project_category`. **Tabela:** `project_templates`. **Função:** `seed_default_templates` (SD). **Trigger:** `on_profile_created_seed_templates`.
- **Dados:** 13 templates técnicos por usuário (catálogo técnico, gerado por trigger) + bloco `DO` de backfill.
- **Depende de:** #1.

### 4. `20260519032754_d1d0c6a6….sql` 🟢 — `REVOKE EXECUTE` de `seed_default_templates`.

### 5. `20260519033247_a1b2d0bc….sql` 🟢
- **Enums:** `inventory_category`, `inventory_unit`. **Tabela:** `inventory_items` + 4 policies + trigger + 2 índices.

### 6. `20260519035449_9d0e0ad0….sql` 🟢
- **Altera:** `profiles` (+`ativo`, +`permissions` jsonb). **Função:** `has_permission` (SD). **Policies:** +2 admin em `profiles`.

### 7. `20260519040113_775fe3ad….sql` 🟢
- **Enums:** `sub_status`, `notif_kind`, `notif_status`. **Tabelas:** `subscriptions`, `billing_notifications`.
- **Funções:** `subscription_state`, `generate_billing_notifications` (SD). 8 policies + trigger + índice.

### 8. `20260519040136_985816e0….sql` 🟢 — `subscription_state` recriada com `search_path`; revokes.

### 9. `20260519040202_7317b341….sql` 🟢 — `generate_billing_notifications` recriada com checagem interna de admin; `GRANT EXECUTE TO authenticated`.

### 10. `20260519163949_b9aee416….sql` 🟡
- **Enum:** `auth_event_kind`. **Tabela:** `auth_events` + 2 índices.
- **Policy de risco:** `"auth_events insert public"` `TO anon, authenticated WITH CHECK (true)` — qualquer visitante insere linhas arbitrárias.
- **Realtime:** `ALTER PUBLICATION supabase_realtime ADD TABLE auth_events`.
- *Corrigida depois por #16/#17.*

### 11. `20260519165623_2713001b….sql` 🟢 — **Enum:** `quote_stage`; **altera** `quotes` (+`etapa`, +`instalacao_em`).

### 12. `20260519172529_3996b36e….sql` 🟡
- **Enum:** `server_log_level`. **Tabela:** `server_logs` + 4 policies + 2 índices + realtime.
- **Policy de risco:** `"server_logs insert any auth"` `TO authenticated, anon WITH CHECK (true)`. *Corrigida por #16/#17.*

### 13. `20260519183915_a6230469….sql` 🟡
- `GRANT EXECUTE` de `has_role`/`has_permission` **para `anon`** + `GRANT USAGE ON TYPE app_role TO anon`. *Revertido por #16/#17.*

### 14. `20260520014651_b1711010….sql` 🟢
- Remove o bypass de admin de `quotes`, `quote_items`, `customers`, `inventory_items`, `project_templates` (15 policies recriadas). Endurecimento correto.

### 15. `20260520020447_1e3389a1….sql` 🟡
- **Altera:** `project_templates` (+`tipo`, +`imagem_url`) + índice.
- **Bucket:** `project-images` criado com **`public = true`**.
- **Storage policies:** leitura pública + insert/update/delete por pasta do usuário. *Bucket fechado em #16.*

### 16. `20260601234312_8efd4775….sql` 🟢 (com efeito colateral — ver §8)
- Endurece `auth_events`/`server_logs` (insert self); torna o bucket **privado**; adiciona policy **RESTRICTIVE** em `user_roles`; revoga `has_role` de anon.
- **Remove `auth_events` e `server_logs` da publicação realtime.**

### 17. `20260604153831_1bca2256….sql` 🟢 (com efeito colateral — ver §8)
- Revoga EXECUTE de 4 funções SD; `billing_notifications` INSERT só admin; **`auth_events` e `server_logs` INSERT só admin**.

### 18. `20260621015137_97a76422….sql` 🟡
- `ALTER TABLE inventory_items ADD COLUMN imagem_url text;` — **sem `IF NOT EXISTS`**, não idempotente.

### 19. `20260621021248_5a472aa7….sql` 🟡
- 5 policies amplas em `storage.objects`, incluindo `"Public can read project-images" TO anon`. *Removidas em #20.*

### 20. `20260622131659_c3772735….sql` 🟢 — `DROP` das 5 policies de #19.

### 21. `20260701020000_enterprise_features.sql` 🟡
- **Tabelas:** `audit_logs`, `security_events` (**v1**), `product_categories`, `products`, `product_images`, `ai_templates`. 12 policies + 1 trigger + 4 índices.
- **Conflito futuro:** `security_events` v1 (colunas `level`, `event`, `ip`) colide com a v2 de #41 → causa a falha de #41.

### 22. `20260701021500_complete_platform_modules.sql` 🟡🔴 *(segurança)*
- **Tabelas:** `company_profiles` (**v1**), `enterprise_products`, `glass_catalog`, `hardware_catalog`, `suppliers`, `employees`, `service_orders`, `financial_entries`, `audit_events`, `admin_security_events`.
- **~20 policies `USING (true) WITH CHECK (true)` `TO authenticated`** — qualquer usuário logado lê e escreve dados de **todas as empresas**. O próprio arquivo admite: *"Ajuste por company_id/role antes de produção multi-tenant."*
- **Conflito:** `company_profiles` v1 (`document`, `whatsapp`, `logo_url`, `pix_key`, `plan`, `subscription_status`, `support_status`) ≠ v2 de #31.

### 23. `20260701023000_quote_drawing_editor.sql` 🟢
- **Altera:** `quote_items` (+`drawing_data` jsonb, +`drawing_notes`, +`updated_at`). **Função:** `set_quote_items_updated_at` (**sem `search_path`**). Trigger + índice GIN.

### 24. `20260701030000_budget_reports_finance_docs.sql` 🔴 **BLOQUEADORA**
- **Tabelas pretendidas:** `quote_notes`, `quote_documents`, `fiscal_invoices` (**v1**), `payment_slips`.
- **Erro fatal:** usa **`CREATE POLICY IF NOT EXISTS`** em **16 policies**. Essa sintaxe **não existe no PostgreSQL** → `ERROR: syntax error at or near "NOT"`.
- **É aqui que `supabase db push` para em um banco vazio.**

### 25. `20260701033000_operational_modules.sql` 🔴 *(funcional)*
- **Tabelas:** `works`, `installation_schedule`, `installer_tasks`, `crm_pipeline`, `purchase_orders`, `warranties`, `digital_signatures`, `project_marketplace`, `manufacturers`, `backup_jobs`.
- **`ENABLE ROW LEVEL SECURITY` nas 10 — e NENHUMA policy criada.** Resultado: 10 tabelas **totalmente inacessíveis** (deny-all) para qualquer cliente.

### 26. `20260702070000_aluminum_catalog_and_realistic_projects.sql` 🟡
- **Tabelas:** `aluminum_categories`, `aluminum_profiles`, `editable_project_versions`. 6 policies **sem cláusula `TO`** (→ `PUBLIC`). 3 índices.

### 27. `20260702083000_plan_segment_module_access.sql` 🟢
- **Tabelas:** `platform_plans`, `platform_modules`, `plan_module_access`, `company_module_access`.
- **Dados:** 5 planos + 10 módulos + mapeamentos (catálogo de configuração, idempotente via `ON CONFLICT`).

### 28. `20260703010000_multiuser_tenant_isolation_and_sales_finance.sql` 🟡
- **Tabela:** `company_members`. **Altera:** `customers`, `quotes`, `inventory_items`, `quote_items` (+`company_id`); `inventory_items` (+segment, location, sku, ncm, cest, gtin).
- **Funções:** `is_company_member`, `is_company_admin`, `is_platform_admin` (todas SD) — **criadas sem `REVOKE`**, portanto executáveis por `PUBLIC` até #32.
- 12 policies de tenant recriadas + 5 índices.

### 29. `20260703020000_versaglass_pay_and_fiscal.sql` 🔴 **BLOQUEADORA (latente)**
- **Tabelas:** `payment_accounts`, `charges`, `payment_splits`, `recurring_charges`, `fiscal_settings`, `fiscal_invoices` (**v2**).
- **Views:** `platform_payment_summary`, `platform_fiscal_summary`. **RPCs:** `company_payment_dashboard`, `company_fiscal_dashboard`.
- **Erro (após corrigir #24):** `fiscal_invoices` já existiria com o schema v1 (sem `company_id`) → `create index … fiscal_invoices(company_id)` e as policies `using (is_company_member(company_id, …))` falham com *column "company_id" does not exist*.
- **Regressão:** recria `set_updated_at` **sem `SET search_path`**, apagando o hardening de #2. (Corrigido só em #36.)

### 30. `20260703030000_subscription_locked_library.sql` 🟢
- **Tabelas:** `plans`, `user_subscriptions`, `project_categories`, `project_models`, `plan_model_limits`.
- **Funções:** `get_user_plan`, `can_access_model` (SD). **Dados:** 2 planos + 10 categorias + 17 limites.

### 31. `20260703035847_eee662a9….sql` 🟡 **(divergência silenciosa)**
- `create table if not exists public.company_profiles (…)` com o schema **v2** (`cnpj`, `email`, `address`, `city`, `state`, `segment`).
- Como a v1 (#22) já existe, este bloco vira **no-op silencioso**. O schema final do replay é a **v1** — mas o banco real tem a **v2** (ver §2 e §10.3).

### 32. `20260703040050_5367a5a3….sql` 🟡 **(consolidação/repair — 434 linhas)**
- Reexecuta, com `if not exists` + `GRANT`s explícitos, praticamente tudo de #27 a #30: `platform_*`, `company_members`, `payment_*`, `charges`, `fiscal_*`, `plans`, `user_subscriptions`, `project_*`, `plan_model_limits`.
- Adiciona `REVOKE`/`GRANT` para `is_company_member`, `is_company_admin`, `is_platform_admin`, `get_user_plan`, `can_access_model`, `company_*_dashboard`.
- **Esta é a migration que corresponde ao banco real.** Evidência forte de que #21–#30 nunca foram aplicadas.

### 33. `20260703040107_08a58c89….sql` 🟢 — `security_invoker = true` nas duas views. Correção importante.

### 34. `20260704093000_company_products_catalog.sql` 🟢
- **Tabela:** `company_products` + 4 índices (inclui GIN full-text) + 4 policies de tenant bem construídas.

### 35. `20260704103000_ia_intelligence_admin.sql` 🟡
- **Tabelas:** `ai_intelligence_commands`, `_approvals`, `_logs`, `_snapshots`, `_rollbacks`, `ai_system_settings` (**v1**: colunas `key`/`value`).
- 6 policies admin-only. **Conflito futuro:** a v1 causa a falha de #47.

### 36. `20260704111741_9bf592a0….sql` 🟡
- Endurece `"Profiles update own"` (bloqueia auto-alteração de `permissions`/`ativo`) — **mas recria a policy sem `TO authenticated`** (→ `PUBLIC`).
- Recria `set_updated_at` **com** `SET search_path` (repara a regressão de #29).

### 37. `20260704114000_ia_intelligence_learning_scans.sql` 🔴 **BLOQUEADORA**
- **Tabelas:** `ai_intelligence_knowledge`, `ai_intelligence_scans`, `ai_intelligence_scan_findings`.
- **Erro fatal:** as 3 policies usam `ur.role in ('admin','super_admin')`. `user_roles.role` é do tipo enum `app_role` = `('admin','vendedor','instalador')`. O literal `'super_admin'` **não existe no enum** → `ERROR: invalid input value for enum public.app_role: "super_admin"` na análise da expressão do `CREATE POLICY`.

### 38. `20260704122000_ia_intelligence_manager_creative.sql` 🟡
- **Tabelas:** `ai_agents`, `ai_agent_versions`, `ai_guided_workflows`, `project_media_changes`. 4 policies **sem `TO`** (→ `PUBLIC`).

### 39. `20260704133000_ia_integrations_manager.sql` 🔴 **BLOQUEADORA**
- **Tabelas:** `integration_connections`, `integration_sync_jobs`, `integration_diagnostics`, `integration_repair_jobs`, `integration_event_logs`.
- **Mesmo erro de #37:** `ur.role in ('admin','super_admin')` em **5 policies**.

### 40. `20260705023016_8ba280bd….sql` 🟡
- **Conteúdo integral:** `-- Ver /tmp/final_mig.sql`. Migration **vazia**, apontando para um arquivo temporário inexistente. Indica uma migration perdida no histórico.

### 41. `20260705034629_32292d7b….sql` 🔴 **BLOQUEADORA**
- **Tabelas:** `password_reset_tokens`, `two_factor_codes`, `security_events` (**v2** — no-op, v1 já existe de #21), `security_lockouts`. Policies criadas de forma idempotente e correta (via `pg_policies`).
- **Erro fatal:** `create index … on public.security_events(flow, created_at desc)` — a coluna `flow` só existe na v2, que virou no-op → *column "flow" does not exist*.

### 42. `20260705124632_6760b27b….sql` 🟢
- **Função:** `is_company_owner` (SD). Substitui a policy genérica de `company_members` por INSERT/UPDATE/DELETE granulares que impedem escalonamento para `owner`. Boa prática.

### 43. `20260705130718_03718d01….sql` 🔴 **BLOQUEADORA DE SEGURANÇA**
- `UPDATE auth.users SET encrypted_password = crypt('<REDIGIDO>', gen_salt('bf')) … WHERE email = '<e-mail corporativo>'`.
- **Senha em texto puro versionada no Git.** Ver §10.2.

### 44. `20260705133650_e388a0d8….sql` 🔴 **BLOQUEADORA DE SEGURANÇA** — idêntica a #43 com outra senha (variante acentuada).

### 45. `20260705150358_1f7c7f6a….sql` 🟢
- **Tabelas:** `ai_dialog_sessions`, `ai_dialog_messages`, `ai_dialog_suggestions`, `ai_dialog_action_previews`, `ai_dialog_executions` + GRANTs + 5 policies admin + 2 triggers.
- Usa `CREATE TABLE` **sem** `IF NOT EXISTS` (não idempotente, mas correto em banco vazio).

### 46. `20260705153015_ec153b1f….sql` 🟡
- `profiles` +`segment` (com `CHECK`). **`ADD CONSTRAINT profiles_segment_check` sem `IF NOT EXISTS`** → não idempotente.
- Recria `handle_new_user` para persistir `segment` do metadata de signup.

### 47. `20260705172639_9629f6f1….sql` 🔴 **BLOQUEADORA**
- `ai_system_settings` **v2** (`setting_key`/`setting_value`/`category`) via `IF NOT EXISTS` → **no-op** (v1 de #35 já existe).
- **Erro fatal:** `CREATE INDEX … ON public.ai_system_settings(setting_key)` — a v1 tem a coluna `key`, não `setting_key` → *column "setting_key" does not exist*.
- Também cria `ai_generated_code` (correta).

### 48. `20260708231226_8b66b62d….sql` 🟢 — `REVOKE EXECUTE ON is_company_owner FROM PUBLIC, anon`.

### 49. `20260714200012_ca36abac….sql` 🔴 **BLOQUEADORA DE SEGURANÇA** — terceira redefinição de senha em texto puro do mesmo e-mail.

---

# Parte 2 — Ciclo de vida dos objetos

## 2.1 Objetos criados mais de uma vez

| Objeto | Criações | Schema vencedor no *replay* | Schema no banco **real** | Consequência |
|---|---|---|---|---|
| `company_profiles` | #22 (v1), #31 (v2) | **v1** (`document`, `whatsapp`, `logo_url`, `pix_key`, `plan`, `subscription_status`, `support_status`) | **v2** (`cnpj`, `email`, `address`, `city`, `state`, `segment`) | Divergência silenciosa total |
| `fiscal_invoices` | #24 (v1), #29 (v2), #32 (v2) | **v1** (`owner_id`, `numero`, `cliente`, `valor`) | **v2** (`company_id`, `invoice_type`, `access_key`) | Falha de índice/policy em #29 |
| `security_events` | #21 (v1), #41 (v2) | **v1** (`level`, `event`, `ip`) | **v2** (`flow`, `action`, `success`, `ip_address`) | **Falha de índice em #41** |
| `ai_system_settings` | #35 (v1 `key`/`value`), #47 (v2 `setting_key`) | **v1** | **v2** | **Falha de índice em #47** |
| `platform_plans`, `platform_modules`, `plan_module_access`, `company_module_access` | #27, #32 | idênticos | ok | Apenas redundância |
| `company_members` | #28, #32 | idênticos | ok | Redundância |
| `charges`, `payment_accounts`, `payment_splits`, `recurring_charges`, `fiscal_settings` | #29, #32 | idênticos | ok | Redundância |
| `plans`, `user_subscriptions`, `project_categories`, `project_models`, `plan_model_limits` | #30, #32 | idênticos | ok | Redundância |

> **Padrão perigoso:** todos usam `CREATE TABLE IF NOT EXISTS`. Quando dois arquivos declaram schemas diferentes para o mesmo nome, **o segundo vira no-op silencioso** — sem erro, sem aviso. Índices e policies criados logo depois é que estouram.

## 2.2 DROP seguido de recriação (policies)

| Policy / objeto | Criada | Removida | Recriada | Estado final |
|---|---|---|---|---|
| `Quotes select/update/delete` | #1 | #14 | #14 (sem bypass admin) | #28 recria como `*_tenant` |
| `Items select/update/delete` | #1 | #14 | #14 | mantida |
| `Customers select/update/delete` | #1 | #14, #28 | #28 (`*_tenant`) | tenant |
| `Inventory select/update/delete` | #5 | #14, #28 | #28 (`*_tenant`) | tenant |
| `Templates select/update/delete` | #3 | #14 | #14 | owner-only |
| `auth_events insert *` | #10 (`anon`, true) | #16 | #16 (self) → #17 (admin) | **admin-only** |
| `server_logs insert *` | #12 (`anon`, true) | #16 | #16 (self) → #17 (admin) | **admin-only** |
| `project-images public read` | #15 | #16 | #16 (`owner select`) | privado por pasta |
| storage policies amplas | #19 | #20 | — | removidas |
| `Notif insert admin or self` | #7 | #17 | #17 (`admin only`) | admin-only |
| `Profiles update own` | #1 | #36 | #36 (sem `TO`) | `PUBLIC` + guarda de colunas |
| `Company members company admin manage` | #28, #32 | #42 | #42 (3 policies granulares) | granular |

## 2.3 Funções substituídas

| Função | Versões | Observação |
|---|---|---|
| `set_updated_at` | #1 → #2 (`ALTER SET search_path`) → **#29 (recria SEM search_path)** → #36 (recria COM) | Regressão de segurança entre #29 e #36 |
| `handle_new_user` | #1 → #46 (persiste `segment`) | Compatível |
| `subscription_state` | #7 → #8 (+`search_path`) | Compatível |
| `generate_billing_notifications` | #7 → #9 (+ checagem de admin) | Compatível, mais restritiva |
| `is_company_member` / `is_company_admin` / `is_platform_admin` | #28 → #32 (idênticas + GRANT/REVOKE) | Compatível |
| `get_user_plan` / `can_access_model` | #30 → #32 | Compatível |
| `company_payment_dashboard` / `company_fiscal_dashboard` | #29 → #32 | Compatível |

**Nenhuma substituição incompatível de assinatura foi encontrada.** O único problema real é a perda de `search_path` em `set_updated_at`.

## 2.4 Enums e tipos

| Enum | Migration | Recriado? | Estado final |
|---|---|---|---|
| `app_role` | #1 | não | `admin, vendedor, instalador` — **não contém `super_admin`** (causa #37 e #39) |
| `quote_status` | #1 | não | ok |
| `project_category` | #3 | não | ok |
| `inventory_category`, `inventory_unit` | #5 | não | ok |
| `sub_status`, `notif_kind`, `notif_status` | #7 | não | ok |
| `auth_event_kind` | #10 (`DO`/`duplicate_object`) | não | ok, idempotente |
| `quote_stage` | #11 | não | ok |
| `server_log_level` | #12 (`DO`/`duplicate_object`) | não | ok, idempotente |

> `#1`, `#3`, `#5`, `#7`, `#11` usam `CREATE TYPE` puro — **não idempotentes** em re-execução.

## 2.5 Referências a objetos antes da criação / riscos de ordem

| Risco | Detalhe |
|---|---|
| ✅ Sem referência antecipada | `company_profiles` é criado em #22, antes de todos os `references public.company_profiles` (#27, #28, #29, #32, #34) |
| ⚠️ `set_updated_at` | Usada como `EXECUTE FUNCTION` em #21, #23, #29, #45, #47 — sempre após #1. OK |
| ⚠️ `has_role` | Usada em policies desde #1 e em #35/#37/#39. OK |
| ⚠️ `is_company_member` | Usada em #29 e #34; criada em #28. OK |
| ⚠️ `is_company_owner` | Usada em #42; criada no mesmo arquivo. OK |
| 🔴 `pgcrypto` | #43/#44/#49 chamam `crypt()`/`gen_salt()` sem qualificar schema. No Supabase a extensão vive em `extensions`; depende do `search_path` da sessão de migration. **Risco de `function crypt(...) does not exist`** |
| 🔴 Ordem `IF NOT EXISTS` | Ver §2.1 — 4 tabelas com schema divergente resolvido silenciosamente pela primeira declaração |

---

# Parte 3 — Matriz de segurança e RLS

## 3.1 Tabelas do núcleo (bem isoladas) 🟢

| Tabela | RLS | SELECT | INSERT | UPDATE | DELETE | Papéis | Isolamento |
|---|---|---|---|---|---|---|---|
| `profiles` | ✅ | own + admin | own | own (com guarda de `permissions`/`ativo`) + admin | — | `authenticated` / `PUBLIC`¹ | `id = auth.uid()` |
| `user_roles` | ✅ | own + admin | admin | admin | admin | `authenticated` | `user_id` + policy **RESTRICTIVE** |
| `customers` | ✅ | owner ∪ membro da empresa | idem | owner ∪ admin da empresa | idem | `authenticated` | `owner_id` + `company_id` |
| `quotes` | ✅ | idem | idem | idem | idem | `authenticated` | `owner_id` + `company_id` |
| `quote_items` | ✅ | via `EXISTS` em `quotes` | idem | idem | idem | `authenticated` | herdado de `quotes` |
| `inventory_items` | ✅ | owner ∪ membro | idem | owner ∪ admin | idem | `authenticated` | `owner_id` + `company_id` |
| `project_templates` | ✅ | owner | owner | owner | owner | `authenticated` | `owner_id` |
| `subscriptions` | ✅ | own + admin | admin | admin | admin | `authenticated` | `user_id` |
| `billing_notifications` | ✅ | own + admin | **admin** | own + admin | admin | `authenticated` | `user_id` |
| `auth_events` | ✅ | admin | **admin** | admin | admin | `authenticated` | — (tabela administrativa) |
| `server_logs` | ✅ | admin | **admin** | admin | admin | `authenticated` | — (tabela administrativa) |
| `company_members` | ✅ | membro ∪ platform admin | admin da empresa (não pode criar `owner`) | idem | idem | `authenticated` | `company_id` |
| `company_products` | ✅ | owner ∪ membro | idem | owner ∪ admin | idem | `authenticated` | `owner_id` + `company_id` |
| `charges`, `recurring_charges`, `fiscal_invoices`(v2) | ✅ | membro da empresa | membro | admin da empresa | admin | `authenticated` | `company_id` |
| `payment_accounts`, `payment_splits`, `fiscal_settings` | ✅ | membro ∪ platform admin | — | admin da empresa | admin | `authenticated` | `company_id` |
| `user_subscriptions` | ✅ | own ∪ admin empresa ∪ platform admin | platform admin | idem | idem | `authenticated` | `user_id` |
| `ai_dialog_*` (5) | ✅ | admin | admin | admin | admin | `authenticated` | — |
| `ai_generated_code` | ✅ | owner ∪ admin | idem | idem | idem | `authenticated` | `user_id` |
| `ai_intelligence_*` (6, #35) | ✅ | admin | admin | admin | admin | `authenticated` | — |
| `password_reset_tokens`, `two_factor_codes`, `security_lockouts` | ✅ | own (`SELECT` apenas) | ❌ nenhuma | ❌ | ❌ | `authenticated` | `user_id` |

¹ `Profiles update own` perdeu o `TO authenticated` em #36 — ver §3.3.

## 3.2 🔴 Tabelas SEM isolamento de tenant — `USING (true)`

Migration #22 (`20260701021500_complete_platform_modules.sql`):

| Tabela | SELECT | ALL (INSERT/UPDATE/DELETE) | Avaliação |
|---|---|---|---|
| `company_profiles` | `using (true)` | `using (true) with check (true)` | 🔴 **Insegura** |
| `enterprise_products` | `using (true)` | `using (true) with check (true)` | 🔴 **Insegura** |
| `glass_catalog` | `using (true)` | `using (true) with check (true)` | 🔴 **Insegura** |
| `hardware_catalog` | `using (true)` | `using (true) with check (true)` | 🔴 **Insegura** |
| `suppliers` | `using (true)` | `using (true) with check (true)` | 🔴 **Insegura** |
| `employees` | `using (true)` | `using (true) with check (true)` | 🔴 **Insegura** — expõe salários/comissões/e-mails |
| `service_orders` | `using (true)` | `using (true) with check (true)` | 🔴 **Insegura** |
| `financial_entries` | `using (true)` | `using (true) with check (true)` | 🔴 **Insegura** — expõe financeiro de todas as empresas |
| `audit_events` | `using (true)` | INSERT `with check (true)` | 🔴 **Insegura** — auditoria falsificável |
| `admin_security_events` | `using (true)` | INSERT `with check (true)` | 🔴 **Insegura** |

**Classificação:** *temporária e assumida pelo autor* (o comentário no arquivo admite a pendência), mas **inaceitável em produção multiempresa**. Como `company_profiles` também recebe `ALL using(true)`, um assinante pode **reescrever o cadastro de qualquer empresa**.

> Atenuante: essas 10 tabelas **não existem no banco real** e **não são usadas pelo frontend**. O risco só se materializa se a migration #22 for aplicada.

## 3.3 Policies `USING (true)` — classificação individual

| Policy | Tabela | Avaliação |
|---|---|---|
| `Plan module read` | `plan_module_access` | 🟢 **Pública e intencional** — catálogo de planos, `TO authenticated`, sem dado sensível |
| `Plan model limits read` | `plan_model_limits` | 🟢 **Pública e intencional** — mesma natureza |
| `authenticated read/manage *` (20 policies) | 10 tabelas de #22 | 🔴 **Insegura** — ver §3.2 |
| `auth_events insert public` | `auth_events` | 🟡 **Substituída** por #16 e #17 |
| `server_logs insert any auth` | `server_logs` | 🟡 **Substituída** por #16 e #17 |
| `authenticated insert security events` | `security_events` | 🟡 **Parcial** — `with check (auth.uid() = user_id or user_id is null)`; o ramo `user_id is null` permite inserir log anônimo. Aceitável para telemetria, mas permite poluição |

## 3.4 Policies `TO anon` (todas revertidas)

| Policy | Migration | Revertida em | Estado final |
|---|---|---|---|
| `auth_events insert public` | #10 | #16 | ✅ removida |
| `server_logs insert any auth` | #12 | #16 | ✅ removida |
| `Public can read project-images` | #19 | #20 | ✅ removida |
| `GRANT EXECUTE has_role/has_permission TO anon` | #13 | #16, #17 | ✅ revogado |
| `GRANT USAGE ON TYPE app_role TO anon` | #13 | — | ⚠️ **nunca revogado** (baixo risco — apenas usar o tipo) |

## 3.5 Policies sem cláusula `TO` (→ `PUBLIC`, inclui `anon`)

| Migration | Qtd | Tabelas | Risco real |
|---|---|---|---|
| #26 | 6 | `aluminum_categories`, `aluminum_profiles`, `editable_project_versions` | 🟡 Baixo — condição `auth.uid() = owner_id` nunca casa para `anon` |
| #36 | 1 | `profiles` (`update own`) | 🟡 Baixo — condição exige `auth.uid() = id` |
| #37 | 3 | `ai_intelligence_knowledge/scans/scan_findings` | 🟡 Baixo (migration não aplica) |
| #38 | 4 | `ai_agents`, `ai_agent_versions`, `ai_guided_workflows`, `project_media_changes` | 🟡 Baixo |
| #39 | 5 | `integration_*` | 🟡 Baixo (migration não aplica) |

**Total: 19 policies sem `TO`.** Nenhuma abre acesso efetivo (todas exigem `auth.uid()`), mas todas deveriam declarar `TO authenticated` por higiene e para evitar avaliação desnecessária no papel `anon`.

## 3.6 🔴 Tabelas com RLS ligado e ZERO policies (deny-all total)

Migration #25 — `works`, `installation_schedule`, `installer_tasks`, `crm_pipeline`, `purchase_orders`, `warranties`, `digital_signatures`, `project_marketplace`, `manufacturers`, `backup_jobs`.

Efeito: **nenhum cliente (nem `authenticated`, nem `anon`) consegue ler ou escrever**. Só `service_role` acessa. Se algum módulo do produto depender delas, ele simplesmente não funciona — silenciosamente.

---

# Parte 4 — Funções `SECURITY DEFINER`

| # | Função | Migration | `search_path` | EXECUTE concedido a | Recebe ID do usuário? | Escalonamento | Deveria ser INVOKER? | Risco |
|---|---|---|---|---|---|---|---|---|
| 1 | `has_role(uuid, app_role)` | #1 | ✅ `public` | `authenticated`, `service_role` | ✅ `_user_id` livre | Não (só lê) | Não — precisa de DEFINER p/ RLS | 🟢 Baixo¹ |
| 2 | `handle_new_user()` | #1, #46 | ✅ `public` | **revogado de todos** | trigger | Não | Não | 🟢 Baixo |
| 3 | `seed_default_templates()` | #3 | ✅ `public` | **revogado de todos** | trigger | Não | Não | 🟢 Baixo |
| 4 | `has_permission(uuid, text)` | #6 | ✅ `public` | `authenticated`, `service_role` | ✅ `_user_id` livre | Não | Não | 🟢 Baixo¹ |
| 5 | `generate_billing_notifications()` | #7, #9 | ✅ `public` | `authenticated`, `service_role` | não | **Não** — checa `has_role(...,'admin')` internamente e faz `RAISE EXCEPTION` | Não | 🟢 Baixo |
| 6 | `is_company_member(uuid, uuid)` | #28, #32 | ✅ `public` | `authenticated`, `service_role` (revogado de PUBLIC/anon **só em #32**) | ✅ `_user_id` com default `auth.uid()` | ⚠️ pode consultar pertencimento de terceiros | Não | 🟡 Médio¹ |
| 7 | `is_company_admin(uuid, uuid)` | #28, #32 | ✅ `public` | idem | ✅ | idem | Não | 🟡 Médio¹ |
| 8 | `is_platform_admin(uuid)` | #28, #32 | ✅ `public` | idem | ✅ | idem | Não | 🟡 Médio¹ |
| 9 | `is_company_owner(uuid, uuid)` | #42 | ✅ `public` | revogado de PUBLIC/anon **só em #48** | ✅ | idem | Não | 🟡 Médio |
| 10 | `get_user_plan(uuid)` | #30, #32 | ✅ `public` | `authenticated`, `service_role` | ✅ `_user_id` livre | Não | **Sim** — poderia usar `auth.uid()` internamente | 🟡 Médio² |
| 11 | `can_access_model(text,text,int,bool)` | #30, #32 | ✅ `public` | `authenticated`, `service_role` | não (só lê tabela pública) | Não | **Sim** | 🟢 Baixo |
| 12 | `company_payment_dashboard(uuid)` | #29, #32 | ✅ `public` | `authenticated`, `service_role` | ✅ `_company_id` | **Não** — `WHERE … AND is_company_member(_company_id, auth.uid())` | **Sim** — RLS de `charges` já isola | 🟢 Baixo |
| 13 | `company_fiscal_dashboard(uuid)` | #29, #32 | ✅ `public` | `authenticated`, `service_role` | ✅ | **Não** — mesma guarda | **Sim** | 🟢 Baixo |
| 14 | `subscription_state(date, sub_status)` | #7, #8 | ✅ `public` | revogado de `anon` | não | Não | (não é DEFINER) | 🟢 Baixo |

¹ **Vazamento de informação de baixo impacto:** funções que aceitam `_user_id`/`_company_id` arbitrário permitem que um usuário autenticado descubra se *outro* usuário é admin ou membro de uma empresa. Não permite escrita nem leitura de dados. Mitigação recomendada: ignorar o parâmetro e usar `auth.uid()`, ou adicionar `IF _user_id <> auth.uid() AND NOT is_platform_admin() THEN RAISE EXCEPTION`.

² `get_user_plan(_user_id)` permite descobrir o plano de qualquer usuário. Mesmo tratamento.

## 4.1 ✅ Nenhuma função `SECURITY DEFINER` está sem `SET search_path`

Todas as 13 funções DEFINER declaram `SET search_path = public` (ou `TO 'public'`). Este é o ponto mais forte do schema.

## 4.2 ⚠️ Funções **não**-DEFINER sem `search_path`

| Função | Migration | Situação |
|---|---|---|
| `set_updated_at()` | #29 recria **sem** `search_path` | **Reparado em #36** — mas ficou vulnerável entre as duas |
| `set_quote_items_updated_at()` | #23 | ❌ **Nunca recebeu `search_path`** — trigger de `quote_items` |

Ambas são `SECURITY INVOKER` (padrão), então o impacto é limitado; ainda assim, Supabase/`supabase db lint` sinaliza `function_search_path_mutable`.

## 4.3 Views

| View | Migration | `security_invoker` | GRANT | Avaliação |
|---|---|---|---|---|
| `platform_payment_summary` | #29, #32 | ✅ ligado em **#33** | `SELECT` → `authenticated` | 🟢 Correto — RLS das tabelas base se aplica |
| `platform_fiscal_summary` | #29, #32 | ✅ ligado em **#33** | `SELECT` → `authenticated` | 🟢 Correto |

> Sem #33, essas views seriam `SECURITY DEFINER` implícitas — vazariam agregados de **todas** as empresas para qualquer autenticado. A correção está presente e na ordem certa.

---

# Parte 5 — Auth e usuários

## 5.1 Referências a `auth.users`

| Tipo | Onde |
|---|---|
| **Trigger** | `on_auth_user_created` `AFTER INSERT ON auth.users` (#1) |
| **FK `ON DELETE CASCADE`** | `profiles.id`, `user_roles.user_id`, `customers.owner_id`, `quotes.owner_id`, `products.owner_id`, `product_categories.owner_id`, `ai_templates.owner_id`, `company_profiles.user_id`, `company_members.user_id`, `user_subscriptions.user_id`, `password_reset_tokens.user_id`, `two_factor_codes.user_id`, `security_lockouts.user_id`, `ai_dialog_sessions.user_id`, `ai_dialog_executions.executed_by`, `aluminum_*.owner_id`, `company_products.owner_id`, `editable_project_versions.owner_id` |
| **FK `ON DELETE SET NULL`** | `audit_logs.actor_id`, `security_events.user_id`, `employees.user_id`, `works.user_id`, e ~25 outras em tabelas operacionais/IA |
| **`UPDATE` direto** | **#43, #44, #49** — alteram `encrypted_password` e `email_confirmed_at` 🔴 |

## 5.2 Fluxo de criação de usuário

```
auth.users INSERT
   └─► on_auth_user_created  → handle_new_user()            [SECURITY DEFINER]
          ├─ INSERT profiles (id, nome, empresa, segment)
          └─ INSERT user_roles (role = 'admin' se for o 1º usuário, senão 'vendedor')
                 └─► on_profile_created_seed_templates → seed_default_templates()
                        └─ INSERT 13 project_templates do usuário
```

- **Perfil automático:** ✅ `public.profiles` (PK = `auth.users.id`).
- **Primeiro acesso:** o **primeiro usuário do banco vira `admin`** (`WHERE (SELECT COUNT(*) FROM user_roles) = 0`). Em banco novo e vazio, **quem se cadastrar primeiro assume o controle da plataforma** — ver §10.9.
- **`segment`** vem de `raw_user_meta_data->>'segment'`, com fallback `'complete'` (#46).

## 5.3 Papéis e funções de autorização

| Camada | Objeto | Valores |
|---|---|---|
| Plataforma | enum `app_role` | `admin`, `vendedor`, `instalador` |
| Plataforma | `user_roles` (+ policy RESTRICTIVE) | 1 linha por (user, role) |
| Plataforma | `profiles.permissions` jsonb | 7 flags granulares |
| Empresa | `company_members.role` (`text` + CHECK) | `owner`, `admin`, `manager`, `operator`, `installer`, `seller` |
| Empresa | `company_profiles.user_id` | dono implícito |

**Funções:** `has_role`, `has_permission`, `is_platform_admin`, `is_company_member`, `is_company_admin`, `is_company_owner`.

🔴 **Inconsistência crítica:** `'super_admin'` é usado em 8 policies (#37, #39) mas **não existe no enum `app_role`** — é a causa direta de duas migrations bloqueadoras. Também existe uma terceira taxonomia (`company_members.role` como `text`), sem relação com o enum.

## 5.4 Multiempresa (`company_id` × `user_id`)

- `company_id` foi **adicionado depois** (#28) a `customers`, `quotes`, `quote_items`, `inventory_items` — como coluna **nullable, sem backfill**.
- As policies de tenant usam `owner_id = auth.uid() OR (company_id IS NOT NULL AND is_company_member(company_id, auth.uid()))` — o ramo `owner_id` mantém compatibilidade com dados legados. Correto.
- 🟡 **Porém:** nenhuma migration força `company_id NOT NULL` nem popula a coluna. O modelo multiempresa está **estruturalmente pronto e operacionalmente inativo**.
- 🟡 O frontend **nunca envia `company_id`** (nenhuma das 13 tabelas usadas o preenche) — o isolamento efetivo hoje é 100 % por `owner_id`.

## 5.5 IDs fixos, e-mails e dados de usuário

| Item | Onde | Avaliação |
|---|---|---|
| E-mail corporativo `versartilvidrosltda@gmail.com` | #43, #44, #49 | 🔴 Usuário fixo em migration |
| Senhas em texto puro (3 valores distintos) | #43, #44, #49 | 🔴 **Credenciais versionadas** |
| UUIDs fixos | — | ✅ **Nenhum** encontrado |
| IDs textuais fixos | `platform_plans.id`, `platform_modules.id`, `plans.slug`, `project_categories.slug`, `plan_model_limits` | 🟢 Chaves naturais de catálogo, legítimas |
| Telefones / URLs de projeto | — | ✅ Nenhum |

**Inserts que dependem de usuário inexistente:** os três `UPDATE auth.users` (#43/#44/#49) usam `WHERE email = …`. Em banco vazio afetam **0 linhas** — não falham, mas também não fazem nada. São ruído perigoso.

---

# Parte 6 — Storage

## 6.1 Buckets

| Bucket | Criado em | `public` inicial | `public` final | Estado |
|---|---|---|---|---|
| `project-images` | #15 (`INSERT INTO storage.buckets … ON CONFLICT DO NOTHING`) | `true` | **`false`** (#16) | 🟢 Privado |

**É o único bucket criado nas migrations.**

## 6.2 Policies sobre `storage.objects`

| Policy | Migration | Operação | Papel | Condição | Estado final |
|---|---|---|---|---|---|
| `project-images public read` | #15 | SELECT | (sem `TO`) | `bucket_id = 'project-images'` | ❌ removida em #16 |
| `project-images owner insert` | #15 | INSERT | `authenticated` | `bucket_id` + `auth.uid()::text = (storage.foldername(name))[1]` | ✅ **ativa** |
| `project-images owner update` | #15 | UPDATE | `authenticated` | idem | ✅ **ativa** |
| `project-images owner delete` | #15 | DELETE | `authenticated` | idem | ✅ **ativa** |
| `project-images owner select` | #16 | SELECT | `authenticated` | idem | ✅ **ativa** |
| 5 policies amplas (inclui `TO anon`) | #19 | todas | `anon`/`authenticated` | só `bucket_id` | ❌ removidas em #20 |

**Estado final: 4 policies, todas exigindo que o primeiro segmento do path seja o UUID do usuário.**

## 6.3 Paths e uso no frontend

| Arquivo | Operação | Path | Compatível com a policy? |
|---|---|---|---|
| `src/routes/_authenticated/app.orcamentos.novo.tsx:545` | `.upload()` | `` `${u.user.id}/${crypto.randomUUID()}.${ext}` `` | ✅ **Sim** |
| `src/components/StorageImage.tsx:30` | `.createSignedUrl(path, 7d)` | path salvo em `imagem_url` | ✅ **Sim** |

🟢 O modelo é coerente: upload em pasta própria, leitura por **URL assinada** (não por URL pública). Consistente com o bucket privado.

⚠️ **Verificar:** `app.estoque.tsx` também grava `inventory_items.imagem_url`. A policy `"Authenticated can upload estoque images"` (#19), que permitia upload **fora** da pasta do usuário, foi removida em #20. Se a tela de estoque não usar o prefixo `${user.id}/`, o upload passará a falhar. **Não confirmado nesta auditoria** (arquivo sob `@ts-nocheck`).

## 6.4 Restrições de upload

❌ **Nenhuma.** O `INSERT INTO storage.buckets` não define `file_size_limit` nem `allowed_mime_types`. Qualquer arquivo de qualquer tamanho/tipo é aceito.

## 6.5 Buckets referenciados no código mas não criados

✅ **Nenhum.** O código referencia apenas `project-images`.

## 6.6 Buckets criados e não utilizados

✅ **Nenhum.**

---

# Parte 7 — Dados iniciais e demonstrativos

| Migration | INSERT | Classificação | Manter em migration? |
|---|---|---|---|
| #27, #32 | `platform_plans` — 5 planos por segmento | **Configuração obrigatória** | ✅ Sim (idempotente via `ON CONFLICT`) |
| #27, #32 | `platform_modules` — 10 módulos com rotas | **Configuração obrigatória** | ✅ Sim |
| #27, #32 | `plan_module_access` — mapeamento plano↔módulo | **Configuração obrigatória** | ✅ Sim |
| #30, #32 | `plans` — PRO R$ 149,90 / PREMIUM R$ 299,90 | **Plano de assinatura** | ⚠️ **Mover para seed** — preço é dado de negócio, muda sem deploy |
| #30, #32 | `project_categories` — 10 categorias | **Catálogo técnico** | ✅ Sim |
| #30, #32 | `plan_model_limits` — 17 limites por plano/categoria | **Plano de assinatura** | ⚠️ **Mover para seed** |
| #3 | 13 `project_templates` por usuário (via trigger + backfill) | **Catálogo técnico / seed por usuário** | 🟡 Aceitável, mas é lógica de produto dentro de trigger `SECURITY DEFINER` |
| #15 | `storage.buckets` (`project-images`) | **Configuração obrigatória** | ✅ Sim |
| **#43, #44, #49** | **`UPDATE auth.users` — senha em texto puro** | 🔴 **NÃO deveria existir em migration** | ❌ **Remover** |

## 7.1 Valores fixos encontrados

| Tipo | Valor | Onde | Avaliação |
|---|---|---|---|
| **Project ref** | `iitgmvdpylwbqipixtah` | `supabase/config.toml` | ✅ **Resolvido em 2026-07-21** — substituído pelo identificador local `vidro-metal-mestre`. O projeto antigo foi descartado |
| **E-mail** | `versartilvidrosltda@gmail.com` | #43, #44, #49 | 🔴 Usuário fixo |
| **Senhas** | 3 valores distintos, em claro | #43, #44, #49 | 🔴 **Credenciais expostas no Git** |
| **Preços** | `149.90`, `299.90` | #30, #32 | 🟡 Dado de negócio em DDL |
| **NCM padrão** | `7604.29.20` | #26 (`aluminum_profiles`) | 🟢 Default técnico legítimo |
| **GTIN padrão** | `SEM GTIN` | #26 | 🟢 Placeholder legítimo |
| **Rotas** | `/app/vidros`, `/app/aluminios`, `/app/ferragens`, `/app/projetos`, `/app/estoque` | #27, #32 | 🟡 Acopla o banco ao roteamento do frontend |
| **UUIDs fixos** | — | — | ✅ Nenhum |
| **URLs externas** | — | — | ✅ Nenhuma |
| **Telefones** | — | — | ✅ Nenhum |

✅ **Não há dados demonstrativos/fake** (clientes, orçamentos, produtos de exemplo) nas migrations. O único "seed de demonstração" é o catálogo de 13 templates por usuário, que é legítimo.

---

# Parte 8 — Integração com o frontend

## 8.1 Matriz de recursos

| Recurso do banco | Arquivos que utilizam | Operações | Está nas migrations? | Tipado em `types.ts`? |
|---|---|---|---|---|
| `customers` | `app.clientes.$id`, `app.clientes`, `app.orcamentos.$id`, `app.orcamentos.ambientes`, `app.orcamentos.novo`, `app.orcamentos.obra`, `app.orcamentos`, `app.projetos` | select, insert, update, delete | ✅ #1 | ✅ |
| `quotes` | `app.clientes.$id`, `app.orcamentos.$id`, `app.orcamentos.novo`, `app.orcamentos` | select, insert, update, delete | ✅ #1 | ✅ |
| `quote_items` | `ProjectDrawingEditor`, `app.orcamentos.$id`, `app.orcamentos.novo` | select, insert, update, delete | ✅ #1 | ✅ |
| `project_templates` | `ParametricProjectEditor`, `app.orcamentos.novo`, `app.projetos` | select, insert, update, delete | ✅ #3 | ✅ |
| `profiles` | `use-auth`, `app.admin.assinaturas`, `app.admin.usuarios`, `app.conta`, `app.orcamentos.$id` | select, update | ✅ #1 | ✅ |
| `user_roles` | `use-auth`, `admin-guard`, `app.admin.usuarios` | select, insert, delete | ✅ #1 | ✅ |
| `inventory_items` | `app.estoque`, `app.orcamentos.novo` | select, insert, update, delete | ✅ #5 | ✅ |
| `subscriptions` | `app.admin.assinaturas`, `app.minha-assinatura` | select, insert, update | ✅ #7 | ✅ |
| `billing_notifications` | `app.admin.assinaturas`, `app.minha-assinatura` | select, update | ✅ #7 | ✅ |
| `auth_events` | `NotificationsBell`, `log-event`, `app.admin.notificacoes` | select, **insert**, update | ✅ #10 | ✅ |
| `server_logs` | `server-log`, `app.admin.logs` | select, **insert**, delete | ✅ #12 | ✅ |
| `user_subscriptions` | `modules/subscriptions/accessControl` | select | ✅ #30 | ✅ |
| `audit_logs` | `app.admin.auditoria` | select | ✅ #21 | ❌ **NÃO** — acessada via `(supabase as any)` |
| **RPC** `generate_billing_notifications` | `app.admin.assinaturas`, `app.minha-assinatura` | rpc | ✅ #7/#9 | ✅ |
| **RPC** `has_role` | `admin-bootstrap.functions` | rpc | ✅ #1 | ✅ |
| **Storage** `project-images` | `StorageImage`, `app.orcamentos.novo` | upload, createSignedUrl | ✅ #15 | n/a |
| **Realtime** `auth_events` | `NotificationsBell`, `app.admin.notificacoes` | channel/postgres_changes | ⚠️ **removida da publicação em #16** | n/a |
| **Realtime** `server_logs` | `app.admin.logs` | channel/postgres_changes | ⚠️ **removida da publicação em #16** | n/a |
| **Auth** | 12 métodos distintos (`getUser` ×13, `getSession` ×6, `updateUser` ×4, `onAuthStateChange` ×4, `verifyOtp`, `signInWithPassword`, `signInWithOtp`, `signUp`, `signOut`, `setSession`, `resetPasswordForEmail`, `getClaims`) | — | n/a | n/a |

## 8.2 🔴 Tabelas usadas no código que **não existem** no schema

✅ **Nenhuma.** Todas as 13 tabelas consultadas existem em alguma migration.

## 8.3 🟡 Tabelas criadas nas migrations e **não usadas** pelo frontend

**74 de 87 tabelas (85 %) nunca são consultadas pelo código.** Grupos:

- **Enterprise (#21, #22):** `audit_events`, `admin_security_events`, `product_categories`, `products`, `product_images`, `ai_templates`, `company_profiles`, `enterprise_products`, `glass_catalog`, `hardware_catalog`, `suppliers`, `employees`, `service_orders`, `financial_entries`
- **Operacional (#25):** `works`, `installation_schedule`, `installer_tasks`, `crm_pipeline`, `purchase_orders`, `warranties`, `digital_signatures`, `project_marketplace`, `manufacturers`, `backup_jobs`
- **Documentos (#24):** `quote_notes`, `quote_documents`, `fiscal_invoices`, `payment_slips`
- **Alumínio (#26):** `aluminum_categories`, `aluminum_profiles`, `editable_project_versions`
- **Planos/módulos (#27):** `platform_plans`, `platform_modules`, `plan_module_access`, `company_module_access`
- **Multiempresa (#28):** `company_members`
- **Pay/Fiscal (#29):** `payment_accounts`, `charges`, `payment_splits`, `recurring_charges`, `fiscal_settings`
- **Biblioteca (#30):** `plans`, `project_categories`, `project_models`, `plan_model_limits`
- **Produtos (#34):** `company_products`
- **IA (#35, #37, #38, #45, #47):** 18 tabelas `ai_*`
- **Integrações (#39):** 5 tabelas `integration_*`
- **Segurança (#41):** `password_reset_tokens`, `two_factor_codes`, `security_events`, `security_lockouts`

## 8.4 RPCs chamadas que não existem

✅ **Nenhuma.** As 2 RPCs chamadas existem.

## 8.5 🔴 Divergências código × schema (colunas)

| Situação | Detalhe | Impacto |
|---|---|---|
| **`audit_logs` sem tipagem** | Usada em `app.admin.auditoria.tsx:23` com `(supabase as any)`. Colunas lidas: `action`, `actor_email`, `entity`, `created_at` — existem na #21 | 🟡 Funciona, mas sem checagem de tipo |
| **`company_profiles` divergente** | Replay produz v1; banco real tem v2 (§2.1) | 🟡 Baixo hoje (não usada pelo frontend), **alto** se algum módulo passar a usá-la |
| **`security_events` divergente** | Replay produz v1 (`level`, `event`); código de segurança esperaria v2 (`flow`, `action`, `success`) | 🟡 Tabela não usada pelo frontend hoje |
| **`ai_system_settings` divergente** | Replay produz `key`/`value`; `types.ts` tem `setting_key`/`setting_value` | 🟡 Não usada pelo frontend |

## 8.6 🔴 Realtime quebrado

`NotificationsBell.tsx`, `app.admin.notificacoes.tsx` e `app.admin.logs.tsx` abrem canais `postgres_changes` em `auth_events` e `server_logs`. A migration **#16 removeu ambas as tabelas da publicação `supabase_realtime`**.

**Efeito:** os canais conectam, mas **nenhum evento chega**. A UI depende do botão "Atualizar". Não gera erro — falha silenciosa.

## 8.7 🔴 Logging quebrado por RLS

`src/lib/log-event.ts` e `src/lib/server-log.ts` fazem `INSERT` em `auth_events` / `server_logs` — inclusive em `login_error` e `signup`, ou seja, **para usuários não-admin e não autenticados**.

A migration **#17 restringiu o INSERT dessas tabelas a `has_role(auth.uid(),'admin')`**.

**Efeito:** todo o logging de autenticação falha. `logEvent` engole a exceção (`catch { console.warn }`), então a falha é **invisível** — a tela de logs do admin fica permanentemente vazia exceto pelas ações do próprio admin.

## 8.8 Módulos que usam apenas `localStorage` (não persistem no Supabase)

| Arquivo | Refs a `supabase` |
|---|---|
| `src/components/EnterpriseCrudPage.tsx` | **0** |
| `src/routes/_authenticated/app.produtos.tsx` | **0** |
| `src/lib/module-access.ts` | **0** |
| `src/lib/planAccess.ts` | **0** |
| `src/lib/segmentAccess.ts` | **0** |
| `src/modules/ai-intelligence/AIDialogPage.tsx` | **0** |
| `src/components/orcamentos/BudgetWorkspace.tsx` | **0** |
| `src/components/ia/IAIntelligencePanel.tsx` | 4 (parcial) |

Ou seja: **produtos, CRUD enterprise, controle de plano/segmento/módulo, IA e o workspace de orçamento são hoje 100 % client-side**, apesar de existirem ~40 tabelas nas migrations para suportá-los. Isso explica o descompasso entre 87 tabelas e 13 tabelas usadas.

---

# Parte 9 — Configuração e credenciais

> Nenhum valor de `.env` foi lido ou reproduzido. Apenas **nomes** de variáveis.

## 9.1 `supabase/config.toml`

> ✅ **Situação superada em 2026-07-21** (ver `docs/PLANO_BASELINE_SUPABASE.md` §0). O bloco
> abaixo é o **estado auditado original**, mantido como registro histórico.

```toml
project_id = "iitgmvdpylwbqipixtah"
```

- 🔴 **Aponta para o projeto Supabase antigo.** Precisa ser atualizado antes de qualquer `supabase link`.
- 🟡 **Arquivo mínimo:** não define `[auth]`, `[db]`, `[storage]`, `[api]`. Um `supabase start` local usará somente defaults — o que significa que **configurações de Auth (confirmação de e-mail, redirect URLs, expiração de OTP) não são versionadas** e terão de ser refeitas à mão no novo projeto.

**Estado atual (2026-07-21):** ambos os pontos resolvidos.

```toml
project_id = "vidro-metal-mestre"   # identificador LOCAL, não o ref remoto
```

- ✅ O projeto antigo foi descartado. O ref remoto do projeto novo **ainda não** foi colocado
  aqui — isso acontece só na etapa de vínculo.
- ✅ O arquivo passou a ser completo: `[api]`, `[db]`, `[db.seed]`, `[auth]`, `[storage]`,
  `[realtime]`, `[studio]`, `[analytics]` versionados. Portas na faixa **55320-55329** para não
  conflitar com o projeto `barbaflow` na mesma máquina. `sql_paths = ["./seed.sql"]`.

## 9.2 `.env` e `.gitignore`

| Item | Situação |
|---|---|
| `.env` rastreado pelo Git? | ✅ **Não** — `.gitignore` linhas 34-36 (`.env`, `.env.*`, `!.env.example`) |
| `.env.example` rastreado? | ✅ Sim (correto) |

## 9.3 🔴 Inconsistência de nomes de variáveis

| Origem | Nome |
|---|---|
| `.env.example` declara | **`VITE_SUPABASE_ANON_KEY`** |
| `src/integrations/supabase/client.ts:9` lê | **`VITE_SUPABASE_PUBLISHABLE_KEY`** (fallback `process.env.SUPABASE_PUBLISHABLE_KEY`) |

**Consequência:** quem seguir o `.env.example` recebe, em runtime:
`Missing Supabase environment variable(s): SUPABASE_PUBLISHABLE_KEY. Connect Supabase in Lovable Cloud.`

Além disso, `.env.example` **não declara** duas variáveis que o código exige:
- `SUPABASE_URL` / `SUPABASE_PUBLISHABLE_KEY` (fallback SSR em `client.ts`)
- **`SUPABASE_SERVICE_ROLE_KEY`** (obrigatória em `client.server.ts`)

## 9.4 Variáveis efetivamente lidas em `src/`

| Variável | Arquivo | Exposta ao browser? |
|---|---|---|
| `import.meta.env.VITE_SUPABASE_URL` | `client.ts` | ✅ Sim (esperado) |
| `import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY` | `client.ts` | ✅ Sim (esperado — chave anônima) |
| `process.env.SUPABASE_URL` | `client.ts`, `client.server.ts` | ❌ Não |
| `process.env.SUPABASE_PUBLISHABLE_KEY` | `client.ts` | ❌ Não |
| `process.env.SUPABASE_SERVICE_ROLE_KEY` | `client.server.ts` | ❌ Não |
| `process.env.LOVABLE_API_KEY` | (server) | ❌ Não |

## 9.5 ✅ Risco de vazamento de `service_role` no bundle — **não confirmado**

Análise:

1. `SUPABASE_SERVICE_ROLE_KEY` é lida **apenas** em `src/integrations/supabase/client.server.ts`, via `process.env` (nunca `import.meta.env`) — o Vite **não** substitui `process.env.*` no bundle do cliente.
2. `client.server.ts` tem **um único importador**: `src/lib/admin-bootstrap.functions.ts:19`, através de `await import(...)` **dinâmico**, dentro de um arquivo `*.functions.ts` (convenção de server function do TanStack Start).
3. Varredura do build gerado (`.output/public/`) por `SUPABASE_SERVICE_ROLE_KEY` / `service_role`: **nenhuma ocorrência**.

🟢 **Conclusão: a chave privilegiada não chega ao bundle do navegador.** O padrão está correto (import dinâmico + `process.env` + arquivo `.server`).

⚠️ **Fragilidade a monitorar:** a proteção depende inteiramente de `client.server.ts` nunca ser importado estaticamente por código de cliente. Não há barreira automatizada (lint rule / `import/no-restricted-paths`) impedindo isso. **Recomendação:** adicionar uma regra de ESLint que proíba importar `*/client.server` fora de `*.functions.ts` / rotas de servidor.

## 9.6 Referências ao projeto antigo

| Local | Referência | Ação |
|---|---|---|
| `supabase/config.toml` | ~~`project_id = "iitgmvdpylwbqipixtah"`~~ | ✅ **Resolvido em 2026-07-21** — agora `"vidro-metal-mestre"` |
| `src/lib/security.ts:17` | CSP `https://*.supabase.co wss://*.supabase.co` | 🟢 Wildcard — funciona com qualquer projeto |
| `src/` (código) | Nenhuma URL de projeto hardcoded | 🟢 OK |

**Verificação pós-promoção (2026-07-21):** a única ocorrência de `iitgmvdpylwbqipixtah` em
arquivos rastreados é este próprio documento de auditoria, **como registro histórico do
projeto descartado**. Nenhuma ocorrência de `uksowfkcqpkkscsonzfs`, nenhum host `db.*` e
nenhum host de pooler antigo em arquivo rastreado.

---

# Parte 10 — Conclusão

## 10.1 🔴 Bloqueadores para executar as migrations em banco vazio

Em ordem de encontro (`supabase db push` **para na primeira**):

| Ordem | Migration | Erro | Causa |
|---|---|---|---|
| **1º** | `20260701030000_budget_reports_finance_docs` | `syntax error at or near "NOT"` | **`CREATE POLICY IF NOT EXISTS`** — sintaxe inexistente no PostgreSQL (16 ocorrências) |
| 2º | `20260703020000_versaglass_pay_and_fiscal` | `column "company_id" does not exist` | `fiscal_invoices` já criada com schema v1 pela anterior |
| 3º | `20260704114000_ia_intelligence_learning_scans` | `invalid input value for enum public.app_role: "super_admin"` | `'super_admin'` não existe no enum (3 policies) |
| 4º | `20260704133000_ia_integrations_manager` | idem | idem (5 policies) |
| 5º | `20260705034629_32292d7b` | `column "flow" does not exist` | `security_events` já criada com schema v1 |
| 6º | `20260705172639_9629f6f1` | `column "setting_key" does not exist` | `ai_system_settings` já criada com schema v1 |

**Risco adicional (não confirmado):** `20260705130718`, `20260705133650`, `20260714200012` chamam `crypt()`/`gen_salt()` sem qualificar schema — podem falhar com `function crypt(text, text) does not exist` dependendo do `search_path` da sessão de migration no Supabase.

## 10.2 🔴 Problemas graves de segurança

| # | Problema | Gravidade | Onde |
|---|---|---|---|
| 1 | **Senhas em texto puro versionadas no Git** — 3 valores distintos para uma conta corporativa real, com `email_confirmed_at` forçado | 🔴 **Crítica** | #43, #44, #49 |
| 2 | **20 policies `USING (true) WITH CHECK (true)`** — qualquer autenticado lê/escreve dados de todas as empresas, incluindo `financial_entries` e `employees` | 🔴 **Crítica** | #22 |
| 3 | **`company_profiles` com `ALL USING (true)`** — um assinante pode reescrever o cadastro de qualquer outra empresa | 🔴 **Crítica** | #22 |
| 4 | Funções DEFINER aceitam `_user_id`/`_company_id` arbitrário → enumeração de papéis e vínculos de terceiros | 🟡 Média | `has_role`, `has_permission`, `is_company_*`, `get_user_plan` |
| 5 | `is_company_member/admin/platform_admin` executáveis por `PUBLIC` entre #28 e #32 | 🟡 Média | janela histórica |
| 6 | `is_company_owner` executável por `PUBLIC` entre #42 e #48 | 🟡 Média | janela histórica |
| 7 | `set_updated_at` perde `search_path` entre #29 e #36 | 🟡 Média | regressão temporária |
| 8 | `set_quote_items_updated_at` nunca recebeu `search_path` | 🟡 Baixa | #23 |
| 9 | Bucket sem `file_size_limit` nem `allowed_mime_types` | 🟡 Baixa | #15 |
| 10 | 19 policies sem cláusula `TO` (avaliadas para `anon`) | 🟢 Baixa | #26, #36, #37, #38, #39 |
| 11 | `GRANT USAGE ON TYPE app_role TO anon` nunca revogado | 🟢 Informativa | #13 |

✅ **Pontos fortes:** todas as 13 funções `SECURITY DEFINER` têm `SET search_path`; as 2 views têm `security_invoker = true`; `user_roles` tem policy **RESTRICTIVE** anti-escalonamento; `company_members` impede promoção a `owner`; a chave `service_role` não vaza para o bundle.

## 10.3 🔴 Inconsistências de schema

1. **O conjunto de migrations não reproduz o banco real.** Comparando `types.ts` (snapshot do banco em produção) com o replay das 49 migrations:
   - **48 das 87 tabelas** criadas nas migrations **não existem** no banco real.
   - `company_profiles`, `fiscal_invoices`, `ai_system_settings` existem no banco real com o schema da **segunda** declaração — mas o replay produziria a **primeira**.
   - **Diagnóstico:** as migrations #21–#30 e #35, #37–#39 **nunca foram aplicadas**. O banco real foi construído a partir da consolidação #31/#32 mais as migrations posteriores.
2. **Quatro tabelas com schema duplo incompatível** (§2.1).
3. **10 tabelas com RLS ligado e zero policies** (§3.6).
4. **`'super_admin'` não existe no enum `app_role`** mas é referenciado em 8 policies.
5. **Três taxonomias de papel** desconectadas: enum `app_role`, `profiles.permissions` jsonb, `company_members.role` text.
6. **`company_id` nullable e nunca populado** — multiempresa inativo (§5.4).
7. **`audit_logs` fora de `types.ts`** — acesso via `as any`.
8. **Realtime e logging quebrados** por endurecimento de RLS/publicação (§8.6, §8.7).

## 10.4 Dados que devem sair para `seed.sql`

| Dado | Migration | Motivo |
|---|---|---|
| `plans` (PRO 149,90 / PREMIUM 299,90) | #30, #32 | Preço é dado de negócio — mudar preço não deve exigir migration |
| `plan_model_limits` (17 linhas) | #30, #32 | Regra comercial, ajustável |
| **`UPDATE auth.users` com senha** | #43, #44, #49 | 🔴 **Não deve existir em lugar nenhum** — criar o admin via Supabase Auth Admin API/Dashboard |

**Devem permanecer em migration** (são estrutura, não dados): `platform_plans`, `platform_modules`, `plan_module_access`, `project_categories`, `storage.buckets`.

## 10.5 Migrations que provavelmente falharão

`20260701030000` · `20260703020000` · `20260704114000` · `20260704133000` · `20260705034629` · `20260705172639`
**+ risco:** `20260705130718` · `20260705133650` · `20260714200012` (`crypt`/`gen_salt` sem schema).

## 10.6 Migrations que precisam ser corrigidas

| Migration | Correção necessária |
|---|---|
| `20260701030000` | Trocar `CREATE POLICY IF NOT EXISTS` por `DROP POLICY IF EXISTS` + `CREATE POLICY` (16×) |
| `20260701021500` | Substituir as 20 policies `USING (true)` por isolamento via `is_company_member`/`is_company_admin` |
| `20260701033000` | Criar policies para as 10 tabelas (ou remover `ENABLE ROW LEVEL SECURITY`) |
| `20260703020000` | Resolver o conflito de `fiscal_invoices`; restaurar `SET search_path` em `set_updated_at` |
| `20260704114000`, `20260704133000` | Remover `'super_admin'` **ou** adicionar o valor ao enum `app_role` (`ALTER TYPE … ADD VALUE`) |
| `20260705034629` | Resolver o conflito de `security_events` antes do índice em `flow` |
| `20260705172639` | Resolver o conflito de `ai_system_settings` antes do índice em `setting_key` |
| `20260705130718`, `20260705133650`, `20260714200012` | **Excluir** — senhas em texto puro |
| `20260705023016` | Migration vazia (`-- Ver /tmp/final_mig.sql`) — remover ou reconstituir |
| `20260621015137`, `20260705153015` | Tornar idempotentes (`IF NOT EXISTS` na constraint/coluna) |
| `20260701023000` | Adicionar `SET search_path` em `set_quote_items_updated_at` |
| `20260519025716` etc. | `CREATE TYPE` → bloco `DO`/`duplicate_object` para idempotência |

## 10.7 ⭐ Recomendação: **baseline consolidada + migrations posteriores**

| Opção | Avaliação |
|---|---|
| **A. Manter e corrigir as 49** | ❌ **Não recomendado.** Exige ~13 correções, incluindo resolver 4 conflitos de schema duplo cuja "resolução correta" contradiz o histórico. Preserva 48 tabelas que nunca existiram e 85 % de schema morto. Alto esforço, alto risco, benefício histórico nulo — **o histórico já não corresponde à realidade**. |
| **B. Baseline única** | 🟡 Viável, mas descarta o rastro de endurecimento de RLS (#14, #16, #17, #36, #42, #48), que é a parte mais bem-feita do repositório. |
| **C. Baseline + posteriores** | ✅ **RECOMENDADO** |

### Plano da opção C

1. **Arquivar** as 49 migrations em `supabase/migrations_legacy/` (fora do path que o CLI lê) — preserva o histórico sem executá-lo.
2. **Gerar `00000000000000_baseline.sql`** a partir do **schema real**, usando `types.ts` como especificação de referência (39 tabelas + 2 views + 14 funções) — **não** a partir do replay das migrations.
3. **Incluir no baseline apenas o que é usado ou tem dono claro:**
   - **Núcleo (13 tabelas do frontend):** `profiles`, `user_roles`, `customers`, `quotes`, `quote_items`, `project_templates`, `inventory_items`, `subscriptions`, `billing_notifications`, `auth_events`, `server_logs`, `user_subscriptions`, `audit_logs`
   - **Enums, funções DEFINER (com `search_path`), triggers, bucket `project-images`**
   - **RLS final endurecida** (o estado pós-#17/#36/#42, não o estado inicial)
4. **Decidir explicitamente** sobre as 74 tabelas não usadas: entram como "schema futuro" ou ficam de fora até que o módulo correspondente saia do `localStorage`. **Recomendo deixar de fora** — schema sem consumidor é dívida.
5. **Corrigir no baseline** os 4 conflitos de schema duplo escolhendo a **v2** (que é o que o banco real tem e o que `types.ts` espera).
6. **Nunca portar** `20260705130718`, `20260705133650`, `20260714200012`.
7. **`supabase/seed.sql`** recebe `plans` e `plan_model_limits`.
8. Migrations novas seguem normalmente a partir do baseline.

## 10.8 Plano seguro para testar localmente

> Sem tocar em nenhum projeto remoto. **Executar apenas quando você autorizar** — nada disso foi feito nesta auditoria.

**Pré-requisitos:** Docker Desktop rodando; Supabase CLI instalado.

```
Passo 0  Branch dedicada          git switch -c chore/baseline-supabase
Passo 1  Arquivar legado          mover supabase/migrations/* → supabase/migrations_legacy/
Passo 2  Escrever o baseline      supabase/migrations/00000000000000_baseline.sql
Passo 3  Subir stack local        supabase start          (Docker, 100% local)
Passo 4  Aplicar do zero          supabase db reset       (recria + aplica + roda seed.sql)
Passo 5  Validar erros            a saída deve terminar sem ERROR
Passo 6  Lint de segurança        supabase db lint --level warning
Passo 7  Regenerar tipos          supabase gen types typescript --local > /tmp/types.new.ts
Passo 8  Diff contra o atual      comparar com src/integrations/supabase/types.ts
         → objetivo: ZERO diferenças nas 13 tabelas usadas pelo frontend
Passo 9  Teste funcional          bun run dev apontando para a stack local
                                  · signup → confirmar profile + role + 13 templates
                                  · CRUD de cliente/orçamento/item
                                  · upload de imagem + URL assinada
                                  · login como 2º usuário → confirmar isolamento
Passo 10 Testes de RLS negativos  autenticar como usuário B e tentar ler dados de A
                                  → deve retornar 0 linhas, não erro
Passo 11 Derrubar                 supabase stop
```

**Critério de sucesso do Passo 8:** o `types.ts` gerado do baseline local deve ser **idêntico** ao atual nas 13 tabelas em uso. Se divergir, o baseline está errado — corrigir antes de prosseguir.

## 10.9 Critérios para autorizar `supabase db push` no novo projeto

Só autorize quando **todos** estiverem satisfeitos:

**Bloqueadores técnicos**
- [ ] `supabase db reset` local termina **sem nenhum ERROR**
- [ ] `supabase db lint` sem findings de nível `error`
- [ ] `types.ts` regenerado é idêntico ao atual nas 13 tabelas em uso
- [ ] `bun run build` e `bunx tsc --noEmit` continuam passando

**Bloqueadores de segurança**
- [ ] **Zero** migrations com senha em texto puro
- [ ] **Zero** policies `USING (true)` em tabelas com dado de tenant
- [ ] **Zero** tabelas com RLS ligado e nenhuma policy
- [ ] Toda função `SECURITY DEFINER` com `SET search_path`
- [ ] Toda view sensível com `security_invoker = true`
- [ ] Testes de RLS negativos passando (usuário B não vê dados de A)

**Bloqueadores de configuração**
- [ ] `supabase/config.toml` com o **novo** `project_id`
- [ ] `.env.example` corrigido: `VITE_SUPABASE_PUBLISHABLE_KEY` (não `ANON_KEY`) + `SUPABASE_SERVICE_ROLE_KEY` documentada
- [ ] `.env` local do novo projeto validado (app conecta e autentica)
- [ ] Configurações de Auth do novo projeto documentadas (redirect URLs, confirmação de e-mail, OTP)

**Bloqueadores de processo**
- [ ] Primeiro usuário admin criado **via Dashboard/Auth Admin API**, nunca por migration
- [ ] Ciente de que o **primeiro signup vira `admin`** (§5.2) — criar o admin **antes** de abrir o cadastro
- [ ] Backup/snapshot do projeto novo antes do push (mesmo vazio)
- [ ] `supabase db push --dry-run` revisado linha a linha
- [ ] Decisão registrada sobre as 74 tabelas sem consumidor

---

## Anexo — Correções fora do escopo desta fase

Itens detectados que **não** pertencem à camada Supabase mas afetam a estabilização:

1. `src/lib/log-event.ts` / `server-log.ts` — o `INSERT` falha por RLS desde a #17. Decidir entre relaxar a policy (permitir self-insert com `user_id = auth.uid()`) ou mover o logging para uma server function com `service_role`.
2. `NotificationsBell.tsx`, `app.admin.logs.tsx`, `app.admin.notificacoes.tsx` — realtime inerte desde a #16. Decidir entre readicionar as tabelas à publicação ou remover os canais e assumir polling.
3. `app.estoque.tsx` — verificar se o upload usa o prefixo `${user.id}/` exigido pela policy do bucket (arquivo sob `@ts-nocheck`).
4. Regra de ESLint para proibir import estático de `*/client.server` fora de contexto de servidor (§9.5).
