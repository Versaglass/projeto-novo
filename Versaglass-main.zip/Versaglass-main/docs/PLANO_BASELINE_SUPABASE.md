# Plano da baseline do Supabase — Vidro & Metal Mestre

> Companheiro de `supabase/migrations/20260721000000_initial_schema.sql`,
> `supabase/seed.sql` e `docs/PENDENCIAS_SUPABASE.md`.
> Base analítica: `docs/AUDITORIA_SUPABASE.md`.
>
> **Status: PROMOVIDA (2026-07-21) · IMPLANTADA (2026-07-22).** A baseline deixou de ser
> rascunho, foi aplicada no projeto remoto novo e recebeu a terceira migration.
> A pasta `supabase/baseline-draft/` não existe mais.
>
> **Decisão estrutural (2026-07-27) · validada localmente, push pendente:**
> `public.inventory_items` passa a ser isolada por **empresa**. A coluna `company_id`, a FK
> e o índice `idx_inventory_company` **já existiam na baseline** — o que mudou é que
> passam a ser usados: `company_id` vira **NOT NULL** e **imutável** (trigger), a leitura
> passa a ser por membership (sem fallback `owner_id`), `imagem_url` fica restrita ao
> prefixo da própria empresa e quantidade/preços ganham CHECK de não-negativo. O enum
> `inventory_category` foi **estendido** com 9 valores que a interface já oferecia e o
> banco rejeitava (⚠️ irreversível). Migrations `20260727000000_inventory_category_expand.sql`
> e `20260727010000_inventory_company_crud.sql`. **Não existe tabela de movimentações de
> estoque** e nenhuma foi criada: `quantidade` é saldo atual, sem histórico. `quote_items`
> **não** ganhou FK para `inventory_items` — o orçamento guarda snapshot de descrição e
> preço. Ver `docs/PENDENCIAS_SUPABASE.md` → "Módulo Estoque".
>
> **Decisão estrutural (2026-07-24) · IMPLANTADA E VALIDADA NO REMOTO (2026-07-27):**
> `public.project_templates` deixa de ser isolado por
> usuário e passa a pertencer à **empresa** (nova coluna `company_id` **NOT NULL**, FK
> `company_profiles ON DELETE CASCADE`, RLS por membership) — biblioteca técnica compartilhada
> entre membros; `owner_id` continua como criador. Migrations
> `20260724030000_project_templates_company.sql` +
> `20260724040000_project_templates_hardening.sql` (imutabilidade de tenant por trigger,
> CHECK de `imagem_url` no prefixo da empresa, Storage UPDATE/DELETE restrito ao uploader ou
> owner/admin/manager) — **ambas aplicadas no remoto**, `migration list --linked` alinhado e
> `db push --dry-run` informando remoto atualizado; teste manual pela UI **aprovado**.
> A obra/projeto comercial do cliente permanece em `public.quotes` (`quotes.etapa` = ciclo);
> **não** foi criada entidade de projeto de cliente nem vínculo de project_templates a
> customers/quotes. Ver `docs/PENDENCIAS_SUPABASE.md` → "Biblioteca de Projetos Técnicos".

---

## 0. Estado após a promoção (2026-07-21) e a implantação (2026-07-22)

| Item | Situação |
|---|---|
| **Supabase antigo** | ❌ **Descartado.** Nenhum dado, usuário ou schema a migrar |
| **49 migrations antigas** | ❌ **Removidas** de `supabase/migrations/`. Não foram copiadas para lugar nenhum do repositório — o histórico vive no Git e na tag `backup/pre-baseline-supabase` |
| **Migrations oficiais** | ✅ **quatro aplicadas no remoto** — `20260721000000_initial_schema.sql`, `20260721010000_storage_realtime.sql`, `20260722000000_auth_user_provisioning.sql`, `20260723010000_foreign_key_integrity.sql` (P-12). **5ª validada localmente, pendente de push:** `20260723020000_company_onboarding.sql` (RPC de onboarding empresarial; ver `PENDENCIAS_SUPABASE.md` → Onboarding) |
| **Seed oficial** | ✅ `supabase/seed.sql` — só catálogo (Bloco A/A'); Bloco B demonstrativo permanece vazio |
| **Pendências** | ✅ `docs/PENDENCIAS_SUPABASE.md` |
| **`config.toml`** | ✅ `project_id = "vidro-metal-mestre"` (identificador **local**, não o ref remoto); portas na faixa 55320-55329 |
| **Projeto Supabase novo** | ✅ **Conectado e implantado (2026-07-22).** As três migrations aplicadas; histórico remoto idêntico ao local |
| **P-23** — provisionamento de usuário | ✅ **Resolvida (2026-07-22)** pela migration 03 — trigger `on_auth_user_created` ativo; papel `vendedor` persistido (§13) |
| **P-24** — botão Google | 🟡 **Desativado (2026-07-22)** — provider não configurado; flag `GOOGLE_OAUTH_ENABLED` em `src/routes/auth.tsx` (§13) |
| **P-05** — `certificate_password` | ✅ **Resolvida na baseline**: coluna removida e não substituída. Integração fiscal segura **adiada** para migration futura (§4.2) |
| **P-07** — logs | ✅ **Resolvida no schema** (só `service_role` escreve) · ✅ **aplicação migrada e validada local (37/37) e remota (2026-07-23)** para `auth_events`/`server_logs` (§4.3; detalhes em `PENDENCIAS_SUPABASE.md`) |
| **P-26** — feature de IA (schema) | 🟡 **Bloqueada.** 19 tabelas referenciadas pelo código foram descartadas na baseline (P-19) e ausentes no remoto; migration **NÃO** criada (schema não comprovável com segurança). Auditoria do caminho de erro corrigida. Ver `PENDENCIAS_SUPABASE.md` → P-26 |
| **P-13** — Storage | ✅ **Resolvida (2026-07-21)** pela migration 02 — bucket `project-images` privado, 5 MiB, MIME restrito, 4 policies por pasta do usuário (§12) |
| **P-14** — Realtime | ✅ **Resolvida (2026-07-21)** pela migration 02 — `auth_events` e `server_logs` publicadas; entrega filtrada por RLS validada em WebSocket real (§12) |
| **P-12** — foreign keys | ✅ **Resolvida (2026-07-23).** 4ª migration `20260723010000_foreign_key_integrity.sql` adiciona as 4 FKs para `auth.users` (`ON DELETE CASCADE`), validada localmente (reset + `db lint` + testes de FK) e **aplicada no remoto** (`db push` concluído; `migration list --linked` alinhado). Detalhes em `PENDENCIAS_SUPABASE.md` → P-12 |

> Ao longo deste documento, trechos que ainda descrevem o processo de rascunho (§1 e §1.3, por
> exemplo) são mantidos como **registro histórico** da investigação. Os comandos de `db dump`
> da §1.3 **não devem mais ser executados**: o projeto de origem foi descartado.

---

## 1. Fontes utilizadas

| # | Fonte | Status | O que forneceu |
|---|---|---|---|
| 1 | `tmp/supabase-antigo/public-schema.sql` | 🔴 **DISPONÍVEL — MAS O SCHEMA ESTÁ VAZIO** | 1 função de infraestrutura + default privileges. **0 tabelas, 0 tipos, 0 views, 0 policies, 0 índices, 0 triggers, 0 dados.** |
| 2 | Uso real do banco em `src/` | ✅ Usada | 13 tabelas com consumidor, 2 RPCs, 1 bucket, 2 canais realtime, 2 divergências × `types.ts` |
| 3 | `src/integrations/supabase/types.ts` | ✅ **Fonte primária de estrutura** | 39 tabelas, colunas, tipos, nulabilidade, 11 enums, 2 views, 12 funções, FKs **entre tabelas de `public`** |
| 4 | `supabase/migrations/20260703040050_5367a5a3-…` | ✅ Usada | Grants, revokes, definição de funções |
| 5 | Migrations posteriores compatíveis | ✅ Usadas | `20260703040107` (views), `20260705124632` (owner), `20260705150358` (ai_dialog), `20260705153015` (segment), `20260705172639` (ai_system_settings v2), `20260708231226` (revoke) |
| 6 | Migrations antigas (definições faltantes) | ⚠️ Uso restrito | Índices, triggers, policies, `audit_logs`, colunas de desenho de `quote_items` |

### 1.1 🔴 O dump chegou, mas o schema está vazio

O arquivo é um dump **bem formado e completo** (101 linhas, cabeçalho `pg_dump`/`supabase db dump`
padrão, `ALTER DEFAULT PRIVILEGES` no rodapé). Ele não está truncado: é o retrato fiel de um
schema `public` **sem nenhuma tabela**.

Conteúdo integral: `CREATE SCHEMA public`, a função `public.rls_auto_enable()`, 4 `GRANT USAGE`,
3 `GRANT ALL ON FUNCTION` e 12 `ALTER DEFAULT PRIVILEGES`. Nenhuma das 40 tabelas da baseline é
mencionada (verificado nome a nome).

**Portanto o dump NÃO resolveu P-03, P-06, P-13 nem P-19 por comparação** — não há nada com que
comparar. `types.ts` continua sendo a única descrição estrutural existente, e agora sabe-se que
descreve um estado que **não existe em nenhum banco conhecido**.

Ver `docs/PENDENCIAS_SUPABASE.md` #P-00 para as três hipóteses (dump do projeto novo · projeto antigo resetado ·
escopo errado no comando) e como confirmar cada uma.

### 1.2 O que o dump ensinou de fato

| Achado | Efeito na baseline |
|---|---|
| Existe `public.rls_auto_enable()` — função de event trigger que liga RLS automaticamente em toda tabela criada em `public` | **Não recriada** (infraestrutura da plataforma). Os `enable row level security` da §10 continuam corretos e são idempotentes. Ver P-21 |
| `ALTER DEFAULT PRIVILEGES ... GRANT ALL ON TABLES TO anon` | Torna os `revoke ... from anon` da §12 **obrigatórios**, não defesa opcional. Documentado no SQL. Ver P-22 |
| `GRANT ALL ON FUNCTION rls_auto_enable() TO anon` | Grant desnecessário herdado do provisionamento; risco prático baixo (event trigger não é invocável por cliente) |
| **Zero dados** | Confirma que o Bloco B do `seed.sql` deve permanecer vazio — não há dado de produção a preservar |

### 1.3 Como fechar P-00

```
# confirmar o projeto e refazer com escopo correto
supabase projects list
supabase db dump --linked --schema public   -f tmp/supabase-antigo/public-schema.sql
supabase db dump --linked --schema storage  -f tmp/supabase-antigo/storage-schema.sql   # fecha P-13
```

Se o Table Editor do projeto antigo também estiver vazio, a hipótese B se confirma: **não há
migração de dados a fazer** e a baseline passa a ser criação limpa.

---

## 1.4 Matriz de fontes

| Categoria | Objetos | Contagem |
|---|---|---|
| **Somente no dump** | `public.rls_auto_enable()`; `ALTER DEFAULT PRIVILEGES` para `anon`/`authenticated`/`service_role`; `GRANT USAGE ON SCHEMA` | 1 função + 12 default privileges |
| **Somente em `types.ts`** | As 39 tabelas, 11 enums, 2 views e 12 funções — **nenhuma aparece no dump** | 39 tabelas |
| **Somente no código (`src/`)** | `audit_logs`; `quote_items.drawing_data` / `.drawing_notes`; bucket `project-images`; canais realtime de `auth_events` e `server_logs` | 1 tabela + 2 colunas + 1 bucket + 2 canais |
| **Somente nas migrations** | As 48 tabelas descartadas; **100 % das policies, triggers, índices, grants e constraints** (nada disso está em `types.ts` nem no dump) | 48 tabelas |
| **Divergente entre fontes** | **Dump (0 tabelas) × `types.ts` (39 tabelas)** — divergência total. `types.ts` × código: 2 divergências. Migrations × `types.ts`: 4 tabelas com schema duplo, já resolvidas | — |

---

## 2. Objetos incluídos

| Categoria | Quantidade |
|---|---|
| Tabelas | **40** |
| Enums | **11** |
| Sequências | **1** |
| Índices | **40** |
| Funções | **14** (12 `SECURITY DEFINER` + 2 `INVOKER`) |
| Triggers em tabelas públicas | **17** |
| Views | **2** (ambas `security_invoker = true`) |
| Policies | **111** |
| Tabelas com RLS habilitado | **40 / 40** |
| Comentários de segurança | **7** |
| Triggers em `auth.users` | **1 ativo** desde a migration 03 — `on_auth_user_created` (§13). Era 0 na baseline, com o `create trigger` comentado na §16 do SQL |

### 2.1 Tabelas por grupo e fonte

| Grupo | Tabelas | Fonte principal |
|---|---|---|
| **Identidade** | `profiles`, `user_roles` | types.ts + `20260519025716`, `20260519035449`, `20260705153015` |
| **Empresa (tenant)** | `company_profiles`, `company_members` | types.ts (schema **v2**) + `20260703040050` |
| **Núcleo operacional** | `customers`, `quotes`, `quote_items`, `inventory_items`, `project_templates` | types.ts + `20260519025716`, `20260519033247`, `20260701023000` |
| **Assinaturas** | `subscriptions`, `billing_notifications`, `user_subscriptions` | types.ts + `20260519040113`, `20260703040050` |
| **Catálogo da plataforma** | `platform_plans`, `platform_modules`, `plan_module_access`, `company_module_access`, `plans`, `project_categories`, `project_models`, `plan_model_limits` | types.ts + `20260703040050` |
| **Pagamentos** | `payment_accounts`, `charges`, `payment_splits`, `recurring_charges` | types.ts + `20260703040050` |
| **Fiscal** | `fiscal_settings`, `fiscal_invoices` | types.ts (schema **v2**) + `20260703040050` |
| **Registros administrativos** | `auth_events`, `server_logs`, `audit_logs` | types.ts + `20260519163949`, `20260519172529`, `20260701020000` |
| **Segurança** | `security_events`, `security_lockouts`, `password_reset_tokens`, `two_factor_codes` | types.ts (schema **v2**) + `20260705034629` |
| **IA** | `ai_system_settings`, `ai_generated_code`, `ai_dialog_sessions`, `ai_dialog_messages`, `ai_dialog_suggestions`, `ai_dialog_action_previews`, `ai_dialog_executions` | types.ts (`ai_system_settings` **v2**) + `20260705150358`, `20260705172639` |

**39 tabelas vêm de `types.ts`.** A 40ª (`audit_logs`) foi incluída porque o código ativo a
consulta — ver P-02.

### 2.2 Conflitos de schema resolvidos

Três tabelas tinham duas definições incompatíveis nas migrations. A baseline escolheu sempre a
versão que **`types.ts` comprova estar no banco real**, e criou cada objeto **uma única vez**:

| Tabela | Versão descartada | Versão adotada |
|---|---|---|
| `company_profiles` | `20260701021500` (`document`, `whatsapp`, `logo_url`, `pix_key`, `plan`) | `20260703035847` (`cnpj`, `email`, `address`, `city`, `state`, `segment`) |
| `fiscal_invoices` | `20260701030000` (`owner_id`, `numero`, `cliente`, `valor`) | `20260703020000` (`company_id`, `invoice_type`, `access_key`) |
| `ai_system_settings` | `20260704103000` (`key`, `value`) | `20260705172639` (`setting_key`, `setting_value`, `category`) |
| `security_events` | `20260701020000` (`level`, `event`, `ip`) | `20260705034629` (`flow`, `action`, `success`, `ip_address`) |

Isso elimina de uma vez **4 dos 6 bloqueadores de replay** identificados na auditoria.

---

## 3. Objetos excluídos

### 3.1 As 48 tabelas que só existiam nas migrations antigas

Nenhuma aparece em `types.ts`; nenhuma é usada pelo frontend. **Excluídas** por decisão explícita
(regra 18), registrada em `docs/PENDENCIAS_SUPABASE.md` #P-19 conforme a regra 19:

`works` · `installation_schedule` · `installer_tasks` · `crm_pipeline` · `purchase_orders` ·
`warranties` · `digital_signatures` · `project_marketplace` · `manufacturers` · `backup_jobs` ·
`enterprise_products` · `glass_catalog` · `hardware_catalog` · `suppliers` · `employees` ·
`service_orders` · `financial_entries` · `audit_events` · `admin_security_events` · `products` ·
`product_categories` · `product_images` · `ai_templates` · `quote_notes` · `quote_documents` ·
`payment_slips` · `aluminum_categories` · `aluminum_profiles` · `editable_project_versions` ·
`company_products` · `ai_intelligence_commands` · `ai_intelligence_approvals` ·
`ai_intelligence_logs` · `ai_intelligence_snapshots` · `ai_intelligence_rollbacks` ·
`ai_intelligence_knowledge` · `ai_intelligence_scans` · `ai_intelligence_scan_findings` ·
`ai_agents` · `ai_agent_versions` · `ai_guided_workflows` · `project_media_changes` ·
`integration_connections` · `integration_sync_jobs` · `integration_diagnostics` ·
`integration_repair_jobs` · `integration_event_logs`

Quando um módulo sair do `localStorage` e precisar persistir, a tabela entra por **migration
nova**, com RLS correta desde o primeiro dia.

### 3.2 Outros objetos deliberadamente ausentes

| Objeto | Motivo |
|---|---|
| `UPDATE auth.users` (3 migrations) | Continham **senha em texto puro**. Nunca serão portados. |
| `seed_default_templates()` + trigger | 13 linhas de produto dentro de função `SECURITY DEFINER`. Decisão pendente — P-09. |
| Trigger `on_auth_user_created` | Definido mas **comentado**, na §16 do SQL, para revisão manual. |
| Extensão `pgcrypto` | Não é mais necessária — P-01. |
| Buckets de Storage | Fora da migration inicial por decisão; entregues na migration 02 — §12. |
| Publicação Realtime | Fora da migration inicial por decisão; entregue na migration 02 — §12. |
| Policy `"Roles restrict non-admin writes"` `FOR ALL` | Bloquearia o SELECT do próprio papel e quebraria o login. Substituída por 3 policies RESTRICTIVE só de escrita — P-06. |
| Policy de INSERT em logs | Negação por padrão — P-07. |
| FKs para `auth.users` em 4 tabelas | Ausentes nas fontes; **não foram inventadas** (regra 20) — P-12. |

---

## 4. Decisões de segurança

| # | Decisão | Regra atendida |
|---|---|---|
| 1 | **O primeiro usuário NÃO vira admin.** `handle_new_user` atribui sempre `'vendedor'`. | 3, 4 |
| 2 | Promoção a admin documentada como **operação manual** na §16.3 do SQL, sem UUID versionado. | 5 |
| 3 | Nenhum `CREATE POLICY IF NOT EXISTS` — sintaxe inexistente no PostgreSQL. | 6 |
| 4 | Nenhum `CREATE TABLE IF NOT EXISTS`; cada objeto criado uma única vez. | 7, 8 |
| 5 | RLS habilitado nas **40/40** tabelas. | 9 |
| 6 | **Negação por padrão**: sem policy correspondente, a operação é negada. Nenhuma tabela fica com RLS ligado e zero policy por descuido — as que não têm policy de escrita (logs, tabelas de segurança) são **intencionais** e comentadas. | 10 |
| 7 | Toda policy multiempresa valida `company_id` **e** a associação de `auth.uid()` via `is_company_member` / `is_company_admin`. | 11 |
| 8 | Apenas **2 policies** usam `using (true)`: `plan_module_access` e `plan_model_limits`, ambas catálogo comercial público, cada uma com comentário de justificativa no SQL. | 12 |
| 9 | Nas policies de INSERT/UPDATE, `owner_id` é **forçado** a `auth.uid()` e `company_id` só é aceito se o usuário for membro. `user_id`/`role` de `user_roles` e `user_subscriptions` só são graváveis pelo admin da plataforma. `company_members.role = 'owner'` exige que o autor já seja `owner`. | 13 |
| 10 | As 12 funções `SECURITY DEFINER` têm `SET search_path = ''` com todos os objetos qualificados; 8 delas validam `auth.uid()` e retornam `false`/`'free'` quando o `_user_id` pedido não é o do chamador; todas com `EXECUTE` revogado de `public`/`anon`. | 14 |
| 11 | Nenhuma policy concede poder administrativo ao papel `authenticated` inteiro. Admin sempre passa por `is_platform_admin()` / `is_company_admin()`. As 20 policies `USING (true)` da migration `20260701021500` **não foram portadas**. | 15 |
| 12 | Dados de demonstração ficam em `seed.sql`; a baseline **não tem nenhum INSERT**. | 16 |
| 13 | `seed.sql` separa **Bloco A** (catálogo obrigatório) de **Bloco A'** (catálogo comercial com preço) e **Bloco B** (demonstrativo, vazio). | 17 |
| 14 | `revoke all ... from anon` em tabelas, sequências e funções: **nenhuma tabela de `public` é exposta ao papel anônimo.** | 9, 10 |
| 15 | Ambas as views são `security_invoker = true` — sem isso vazariam faturamento entre empresas. | — |
| 16 | Admin da plataforma **perdeu** o acesso de leitura a `fiscal_settings`. Divergência deliberada da migration original; mantida mesmo após a remoção de `certificate_password` (dado fiscal identificável, sem consumidor). | — |
| 17 | **Nenhuma coluna de `public` armazena segredo.** `certificate_password` foi removida e não substituída — nem texto, nem cifra, nem `secret_id`. | P-05 |
| 18 | **Nenhuma policy de INSERT/UPDATE/DELETE em tabela de log para `anon` ou `authenticated`.** Log é escrito exclusivamente por `service_role`. | P-07 |

### 4.1 Endurecimentos aplicados em relação ao schema real

Estes pontos **divergem** do que as migrations antigas definiam. Cada um está registrado:

| Mudança | Antes | Agora | Ref. |
|---|---|---|---|
| Primeiro usuário vira admin | sim | **não** | Regra 3 |
| `has_role(_user_id, …)` de terceiros | permitido | retorna `false` | P-20 |
| `is_company_*(…, _user_id)` de terceiros | permitido | retorna `false` | Regra 14 |
| `get_user_plan(_user_id)` de terceiros | permitido | retorna `'free'` | Regra 14 |
| `user_roles` RESTRICTIVE | `FOR ALL` (quebra login) | 3 policies de escrita | P-06 |
| Admin lê `fiscal_settings` | sim | **não** | P-05 |
| `fiscal_settings.certificate_password` | coluna `text` em claro | **coluna removida**, sem substituta | P-05 |
| INSERT de logs pelo cliente | admin apenas | **nenhum** (só `service_role`) | P-07 |
| `security_events` INSERT com `user_id is null` | permitido | **removido** | P-17 |
| `set_updated_at` `search_path` | ora sim, ora não | sempre `''` | — |

---

## 4.2 P-05 — segredo do certificado digital · **resolvida para a baseline inicial**

> Decisão de 2026-07-21. **Integração fiscal segura adiada para uma migration futura.**

### Decisão

`fiscal_settings.certificate_password` foi **removida da baseline** e **não substituída**.
O schema `public` não armazena senha de certificado digital A1 em nenhuma forma: nem em
texto, nem cifrada pela aplicação, nem como `secret_id` apontando para o Vault.

| Alternativa | Aplicada? | Motivo |
|---|---|---|
| Outra coluna `text` | ❌ | Mesmo problema com outro nome |
| Coluna cifrada pela aplicação | ❌ | A chave de cifra acabaria no cliente ou em `.env`; criptografia caseira |
| `secret_id` → Supabase Vault | ❌ | Não criar referência a segredo sem integração servidor que a use |
| Habilitar o Vault agora | ❌ | Sem consumidor: infraestrutura sem uso é superfície de ataque sem contrapartida |
| **Não persistir segredo** | ✅ | Único estado sem risco enquanto a integração é simulada |

### Por que é seguro remover agora: a integração fiscal é simulada

Os três provedores (`plugNotasProvider.ts`, `tecnoSpeedProvider.ts`,
`nuvemFiscalProvider.ts`) geram número, chave de acesso e protocolo com
`crypto.randomUUID()` e devolvem URLs de exemplo (`https://fiscal.exemplo/...`).
**Nenhum faz requisição de rede e nenhum lê a senha do certificado.** No projeto inteiro
não existe um único leitor de `certificate_password` — só uma declaração de tipo
(`src/modules/fiscal/types.ts:18`) e um campo de formulário mock
(`src/routes/_authenticated/app.fiscal.tsx:22,44`, estado local via `storageKey`).

### Consequência registrada

A **configuração de certificado digital fica indisponível** no produto até que a integração
fiscal segura seja implementada. Nada quebra hoje: a tela nunca gravou no banco.

### Estratégia futura (migration posterior)

1. Segredo no **Supabase Vault** ou serviço de segredos equivalente.
2. Gravação e leitura **somente pelo backend**.
3. **Nenhuma senha retornada ao navegador.**
4. **Nenhum segredo em logs.**
5. Associação futura entre empresa e **identificador opaco** do segredo — criada apenas
   quando existir a integração servidor que o consuma.

### Fora do escopo desta fase

`src/` não foi alterado. `src/integrations/supabase/types.ts` será **regenerado** depois que
a migration oficial for aplicada — nunca editado à mão.

---

## 4.3 P-07 — estratégia de logs · **resolvida no schema, pendente na aplicação**

> Decisão de 2026-07-21. Opção **A** adotada em definitivo; **B e C descartadas**.

### Decisão de arquitetura

- Logs são escritos **somente por código servidor confiável**.
- O servidor usa um **cliente separado** com secret/service role
  (`src/integrations/supabase/client.server.ts`, já existente).
- A chave privilegiada **nunca** é usada no navegador.
- **Falhas de logging não devem ser silenciosamente ignoradas** — hoje são, em três lugares.
- As chamadas feitas hoje direto pelo cliente **passarão por endpoint ou função de servidor**.

B e C caem pelo mesmo motivo: qualquer INSERT concedido a `authenticated` permite que um
usuário comum escreva na trilha que deveria julgá-lo. E `login_error` ocorre **antes** de
existir sessão — `auth.uid()` é nulo, então B não cobre justamente o caso mais relevante.

### Verificação no schema (7 pontos)

| # | Garantia | Situação |
|---|---|---|
| 1 | `anon` não faz INSERT/UPDATE/DELETE em log | ✅ zero policies para `anon` + `revoke all` nas §12/§15 |
| 2 | `authenticated` não faz INSERT/UPDATE/DELETE em log | ✅ nenhuma policy de INSERT existe; UPDATE/DELETE só sob `is_platform_admin()` |
| 3 | Usuário comum não forja registro | ✅ negação por padrão |
| 4 | Leitura restrita a administradores | ✅ `is_platform_admin()`; `security_events` também deixa o próprio usuário ler o que é dele |
| 5 | `service_role` mantém acesso | ✅ papel `BYPASSRLS` do Supabase |
| 6 | Nenhuma função `SECURITY DEFINER` pública forja log | ✅ das 12 funções, nenhuma escreve em tabela de log |
| 7 | Logs não guardam senha, token ou credencial | ✅ colunas não comportam segredo; `comment on table` proíbe explicitamente |

### 🟡 Pendente na aplicação — código a corrigir depois de conectar o Supabase novo

**Nada em `src/` foi alterado nesta fase.**

| # | Arquivo | Linha | Hoje | Correção |
|---|---|---|---|---|
| 1 | `src/lib/server-log.ts` | 18 | INSERT em `server_logs` pelo browser | Endpoint/função de servidor com `supabaseAdmin` |
| 2 | `src/lib/server-log.ts` | 29 | `catch` → `console.warn` | Não engolir a falha |
| 3 | `src/lib/server-log.ts` | 42, 45 | `withServerLog` chama `serverLog` sem `await` | Tratar rejeição |
| 4 | `src/lib/log-event.ts` | 19 | INSERT em `auth_events` pelo browser | Endpoint de servidor |
| 5 | `src/lib/log-event.ts` | 24 | espelha em `serverLog` | Segue o item 1 |
| 6 | `src/lib/log-event.ts` | 31 | `catch` → `console.warn` | Não engolir a falha |
| 7 | `src/lib/access-security.ts` | 40 | INSERT em `security_events` pelo browser (`as any`) | Endpoint de servidor; remover o `as any` |
| 8 | `src/lib/access-security.ts` | 48-50 | **`catch {}` vazio** | Tratar erro |
| 9 | `src/modules/ai-intelligence/aiActionExecutor.ts` | 103, 110 | INSERT em `audit_logs` pelo browser (`as any`) | Endpoint de servidor |
| 10 | `src/routes/auth.tsx` | 152, 209, 228, 241 | 4 chamadas a `logEvent`, incluindo `login_error` sem sessão | Segue os itens 4-6 |
| 11 | `src/routes/_authenticated/app.admin.logs.tsx` | 70 | `DELETE` de `server_logs` pelo browser | Só admin consegue; avaliar expurgo por servidor |
| 12 | `src/routes/_authenticated/app.admin.logs.tsx` | 45-46 | canal Realtime em `server_logs` | ✅ **Nada a fazer** — publicado e validado na migration 02 (§12) |
| 13 | `src/integrations/supabase/client.server.ts` | 10 | lê `SUPABASE_SERVICE_ROLE_KEY` de `process.env` | Já correto; garantir que nunca entre no bundle de cliente |
| 14 | `.env.example` | 19-20 | só chaves fiscais | Documentar `SUPABASE_SERVICE_ROLE_KEY` como exclusiva de servidor |

**Leitura administrativa segue funcionando sem mudança:** `app.admin.logs.tsx` (SELECT em
`server_logs`) e `app.admin.auditoria.tsx:23` (SELECT em `audit_logs`) passam por
`is_platform_admin()`.

---

## 5. Estratégia de perfil e papel inicial

```
Cadastro (auth.users INSERT)
  └─► [trigger on_auth_user_created — COMENTADO, ativar manualmente]
        └─► public.handle_new_user()            [SECURITY DEFINER, search_path='']
              ├─ INSERT public.profiles (id, nome, empresa, segment)
              │    · segment vem de raw_user_meta_data->>'segment', default 'complete'
              │    · permissions recebe o default jsonb da tabela
              └─ INSERT public.user_roles (user_id, 'vendedor')   ← SEMPRE 'vendedor'
```

**Primeiro administrador — procedimento manual (§16.3 do SQL):**

1. Criar o usuário pelo **Dashboard** do Supabase ou pela Auth Admin API. Nunca por migration.
2. Copiar o UUID no Dashboard.
3. No SQL Editor, executar **uma vez**:
   `insert into public.user_roles (user_id, role) values ('<UUID>', 'admin');`
4. Conferir: `select * from public.user_roles where role = 'admin';`
5. Registrar quem executou e quando, **fora do repositório**.

**Fazer isso ANTES de abrir o cadastro público.** Enquanto não houver nenhum admin, telas
administrativas ficam inacessíveis — o que é o comportamento seguro.

---

## 6. Estratégia multiempresa

**Modelo atual: dormente e compatível para trás.**

- `owner_id` é o isolamento **efetivo** hoje — o frontend nunca envia `company_id` (auditoria §8).
- `company_id` existe como coluna **nullable** em `customers`, `quotes`, `quote_items`,
  `inventory_items`. Nenhum backfill, nenhum `NOT NULL`.
- Toda policy segue a forma:
  `owner_id = auth.uid() OR (company_id IS NOT NULL AND is_company_member(company_id, auth.uid()))`
  — o primeiro ramo mantém o produto funcionando exatamente como hoje.
- **Endurecimento no INSERT:** `owner_id` **precisa** ser `auth.uid()`, e `company_id`, se
  informado, precisa ser de uma empresa da qual o usuário é membro. As migrations antigas
  aceitavam `owner_id` de terceiros — a baseline não aceita (regra 13).
- Escrita sensível (UPDATE/DELETE em contexto de empresa) exige `is_company_admin`.
- `company_members.role = 'owner'` só pode ser atribuído por quem já é `owner`.

**Ativação futura** (fora desta fase): criar `company_profiles` por assinante → popular
`company_members` → backfill de `company_id` → `NOT NULL` → passar a enviar `company_id` no
frontend. Ver P-16.

---

## 7. Dados que vão para o seed

| Bloco | Tabela | Linhas | Classificação |
|---|---|---|---|
| **A.1** | `platform_plans` | 5 | Catálogo obrigatório |
| **A.2** | `platform_modules` | 10 | Catálogo obrigatório |
| **A.3** | `plan_module_access` | 20 (via `SELECT`) | Catálogo obrigatório |
| **A.4** | `project_categories` | 10 | Catálogo obrigatório |
| **A'.1** | `plans` | 2 | **Catálogo comercial — confirmar preços** |
| **A'.2** | `plan_model_limits` | 17 | **Catálogo comercial — confirmar limites** |
| **B** | — | **0** | Demonstrativo — intencionalmente vazio |

Todos os blocos são idempotentes (`ON CONFLICT ... DO UPDATE`). Nenhum `INSERT` em `auth.users`,
nenhum UUID fixo, nenhum e-mail, nenhuma senha.

**Bloco B vazio** porque todo dado operacional depende de um `owner_id`/`company_id` real —
inventar UUID quebraria as FKs em qualquer outro ambiente e violaria as regras 1, 2 e 20.

---

## 8. Plano de Storage — **fora da baseline**

`types.ts` não descreve Storage, e um dump do schema `public` também não o traria.
**Nada de Storage foi incluído no `initial_schema.sql`.** Passou para a migration 02 — ver §12.

### 8.1 Buckets necessários

| Bucket | Público/Privado | Estado final segundo as migrations | Consumo no código |
|---|---|---|---|
| `project-images` | **Privado** | criado `public = true` em `20260520020447`; alterado para `public = false` em `20260601234312` | `src/components/StorageImage.tsx:30` (`createSignedUrl`, 7 dias); `src/routes/_authenticated/app.orcamentos.novo.tsx:545` (`upload`) |

**É o único bucket.** Nenhum outro bucket é referenciado pelo código, e nenhum bucket criado
fica sem uso.

### 8.2 Policies de `storage.objects` a recriar

Estado final derivado das migrations (4 policies ativas):

| Policy | Operação | Papel | Condição |
|---|---|---|---|
| `project-images owner select` | SELECT | `authenticated` | `bucket_id = 'project-images' AND auth.uid()::text = (storage.foldername(name))[1]` |
| `project-images owner insert` | INSERT | `authenticated` | idem |
| `project-images owner update` | UPDATE | `authenticated` | idem |
| `project-images owner delete` | DELETE | `authenticated` | idem |

Removidas ao longo do histórico e **não devem voltar**: `project-images public read`,
`Public can read project-images` (`TO anon`), e as 4 policies amplas de `20260621021248`.

### 8.3 Paths

Convenção: `{auth.uid()}/{uuid}.{ext}` — confirmada em `app.orcamentos.novo.tsx:544`.
Compatível com `(storage.foldername(name))[1]`.

### 8.4 Restrições de upload — **ausentes**

O bucket foi criado sem `file_size_limit` e sem `allowed_mime_types`. **Definir antes de
produção** (sugestão: 10 MB, `image/jpeg`, `image/png`, `image/webp`).

### 8.5 O que `db diff` não captura

- Criação e flags dos buckets (linhas de `storage.buckets`)
- `file_size_limit`, `allowed_mime_types`
- Policies do schema `storage` (fora de `--schema public`)
- Configurações de Auth: redirect URLs, confirmação de e-mail, expiração de OTP, provedores
- Segredos e webhooks

**Ação:** ao criar o projeto novo, aplicar Storage por script dedicado e **documentar as
configurações de Auth manualmente** — `supabase/config.toml` hoje só tem `project_id`.

---

## 9. Plano de Realtime — **fora da baseline**

A migration inicial não mexe na publicação. As duas tabelas necessárias entraram na migration 02 — ver §12.

### 9.1 O que o código realmente assina

| Componente | Canal | Tabela | Evento |
|---|---|---|---|
| `src/components/NotificationsBell.tsx:20` | `auth_events_bell` | `auth_events` | `postgres_changes` |
| `src/routes/_authenticated/app.admin.notificacoes.tsx:46` | `auth_events` | `auth_events` | `postgres_changes` |
| `src/routes/_authenticated/app.admin.logs.tsx:45` | `server_logs` | `server_logs` | INSERT |

### 9.2 Tabelas que precisariam entrar em `supabase_realtime`

`public.auth_events` e `public.server_logs` — **e nenhuma outra**.

### 9.3 Estado atual

Ambas foram **adicionadas** (`20260519163949`, `20260519172529`) e depois **removidas**
(`20260601234312`). Os três componentes conectam e **nunca recebem evento**, sem erro visível.

### 9.4 Decisão necessária

| Opção | Efeito |
|---|---|
| **A** — republicar as duas | Realtime volta a funcionar. RLS continua valendo: só admins recebem. Requer `replica identity` adequada. |
| **B** — remover os canais do frontend | Assume-se polling pelo botão "Atualizar". Menos carga, menos código. |

Combina com a decisão de P-07: se os logs passarem a ser escritos por `service_role` no servidor,
o realtime continua funcionando normalmente (a publicação é independente de quem insere).

---

## 10. Plano para regenerar `types.ts`

**Não regenerar agora.** `src/integrations/supabase/types.ts` é hoje a **fonte primária** da
baseline — sobrescrevê-lo destruiria a única evidência do schema real.

Sequência correta, no ambiente **local**:

```
1. supabase start                       # stack local em Docker
2. supabase db reset                    # aplica baseline + seed do zero
3. supabase gen types typescript --local > /tmp/types.new.ts
4. diff /tmp/types.new.ts src/integrations/supabase/types.ts
```

**Critério de aceite:** as **13 tabelas usadas pelo frontend** (`customers`, `quotes`,
`quote_items`, `project_templates`, `profiles`, `user_roles`, `inventory_items`, `subscriptions`,
`billing_notifications`, `auth_events`, `server_logs`, `user_subscriptions`, `audit_logs`) devem
sair **idênticas**, com duas diferenças esperadas e desejadas:

- `audit_logs` **passa a existir** (hoje ausente) — P-02
- `quote_items` ganha `drawing_data`, `drawing_notes`, `updated_at` — P-03

As 48 tabelas excluídas vão desaparecer do `types.ts` novo. Isso é **esperado**; confirme que
nenhuma delas é referenciada por código antes de aceitar.

`types.ts` só é substituído **depois** que a baseline for promovida a `supabase/migrations/`.

---

## 11. Critérios de promoção — checklist (promoção executada em 2026-07-21)

### Bloco 1 — Fonte de verdade
- [ ] **P-00 fechada**: confirmado de qual projeto veio o dump (hipótese A, B ou C)
- [ ] Se hipótese A/C — dump refeito com `--linked` no projeto antigo e baseline reconferida
- [ ] Se hipótese B — registrado que não há migração de dados e a baseline é criação limpa
- [x] ~~`supabase db dump --schema storage`~~ — **desnecessário**: o projeto de origem foi descartado; o Storage foi definido a partir do uso real no código (§12)
- [x] ~~P-19: nenhuma das 48 tabelas excluídas tem dado real~~ — **resolvida** pelo dump (condicional a P-00)
- [ ] P-03 confirmada no teste local (editor de desenho funciona contra a baseline)

### Bloco 2 — Validação local
- [ ] `supabase start` sobe sem erro
- [ ] `supabase db reset` termina **sem nenhum ERROR**
- [ ] `supabase db lint --level warning` sem findings de nível `error`
- [ ] `types.ts` regenerado bate com o atual nas 13 tabelas em uso (§10)
- [ ] `bun run build` e `bunx tsc --noEmit` continuam passando

### Bloco 3 — Testes funcionais locais
- [ ] Signup cria `profiles` + `user_roles('vendedor')` — **e não `admin`**
- [ ] Promoção manual do primeiro admin funciona (§16.3 do SQL)
- [ ] CRUD completo de cliente → orçamento → item
- [ ] Editor de desenho grava e lê `drawing_data`
- [ ] Upload de imagem + URL assinada
- [ ] Tela de assinatura e RPC `generate_billing_notifications`

### Bloco 4 — Testes negativos de RLS (obrigatórios)
- [ ] Usuário B **não** lê `customers`/`quotes`/`inventory_items` do usuário A (0 linhas, não erro)
- [ ] Usuário comum **não** consegue `INSERT` em `user_roles`
- [ ] Usuário comum **não** altera `profiles.permissions` nem `profiles.ativo`
- [ ] Usuário comum **não** lê `auth_events`, `server_logs`, `audit_logs`
- [ ] `has_role(<uuid de outro>, 'admin')` retorna `false`
- [ ] `anon` não lê nenhuma tabela de `public`
- [ ] Membro da empresa X **não** lê `charges`/`fiscal_invoices` da empresa Y

### Bloco 5 — Decisões humanas pendentes
- [x] **P-07** — estratégia de logs escolhida: **opção A** (só `service_role`). Fechada no
      schema em 2026-07-21; 14 pontos de código pendentes (§4.3)
- [ ] **P-09** — destino dos 13 templates iniciais
- [x] **P-05** — `certificate_password` **removida e não substituída**; integração fiscal
      segura adiada para migration futura (§4.2)
- [x] **P-13** — bucket `project-images` privado, 5 MiB, MIME restrito, 4 policies (§12)
- [x] **P-14** — `auth_events` e `server_logs` republicadas; entrega validada (§12)
- [ ] **P-08** — como o admin da plataforma verá os agregados
- [ ] Trigger `on_auth_user_created` revisado e **descomentado**

### Bloco 6 — Promoção · **executado em 2026-07-21**
- [x] As 49 migrations antigas foram **removidas**, não movidas. Decisão revista: não existe
      `supabase/migrations_legacy/`, `docs/migrations-antigas/` nem ZIP no repositório —
      elas não reproduzem um banco válido, não serão usadas e algumas carregam dado sensível.
      O histórico está no Git e na tag `backup/pre-baseline-supabase`
- [x] `20260721000000_baseline.sql` → `supabase/migrations/20260721000000_initial_schema.sql`
- [x] `seed.sql` → `supabase/seed.sql`
- [x] `PENDENCIAS.md` → `docs/PENDENCIAS_SUPABASE.md`; pasta `supabase/baseline-draft/` removida
- [x] `supabase/config.toml` com `project_id = "vidro-metal-mestre"` (**local**, não o ref remoto)
- [x] `types.ts` regenerado a partir do banco **local oficial**
- [ ] `.env.example` corrigido (`VITE_SUPABASE_PUBLISHABLE_KEY`, não `ANON_KEY`; documentar `SUPABASE_SERVICE_ROLE_KEY`) — **fora do escopo desta fase**
- [ ] Projeto novo vinculado (`project_id` remoto no `config.toml`) — **ainda não**
- [ ] Admin inicial criado pelo Dashboard **antes** de abrir o cadastro
- [ ] `supabase db push --dry-run` revisado linha a linha

> **Nenhum `db push` antes do Bloco 4 passar inteiro.** Um erro de RLS descoberto em produção
> é um vazamento entre assinantes, não um bug.


---

## 12. Migration 02 — Storage e Realtime (2026-07-21)

**Arquivo:** `supabase/migrations/20260721010000_storage_realtime.sql`
**Regra que a governou:** só entra o que o código em `src/` comprovadamente usa. Nada foi
adicionado "para o futuro". Cada objeto tem, no SQL, o arquivo e a linha que o exigem.
A migration inicial **não foi tocada**.

### 12.1 Storage — bucket `project-images`

Inventário de todo o `src/`: **1 bucket, 3 pontos de uso**.

| Arquivo | Linha | Operação | Path | Coluna que guarda |
|---|---|---|---|---|
| `app.estoque.tsx` | 461 | `upload` | `${user.id}/estoque/${uuid}.${ext}` | `inventory_items.imagem_url` |
| `app.orcamentos.novo.tsx` | 545 | `upload` (`upsert:false`) | `${user.id}/${uuid}.${ext}` | `project_templates.imagem_url` |
| `StorageImage.tsx` | 30 | `createSignedUrl` (7 dias) | path lido da coluna | — |

Não existe `getPublicUrl`, `.remove()`, `.list()`, `.download()`, `.update()`, `.move()`,
`.copy()`, nem segundo bucket. As colunas guardam **path**, não URL.

**Bucket:** `public = false` · `file_size_limit = 5 MiB` ·
`allowed_mime_types = {image/jpeg, image/png, image/webp, image/gif, image/avif}`.
Colunas conferidas em `\d storage.buckets` no banco local antes de escrever o INSERT —
nenhuma inventada.

**4 policies em `storage.objects`**, todas restritas a `bucket_id = 'project-images'` e a
`(storage.foldername(name))[1] = auth.uid()::text`: SELECT, INSERT, UPDATE, DELETE, só para
`authenticated`. Nenhuma para `anon`; nenhuma genérica; nenhum `USING (true)`/
`WITH CHECK (true)`. `service_role` opera por bypass de RLS. Path sem pasta faz
`foldername()` retornar `{}`, o índice `[1]` vira NULL e o acesso é **negado** — falha fechada.

**Nenhuma incompatibilidade com o frontend.** Era o risco central da pendência: bucket
privado quebraria o app se ele usasse `getPublicUrl`. Não usa — já lê por URL assinada.
**Zero arquivos de `src/` precisam mudar.**

### 12.2 Realtime — 2 tabelas publicadas

| Arquivo | Linha | Canal | Tabela | Eventos | Usa `payload.old`? |
|---|---|---|---|---|---|
| `NotificationsBell.tsx` | 20-30 | `auth_events_bell` | `auth_events` | INSERT, UPDATE, DELETE | não |
| `app.admin.notificacoes.tsx` | 46-53 | `auth_events` | `auth_events` | INSERT | não |
| `app.admin.logs.tsx` | 45-50 | `server_logs` | `server_logs` | INSERT | não |

Só `public.auth_events` e `public.server_logs` entraram em `supabase_realtime`. A publicação
não foi recriada e nada foi removido dela. As outras 38 tabelas ficaram de fora.

**REPLICA IDENTITY mantida em DEFAULT.** Nenhum callback lê `payload.old`; os que reagem a
UPDATE/DELETE descartam o payload e refazem a consulta. `FULL` colocaria todas as colunas
antigas no WAL — inclusive e-mail e `metadata` de `auth_events` — sem consumidor.

### 12.3 Testes executados

**Storage — 10/10**, contra o serviço real em `127.0.0.1:55321`, com JWTs sintéticos:
`anon` upload ❌403 · A no próprio path ✅200 · A na pasta de B ❌403 · B baixa de A ❌400 ·
B assina URL de A ❌404 · B atualiza de A ❌403 · B remove de A ❌403 (arquivo intacto) ·
A baixa e assina o próprio ✅200 · `text/plain` ❌415 · 6 MiB ❌413 · `service_role` ✅200 ·
0 policies de escrita permissivas.

**Realtime — entrega validada em WebSocket real**, dois assinantes simultâneos, `INSERT`
em `server_logs` por `service_role`: admin da plataforma recebeu **1** evento; usuário comum
assinou com sucesso e recebeu **0**. A RLS é aplicada na entrega, não só na consulta.
Sem limitação de teste a registrar.

`db reset` aplicou as duas migrations na ordem correta e o seed; `db lint --level warning`
sem findings. Nenhuma migration antiga foi executada.

### 12.4 Registrado para depois, sem ação nesta fase

- **Isolamento de Storage é por usuário, não por empresa** — coerente com `owner_id` e com
  P-16. Ativar multiempresa exigirá migrar path e policies para `company_id`.
- **Imagem órfã:** nada apaga o objeto quando a linha some. A policy de DELETE já existe.
- **HEIC/HEIF de iPhone é recusado** pela lista de MIME — decidir entre converter no cliente
  ou ampliar a lista se aparecer no uso real.
- **`NotificationsBell` fica sempre zerado para o vendedor**, porque `auth_events` é
  admin-only. Comportamento correto; notificação para usuário comum exige tabela própria,
  não afrouxar a RLS.

---

## 13. Migration 03 — provisionamento de usuários (2026-07-22)

`supabase/migrations/20260722000000_auth_user_provisioning.sql`

### 13.1 Por que existiu

A baseline §16.1 já trazia `public.handle_new_user()` pronta, mas com o `create trigger`
**comentado de propósito**, aguardando revisão manual do fluxo de cadastro. Enquanto isso,
todo signup criava só a linha em `auth.users`: `profiles` e `user_roles` ficavam vazios e o
frontend compensava com um `"vendedor"` de fallback **não persistido**, invisível para RLS.
Esta migration faz a revisão pedida e liga o gatilho.

### 13.2 O que faz

| Objeto | Ação |
|---|---|
| `public.handle_new_user()` | `create or replace` — versão endurecida |
| `on_auth_user_created` | `create trigger … after insert on auth.users for each row` |

Endurecimentos em relação à versão da baseline:

- `segment` vindo de metadata é validado contra a lista de `profiles_segment_check`;
  valor inválido degrada para `'complete'` em vez de violar a constraint e derrubar o
  cadastro inteiro;
- `nome` e `empresa` passam por `btrim` + `left(…, 120)`;
- `on conflict do nothing` nas duas inserções, apoiado em constraints reais;
- comentários explicitando que metadata **nunca** concede privilégio.

### 13.3 Descoberta operacional

`comment on trigger … on auth.users` **falha** com `must be owner of relation users`
(42501): `auth.users` pertence a `supabase_auth_admin` e o papel das migrations
(`postgres`) tem privilégio de TRIGGER mas não é dono. `create trigger` funciona;
`comment on trigger` não. A descrição do gatilho ficou em comentário SQL e no
`comment on function`.

### 13.4 Testes executados

**Local** (`supabase start` + `db reset --local`, três migrations + seed):

| Bloco | Resultado |
|---|---|
| `db lint --local --level warning` | `No schema errors found` |
| Dois usuários sintéticos, 18 asserções de cliente | 18/18 |
| Contagens: 2 usuários / 2 profiles / 2 papéis `vendedor` / 0 admin / 0 `company_members` | ✅ |
| Sem órfãos, sem duplicatas, 1 trigger em `auth.users` | ✅ |
| Metadata maliciosa (`role=admin`, `is_admin=true`, `company_id`, `permissions`, `ativo=false`, `segment` inválido) | integralmente ignorada |
| Escalada: alterar próprio papel / inserir papel / atribuir papel a terceiro | bloqueadas (`42501`) |
| `is_platform_admin` = false · `has_role` próprio = true · `has_role` de terceiro = false | ✅ |
| Login, reload, logout+login sem duplicar registros | ✅ |

**Atomicidade** — trigger temporário local (fora de qualquer migration) forçou o INSERT em
`profiles` a falhar. Resultado: signup rejeitado com `500 Database error saving new user` e
`auth.users` **inalterado**. Nenhum usuário sem profile, nenhum profile sem papel, nenhum
papel sem profile. Confirma que o gatilho roda na transação do INSERT em `auth.users`.

**Remoto** — usuário criado pelo Dashboard com *Auto Confirm*:
1 usuário / 1 profile / 1 papel `vendedor` / 0 admin / 0 `company_members`, sem órfãos nem
duplicatas, `ativo = true`, `permissions` no default, `segment = 'complete'`.
Login, reload e escrita em `user_roles` exigem sessão e ficaram cobertos apenas pelo teste
local — o Dashboard não expôs campo de metadata para reproduzir a carga maliciosa no remoto.

### 13.5 Botão Google

Provider desabilitado no projeto novo (`external.google = false`). Flag
`GOOGLE_OAUTH_ENABLED = false` em `src/routes/auth.tsx` oculta o botão; o fluxo OAuth
foi preservado para reativação. Ver P-24 em `docs/PENDENCIAS_SUPABASE.md`.
