# Bootstrap do primeiro administrador da plataforma

Procedimento manual para promover **um** usuário já existente a administrador da
plataforma no projeto Supabase remoto.

> **Não execute este SQL antes de criar o usuário no Dashboard.** O script falha
> de propósito se o UUID não existir em `auth.users`.

---

## 1. Por que é manual

O schema oficial não cria administradores sozinho:

- **não existe trigger em `auth.users`** — nenhuma linha em `public.profiles` ou
  `public.user_roles` é criada automaticamente no cadastro;
- a lógica antiga *"o primeiro usuário vira admin"* foi **removida** de propósito
  (era uma janela de sequestro em banco vazio — ver comentário em
  `supabase/migrations/20260721000000_initial_schema.sql`, §14);
- o enum `public.app_role` **não possui** `super_admin`. O papel de plataforma é
  exatamente `'admin'`.

Promoção é, portanto, uma operação deliberada e única.

---

## 2. Estrutura relevante (conferida no banco remoto)

### `public.profiles`

| Coluna | Tipo | Nulo | Padrão |
|---|---|---|---|
| `id` | `uuid` | não | — (PK, FK → `auth.users(id)` ON DELETE CASCADE) |
| `nome` | `text` | sim | — |
| `telefone` | `text` | sim | — |
| `empresa` | `text` | sim | — |
| `ativo` | `boolean` | não | `true` |
| `segment` | `text` | não | `'complete'` |
| `permissions` | `jsonb` | não | objeto com as 7 permissões |
| `created_at` / `updated_at` | `timestamptz` | não | `now()` |

Constraint: `profiles_segment_check` — `segment` ∈
`('glass','steel','woodworking','stone','complete')`.

> `profiles` **não possui** coluna `company_id`. O vínculo com empresa é feito por
> `public.company_members`, e não é necessário para o admin de plataforma.

### `public.user_roles`

| Coluna | Tipo | Nulo | Padrão |
|---|---|---|---|
| `id` | `uuid` | não | `gen_random_uuid()` |
| `user_id` | `uuid` | não | — (FK → `auth.users(id)` ON DELETE CASCADE) |
| `role` | `public.app_role` | não | — |
| `created_at` | `timestamptz` | não | `now()` |

Constraint: `user_roles_user_id_role_key` — `UNIQUE (user_id, role)`. É ela que
torna o `on conflict do nothing` seguro e idempotente.

### Função de autorização

```sql
public.is_platform_admin(_user_id uuid default auth.uid())
  -> select public.has_role(_user_id, 'admin'::public.app_role)
```

Ou seja: **basta uma linha em `user_roles` com `role = 'admin'`** para o usuário
ser reconhecido. O perfil é criado junto porque a aplicação (`useAuth`) lê
`profiles.permissions` e `user_roles.role` no login.

---

## 3. Passo a passo

1. **Dashboard → Authentication → Users → Add user**
   - marque **Auto Confirm User** (evita depender do e-mail de confirmação);
   - defina uma senha forte, guardada no gerenciador de senhas.
2. Abra o usuário criado e **copie o UUID** (campo `UID`).
3. **Dashboard → SQL Editor → New query**, cole o bloco da seção 4.
4. Substitua **as três ocorrências** de `<ADMIN_USER_UUID>` pelo UUID copiado.
5. Execute. Depois execute a consulta de verificação da seção 5.
6. Faça login na aplicação e confirme o acesso às rotas `/app/admin/*`.

---

## 4. Transação de promoção

```sql
-- Promove UM usuário a administrador da plataforma.
-- Idempotente: pode ser reexecutado sem efeito colateral.
-- Substitua <ADMIN_USER_UUID> pelo UID copiado do Dashboard.

begin;

do $$
declare
  v_user_id uuid := '<ADMIN_USER_UUID>';
begin
  -- Guarda: exige que o usuário já exista. Não cria nem altera auth.users.
  if not exists (select 1 from auth.users u where u.id = v_user_id) then
    raise exception
      'UUID % nao encontrado em auth.users. Crie o usuario em Authentication -> Users antes de executar.',
      v_user_id;
  end if;

  -- Perfil mínimo. Não sobrescreve nome/telefone/empresa/permissões já existentes.
  insert into public.profiles (id, ativo, segment)
  values (v_user_id, true, 'complete')
  on conflict (id) do update
    set ativo      = true,
        updated_at = now();

  -- Papel administrativo. A UNIQUE(user_id, role) garante idempotência.
  insert into public.user_roles (user_id, role)
  values (v_user_id, 'admin'::public.app_role)
  on conflict (user_id, role) do nothing;
end
$$;

commit;
```

### Garantias desta transação

| Requisito | Como é atendido |
|---|---|
| Não promove qualquer outro usuário | Todo DML filtra por `v_user_id`; não há `where role = ...` amplo nem update em massa |
| Não depende de "primeiro usuário" | O UUID é fornecido explicitamente; nenhuma consulta ordena por `created_at` |
| Não altera `auth.users` | Apenas `select` de verificação sobre `auth.users` |
| Não remove papéis existentes | Nenhum `delete`; o `on conflict do nothing` preserva o que já houver |
| Executável uma única vez | `on conflict` em ambas as tabelas torna a reexecução um no-op |
| Atômica | Tudo entre `begin` / `commit`; a exceção da guarda aborta a transação inteira |

---

## 5. Verificação

```sql
select
  u.id                                                      as usuario,
  (select count(*) from public.profiles p
     where p.id = u.id)                                     as tem_perfil,
  (select count(*) from public.user_roles r
     where r.user_id = u.id and r.role = 'admin')           as tem_papel_admin,
  public.is_platform_admin(u.id)                            as reconhecido_como_admin,
  (select count(*) from public.user_roles
     where role = 'admin')                                  as total_admins_na_plataforma
from auth.users u
where u.id = '<ADMIN_USER_UUID>';
```

Resultado esperado:

| Campo | Valor |
|---|---|
| `tem_perfil` | `1` |
| `tem_papel_admin` | `1` |
| `reconhecido_como_admin` | `true` |
| `total_admins_na_plataforma` | `1` na primeira execução |

Se `total_admins_na_plataforma` for maior que o esperado, **investigue antes de
prosseguir** — significa que outro usuário já possui o papel.

---

## 6. Reversão

```sql
-- Remove apenas o papel administrativo, preservando perfil e usuário.
delete from public.user_roles
where user_id = '<ADMIN_USER_UUID>'
  and role = 'admin';
```

---

## 7. Observação sobre o usuário de homologação

A conta usada para testar os fluxos de autenticação **não deve** ser promovida.
Mantenha o administrador em uma conta separada e identificável.
