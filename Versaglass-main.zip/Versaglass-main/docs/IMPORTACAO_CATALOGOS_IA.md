# Importação de Catálogos com IA

## Fluxo

PDF + Kit → IA externa → ZIP → TUS → staging → revisão → publicação → catálogo global → adoção pelo estoque.

## Permissões

| Papel | Capacidade |
|-------|------------|
| Super Admin (`user_roles.role = admin`) | Importação, Kit, staging, revisão, aprovação, publicação |
| Usuário autenticado (membro) | Consulta do catálogo global (produtos ativos) |
| Gestão de estoque | Adoção e CRUD de `inventory_items` |

**Gestão de estoque** (UI + RLS + RPC de adoção) exige:

- membership ativo na empresa; **e**
- papel empresarial `owner` / `admin` / `manager`, **ou** checkbox `profiles.permissions.manage_estoque`.

Platform admin **sem** membership **não** gerencia estoque de terceiros.

Company admin **não** herda importação administrativa da plataforma.

## Limites

| Recurso | Limite |
|---------|--------|
| ZIP compactado | 50 MiB |
| Entradas no ZIP | 2.500 |
| Itens no manifesto | 1.000 |
| Imagem individual | 5 MiB (declared size + stream + MIME) |
| Imagens técnicas por item | 20 |
| Total descompactado | 250 MiB |

## Segurança

- JSON Schema no manifesto
- MIME real / magic bytes
- Proteção ZIP bomb e path traversal
- RLS por membership / platform admin
- Claims atômicos (process / publish)
- Unique constraints (fabricante, produto, adoção)
- TUS com `upsert=false` e path gerado no servidor
- Sem service role no frontend
- `can_manage_company_estoque` na escrita de estoque e na adoção

## Catálogo × estoque

| Entidade | Papel |
|----------|--------|
| `manufacturer_products` | Dados técnicos globais (somente Super Admin escreve) |
| `inventory_items` | Snapshot comercial por empresa |

Vínculo: `inventory_items.manufacturer_product_id` (proveniência).

**Sem sincronização automática** após a adoção.

Imagem do estoque:

1. `inventory_items.imagem_url` (`project-images`)
2. senão `manufacturer_products.primary_image_path` (`manufacturer-catalog`)
3. senão placeholder

## Jobs órfãos (v1)

`awaiting_upload` / `processing` abandonados não têm worker/cron nesta versão.

- Nova importação pode ser iniciada sem corromper o catálogo publicado.
- GC automático fica como pós-MVP.
- `processing` preso após timeout abrupto é raro e recuperável manualmente (documentado).

## Riscos conhecidos (pós Fase 5)

- Homologação E2E live completa depende de Docker local ou ambiente de teste dedicado (não poluir produção).
- Jobs `awaiting_upload` / `processing` podem exigir GC manual ou futuro (sem worker/cron na v1).
- Processamento serverless de catálogo muito denso ainda possui risco operacional de timeout.
- Sales RPCs DEFINER continuam atualizando quantidade sem passar pela RLS de manage_estoque (baixa/estorno de venda — comportamento pré-existente intencional).
